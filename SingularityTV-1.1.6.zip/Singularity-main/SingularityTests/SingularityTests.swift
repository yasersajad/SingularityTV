import XCTest
@testable import SingularityTV

final class SingularityTests: XCTestCase {
    func testSemanticVersionComparison() {
        XCTAssertEqual(SemanticVersion.compare("1.1.5", "1.1.6"), .orderedAscending)
        XCTAssertEqual(SemanticVersion.compare("v3.0.0", "3.0.0"), .orderedSame)
        XCTAssertEqual(SemanticVersion.compare("3.1.0", "3.0.9"), .orderedDescending)
    }

    func testDurationFormattingHandlesNonFiniteAndNegativeInputsWithoutTrap() {
        XCTAssertEqual(NF.compactDuration(seconds: .nan), "1m")
        XCTAssertEqual(NF.compactDuration(seconds: .infinity), "1m")
        XCTAssertEqual(NF.compactDuration(seconds: -100), "1m")
        XCTAssertEqual(NF.compactDuration(seconds: 0), "1m")
        XCTAssertEqual(NF.compactDuration(seconds: 5400), "1h 30m")
        XCTAssertEqual(NF.runtimeText(minutes: nil), nil)
        XCTAssertEqual(NF.runtimeText(minutes: 0), nil)
        XCTAssertEqual(NF.runtimeText(minutes: 135), "2h 15m")
    }

    @MainActor
    func testProfileSanitizationDeduplicatesAndCapsAtFive() {
        let input = [
            UserProfile(id: "p1", name: "One", avatarColor: "#E50914", isKids: false, createdAt: 1),
            UserProfile(id: "p1", name: "Duplicate", avatarColor: "#E50914", isKids: false, createdAt: 2),
            UserProfile(id: "", name: "EmptyID", avatarColor: "#E50914", isKids: false, createdAt: 3),
            UserProfile(id: "p2", name: "Two", avatarColor: "#3B82F6", isKids: true, createdAt: 4),
            UserProfile(id: "p3", name: "Three", avatarColor: "#10B981", isKids: false, createdAt: 5),
            UserProfile(id: "p4", name: "Four", avatarColor: "#8B5CF6", isKids: false, createdAt: 6),
            UserProfile(id: "p5", name: "Five", avatarColor: "#EC4899", isKids: false, createdAt: 7),
            UserProfile(id: "p6", name: "Six", avatarColor: "#06B6D4", isKids: false, createdAt: 8)
        ]
        let sanitized = SingularitySessionManager.sanitizeProfiles(input, fallbackName: "Main")
        XCTAssertEqual(sanitized.count, 5)
        XCTAssertEqual(sanitized.map(\.id), ["p1", "p2", "p3", "p4", "p5"])
        XCTAssertEqual(sanitized[0].name, "One")
    }

    @MainActor
    func testDiagnosticsBreadcrumbsIncludeOperationAndExecutorMetadata() {
        SingularityDiagnostics.shared.clear()
        SingularityDiagnostics.shared.record(
            category: "ProfileSwitchBegin",
            message: "Testing switch",
            operationID: "op1234",
            generationID: 42,
            profileID: "prof_test"
        )
        let report = SingularityDiagnostics.shared.formattedReport()
        XCTAssertTrue(report.contains("ProfileSwitchBegin"))
        XCTAssertTrue(report.contains("op=op1234"))
        XCTAssertTrue(report.contains("gen=42"))
        XCTAssertTrue(report.contains("prof=prof_test"))
        XCTAssertTrue(report.contains("[MainActor]"))
    }

    @MainActor
    func testSearchModelRapidQueryChurnAndCancellationSafety() async {
        let model = NFSearchModel()
        model.query = "Inception"
        model.query = "Interstellar"
        model.query = ""
        XCTAssertTrue(model.results.isEmpty)
        XCTAssertFalse(model.isSearching)

        model.query = "Breaking Bad"
        model.cancelAll()
        try? await Task.sleep(for: .milliseconds(50))
        XCTAssertTrue(model.results.isEmpty)
    }

    @MainActor
    func testContinueWatchingAndHistoryIsolation() {
        let suiteName = "singularity.test.\(UUID().uuidString)"
        guard let defaults = UserDefaults(suiteName: suiteName) else {
            XCTFail("Failed to create isolated UserDefaults")
            return
        }
        defer { defaults.removePersistentDomain(forName: suiteName) }

        let cw = ContinueWatchingManager(userDefaults: defaults)
        let hist = WatchHistoryManager(userDefaults: defaults)
        let myList = MyListManager(userDefaults: defaults)

        let item = WatchItem(
            type: .movie,
            title: "Test Movie",
            tmdbId: "999",
            posterPath: nil,
            generatedURL: URL(string: "https://vidly.pro/movie/999")!
        )
        hist.add(item)
        XCTAssertEqual(hist.items.count, 1)

        cw.recordProgress(
            type: .movie,
            tmdbId: "999",
            title: "Test Movie",
            posterPath: nil,
            season: nil,
            episode: nil,
            episodeName: nil,
            positionSeconds: 120,
            durationSeconds: 3600
        )
        XCTAssertEqual(cw.items.count, 1)
        XCTAssertEqual(cw.resumeSeconds(type: .movie, tmdbId: "999", season: nil, episode: nil), 120)

        myList.add(MyListItem(
            mediaType: .movie,
            tmdbId: 999,
            title: "Test Movie",
            posterPath: nil,
            backdropPath: nil,
            overview: nil,
            year: nil,
            dateAdded: Date()
        ))
        XCTAssertTrue(myList.contains(mediaType: .movie, tmdbId: 999))
    }

    func testImagePipelineConcurrentPrefetchStress() async {
        let urls = (0..<25).compactMap { URL(string: "https://invalid.local/poster_\($0).jpg") }
        await withTaskGroup(of: Void.self) { group in
            for _ in 0..<4 {
                group.addTask {
                    NFImagePipeline.shared.prefetch(urls)
                }
            }
        }
        XCTAssertNil(NFImagePipeline.shared.cachedImage(for: urls[0]))
    }
}
