package com.singularity.tv.core.network

object SingularityConfig {
    const val APP_NAME = "SingularityTV"
    const val APP_VERSION = "1.1.6"
    const val SUPABASE_URL = "https://soufctreejgcpvqftxeb.supabase.co"
    const val SUPABASE_PUBLISHABLE_KEY = "sb_publishable_CRHhsCu1wvqdK7lUok8VfQ_IOBUqwJI"
    const val TELEGRAM_BOT_USERNAME = "SingularityTV_Official_Bot"
    const val TELEGRAM_CHANNEL_URL = "https://t.me/+IUpscNRqcqc4Y2Zk"
    const val TMDB_READ_TOKEN = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI3MTNlY2VkZmQ1NmVkNDZiMDBiZTg1N2Q3ODg3NTE1MSIsIm5iZiI6MTc3OTYyMzA4Mi4xNzUsInN1YiI6IjZhMTJlNGFhOWFkOWYxOWE3ZWE5Y2NiZiIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.8g0u3KwAVxnWszrKGfqvxrUl0VuG-_e0ZvTv5xDVRd4"
    const val PRIMARY_STREAM_HOST = "vidly.pro"
}
