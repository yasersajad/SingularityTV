package com.singularity.tv.core.network

import com.singularity.tv.core.model.WatchType

object StreamingProviderBuilder {
    @Volatile var customHostOverride: String = SingularityConfig.PRIMARY_STREAM_HOST
    @Volatile var accentHexOverride: String = "E50914"

    private fun cleanHost(): String {
        val raw = customHostOverride.trim().lowercase()
            .removePrefix("https://")
            .removePrefix("http://")
            .substringBefore("/")
        return raw.ifEmpty { SingularityConfig.PRIMARY_STREAM_HOST }
    }

    fun movieUrl(tmdbId: Int, progressSeconds: Int? = null): String {
        val hex = accentHexOverride.removePrefix("#").uppercase().ifEmpty { "E50914" }
        val base = "https://${cleanHost()}/embed/movie/$tmdbId?autoplay=true&color=$hex"
        return if (progressSeconds != null && progressSeconds >= 5) "$base&progress=$progressSeconds" else base
    }

    fun tvUrl(tmdbId: Int, season: Int, episode: Int, progressSeconds: Int? = null): String {
        val hex = accentHexOverride.removePrefix("#").uppercase().ifEmpty { "E50914" }
        val base = "https://${cleanHost()}/embed/tv/$tmdbId/$season/$episode?autoplay=true&color=$hex"
        return if (progressSeconds != null && progressSeconds >= 5) "$base&progress=$progressSeconds" else base
    }

    fun buildUrl(type: WatchType, tmdbId: Int, season: Int? = null, episode: Int? = null, progressSeconds: Int? = null): String {
        return when (type) {
            WatchType.MOVIE -> movieUrl(tmdbId, progressSeconds)
            WatchType.TV -> tvUrl(tmdbId, season ?: 1, episode ?: 1, progressSeconds)
        }
    }
}
