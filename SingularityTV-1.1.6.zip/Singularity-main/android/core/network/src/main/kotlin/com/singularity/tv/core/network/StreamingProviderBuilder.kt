package com.singularity.tv.core.network

import com.singularity.tv.core.model.WatchType

object StreamingProviderBuilder {
    fun movieUrl(tmdbId: Int, progressSeconds: Int? = null): String {
        val base = "https://${SingularityConfig.PRIMARY_STREAM_HOST}/embed/movie/$tmdbId?autoplay=true&color=E50914"
        return if (progressSeconds != null && progressSeconds >= 5) "$base&progress=$progressSeconds" else base
    }

    fun tvUrl(tmdbId: Int, season: Int, episode: Int, progressSeconds: Int? = null): String {
        val base = "https://${SingularityConfig.PRIMARY_STREAM_HOST}/embed/tv/$tmdbId/$season/$episode?autoplay=true&color=E50914"
        return if (progressSeconds != null && progressSeconds >= 5) "$base&progress=$progressSeconds" else base
    }

    fun buildUrl(type: WatchType, tmdbId: Int, season: Int? = null, episode: Int? = null, progressSeconds: Int? = null): String {
        return when (type) {
            WatchType.MOVIE -> movieUrl(tmdbId, progressSeconds)
            WatchType.TV -> tvUrl(tmdbId, season ?: 1, episode ?: 1, progressSeconds)
        }
    }
}
