package com.singularity.tv.core.network

import com.singularity.tv.core.model.SupabaseSession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class TelegramGateResult(
    val isMember: Boolean,
    val linked: Boolean,
    val channelUrl: String,
    val error: String? = null
)

object SupabaseClient {
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()

    suspend fun signIn(email: String, password: String): Result<SupabaseSession> = withContext(Dispatchers.IO) {
        runCatching {
            val payload = JSONObject().put("email", email).put("password", password).toString()
            val req = Request.Builder()
                .url("${SingularityConfig.SUPABASE_URL}/auth/v1/token?grant_type=password")
                .header("apikey", SingularityConfig.SUPABASE_PUBLISHABLE_KEY)
                .header("Content-Type", "application/json")
                .post(payload.toRequestBody(jsonMediaType))
                .build()
            http.newCall(req).execute().use { res ->
                val raw = res.body?.string().orEmpty()
                val obj = JSONObject(raw)
                if (!res.isSuccessful) {
                    error(obj.optString("error_description", obj.optString("msg", "Authentication failed")))
                }
                parseSession(obj)
            }
        }
    }

    suspend fun signUp(email: String, password: String, name: String): Result<SupabaseSession> = withContext(Dispatchers.IO) {
        runCatching {
            val meta = JSONObject().put("name", name)
            val payload = JSONObject().put("email", email).put("password", password).put("data", meta).toString()
            val req = Request.Builder()
                .url("${SingularityConfig.SUPABASE_URL}/auth/v1/signup")
                .header("apikey", SingularityConfig.SUPABASE_PUBLISHABLE_KEY)
                .header("Content-Type", "application/json")
                .post(payload.toRequestBody(jsonMediaType))
                .build()
            http.newCall(req).execute().use { res ->
                val raw = res.body?.string().orEmpty()
                val obj = JSONObject(raw)
                if (!res.isSuccessful) {
                    error(obj.optString("msg", obj.optString("error_description", "Sign up failed")))
                }
                parseSession(obj)
            }
        }
    }

    suspend fun refreshSession(refreshToken: String): Result<SupabaseSession> = withContext(Dispatchers.IO) {
        runCatching {
            val payload = JSONObject().put("refresh_token", refreshToken).toString()
            val req = Request.Builder()
                .url("${SingularityConfig.SUPABASE_URL}/auth/v1/token?grant_type=refresh_token")
                .header("apikey", SingularityConfig.SUPABASE_PUBLISHABLE_KEY)
                .header("Content-Type", "application/json")
                .post(payload.toRequestBody(jsonMediaType))
                .build()
            http.newCall(req).execute().use { res ->
                val raw = res.body?.string().orEmpty()
                val obj = JSONObject(raw)
                if (!res.isSuccessful) error("Session expired")
                parseSession(obj)
            }
        }
    }

    suspend fun checkTelegramGate(accessToken: String): TelegramGateResult = withContext(Dispatchers.IO) {
        runCatching {
            val body = JSONObject().put("action", "check").toString()
            val req = Request.Builder()
                .url("${SingularityConfig.SUPABASE_URL}/functions/v1/telegram-gate")
                .header("apikey", SingularityConfig.SUPABASE_PUBLISHABLE_KEY)
                .header("Authorization", "Bearer $accessToken")
                .header("Content-Type", "application/json")
                .post(body.toRequestBody(jsonMediaType))
                .build()
            http.newCall(req).execute().use { res ->
                val obj = JSONObject(res.body?.string().orEmpty())
                TelegramGateResult(
                    isMember = obj.optBoolean("member", false),
                    linked = obj.optBoolean("linked", false),
                    channelUrl = obj.optString("channelUrl", SingularityConfig.TELEGRAM_CHANNEL_URL)
                )
            }
        }.getOrElse {
            TelegramGateResult(false, false, SingularityConfig.TELEGRAM_CHANNEL_URL, it.message)
        }
    }

    suspend fun pullProfileData(accessToken: String, profileId: String?): JSONObject? = withContext(Dispatchers.IO) {
        val pid = profileId?.let { URLEncoder.encode(it, "UTF-8") } ?: ""
        val suffix = if (pid.isNotEmpty()) "&profileId=$pid" else ""
        val req = Request.Builder()
            .url("${SingularityConfig.SUPABASE_URL}/functions/v1/telegram-gate?action=sync_profile_pull$suffix")
            .header("apikey", SingularityConfig.SUPABASE_PUBLISHABLE_KEY)
            .header("Authorization", "Bearer $accessToken")
            .get()
            .build()
        runCatching {
            http.newCall(req).execute().use { res ->
                if (!res.isSuccessful) null else JSONObject(res.body?.string().orEmpty())
            }
        }.getOrNull()
    }

    suspend fun pushSyncPayload(accessToken: String, payload: JSONObject): Boolean = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url("${SingularityConfig.SUPABASE_URL}/functions/v1/telegram-gate?action=sync_push")
            .header("apikey", SingularityConfig.SUPABASE_PUBLISHABLE_KEY)
            .header("Authorization", "Bearer $accessToken")
            .header("Content-Type", "application/json")
            .post(payload.toString().toRequestBody(jsonMediaType))
            .build()
        runCatching {
            http.newCall(req).execute().use { it.isSuccessful }
        }.getOrDefault(false)
    }

    suspend fun manageProfile(accessToken: String, op: String, id: String? = null, name: String? = null, avatarColor: String? = null, isKids: Boolean = false): JSONObject? = withContext(Dispatchers.IO) {
        val body = JSONObject().put("action", "sync_profiles").put("op", op)
        if (id != null) body.put("id", id)
        if (name != null) body.put("name", name)
        if (avatarColor != null) body.put("avatarColor", avatarColor)
        body.put("isKids", isKids)
        val req = Request.Builder()
            .url("${SingularityConfig.SUPABASE_URL}/functions/v1/telegram-gate?action=sync_profiles")
            .header("apikey", SingularityConfig.SUPABASE_PUBLISHABLE_KEY)
            .header("Authorization", "Bearer $accessToken")
            .header("Content-Type", "application/json")
            .post(body.toString().toRequestBody(jsonMediaType))
            .build()
        runCatching {
            http.newCall(req).execute().use { res ->
                if (res.isSuccessful) JSONObject(res.body?.string().orEmpty()) else null
            }
        }.getOrNull()
    }

    private fun parseSession(obj: JSONObject): SupabaseSession {
        val user = obj.optJSONObject("user") ?: JSONObject()
        val meta = user.optJSONObject("user_metadata") ?: JSONObject()
        val email = user.optString("email", "")
        val name = meta.optString("name", email.substringBefore("@").ifEmpty { "User" })
        val expiresIn = obj.optLong("expires_in", 3600L)
        return SupabaseSession(
            accessToken = obj.getString("access_token"),
            refreshToken = obj.optString("refresh_token", ""),
            userId = user.getString("id"),
            email = email,
            name = name,
            expiresAtEpochSec = (System.currentTimeMillis() / 1000L) + expiresIn
        )
    }
}
