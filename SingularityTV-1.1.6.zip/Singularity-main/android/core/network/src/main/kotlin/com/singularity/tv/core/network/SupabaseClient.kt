package com.singularity.tv.core.network

import com.singularity.tv.core.model.SupabaseSession
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class TelegramGateResult(
    val isMember: Boolean,
    val linked: Boolean,
    val channelUrl: String,
    val error: String? = null
)

class EmailNotConfirmedException : Exception("Your email is not verified yet.")

sealed class SignUpOutcome {
    data class Authenticated(val session: SupabaseSession) : SignUpOutcome()
    data class NeedsVerification(val email: String) : SignUpOutcome()
}

object SupabaseClient {
    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()

    suspend fun signIn(email: String, password: String): Result<SupabaseSession> = withContext(Dispatchers.IO) {
        runCatching {
            val payload = JSONObject().put("email", email).put("password", password).toString()
            val req = Request.Builder()
                .url("${SingularityConfig.SUPABASE_URL}/auth/v1/token?grant_type=password")
                .header("apikey", SingularityConfig.SUPABASE_PUBLISHABLE_KEY)
                .header("Content-Type", "application/json")
                .post(payload.toRequestBody(jsonMediaType))
                .build()
            http.newCall(req).execute().use { res ->
                val raw = res.body?.string().orEmpty()
                val obj = JSONObject(raw)
                if (!res.isSuccessful) {
                    val msg = obj.optString("error_description", obj.optString("msg", obj.optString("message", "Authentication failed")))
                    if (msg.contains("not confirmed", ignoreCase = true)) {
                        throw EmailNotConfirmedException()
                    }
                    error(msg)
                }
                parseSession(obj)
            }
        }
    }

    suspend fun signUp(email: String, password: String, name: String): Result<SupabaseSession> = withContext(Dispatchers.IO) {
        runCatching {
            val meta = JSONObject().put("name", name)
            val payload = JSONObject().put("email", email).put("password", password).put("data", meta).toString()
            val req = Request.Builder()
                .url("${SingularityConfig.SUPABASE_URL}/auth/v1/signup")
                .header("apikey", SingularityConfig.SUPABASE_PUBLISHABLE_KEY)
                .header("Content-Type", "application/json")
                .post(payload.toRequestBody(jsonMediaType))
                .build()
            http.newCall(req).execute().use { res ->
                val raw = res.body?.string().orEmpty()
                val obj = JSONObject(raw)
                if (!res.isSuccessful) {
                    error(obj.optString("msg", obj.optString("error_description", "Sign up failed")))
                }
                parseSession(obj)
            }
        }
    }


    suspend fun signUpDetailed(email: String, password: String, name: String): Result<SignUpOutcome> = withContext(Dispatchers.IO) {
        runCatching {
            val cleanEmail = email.trim().lowercase()
            val resolvedName = name.trim().ifEmpty { cleanEmail.substringBefore("@").ifEmpty { "User" } }
            val meta = JSONObject().put("name", resolvedName)
            val payload = JSONObject().put("email", cleanEmail).put("password", password).put("data", meta).toString()
            val req = Request.Builder()
                .url("${SingularityConfig.SUPABASE_URL}/auth/v1/signup")
                .header("apikey", SingularityConfig.SUPABASE_PUBLISHABLE_KEY)
                .header("Content-Type", "application/json")
                .post(payload.toRequestBody(jsonMediaType))
                .build()
            http.newCall(req).execute().use { res ->
                val raw = res.body?.string().orEmpty()
                val obj = if (raw.isNotBlank()) JSONObject(raw) else JSONObject()
                if (!res.isSuccessful) {
                    error(obj.optString("msg", obj.optString("error_description", obj.optString("message", "Could not create account."))))
                }
                if (obj.has("access_token") && obj.optString("access_token").isNotEmpty()) {
                    SignUpOutcome.Authenticated(parseSession(obj))
                } else {
                    val identities = obj.optJSONArray("identities")
                    if (identities != null && identities.length() == 0) {
                        error("An account with this email already exists.")
                    }
                    SignUpOutcome.NeedsVerification(cleanEmail)
                }
            }
        }
    }

    suspend fun resendSignupOTP(email: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val payload = JSONObject().put("type", "signup").put("email", email.trim().lowercase()).toString()
            val req = Request.Builder()
                .url("${SingularityConfig.SUPABASE_URL}/auth/v1/resend")
                .header("apikey", SingularityConfig.SUPABASE_PUBLISHABLE_KEY)
                .header("Content-Type", "application/json")
                .post(payload.toRequestBody(jsonMediaType))
                .build()
            http.newCall(req).execute().use { res ->
                if (!res.isSuccessful) {
                    val obj = runCatching { JSONObject(res.body?.string().orEmpty()) }.getOrNull()
                    error(obj?.optString("msg", obj.optString("message", "Could not resend verification code.")) ?: "Could not resend verification code.")
                }
            }
        }
    }

    suspend fun verifyEmailOTP(email: String, token: String, type: String = "signup"): Result<SupabaseSession> = withContext(Dispatchers.IO) {
        runCatching {
            val digits = token.filter { it.isDigit() }
            if (digits.length != 6) error("Enter the 6-digit code.")
            val payload = JSONObject()
                .put("email", email.trim().lowercase())
                .put("token", digits)
                .put("type", type)
                .toString()
            val req = Request.Builder()
                .url("${SingularityConfig.SUPABASE_URL}/auth/v1/verify")
                .header("apikey", SingularityConfig.SUPABASE_PUBLISHABLE_KEY)
                .header("Content-Type", "application/json")
                .post(payload.toRequestBody(jsonMediaType))
                .build()
            http.newCall(req).execute().use { res ->
                val raw = res.body?.string().orEmpty()
                val obj = if (raw.isNotBlank()) JSONObject(raw) else JSONObject()
                if (!res.isSuccessful || !obj.has("access_token")) {
                    error(obj.optString("msg", obj.optString("error_description", "Invalid or expired verification code.")))
                }
                parseSession(obj)
            }
        }
    }

    suspend fun requestPasswordReset(email: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            val payload = JSONObject().put("email", email.trim().lowercase()).toString()
            val req = Request.Builder()
                .url("${SingularityConfig.SUPABASE_URL}/auth/v1/recover")
                .header("apikey", SingularityConfig.SUPABASE_PUBLISHABLE_KEY)
                .header("Content-Type", "application/json")
                .post(payload.toRequestBody(jsonMediaType))
                .build()
            http.newCall(req).execute().use { res ->
                if (!res.isSuccessful) {
                    val obj = runCatching { JSONObject(res.body?.string().orEmpty()) }.getOrNull()
                    error(obj?.optString("msg", obj.optString("message", "Could not send password reset code.")) ?: "Could not send password reset code.")
                }
            }
        }
    }

    suspend fun completePasswordReset(email: String, token: String, newPassword: String): Result<SupabaseSession> = withContext(Dispatchers.IO) {
        runCatching {
            if (newPassword.length < 6) error("Password must be at least 6 characters.")
            val verified = verifyEmailOTP(email, token, "recovery").getOrThrow()
            val payload = JSONObject().put("password", newPassword).toString()
            val req = Request.Builder()
                .url("${SingularityConfig.SUPABASE_URL}/auth/v1/user")
                .header("apikey", SingularityConfig.SUPABASE_PUBLISHABLE_KEY)
                .header("Authorization", "Bearer ${verified.accessToken}")
                .header("Content-Type", "application/json")
                .put(payload.toRequestBody(jsonMediaType))
                .build()
            http.newCall(req).execute().use { res ->
                if (!res.isSuccessful) {
                    val obj = runCatching { JSONObject(res.body?.string().orEmpty()) }.getOrNull()
                    error(obj?.optString("msg", obj.optString("message", "Could not update password.")) ?: "Could not update password.")
                }
            }
            verified
        }
    }

    suspend fun refreshSession(refreshToken: String): Result<SupabaseSession> = withContext(Dispatchers.IO) {
        runCatching {
            val payload = JSONObject().put("refresh_token", refreshToken).toString()
            val req = Request.Builder()
                .url("${SingularityConfig.SUPABASE_URL}/auth/v1/token?grant_type=refresh_token")
                .header("apikey", SingularityConfig.SUPABASE_PUBLISHABLE_KEY)
                .header("Content-Type", "application/json")
                .post(payload.toRequestBody(jsonMediaType))
                .build()
            http.newCall(req).execute().use { res ->
                val raw = res.body?.string().orEmpty()
                val obj = JSONObject(raw)
                if (!res.isSuccessful) error("Session expired")
                parseSession(obj)
            }
        }
    }

    suspend fun checkTelegramGate(accessToken: String): TelegramGateResult = withContext(Dispatchers.IO) {
        runCatching {
            val body = JSONObject().put("action", "check").toString()
            val req = Request.Builder()
                .url("${SingularityConfig.SUPABASE_URL}/functions/v1/telegram-gate")
                .header("apikey", SingularityConfig.SUPABASE_PUBLISHABLE_KEY)
                .header("Authorization", "Bearer $accessToken")
                .header("Content-Type", "application/json")
                .post(body.toRequestBody(jsonMediaType))
                .build()
            http.newCall(req).execute().use { res ->
                val obj = JSONObject(res.body?.string().orEmpty())
                TelegramGateResult(
                    isMember = obj.optBoolean("member", false),
                    linked = obj.optBoolean("linked", false),
                    channelUrl = obj.optString("channelUrl", SingularityConfig.TELEGRAM_CHANNEL_URL)
                )
            }
        }.getOrElse {
            TelegramGateResult(false, false, SingularityConfig.TELEGRAM_CHANNEL_URL, it.message)
        }
    }

    suspend fun pullProfileData(accessToken: String, profileId: String?): JSONObject? = withContext(Dispatchers.IO) {
        val pid = profileId?.let { URLEncoder.encode(it, "UTF-8") } ?: ""
        val suffix = if (pid.isNotEmpty()) "&profileId=$pid" else ""
        val req = Request.Builder()
            .url("${SingularityConfig.SUPABASE_URL}/functions/v1/telegram-gate?action=sync_profile_pull$suffix")
            .header("apikey", SingularityConfig.SUPABASE_PUBLISHABLE_KEY)
            .header("Authorization", "Bearer $accessToken")
            .get()
            .build()
        runCatching {
            http.newCall(req).execute().use { res ->
                if (!res.isSuccessful) null else JSONObject(res.body?.string().orEmpty())
            }
        }.getOrNull()
    }

    suspend fun pushSyncPayload(accessToken: String, payload: JSONObject): Boolean = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url("${SingularityConfig.SUPABASE_URL}/functions/v1/telegram-gate?action=sync_push")
            .header("apikey", SingularityConfig.SUPABASE_PUBLISHABLE_KEY)
            .header("Authorization", "Bearer $accessToken")
            .header("Content-Type", "application/json")
            .post(payload.toString().toRequestBody(jsonMediaType))
            .build()
        runCatching {
            http.newCall(req).execute().use { it.isSuccessful }
        }.getOrDefault(false)
    }

    suspend fun manageProfile(accessToken: String, op: String, id: String? = null, name: String? = null, avatarColor: String? = null, isKids: Boolean = false): JSONObject? = withContext(Dispatchers.IO) {
        val body = JSONObject().put("action", "sync_profiles").put("op", op)
        if (id != null) body.put("id", id)
        if (name != null) body.put("name", name)
        if (avatarColor != null) body.put("avatarColor", avatarColor)
        body.put("isKids", isKids)
        val req = Request.Builder()
            .url("${SingularityConfig.SUPABASE_URL}/functions/v1/telegram-gate?action=sync_profiles")
            .header("apikey", SingularityConfig.SUPABASE_PUBLISHABLE_KEY)
            .header("Authorization", "Bearer $accessToken")
            .header("Content-Type", "application/json")
            .post(body.toString().toRequestBody(jsonMediaType))
            .build()
        runCatching {
            http.newCall(req).execute().use { res ->
                if (res.isSuccessful) JSONObject(res.body?.string().orEmpty()) else null
            }
        }.getOrNull()
    }

    private fun parseSession(obj: JSONObject): SupabaseSession {
        val user = obj.optJSONObject("user") ?: JSONObject()
        val meta = user.optJSONObject("user_metadata") ?: JSONObject()
        val email = user.optString("email", "")
        val name = meta.optString("name", email.substringBefore("@").ifEmpty { "User" })
        val expiresIn = obj.optLong("expires_in", 3600L)
        return SupabaseSession(
            accessToken = obj.getString("access_token"),
            refreshToken = obj.optString("refresh_token", ""),
            userId = user.getString("id"),
            email = email,
            name = name,
            expiresAtEpochSec = (System.currentTimeMillis() / 1000L) + expiresIn
        )
    }
}
