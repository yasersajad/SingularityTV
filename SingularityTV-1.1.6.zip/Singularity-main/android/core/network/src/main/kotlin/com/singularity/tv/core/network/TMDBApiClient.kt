package com.singularity.tv.core.network

import com.singularity.tv.core.model.EpisodeSummary
import com.singularity.tv.core.model.MediaItem
import com.singularity.tv.core.model.TitleDetailPayload
import com.singularity.tv.core.model.WatchType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

@Serializable
private data class TMDBPagedResponse(
    val results: List<MediaItem> = emptyList()
)

@Serializable
private data class TMDBSeasonResponse(
    val episodes: List<EpisodeSummary> = emptyList()
)

object TMDBApiClient {
    private val json = Json { ignoreUnknownKeys = true; coerceInputValues = true }
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private suspend fun get(path: String): String? = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url("https://api.themoviedb.org/3/$path")
            .header("Authorization", "Bearer ${SingularityConfig.TMDB_READ_TOKEN}")
            .header("Accept", "application/json")
            .build()
        runCatching {
            http.newCall(req).execute().use { res ->
                if (res.isSuccessful) res.body?.string() else null
            }
        }.getOrNull()
    }

    suspend fun trendingAll(): List<MediaItem> {
        val body = get("trending/all/week?language=en-US") ?: return emptyList()
        return runCatching { json.decodeFromString<TMDBPagedResponse>(body).results }.getOrDefault(emptyList())
            .filter { it.mediaType == "movie" || it.mediaType == "tv" }
    }

    suspend fun popularMovies(): List<MediaItem> {
        val body = get("movie/popular?language=en-US") ?: return emptyList()
        return runCatching { json.decodeFromString<TMDBPagedResponse>(body).results }.getOrDefault(emptyList())
            .map { it.copy(mediaType = "movie") }
    }

    suspend fun popularSeries(): List<MediaItem> {
        val body = get("tv/popular?language=en-US") ?: return emptyList()
        return runCatching { json.decodeFromString<TMDBPagedResponse>(body).results }.getOrDefault(emptyList())
            .map { it.copy(mediaType = "tv") }
    }

    suspend fun topRatedMovies(): List<MediaItem> {
        val body = get("movie/top_rated?language=en-US") ?: return emptyList()
        return runCatching { json.decodeFromString<TMDBPagedResponse>(body).results }.getOrDefault(emptyList())
            .map { it.copy(mediaType = "movie") }
    }

    suspend fun upcomingMovies(): List<MediaItem> {
        val body = get("movie/upcoming?language=en-US") ?: return emptyList()
        return runCatching { json.decodeFromString<TMDBPagedResponse>(body).results }.getOrDefault(emptyList())
            .map { it.copy(mediaType = "movie") }
    }

    suspend fun searchMulti(query: String): List<MediaItem> {
        val q = withContext(Dispatchers.IO) { URLEncoder.encode(query.trim(), "UTF-8") }
        if (q.isBlank()) return emptyList()
        val body = get("search/multi?query=$q&include_adult=false&language=en-US") ?: return emptyList()
        return runCatching { json.decodeFromString<TMDBPagedResponse>(body).results }.getOrDefault(emptyList())
            .filter { it.mediaType == "movie" || it.mediaType == "tv" }
    }

    suspend fun titleDetail(type: WatchType, id: Int): TitleDetailPayload? {
        val kind = type.rawValue
        val body = get("$kind/$id?language=en-US") ?: return null
        return runCatching { json.decodeFromString<TitleDetailPayload>(body) }.getOrNull()
    }

    suspend fun seasonEpisodes(tvId: Int, seasonNumber: Int): List<EpisodeSummary> {
        val body = get("tv/$tvId/season/$seasonNumber?language=en-US") ?: return emptyList()
        return runCatching { json.decodeFromString<TMDBSeasonResponse>(body).episodes }.getOrDefault(emptyList())
    }
}
