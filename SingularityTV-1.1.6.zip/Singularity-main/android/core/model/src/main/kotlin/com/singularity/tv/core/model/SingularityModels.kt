package com.singularity.tv.core.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
enum class WatchType(val rawValue: String) {
    @SerialName("movie") MOVIE("movie"),
    @SerialName("tv") TV("tv")
}

@Serializable
data class MediaItem(
    val id: Int,
    @SerialName("media_type") val mediaType: String = "movie",
    val title: String? = null,
    val name: String? = null,
    val overview: String = "",
    @SerialName("release_date") val releaseDate: String? = null,
    @SerialName("first_air_date") val firstAirDate: String? = null,
    @SerialName("poster_path") val posterPath: String? = null,
    @SerialName("backdrop_path") val backdropPath: String? = null,
    @SerialName("vote_average") val voteAverage: Double? = null,
    @SerialName("vote_count") val voteCount: Int? = null,
    @SerialName("genre_ids") val genreIds: List<Int>? = null,
    @SerialName("original_language") val originalLanguage: String? = null,
    @SerialName("origin_country") val originCountry: List<String>? = null
) {
    val isMovie: Boolean get() = mediaType == "movie"
    val watchType: WatchType get() = if (isMovie) WatchType.MOVIE else WatchType.TV
    val displayTitle: String get() = if (isMovie) (title ?: name ?: "Untitled Movie") else (name ?: title ?: "Untitled Series")
    val displayYear: String? get() = (if (isMovie) releaseDate else firstAirDate)?.take(4)
    val posterUrl: String? get() = posterPath?.let { "https://image.tmdb.org/t/p/w500$it" }
    val backdropUrl: String? get() = backdropPath?.let { "https://image.tmdb.org/t/p/w1280$it" }

    val isArabicOrGulfContent: Boolean
        get() {
            if (originalLanguage.equals("ar", ignoreCase = true)) return true
            val arabCountries = setOf("SA", "AE", "KW", "QA", "BH", "OM", "EG", "LB", "SY", "JO", "IQ", "MA", "TN", "DZ", "YE", "SD", "LY", "PS")
            if (originCountry?.any { it.uppercase() in arabCountries } == true) return true
            val text = "${title.orEmpty()} ${name.orEmpty()}"
            return Regex("\\p{InArabic}").containsMatchIn(text)
        }
}

@Serializable
data class WatchItem(
    val id: String,
    val type: WatchType,
    val title: String,
    val tmdbId: String,
    val season: Int? = null,
    val episode: Int? = null,
    val episodeName: String? = null,
    val posterPath: String? = null,
    val generatedURL: String,
    val dateWatchedEpochMs: Long = System.currentTimeMillis()
) {
    val posterUrl: String? get() = posterPath?.let { "https://image.tmdb.org/t/p/w500$it" }
}

@Serializable
data class ContinueWatchingItem(
    val id: String,
    val type: WatchType,
    val title: String,
    val tmdbId: String,
    val season: Int? = null,
    val episode: Int? = null,
    val episodeName: String? = null,
    val posterPath: String? = null,
    val playableURL: String? = null,
    val lastWatchedEpochMs: Long = System.currentTimeMillis(),
    val progressSeconds: Double? = null,
    val durationSeconds: Double? = null
) {
    val progressFraction: Double?
        get() = if (progressSeconds != null && durationSeconds != null && durationSeconds > 0.0) {
            (progressSeconds / durationSeconds).coerceIn(0.0, 1.0)
        } else null

    val posterUrl: String? get() = posterPath?.let { "https://image.tmdb.org/t/p/w500$it" }
}

@Serializable
data class MyListItem(
    val mediaType: WatchType,
    val tmdbId: Int,
    val title: String,
    val posterPath: String? = null,
    val backdropPath: String? = null,
    val overview: String? = null,
    val year: String? = null,
    val dateAddedEpochMs: Long = System.currentTimeMillis()
) {
    fun toMediaItem(): MediaItem = MediaItem(
        id = tmdbId,
        mediaType = mediaType.rawValue,
        title = if (mediaType == WatchType.MOVIE) title else null,
        name = if (mediaType == WatchType.TV) title else null,
        overview = overview ?: "",
        releaseDate = if (mediaType == WatchType.MOVIE) year else null,
        firstAirDate = if (mediaType == WatchType.TV) year else null,
        posterPath = posterPath,
        backdropPath = backdropPath
    )
}

@Serializable
data class UserProfile(
    val id: String,
    val name: String,
    val avatarColor: String = "#E50914",
    val isKids: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable
data class SupabaseSession(
    val accessToken: String,
    val refreshToken: String,
    val userId: String,
    val email: String,
    val name: String,
    val expiresAtEpochSec: Long
)

@Serializable
data class WebPlayerPrefs(
    val preferredQuality: String = "Auto",
    val subtitleLanguage: String = "Off",
    val playbackSpeed: String = "1"
)

@Serializable
data class SeasonSummary(
    val id: Int,
    @SerialName("season_number") val seasonNumber: Int,
    val name: String = "",
    @SerialName("episode_count") val episodeCount: Int = 0
)

@Serializable
data class EpisodeSummary(
    val id: Int,
    @SerialName("episode_number") val episodeNumber: Int,
    val name: String = "",
    val overview: String = "",
    @SerialName("still_path") val stillPath: String? = null,
    val runtime: Int? = null
) {
    val stillUrl: String? get() = stillPath?.let { "https://image.tmdb.org/t/p/w500$it" }
}

@Serializable
data class TitleDetailPayload(
    val id: Int,
    val title: String? = null,
    val name: String? = null,
    val overview: String = "",
    @SerialName("poster_path") val posterPath: String? = null,
    @SerialName("backdrop_path") val backdropPath: String? = null,
    @SerialName("release_date") val releaseDate: String? = null,
    @SerialName("first_air_date") val firstAirDate: String? = null,
    @SerialName("vote_average") val voteAverage: Double? = null,
    val runtime: Int? = null,
    @SerialName("number_of_seasons") val numberOfSeasons: Int? = null,
    val seasons: List<SeasonSummary> = emptyList(),
    @SerialName("original_language") val originalLanguage: String? = null,
    @SerialName("origin_country") val originCountry: List<String>? = null
)
