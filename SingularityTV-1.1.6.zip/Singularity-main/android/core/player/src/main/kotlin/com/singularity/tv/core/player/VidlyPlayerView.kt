package com.singularity.tv.core.player

import android.annotation.SuppressLint
import android.graphics.Color
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayDisabled
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import com.singularity.tv.core.model.WatchItem
import com.singularity.tv.core.model.WebPlayerPrefs
import java.io.ByteArrayInputStream

private val BLOCKED_AD_DOMAINS = setOf(
    "doubleclick.net", "googlesyndication.com", "googleadservices.com",
    "googletagmanager.com", "google-analytics.com", "popads.net", "popcash.net",
    "propellerads.com", "adsterra.com", "adskeeper.com", "mgid.com", "taboola.com",
    "outbrain.com", "exoclick.com", "juicyads.com", "trafficjunky.com", "histats.com",
    "mc.yandex.ru", "4rabet", "1xbet", "betway", "onclickalgo", "adsco.re",
    "a-ads.com", "realsrv.com", "tsyndicate.com", "acscdn.com", "dtscout.com",
    "richpush.co", "pushub.net", "onclickperformance.com", "adnxs.com"
)

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun SingularityPlayerHost(
    item: WatchItem,
    savedPrefs: WebPlayerPrefs,
    onProgress: (Double, Double) -> Unit,
    onPrefChanged: (String, String) -> Unit,
    onBack: () -> Unit
) {
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var reloadKey by remember { mutableIntStateOf(0) }

    Box(modifier = Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                WebView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    setBackgroundColor(Color.BLACK)
                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        mediaPlaybackRequiresUserGesture = false
                        mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                        userAgentString = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
                    }
                    addJavascriptInterface(
                        object {
                            @JavascriptInterface
                            fun onProgressUpdate(ct: Double, dur: Double) {
                                onProgress(ct, dur)
                            }

                            @JavascriptInterface
                            fun onPreference(key: String, value: String) {
                                onPrefChanged(key, value)
                            }

                            @JavascriptInterface
                            fun onFatalError(msg: String) {
                                errorMessage = msg
                                isLoading = false
                            }

                            @JavascriptInterface
                            fun onRequestBack() {
                                post { onBack() }
                            }
                        },
                        "SingularityBridge"
                    )
                    webViewClient = object : WebViewClient() {
                        override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                            val host = request?.url?.host?.lowercase().orEmpty()
                            if (BLOCKED_AD_DOMAINS.any { host.contains(it) }) {
                                return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                            }
                            return super.shouldInterceptRequest(view, request)
                        }

                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                            val host = request?.url?.host?.lowercase().orEmpty()
                            if (request?.isForMainFrame == true && !host.contains("vidly")) {
                                return true
                            }
                            return BLOCKED_AD_DOMAINS.any { host.contains(it) }
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            isLoading = false
                            view?.evaluateJavascript(buildInjectionJs(savedPrefs), null)
                        }

                        override fun onReceivedHttpError(view: WebView?, request: WebResourceRequest?, errorResponse: WebResourceResponse?) {
                            if (request?.isForMainFrame == true && (errorResponse?.statusCode ?: 0) >= 400) {
                                isLoading = false
                                errorMessage = "The streaming server returned an error (${errorResponse?.statusCode}). Please try again."
                            }
                        }

                        override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                            if (request?.isForMainFrame == true) {
                                isLoading = false
                                errorMessage = "Unable to reach the streaming server. Check your connection or try again."
                            }
                        }
                    }
                    loadUrl(item.generatedURL)
                }
            },
            update = { webView ->
                if (webView.tag != reloadKey) {
                    webView.tag = reloadKey
                    if (reloadKey > 0) {
                        errorMessage = null
                        isLoading = true
                        webView.loadUrl(item.generatedURL)
                    }
                }
            }
        )

        if (isLoading && errorMessage == null) {
            CircularProgressIndicator(
                color = androidx.compose.ui.graphics.Color.White,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        errorMessage?.let { msg ->
            NativeErrorOverlay(
                title = item.title,
                posterUrl = item.posterUrl,
                message = msg,
                onRetry = {
                    errorMessage = null
                    isLoading = true
                    reloadKey++
                },
                onBack = onBack
            )
        }
    }
}

@Composable
private fun NativeErrorOverlay(
    title: String,
    posterUrl: String?,
    message: String,
    onRetry: () -> Unit,
    onBack: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color.Black)) {
        if (!posterUrl.isNullOrEmpty()) {
            AsyncImage(
                model = posterUrl,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize().blur(36.dp),
                alpha = 0.28f
            )
        }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.75f),
                            androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.94f)
                        )
                    )
                )
        )
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .padding(18.dp)
                .size(40.dp)
                .background(androidx.compose.ui.graphics.Color.White.copy(alpha = 0.12f), CircleShape)
                .align(Alignment.TopStart)
        ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = androidx.compose.ui.graphics.Color.White)
        }

        Column(
            modifier = Modifier.align(Alignment.Center).padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .background(androidx.compose.ui.graphics.Color.White.copy(alpha = 0.08f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.PlayDisabled, contentDescription = null, tint = androidx.compose.ui.graphics.Color.White, modifier = Modifier.size(30.dp))
            }
            Text(title, color = androidx.compose.ui.graphics.Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text(message, color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.7f), fontSize = 14.sp, textAlign = TextAlign.Center)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    onClick = onRetry,
                    colors = ButtonDefaults.buttonColors(containerColor = androidx.compose.ui.graphics.Color.White, contentColor = androidx.compose.ui.graphics.Color.Black),
                    shape = RoundedCornerShape(50)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Text(" Try Again", fontWeight = FontWeight.SemiBold)
                }
                OutlinedButton(
                    onClick = onBack,
                    shape = RoundedCornerShape(50)
                ) {
                    Text("Go Back", color = androidx.compose.ui.graphics.Color.White)
                }
            }
        }
    }
}

private fun buildInjectionJs(prefs: WebPlayerPrefs): String {
    return """
    (function () {
        try { window.open = function () { return null; }; } catch (e) {}
        var prefs = {
            preferredQuality: '${prefs.preferredQuality.replace("'", "\\'")}',
            subtitleLanguage: '${prefs.subtitleLanguage.replace("'", "\\'")}',
            playbackSpeed: '${prefs.playbackSpeed.replace("'", "\\'")}'
        };
        document.addEventListener('click', function (ev) {
            var btn = ev.target && ev.target.closest ? ev.target.closest('button, [role="button"], [role="menuitem"]') : null;
            if (!btn || !btn.closest('[role="dialog"], [role="menu"]')) return;
            var txt = (btn.innerText || '').trim();
            var low = txt.toLowerCase();
            if (low.indexOf('auto') === 0 || /\b(2160|1080|720|480|360)p\b/.test(low) || low.indexOf('cinematic') !== -1 || low.indexOf('theatrical') !== -1 || low.indexOf('smooth') !== -1) {
                prefs.preferredQuality = txt;
                SingularityBridge.onPreference('preferredQuality', txt);
            } else if (/^(0\.5|0\.75|1|1\.25|1\.5|2)x$/i.test(low)) {
                prefs.playbackSpeed = low.replace('x', '');
                SingularityBridge.onPreference('playbackSpeed', prefs.playbackSpeed);
            } else if (low === 'off' || low === 'arabic' || low === 'english') {
                prefs.subtitleLanguage = txt;
                SingularityBridge.onPreference('subtitleLanguage', txt);
            }
        }, true);
        setInterval(function () {
            var v = document.querySelector('video');
            if (v && isFinite(v.currentTime) && isFinite(v.duration) && v.duration > 0) {
                SingularityBridge.onProgressUpdate(v.currentTime, v.duration);
            }
            var txt = (document.body && document.body.innerText || '').toLowerCase();
            if ((!v || v.readyState < 2) && (txt.indexOf('gateway time-out') !== -1 || txt.indexOf('error code 504') !== -1 || txt.indexOf('stream unavailable') !== -1)) {
                SingularityBridge.onFatalError('The streaming server is temporarily unavailable.');
            }
        }, 2000);
    })();
    """.trimIndent()
}
