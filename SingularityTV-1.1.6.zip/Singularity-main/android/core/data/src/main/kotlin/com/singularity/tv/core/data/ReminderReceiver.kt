package com.singularity.tv.core.data

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.singularity.tv.core.model.MyListItem
import com.singularity.tv.core.model.WatchType
import java.util.Calendar

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val title = intent.getStringExtra("title") ?: "SingularityTV"
        val isMovie = intent.getBooleanExtra("isMovie", true)
        val notifId = intent.getIntExtra("notifId", 1001)
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Release Reminders",
                NotificationManager.IMPORTANCE_DEFAULT
            )
            manager.createNotificationChannel(channel)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            if (!granted) return
        }

        val body = if (isMovie) {
            "The film you asked to be reminded about has been released."
        } else {
            "The series you asked to be reminded about has premiered."
        }

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("$title is out today")
            .setContentText(body)
            .setAutoCancel(true)
            .build()

        manager.notify(notifId, notification)
    }

    companion object {
        const val CHANNEL_ID = "singularity_reminders"
    }
}

object ReminderScheduler {
    fun hasNotificationPermission(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true
        return ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    }

    fun schedule(context: Context, item: MyListItem, releaseEpochMs: Long) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val notifId = "${item.mediaType.rawValue}-${item.tmdbId}".hashCode()
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra("title", item.title)
            putExtra("isMovie", item.mediaType == WatchType.MOVIE)
            putExtra("notifId", notifId)
        }
        val pi = PendingIntent.getBroadcast(
            context,
            notifId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val cal = Calendar.getInstance().apply {
            timeInMillis = releaseEpochMs
            set(Calendar.HOUR_OF_DAY, 10)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
        }
        val triggerAt = maxOf(cal.timeInMillis, System.currentTimeMillis() + 60_000L)
        alarm.set(AlarmManager.RTC_WAKEUP, triggerAt, pi)
    }

    fun cancel(context: Context, item: MyListItem) {
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val notifId = "${item.mediaType.rawValue}-${item.tmdbId}".hashCode()
        val intent = Intent(context, ReminderReceiver::class.java)
        val pi = PendingIntent.getBroadcast(
            context,
            notifId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarm.cancel(pi)
    }
}
