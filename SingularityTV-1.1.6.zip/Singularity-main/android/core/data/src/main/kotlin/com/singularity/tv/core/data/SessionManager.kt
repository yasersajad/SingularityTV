package com.singularity.tv.core.data

import android.content.Context
import com.singularity.tv.core.model.AppSettingsState
import com.singularity.tv.core.model.ContinueWatchingItem
import com.singularity.tv.core.model.MyListItem
import com.singularity.tv.core.model.ReminderItem
import com.singularity.tv.core.model.ReminderResult
import com.singularity.tv.core.model.SingularityDateHelper
import com.singularity.tv.core.model.SupabaseSession
import com.singularity.tv.core.model.UserProfile
import com.singularity.tv.core.model.WatchItem
import com.singularity.tv.core.model.WatchType
import com.singularity.tv.core.model.WebPlayerPrefs
import com.singularity.tv.core.network.StreamingProviderBuilder
import com.singularity.tv.core.network.SupabaseClient
import com.singularity.tv.core.network.TMDBApiClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import org.json.JSONArray
import org.json.JSONObject

enum class GateStage {
    CHECKING_AUTH,
    AUTH_REQUIRED,
    TELEGRAM_REQUIRED,
    PROFILE_SELECT,
    READY
}

class SessionManager private constructor(context: Context) {
    private val appContext = context.applicationContext
    private val prefs = appContext.getSharedPreferences("singularity_vault", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    private val _stage = MutableStateFlow(GateStage.CHECKING_AUTH)
    val stage: StateFlow<GateStage> = _stage.asStateFlow()

    private val _session = MutableStateFlow<SupabaseSession?>(null)
    val session: StateFlow<SupabaseSession?> = _session.asStateFlow()

    private val _profiles = MutableStateFlow<List<UserProfile>>(emptyList())
    val profiles: StateFlow<List<UserProfile>> = _profiles.asStateFlow()

    private val _activeProfile = MutableStateFlow<UserProfile?>(null)
    val activeProfile: StateFlow<UserProfile?> = _activeProfile.asStateFlow()

    private val _myList = MutableStateFlow<List<MyListItem>>(emptyList())
    val myList: StateFlow<List<MyListItem>> = _myList.asStateFlow()

    private val _liked = MutableStateFlow<List<MyListItem>>(emptyList())
    val liked: StateFlow<List<MyListItem>> = _liked.asStateFlow()

    private val _reminders = MutableStateFlow<List<ReminderItem>>(emptyList())
    val reminders: StateFlow<List<ReminderItem>> = _reminders.asStateFlow()

    private val _history = MutableStateFlow<List<WatchItem>>(emptyList())
    val history: StateFlow<List<WatchItem>> = _history.asStateFlow()

    private val _continueWatching = MutableStateFlow<List<ContinueWatchingItem>>(emptyList())
    val continueWatching: StateFlow<List<ContinueWatchingItem>> = _continueWatching.asStateFlow()

    private val _webPlayerPrefs = MutableStateFlow(WebPlayerPrefs())
    val webPlayerPrefs: StateFlow<WebPlayerPrefs> = _webPlayerPrefs.asStateFlow()

    private val _appSettings = MutableStateFlow(AppSettingsState())
    val appSettings: StateFlow<AppSettingsState> = _appSettings.asStateFlow()

    private val _isHydratingProfile = MutableStateFlow(false)
    val isHydratingProfile: StateFlow<Boolean> = _isHydratingProfile.asStateFlow()

    private val dismissedCW = mutableSetOf<String>()

    init {
        loadLocalAppSettings()
        restoreSession()
    }

    private fun loadLocalAppSettings() {
        val raw = prefs.getString("app_settings_json", null)
        val decoded = raw?.let { runCatching { json.decodeFromString<AppSettingsState>(it) }.getOrNull() }
        if (decoded != null) {
            applyAppSettings(decoded, syncCloud = false)
        }
    }

    private fun applyAppSettings(state: AppSettingsState, syncCloud: Boolean) {
        _appSettings.value = state
        prefs.edit().putString("app_settings_json", json.encodeToString(state)).apply()
        StreamingProviderBuilder.customHostOverride = state.streamingProviderBaseURL
        StreamingProviderBuilder.accentHexOverride = state.accentColorHex
        TMDBApiClient.customTokenOverride = state.customTmdbToken
        if (syncCloud) pushActiveBucket()
    }

    fun updateAppSettings(transform: (AppSettingsState) -> AppSettingsState) {
        applyAppSettings(transform(_appSettings.value), syncCloud = true)
    }

    private fun restoreSession() {
        val raw = prefs.getString("session_json", null)
        val decoded = raw?.let { runCatching { json.decodeFromString<SupabaseSession>(it) }.getOrNull() }
        if (decoded == null) {
            _stage.value = GateStage.AUTH_REQUIRED
            return
        }
        _session.value = decoded
        scope.launch {
            val active = ensureValidSession() ?: run {
                _stage.value = GateStage.AUTH_REQUIRED
                return@launch
            }
            val gate = SupabaseClient.checkTelegramGate(active.accessToken)
            if (!gate.isMember) {
                _stage.value = GateStage.TELEGRAM_REQUIRED
                return@launch
            }
            SupabaseClient.pullProfileData(active.accessToken, null)?.let { parseProfilesFromPull(it) }
            _stage.value = GateStage.PROFILE_SELECT
        }
    }

    private suspend fun ensureValidSession(): SupabaseSession? {
        val cur = _session.value ?: return null
        val now = System.currentTimeMillis() / 1000L
        if (cur.expiresAtEpochSec > now + 60) return cur
        val refreshed = SupabaseClient.refreshSession(cur.refreshToken).getOrNull() ?: return null
        saveSession(refreshed)
        return refreshed
    }

    private fun saveSession(session: SupabaseSession) {
        _session.value = session
        prefs.edit().putString("session_json", json.encodeToString(session)).apply()
    }

    suspend fun signIn(email: String, password: String): Result<Unit> {
        val res = SupabaseClient.signIn(email, password)
        return res.map { sess ->
            saveSession(sess)
            val gate = SupabaseClient.checkTelegramGate(sess.accessToken)
            if (!gate.isMember) {
                _stage.value = GateStage.TELEGRAM_REQUIRED
            } else {
                SupabaseClient.pullProfileData(sess.accessToken, null)?.let { parseProfilesFromPull(it) }
                _stage.value = GateStage.PROFILE_SELECT
            }
        }
    }

    suspend fun signUp(email: String, password: String, name: String): Result<Unit> {
        val res = SupabaseClient.signUp(email, password, name)
        return res.map { sess ->
            saveSession(sess)
            _stage.value = GateStage.TELEGRAM_REQUIRED
        }
    }

    suspend fun recheckTelegramGate(): Boolean {
        val sess = ensureValidSession() ?: return false
        val gate = SupabaseClient.checkTelegramGate(sess.accessToken)
        if (gate.isMember) {
            SupabaseClient.pullProfileData(sess.accessToken, null)?.let { parseProfilesFromPull(it) }
            _stage.value = GateStage.PROFILE_SELECT
        }
        return gate.isMember
    }

    fun signOut() {
        prefs.edit().remove("session_json").apply()
        _session.value = null
        _profiles.value = emptyList()
        _activeProfile.value = null
        _myList.value = emptyList()
        _liked.value = emptyList()
        _reminders.value = emptyList()
        _history.value = emptyList()
        _continueWatching.value = emptyList()
        dismissedCW.clear()
        _stage.value = GateStage.AUTH_REQUIRED
    }

    fun selectProfile(profile: UserProfile) {
        _activeProfile.value = profile
        _isHydratingProfile.value = true
        scope.launch {
            val sess = ensureValidSession()
            if (sess != null) {
                val pulled = SupabaseClient.pullProfileData(sess.accessToken, profile.id)
                if (pulled != null) {
                    applyPulledBucket(pulled.optJSONObject("profileData") ?: JSONObject())
                }
            }
            _isHydratingProfile.value = false
            _stage.value = GateStage.READY
        }
    }

    fun createProfile(name: String, avatarColor: String, isKids: Boolean) {
        scope.launch {
            val sess = ensureValidSession() ?: return@launch
            val res = SupabaseClient.manageProfile(sess.accessToken, op = "create", name = name, avatarColor = avatarColor, isKids = isKids)
            if (res != null) parseProfilesFromPull(res)
        }
    }

    fun deleteProfile(profileId: String) {
        scope.launch {
            val sess = ensureValidSession() ?: return@launch
            val res = SupabaseClient.manageProfile(sess.accessToken, op = "delete", id = profileId)
            if (res != null) parseProfilesFromPull(res)
        }
    }

    fun switchToProfilePicker() {
        _stage.value = GateStage.PROFILE_SELECT
    }

    fun toggleMyList(item: MyListItem) {
        val current = _myList.value.toMutableList()
        val idx = current.indexOfFirst { it.mediaType == item.mediaType && it.tmdbId == item.tmdbId }
        if (idx >= 0) current.removeAt(idx) else current.add(item)
        _myList.value = current.sortedBy { it.dateAddedEpochMs }
        pushActiveBucket()
    }

    fun isInMyList(type: WatchType, tmdbId: Int): Boolean =
        _myList.value.any { it.mediaType == type && it.tmdbId == tmdbId }

    fun toggleLike(item: MyListItem) {
        val current = _liked.value.toMutableList()
        val idx = current.indexOfFirst { it.mediaType == item.mediaType && it.tmdbId == item.tmdbId }
        if (idx >= 0) current.removeAt(idx) else current.add(item)
        _liked.value = current
        pushActiveBucket()
    }

    fun isLiked(type: WatchType, tmdbId: Int): Boolean =
        _liked.value.any { it.mediaType == type && it.tmdbId == tmdbId }

    fun toggleReminder(
        item: MyListItem,
        releaseEpochMs: Long = System.currentTimeMillis(),
        scheduleNotification: Boolean = true
    ): ReminderResult {
        val current = _reminders.value
            .filter { it.releaseDateEpochMs >= SingularityDateHelper.startOfToday().time }
            .toMutableList()
        val idx = current.indexOfFirst { it.title.mediaType == item.mediaType && it.title.tmdbId == item.tmdbId }
        if (idx >= 0) {
            current.removeAt(idx)
            if (scheduleNotification) ReminderScheduler.cancel(context, item)
            _reminders.value = current
            pushActiveBucket()
            return ReminderResult.REMOVED
        }
        if (scheduleNotification && !ReminderScheduler.hasNotificationPermission(context)) {
            return ReminderResult.NOTIFICATIONS_DENIED
        }
        current.add(ReminderItem(item, releaseEpochMs))
        val sorted = current.sortedBy { it.releaseDateEpochMs }
        if (scheduleNotification) ReminderScheduler.schedule(context, item, releaseEpochMs)
        _reminders.value = sorted
        pushActiveBucket()
        return ReminderResult.ADDED
    }

    fun isReminded(type: WatchType, tmdbId: Int): Boolean =
        _reminders.value.any { it.title.mediaType == type && it.title.tmdbId == tmdbId }

    fun recordHistory(item: WatchItem) {
        val current = _history.value.toMutableList()
        current.removeAll { it.type == item.type && it.tmdbId == item.tmdbId && it.season == item.season && it.episode == item.episode }
        current.add(item)
        _history.value = current.sortedBy { it.dateWatchedEpochMs }.takeLast(12)
        pushActiveBucket()
    }

    fun recordProgress(
        type: WatchType,
        tmdbId: String,
        title: String,
        posterPath: String?,
        season: Int?,
        episode: Int?,
        episodeName: String?,
        positionSeconds: Double,
        durationSeconds: Double
    ) {
        dismissedCW.remove("${type.rawValue}_$tmdbId")
        val current = _continueWatching.value.toMutableList()
        current.removeAll { it.type == type && it.tmdbId == tmdbId }
        val item = ContinueWatchingItem(
            id = "${type.rawValue}_$tmdbId",
            type = type,
            title = title,
            tmdbId = tmdbId,
            season = season,
            episode = episode,
            episodeName = episodeName,
            posterPath = posterPath,
            playableURL = StreamingProviderBuilder.buildUrl(type, tmdbId.toIntOrNull() ?: 0, season, episode, positionSeconds.toInt()),
            lastWatchedEpochMs = System.currentTimeMillis(),
            progressSeconds = positionSeconds,
            durationSeconds = durationSeconds
        )
        current.add(0, item)
        _continueWatching.value = current.take(20)
        pushActiveBucket()
    }

    fun removeContinueWatching(type: WatchType, tmdbId: String) {
        dismissedCW.add("${type.rawValue}_$tmdbId")
        _continueWatching.value = _continueWatching.value.filterNot { it.type == type && it.tmdbId == tmdbId }
        pushActiveBucket()
    }

    fun clearHistory() {
        _history.value = emptyList()
        _continueWatching.value = emptyList()
        dismissedCW.clear()
        pushActiveBucket()
    }

    fun cacheSizeMb(): String {
        val dir = appContext.cacheDir
        val bytes = dir?.walkTopDown()?.filter { it.isFile }?.map { it.length() }?.sum() ?: 0L
        return String.format("%.1f MB", bytes / (1024.0 * 1024.0))
    }

    fun clearCache() {
        appContext.cacheDir?.deleteRecursively()
    }

    fun updateWebPlayerPrefs(update: (WebPlayerPrefs) -> WebPlayerPrefs) {
        _webPlayerPrefs.value = update(_webPlayerPrefs.value)
        pushActiveBucket()
    }

    private fun parseProfilesFromPull(pulled: JSONObject) {
        val arr = pulled.optJSONArray("profiles") ?: return
        val list = mutableListOf<UserProfile>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            list.add(
                UserProfile(
                    id = o.optString("id", "prof_main"),
                    name = o.optString("name", "Main"),
                    avatarColor = o.optString("avatarColor", "#E50914"),
                    isKids = o.optBoolean("isKids", false),
                    createdAt = o.optLong("createdAt", System.currentTimeMillis())
                )
            )
        }
        if (list.isNotEmpty()) _profiles.value = list
    }

    private fun applyPulledBucket(bucket: JSONObject) {
        val savedMap = bucket.optJSONObject("saved")
        val savedOrder = bucket.optJSONArray("savedOrder")
        val list = mutableListOf<MyListItem>()
        if (savedMap != null) {
            val keys = mutableListOf<String>()
            if (savedOrder != null) {
                for (i in 0 until savedOrder.length()) keys.add(savedOrder.optString(i))
            }
            savedMap.keys().forEach { k -> if (k !in keys) keys.add(k) }
            keys.forEachIndexed { idx, key ->
                val e = savedMap.optJSONObject(key) ?: return@forEachIndexed
                val id = e.optInt("id", e.optInt("tmdbId", 0))
                if (id <= 0) return@forEachIndexed
                val type = if (e.optString("media_type", "movie") == "tv") WatchType.TV else WatchType.MOVIE
                val added = e.optLong("dateAdded", idx.toLong() * 1000L)
                list.add(
                    MyListItem(
                        mediaType = type,
                        tmdbId = id,
                        title = e.optString("title", e.optString("name", "Untitled")),
                        posterPath = e.optString("poster_path", "").ifEmpty { null },
                        dateAddedEpochMs = added
                    )
                )
            }
        }
        _myList.value = list.sortedBy { it.dateAddedEpochMs }

        val histArr = bucket.optJSONArray("history") ?: JSONArray()
        val histList = mutableListOf<WatchItem>()
        for (i in 0 until histArr.length()) {
            val e = histArr.optJSONObject(i) ?: continue
            val id = e.optInt("id", e.optInt("tmdbId", 0))
            if (id <= 0) continue
            val type = if (e.optString("media_type", "movie") == "tv") WatchType.TV else WatchType.MOVIE
            val season = if (e.has("season")) e.optInt("season") else null
            val episode = if (e.has("episode")) e.optInt("episode") else null
            histList.add(
                WatchItem(
                    id = "${type.rawValue}_${id}_${season ?: 0}_${episode ?: 0}",
                    type = type,
                    title = e.optString("title", "Untitled"),
                    tmdbId = id.toString(),
                    season = season,
                    episode = episode,
                    episodeName = e.optString("episode_name", "").ifEmpty { null },
                    posterPath = e.optString("poster_path", "").ifEmpty { null },
                    generatedURL = StreamingProviderBuilder.buildUrl(type, id, season, episode),
                    dateWatchedEpochMs = e.optLong("watchedAt", i.toLong() * 1000L)
                )
            )
        }
        _history.value = histList.sortedBy { it.dateWatchedEpochMs }

        dismissedCW.clear()
        val disArr = bucket.optJSONArray("dismissedContinueWatching")
        if (disArr != null) {
            for (i in 0 until disArr.length()) dismissedCW.add(disArr.optString(i))
        }

        val cwArr = bucket.optJSONArray("continueWatching")
        val cwList = mutableListOf<ContinueWatchingItem>()
        if (cwArr != null) {
            for (i in 0 until cwArr.length()) {
                val e = cwArr.optJSONObject(i) ?: continue
                val type = if (e.optString("type", "movie") == "tv") WatchType.TV else WatchType.MOVIE
                val tmdbId = e.optString("tmdbId", "")
                if (tmdbId.isEmpty() || "${type.rawValue}_$tmdbId" in dismissedCW) continue
                cwList.add(
                    ContinueWatchingItem(
                        id = "${type.rawValue}_$tmdbId",
                        type = type,
                        title = e.optString("title", "Untitled"),
                        tmdbId = tmdbId,
                        season = if (e.has("season")) e.optInt("season") else null,
                        episode = if (e.has("episode")) e.optInt("episode") else null,
                        episodeName = e.optString("episodeName", "").ifEmpty { null },
                        posterPath = e.optString("posterPath", "").ifEmpty { null },
                        playableURL = e.optString("playableURL", "").ifEmpty { null },
                        lastWatchedEpochMs = e.optLong("lastWatchedDate", System.currentTimeMillis()),
                        progressSeconds = if (e.has("progressSeconds")) e.optDouble("progressSeconds") else null,
                        durationSeconds = if (e.has("durationSeconds")) e.optDouble("durationSeconds") else null
                    )
                )
            }
        }
        _continueWatching.value = cwList.sortedByDescending { it.lastWatchedEpochMs }

        val wp = bucket.optJSONObject("webPlayerPrefs")
        if (wp != null) {
            _webPlayerPrefs.value = WebPlayerPrefs(
                preferredQuality = wp.optString("preferredQuality", "Auto"),
                subtitleLanguage = wp.optString("subtitleLanguage", "Off"),
                playbackSpeed = wp.optString("playbackSpeed", "1")
            )
        }

        val pp = bucket.optJSONObject("playerPrefs")
        if (pp != null) {
            val cur = _appSettings.value
            val updated = cur.copy(
                accentColorHex = pp.optString("accentColorHex", cur.accentColorHex).ifEmpty { cur.accentColorHex },
                streamingProviderBaseURL = pp.optString("streamingProviderBaseURL", cur.streamingProviderBaseURL).ifEmpty { cur.streamingProviderBaseURL },
                hapticsEnabled = if (pp.has("hapticsEnabled")) pp.optBoolean("hapticsEnabled") else cur.hapticsEnabled
            )
            applyAppSettings(updated, syncCloud = false)
        }
    }

    private fun pushActiveBucket() {
        val pid = _activeProfile.value?.id ?: return
        scope.launch {
            val sess = ensureValidSession() ?: return@launch
            val savedDict = JSONObject()
            val savedOrder = JSONArray()
            _myList.value.sortedBy { it.dateAddedEpochMs }.forEach { item ->
                val key = "${item.mediaType.rawValue}_${item.tmdbId}"
                savedOrder.put(key)
                savedDict.put(
                    key,
                    JSONObject()
                        .put("id", item.tmdbId)
                        .put("media_type", item.mediaType.rawValue)
                        .put("title", item.title)
                        .put("dateAdded", item.dateAddedEpochMs)
                        .apply { if (!item.posterPath.isNullOrEmpty()) put("poster_path", item.posterPath) }
                )
            }

            val historyArr = JSONArray()
            _history.value.sortedBy { it.dateWatchedEpochMs }.forEach { item ->
                historyArr.put(
                    JSONObject()
                        .put("id", item.tmdbId.toIntOrNull() ?: 0)
                        .put("media_type", item.type.rawValue)
                        .put("title", item.title)
                        .put("watchedAt", item.dateWatchedEpochMs)
                        .apply {
                            if (!item.posterPath.isNullOrEmpty()) put("poster_path", item.posterPath)
                            if (item.season != null) put("season", item.season)
                            if (item.episode != null) put("episode", item.episode)
                            if (!item.episodeName.isNullOrEmpty()) put("episode_name", item.episodeName)
                        }
                )
            }

            val cwArr = JSONArray()
            _continueWatching.value.forEach { cw ->
                cwArr.put(
                    JSONObject()
                        .put("type", cw.type.rawValue)
                        .put("title", cw.title)
                        .put("tmdbId", cw.tmdbId)
                        .put("lastWatchedDate", cw.lastWatchedEpochMs)
                        .apply {
                            if (cw.season != null) put("season", cw.season)
                            if (cw.episode != null) put("episode", cw.episode)
                            if (!cw.episodeName.isNullOrEmpty()) put("episodeName", cw.episodeName)
                            if (!cw.posterPath.isNullOrEmpty()) put("posterPath", cw.posterPath)
                            if (cw.progressSeconds != null) put("progressSeconds", cw.progressSeconds)
                            if (cw.durationSeconds != null) put("durationSeconds", cw.durationSeconds)
                        }
                )
            }

            val wp = _webPlayerPrefs.value
            val wpObj = JSONObject()
                .put("preferredQuality", wp.preferredQuality)
                .put("subtitleLanguage", wp.subtitleLanguage)
                .put("playbackSpeed", wp.playbackSpeed)

            val st = _appSettings.value
            val ppObj = JSONObject()
                .put("accentColorHex", st.accentColorHex)
                .put("streamingProviderBaseURL", st.streamingProviderBaseURL)
                .put("hapticsEnabled", st.hapticsEnabled)

            val bucket = JSONObject()
                .put("saved", savedDict)
                .put("savedOrder", savedOrder)
                .put("history", historyArr)
                .put("continueWatching", cwArr)
                .put("dismissedContinueWatching", JSONArray(dismissedCW.toList()))
                .put("webPlayerPrefs", wpObj)
                .put("playerPrefs", ppObj)
                .put("_playerPrefsTs", System.currentTimeMillis())

            val payload = JSONObject()
                .put("schemaVersion", 2)
                .put("profileData", JSONObject().put(pid, bucket))

            SupabaseClient.pushSyncPayload(sess.accessToken, payload)
        }
    }

    companion object {
        @Volatile private var instance: SessionManager? = null
        fun getInstance(context: Context): SessionManager =
            instance ?: synchronized(this) {
                instance ?: SessionManager(context).also { instance = it }
            }
    }
}
