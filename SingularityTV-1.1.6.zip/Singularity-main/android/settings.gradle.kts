pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}

dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

rootProject.name = "SingularityTV"
include(":core:model")
include(":core:network")
include(":core:data")
include(":core:player")
include(":app-mobile")
include(":app-tv")
