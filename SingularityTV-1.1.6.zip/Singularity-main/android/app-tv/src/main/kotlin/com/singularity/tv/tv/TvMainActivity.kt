package com.singularity.tv.tv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Border
import androidx.tv.material3.Button
import androidx.tv.material3.ButtonDefaults
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.Icon
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import androidx.tv.material3.darkColorScheme
import coil.compose.AsyncImage
import com.singularity.tv.core.data.GateStage
import com.singularity.tv.core.data.SessionManager
import com.singularity.tv.core.model.MediaItem
import com.singularity.tv.core.model.MyListItem
import com.singularity.tv.core.model.WatchItem
import com.singularity.tv.core.network.SingularityConfig
import com.singularity.tv.core.network.StreamingProviderBuilder
import com.singularity.tv.core.network.TMDBApiClient
import com.singularity.tv.core.player.SingularityPlayerHost
import kotlinx.coroutines.launch

private val AccentRed = Color(0xFFE50914)

@OptIn(ExperimentalTvMaterial3Api::class)
class TvMainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sessionManager = SessionManager.getInstance(applicationContext)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = AccentRed,
                    background = Color.Black,
                    surface = Color(0xFF141414),
                    onBackground = Color.White,
                    onSurface = Color.White
                )
            ) {
                SingularityTvRoot(sessionManager)
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun SingularityTvRoot(sessionManager: SessionManager) {
    val stage by sessionManager.stage.collectAsState()
    val isHydrating by sessionManager.isHydratingProfile.collectAsState()
    var activePlayerItem by remember { mutableStateOf<WatchItem?>(null) }
    var detailItem by remember { mutableStateOf<MediaItem?>(null) }

    if (activePlayerItem != null) {
        val item = activePlayerItem!!
        val prefs by sessionManager.webPlayerPrefs.collectAsState()
        BackHandler { activePlayerItem = null }
        SingularityPlayerHost(
            item = item,
            savedPrefs = prefs,
            onProgress = { ct, dur ->
                sessionManager.recordProgress(
                    type = item.type,
                    tmdbId = item.tmdbId,
                    title = item.title,
                    posterPath = item.posterPath,
                    season = item.season,
                    episode = item.episode,
                    episodeName = item.episodeName,
                    positionSeconds = ct,
                    durationSeconds = dur
                )
            },
            onPrefChanged = { key, value ->
                sessionManager.updateWebPlayerPrefs { cur ->
                    when (key) {
                        "preferredQuality" -> cur.copy(preferredQuality = value)
                        "subtitleLanguage" -> cur.copy(subtitleLanguage = value)
                        "playbackSpeed" -> cur.copy(playbackSpeed = value)
                        else -> cur
                    }
                }
            },
            onBack = { activePlayerItem = null }
        )
        return
    }

    if (detailItem != null) {
        BackHandler { detailItem = null }
        TvDetailScreen(
            item = detailItem!!,
            sessionManager = sessionManager,
            onPlay = {
                sessionManager.recordHistory(it)
                activePlayerItem = it
            },
            onBack = { detailItem = null }
        )
        return
    }

    when (stage) {
        GateStage.CHECKING_AUTH -> Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = AccentRed)
        }
        GateStage.AUTH_REQUIRED -> TvAuthScreen(sessionManager)
        GateStage.TELEGRAM_REQUIRED -> TvTelegramScreen(sessionManager)
        GateStage.PROFILE_SELECT -> TvProfilesScreen(sessionManager, isHydrating)
        GateStage.READY -> TvMainShell(
            sessionManager = sessionManager,
            onOpenDetail = { detailItem = it },
            onPlay = {
                sessionManager.recordHistory(it)
                activePlayerItem = it
            }
        )
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvAuthScreen(sessionManager: SessionManager) {
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        Column(modifier = Modifier.width(420.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("SingularityTV", color = AccentRed, fontSize = 36.sp, fontWeight = FontWeight.Black)
            OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
            error?.let { Text(it, color = AccentRed, fontSize = 14.sp) }
            Button(
                onClick = {
                    busy = true
                    error = null
                    scope.launch {
                        val res = sessionManager.signIn(email.trim(), password)
                        busy = false
                        res.onFailure { error = it.message }
                    }
                },
                colors = ButtonDefaults.colors(containerColor = AccentRed, contentColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (busy) "Signing In..." else "Sign In", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvTelegramScreen(sessionManager: SessionManager) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        Column(modifier = Modifier.width(520.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("Telegram Verification", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Link your account via @${SingularityConfig.TELEGRAM_BOT_USERNAME} and join our channel.", color = Color.Gray, fontSize = 16.sp)
            Button(
                onClick = {
                    busy = true
                    scope.launch {
                        sessionManager.recheckTelegramGate()
                        busy = false
                    }
                },
                colors = ButtonDefaults.colors(containerColor = AccentRed, contentColor = Color.White)
            ) {
                Text(if (busy) "Checking..." else "Verify Membership")
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvProfilesScreen(sessionManager: SessionManager, isHydrating: Boolean) {
    val profiles by sessionManager.profiles.collectAsState()
    var selectedName by remember { mutableStateOf<String?>(null) }

    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(28.dp)) {
            Text("Who's Watching?", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                profiles.forEach { profile ->
                    Surface(
                        onClick = {
                            if (!isHydrating) {
                                selectedName = profile.name
                                sessionManager.selectProfile(profile)
                            }
                        },
                        border = ClickableSurfaceDefaults.border(focusedBorder = Border(BorderStroke(3.dp, Color.White))),
                        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.08f),
                        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(16.dp))
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(18.dp)) {
                            Box(Modifier.size(110.dp).background(AccentRed, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                                Text(profile.name.take(1).uppercase(), color = Color.White, fontSize = 42.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.height(10.dp))
                            Text(profile.name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
        if (isHydrating) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.85f)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    CircularProgressIndicator(color = Color.White)
                    Text("Loading ${selectedName ?: "profile"}...", color = Color.White, fontSize = 18.sp)
                }
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvMainShell(sessionManager: SessionManager, onOpenDetail: (MediaItem) -> Unit, onPlay: (WatchItem) -> Unit) {
    var selectedNav by remember { mutableStateOf(0) }
    Row(Modifier.fillMaxSize().background(Color.Black)) {
        Column(
            modifier = Modifier.width(200.dp).fillMaxHeight().background(Color(0xFF0A0A0A)).padding(vertical = 28.dp, horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("SingularityTV", color = AccentRed, fontSize = 22.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(bottom = 18.dp, start = 8.dp))
            TvNavRailButton("Home", Icons.Default.Home, selectedNav == 0) { selectedNav = 0 }
            TvNavRailButton("Search", Icons.Default.Search, selectedNav == 1) { selectedNav = 1 }
            TvNavRailButton("Profiles", Icons.Default.Person, selectedNav == 2) { sessionManager.switchToProfilePicker() }
            Spacer(Modifier.weight(1f))
            Text("v${SingularityConfig.APP_VERSION}", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp))
        }

        Box(Modifier.weight(1f).fillMaxHeight()) {
            when (selectedNav) {
                0 -> TvHomeContent(sessionManager, onOpenDetail, onPlay)
                1 -> TvSearchContent(onOpenDetail)
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvNavRailButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        colors = ClickableSurfaceDefaults.colors(
            containerColor = if (selected) Color.White.copy(alpha = 0.14f) else Color.Transparent,
            focusedContainerColor = Color.White.copy(alpha = 0.24f)
        ),
        border = ClickableSurfaceDefaults.border(focusedBorder = Border(BorderStroke(2.dp, Color.White))),
        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(10.dp)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(icon, null, tint = if (selected) Color.White else Color.Gray)
            Text(label, color = if (selected) Color.White else Color.Gray, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvHomeContent(sessionManager: SessionManager, onOpenDetail: (MediaItem) -> Unit, onPlay: (WatchItem) -> Unit) {
    var trending by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var movies by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var series by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    val myList by sessionManager.myList.collectAsState()

    LaunchedEffect(Unit) {
        trending = TMDBApiClient.trendingAll()
        movies = TMDBApiClient.popularMovies()
        series = TMDBApiClient.popularSeries()
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 36.dp)) {
        trending.firstOrNull()?.let { hero ->
            item {
                Box(Modifier.fillMaxWidth().height(360.dp)) {
                    AsyncImage(model = hero.backdropUrl ?: hero.posterUrl, contentDescription = hero.displayTitle, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color.Black.copy(alpha = 0.92f), Color.Transparent))))
                    Column(modifier = Modifier.align(Alignment.CenterStart).padding(36.dp).width(460.dp)) {
                        Text(hero.displayTitle, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(10.dp))
                        Text(hero.overview, color = Color.LightGray, fontSize = 14.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(18.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            Button(
                                onClick = {
                                    onPlay(
                                        WatchItem(
                                            id = "${hero.watchType.rawValue}_${hero.id}",
                                            type = hero.watchType,
                                            title = hero.displayTitle,
                                            tmdbId = hero.id.toString(),
                                            season = if (hero.isMovie) null else 1,
                                            episode = if (hero.isMovie) null else 1,
                                            posterPath = hero.posterPath,
                                            generatedURL = StreamingProviderBuilder.buildUrl(hero.watchType, hero.id, 1, 1)
                                        )
                                    )
                                },
                                colors = ButtonDefaults.colors(containerColor = Color.White, contentColor = Color.Black)
                            ) {
                                Icon(Icons.Default.PlayArrow, null)
                                Text(" Play", fontWeight = FontWeight.Bold)
                            }
                            Button(onClick = { onOpenDetail(hero) }) {
                                Text("Details")
                            }
                        }
                    }
                }
            }
        }
        if (trending.isNotEmpty()) item { TvMediaRow("Trending Now", trending, onOpenDetail) }
        if (movies.isNotEmpty()) item { TvMediaRow("Popular Movies", movies, onOpenDetail) }
        if (series.isNotEmpty()) item { TvMediaRow("Popular Series", series, onOpenDetail) }
        if (myList.isNotEmpty()) item { TvMediaRow("My List", myList.map { it.toMediaItem() }, onOpenDetail) }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvMediaRow(title: String, items: List<MediaItem>, onClick: (MediaItem) -> Unit) {
    Column(Modifier.padding(top = 22.dp)) {
        Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 28.dp, vertical = 8.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 28.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            items(items, key = { "${it.mediaType}_${it.id}" }) { item ->
                Surface(
                    onClick = { onClick(item) },
                    border = ClickableSurfaceDefaults.border(focusedBorder = Border(BorderStroke(3.dp, Color.White))),
                    scale = ClickableSurfaceDefaults.scale(focusedScale = 1.07f),
                    shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(10.dp)),
                    modifier = Modifier.width(150.dp).height(225.dp)
                ) {
                    Box(Modifier.fillMaxSize()) {
                        AsyncImage(model = item.posterUrl, contentDescription = item.displayTitle, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        if (item.isArabicOrGulfContent) {
                            Text(
                                "May Not Stream",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(6.dp).background(Color.Black.copy(alpha = 0.72f), RoundedCornerShape(50)).padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvSearchContent(onOpenDetail: (MediaItem) -> Unit) {
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    LaunchedEffect(query) {
        results = if (query.isBlank()) TMDBApiClient.trendingAll() else TMDBApiClient.searchMulti(query)
    }
    Column(Modifier.fillMaxSize().padding(28.dp)) {
        OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Search movies & series") }, singleLine = true, modifier = Modifier.width(420.dp))
        Spacer(Modifier.height(18.dp))
        TvMediaRow("Results", results, onOpenDetail)
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvDetailScreen(item: MediaItem, sessionManager: SessionManager, onPlay: (WatchItem) -> Unit, onBack: () -> Unit) {
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AsyncImage(model = item.backdropUrl ?: item.posterUrl, contentDescription = item.displayTitle, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize(), alpha = 0.35f)
        Column(modifier = Modifier.align(Alignment.CenterStart).padding(48.dp).width(580.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(item.displayTitle, color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Black)
            Text(item.overview, color = Color.LightGray, fontSize = 16.sp, maxLines = 5, overflow = TextOverflow.Ellipsis)
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Button(
                    onClick = {
                        onPlay(
                            WatchItem(
                                id = "${item.watchType.rawValue}_${item.id}",
                                type = item.watchType,
                                title = item.displayTitle,
                                tmdbId = item.id.toString(),
                                season = if (item.isMovie) null else 1,
                                episode = if (item.isMovie) null else 1,
                                posterPath = item.posterPath,
                                generatedURL = StreamingProviderBuilder.buildUrl(item.watchType, item.id, 1, 1)
                            )
                        )
                    },
                    colors = ButtonDefaults.colors(containerColor = Color.White, contentColor = Color.Black)
                ) {
                    Icon(Icons.Default.PlayArrow, null)
                    Text(" Play", fontWeight = FontWeight.Bold)
                }
                Button(onClick = { sessionManager.toggleMyList(MyListItem(item.watchType, item.id, item.displayTitle, item.posterPath, item.backdropPath, item.overview, item.displayYear)) }) {
                    Icon(if (sessionManager.isInMyList(item.watchType, item.id)) Icons.Default.Check else Icons.Default.Add, null)
                    Text(" My List")
                }
                Button(onClick = onBack) { Text("Back") }
            }
        }
    }
}
