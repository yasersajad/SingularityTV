package com.singularity.tv.tv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Border
import androidx.tv.material3.Button
import androidx.tv.material3.ButtonDefaults
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.Icon
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import androidx.tv.material3.darkColorScheme
import coil.compose.AsyncImage
import com.singularity.tv.core.data.GateStage
import com.singularity.tv.core.data.SessionManager
import com.singularity.tv.core.model.EpisodeSummary
import com.singularity.tv.core.model.MediaItem
import com.singularity.tv.core.model.MyListItem
import com.singularity.tv.core.model.SingularityAccentPalette
import com.singularity.tv.core.model.SingularityDateHelper
import com.singularity.tv.core.model.TitleDetailPayload
import com.singularity.tv.core.model.WatchItem
import com.singularity.tv.core.model.WatchType
import com.singularity.tv.core.network.SingularityConfig
import com.singularity.tv.core.network.StreamingProviderBuilder
import com.singularity.tv.core.network.TMDBApiClient
import com.singularity.tv.core.player.SingularityPlayerHost
import kotlinx.coroutines.launch

private fun tvAccent(hex: String): Color {
    val clean = hex.removePrefix("#").trim()
    val rgb = clean.toLongOrNull(16) ?: 0xE50914L
    return Color(0xFF000000L or rgb)
}

@OptIn(ExperimentalTvMaterial3Api::class)
class TvMainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sessionManager = SessionManager.getInstance(applicationContext)
        setContent {
            val appSettings by sessionManager.appSettings.collectAsState()
            val accent = tvAccent(appSettings.accentColorHex)
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = accent,
                    background = Color.Black,
                    surface = Color(0xFF141414),
                    onBackground = Color.White,
                    onSurface = Color.White
                )
            ) {
                SingularityTvRoot(sessionManager, accent)
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun SingularityTvRoot(sessionManager: SessionManager, accent: Color) {
    val stage by sessionManager.stage.collectAsState()
    val isHydrating by sessionManager.isHydratingProfile.collectAsState()
    val appSettings by sessionManager.appSettings.collectAsState()
    var activePlayerItem by remember { mutableStateOf<WatchItem?>(null) }
    var detailItem by remember { mutableStateOf<MediaItem?>(null) }

    if (activePlayerItem != null) {
        val item = activePlayerItem!!
        val prefs by sessionManager.webPlayerPrefs.collectAsState()
        BackHandler { activePlayerItem = null }
        SingularityPlayerHost(
            item = item,
            savedPrefs = prefs,
            accentHex = appSettings.accentColorHex,
            isTvMode = true,
            onProgress = { ct, dur ->
                sessionManager.recordProgress(
                    type = item.type,
                    tmdbId = item.tmdbId,
                    title = item.title,
                    posterPath = item.posterPath,
                    season = item.season,
                    episode = item.episode,
                    episodeName = item.episodeName,
                    positionSeconds = ct,
                    durationSeconds = dur
                )
            },
            onPrefChanged = { key, value ->
                sessionManager.updateWebPlayerPrefs { cur ->
                    when (key) {
                        "preferredQuality" -> cur.copy(preferredQuality = value)
                        "subtitleLanguage" -> cur.copy(subtitleLanguage = value)
                        "playbackSpeed" -> cur.copy(playbackSpeed = value)
                        else -> cur
                    }
                }
            },
            onBack = { activePlayerItem = null }
        )
        return
    }

    if (detailItem != null) {
        BackHandler { detailItem = null }
        TvDetailScreen(
            item = detailItem!!,
            sessionManager = sessionManager,
            accent = accent,
            onOpenRelated = { detailItem = it },
            onPlay = {
                sessionManager.recordHistory(it)
                activePlayerItem = it
            },
            onBack = { detailItem = null }
        )
        return
    }

    when (stage) {
        GateStage.CHECKING_AUTH -> Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = accent)
        }
        GateStage.AUTH_REQUIRED -> TvAuthScreen(sessionManager, accent)
        GateStage.TELEGRAM_REQUIRED -> TvTelegramScreen(sessionManager, accent)
        GateStage.PROFILE_SELECT -> TvProfilesScreen(sessionManager, isHydrating, accent)
        GateStage.READY -> TvMainShell(
            sessionManager = sessionManager,
            accent = accent,
            onOpenDetail = { detailItem = it },
            onPlay = {
                sessionManager.recordHistory(it)
                activePlayerItem = it
            }
        )
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvAuthScreen(sessionManager: SessionManager, accent: Color) {
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        Column(modifier = Modifier.width(420.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text("SingularityTV", color = accent, fontSize = 36.sp, fontWeight = FontWeight.Black)
            OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
            error?.let { Text(it, color = accent, fontSize = 14.sp) }
            Button(
                onClick = {
                    busy = true
                    error = null
                    scope.launch {
                        val res = sessionManager.signIn(email.trim(), password)
                        busy = false
                        res.onFailure { error = it.message }
                    }
                },
                colors = ButtonDefaults.colors(containerColor = accent, contentColor = Color.White),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (busy) "Signing In..." else "Sign In", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvTelegramScreen(sessionManager: SessionManager, accent: Color) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        Column(modifier = Modifier.width(520.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("Telegram Verification", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Link your account via @${SingularityConfig.TELEGRAM_BOT_USERNAME} and join our channel.", color = Color.Gray, fontSize = 16.sp)
            Button(
                onClick = {
                    busy = true
                    scope.launch {
                        sessionManager.recheckTelegramGate()
                        busy = false
                    }
                },
                colors = ButtonDefaults.colors(containerColor = accent, contentColor = Color.White)
            ) {
                Text(if (busy) "Checking..." else "Verify Membership")
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvProfilesScreen(sessionManager: SessionManager, isHydrating: Boolean, accent: Color) {
    val profiles by sessionManager.profiles.collectAsState()
    var selectedName by remember { mutableStateOf<String?>(null) }

    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(28.dp)) {
            Text("Who's Watching?", color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(28.dp)) {
                profiles.forEach { profile ->
                    Surface(
                        onClick = {
                            if (!isHydrating) {
                                selectedName = profile.name
                                sessionManager.selectProfile(profile)
                            }
                        },
                        border = ClickableSurfaceDefaults.border(focusedBorder = Border(BorderStroke(3.dp, Color.White))),
                        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.08f),
                        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(16.dp))
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(18.dp)) {
                            Box(Modifier.size(110.dp).background(tvAccent(profile.avatarColor), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                                Text(profile.name.take(1).uppercase(), color = Color.White, fontSize = 42.sp, fontWeight = FontWeight.Bold)
                            }
                            Spacer(Modifier.height(10.dp))
                            Text(profile.name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
        if (isHydrating) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.85f)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    CircularProgressIndicator(color = Color.White)
                    Text("Loading ${selectedName ?: "profile"}...", color = Color.White, fontSize = 18.sp)
                }
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvMainShell(sessionManager: SessionManager, accent: Color, onOpenDetail: (MediaItem) -> Unit, onPlay: (WatchItem) -> Unit) {
    var selectedNav by remember { mutableIntStateOf(0) }
    Row(Modifier.fillMaxSize().background(Color.Black)) {
        Column(
            modifier = Modifier.width(210.dp).fillMaxHeight().background(Color(0xFF0A0A0A)).padding(vertical = 28.dp, horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Text("SingularityTV", color = accent, fontSize = 22.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(bottom = 16.dp, start = 8.dp))
            TvNavRailButton("Home", Icons.Default.Home, selectedNav == 0) { selectedNav = 0 }
            TvNavRailButton("New & Hot", Icons.Default.Whatshot, selectedNav == 1) { selectedNav = 1 }
            TvNavRailButton("Search", Icons.Default.Search, selectedNav == 2) { selectedNav = 2 }
            TvNavRailButton("Settings", Icons.Default.Settings, selectedNav == 3) { selectedNav = 3 }
            TvNavRailButton("Profiles", Icons.Default.Person, false) { sessionManager.switchToProfilePicker() }
            Spacer(Modifier.weight(1f))
            Text("v${SingularityConfig.APP_VERSION}", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp))
        }

        Box(Modifier.weight(1f).fillMaxHeight()) {
            when (selectedNav) {
                0 -> TvHomeContent(sessionManager, accent, onOpenDetail, onPlay)
                1 -> TvNewHotContent(sessionManager, accent, onOpenDetail)
                2 -> TvSearchContent(onOpenDetail)
                3 -> TvSettingsContent(sessionManager, accent)
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvNavRailButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        colors = ClickableSurfaceDefaults.colors(
            containerColor = if (selected) Color.White.copy(alpha = 0.14f) else Color.Transparent,
            focusedContainerColor = Color.White.copy(alpha = 0.24f)
        ),
        border = ClickableSurfaceDefaults.border(focusedBorder = Border(BorderStroke(2.dp, Color.White))),
        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(10.dp)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(modifier = Modifier.padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(icon, null, tint = if (selected) Color.White else Color.Gray)
            Text(label, color = if (selected) Color.White else Color.Gray, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvHomeContent(sessionManager: SessionManager, accent: Color, onOpenDetail: (MediaItem) -> Unit, onPlay: (WatchItem) -> Unit) {
    var trending by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var movies by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var series by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    val cw by sessionManager.continueWatching.collectAsState()
    val myList by sessionManager.myList.collectAsState()

    LaunchedEffect(Unit) {
        trending = TMDBApiClient.trendingAll()
        movies = TMDBApiClient.popularMovies()
        series = TMDBApiClient.popularSeries()
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 36.dp)) {
        trending.firstOrNull()?.let { hero ->
            item {
                Box(Modifier.fillMaxWidth().height(360.dp)) {
                    AsyncImage(model = hero.backdropUrl ?: hero.posterUrl, contentDescription = hero.displayTitle, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color.Black.copy(alpha = 0.92f), Color.Transparent))))
                    Column(modifier = Modifier.align(Alignment.CenterStart).padding(36.dp).width(460.dp)) {
                        Text(hero.displayTitle, color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.Black, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(10.dp))
                        Text(hero.overview, color = Color.LightGray, fontSize = 14.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(18.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            Button(
                                onClick = {
                                    onPlay(WatchItem(id = "${hero.watchType.rawValue}_${hero.id}", type = hero.watchType, title = hero.displayTitle, tmdbId = hero.id.toString(), season = if (hero.isMovie) null else 1, episode = if (hero.isMovie) null else 1, posterPath = hero.posterPath, generatedURL = StreamingProviderBuilder.buildUrl(hero.watchType, hero.id, 1, 1)))
                                },
                                colors = ButtonDefaults.colors(containerColor = Color.White, contentColor = Color.Black)
                            ) {
                                Icon(Icons.Default.PlayArrow, null)
                                Text(" Play", fontWeight = FontWeight.Bold)
                            }
                            Button(onClick = { onOpenDetail(hero) }) { Text("Details") }
                        }
                    }
                }
            }
        }
        if (cw.isNotEmpty()) {
            item {
                TvMediaRow(
                    title = "Continue Watching",
                    items = cw.map { MediaItem(id = it.tmdbId.toIntOrNull() ?: 0, mediaType = it.type.rawValue, title = it.title, name = it.title, posterPath = it.posterPath) },
                    accent = accent,
                    onClick = onOpenDetail
                )
            }
        }
        if (trending.isNotEmpty()) item { TvMediaRow("Top 10 Today", trending.take(10), accent, onOpenDetail) }
        if (movies.isNotEmpty()) item { TvMediaRow("Popular Movies", movies, accent, onOpenDetail) }
        if (series.isNotEmpty()) item { TvMediaRow("Popular Series", series, accent, onOpenDetail) }
        if (myList.isNotEmpty()) item { TvMediaRow("My List", myList.map { it.toMediaItem() }, accent, onOpenDetail) }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvMediaRow(title: String, items: List<MediaItem>, accent: Color, onClick: (MediaItem) -> Unit) {
    Column(Modifier.padding(top = 22.dp)) {
        Text(title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 28.dp, vertical = 8.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 28.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            items(items, key = { "${title}_${it.mediaType}_${it.id}" }) { item ->
                Surface(
                    onClick = { onClick(item) },
                    border = ClickableSurfaceDefaults.border(focusedBorder = Border(BorderStroke(3.dp, Color.White))),
                    scale = ClickableSurfaceDefaults.scale(focusedScale = 1.07f),
                    shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(10.dp)),
                    modifier = Modifier.width(150.dp).height(225.dp)
                ) {
                    Box(Modifier.fillMaxSize()) {
                        AsyncImage(model = item.posterUrl, contentDescription = item.displayTitle, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        if (item.isArabicOrGulfContent) {
                            Text("May Not Stream", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(6.dp).background(Color.Black.copy(alpha = 0.72f), RoundedCornerShape(50)).padding(horizontal = 8.dp, vertical = 3.dp))
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvNewHotContent(sessionManager: SessionManager, accent: Color, onOpenDetail: (MediaItem) -> Unit) {
    var upcoming by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var everyonesWatching by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var topSeries by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var topFilms by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    val reminders by sessionManager.reminders.collectAsState()

    LaunchedEffect(Unit) {
        upcoming = TMDBApiClient.upcomingComingSoon()
        everyonesWatching = TMDBApiClient.trendingToday().take(10)
        topSeries = TMDBApiClient.trendingTodaySeries().take(10)
        topFilms = TMDBApiClient.trendingTodayMovies().take(10)
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 24.dp, horizontal = 24.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        item { Text("Coming Soon", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        if (upcoming.isNotEmpty()) {
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    items(upcoming, key = { "${it.mediaType}_${it.id}" }) { item ->
                        val relDate = item.releaseDateParsed
                        val saved = MyListItem(item.watchType, item.id, item.displayTitle, item.posterPath, item.backdropPath, item.overview, item.displayYear)
                        val reminded = reminders.any { it.title.mediaType == item.watchType && it.title.tmdbId == item.id }
                        Column(
                            modifier = Modifier
                                .width(340.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF141414))
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                onClick = { onOpenDetail(item) },
                                border = ClickableSurfaceDefaults.border(focusedBorder = Border(BorderStroke(2.dp, Color.White))),
                                shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(8.dp)),
                                modifier = Modifier.fillMaxWidth().height(175.dp)
                            ) {
                                AsyncImage(model = item.backdropUrl ?: item.posterUrl, contentDescription = item.displayTitle, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                            }
                            if (relDate != null) {
                                Text(SingularityDateHelper.comingLabel(relDate, item.isMovie), color = accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Text(item.displayTitle, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(item.overview, color = Color.LightGray, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(onClick = {
                                    sessionManager.toggleReminder(saved, relDate?.time ?: SingularityDateHelper.startOfTomorrow().time, scheduleNotification = false)
                                }) {
                                    Icon(if (reminded) Icons.Default.Notifications else Icons.Default.NotificationsNone, null)
                                    Text(if (reminded) " Reminder Set" else " Remind Me")
                                }
                                Button(onClick = { onOpenDetail(item) }) {
                                    Text("Info")
                                }
                            }
                        }
                    }
                }
            }
        }
        item { TvMediaRow("Everyone's Watching", everyonesWatching, accent, onOpenDetail) }
        item { TvMediaRow("Top 10 Series", topSeries, accent, onOpenDetail) }
        item { TvMediaRow("Top 10 Films", topFilms, accent, onOpenDetail) }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvSearchContent(onOpenDetail: (MediaItem) -> Unit) {
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    LaunchedEffect(query) {
        results = if (query.isBlank()) TMDBApiClient.trendingToday() else TMDBApiClient.searchMulti(query)
    }
    Column(Modifier.fillMaxSize().padding(28.dp)) {
        OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Search movies & series") }, singleLine = true, modifier = Modifier.width(420.dp))
        Spacer(Modifier.height(18.dp))
        TvMediaRow(if (query.isBlank()) "Top Searches" else "Results", results, Color.Red, onOpenDetail)
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvSettingsContent(sessionManager: SessionManager, accent: Color) {
    val settings by sessionManager.appSettings.collectAsState()
    val webPrefs by sessionManager.webPlayerPrefs.collectAsState()
    val profile by sessionManager.activeProfile.collectAsState()

    LazyColumn(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        item { Text("Settings", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold) }
        item {
            Text("Profile: ${profile?.name ?: "Main"} · v${SingularityConfig.APP_VERSION}", color = Color.LightGray, fontSize = 15.sp)
        }
        item {
            Text("Accent Color", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SingularityAccentPalette.presets.forEach { opt ->
                    Surface(
                        onClick = { sessionManager.updateAppSettings { it.copy(accentColorHex = opt.hex) } },
                        border = ClickableSurfaceDefaults.border(focusedBorder = Border(BorderStroke(3.dp, Color.White))),
                        shape = ClickableSurfaceDefaults.shape(CircleShape),
                        colors = ClickableSurfaceDefaults.colors(containerColor = tvAccent(opt.hex)),
                        modifier = Modifier.size(44.dp)
                    ) {
                        if (settings.accentColorHex.equals(opt.hex, true)) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Icon(Icons.Default.Check, null, tint = Color.White) }
                        }
                    }
                }
            }
        }
        item {
            Text("Preferred Quality: ${webPrefs.preferredQuality}", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("Auto", "1080p", "720p", "480p").forEach { q ->
                    Button(onClick = { sessionManager.updateWebPlayerPrefs { it.copy(preferredQuality = q) } }) { Text(q) }
                }
            }
        }
        item {
            Text("Subtitle Language: ${webPrefs.subtitleLanguage}", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("Off", "Arabic", "English").forEach { s ->
                    Button(onClick = { sessionManager.updateWebPlayerPrefs { it.copy(subtitleLanguage = s) } }) { Text(s) }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Button(onClick = { sessionManager.clearHistory() }) { Text("Delete History") }
                Button(onClick = { sessionManager.clearCache() }) { Text("Delete Cache") }
                Button(onClick = { sessionManager.signOut() }, colors = ButtonDefaults.colors(containerColor = accent, contentColor = Color.White)) { Text("Sign Out") }
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvDetailScreen(
    item: MediaItem,
    sessionManager: SessionManager,
    accent: Color,
    onOpenRelated: (MediaItem) -> Unit,
    onPlay: (WatchItem) -> Unit,
    onBack: () -> Unit
) {
    var payload by remember { mutableStateOf<TitleDetailPayload?>(null) }
    var selectedSeason by remember { mutableIntStateOf(1) }
    var episodes by remember { mutableStateOf<List<EpisodeSummary>>(emptyList()) }
    val reminders by sessionManager.reminders.collectAsState()

    LaunchedEffect(item.id, item.mediaType) {
        payload = TMDBApiClient.titleDetail(item.watchType, item.id)
        if (!item.isMovie) {
            selectedSeason = payload?.seasons?.firstOrNull { it.seasonNumber > 0 }?.seasonNumber ?: 1
            episodes = TMDBApiClient.seasonEpisodes(item.id, selectedSeason)
        }
    }

    LaunchedEffect(selectedSeason) {
        if (!item.isMovie) episodes = TMDBApiClient.seasonEpisodes(item.id, selectedSeason)
    }

    val saved = MyListItem(item.watchType, item.id, item.displayTitle, item.posterPath, item.backdropPath, item.overview, item.displayYear)
    val reminded = reminders.any { it.title.mediaType == item.watchType && it.title.tmdbId == item.id }
    val relDate = item.releaseDateParsed
    val cast = payload?.credits?.cast?.take(14).orEmpty()
    val related = (payload?.recommendations?.results.orEmpty() + payload?.similar?.results.orEmpty())
        .map { if (it.mediaType != "movie" && it.mediaType != "tv") it.copy(mediaType = item.mediaType) else it }
        .distinctBy { "${it.mediaType}_${it.id}" }
        .filter { it.id != item.id && !it.posterPath.isNullOrBlank() }
        .take(14)
    val cert = payload?.usCertification(item.isMovie)
    val directorOrCreators = payload?.directorOrCreators(item.isMovie)

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AsyncImage(model = item.backdropUrl ?: item.posterUrl, contentDescription = item.displayTitle, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize(), alpha = 0.42f)
        Box(
            Modifier.fillMaxSize().background(
                Brush.horizontalGradient(listOf(Color.Black.copy(alpha = 0.94f), Color.Black.copy(alpha = 0.7f), Color.Black.copy(alpha = 0.35f)))
            )
        )
        LazyColumn(modifier = Modifier.fillMaxSize().padding(38.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
            item {
                Column(modifier = Modifier.width(680.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(item.displayTitle, color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.Black)
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        item.matchPercent?.let { Text("$it% Match", color = Color(0xFF45D478), fontSize = 14.sp, fontWeight = FontWeight.Bold) }
                        item.displayYear?.let { Text(it, color = Color.LightGray, fontSize = 14.sp) }
                        cert?.let { Text(it, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.background(Color.White.copy(alpha = 0.16f), RoundedCornerShape(4.dp)).padding(horizontal = 6.dp, vertical = 2.dp)) }
                        if (item.isMovie) {
                            payload?.runtime?.takeIf { it > 0 }?.let { Text("${it / 60}h ${it % 60}m", color = Color.LightGray, fontSize = 14.sp) }
                        } else {
                            payload?.numberOfSeasons?.let { Text("$it ${if (it == 1) "Season" else "Seasons"}", color = Color.LightGray, fontSize = 14.sp) }
                        }
                        payload?.status?.takeIf { it.isNotBlank() }?.let { Text("• $it", color = Color.Gray, fontSize = 13.sp) }
                    }
                    val genres = payload?.genres?.map { it.name }?.take(4).orEmpty().ifEmpty { item.genreTags }
                    if (genres.isNotEmpty()) {
                        Text(genres.joinToString("  •  "), color = Color(0xFFB8B8B8), fontSize = 13.sp)
                    }
                    Text(item.overview, color = Color.LightGray, fontSize = 15.sp, maxLines = 4, overflow = TextOverflow.Ellipsis)
                    if (cast.isNotEmpty()) {
                        Text("Starring: ${cast.take(4).joinToString(", ") { it.name }}", color = Color.Gray, fontSize = 13.sp)
                    }
                    directorOrCreators?.let {
                        Text("${if (item.isMovie) "Director" else "Creators"}: $it", color = Color.Gray, fontSize = 13.sp)
                    }
                    Spacer(Modifier.height(4.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        if (item.isUpcoming && relDate != null) {
                            Button(
                                onClick = { sessionManager.toggleReminder(saved, relDate.time, scheduleNotification = false) },
                                colors = ButtonDefaults.colors(containerColor = Color.White, contentColor = Color.Black)
                            ) {
                                Icon(if (reminded) Icons.Default.Notifications else Icons.Default.NotificationsNone, null)
                                Text(if (reminded) " Reminder Set" else " Remind Me", fontWeight = FontWeight.Bold)
                            }
                        } else {
                            Button(
                                onClick = {
                                    onPlay(WatchItem(id = "${item.watchType.rawValue}_${item.id}", type = item.watchType, title = item.displayTitle, tmdbId = item.id.toString(), season = if (item.isMovie) null else selectedSeason, episode = if (item.isMovie) null else 1, posterPath = item.posterPath, generatedURL = StreamingProviderBuilder.buildUrl(item.watchType, item.id, selectedSeason, 1)))
                                },
                                colors = ButtonDefaults.colors(containerColor = Color.White, contentColor = Color.Black)
                            ) { Icon(Icons.Default.PlayArrow, null); Text(" Play", fontWeight = FontWeight.Bold) }
                        }
                        Button(onClick = { sessionManager.toggleMyList(saved) }) {
                            Icon(if (sessionManager.isInMyList(item.watchType, item.id)) Icons.Default.Check else Icons.Default.Add, null)
                            Text(" My List")
                        }
                        Button(onClick = { sessionManager.toggleLike(saved) }) {
                            Icon(Icons.Default.ThumbUp, null)
                            Text(" Rate")
                        }
                        Button(onClick = onBack) { Text("Back") }
                    }
                }
            }
            if (cast.isNotEmpty()) {
                item {
                    Text("Cast & Crew", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        items(cast, key = { it.id }) { p ->
                            Column(Modifier.width(100.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                AsyncImage(model = p.profileUrl, contentDescription = p.name, contentScale = ContentScale.Crop, modifier = Modifier.size(76.dp).clip(CircleShape).background(Color(0xFF2B2B2B)))
                                Spacer(Modifier.height(6.dp))
                                Text(p.name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                p.character?.takeIf { it.isNotBlank() }?.let { Text(it, color = Color.Gray, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                            }
                        }
                    }
                }
            }
            if (!item.isMovie) {
                val seasons = payload?.seasons?.filter { it.seasonNumber > 0 }.orEmpty()
                if (seasons.isNotEmpty()) {
                    item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(seasons) { s ->
                                Button(
                                    onClick = { selectedSeason = s.seasonNumber },
                                    colors = ButtonDefaults.colors(containerColor = if (selectedSeason == s.seasonNumber) accent else Color(0xFF262626), contentColor = Color.White)
                                ) { Text("Season ${s.seasonNumber}") }
                            }
                        }
                    }
                }
                if (episodes.isNotEmpty()) {
                    item {
                        Text("Episodes", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(8.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            itemsIndexed(episodes) { _, ep ->
                                val aired = ep.hasAired
                                Surface(
                                    onClick = {
                                        if (aired) {
                                            onPlay(WatchItem(id = "tv_${item.id}_s${selectedSeason}_e${ep.episodeNumber}", type = WatchType.TV, title = item.displayTitle, tmdbId = item.id.toString(), season = selectedSeason, episode = ep.episodeNumber, episodeName = ep.name, posterPath = item.posterPath, generatedURL = StreamingProviderBuilder.buildUrl(WatchType.TV, item.id, selectedSeason, ep.episodeNumber)))
                                        }
                                    },
                                    border = ClickableSurfaceDefaults.border(focusedBorder = Border(BorderStroke(2.dp, Color.White))),
                                    modifier = Modifier.width(240.dp).alpha(if (aired) 1f else 0.55f)
                                ) {
                                    Column(Modifier.padding(10.dp)) {
                                        AsyncImage(model = ep.stillUrl ?: item.backdropUrl, contentDescription = ep.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().height(120.dp).clip(RoundedCornerShape(6.dp)))
                                        Spacer(Modifier.height(6.dp))
                                        Text("${ep.episodeNumber}. ${ep.name.ifBlank { "Episode ${ep.episodeNumber}" }}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        if (!aired && !ep.airDate.isNullOrBlank()) {
                                            Text("Coming ${ep.airDate}", color = accent, fontSize = 11.sp)
                                        } else if (ep.overview.isNotBlank()) {
                                            Text(ep.overview, color = Color.Gray, fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (related.isNotEmpty()) {
                item { TvMediaRow("More Like This", related, accent, onOpenRelated) }
            }
        }
    }
}
