package com.singularity.tv.mobile

import android.Manifest
import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.ThumbUpOffAlt
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.singularity.tv.core.data.GateStage
import com.singularity.tv.core.data.SessionManager
import com.singularity.tv.core.model.ContinueWatchingItem
import com.singularity.tv.core.model.EpisodeSummary
import com.singularity.tv.core.model.MediaItem
import com.singularity.tv.core.model.MyListItem
import com.singularity.tv.core.model.ReminderResult
import com.singularity.tv.core.model.SingularityDateHelper
import com.singularity.tv.core.model.SingularityAccentPalette
import com.singularity.tv.core.model.SingularityGenres
import com.singularity.tv.core.model.TitleDetailPayload
import com.singularity.tv.core.model.WatchItem
import com.singularity.tv.core.model.WatchType
import com.singularity.tv.core.network.SingularityConfig
import com.singularity.tv.core.network.StreamingProviderBuilder
import com.singularity.tv.core.network.TMDBApiClient
import com.singularity.tv.core.player.SingularityPlayerHost
import kotlinx.coroutines.launch

private fun parseAccentColor(hex: String): Color {
    val clean = hex.removePrefix("#").trim()
    val rgb = clean.toLongOrNull(16) ?: 0xE50914L
    return Color(0xFF000000L or rgb)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val sessionManager = SessionManager.getInstance(applicationContext)
        setContent {
            val appSettings by sessionManager.appSettings.collectAsState()
            val accentColor = parseAccentColor(appSettings.accentColorHex)
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = accentColor,
                    background = Color.Black,
                    surface = Color(0xFF1C1C1C),
                    onBackground = Color.White,
                    onSurface = Color.White
                )
            ) {
                SingularityMobileRoot(sessionManager = sessionManager, accent = accentColor, activity = this)
            }
        }
    }
}

@Composable
private fun SingularityMobileRoot(sessionManager: SessionManager, accent: Color, activity: ComponentActivity) {
    val stage by sessionManager.stage.collectAsState()
    val isHydrating by sessionManager.isHydratingProfile.collectAsState()
    val appSettings by sessionManager.appSettings.collectAsState()
    var activePlayerItem by remember { mutableStateOf<WatchItem?>(null) }
    var detailItem by remember { mutableStateOf<MediaItem?>(null) }
    var showSettings by remember { mutableStateOf(false) }

    if (activePlayerItem != null) {
        val item = activePlayerItem!!
        val prefs by sessionManager.webPlayerPrefs.collectAsState()
        DisposableEffect(Unit) {
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            onDispose { activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED }
        }
        SingularityPlayerHost(
            item = item,
            savedPrefs = prefs,
            accentHex = appSettings.accentColorHex,
            onProgress = { ct, dur ->
                sessionManager.recordProgress(
                    type = item.type,
                    tmdbId = item.tmdbId,
                    title = item.title,
                    posterPath = item.posterPath,
                    season = item.season,
                    episode = item.episode,
                    episodeName = item.episodeName,
                    positionSeconds = ct,
                    durationSeconds = dur
                )
            },
            onPrefChanged = { key, value ->
                sessionManager.updateWebPlayerPrefs { cur ->
                    when (key) {
                        "preferredQuality" -> cur.copy(preferredQuality = value)
                        "subtitleLanguage" -> cur.copy(subtitleLanguage = value)
                        "playbackSpeed" -> cur.copy(playbackSpeed = value)
                        else -> cur
                    }
                }
            },
            onBack = { activePlayerItem = null }
        )
        return
    }

    if (showSettings) {
        MobileSettingsScreen(
            sessionManager = sessionManager,
            accent = accent,
            onBack = { showSettings = false }
        )
        return
    }

    if (detailItem != null) {
        MobileDetailScreen(
            item = detailItem!!,
            sessionManager = sessionManager,
            accent = accent,
            onOpenRelated = { detailItem = it },
            onPlay = { watchItem ->
                sessionManager.recordHistory(watchItem)
                activePlayerItem = watchItem
            },
            onBack = { detailItem = null }
        )
        return
    }

    when (stage) {
        GateStage.CHECKING_AUTH -> Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = accent)
        }
        GateStage.AUTH_REQUIRED -> MobileAuthScreen(sessionManager, accent)
        GateStage.TELEGRAM_REQUIRED -> MobileTelegramGateScreen(sessionManager, accent)
        GateStage.PROFILE_SELECT -> MobileProfilesGateScreen(sessionManager, isHydrating, accent)
        GateStage.READY -> MobileMainShell(
            sessionManager = sessionManager,
            accent = accent,
            onOpenDetail = { detailItem = it },
            onOpenSettings = { showSettings = true },
            onPlay = { watchItem ->
                sessionManager.recordHistory(watchItem)
                activePlayerItem = watchItem
            }
        )
    }
}

@Composable
private fun MobileAuthScreen(sessionManager: SessionManager, accent: Color) {
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var isSignUp by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier.fillMaxSize().background(Color.Black).padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("SingularityTV", color = accent, fontSize = 32.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(24.dp))
        if (isSignUp) {
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
        }
        OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
        error?.let {
            Spacer(Modifier.height(10.dp))
            Text(it, color = accent, fontSize = 13.sp)
        }
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = {
                busy = true
                error = null
                scope.launch {
                    val res = if (isSignUp) sessionManager.signUp(email.trim(), password, name.trim()) else sessionManager.signIn(email.trim(), password)
                    busy = false
                    res.onFailure { error = it.message }
                }
            },
            enabled = !busy,
            colors = ButtonDefaults.buttonColors(containerColor = accent),
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) {
            if (busy) CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
            else Text(if (isSignUp) "Create Account" else "Sign In", color = Color.White, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = { isSignUp = !isSignUp }, modifier = Modifier.fillMaxWidth()) {
            Text(if (isSignUp) "Already have an account? Sign In" else "New to SingularityTV? Sign Up", color = Color.White)
        }
    }
}

@Composable
private fun MobileTelegramGateScreen(sessionManager: SessionManager, accent: Color) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier.fillMaxSize().background(Color.Black).padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Telegram Verification", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text("Link your account via @${SingularityConfig.TELEGRAM_BOT_USERNAME} and join our channel to unlock streaming.", color = Color.Gray, fontSize = 14.sp)
        Spacer(Modifier.height(24.dp))
        Button(
            onClick = {
                busy = true
                scope.launch {
                    sessionManager.recheckTelegramGate()
                    busy = false
                }
            },
            enabled = !busy,
            colors = ButtonDefaults.buttonColors(containerColor = accent),
            modifier = Modifier.fillMaxWidth().height(48.dp)
        ) {
            Text(if (busy) "Checking..." else "Verify Membership", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun MobileProfilesGateScreen(sessionManager: SessionManager, isHydrating: Boolean, accent: Color) {
    val profiles by sessionManager.profiles.collectAsState()
    var selectedName by remember { mutableStateOf<String?>(null) }
    var showCreate by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
            Text("Who's Watching?", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(28.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                profiles.forEach { profile ->
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable(enabled = !isHydrating) {
                            selectedName = profile.name
                            sessionManager.selectProfile(profile)
                        }
                    ) {
                        Box(
                            modifier = Modifier.size(82.dp).clip(RoundedCornerShape(14.dp)).background(parseAccentColor(profile.avatarColor)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(profile.name.take(1).uppercase(), color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(profile.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    }
                }
                if (profiles.size < 5) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable { showCreate = true }
                    ) {
                        Box(
                            modifier = Modifier.size(82.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF1F1F1F)).border(1.dp, Color.White.copy(alpha = 0.2f), RoundedCornerShape(14.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Add, null, tint = Color.White, modifier = Modifier.size(30.dp))
                        }
                        Spacer(Modifier.height(8.dp))
                        Text("Add Profile", color = Color.Gray, fontSize = 13.sp)
                    }
                }
            }
        }
        if (isHydrating) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.82f)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    CircularProgressIndicator(color = Color.White)
                    Text("Loading ${selectedName ?: "profile"}...", color = Color.White.copy(alpha = 0.88f), fontSize = 14.sp)
                }
            }
        }
        if (showCreate) {
            AlertDialog(
                onDismissRequest = { showCreate = false },
                title = { Text("New Profile") },
                text = { OutlinedTextField(value = newName, onValueChange = { newName = it }, label = { Text("Profile Name") }, singleLine = true) },
                confirmButton = {
                    Button(onClick = {
                        if (newName.isNotBlank()) sessionManager.createProfile(newName.trim(), "#E50914", false)
                        newName = ""
                        showCreate = false
                    }, colors = ButtonDefaults.buttonColors(containerColor = accent)) { Text("Create") }
                },
                dismissButton = { TextButton(onClick = { showCreate = false }) { Text("Cancel") } }
            )
        }
    }
}

@Composable
private fun MobileMainShell(
    sessionManager: SessionManager,
    accent: Color,
    onOpenDetail: (MediaItem) -> Unit,
    onOpenSettings: () -> Unit,
    onPlay: (WatchItem) -> Unit
) {
    var tab by remember { mutableIntStateOf(0) }
    Scaffold(
        containerColor = Color.Black,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0D0D0D)) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Whatshot, null) }, label = { Text("New & Hot") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Search, null) }, label = { Text("Search") })
                NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("My Singularity") })
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            when (tab) {
                0 -> MobileHomeTab(sessionManager, accent, onOpenDetail, onOpenSearch = { tab = 2 }, onPlay = onPlay)
                1 -> MobileNewHotTab(sessionManager, accent, onOpenDetail, onPlay)
                2 -> MobileSearchTab(accent, onOpenDetail, onPlay)
                3 -> MobileMySingularityTab(sessionManager, accent, onOpenDetail, onOpenSettings, onPlay)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun MobileHomeTab(
    sessionManager: SessionManager,
    accent: Color,
    onOpenDetail: (MediaItem) -> Unit,
    onOpenSearch: () -> Unit,
    onPlay: (WatchItem) -> Unit
) {
    var scope by remember { mutableStateOf("all") }
    var selectedGenre by remember { mutableStateOf<Pair<Int, String>?>(null) }
    var showCategories by remember { mutableStateOf(false) }

    var trending by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var movies by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var series by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var genreItems by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    val cw by sessionManager.continueWatching.collectAsState()
    val myList by sessionManager.myList.collectAsState()

    LaunchedEffect(Unit) {
        trending = TMDBApiClient.trendingAll()
        movies = TMDBApiClient.popularMovies()
        series = TMDBApiClient.popularSeries()
    }

    LaunchedEffect(scope, selectedGenre) {
        selectedGenre?.let { (gid, _) ->
            val type = if (scope == "series") WatchType.TV else WatchType.MOVIE
            genreItems = TMDBApiClient.discoverByGenre(type, gid)
        }
    }

    val filteredTrending = when (scope) {
        "series" -> trending.filter { !it.isMovie }
        "films" -> trending.filter { it.isMovie }
        else -> trending
    }
    val heroItem = (if (selectedGenre != null) genreItems else filteredTrending).firstOrNull()

    LazyColumn(modifier = Modifier.fillMaxSize().background(Color.Black), contentPadding = PaddingValues(bottom = 28.dp)) {
        item {
            Column(modifier = Modifier.fillMaxWidth().statusBarsPadding()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("SingularityTV", color = accent, fontSize = 23.sp, fontWeight = FontWeight.Black)
                    IconButton(onClick = onOpenSearch) {
                        Icon(Icons.Default.Search, contentDescription = "Search", tint = Color.White)
                    }
                }
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (scope != "all" || selectedGenre != null) {
                        item {
                            FilterChip(
                                selected = false,
                                onClick = { scope = "all"; selectedGenre = null },
                                label = { Icon(Icons.Default.Close, null, modifier = Modifier.size(16.dp)) },
                                shape = CircleShape
                            )
                        }
                    }
                    item {
                        FilterChip(
                            selected = scope == "series",
                            onClick = { scope = if (scope == "series") "all" else "series" },
                            label = { Text("Series") },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color.White, selectedLabelColor = Color.Black),
                            shape = CircleShape
                        )
                    }
                    item {
                        FilterChip(
                            selected = scope == "films",
                            onClick = { scope = if (scope == "films") "all" else "films" },
                            label = { Text("Films") },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color.White, selectedLabelColor = Color.Black),
                            shape = CircleShape
                        )
                    }
                    item {
                        FilterChip(
                            selected = selectedGenre != null,
                            onClick = { showCategories = true },
                            label = {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(selectedGenre?.second ?: "Categories")
                                    Icon(Icons.Default.KeyboardArrowDown, null, modifier = Modifier.size(16.dp))
                                }
                            },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color.White, selectedLabelColor = Color.Black),
                            shape = CircleShape
                        )
                    }
                }
                Spacer(Modifier.height(10.dp))
            }
        }

        heroItem?.let { hero ->
            item {
                Box(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(380.dp).clip(RoundedCornerShape(12.dp)).clickable { onOpenDetail(hero) }
                ) {
                    AsyncImage(model = hero.posterUrl, contentDescription = hero.displayTitle, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.90f)))))
                    Column(modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(hero.displayTitle, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        val tags = hero.genreIds?.mapNotNull { SingularityGenres.names[it] }?.take(3)?.joinToString(" · ")
                        if (!tags.isNullOrEmpty()) {
                            Spacer(Modifier.height(4.dp))
                            Text(tags, color = Color.White.copy(alpha = 0.85f), fontSize = 12.sp)
                        }
                        Spacer(Modifier.height(12.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                            Button(
                                onClick = {
                                    onPlay(
                                        WatchItem(
                                            id = "${hero.watchType.rawValue}_${hero.id}",
                                            type = hero.watchType,
                                            title = hero.displayTitle,
                                            tmdbId = hero.id.toString(),
                                            season = if (hero.isMovie) null else 1,
                                            episode = if (hero.isMovie) null else 1,
                                            posterPath = hero.posterPath,
                                            generatedURL = StreamingProviderBuilder.buildUrl(hero.watchType, hero.id, 1, 1)
                                        )
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Icon(Icons.Default.PlayArrow, null)
                                Text("Play", fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = { sessionManager.toggleMyList(MyListItem(hero.watchType, hero.id, hero.displayTitle, hero.posterPath, hero.backdropPath, hero.overview, hero.displayYear)) },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.22f), contentColor = Color.White),
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Icon(if (sessionManager.isInMyList(hero.watchType, hero.id)) Icons.Default.Check else Icons.Default.Add, null)
                                Text(" My List", fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }
            }
        }

        if (selectedGenre != null && genreItems.isNotEmpty()) {
            item { MediaRail(selectedGenre!!.second, genreItems, accent, onOpenDetail) }
        } else {
            val filteredCW = cw.filter { scope == "all" || (scope == "series" && it.type == WatchType.TV) || (scope == "films" && it.type == WatchType.MOVIE) }
            if (filteredCW.isNotEmpty()) {
                item {
                    Spacer(Modifier.height(20.dp))
                    Text("Continue Watching", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(filteredCW, key = { it.id }) { entry ->
                            ContinueCardMobile(
                                entry = entry,
                                accent = accent,
                                onPlay = {
                                    onPlay(
                                        WatchItem(
                                            id = entry.id,
                                            type = entry.type,
                                            title = entry.title,
                                            tmdbId = entry.tmdbId,
                                            season = entry.season,
                                            episode = entry.episode,
                                            episodeName = entry.episodeName,
                                            posterPath = entry.posterPath,
                                            generatedURL = StreamingProviderBuilder.buildUrl(entry.type, entry.tmdbId.toIntOrNull() ?: 0, entry.season, entry.episode, entry.progressSeconds?.toInt())
                                        )
                                    )
                                },
                                onInfo = {
                                    onOpenDetail(MediaItem(id = entry.tmdbId.toIntOrNull() ?: 0, mediaType = entry.type.rawValue, title = entry.title, name = entry.title, posterPath = entry.posterPath))
                                },
                                onRemove = { sessionManager.removeContinueWatching(entry.type, entry.tmdbId) }
                            )
                        }
                    }
                }
            }
            if (filteredTrending.isNotEmpty()) item { Top10Rail("Top 10 Today", filteredTrending.take(10), accent, onOpenDetail) }
            if (scope != "series" && movies.isNotEmpty()) item { MediaRail("Popular Movies", movies, accent, onOpenDetail, badge = "Recently Added") }
            if (scope != "films" && series.isNotEmpty()) item { MediaRail("Popular Series", series, accent, onOpenDetail, badge = "New Episodes") }
            if (myList.isNotEmpty()) item { MediaRail("My List", myList.map { it.toMediaItem() }, accent, onOpenDetail) }
        }
    }

    if (showCategories) {
        ModalBottomSheet(onDismissRequest = { showCategories = false }, containerColor = Color(0xFF141414)) {
            LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(SingularityGenres.all) { pair ->
                    Text(
                        pair.second,
                        color = if (selectedGenre?.first == pair.first) accent else Color.White,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.fillMaxWidth().clickable {
                            selectedGenre = pair
                            showCategories = false
                        }.padding(vertical = 10.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ContinueCardMobile(entry: ContinueWatchingItem, accent: Color, onPlay: () -> Unit, onInfo: () -> Unit, onRemove: () -> Unit) {
    var menuExpanded by remember { mutableStateOf(false) }
    Column(modifier = Modifier.width(114.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFF1F1F1F))) {
        Box(modifier = Modifier.fillMaxWidth().height(162.dp).clickable(onClick = onPlay)) {
            AsyncImage(model = entry.posterUrl, contentDescription = entry.title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            Box(modifier = Modifier.size(42.dp).align(Alignment.Center).clip(CircleShape).background(Color.Black.copy(alpha = 0.55f)).border(1.5.dp, Color.White, CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.PlayArrow, null, tint = Color.White)
            }
            LinearProgressIndicator(progress = { (entry.progressFraction ?: 0.04).toFloat() }, color = accent, trackColor = Color.White.copy(alpha = 0.25f), modifier = Modifier.fillMaxWidth().height(3.dp).align(Alignment.BottomCenter))
        }
        Row(modifier = Modifier.fillMaxWidth().height(34.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Icon(Icons.Default.Info, null, tint = Color.White.copy(alpha = 0.85f), modifier = Modifier.size(18.dp).clickable(onClick = onInfo))
            val sub = if (entry.type == WatchType.TV) "S${entry.season ?: 1}:E${entry.episode ?: 1}" else entry.durationSeconds?.takeIf { it > 0 }?.let { "${(it / 60).toInt()}m" }.orEmpty()
            Text(sub, color = Color.LightGray, fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
            Box {
                Icon(Icons.Default.MoreVert, null, tint = Color.White.copy(alpha = 0.85f), modifier = Modifier.size(18.dp).clickable { menuExpanded = true })
                DropdownMenu(expanded = menuExpanded, onDismissRequest = { menuExpanded = false }) {
                    DropdownMenuItem(text = { Text("Details & More") }, onClick = { menuExpanded = false; onInfo() })
                    DropdownMenuItem(text = { Text("Remove from Row", color = accent) }, onClick = { menuExpanded = false; onRemove() })
                }
            }
        }
    }
}

@Composable
private fun Top10Rail(title: String, items: List<MediaItem>, accent: Color, onClick: (MediaItem) -> Unit) {
    Column {
        Spacer(Modifier.height(20.dp))
        Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            itemsIndexed(items, key = { _, it -> "top10_${it.mediaType}_${it.id}" }) { index, item ->
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("${index + 1}", color = Color.White.copy(alpha = 0.28f), fontSize = 68.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(end = 2.dp))
                    PosterCardMobile(item, accent, badge = "TOP 10", onClick = onClick)
                }
            }
        }
    }
}

@Composable
private fun MediaRail(title: String, items: List<MediaItem>, accent: Color, onClick: (MediaItem) -> Unit, badge: String? = null) {
    Column {
        Spacer(Modifier.height(20.dp))
        Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(items, key = { "${it.mediaType}_${it.id}" }) { item ->
                PosterCardMobile(item, accent, badge = badge, onClick = onClick)
            }
        }
    }
}

@Composable
private fun PosterCardMobile(item: MediaItem, accent: Color, badge: String? = null, onClick: (MediaItem) -> Unit) {
    Box(modifier = Modifier.width(112.dp).aspectRatio(0.67f).clip(RoundedCornerShape(4.dp)).clickable { onClick(item) }) {
        AsyncImage(model = item.posterUrl, contentDescription = item.displayTitle, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        if (item.isArabicOrGulfContent) {
            Row(
                modifier = Modifier.padding(4.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.72f)).padding(horizontal = 6.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Icon(Icons.Default.ErrorOutline, null, tint = Color.White, modifier = Modifier.size(10.dp))
                Text("May Not Stream", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        if (badge == "TOP 10") {
            Box(modifier = Modifier.align(Alignment.TopEnd).background(accent, RoundedCornerShape(bottomStart = 3.dp)).padding(horizontal = 4.dp, vertical = 2.dp)) {
                Text("TOP\n10", color = Color.White, fontSize = 7.sp, fontWeight = FontWeight.Black, lineHeight = 8.sp)
            }
        } else if (badge != null) {
            Box(modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp).background(accent, RoundedCornerShape(2.dp)).padding(horizontal = 6.dp, vertical = 2.dp)) {
                Text(badge, color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun MobileNewHotTab(sessionManager: SessionManager, accent: Color, onOpenDetail: (MediaItem) -> Unit, onPlay: (WatchItem) -> Unit) {
    val context = LocalContext.current
    var selectedChip by remember { mutableIntStateOf(0) }
    var items by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var showDeniedDialog by remember { mutableStateOf(false) }
    var pendingReminder by remember { mutableStateOf<Pair<MyListItem, Long>?>(null) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val pending = pendingReminder
        pendingReminder = null
        if (granted && pending != null) {
            sessionManager.toggleReminder(pending.first, pending.second, scheduleNotification = true)
        } else if (!granted) {
            showDeniedDialog = true
        }
    }

    LaunchedEffect(selectedChip) {
        isLoading = true
        items = when (selectedChip) {
            0 -> TMDBApiClient.upcomingComingSoon()
            1 -> TMDBApiClient.trendingToday().take(10)
            2 -> TMDBApiClient.trendingTodaySeries().take(10)
            else -> TMDBApiClient.trendingTodayMovies().take(10)
        }
        isLoading = false
    }

    if (showDeniedDialog) {
        AlertDialog(
            onDismissRequest = { showDeniedDialog = false },
            title = { Text("Notifications are off") },
            text = { Text("Allow notifications for SingularityTV in Settings to get a reminder when titles come out.") },
            confirmButton = {
                TextButton(onClick = {
                    showDeniedDialog = false
                    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
                    context.startActivity(intent)
                }) { Text("Open Settings") }
            },
            dismissButton = { TextButton(onClick = { showDeniedDialog = false }) { Text("Not Now") } }
        )
    }

    Column(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding()) {
        Text("New & Hot", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val chips = listOf("Coming Soon", "Everyone's Watching", "Top 10 Series", "Top 10 Films")
            itemsIndexed(chips) { idx, label ->
                FilterChip(
                    selected = selectedChip == idx,
                    onClick = { selectedChip = idx },
                    label = { Text(label, fontWeight = FontWeight.SemiBold) },
                    colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Color.White, selectedLabelColor = Color.Black),
                    shape = CircleShape
                )
            }
        }
        if (isLoading) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = Color.White)
            }
        } else if (items.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No upcoming titles found right now.", color = Color.Gray)
            }
        } else {
            LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(26.dp)) {
                itemsIndexed(items, key = { _, it -> "${selectedChip}_${it.mediaType}_${it.id}" }) { idx, item ->
                    val saved = MyListItem(item.watchType, item.id, item.displayTitle, item.posterPath, item.backdropPath, item.overview, item.displayYear)
                    val relDate = item.releaseDateParsed
                    val reminded = sessionManager.isReminded(item.watchType, item.id)
                    val inList = sessionManager.isInMyList(item.watchType, item.id)

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
                        if (selectedChip == 0 && relDate != null) {
                            Column(modifier = Modifier.width(46.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(SingularityDateHelper.monthAbbrev(relDate), color = Color(0xFFB8B8B8), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                Text(SingularityDateHelper.dayNumber(relDate), color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                            }
                        } else if (selectedChip >= 2) {
                            Text("${idx + 1}", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Black, modifier = Modifier.width(42.dp))
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .aspectRatio(16f / 9f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color(0xFF1C1C1C))
                                    .clickable { onOpenDetail(item) }
                            ) {
                                AsyncImage(model = item.backdropUrl ?: item.posterUrl, contentDescription = item.displayTitle, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                            }
                            Spacer(Modifier.height(10.dp))
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(item.displayTitle, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
                                if (selectedChip == 0) {
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.clickable {
                                            val epochMs = relDate?.time ?: SingularityDateHelper.startOfTomorrow().time
                                            val res = sessionManager.toggleReminder(saved, epochMs, scheduleNotification = true)
                                            if (res == ReminderResult.NOTIFICATIONS_DENIED && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                                pendingReminder = saved to epochMs
                                                permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                            }
                                        }.padding(horizontal = 10.dp)
                                    ) {
                                        Icon(if (reminded) Icons.Default.Notifications else Icons.Default.NotificationsNone, null, tint = if (reminded) accent else Color.White)
                                        Text(if (reminded) "Reminder Set" else "Remind Me", color = Color(0xFFB8B8B8), fontSize = 10.sp)
                                    }
                                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { onOpenDetail(item) }.padding(horizontal = 8.dp)) {
                                        Icon(Icons.Default.Info, null, tint = Color.White)
                                        Text("Info", color = Color(0xFFB8B8B8), fontSize = 10.sp)
                                    }
                                } else {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { sessionManager.toggleMyList(saved) }.padding(horizontal = 10.dp)) {
                                        Icon(if (inList) Icons.Default.Check else Icons.Default.Add, null, tint = Color.White)
                                        Text("My List", color = Color(0xFFB8B8B8), fontSize = 10.sp)
                                    }
                                    Column(
                                        horizontalAlignment = Alignment.CenterHorizontally,
                                        modifier = Modifier.clickable {
                                            onPlay(WatchItem(id = "${item.watchType.rawValue}_${item.id}", type = item.watchType, title = item.displayTitle, tmdbId = item.id.toString(), season = if (item.isMovie) null else 1, episode = if (item.isMovie) null else 1, posterPath = item.posterPath, generatedURL = StreamingProviderBuilder.buildUrl(item.watchType, item.id, 1, 1)))
                                        }.padding(horizontal = 8.dp)
                                    ) {
                                        Icon(Icons.Default.PlayArrow, null, tint = Color.White)
                                        Text("Play", color = Color(0xFFB8B8B8), fontSize = 10.sp)
                                    }
                                }
                            }
                            if (selectedChip == 0 && relDate != null) {
                                Spacer(Modifier.height(4.dp))
                                Text(SingularityDateHelper.comingLabel(relDate, item.isMovie), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            }
                            Spacer(Modifier.height(4.dp))
                            Text(item.overview, color = Color(0xFFB8B8B8), fontSize = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis, lineHeight = 18.sp)
                            if (item.genreTags.isNotEmpty()) {
                                Spacer(Modifier.height(6.dp))
                                Text(item.genreTags.joinToString("  •  "), color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MobileSearchTab(accent: Color, onOpenDetail: (MediaItem) -> Unit, onPlay: (WatchItem) -> Unit) {
    var query by remember { mutableStateOf("") }
    var topSearches by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var results by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    LaunchedEffect(Unit) { topSearches = TMDBApiClient.trendingToday() }
    LaunchedEffect(query) { results = if (query.isBlank()) emptyList() else TMDBApiClient.searchMulti(query) }

    Column(modifier = Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().padding(16.dp)) {
        OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Search movies & series") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(14.dp))
        if (query.isBlank()) {
            Text("Top Searches", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(topSearches, key = { "${it.mediaType}_${it.id}" }) { item ->
                    Row(
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(Color(0xFF141414)).clickable { onOpenDetail(item) }.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AsyncImage(model = item.backdropUrl ?: item.posterUrl, contentDescription = item.displayTitle, contentScale = ContentScale.Crop, modifier = Modifier.width(120.dp).height(68.dp).clip(RoundedCornerShape(4.dp)))
                        Spacer(Modifier.width(12.dp))
                        Text(item.displayTitle, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), maxLines = 2)
                        IconButton(onClick = {
                            onPlay(WatchItem(id = "${item.watchType.rawValue}_${item.id}", type = item.watchType, title = item.displayTitle, tmdbId = item.id.toString(), season = if (item.isMovie) null else 1, episode = if (item.isMovie) null else 1, posterPath = item.posterPath, generatedURL = StreamingProviderBuilder.buildUrl(item.watchType, item.id, 1, 1)))
                        }) { Icon(Icons.Default.PlayArrow, null, tint = Color.White) }
                    }
                }
            }
        } else {
            LazyVerticalGrid(columns = GridCells.Fixed(3), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(results, key = { "${it.mediaType}_${it.id}" }) { PosterCardMobile(it, accent, onClick = onOpenDetail) }
            }
        }
    }
}

@Composable
private fun MobileMySingularityTab(
    sessionManager: SessionManager,
    accent: Color,
    onOpenDetail: (MediaItem) -> Unit,
    onOpenSettings: () -> Unit,
    onPlay: (WatchItem) -> Unit
) {
    val profile by sessionManager.activeProfile.collectAsState()
    val session by sessionManager.session.collectAsState()
    val myList by sessionManager.myList.collectAsState()
    val liked by sessionManager.liked.collectAsState()
    val reminders by sessionManager.reminders.collectAsState()
    val cw by sessionManager.continueWatching.collectAsState()
    val history by sessionManager.history.collectAsState()

    LazyColumn(modifier = Modifier.fillMaxSize().background(Color.Black).statusBarsPadding(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text("My SingularityTV", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                IconButton(onClick = onOpenSettings) { Icon(Icons.Default.Menu, contentDescription = "Settings", tint = Color.White) }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Box(Modifier.size(72.dp).clip(RoundedCornerShape(14.dp)).background(parseAccentColor(profile?.avatarColor ?: "E50914")), contentAlignment = Alignment.Center) {
                    Text((profile?.name ?: "S").take(1).uppercase(), color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.height(8.dp))
                Text(profile?.name ?: "Profile", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                session?.email?.let { Text(it, color = Color.Gray, fontSize = 12.sp) }
                Text("${myList.size} in My List · ${cw.size} in progress", color = Color.Gray, fontSize = 12.sp)
                Spacer(Modifier.height(10.dp))
                OutlinedButton(onClick = { sessionManager.switchToProfilePicker() }, shape = CircleShape) {
                    Text("Switch Profile", color = Color.White)
                }
            }
        }
        if (myList.isNotEmpty()) item { MediaRail("My List", myList.map { it.toMediaItem() }, accent, onOpenDetail) }
        if (liked.isNotEmpty()) item { MediaRail("Titles You've Rated", liked.map { it.toMediaItem() }, accent, onOpenDetail) }
        if (reminders.isNotEmpty()) item { MediaRail("Reminders", reminders.map { it.title.toMediaItem() }, accent, onOpenDetail) }
        if (history.isNotEmpty()) {
            item {
                Spacer(Modifier.height(20.dp))
                Text("Recently Watched", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    history.forEach { w ->
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(Color(0xFF141414)).clickable { onPlay(w) }.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            AsyncImage(model = w.posterUrl, contentDescription = w.title, contentScale = ContentScale.Crop, modifier = Modifier.width(44.dp).height(64.dp).clip(RoundedCornerShape(4.dp)))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(w.title, color = Color.White, fontWeight = FontWeight.SemiBold)
                                if (w.type == WatchType.TV) Text("S${w.season ?: 1} E${w.episode ?: 1}", color = Color.Gray, fontSize = 12.sp)
                            }
                            Icon(Icons.Default.PlayArrow, null, tint = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MobileDetailScreen(
    item: MediaItem,
    sessionManager: SessionManager,
    accent: Color,
    onOpenRelated: (MediaItem) -> Unit,
    onPlay: (WatchItem) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var payload by remember { mutableStateOf<TitleDetailPayload?>(null) }
    var selectedSeason by remember { mutableIntStateOf(1) }
    var episodes by remember { mutableStateOf<List<EpisodeSummary>>(emptyList()) }
    var activeTab by remember { mutableIntStateOf(if (item.isMovie) 1 else 0) }
    var overviewExpanded by remember { mutableStateOf(false) }
    var showDeniedDialog by remember { mutableStateOf(false) }
    var pendingReminder by remember { mutableStateOf<Pair<MyListItem, Long>?>(null) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val pending = pendingReminder
        pendingReminder = null
        if (granted && pending != null) {
            sessionManager.toggleReminder(pending.first, pending.second, scheduleNotification = true)
        } else if (!granted) {
            showDeniedDialog = true
        }
    }

    LaunchedEffect(item.id, item.mediaType) {
        payload = TMDBApiClient.titleDetail(item.watchType, item.id)
        if (!item.isMovie) {
            selectedSeason = payload?.seasons?.firstOrNull { it.seasonNumber > 0 }?.seasonNumber ?: 1
            episodes = TMDBApiClient.seasonEpisodes(item.id, selectedSeason)
        }
    }

    LaunchedEffect(selectedSeason) {
        if (!item.isMovie) episodes = TMDBApiClient.seasonEpisodes(item.id, selectedSeason)
    }

    if (showDeniedDialog) {
        AlertDialog(
            onDismissRequest = { showDeniedDialog = false },
            title = { Text("Notifications are off") },
            text = { Text("Allow notifications for SingularityTV in Settings to get a reminder when titles come out.") },
            confirmButton = {
                TextButton(onClick = {
                    showDeniedDialog = false
                    context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null)))
                }) { Text("Open Settings") }
            },
            dismissButton = { TextButton(onClick = { showDeniedDialog = false }) { Text("Not Now") } }
        )
    }

    val savedEntry = MyListItem(item.watchType, item.id, item.displayTitle, item.posterPath, item.backdropPath, item.overview, item.displayYear)
    val inList = sessionManager.isInMyList(item.watchType, item.id)
    val liked = sessionManager.isLiked(item.watchType, item.id)
    val reminded = sessionManager.isReminded(item.watchType, item.id)
    val relDate = item.releaseDateParsed
    val trailer = payload?.videos?.results?.firstOrNull { it.isYouTube && it.type.equals("Trailer", true) }
        ?: payload?.videos?.results?.firstOrNull { it.isYouTube }
    val cast = payload?.credits?.cast?.take(18).orEmpty()
    val related = (payload?.recommendations?.results.orEmpty() + payload?.similar?.results.orEmpty())
        .map { if (it.mediaType != "movie" && it.mediaType != "tv") it.copy(mediaType = item.mediaType) else it }
        .distinctBy { "${it.mediaType}_${it.id}" }
        .filter { it.id != item.id && !it.posterPath.isNullOrBlank() }
        .take(18)
    val videos = payload?.videos?.results?.filter { it.isYouTube }?.take(12).orEmpty()
    val cert = payload?.usCertification(item.isMovie)
    val directorOrCreators = payload?.directorOrCreators(item.isMovie)

    LazyColumn(modifier = Modifier.fillMaxSize().background(Color.Black), contentPadding = PaddingValues(bottom = 36.dp)) {
        item {
            Box(modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)) {
                AsyncImage(model = item.backdropUrl ?: item.posterUrl, contentDescription = item.displayTitle, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                Box(
                    Modifier.fillMaxSize().background(
                        Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.35f), Color.Transparent, Color.Black.copy(alpha = 0.92f)))
                    )
                )
                IconButton(onClick = onBack, modifier = Modifier.statusBarsPadding().padding(12.dp).background(Color.Black.copy(alpha = 0.6f), CircleShape)) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
                }
                if (trailer?.watchUrl != null) {
                    Surface(
                        color = Color.Black.copy(alpha = 0.62f),
                        shape = CircleShape,
                        modifier = Modifier.align(Alignment.BottomStart).padding(12.dp).clickable {
                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(trailer.watchUrl)))
                        }
                    ) {
                        Row(Modifier.padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(14.dp))
                            Text("Preview", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }
        item {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                Text(item.displayTitle, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
                val origTitle = if (item.isMovie) payload?.originalTitle else payload?.originalName
                if (!origTitle.isNullOrBlank() && origTitle != item.displayTitle) {
                    Text(origTitle, color = Color.Gray, fontSize = 13.sp)
                }
                payload?.tagline?.takeIf { it.isNotBlank() }?.let {
                    Spacer(Modifier.height(4.dp))
                    Text(it, color = Color(0xFFB8B8B8), fontSize = 13.sp, fontWeight = FontWeight.Medium)
                }
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    item.matchPercent?.let { Text("$it% Match", color = Color(0xFF45D478), fontSize = 13.sp, fontWeight = FontWeight.Bold) }
                    item.displayYear?.let { Text(it, color = Color(0xFFB8B8B8), fontSize = 13.sp) }
                    cert?.let {
                        Surface(border = BorderStroke(1.dp, Color.Gray), color = Color.Transparent, shape = RoundedCornerShape(3.dp)) {
                            Text(it, color = Color(0xFFB8B8B8), fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp))
                        }
                    }
                    if (item.isMovie) {
                        payload?.runtime?.takeIf { it > 0 }?.let { Text("${it / 60}h ${it % 60}m", color = Color(0xFFB8B8B8), fontSize = 13.sp) }
                    } else {
                        payload?.numberOfSeasons?.let { Text("$it ${if (it == 1) "Season" else "Seasons"}", color = Color(0xFFB8B8B8), fontSize = 13.sp) }
                    }
                    payload?.status?.takeIf { it.isNotBlank() }?.let {
                        Text("• $it", color = Color(0xFF888888), fontSize = 12.sp)
                    }
                }
                val genresList = payload?.genres?.map { it.name }?.take(4).orEmpty().ifEmpty { item.genreTags }
                if (genresList.isNotEmpty()) {
                    Spacer(Modifier.height(6.dp))
                    Text(genresList.joinToString("  •  "), color = Color(0xFFB8B8B8), fontSize = 12.sp)
                }
                if (item.isArabicOrGulfContent) {
                    Spacer(Modifier.height(10.dp))
                    Surface(color = Color.White.copy(alpha = 0.1f), shape = RoundedCornerShape(8.dp)) {
                        Text("Arabic/Gulf titles may have limited availability on external servers.", color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.padding(10.dp))
                    }
                }
                Spacer(Modifier.height(14.dp))
                if (item.isUpcoming && relDate != null) {
                    Text(SingularityDateHelper.comingLabel(relDate, item.isMovie), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = {
                            val res = sessionManager.toggleReminder(savedEntry, relDate.time, scheduleNotification = true)
                            if (res == ReminderResult.NOTIFICATIONS_DENIED && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                pendingReminder = savedEntry to relDate.time
                                permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                        modifier = Modifier.fillMaxWidth().height(46.dp),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Icon(if (reminded) Icons.Default.Notifications else Icons.Default.NotificationsNone, null)
                        Spacer(Modifier.width(6.dp))
                        Text(if (reminded) "Reminder Set" else "Remind Me", fontWeight = FontWeight.Bold)
                    }
                } else {
                    Button(
                        onClick = {
                            onPlay(WatchItem(id = "${item.watchType.rawValue}_${item.id}", type = item.watchType, title = item.displayTitle, tmdbId = item.id.toString(), season = if (item.isMovie) null else selectedSeason, episode = if (item.isMovie) null else 1, posterPath = item.posterPath, generatedURL = StreamingProviderBuilder.buildUrl(item.watchType, item.id, selectedSeason, 1)))
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                        modifier = Modifier.fillMaxWidth().height(46.dp),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Play", fontWeight = FontWeight.Bold)
                    }
                }
                if (trailer?.watchUrl != null) {
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(trailer.watchUrl))) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.White.copy(alpha = 0.18f), contentColor = Color.White),
                        modifier = Modifier.fillMaxWidth().height(44.dp),
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, null)
                        Spacer(Modifier.width(6.dp))
                        Text("Trailer", fontWeight = FontWeight.SemiBold)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Text(
                    item.overview,
                    color = Color.White,
                    fontSize = 14.sp,
                    lineHeight = 20.sp,
                    maxLines = if (overviewExpanded) Int.MAX_VALUE else 4,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.clickable { overviewExpanded = !overviewExpanded }
                )
                if (cast.isNotEmpty()) {
                    Spacer(Modifier.height(8.dp))
                    Text("Starring: ${cast.take(4).joinToString(", ") { it.name }}", color = Color(0xFFB8B8B8), fontSize = 12.sp)
                }
                directorOrCreators?.let {
                    Spacer(Modifier.height(3.dp))
                    Text("${if (item.isMovie) "Director" else "Creators"}: $it", color = Color(0xFFB8B8B8), fontSize = 12.sp)
                }
                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { sessionManager.toggleMyList(savedEntry) }) {
                        Icon(if (inList) Icons.Default.Check else Icons.Default.Add, null, tint = Color.White)
                        Text("My List", color = Color.Gray, fontSize = 12.sp)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable { sessionManager.toggleLike(savedEntry) }) {
                        Icon(if (liked) Icons.Default.ThumbUp else Icons.Default.ThumbUpOffAlt, null, tint = if (liked) accent else Color.White)
                        Text(if (liked) "Rated" else "Rate", color = Color.Gray, fontSize = 12.sp)
                    }
                    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.clickable {
                        val sendIntent = Intent(Intent.ACTION_SEND).apply {
                            putExtra(Intent.EXTRA_TEXT, "Watch ${item.displayTitle} on SingularityTV https://www.themoviedb.org/${item.mediaType}/${item.id}")
                            type = "text/plain"
                        }
                        context.startActivity(Intent.createChooser(sendIntent, null))
                    }) {
                        Icon(Icons.Default.Share, null, tint = Color.White)
                        Text("Share", color = Color.Gray, fontSize = 12.sp)
                    }
                }
            }
        }
        if (cast.isNotEmpty()) {
            item {
                Spacer(Modifier.height(10.dp))
                Text("Cast & Crew", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp))
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(cast, key = { it.id }) { person ->
                        Column(modifier = Modifier.width(86.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            AsyncImage(
                                model = person.profileUrl,
                                contentDescription = person.name,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.size(72.dp).clip(CircleShape).background(Color(0xFF2B2B2B))
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(person.name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            person.character?.takeIf { it.isNotBlank() }?.let {
                                Text(it, color = Color.Gray, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                }
            }
        }
        item {
            Spacer(Modifier.height(16.dp))
            HorizontalDivider(color = Color.White.copy(alpha = 0.12f))
            Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(22.dp)) {
                val tabs = buildList {
                    if (!item.isMovie) add(0 to "Episodes")
                    add(1 to "More Like This")
                    if (videos.isNotEmpty()) add(2 to "Trailers & More")
                }
                tabs.forEach { (tabId, label) ->
                    Column(modifier = Modifier.clickable { activeTab = tabId }) {
                        Box(Modifier.width(72.dp).height(3.dp).background(if (activeTab == tabId) accent else Color.Transparent))
                        Spacer(Modifier.height(8.dp))
                        Text(label, color = if (activeTab == tabId) Color.White else Color.Gray, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
        if (activeTab == 0 && !item.isMovie) {
            val seasons = payload?.seasons?.filter { it.seasonNumber > 0 }.orEmpty()
            if (seasons.isNotEmpty()) {
                item {
                    LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(seasons) { s ->
                            FilterChip(
                                selected = selectedSeason == s.seasonNumber,
                                onClick = { selectedSeason = s.seasonNumber },
                                label = { Text(s.name.ifBlank { "Season ${s.seasonNumber}" }) },
                                colors = FilterChipDefaults.filterChipColors(selectedContainerColor = accent, selectedLabelColor = Color.White)
                            )
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
            items(episodes, key = { it.id }) { ep ->
                val aired = ep.hasAired
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .alpha(if (aired) 1f else 0.55f)
                        .clickable(enabled = aired) {
                            onPlay(WatchItem(id = "tv_${item.id}_s${selectedSeason}_e${ep.episodeNumber}", type = WatchType.TV, title = item.displayTitle, tmdbId = item.id.toString(), season = selectedSeason, episode = ep.episodeNumber, episodeName = ep.name, posterPath = item.posterPath, generatedURL = StreamingProviderBuilder.buildUrl(WatchType.TV, item.id, selectedSeason, ep.episodeNumber)))
                        }
                        .padding(horizontal = 16.dp, vertical = 10.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.width(132.dp).height(74.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFF1C1C1C))) {
                            AsyncImage(model = ep.stillUrl ?: item.backdropUrl, contentDescription = ep.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                            if (aired) {
                                Box(Modifier.align(Alignment.Center).size(32.dp).background(Color.Black.copy(alpha = 0.55f), CircleShape), contentAlignment = Alignment.Center) {
                                    Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("${ep.episodeNumber}. ${ep.name.ifBlank { "Episode ${ep.episodeNumber}" }}", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 2)
                            val sub = if (!aired && !ep.airDate.isNullOrBlank()) "Coming ${ep.airDate}" else (ep.runtime?.let { "${it}m" } ?: "")
                            if (sub.isNotBlank()) Text(sub, color = Color.Gray, fontSize = 12.sp)
                        }
                    }
                    if (ep.overview.isNotBlank()) {
                        Spacer(Modifier.height(6.dp))
                        Text(ep.overview, color = Color(0xFFB8B8B8), fontSize = 12.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        } else if (activeTab == 1) {
            items(related.chunked(3)) { rowItems ->
                Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    rowItems.forEach { rel ->
                        Box(modifier = Modifier.weight(1f)) {
                            PosterCardMobile(rel, accent, onClick = onOpenRelated)
                        }
                    }
                    repeat(3 - rowItems.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        } else if (activeTab == 2) {
            items(videos, key = { it.id }) { vid ->
                Column(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp).clickable {
                        vid.watchUrl?.let { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it))) }
                    }
                ) {
                    Box(modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f).clip(RoundedCornerShape(8.dp)).background(Color(0xFF1C1C1C))) {
                        AsyncImage(model = vid.thumbnailUrl, contentDescription = vid.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                        Box(Modifier.align(Alignment.Center).size(44.dp).background(Color.Black.copy(alpha = 0.6f), CircleShape), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.PlayArrow, null, tint = Color.White)
                        }
                    }
                    Spacer(Modifier.height(6.dp))
                    Text(vid.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text(vid.type, color = Color.Gray, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun MobileSettingsScreen(sessionManager: SessionManager, accent: Color, onBack: () -> Unit) {
    val settings by sessionManager.appSettings.collectAsState()
    val webPrefs by sessionManager.webPlayerPrefs.collectAsState()
    val profile by sessionManager.activeProfile.collectAsState()
    val session by sessionManager.session.collectAsState()

    var serverHost by remember(settings.streamingProviderBaseURL) { mutableStateOf(settings.streamingProviderBaseURL) }
    var customTmdb by remember(settings.customTmdbToken) { mutableStateOf(settings.customTmdbToken) }
    var cacheSize by remember { mutableStateOf(sessionManager.cacheSizeMb()) }
    var confirmClearHistory by remember { mutableStateOf(false) }
    var confirmClearCache by remember { mutableStateOf(false) }
    var confirmSignOut by remember { mutableStateOf(false) }
    var updateMsg by remember { mutableStateOf<String?>(null) }

    Scaffold(
        containerColor = Color.Black,
        topBar = {
            Row(Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 8.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White) }
                Text("Settings", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
        }
    ) { pad ->
        LazyColumn(modifier = Modifier.fillMaxSize().padding(pad), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            item {
                SettingsCard("Account & Profiles") {
                    Text(profile?.name ?: "Profile", color = Color.White, fontWeight = FontWeight.Bold)
                    session?.email?.let { Text(it, color = Color.Gray, fontSize = 12.sp) }
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = { onBack(); sessionManager.switchToProfilePicker() }, modifier = Modifier.fillMaxWidth()) {
                        Text("Switch / Manage Profiles", color = Color.White)
                    }
                    OutlinedButton(onClick = { confirmSignOut = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Sign Out", color = accent)
                    }
                }
            }
            item {
                SettingsCard("Player & Audio Server") {
                    OutlinedTextField(value = serverHost, onValueChange = { serverHost = it }, label = { Text("Streaming Host (e.g. vidly.pro)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { sessionManager.updateAppSettings { it.copy(streamingProviderBaseURL = serverHost) } }, colors = ButtonDefaults.buttonColors(containerColor = accent)) {
                        Text("Save Server")
                    }
                }
            }
            item {
                SettingsCard("Web Player Defaults") {
                    Text("Preferred Quality: ${webPrefs.preferredQuality}", color = Color.LightGray, fontSize = 13.sp)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 6.dp)) {
                        items(listOf("Auto", "1080p", "720p", "480p")) { q ->
                            FilterChip(selected = webPrefs.preferredQuality == q, onClick = { sessionManager.updateWebPlayerPrefs { it.copy(preferredQuality = q) } }, label = { Text(q) })
                        }
                    }
                    Text("Subtitle Language: ${webPrefs.subtitleLanguage}", color = Color.LightGray, fontSize = 13.sp)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 6.dp)) {
                        items(listOf("Off", "Arabic", "English")) { s ->
                            FilterChip(selected = webPrefs.subtitleLanguage == s, onClick = { sessionManager.updateWebPlayerPrefs { it.copy(subtitleLanguage = s) } }, label = { Text(s) })
                        }
                    }
                }
            }
            item {
                SettingsCard("Haptic Feedback") {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Haptic Feedback", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Switch(checked = settings.hapticsEnabled, onCheckedChange = { v -> sessionManager.updateAppSettings { it.copy(hapticsEnabled = v) } }, colors = SwitchDefaults.colors(checkedTrackColor = accent))
                    }
                }
            }
            item {
                SettingsCard("Accent Color") {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(SingularityAccentPalette.presets) { opt ->
                            val sel = settings.accentColorHex.equals(opt.hex, ignoreCase = true)
                            Box(
                                modifier = Modifier.size(42.dp).clip(CircleShape).background(parseAccentColor(opt.hex)).border(if (sel) 2.5.dp else 1.dp, if (sel) Color.White else Color.Gray, CircleShape).clickable {
                                    sessionManager.updateAppSettings { it.copy(accentColorHex = opt.hex) }
                                },
                                contentAlignment = Alignment.Center
                            ) {
                                if (sel) Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }
            item {
                SettingsCard("TMDB API Key") {
                    OutlinedTextField(value = customTmdb, onValueChange = { customTmdb = it }, label = { Text("Custom TMDB Read Token (Optional)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { sessionManager.updateAppSettings { it.copy(customTmdbToken = customTmdb) } }, colors = ButtonDefaults.buttonColors(containerColor = accent)) { Text("Save Key") }
                        OutlinedButton(onClick = { customTmdb = ""; sessionManager.updateAppSettings { it.copy(customTmdbToken = "") } }) { Text("Reset Default", color = Color.White) }
                    }
                }
            }
            item {
                SettingsCard("Updates") {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("Automatic update checks", color = Color.White)
                        Switch(checked = settings.automaticUpdateChecksEnabled, onCheckedChange = { v -> sessionManager.updateAppSettings { it.copy(automaticUpdateChecksEnabled = v) } }, colors = SwitchDefaults.colors(checkedTrackColor = accent))
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedButton(onClick = { updateMsg = "You're on the latest version (v${SingularityConfig.APP_VERSION})." }, modifier = Modifier.fillMaxWidth()) {
                        Text("Check for Updates Now", color = Color.White)
                    }
                    updateMsg?.let { Text(it, color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
                }
            }
            item {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = { confirmClearHistory = true }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Delete, null, tint = accent)
                        Text(" Delete History", color = accent)
                    }
                    OutlinedButton(onClick = { confirmClearCache = true }, modifier = Modifier.fillMaxWidth()) {
                        Text("Delete Cache ($cacheSize)", color = Color.White)
                    }
                }
            }
        }
    }

    if (confirmClearHistory) {
        AlertDialog(onDismissRequest = { confirmClearHistory = false }, title = { Text("Delete watch history?") }, confirmButton = { Button(onClick = { sessionManager.clearHistory(); confirmClearHistory = false }, colors = ButtonDefaults.buttonColors(containerColor = accent)) { Text("Delete") } }, dismissButton = { TextButton(onClick = { confirmClearHistory = false }) { Text("Cancel") } })
    }
    if (confirmClearCache) {
        AlertDialog(onDismissRequest = { confirmClearCache = false }, title = { Text("Delete cache?") }, confirmButton = { Button(onClick = { sessionManager.clearCache(); cacheSize = sessionManager.cacheSizeMb(); confirmClearCache = false }, colors = ButtonDefaults.buttonColors(containerColor = accent)) { Text("Delete") } }, dismissButton = { TextButton(onClick = { confirmClearCache = false }) { Text("Cancel") } })
    }
    if (confirmSignOut) {
        AlertDialog(onDismissRequest = { confirmSignOut = false }, title = { Text("Sign out?") }, confirmButton = { Button(onClick = { confirmSignOut = false; onBack(); sessionManager.signOut() }, colors = ButtonDefaults.buttonColors(containerColor = accent)) { Text("Sign Out") } }, dismissButton = { TextButton(onClick = { confirmSignOut = false }) { Text("Cancel") } })
    }
}

@Composable
private fun SettingsCard(title: String, content: @Composable () -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFF141414)).border(1.dp, Color.White.copy(alpha = 0.08f), RoundedCornerShape(16.dp)).padding(16.dp)
    ) {
        Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        content()
    }
}
