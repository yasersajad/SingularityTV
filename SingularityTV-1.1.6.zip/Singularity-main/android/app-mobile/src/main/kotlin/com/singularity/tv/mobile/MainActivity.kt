package com.singularity.tv.mobile

import android.content.pm.ActivityInfo
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.singularity.tv.core.data.GateStage
import com.singularity.tv.core.data.SessionManager
import com.singularity.tv.core.model.ContinueWatchingItem
import com.singularity.tv.core.model.MediaItem
import com.singularity.tv.core.model.MyListItem
import com.singularity.tv.core.model.UserProfile
import com.singularity.tv.core.model.WatchItem
import com.singularity.tv.core.model.WatchType
import com.singularity.tv.core.network.SingularityConfig
import com.singularity.tv.core.network.StreamingProviderBuilder
import com.singularity.tv.core.network.TMDBApiClient
import com.singularity.tv.core.player.SingularityPlayerHost
import kotlinx.coroutines.launch

private val AccentRed = Color(0xFFE50914)
private val SurfaceDark = Color(0xFF141414)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val sessionManager = SessionManager.getInstance(applicationContext)
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = AccentRed,
                    background = Color.Black,
                    surface = SurfaceDark,
                    onBackground = Color.White,
                    onSurface = Color.White
                )
            ) {
                SingularityMobileRoot(sessionManager = sessionManager, activity = this)
            }
        }
    }
}

@Composable
private fun SingularityMobileRoot(sessionManager: SessionManager, activity: ComponentActivity) {
    val stage by sessionManager.stage.collectAsState()
    val isHydrating by sessionManager.isHydratingProfile.collectAsState()
    var activePlayerItem by remember { mutableStateOf<WatchItem?>(null) }
    var detailItem by remember { mutableStateOf<MediaItem?>(null) }

    if (activePlayerItem != null) {
        val item = activePlayerItem!!
        val prefs by sessionManager.webPlayerPrefs.collectAsState()
        DisposableEffect(Unit) {
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            onDispose { activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED }
        }
        SingularityPlayerHost(
            item = item,
            savedPrefs = prefs,
            onProgress = { ct, dur ->
                sessionManager.recordProgress(
                    type = item.type,
                    tmdbId = item.tmdbId,
                    title = item.title,
                    posterPath = item.posterPath,
                    season = item.season,
                    episode = item.episode,
                    episodeName = item.episodeName,
                    positionSeconds = ct,
                    durationSeconds = dur
                )
            },
            onPrefChanged = { key, value ->
                sessionManager.updateWebPlayerPrefs { cur ->
                    when (key) {
                        "preferredQuality" -> cur.copy(preferredQuality = value)
                        "subtitleLanguage" -> cur.copy(subtitleLanguage = value)
                        "playbackSpeed" -> cur.copy(playbackSpeed = value)
                        else -> cur
                    }
                }
            },
            onBack = { activePlayerItem = null }
        )
        return
    }

    if (detailItem != null) {
        MobileDetailScreen(
            item = detailItem!!,
            sessionManager = sessionManager,
            onPlay = { watchItem ->
                sessionManager.recordHistory(watchItem)
                activePlayerItem = watchItem
            },
            onBack = { detailItem = null }
        )
        return
    }

    when (stage) {
        GateStage.CHECKING_AUTH -> Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = AccentRed)
        }
        GateStage.AUTH_REQUIRED -> MobileAuthScreen(sessionManager)
        GateStage.TELEGRAM_REQUIRED -> MobileTelegramGateScreen(sessionManager)
        GateStage.PROFILE_SELECT -> MobileProfilesGateScreen(sessionManager, isHydrating)
        GateStage.READY -> MobileMainShell(
            sessionManager = sessionManager,
            onOpenDetail = { detailItem = it },
            onPlay = { watchItem ->
                sessionManager.recordHistory(watchItem)
                activePlayerItem = watchItem
            }
        )
    }
}

@Composable
private fun MobileAuthScreen(sessionManager: SessionManager) {
    val scope = rememberCoroutineScope()
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var isSignUp by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier.fillMaxSize().background(Color.Black).padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("SingularityTV", color = AccentRed, fontSize = 32.sp, fontWeight = FontWeight.Black)
        Spacer(Modifier.height(24.dp))
        if (isSignUp) {
            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
        }
        OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth())
        error?.let {
            Spacer(Modifier.height(10.dp))
            Text(it, color = AccentRed, fontSize = 13.sp)
        }
        Spacer(Modifier.height(20.dp))
        Button(
            onClick = {
                busy = true
                error = null
                scope.launch {
                    val res = if (isSignUp) sessionManager.signUp(email.trim(), password, name.trim()) else sessionManager.signIn(email.trim(), password)
                    busy = false
                    res.onFailure { error = it.message }
                }
            },
            enabled = !busy,
            colors = ButtonDefaults.buttonColors(containerColor = AccentRed),
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) {
            if (busy) CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp))
            else Text(if (isSignUp) "Create Account" else "Sign In", color = Color.White, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(12.dp))
        OutlinedButton(onClick = { isSignUp = !isSignUp }, modifier = Modifier.fillMaxWidth()) {
            Text(if (isSignUp) "Already have an account? Sign In" else "New to SingularityTV? Sign Up", color = Color.White)
        }
    }
}

@Composable
private fun MobileTelegramGateScreen(sessionManager: SessionManager) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    Column(
        modifier = Modifier.fillMaxSize().background(Color.Black).padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Telegram Verification", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        Text("Link your account via @${SingularityConfig.TELEGRAM_BOT_USERNAME} and join our channel to unlock streaming.", color = Color.Gray, fontSize = 14.sp)
        Spacer(Modifier.height(24.dp))
        Button(
            onClick = {
                busy = true
                scope.launch {
                    sessionManager.recheckTelegramGate()
                    busy = false
                }
            },
            enabled = !busy,
            colors = ButtonDefaults.buttonColors(containerColor = AccentRed),
            modifier = Modifier.fillMaxWidth().height(48.dp)
        ) {
            Text(if (busy) "Checking..." else "Verify Membership", color = Color.White, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun MobileProfilesGateScreen(sessionManager: SessionManager, isHydrating: Boolean) {
    val profiles by sessionManager.profiles.collectAsState()
    var selectedName by remember { mutableStateOf<String?>(null) }

    Box(modifier = Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(24.dp)) {
            Text("Who's Watching?", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(28.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
                profiles.forEach { profile ->
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier.clickable(enabled = !isHydrating) {
                            selectedName = profile.name
                            sessionManager.selectProfile(profile)
                        }
                    ) {
                        Box(
                            modifier = Modifier.size(84.dp).clip(RoundedCornerShape(14.dp)).background(AccentRed),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(profile.name.take(1).uppercase(), color = Color.White, fontSize = 32.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(Modifier.height(8.dp))
                        Text(profile.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }
        if (isHydrating) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.8f)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    CircularProgressIndicator(color = Color.White)
                    Text("Loading ${selectedName ?: "profile"}...", color = Color.White.copy(alpha = 0.85f), fontSize = 14.sp)
                }
            }
        }
    }
}

@Composable
private fun MobileMainShell(
    sessionManager: SessionManager,
    onOpenDetail: (MediaItem) -> Unit,
    onPlay: (WatchItem) -> Unit
) {
    var tab by remember { mutableStateOf(0) }
    Scaffold(
        containerColor = Color.Black,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF0D0D0D)) {
                NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
                NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.Whatshot, null) }, label = { Text("New & Hot") })
                NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Search, null) }, label = { Text("Search") })
                NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("My Singularity") })
            }
        }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            when (tab) {
                0 -> MobileHomeTab(sessionManager, onOpenDetail, onPlay)
                1 -> MobileNewHotTab(onOpenDetail)
                2 -> MobileSearchTab(onOpenDetail)
                3 -> MobileMySingularityTab(sessionManager, onOpenDetail)
            }
        }
    }
}

@Composable
private fun MobileHomeTab(
    sessionManager: SessionManager,
    onOpenDetail: (MediaItem) -> Unit,
    onPlay: (WatchItem) -> Unit
) {
    var trending by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var movies by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var series by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    val cw by sessionManager.continueWatching.collectAsState()
    val myList by sessionManager.myList.collectAsState()

    LaunchedEffect(Unit) {
        trending = TMDBApiClient.trendingAll()
        movies = TMDBApiClient.popularMovies()
        series = TMDBApiClient.popularSeries()
    }

    LazyColumn(modifier = Modifier.fillMaxSize().background(Color.Black), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("SingularityTV", color = AccentRed, fontSize = 22.sp, fontWeight = FontWeight.Black)
            }
        }
        trending.firstOrNull()?.let { hero ->
            item {
                Box(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(340.dp).clip(RoundedCornerShape(14.dp)).clickable { onOpenDetail(hero) }
                ) {
                    AsyncImage(model = hero.posterUrl, contentDescription = hero.displayTitle, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.88f)))))
                    Column(modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(hero.displayTitle, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = {
                                    onPlay(
                                        WatchItem(
                                            id = "${hero.watchType.rawValue}_${hero.id}",
                                            type = hero.watchType,
                                            title = hero.displayTitle,
                                            tmdbId = hero.id.toString(),
                                            season = if (hero.isMovie) null else 1,
                                            episode = if (hero.isMovie) null else 1,
                                            posterPath = hero.posterPath,
                                            generatedURL = StreamingProviderBuilder.buildUrl(hero.watchType, hero.id, 1, 1)
                                        )
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black)
                            ) {
                                Icon(Icons.Default.PlayArrow, null)
                                Text("Play", fontWeight = FontWeight.Bold)
                            }
                            OutlinedButton(onClick = { sessionManager.toggleMyList(MyListItem(hero.watchType, hero.id, hero.displayTitle, hero.posterPath, hero.backdropPath, hero.overview, hero.displayYear)) }) {
                                Icon(if (sessionManager.isInMyList(hero.watchType, hero.id)) Icons.Default.Check else Icons.Default.Add, null, tint = Color.White)
                                Text(" My List", color = Color.White)
                            }
                        }
                    }
                }
            }
        }
        if (cw.isNotEmpty()) {
            item {
                Spacer(Modifier.height(18.dp))
                Text("Continue Watching", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(cw, key = { it.id }) { entry ->
                        ContinueCardMobile(entry = entry, onPlay = {
                            onPlay(
                                WatchItem(
                                    id = entry.id,
                                    type = entry.type,
                                    title = entry.title,
                                    tmdbId = entry.tmdbId,
                                    season = entry.season,
                                    episode = entry.episode,
                                    episodeName = entry.episodeName,
                                    posterPath = entry.posterPath,
                                    generatedURL = StreamingProviderBuilder.buildUrl(entry.type, entry.tmdbId.toIntOrNull() ?: 0, entry.season, entry.episode, entry.progressSeconds?.toInt())
                                )
                            )
                        }, onRemove = { sessionManager.removeContinueWatching(entry.type, entry.tmdbId) })
                    }
                }
            }
        }
        if (trending.isNotEmpty()) item { MediaRail("Trending Now", trending, onOpenDetail) }
        if (movies.isNotEmpty()) item { MediaRail("Popular Movies", movies, onOpenDetail) }
        if (series.isNotEmpty()) item { MediaRail("Popular Series", series, onOpenDetail) }
        if (myList.isNotEmpty()) item { MediaRail("My List", myList.map { it.toMediaItem() }, onOpenDetail) }
    }
}

@Composable
private fun ContinueCardMobile(entry: ContinueWatchingItem, onPlay: () -> Unit, onRemove: () -> Unit) {
    Column(modifier = Modifier.width(114.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFF1F1F1F))) {
        Box(modifier = Modifier.fillMaxWidth().height(162.dp).clickable(onClick = onPlay)) {
            AsyncImage(model = entry.posterUrl, contentDescription = entry.title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            Box(modifier = Modifier.size(42.dp).align(Alignment.Center).clip(CircleShape).background(Color.Black.copy(alpha = 0.55f)).border(1.5.dp, Color.White, CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Default.PlayArrow, null, tint = Color.White)
            }
            LinearProgressIndicator(progress = { (entry.progressFraction ?: 0.04).toFloat() }, color = AccentRed, trackColor = Color.White.copy(alpha = 0.25f), modifier = Modifier.fillMaxWidth().height(3.dp).align(Alignment.BottomCenter))
        }
        Row(modifier = Modifier.fillMaxWidth().height(32.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Icon(Icons.Default.Info, null, tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(16.dp))
            val sub = if (entry.type == WatchType.TV) "S${entry.season ?: 1}:E${entry.episode ?: 1}" else "${((entry.durationSeconds ?: 0.0) / 60).toInt()}m"
            Text(sub, color = Color.LightGray, fontSize = 10.sp, maxLines = 1)
            Icon(Icons.Default.Close, null, tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(16.dp).clickable(onClick = onRemove))
        }
    }
}

@Composable
private fun MediaRail(title: String, items: List<MediaItem>, onClick: (MediaItem) -> Unit) {
    Column {
        Spacer(Modifier.height(18.dp))
        Text(title, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(items, key = { "${it.mediaType}_${it.id}" }) { item ->
                PosterCardMobile(item, onClick)
            }
        }
    }
}

@Composable
private fun PosterCardMobile(item: MediaItem, onClick: (MediaItem) -> Unit) {
    Box(modifier = Modifier.width(112.dp).aspectRatio(0.67f).clip(RoundedCornerShape(6.dp)).clickable { onClick(item) }) {
        AsyncImage(model = item.posterUrl, contentDescription = item.displayTitle, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        if (item.isArabicOrGulfContent) {
            Row(
                modifier = Modifier.padding(4.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.7f)).padding(horizontal = 6.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(3.dp)
            ) {
                Icon(Icons.Default.ErrorOutline, null, tint = Color.White, modifier = Modifier.size(10.dp))
                Text("May Not Stream", color = Color.White, fontSize = 8.sp, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun MobileNewHotTab(onOpenDetail: (MediaItem) -> Unit) {
    var upcoming by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    LaunchedEffect(Unit) { upcoming = TMDBApiClient.upcomingMovies() }
    LazyVerticalGrid(columns = GridCells.Fixed(3), contentPadding = PaddingValues(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items(upcoming, key = { it.id }) { PosterCardMobile(it, onOpenDetail) }
    }
}

@Composable
private fun MobileSearchTab(onOpenDetail: (MediaItem) -> Unit) {
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    LaunchedEffect(query) {
        results = if (query.isBlank()) TMDBApiClient.trendingAll() else TMDBApiClient.searchMulti(query)
    }
    Column(modifier = Modifier.fillMaxSize().background(Color.Black).padding(16.dp)) {
        OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Search movies & series") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(3), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(results, key = { "${it.mediaType}_${it.id}" }) { PosterCardMobile(it, onOpenDetail) }
        }
    }
}

@Composable
private fun MobileMySingularityTab(sessionManager: SessionManager, onOpenDetail: (MediaItem) -> Unit) {
    val profile by sessionManager.activeProfile.collectAsState()
    val myList by sessionManager.myList.collectAsState()
    Column(modifier = Modifier.fillMaxSize().background(Color.Black).padding(16.dp)) {
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(profile?.name ?: "Profile", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { sessionManager.switchToProfilePicker() }) { Text("Switch Profile", color = Color.White) }
                OutlinedButton(onClick = { sessionManager.signOut() }) { Text("Sign Out", color = AccentRed) }
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("Version ${SingularityConfig.APP_VERSION}", color = Color.Gray, fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))
        Text("My List", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(10.dp))
        LazyVerticalGrid(columns = GridCells.Fixed(3), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(myList.map { it.toMediaItem() }, key = { "${it.mediaType}_${it.id}" }) { PosterCardMobile(it, onOpenDetail) }
        }
    }
}

@Composable
private fun MobileDetailScreen(item: MediaItem, sessionManager: SessionManager, onPlay: (WatchItem) -> Unit, onBack: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize().background(Color.Black)) {
        Box(modifier = Modifier.fillMaxWidth().height(260.dp)) {
            AsyncImage(model = item.backdropUrl ?: item.posterUrl, contentDescription = item.displayTitle, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            IconButton(onClick = onBack, modifier = Modifier.statusBarsPadding().padding(12.dp).background(Color.Black.copy(alpha = 0.6f), CircleShape)) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = Color.White)
            }
        }
        Column(modifier = Modifier.padding(16.dp)) {
            Text(item.displayTitle, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(item.displayYear.orEmpty(), color = Color.Gray, fontSize = 13.sp)
            if (item.isArabicOrGulfContent) {
                Spacer(Modifier.height(8.dp))
                Surface(color = Color.White.copy(alpha = 0.1f), shape = RoundedCornerShape(8.dp)) {
                    Text("Arabic/Gulf titles may have limited availability on external servers.", color = Color.LightGray, fontSize = 12.sp, modifier = Modifier.padding(10.dp))
                }
            }
            Spacer(Modifier.height(14.dp))
            Button(
                onClick = {
                    onPlay(
                        WatchItem(
                            id = "${item.watchType.rawValue}_${item.id}",
                            type = item.watchType,
                            title = item.displayTitle,
                            tmdbId = item.id.toString(),
                            season = if (item.isMovie) null else 1,
                            episode = if (item.isMovie) null else 1,
                            posterPath = item.posterPath,
                            generatedURL = StreamingProviderBuilder.buildUrl(item.watchType, item.id, 1, 1)
                        )
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Color.Black),
                modifier = Modifier.fillMaxWidth().height(46.dp)
            ) {
                Icon(Icons.Default.PlayArrow, null)
                Text("Play", fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(14.dp))
            Text(item.overview, color = Color.LightGray, fontSize = 14.sp, lineHeight = 20.sp)
        }
    }
}
