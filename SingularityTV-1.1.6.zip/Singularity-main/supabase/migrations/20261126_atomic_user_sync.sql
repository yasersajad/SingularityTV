-- Atomic row-locked helper functions for SingularityTV user_sync
-- Apply via Supabase SQL Editor or `supabase db push`

CREATE OR REPLACE FUNCTION public.singularity_upsert_progress(
  p_user_id uuid,
  p_email text,
  p_profile_id text,
  p_progress_key text,
  p_percent integer,
  p_position_sec integer,
  p_duration_sec integer,
  p_watched boolean,
  p_live_playback jsonb,
  p_server_now bigint
)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
DECLARE
  v_data jsonb;
  v_profiles jsonb;
  v_bucket jsonb;
  v_prev_ts bigint;
BEGIN
  SELECT data INTO v_data
  FROM public.user_sync
  WHERE user_id = p_user_id
  FOR UPDATE;

  IF v_data IS NULL THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Account sync record not found');
  END IF;

  v_profiles := COALESCE(v_data->'profiles', '[]'::jsonb);
  IF NOT EXISTS (
    SELECT 1 FROM jsonb_array_elements(v_profiles) elem
    WHERE elem->>'id' = p_profile_id
  ) THEN
    RETURN jsonb_build_object('ok', false, 'error', 'Profile not found');
  END IF;

  v_bucket := COALESCE(v_data->'profileData'->p_profile_id, '{}'::jsonb);
  v_prev_ts := COALESCE((v_bucket->'_progressTs'->>p_progress_key)::bigint, 0);

  IF p_server_now >= v_prev_ts THEN
    IF p_duration_sec > 0 OR p_watched THEN
      v_bucket := jsonb_set(v_bucket, ARRAY['progress', p_progress_key], to_jsonb(CASE WHEN p_watched THEN 100 ELSE p_percent END), true);
      v_bucket := jsonb_set(v_bucket, ARRAY['_progressTs', p_progress_key], to_jsonb(p_server_now), true);
      IF p_position_sec > 0 THEN
        v_bucket := jsonb_set(v_bucket, ARRAY['_dlTimes', 'dlTime_' || p_progress_key], to_jsonb(p_position_sec), true);
      END IF;
      IF p_watched THEN
        v_bucket := jsonb_set(v_bucket, ARRAY['watched', p_progress_key], 'true'::jsonb, true);
        v_bucket := jsonb_set(v_bucket, ARRAY['_watchedTs', p_progress_key], to_jsonb(p_server_now), true);
      END IF;
    END IF;
    v_bucket := jsonb_set(v_bucket, ARRAY['_livePlayback'], p_live_playback, true);
    v_data := jsonb_set(v_data, ARRAY['profileData', p_profile_id], v_bucket, true);

    UPDATE public.user_sync
    SET data = v_data, email = COALESCE(NULLIF(p_email, ''), email), updated_at = NOW()
    WHERE user_id = p_user_id;
  END IF;

  RETURN jsonb_build_object('ok', true, 'serverNow', p_server_now);
END;
$$;
