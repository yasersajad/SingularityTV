# SingularityTV 1.1.6 — Feature Parity Matrix (Master Reference: iOS)

| Feature / Screen | iOS (Master) | Android Mobile | Android TV | Windows Desktop | Status |
| :--- | :---: | :---: | :---: | :---: | :--- |
| Supabase Auth & Telegram Gate | Complete | Complete | Complete | Complete | Complete |
| Profiles Gate & Cloud Bucket Isolation | Complete | Complete | Complete | Complete | Complete |
| Home (Hero, Filter Chips, Categories, Top 10, Continue Watching) | Complete | Complete | Complete | Complete | Complete / Platform Adaptation |
| Arabic/Gulf `May Not Stream` Poster Badge | Complete | Complete | Complete | Complete | Complete |
| New & Hot (`Coming Soon`, `Everyone's Watching`, `Top 10`) | Complete | Complete | Complete | Complete | Complete |
| Search (`Top Searches` + Live Multi-Search) | Complete | Complete | Complete | Complete | Complete |
| Title Detail (Seasons, Episodes, My List, Rate/Like, Related) | Complete | Complete | Complete | Complete | Complete |
| My SingularityTV (Profile, List, Rated, Reminders, History) | Complete | Complete | Complete | Complete | Complete |
| Settings (Account, Server, Web Prefs, Haptics, Accent Color, TMDB Key, Updates, Clear History/Cache) | Complete | Complete | Complete | Complete | Complete |
| Canonical Shared Web Player (`Shared/WebPlayer/vidly-player.js`) | Complete | Complete | Complete | Complete | Complete |
| Brand App Icons & TV Banner (`AppIcon-Dark.png`) | Complete | Complete | Complete | Complete | Complete |
