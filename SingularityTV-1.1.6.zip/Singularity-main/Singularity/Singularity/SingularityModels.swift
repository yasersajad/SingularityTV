import Foundation
import SwiftUI

struct SupabaseUser: Codable, Equatable, Sendable {
    let id: String
    let email: String
    let name: String
}

struct SupabaseSession: Codable, Equatable, Sendable {
    let accessToken: String
    let refreshToken: String
    let expiresAtMs: Double
    let user: SupabaseUser

    nonisolated var isExpiringSoon: Bool {
        let nowMs = Date().timeIntervalSince1970 * 1000
        return nowMs >= (expiresAtMs - 120_000)
    }
}

struct UserProfile: Codable, Identifiable, Equatable, Hashable, Sendable {
    let id: String
    var name: String
    var avatarColor: String
    var isKids: Bool
    var createdAt: Double

    var isPrimary: Bool {
        id == "prof_main"
    }

    var initial: String {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        return String((trimmed.first ?? "S")).uppercased()
    }

    static let avatarPalette: [String] = [
        "#E50914",
        "#E6B86A",
        "#3B82F6",
        "#10B981",
        "#8B5CF6",
        "#EC4899",
        "#06B6D4"
    ]
}

extension UserProfile {
    @MainActor
    var color: Color {
        Color(hex: avatarColor.replacingOccurrences(of: "#", with: ""))
    }
}

struct AppReleaseInfo: Codable, Equatable, Sendable {
    let latestVersion: String
    let minRequiredVersion: String
    let forceUpdate: Bool
    let changelog: String
    let channelUrl: String
    let updatePostUrl: String

    enum CodingKeys: String, CodingKey {
        case latestVersion = "latest_version"
        case minRequiredVersion = "min_required_version"
        case forceUpdate = "force_update"
        case changelog
        case channelUrl = "channel_url"
        case updatePostUrl = "update_post_url"
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        latestVersion = (try? c.decodeIfPresent(String.self, forKey: .latestVersion)) ?? ""
        minRequiredVersion = (try? c.decodeIfPresent(String.self, forKey: .minRequiredVersion)) ?? ""
        forceUpdate = (try? c.decodeIfPresent(Bool.self, forKey: .forceUpdate)) ?? false
        changelog = (try? c.decodeIfPresent(String.self, forKey: .changelog)) ?? ""
        channelUrl = (try? c.decodeIfPresent(String.self, forKey: .channelUrl)) ?? SingularityConfig.telegramChannelURL
        updatePostUrl = (try? c.decodeIfPresent(String.self, forKey: .updatePostUrl)) ?? SingularityConfig.telegramChannelURL
    }

    init(
        latestVersion: String,
        minRequiredVersion: String,
        forceUpdate: Bool,
        changelog: String,
        channelUrl: String,
        updatePostUrl: String
    ) {
        self.latestVersion = latestVersion
        self.minRequiredVersion = minRequiredVersion
        self.forceUpdate = forceUpdate
        self.changelog = changelog
        self.channelUrl = channelUrl
        self.updatePostUrl = updatePostUrl
    }
}

struct TelegramGateStatus: Equatable, Sendable {
    let member: Bool
    let linked: Bool
    let leftChannel: Bool
    let channelUrl: String
    let release: AppReleaseInfo?
    let needsMandatoryUpdate: Bool
    let hasOptionalUpdate: Bool
    let networkError: String?
}

enum SemanticVersion {
    static func compare(_ a: String, _ b: String) -> ComparisonResult {
        let pa = normalize(a)
        let pb = normalize(b)
        let len = max(pa.count, pb.count)
        for i in 0..<len {
            let x = i < pa.count ? pa[i] : 0
            let y = i < pb.count ? pb[i] : 0
            if x > y { return .orderedDescending }
            if x < y { return .orderedAscending }
        }
        return .orderedSame
    }

    static func isValid(_ version: String) -> Bool {
        let clean = version.trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "^[vV]", with: "", options: .regularExpression)
        guard !clean.isEmpty else { return false }
        let parts = clean.split(separator: ".")
        return !parts.isEmpty && parts.allSatisfy { Int($0) != nil }
    }

    private static func normalize(_ raw: String) -> [Int] {
        let cleaned = raw
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "^[vV]", with: "", options: .regularExpression)
        return cleaned
            .split(separator: ".")
            .map { part in
                let digits = part.prefix(while: \.isNumber)
                return Int(digits) ?? 0
            }
    }
}

enum AuthFlowError: LocalizedError, Sendable {
    case invalidEmail
    case weakPassword
    case invalidOTP
    case emailNotConfirmed
    case accountAlreadyExists
    case network(String)
    case server(String)

    var errorDescription: String? {
        switch self {
        case .invalidEmail:
            return "Please enter a valid email address."
        case .weakPassword:
            return "Password must be at least 6 characters."
        case .invalidOTP:
            return "Please enter the 6-digit verification code."
        case .emailNotConfirmed:
            return "Your email is not verified yet. Check your inbox for the 6-digit code."
        case .accountAlreadyExists:
            return "An account with this email already exists. Please sign in instead."
        case .network(let msg):
            return msg
        case .server(let msg):
            return msg
        }
    }
}
