import Foundation

enum SingularityConfig {
    static let appName = "SingularityTV"
    static let bundleIdentifier = "com.singularity.tv"
    static let developerHandle = "@ec1lz"
    static let developerTelegramURL = URL(string: "https://t.me/ec1lz")!

    nonisolated static let supabaseURL = "https://soufctreejgcpvqftxeb.supabase.co"
    static let supabaseRealtimeURL = "wss://soufctreejgcpvqftxeb.supabase.co/realtime/v1/websocket"
    nonisolated static let supabasePublishableKey = "sb_publishable_CRHhsCu1wvqdK7lUok8VfQ_IOBUqwJI"

    static let telegramBotUsername = "SingularityTV_Official_Bot"
    static let telegramChannelURL = "https://t.me/+IUpscNRqcqc4Y2Zk"

    static var currentAppVersion: String {
        let info = Bundle.main.infoDictionary
        if let short = info?["CFBundleShortVersionString"] as? String, !short.isEmpty {
            return short.trimmingCharacters(in: .whitespacesAndNewlines)
        }
        return "1.1.6"
    }
}
