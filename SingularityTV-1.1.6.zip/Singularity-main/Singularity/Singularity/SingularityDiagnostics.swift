import Foundation

@MainActor
final class SingularityDiagnostics {
    static let shared = SingularityDiagnostics()

    struct Entry: Codable, Identifiable {
        let id: UUID
        let timestamp: Date
        let category: String
        let message: String
        let operationID: String?
        let generationID: Int?
        let profileID: String?
        let screenID: String?
        let executorContext: String?
    }

    private(set) var entries: [Entry] = []
    private let maxEntries = 120
    private let storageKey = "singularity.diagnostics.log"

    private init() {
        if let data = UserDefaults.standard.data(forKey: storageKey),
           let decoded = try? JSONDecoder().decode([Entry].self, from: data) {
            entries = decoded
        }
    }

    func record(
        category: String,
        message: String,
        operationID: String? = nil,
        generationID: Int? = nil,
        profileID: String? = nil,
        screenID: String? = nil
    ) {
        let executor = Thread.isMainThread ? "MainActor" : "Background"
        let entry = Entry(
            id: UUID(),
            timestamp: Date(),
            category: category,
            message: message,
            operationID: operationID,
            generationID: generationID,
            profileID: profileID,
            screenID: screenID,
            executorContext: executor
        )
        entries.insert(entry, at: 0)
        if entries.count > maxEntries {
            entries = Array(entries.prefix(maxEntries))
        }
        if let data = try? JSONEncoder().encode(entries) {
            UserDefaults.standard.set(data, forKey: storageKey)
        }
        let formatter = ISO8601DateFormatter()
        let snapshot = entries.prefix(40)
            .map { e in
                let op = e.operationID.map { " op=\($0)" } ?? ""
                let gen = e.generationID.map { " gen=\($0)" } ?? ""
                let pid = e.profileID.map { " prof=\($0)" } ?? ""
                let exec = e.executorContext.map { " [\($0)]" } ?? ""
                return "[\(formatter.string(from: e.timestamp))]\(exec) [\(e.category)]\(op)\(gen)\(pid) \(e.message)"
            }
            .joined(separator: "\n")
        try? snapshot.write(to: SingularityCrashReporter.breadcrumbsFileURL, atomically: true, encoding: .utf8)
    }

    func record(sessionId: Int, provider: String, category: String, message: String) {
        let host = provider.isEmpty ? "unknown" : provider
        record(category: category, message: "[S\(sessionId) | \(host)] \(message)")
    }

    func clear() {
        entries = []
        UserDefaults.standard.removeObject(forKey: storageKey)
        try? FileManager.default.removeItem(at: SingularityCrashReporter.breadcrumbsFileURL)
    }

    func formattedReport() -> String {
        let formatter = ISO8601DateFormatter()
        return entries.map { e in
            let op = e.operationID.map { " op=\($0)" } ?? ""
            let gen = e.generationID.map { " gen=\($0)" } ?? ""
            let pid = e.profileID.map { " prof=\($0)" } ?? ""
            let exec = e.executorContext.map { " [\($0)]" } ?? ""
            return "[\(formatter.string(from: e.timestamp))]\(exec) [\(e.category)]\(op)\(gen)\(pid) \(e.message)"
        }.joined(separator: "\n")
    }
}
