import SwiftUI

struct NFRootView: View {
    enum Tab: String, CaseIterable, Identifiable {
        case home
        case newHot
        case my

        var id: String { rawValue }

        var title: String {
            switch self {
            case .home: return "Home"
            case .newHot: return "New & Hot"
            case .my: return "My SingularityTV"
            }
        }
    }

    @EnvironmentObject private var settings: AppSettingsManager
    @EnvironmentObject private var sessionManager: SingularitySessionManager
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    @State private var app = NFAppModel()
    @StateObject private var myList = MyListManager()

    @State private var selectedTab: Tab = .home
    @State private var visitedTabs: Set<Tab> = [.home]
    @State private var scrollToTopTokens: [Tab: Int] = [:]

    @State private var isShowingStartup = true

    var body: some View {
        ZStack {
            NF.canvas.ignoresSafeArea()

            switch sessionManager.stage {
            case .loading:
                loadingGateView
            case .auth:
                AuthGateView()
                    .transition(.opacity)
            case .mandatoryUpdate:
                if let rel = sessionManager.gateStatus?.release {
                    UpdateGateView(release: rel, isMandatory: true, onDismissOptional: nil)
                        .transition(.opacity)
                } else {
                    loadingGateView
                }
            case .telegramGate:
                TelegramGateView()
                    .transition(.opacity)
            case .syncError:
                syncErrorGateView
                    .transition(.opacity)
            case .profilePicker:
                ProfilesGateView(allowDismiss: false)
                    .transition(.opacity)
            case .ready:
                tabs
                    .safeAreaInset(edge: .bottom, spacing: 0) {
                        NFTabBar(selected: selectedTab, activeProfile: sessionManager.activeProfile, onSelect: select)
                    }
                    .nfRouterHost()
                    .transition(.opacity)
            }

            if sessionManager.stage == .ready, let picker = app.picker {
                NFPickerOverlay(request: picker) {
                    app.picker = nil
                }
                .id(picker.id)
                .zIndex(10)
            }

            if isShowingStartup && startupEnabled {
                NightflixStartupAnimationView(animationsEnabled: startupEnabled) {
                    finishStartup()
                }
                .ignoresSafeArea()
                .transition(.opacity)
                .zIndex(30)
            }
        }
        .environment(app)
        .environmentObject(myList)
        .ignoresSafeArea(.keyboard, edges: .bottom)
        .preferredColorScheme(.dark)
        .onAppear {
            sessionManager.attachManagers(
                myList: myList,
                history: app.history,
                continueWatching: app.continueWatching,
                library: app.library,
                settings: settings
            )
            if !startupEnabled {
                finishStartup()
            }
        }
        .task {
            await sessionManager.bootstrapIfNeeded()
        }
        .sheet(isPresented: $sessionManager.isShowingProfileSheet) {
            ProfilesGateView(allowDismiss: true)
                .environmentObject(sessionManager)
                .presentationBackground(Color.black)
        }
        .sheet(isPresented: $sessionManager.isShowingOptionalUpdate) {
            if let rel = sessionManager.optionalUpdate {
                UpdateGateView(release: rel, isMandatory: false) {
                    sessionManager.isShowingOptionalUpdate = false
                }
                .environmentObject(sessionManager)
                .presentationBackground(Color.black)
            }
        }
        .alert("Keep Local Watch Data?", isPresented: $sessionManager.isShowingLocalMergePrompt) {
            Button("Merge Local Data") {
                Task { await sessionManager.resolveLocalMerge(shouldMergeLocal: true) }
            }
            Button("Use Cloud Data Only", role: .destructive) {
                Task { await sessionManager.resolveLocalMerge(shouldMergeLocal: false) }
            }
        } message: {
            Text("We found existing local watch history and My List items on this device. Would you like to merge them into your SingularityTV account?")
        }
    }

    private var syncErrorGateView: some View {
        VStack(spacing: 18) {
            Image(systemName: "icloud.slash.fill")
                .font(.system(size: 42))
                .foregroundStyle(NightFlixStyle.accentColor)

            Text("Couldn't Load Saved Data")
                .font(.title3.weight(.bold))
                .foregroundStyle(.white)

            Text(sessionManager.syncPullError ?? "Please check your internet connection and retry.")
                .font(.footnote)
                .foregroundStyle(.white.opacity(0.72))
                .multilineTextAlignment(.center)
                .frame(maxWidth: 320)

            VStack(spacing: 10) {
                Button {
                    Task { await sessionManager.recheckGate() }
                } label: {
                    Text("Retry Sync")
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.white)
                        .frame(maxWidth: 240)
                        .padding(.vertical, 12)
                        .background(NightFlixStyle.accentColor, in: Capsule())
                }
                .buttonStyle(NFScaleButtonStyle())

                if sessionManager.hasLocalVaultProfiles {
                    Button {
                        sessionManager.continueOfflineWithLocalVault()
                    } label: {
                        Text("Use Local Profiles")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(.white)
                            .frame(maxWidth: 240)
                            .padding(.vertical, 11)
                            .background(Color.white.opacity(0.12), in: Capsule())
                    }
                    .buttonStyle(NFScaleButtonStyle())
                }

                Button("Sign Out") {
                    Task { await sessionManager.signOut() }
                }
                .font(.caption.weight(.semibold))
                .foregroundStyle(.white.opacity(0.6))
                .padding(.top, 4)
            }
        }
        .padding(24)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.black.ignoresSafeArea())
    }

    private var loadingGateView: some View {
        VStack(spacing: 18) {
            Text("S")
                .font(.system(size: 56, weight: .black, design: .rounded))
                .foregroundStyle(NightFlixStyle.accentColor)
            ProgressView()
                .tint(NightFlixStyle.accentColor)
            Text("Loading your account...")
                .font(.footnote.weight(.medium))
                .foregroundStyle(.white.opacity(0.65))
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.black.ignoresSafeArea())
    }

    // MARK: - Tabs

    private var tabs: some View {
        ZStack {
            ForEach(Tab.allCases) { tab in
                if visitedTabs.contains(tab) {
                    tabContent(tab)
                        .opacity(selectedTab == tab ? 1 : 0)
                        .allowsHitTesting(selectedTab == tab)
                        .accessibilityHidden(selectedTab != tab)
                        .zIndex(selectedTab == tab ? 1 : 0)
                }
            }
        }
    }

    @ViewBuilder
    private func tabContent(_ tab: Tab) -> some View {
        let token = scrollToTopTokens[tab, default: 0]

        switch tab {
        case .home:
            NFHomeView(scrollToTopToken: token)
        case .newHot:
            NFNewHotView(scrollToTopToken: token)
        case .my:
            NFMyNightflixView(scrollToTopToken: token)
        }
    }

    private func select(_ tab: Tab) {
        guard tab != selectedTab else {
            scrollToTopTokens[tab, default: 0] += 1
            return
        }

        HapticManager.shared.tabChange()
        visitedTabs.insert(tab)

        withAnimation(reduceMotion ? nil : .easeOut(duration: 0.16)) {
            selectedTab = tab
        }
    }

    // MARK: - Startup

    private var startupEnabled: Bool {
        settings.animationMode != .off && !reduceMotion && !settings.skipIntroAnimation
    }

    private func finishStartup() {
        guard isShowingStartup else { return }

        withAnimation(startupEnabled ? .easeOut(duration: 0.28) : nil) {
            isShowingStartup = false
        }
    }
}

// MARK: - Tab bar

private struct NFTabBar: View {
    let selected: NFRootView.Tab
    let activeProfile: UserProfile?
    let onSelect: (NFRootView.Tab) -> Void

    var body: some View {
        HStack(spacing: 0) {
            ForEach(NFRootView.Tab.allCases) { tab in
                Button {
                    onSelect(tab)
                } label: {
                    VStack(spacing: 4) {
                        icon(for: tab)
                            .frame(height: 26)

                        Text(tab.title)
                            .font(.system(size: 10.5, weight: .medium))
                            .lineLimit(1)
                    }
                    .foregroundStyle(selected == tab ? Color.white : Color(white: 0.55))
                    .frame(maxWidth: .infinity)
                    .contentShape(Rectangle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel(tab.title)
                .accessibilityAddTraits(selected == tab ? [.isSelected, .isButton] : .isButton)
            }
        }
        .padding(.top, 8)
        .padding(.bottom, 4)
        .background {
            ZStack {
                Rectangle().fill(.ultraThinMaterial)
                Color.black.opacity(0.72)
            }
            .ignoresSafeArea(edges: .bottom)
        }
        .overlay(alignment: .top) {
            Rectangle()
                .fill(Color.white.opacity(0.08))
                .frame(height: 0.5)
        }
    }

    @ViewBuilder
    private func icon(for tab: NFRootView.Tab) -> some View {
        let isSelected = selected == tab

        switch tab {
        case .home:
            Image(systemName: isSelected ? "house.fill" : "house")
                .font(.system(size: 21, weight: .regular))
        case .newHot:
            Image(systemName: isSelected ? "play.rectangle.on.rectangle.fill" : "play.rectangle.on.rectangle")
                .font(.system(size: 20, weight: .regular))
        case .my:
            NFProfileAvatar(size: 24, isSelected: isSelected, profile: activeProfile)
        }
    }
}
