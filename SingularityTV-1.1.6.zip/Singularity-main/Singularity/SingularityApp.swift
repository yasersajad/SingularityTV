import SwiftUI

@main
struct NightFlixApp: App {
    @UIApplicationDelegateAdaptor(NightflixAppDelegate.self) private var appDelegate
    @StateObject private var settings = AppSettingsManager()
    @StateObject private var sessionManager = SingularitySessionManager.shared

    init() {
        SingularityCrashReporter.install()
    }

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(settings)
                .environmentObject(sessionManager)
                .environment(\.nightflixAccent, settings.accentColor)
                .tint(settings.accentColor)
                .preferredColorScheme(.dark)
        }
    }
}
