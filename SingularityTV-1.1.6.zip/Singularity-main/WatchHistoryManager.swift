import Foundation
import Observation

@MainActor
@Observable
final class WatchHistoryManager {
    private(set) var items: [WatchItem] = []

    private let storageKey = "recentlyWatchedItems"
    private let maxItems = 12
    private let userDefaults: UserDefaults
    private let decoder = JSONDecoder()
    private let encoder = JSONEncoder()

    init(userDefaults: UserDefaults = .standard) {
        self.userDefaults = userDefaults
        reloadFromDefaults()
    }

    func add(_ item: WatchItem) {
        items.removeAll { existingItem in
            existingItem.type == item.type
                && existingItem.tmdbId == item.tmdbId
                && existingItem.season == item.season
                && existingItem.episode == item.episode
        }

        items.append(item)
        items.sort { $0.dateWatched < $1.dateWatched }
        if items.count > maxItems {
            items = Array(items.suffix(maxItems))
        }
        save()
    }

    func clear() {
        items = []
        userDefaults.removeObject(forKey: storageKey)
        Task { @MainActor in SingularitySessionManager.shared.notifyLocalDataChanged() }
    }

    func reloadFromDefaults() {
        guard let data = userDefaults.data(forKey: storageKey) else {
            items = []
            return
        }

        do {
            let decoded = try decoder.decode([WatchItem].self, from: data)
            items = decoded.sorted { $0.dateWatched < $1.dateWatched }
        } catch {
            items = []
            userDefaults.removeObject(forKey: storageKey)
        }
    }

    private func save() {
        do {
            let data = try encoder.encode(items)
            userDefaults.set(data, forKey: storageKey)
            Task { @MainActor in SingularitySessionManager.shared.notifyLocalDataChanged() }
        } catch {
            userDefaults.removeObject(forKey: storageKey)
        }
    }
}
