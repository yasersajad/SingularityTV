# SingularityTV 1.1.6 — Build, Verification & Android Launch Diagnosis Report

## 1. Android Mobile Disabled "Open" Button & Missing Launcher Icon — Root Cause & Fix
- **Root Causes Identified:**
  1. `android/app-mobile/build.gradle.kts` enabled `isMinifyEnabled = true` and `isShrinkResources = true` while `android/app-mobile/proguard-rules.pro` was missing from the repository, risking R8 / resource-shrinker stripping of classes, serializers, or launcher mipmap resources.
  2. `android/app-mobile/src/main/AndroidManifest.xml` declared `android:name=".MainActivity"` while `namespace = "com.singularity.tv.mobile"` differed from `applicationId = "com.singularity.tv"`.
  3. `.github/workflows/build-all.yml` did not verify the generated release APK's `launchable-activity` and `native-code` ABI with `aapt2`.
- **Fixes Implemented:**
  - Created `android/app-mobile/proguard-rules.pro` (and `android/app-tv/proguard-rules.pro`) preserving `MainActivity`, `TvMainActivity`, `ReminderReceiver`, `@JavascriptInterface`, and `kotlinx.serialization` models.
  - Created `android/app-mobile/src/main/res/raw/keep.xml` to protect `@mipmap/ic_launcher` and `@mipmap/ic_launcher_round` from resource shrinking.
  - Updated `android/app-mobile/src/main/AndroidManifest.xml` to explicitly declare `android:name="com.singularity.tv.mobile.MainActivity"` with `android:launchMode="singleTop"`, `android:exported="true"`, `MAIN`, and `LAUNCHER`.
  - Added `aapt2 dump badging` verification in `.github/workflows/build-all.yml` for both `arm64-v8a` and `armeabi-v7a` mobile APKs.

## 2. Verification Status
- **Verified Locally on Linux Sandbox:**
  - Static delimiter balance across all `.kt`, `.cs`, `.js`, `.css` files (`0` errors).
  - Strict XML/XAML/csproj parsing (`0` errors) and JSON validation (`0` errors).
  - Archive integrity via `zipfile.testzip()` (`None` / `0` corrupt entries).
- **Requires GitHub Actions & Physical Device / Emulator Execution (Not Available on Linux VM):**
  - Full compilation via `xcodebuild`, `gradle`, `dotnet publish`, and `iscc` (Inno Setup) in `.github/workflows/build-all.yml`.
  - On-device installation (`adb install`) and launcher/Open-button/D-pad/playback testing on Android Mobile, Android TV, iOS, and Windows Desktop.
