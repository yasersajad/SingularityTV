# SingularityTV 1.1.6 — Multi-Platform Build & Architecture Report

## 1. Platform Projects & Architecture
1. **iOS (`Singularity.xcodeproj`, `Singularity/`, `SingularityTests/`)**
   - Reference SwiftUI app preserved intact; version updated from `3.0.0` to `1.1.6`.
   - Outputs via `.github/workflows/build-ios.yml` (`macos-15`):
     - `SingularityTV-iOS-1.1.6.ipa`
     - `SingularityTV-iOS-1.1.6.tipa` (ad-hoc TrollStore signed via `ldid -Sentitlements.plist`)
2. **Android Mobile (`android/app-mobile`, `com.singularity.tv`, version `1.1.6`, `versionCode 10106`)**
   - Native Kotlin + Jetpack Compose + Material 3 + Media3 / Vidly WebView bridge.
   - Shared core modules: `:core:model`, `:core:network`, `:core:data`, `:core:player`.
   - ABI split APKs (`arm64-v8a`, `armeabi-v7a`) + release AAB via `.github/workflows/build-android-mobile.yml`.
   - Note on AAB: Android App Bundles (`.aab`) are multi-ABI distribution bundles by Google Play specification; individual ABI APKs are generated via `splits.abi`.
3. **Android TV (`android/app-tv`, `com.singularity.tv.tv`, version `1.1.6`, `versionCode 10106`)**
   - Native Kotlin + `androidx.tv.material3` (`LEANBACK_LAUNCHER`), D-pad focus navigation, wide TV hero & rails, and remote-friendly player.
   - ABI split APKs (`arm64-v8a`, `armeabi-v7a`) + release AAB via `.github/workflows/build-android-tv.yml`.
4. **Windows Desktop (`windows/SingularityTV.Desktop`, `.NET 8 + WinUI 3 + Windows App SDK 1.6`, version `1.1.6`)**
   - Native Fluent Dark Desktop app with `NavigationView`, PerMonitorV2 DPI scaling, keyboard shortcuts (`F` fullscreen, `Esc` back), and `WebView2` player with ad/tracker filtering and redirect blocking.
   - Self-contained Inno Setup installers (`windows/installer/SingularityTV.iss`) for `win-x64` (`SingularityTV-Desktop-1.1.6-Windows-x64.exe`) and `win-arm64` (`SingularityTV-Desktop-1.1.6-Windows-ARM64.exe`) via `.github/workflows/build-windows-x64.yml` and `.github/workflows/build-windows-arm64.yml`.

## 2. Shared Backend Consistency
- All 4 platforms connect to the same Supabase Auth, `telegram-gate` Edge Function, and TMDB v3 API.
- Preserves oldest-to-newest `My List` & `Watch History` ordering, `dismissedContinueWatching`, and per-profile `webPlayerPrefs`.

## 3. Verification & Environment Limitations
- **Verified locally (Linux VM):** Static syntax & delimiter checks across Swift, Kotlin, and C# files; ZIP archive integrity (`testzip`).
- **Requires GitHub Actions & Target Devices:** Compilation (`xcodebuild`, `gradle`, `dotnet publish`, `iscc`) and runtime/device QA on iPhone/iPad, Android Phone, Android TV, and Windows x64/ARM64 could not be executed locally on the Linux VM and must run via `.github/workflows/release-all.yml` or individual platform workflows.
