using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SingularityTV.Desktop.Services;

public static class SingularityConstants
{
    public const string AppName = "SingularityTV";
    public const string AppVersion = "1.1.6";
    public const string SupabaseUrl = "https://soufctreejgcpvqftxeb.supabase.co";
    public const string SupabaseKey = "sb_publishable_CRHhsCu1wvqdK7lUok8VfQ_IOBUqwJI";
    public const string TelegramBot = "SingularityTV_Official_Bot";
    public const string TelegramChannelUrl = "https://t.me/+IUpscNRqcqc4Y2Zk";
    public const string TmdbToken = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI3MTNlY2VkZmQ1NmVkNDZiMDBiZTg1N2Q3ODg3NTE1MSIsIm5iZiI6MTc3OTYyMzA4Mi4xNzUsInN1YiI6IjZhMTJlNGFhOWFkOWYxOWE3ZWE5Y2NiZiIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.8g0u3KwAVxnWszrKGfqvxrUl0VuG-_e0ZvTv5xDVRd4";
    public const string PrimaryStreamHost = "vidly.pro";

    public static readonly (string Name, string Hex)[] AccentPresets =
    {
        ("Singularity Red", "E50914"),
        ("Electric Blue", "0071EB"),
        ("Royal Purple", "7C3AED"),
        ("Emerald", "059669"),
        ("Amber Gold", "D97706"),
        ("Neon Pink", "DB2777"),
        ("Cyan", "0891B2"),
        ("Lime", "65A30D")
    };
}

public sealed class MediaItemDto
{
    [JsonPropertyName("id")] public int Id { get; set; }
    [JsonPropertyName("media_type")] public string MediaType { get; set; } = "movie";
    [JsonPropertyName("title")] public string? Title { get; set; }
    [JsonPropertyName("name")] public string? Name { get; set; }
    [JsonPropertyName("overview")] public string Overview { get; set; } = "";
    [JsonPropertyName("poster_path")] public string? PosterPath { get; set; }
    [JsonPropertyName("backdrop_path")] public string? BackdropPath { get; set; }
    [JsonPropertyName("release_date")] public string? ReleaseDate { get; set; }
    [JsonPropertyName("first_air_date")] public string? FirstAirDate { get; set; }
    [JsonPropertyName("vote_average")] public double? VoteAverage { get; set; }
    [JsonPropertyName("original_language")] public string? OriginalLanguage { get; set; }
    [JsonPropertyName("origin_country")] public List<string>? OriginCountry { get; set; }

    public bool IsMovie => MediaType == "movie";
    public string DisplayTitle => IsMovie ? (Title ?? Name ?? "Untitled") : (Name ?? Title ?? "Untitled");
    public string DisplayYear => ((IsMovie ? ReleaseDate : FirstAirDate) ?? "").Length >= 4 ? ((IsMovie ? ReleaseDate : FirstAirDate)!).Substring(0, 4) : "";
    public string PosterUrl => string.IsNullOrEmpty(PosterPath) ? "" : $"https://image.tmdb.org/t/p/w500{PosterPath}";
    public string BackdropUrl => string.IsNullOrEmpty(BackdropPath) ? PosterUrl : $"https://image.tmdb.org/t/p/w1280{BackdropPath}";

    public bool IsArabicOrGulfContent
    {
        get
        {
            if (string.Equals(OriginalLanguage, "ar", StringComparison.OrdinalIgnoreCase)) return true;
            var arab = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "SA", "AE", "KW", "QA", "BH", "OM", "EG", "LB", "SY", "JO", "IQ", "MA", "TN", "DZ", "YE", "SD", "LY", "PS" };
            if (OriginCountry != null && OriginCountry.Any(c => arab.Contains(c))) return true;
            return Regex.IsMatch($"{Title} {Name}", @"\p{IsArabic}");
        }
    }

    public string BuildStreamUrl(string host, string accentHex, int season = 1, int episode = 1)
    {
        var cleanHost = string.IsNullOrWhiteSpace(host) ? SingularityConstants.PrimaryStreamHost : host.Trim().Replace("https://", "").Replace("http://", "").Split('/')[0];
        var hex = accentHex.TrimStart('#').ToUpperInvariant();
        if (string.IsNullOrEmpty(hex)) hex = "E50914";
        return IsMovie
            ? $"https://{cleanHost}/embed/movie/{Id}?autoplay=true&color={hex}"
            : $"https://{cleanHost}/embed/tv/{Id}/{season}/{episode}?autoplay=true&color={hex}";
    }
}

public sealed class TmdbListResponse
{
    [JsonPropertyName("results")] public List<MediaItemDto> Results { get; set; } = new();
}

public sealed class EpisodeDto
{
    [JsonPropertyName("id")] public int Id { get; set; }
    [JsonPropertyName("episode_number")] public int EpisodeNumber { get; set; }
    [JsonPropertyName("name")] public string Name { get; set; } = "";
    [JsonPropertyName("overview")] public string Overview { get; set; } = "";
    [JsonPropertyName("still_path")] public string? StillPath { get; set; }
}

public sealed class SeasonResponseDto
{
    [JsonPropertyName("episodes")] public List<EpisodeDto> Episodes { get; set; } = new();
}

public sealed class UserProfileDto
{
    [JsonPropertyName("id")] public string Id { get; set; } = "prof_main";
    [JsonPropertyName("name")] public string Name { get; set; } = "Main";
    [JsonPropertyName("avatarColor")] public string AvatarColor { get; set; } = "#E50914";
}

public sealed class DesktopSession
{
    public string AccessToken { get; set; } = "";
    public string RefreshToken { get; set; } = "";
    public string UserId { get; set; } = "";
    public string Email { get; set; } = "";
    public string Name { get; set; } = "";
}

public sealed class WebPlayerPrefsDto
{
    [JsonPropertyName("preferredQuality")] public string PreferredQuality { get; set; } = "Auto";
    [JsonPropertyName("subtitleLanguage")] public string SubtitleLanguage { get; set; } = "Off";
    [JsonPropertyName("playbackSpeed")] public string PlaybackSpeed { get; set; } = "1";
}

public sealed class DesktopAppSettings
{
    public string AccentColorHex { get; set; } = "E50914";
    public string StreamingProviderBaseURL { get; set; } = "vidly.pro";
    public string CustomTmdbToken { get; set; } = "";
    public bool AutomaticUpdateChecks { get; set; } = true;
}

public sealed class DesktopBackendService
{
    private readonly HttpClient _http = new() { Timeout = TimeSpan.FromSeconds(20) };
    private readonly string _dataDir;
    private readonly string _sessionPath;
    private readonly string _settingsPath;

    public DesktopSession? Session { get; private set; }
    public List<UserProfileDto> Profiles { get; private set; } = new();
    public UserProfileDto? ActiveProfile { get; private set; }
    public WebPlayerPrefsDto PlayerPrefs { get; set; } = new();
    public DesktopAppSettings AppSettings { get; private set; } = new();
    public List<MediaItemDto> MyList { get; } = new();
    public List<MediaItemDto> Liked { get; } = new();
    public List<MediaItemDto> History { get; } = new();

    public DesktopBackendService()
    {
        _dataDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SingularityTV");
        Directory.CreateDirectory(_dataDir);
        _sessionPath = Path.Combine(_dataDir, "session.json");
        _settingsPath = Path.Combine(_dataDir, "settings.json");
        if (File.Exists(_sessionPath))
        {
            try { Session = JsonSerializer.Deserialize<DesktopSession>(File.ReadAllText(_sessionPath)); } catch { }
        }
        if (File.Exists(_settingsPath))
        {
            try { AppSettings = JsonSerializer.Deserialize<DesktopAppSettings>(File.ReadAllText(_settingsPath)) ?? new(); } catch { }
        }
    }

    public void SaveAppSettings()
    {
        File.WriteAllText(_settingsPath, JsonSerializer.Serialize(AppSettings));
        _ = PushActiveProfileAsync();
    }

    public async Task<(bool ok, string? error)> SignInAsync(string email, string password)
    {
        var body = JsonSerializer.Serialize(new { email, password });
        var req = new HttpRequestMessage(HttpMethod.Post, $"{SingularityConstants.SupabaseUrl}/auth/v1/token?grant_type=password");
        req.Headers.Add("apikey", SingularityConstants.SupabaseKey);
        req.Content = new StringContent(body, Encoding.UTF8, "application/json");
        var res = await _http.SendAsync(req);
        var txt = await res.Content.ReadAsStringAsync();
        if (!res.IsSuccessStatusCode) return (false, "Invalid email or password.");
        using var doc = JsonDocument.Parse(txt);
        var root = doc.RootElement;
        Session = new DesktopSession
        {
            AccessToken = root.GetProperty("access_token").GetString() ?? "",
            RefreshToken = root.TryGetProperty("refresh_token", out var rt) ? rt.GetString() ?? "" : "",
            UserId = root.GetProperty("user").GetProperty("id").GetString() ?? "",
            Email = email
        };
        File.WriteAllText(_sessionPath, JsonSerializer.Serialize(Session));
        return (true, null);
    }

    public void SignOut()
    {
        Session = null;
        ActiveProfile = null;
        Profiles.Clear();
        MyList.Clear();
        Liked.Clear();
        History.Clear();
        if (File.Exists(_sessionPath)) File.Delete(_sessionPath);
    }

    public async Task<bool> CheckTelegramGateAsync()
    {
        if (Session == null) return false;
        var req = new HttpRequestMessage(HttpMethod.Post, $"{SingularityConstants.SupabaseUrl}/functions/v1/telegram-gate");
        req.Headers.Add("apikey", SingularityConstants.SupabaseKey);
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", Session.AccessToken);
        req.Content = new StringContent("{\"action\":\"check\"}", Encoding.UTF8, "application/json");
        var res = await _http.SendAsync(req);
        if (!res.IsSuccessStatusCode) return false;
        using var doc = JsonDocument.Parse(await res.Content.ReadAsStringAsync());
        return doc.RootElement.TryGetProperty("member", out var m) && m.GetBoolean();
    }

    public async Task LoadProfilesAsync()
    {
        if (Session == null) return;
        var req = new HttpRequestMessage(HttpMethod.Get, $"{SingularityConstants.SupabaseUrl}/functions/v1/telegram-gate?action=sync_profile_pull");
        req.Headers.Add("apikey", SingularityConstants.SupabaseKey);
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", Session.AccessToken);
        var res = await _http.SendAsync(req);
        if (!res.IsSuccessStatusCode) return;
        using var doc = JsonDocument.Parse(await res.Content.ReadAsStringAsync());
        if (doc.RootElement.TryGetProperty("profiles", out var arr))
        {
            Profiles = JsonSerializer.Deserialize<List<UserProfileDto>>(arr.GetRawText()) ?? new();
        }
    }

    public async Task SelectProfileAsync(UserProfileDto profile)
    {
        ActiveProfile = profile;
        MyList.Clear();
        History.Clear();
        if (Session == null) return;
        var req = new HttpRequestMessage(HttpMethod.Get, $"{SingularityConstants.SupabaseUrl}/functions/v1/telegram-gate?action=sync_profile_pull&profileId={Uri.EscapeDataString(profile.Id)}");
        req.Headers.Add("apikey", SingularityConstants.SupabaseKey);
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", Session.AccessToken);
        var res = await _http.SendAsync(req);
        if (!res.IsSuccessStatusCode) return;
        using var doc = JsonDocument.Parse(await res.Content.ReadAsStringAsync());
        if (doc.RootElement.TryGetProperty("profileData", out var bucket))
        {
            if (bucket.TryGetProperty("webPlayerPrefs", out var wp))
            {
                PlayerPrefs = JsonSerializer.Deserialize<WebPlayerPrefsDto>(wp.GetRawText()) ?? new();
            }
            if (bucket.TryGetProperty("playerPrefs", out var pp))
            {
                if (pp.TryGetProperty("accentColorHex", out var ac) && !string.IsNullOrWhiteSpace(ac.GetString()))
                    AppSettings.AccentColorHex = ac.GetString()!;
                if (pp.TryGetProperty("streamingProviderBaseURL", out var sp) && !string.IsNullOrWhiteSpace(sp.GetString()))
                    AppSettings.StreamingProviderBaseURL = sp.GetString()!;
            }
            if (bucket.TryGetProperty("saved", out var saved) && saved.ValueKind == JsonValueKind.Object)
            {
                foreach (var prop in saved.EnumerateObject())
                {
                    var v = prop.Value;
                    MyList.Add(new MediaItemDto
                    {
                        Id = v.TryGetProperty("id", out var idEl) ? idEl.GetInt32() : 0,
                        MediaType = v.TryGetProperty("media_type", out var mtEl) ? mtEl.GetString() ?? "movie" : "movie",
                        Title = v.TryGetProperty("title", out var tEl) ? tEl.GetString() : null,
                        Name = v.TryGetProperty("title", out var nEl) ? nEl.GetString() : null,
                        PosterPath = v.TryGetProperty("poster_path", out var pEl) ? pEl.GetString() : null
                    });
                }
            }
        }
    }

    public async Task PushActiveProfileAsync()
    {
        if (Session == null || ActiveProfile == null) return;
        var savedObj = new JsonObject();
        var savedOrder = new JsonArray();
        foreach (var m in MyList)
        {
            var key = $"{m.MediaType}_{m.Id}";
            savedOrder.Add(key);
            savedObj[key] = new JsonObject
            {
                ["id"] = m.Id,
                ["media_type"] = m.MediaType,
                ["title"] = m.DisplayTitle,
                ["poster_path"] = m.PosterPath
            };
        }
        var bucket = new JsonObject
        {
            ["saved"] = savedObj,
            ["savedOrder"] = savedOrder,
            ["webPlayerPrefs"] = new JsonObject
            {
                ["preferredQuality"] = PlayerPrefs.PreferredQuality,
                ["subtitleLanguage"] = PlayerPrefs.SubtitleLanguage,
                ["playbackSpeed"] = PlayerPrefs.PlaybackSpeed
            },
            ["playerPrefs"] = new JsonObject
            {
                ["accentColorHex"] = AppSettings.AccentColorHex,
                ["streamingProviderBaseURL"] = AppSettings.StreamingProviderBaseURL
            },
            ["_playerPrefsTs"] = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
        };
        var payload = new JsonObject
        {
            ["schemaVersion"] = 2,
            ["profileData"] = new JsonObject { [ActiveProfile.Id] = bucket }
        };
        var req = new HttpRequestMessage(HttpMethod.Post, $"{SingularityConstants.SupabaseUrl}/functions/v1/telegram-gate?action=sync_push");
        req.Headers.Add("apikey", SingularityConstants.SupabaseKey);
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", Session.AccessToken);
        req.Content = new StringContent(payload.ToJsonString(), Encoding.UTF8, "application/json");
        try { await _http.SendAsync(req); } catch { }
    }

    public void ToggleMyList(MediaItemDto item)
    {
        var idx = MyList.FindIndex(x => x.Id == item.Id && x.MediaType == item.MediaType);
        if (idx >= 0) MyList.RemoveAt(idx); else MyList.Add(item);
        _ = PushActiveProfileAsync();
    }

    public void ToggleLike(MediaItemDto item)
    {
        var idx = Liked.FindIndex(x => x.Id == item.Id && x.MediaType == item.MediaType);
        if (idx >= 0) Liked.RemoveAt(idx); else Liked.Add(item);
    }

    private string ActiveTmdbToken() =>
        string.IsNullOrWhiteSpace(AppSettings.CustomTmdbToken) ? SingularityConstants.TmdbToken : AppSettings.CustomTmdbToken.Trim();

    public async Task<List<MediaItemDto>> FetchTmdbListAsync(string endpoint, string? forcedType = null)
    {
        var req = new HttpRequestMessage(HttpMethod.Get, $"https://api.themoviedb.org/3/{endpoint}");
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", ActiveTmdbToken());
        var res = await _http.SendAsync(req);
        if (!res.IsSuccessStatusCode) return new();
        var parsed = JsonSerializer.Deserialize<TmdbListResponse>(await res.Content.ReadAsStringAsync());
        var list = parsed?.Results ?? new();
        if (forcedType != null)
        {
            foreach (var item in list) item.MediaType = forcedType;
        }
        return list.Where(i => i.MediaType is "movie" or "tv").ToList();
    }

    public async Task<List<EpisodeDto>> FetchSeasonEpisodesAsync(int tvId, int season = 1)
    {
        var req = new HttpRequestMessage(HttpMethod.Get, $"https://api.themoviedb.org/3/tv/{tvId}/season/{season}?language=en-US");
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", ActiveTmdbToken());
        var res = await _http.SendAsync(req);
        if (!res.IsSuccessStatusCode) return new();
        var parsed = JsonSerializer.Deserialize<SeasonResponseDto>(await res.Content.ReadAsStringAsync());
        return parsed?.Episodes ?? new();
    }
}
