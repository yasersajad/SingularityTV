using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace SingularityTV.Desktop.Services;

public static class SingularityConstants
{
    public const string AppName = "SingularityTV";
    public const string AppVersion = "1.1.6";
    public const string SupabaseUrl = "https://soufctreejgcpvqftxeb.supabase.co";
    public const string SupabaseKey = "sb_publishable_CRHhsCu1wvqdK7lUok8VfQ_IOBUqwJI";
    public const string TelegramBot = "SingularityTV_Official_Bot";
    public const string TelegramChannelUrl = "https://t.me/+IUpscNRqcqc4Y2Zk";
    public const string TmdbToken = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiI3MTNlY2VkZmQ1NmVkNDZiMDBiZTg1N2Q3ODg3NTE1MSIsIm5iZiI6MTc3OTYyMzA4Mi4xNzUsInN1YiI6IjZhMTJlNGFhOWFkOWYxOWE3ZWE5Y2NiZiIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.8g0u3KwAVxnWszrKGfqvxrUl0VuG-_e0ZvTv5xDVRd4";
    public const string PrimaryStreamHost = "vidly.pro";

    public static readonly (string Name, string Hex)[] AccentPresets =
    {
        ("Singularity Red", "E50914"),
        ("Electric Blue", "0071EB"),
        ("Royal Purple", "7C3AED"),
        ("Emerald", "059669"),
        ("Amber Gold", "D97706"),
        ("Neon Pink", "DB2777"),
        ("Cyan", "0891B2"),
        ("Lime", "65A30D")
    };

    public static readonly Dictionary<int, string> GenreNames = new()
    {
        [28] = "Action", [12] = "Adventure", [16] = "Animation", [35] = "Comedy", [80] = "Crime",
        [99] = "Documentary", [18] = "Drama", [10751] = "Family", [14] = "Fantasy", [36] = "History",
        [27] = "Horror", [10402] = "Music", [9648] = "Mystery", [10749] = "Romance", [878] = "Sci-Fi",
        [53] = "Thriller", [10752] = "War", [37] = "Western", [10759] = "Action & Adventure",
        [10762] = "Kids", [10764] = "Reality", [10765] = "Sci-Fi & Fantasy", [10768] = "War & Politics"
    };
}

public enum ReleaseStatus
{
    Upcoming,
    Released,
    InProduction,
    Unknown
}

public static class SingularityDateHelper
{
    public static DateTime? ParseTmdbDate(string? value)
    {
        if (string.IsNullOrWhiteSpace(value) || value.Length < 10) return null;
        if (DateTime.TryParseExact(value.Substring(0, 10), "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var dt))
            return dt.Date;
        return null;
    }

    public static string TmdbDay(int offsetDays) => DateTime.Today.AddDays(offsetDays).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);

    public static string ComingLabel(DateTime releaseDate, bool isMovie)
    {
        var days = (releaseDate.Date - DateTime.Today).Days;
        var verb = isMovie ? "Coming" : "Premieres";
        if (days <= 1) return $"{verb} Tomorrow";
        if (days < 7) return $"{verb} {releaseDate.ToString("dddd", CultureInfo.InvariantCulture)}";
        var sameYear = releaseDate.Year == DateTime.Today.Year;
        return sameYear
            ? $"{verb} {releaseDate.ToString("MMMM d", CultureInfo.InvariantCulture)}"
            : $"{verb} {releaseDate.ToString("MMMM d, yyyy", CultureInfo.InvariantCulture)}";
    }
}

public sealed class MediaItemDto
{
    [JsonPropertyName("id")] public int Id { get; set; }
    [JsonPropertyName("media_type")] public string MediaType { get; set; } = "movie";
    [JsonPropertyName("title")] public string? Title { get; set; }
    [JsonPropertyName("name")] public string? Name { get; set; }
    [JsonPropertyName("overview")] public string Overview { get; set; } = "";
    [JsonPropertyName("poster_path")] public string? PosterPath { get; set; }
    [JsonPropertyName("backdrop_path")] public string? BackdropPath { get; set; }
    [JsonPropertyName("release_date")] public string? ReleaseDate { get; set; }
    [JsonPropertyName("first_air_date")] public string? FirstAirDate { get; set; }
    [JsonPropertyName("vote_average")] public double? VoteAverage { get; set; }
    [JsonPropertyName("genre_ids")] public List<int>? GenreIds { get; set; }
    [JsonPropertyName("original_language")] public string? OriginalLanguage { get; set; }
    [JsonPropertyName("origin_country")] public List<string>? OriginCountry { get; set; }
    [JsonPropertyName("status")] public string? Status { get; set; }

    public bool IsMovie => MediaType == "movie";
    public string DisplayTitle => IsMovie ? (Title ?? Name ?? "Untitled") : (Name ?? Title ?? "Untitled");
    public string? RawDateString => IsMovie ? ReleaseDate : FirstAirDate;
    public DateTime? ReleaseDateParsed => SingularityDateHelper.ParseTmdbDate(RawDateString);
    public string DisplayYear => (RawDateString ?? "").Length >= 4 ? RawDateString!.Substring(0, 4) : "";
    public string PosterUrl => string.IsNullOrEmpty(PosterPath) ? "" : $"https://image.tmdb.org/t/p/w500{PosterPath}";
    public string BackdropUrl => string.IsNullOrEmpty(BackdropPath) ? PosterUrl : $"https://image.tmdb.org/t/p/w1280{BackdropPath}";
    public int? MatchPercent => VoteAverage is > 0 ? (int)Math.Round(VoteAverage.Value * 10) : null;
    public List<string> GenreTags => GenreIds?.Where(SingularityConstants.GenreNames.ContainsKey).Select(id => SingularityConstants.GenreNames[id]).Distinct().Take(3).ToList() ?? new();

    public ReleaseStatus ReleaseStatus
    {
        get
        {
            var dt = ReleaseDateParsed;
            if (dt.HasValue) return dt.Value >= DateTime.Today.AddDays(1) ? ReleaseStatus.Upcoming : ReleaseStatus.Released;
            var st = (Status ?? "").ToLowerInvariant();
            if (st.Contains("production") || st.Contains("planned") || st.Contains("rumored")) return ReleaseStatus.InProduction;
            return ReleaseStatus.Unknown;
        }
    }

    public bool IsListable => !string.IsNullOrWhiteSpace(PosterPath) && (GenreIds == null || (!GenreIds.Contains(10763) && !GenreIds.Contains(10767)));
    public bool IsBrowsable => IsListable && ReleaseStatus != ReleaseStatus.Upcoming;

    public bool IsArabicOrGulfContent
    {
        get
        {
            if (string.Equals(OriginalLanguage, "ar", StringComparison.OrdinalIgnoreCase)) return true;
            var arab = new HashSet<string>(StringComparer.OrdinalIgnoreCase) { "SA", "AE", "KW", "QA", "BH", "OM", "EG", "LB", "SY", "JO", "IQ", "MA", "TN", "DZ", "YE", "SD", "LY", "PS" };
            if (OriginCountry != null && OriginCountry.Any(c => arab.Contains(c))) return true;
            return Regex.IsMatch($"{Title} {Name}", @"\p{IsArabic}");
        }
    }

    public string BuildStreamUrl(string host, string accentHex, int season = 1, int episode = 1)
    {
        var cleanHost = string.IsNullOrWhiteSpace(host) ? SingularityConstants.PrimaryStreamHost : host.Trim().Replace("https://", "").Replace("http://", "").Split('/')[0];
        var hex = accentHex.TrimStart('#').ToUpperInvariant();
        if (string.IsNullOrEmpty(hex)) hex = "E50914";
        return IsMovie
            ? $"https://{cleanHost}/embed/movie/{Id}?autoplay=true&color={hex}"
            : $"https://{cleanHost}/embed/tv/{Id}/{season}/{episode}?autoplay=true&color={hex}";
    }
}

public sealed class TmdbListResponse
{
    [JsonPropertyName("results")] public List<MediaItemDto> Results { get; set; } = new();
}

public sealed class NamedGenreDto
{
    [JsonPropertyName("id")] public int Id { get; set; }
    [JsonPropertyName("name")] public string Name { get; set; } = "";
}

public sealed class CastDto
{
    [JsonPropertyName("id")] public int Id { get; set; }
    [JsonPropertyName("name")] public string Name { get; set; } = "";
    [JsonPropertyName("character")] public string? Character { get; set; }
    [JsonPropertyName("profile_path")] public string? ProfilePath { get; set; }
    public string ProfileUrl => string.IsNullOrEmpty(ProfilePath) ? "" : $"https://image.tmdb.org/t/p/w185{ProfilePath}";
}

public sealed class CrewDto
{
    [JsonPropertyName("id")] public int Id { get; set; }
    [JsonPropertyName("name")] public string Name { get; set; } = "";
    [JsonPropertyName("job")] public string? Job { get; set; }
}

public sealed class CreditsDto
{
    [JsonPropertyName("cast")] public List<CastDto> Cast { get; set; } = new();
    [JsonPropertyName("crew")] public List<CrewDto> Crew { get; set; } = new();
}

public sealed class VideoDto
{
    [JsonPropertyName("id")] public string Id { get; set; } = "";
    [JsonPropertyName("key")] public string Key { get; set; } = "";
    [JsonPropertyName("name")] public string Name { get; set; } = "";
    [JsonPropertyName("site")] public string Site { get; set; } = "";
    [JsonPropertyName("type")] public string Type { get; set; } = "";
    public bool IsYouTube => string.Equals(Site, "YouTube", StringComparison.OrdinalIgnoreCase) && !string.IsNullOrWhiteSpace(Key);
    public string ThumbnailUrl => IsYouTube ? $"https://img.youtube.com/vi/{Key}/hqdefault.jpg" : "";
    public string WatchUrl => IsYouTube ? $"https://www.youtube.com/watch?v={Key}" : "";
}

public sealed class VideosDto
{
    [JsonPropertyName("results")] public List<VideoDto> Results { get; set; } = new();
}

public sealed class ReleaseDateEntryDto
{
    [JsonPropertyName("certification")] public string? Certification { get; set; }
}

public sealed class ReleaseDateCountryDto
{
    [JsonPropertyName("iso_3166_1")] public string Country { get; set; } = "";
    [JsonPropertyName("release_dates")] public List<ReleaseDateEntryDto> ReleaseDates { get; set; } = new();
}

public sealed class ReleaseDatesDto
{
    [JsonPropertyName("results")] public List<ReleaseDateCountryDto> Results { get; set; } = new();
}

public sealed class ContentRatingDto
{
    [JsonPropertyName("iso_3166_1")] public string Country { get; set; } = "";
    [JsonPropertyName("rating")] public string? Rating { get; set; }
}

public sealed class ContentRatingsDto
{
    [JsonPropertyName("results")] public List<ContentRatingDto> Results { get; set; } = new();
}

public sealed class SeasonSummaryDto
{
    [JsonPropertyName("id")] public int Id { get; set; }
    [JsonPropertyName("season_number")] public int SeasonNumber { get; set; }
    [JsonPropertyName("name")] public string Name { get; set; } = "";
    [JsonPropertyName("episode_count")] public int EpisodeCount { get; set; }
    public string DisplayName => !string.IsNullOrWhiteSpace(Name) ? Name : (SeasonNumber == 0 ? "Specials" : $"Season {SeasonNumber}");
}

public sealed class EpisodeDto
{
    [JsonPropertyName("id")] public int Id { get; set; }
    [JsonPropertyName("episode_number")] public int EpisodeNumber { get; set; }
    [JsonPropertyName("season_number")] public int SeasonNumber { get; set; } = 1;
    [JsonPropertyName("name")] public string Name { get; set; } = "";
    [JsonPropertyName("overview")] public string Overview { get; set; } = "";
    [JsonPropertyName("still_path")] public string? StillPath { get; set; }
    [JsonPropertyName("runtime")] public int? Runtime { get; set; }
    [JsonPropertyName("air_date")] public string? AirDate { get; set; }

    public string StillUrl => string.IsNullOrEmpty(StillPath) ? "" : $"https://image.tmdb.org/t/p/w500{StillPath}";
    public bool HasAired
    {
        get
        {
            var dt = SingularityDateHelper.ParseTmdbDate(AirDate);
            return !dt.HasValue || dt.Value < DateTime.Today.AddDays(1);
        }
    }
}

public sealed class SeasonResponseDto
{
    [JsonPropertyName("episodes")] public List<EpisodeDto> Episodes { get; set; } = new();
}

public sealed class TitleDetailDto
{
    [JsonPropertyName("id")] public int Id { get; set; }
    [JsonPropertyName("title")] public string? Title { get; set; }
    [JsonPropertyName("name")] public string? Name { get; set; }
    [JsonPropertyName("original_title")] public string? OriginalTitle { get; set; }
    [JsonPropertyName("original_name")] public string? OriginalName { get; set; }
    [JsonPropertyName("tagline")] public string? Tagline { get; set; }
    [JsonPropertyName("overview")] public string Overview { get; set; } = "";
    [JsonPropertyName("status")] public string? Status { get; set; }
    [JsonPropertyName("poster_path")] public string? PosterPath { get; set; }
    [JsonPropertyName("backdrop_path")] public string? BackdropPath { get; set; }
    [JsonPropertyName("release_date")] public string? ReleaseDate { get; set; }
    [JsonPropertyName("first_air_date")] public string? FirstAirDate { get; set; }
    [JsonPropertyName("vote_average")] public double? VoteAverage { get; set; }
    [JsonPropertyName("runtime")] public int? Runtime { get; set; }
    [JsonPropertyName("episode_run_time")] public List<int> EpisodeRunTime { get; set; } = new();
    [JsonPropertyName("number_of_seasons")] public int? NumberOfSeasons { get; set; }
    [JsonPropertyName("genres")] public List<NamedGenreDto> Genres { get; set; } = new();
    [JsonPropertyName("created_by")] public List<NamedGenreDto> CreatedBy { get; set; } = new();
    [JsonPropertyName("seasons")] public List<SeasonSummaryDto> Seasons { get; set; } = new();
    [JsonPropertyName("credits")] public CreditsDto? Credits { get; set; }
    [JsonPropertyName("videos")] public VideosDto? Videos { get; set; }
    [JsonPropertyName("recommendations")] public TmdbListResponse? Recommendations { get; set; }
    [JsonPropertyName("similar")] public TmdbListResponse? Similar { get; set; }
    [JsonPropertyName("release_dates")] public ReleaseDatesDto? ReleaseDates { get; set; }
    [JsonPropertyName("content_ratings")] public ContentRatingsDto? ContentRatings { get; set; }

    public string? UsCertification(bool isMovie)
    {
        if (isMovie)
        {
            return ReleaseDates?.Results.FirstOrDefault(r => r.Country == "US")?.ReleaseDates.FirstOrDefault(d => !string.IsNullOrWhiteSpace(d.Certification))?.Certification;
        }
        return ContentRatings?.Results.FirstOrDefault(r => r.Country == "US")?.Rating;
    }

    public string? DirectorOrCreators(bool isMovie)
    {
        if (isMovie)
        {
            var dirs = Credits?.Crew.Where(c => c.Job == "Director").Select(c => c.Name).Take(3).ToList();
            return dirs is { Count: > 0 } ? string.Join(", ", dirs) : null;
        }
        var creators = CreatedBy.Select(c => c.Name).Take(3).ToList();
        return creators.Count > 0 ? string.Join(", ", creators) : null;
    }
}

public sealed class ReminderDto
{
    public MediaItemDto Item { get; set; } = new();
    public long ReleaseDateEpochMs { get; set; }
}

public sealed class UserProfileDto
{
    [JsonPropertyName("id")] public string Id { get; set; } = "prof_main";
    [JsonPropertyName("name")] public string Name { get; set; } = "Main";
    [JsonPropertyName("avatarColor")] public string AvatarColor { get; set; } = "#E50914";
}

public sealed class DesktopSession
{
    public string AccessToken { get; set; } = "";
    public string RefreshToken { get; set; } = "";
    public string UserId { get; set; } = "";
    public string Email { get; set; } = "";
    public string Name { get; set; } = "";
}

public sealed class WebPlayerPrefsDto
{
    [JsonPropertyName("preferredQuality")] public string PreferredQuality { get; set; } = "Auto";
    [JsonPropertyName("subtitleLanguage")] public string SubtitleLanguage { get; set; } = "Off";
    [JsonPropertyName("playbackSpeed")] public string PlaybackSpeed { get; set; } = "1";
}

public sealed class DesktopAppSettings
{
    public string AccentColorHex { get; set; } = "E50914";
    public string StreamingProviderBaseURL { get; set; } = "vidly.pro";
    public string CustomTmdbToken { get; set; } = "";
    public bool AutomaticUpdateChecks { get; set; } = true;
}

public sealed class DesktopBackendService
{
    private readonly HttpClient _http = new() { Timeout = TimeSpan.FromSeconds(20) };
    private readonly string _dataDir;
    private readonly string _sessionPath;
    private readonly string _settingsPath;
    private readonly string _remindersPath;

    public DesktopSession? Session { get; private set; }
    public List<UserProfileDto> Profiles { get; private set; } = new();
    public UserProfileDto? ActiveProfile { get; private set; }
    public WebPlayerPrefsDto PlayerPrefs { get; set; } = new();
    public DesktopAppSettings AppSettings { get; private set; } = new();
    public List<MediaItemDto> MyList { get; } = new();
    public List<MediaItemDto> Liked { get; } = new();
    public List<MediaItemDto> History { get; } = new();
    public List<ReminderDto> Reminders { get; private set; } = new();

    public DesktopBackendService()
    {
        _dataDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "SingularityTV");
        Directory.CreateDirectory(_dataDir);
        _sessionPath = Path.Combine(_dataDir, "session.json");
        _settingsPath = Path.Combine(_dataDir, "settings.json");
        _remindersPath = Path.Combine(_dataDir, "reminders.json");
        if (File.Exists(_sessionPath))
        {
            try { Session = JsonSerializer.Deserialize<DesktopSession>(File.ReadAllText(_sessionPath)); } catch { }
        }
        if (File.Exists(_settingsPath))
        {
            try { AppSettings = JsonSerializer.Deserialize<DesktopAppSettings>(File.ReadAllText(_settingsPath)) ?? new(); } catch { }
        }
        if (File.Exists(_remindersPath))
        {
            try
            {
                var loaded = JsonSerializer.Deserialize<List<ReminderDto>>(File.ReadAllText(_remindersPath)) ?? new();
                var todayMs = new DateTimeOffset(DateTime.Today).ToUnixTimeMilliseconds();
                Reminders = loaded.Where(r => r.ReleaseDateEpochMs >= todayMs).ToList();
            }
            catch { }
        }
    }

    public void SaveAppSettings()
    {
        File.WriteAllText(_settingsPath, JsonSerializer.Serialize(AppSettings));
        _ = PushActiveProfileAsync();
    }

    private void SaveReminders()
    {
        File.WriteAllText(_remindersPath, JsonSerializer.Serialize(Reminders));
    }

    public bool HasReminder(MediaItemDto item) => Reminders.Any(r => r.Item.Id == item.Id && r.Item.MediaType == item.MediaType);

    public bool ToggleReminder(MediaItemDto item, DateTime releaseDate)
    {
        var idx = Reminders.FindIndex(r => r.Item.Id == item.Id && r.Item.MediaType == item.MediaType);
        bool added;
        if (idx >= 0)
        {
            Reminders.RemoveAt(idx);
            added = false;
        }
        else
        {
            var epoch = new DateTimeOffset(releaseDate.Date).ToUnixTimeMilliseconds();
            Reminders.Add(new ReminderDto { Item = item, ReleaseDateEpochMs = epoch });
            Reminders = Reminders.OrderBy(r => r.ReleaseDateEpochMs).ToList();
            added = true;
        }
        SaveReminders();
        _ = PushActiveProfileAsync();
        return added;
    }

    public async Task<(bool ok, string? error)> SignInAsync(string email, string password)
    {
        var body = JsonSerializer.Serialize(new { email, password });
        var req = new HttpRequestMessage(HttpMethod.Post, $"{SingularityConstants.SupabaseUrl}/auth/v1/token?grant_type=password");
        req.Headers.Add("apikey", SingularityConstants.SupabaseKey);
        req.Content = new StringContent(body, Encoding.UTF8, "application/json");
        var res = await _http.SendAsync(req);
        var txt = await res.Content.ReadAsStringAsync();
        if (!res.IsSuccessStatusCode) return (false, "Invalid email or password.");
        using var doc = JsonDocument.Parse(txt);
        var root = doc.RootElement;
        Session = new DesktopSession
        {
            AccessToken = root.GetProperty("access_token").GetString() ?? "",
            RefreshToken = root.TryGetProperty("refresh_token", out var rt) ? rt.GetString() ?? "" : "",
            UserId = root.GetProperty("user").GetProperty("id").GetString() ?? "",
            Email = email
        };
        File.WriteAllText(_sessionPath, JsonSerializer.Serialize(Session));
        return (true, null);
    }

    public void SignOut()
    {
        Session = null;
        ActiveProfile = null;
        Profiles.Clear();
        MyList.Clear();
        Liked.Clear();
        History.Clear();
        if (File.Exists(_sessionPath)) File.Delete(_sessionPath);
    }

    public async Task<bool> CheckTelegramGateAsync()
    {
        if (Session == null) return false;
        var req = new HttpRequestMessage(HttpMethod.Post, $"{SingularityConstants.SupabaseUrl}/functions/v1/telegram-gate");
        req.Headers.Add("apikey", SingularityConstants.SupabaseKey);
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", Session.AccessToken);
        req.Content = new StringContent("{\"action\":\"check\"}", Encoding.UTF8, "application/json");
        var res = await _http.SendAsync(req);
        if (!res.IsSuccessStatusCode) return false;
        using var doc = JsonDocument.Parse(await res.Content.ReadAsStringAsync());
        return doc.RootElement.TryGetProperty("member", out var m) && m.GetBoolean();
    }

    public async Task LoadProfilesAsync()
    {
        if (Session == null) return;
        var req = new HttpRequestMessage(HttpMethod.Get, $"{SingularityConstants.SupabaseUrl}/functions/v1/telegram-gate?action=sync_profile_pull");
        req.Headers.Add("apikey", SingularityConstants.SupabaseKey);
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", Session.AccessToken);
        var res = await _http.SendAsync(req);
        if (!res.IsSuccessStatusCode) return;
        using var doc = JsonDocument.Parse(await res.Content.ReadAsStringAsync());
        if (doc.RootElement.TryGetProperty("profiles", out var arr))
        {
            Profiles = JsonSerializer.Deserialize<List<UserProfileDto>>(arr.GetRawText()) ?? new();
        }
    }

    public async Task SelectProfileAsync(UserProfileDto profile)
    {
        ActiveProfile = profile;
        MyList.Clear();
        History.Clear();
        if (Session == null) return;
        var req = new HttpRequestMessage(HttpMethod.Get, $"{SingularityConstants.SupabaseUrl}/functions/v1/telegram-gate?action=sync_profile_pull&profileId={Uri.EscapeDataString(profile.Id)}");
        req.Headers.Add("apikey", SingularityConstants.SupabaseKey);
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", Session.AccessToken);
        var res = await _http.SendAsync(req);
        if (!res.IsSuccessStatusCode) return;
        using var doc = JsonDocument.Parse(await res.Content.ReadAsStringAsync());
        if (doc.RootElement.TryGetProperty("profileData", out var bucket))
        {
            if (bucket.TryGetProperty("webPlayerPrefs", out var wp))
            {
                PlayerPrefs = JsonSerializer.Deserialize<WebPlayerPrefsDto>(wp.GetRawText()) ?? new();
            }
            if (bucket.TryGetProperty("playerPrefs", out var pp))
            {
                if (pp.TryGetProperty("accentColorHex", out var ac) && !string.IsNullOrWhiteSpace(ac.GetString()))
                    AppSettings.AccentColorHex = ac.GetString()!;
                if (pp.TryGetProperty("streamingProviderBaseURL", out var sp) && !string.IsNullOrWhiteSpace(sp.GetString()))
                    AppSettings.StreamingProviderBaseURL = sp.GetString()!;
            }
            if (bucket.TryGetProperty("reminders", out var rem) && rem.ValueKind == JsonValueKind.Array)
            {
                try
                {
                    var synced = JsonSerializer.Deserialize<List<ReminderDto>>(rem.GetRawText());
                    if (synced != null)
                    {
                        var todayMs = new DateTimeOffset(DateTime.Today).ToUnixTimeMilliseconds();
                        Reminders = synced.Where(r => r.ReleaseDateEpochMs >= todayMs).ToList();
                        SaveReminders();
                    }
                }
                catch { }
            }
            if (bucket.TryGetProperty("saved", out var saved) && saved.ValueKind == JsonValueKind.Object)
            {
                foreach (var prop in saved.EnumerateObject())
                {
                    var v = prop.Value;
                    MyList.Add(new MediaItemDto
                    {
                        Id = v.TryGetProperty("id", out var idEl) ? idEl.GetInt32() : 0,
                        MediaType = v.TryGetProperty("media_type", out var mtEl) ? mtEl.GetString() ?? "movie" : "movie",
                        Title = v.TryGetProperty("title", out var tEl) ? tEl.GetString() : null,
                        Name = v.TryGetProperty("title", out var nEl) ? nEl.GetString() : null,
                        PosterPath = v.TryGetProperty("poster_path", out var pEl) ? pEl.GetString() : null
                    });
                }
            }
        }
    }

    public async Task PushActiveProfileAsync()
    {
        if (Session == null || ActiveProfile == null) return;
        var savedObj = new JsonObject();
        var savedOrder = new JsonArray();
        foreach (var m in MyList)
        {
            var key = $"{m.MediaType}_{m.Id}";
            savedOrder.Add(key);
            savedObj[key] = new JsonObject
            {
                ["id"] = m.Id,
                ["media_type"] = m.MediaType,
                ["title"] = m.DisplayTitle,
                ["poster_path"] = m.PosterPath
            };
        }
        var bucket = new JsonObject
        {
            ["saved"] = savedObj,
            ["savedOrder"] = savedOrder,
            ["reminders"] = JsonSerializer.SerializeToNode(Reminders),
            ["webPlayerPrefs"] = new JsonObject
            {
                ["preferredQuality"] = PlayerPrefs.PreferredQuality,
                ["subtitleLanguage"] = PlayerPrefs.SubtitleLanguage,
                ["playbackSpeed"] = PlayerPrefs.PlaybackSpeed
            },
            ["playerPrefs"] = new JsonObject
            {
                ["accentColorHex"] = AppSettings.AccentColorHex,
                ["streamingProviderBaseURL"] = AppSettings.StreamingProviderBaseURL
            },
            ["_playerPrefsTs"] = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds()
        };
        var payload = new JsonObject
        {
            ["schemaVersion"] = 2,
            ["profileData"] = new JsonObject { [ActiveProfile.Id] = bucket }
        };
        var req = new HttpRequestMessage(HttpMethod.Post, $"{SingularityConstants.SupabaseUrl}/functions/v1/telegram-gate?action=sync_push");
        req.Headers.Add("apikey", SingularityConstants.SupabaseKey);
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", Session.AccessToken);
        req.Content = new StringContent(payload.ToJsonString(), Encoding.UTF8, "application/json");
        try { await _http.SendAsync(req); } catch { }
    }

    public void ToggleMyList(MediaItemDto item)
    {
        var idx = MyList.FindIndex(x => x.Id == item.Id && x.MediaType == item.MediaType);
        if (idx >= 0) MyList.RemoveAt(idx); else MyList.Add(item);
        _ = PushActiveProfileAsync();
    }

    public void ToggleLike(MediaItemDto item)
    {
        var idx = Liked.FindIndex(x => x.Id == item.Id && x.MediaType == item.MediaType);
        if (idx >= 0) Liked.RemoveAt(idx); else Liked.Add(item);
    }

    private string ActiveTmdbToken() =>
        string.IsNullOrWhiteSpace(AppSettings.CustomTmdbToken) ? SingularityConstants.TmdbToken : AppSettings.CustomTmdbToken.Trim();

    public async Task<List<MediaItemDto>> FetchTmdbListAsync(string endpoint, string? forcedType = null, bool filterBrowsable = true)
    {
        var req = new HttpRequestMessage(HttpMethod.Get, $"https://api.themoviedb.org/3/{endpoint}");
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", ActiveTmdbToken());
        var res = await _http.SendAsync(req);
        if (!res.IsSuccessStatusCode) return new();
        var parsed = JsonSerializer.Deserialize<TmdbListResponse>(await res.Content.ReadAsStringAsync());
        var list = parsed?.Results ?? new();
        if (forcedType != null)
        {
            foreach (var item in list) item.MediaType = forcedType;
        }
        return list.Where(i => (i.MediaType is "movie" or "tv") && (!filterBrowsable || i.IsBrowsable)).ToList();
    }

    public async Task<List<MediaItemDto>> FetchUpcomingComingSoonAsync()
    {
        var tomorrow = SingularityDateHelper.TmdbDay(1);
        var horizon = SingularityDateHelper.TmdbDay(120);
        var m1 = await FetchTmdbListAsync("movie/upcoming?region=US&language=en-US&page=1", "movie", false);
        var m2 = await FetchTmdbListAsync("movie/upcoming?region=US&language=en-US&page=2", "movie", false);
        var t1 = await FetchTmdbListAsync($"discover/tv?first_air_date.gte={tomorrow}&first_air_date.lte={horizon}&sort_by=popularity.desc&without_genres=10763,10767,10766,10764&language=en-US&page=1", "tv", false);
        var t2 = await FetchTmdbListAsync($"discover/tv?first_air_date.gte={tomorrow}&first_air_date.lte={horizon}&sort_by=popularity.desc&without_genres=10763,10767,10766,10764&language=en-US&page=2", "tv", false);
        return m1.Concat(m2).Concat(t1).Concat(t2)
            .GroupBy(i => $"{i.MediaType}-{i.Id}")
            .Select(g => g.First())
            .Where(i => !string.IsNullOrWhiteSpace(i.PosterPath) && !string.IsNullOrWhiteSpace(i.BackdropPath) && !string.IsNullOrWhiteSpace(i.Overview) && i.ReleaseStatus == ReleaseStatus.Upcoming)
            .OrderBy(i => i.ReleaseDateParsed ?? DateTime.MaxValue)
            .Take(24)
            .ToList();
    }

    public async Task<TitleDetailDto?> FetchTitleDetailAsync(string mediaType, int id)
    {
        var append = mediaType == "movie"
            ? "credits,videos,images,release_dates,recommendations,similar"
            : "credits,videos,images,content_ratings,recommendations,similar";
        var req = new HttpRequestMessage(HttpMethod.Get, $"https://api.themoviedb.org/3/{mediaType}/{id}?append_to_response={append}&include_image_language=en,null&include_video_language=en,null&language=en-US");
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", ActiveTmdbToken());
        var res = await _http.SendAsync(req);
        if (!res.IsSuccessStatusCode) return null;
        return JsonSerializer.Deserialize<TitleDetailDto>(await res.Content.ReadAsStringAsync());
    }

    public async Task<List<EpisodeDto>> FetchSeasonEpisodesAsync(int tvId, int season = 1)
    {
        var req = new HttpRequestMessage(HttpMethod.Get, $"https://api.themoviedb.org/3/tv/{tvId}/season/{season}?language=en-US");
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", ActiveTmdbToken());
        var res = await _http.SendAsync(req);
        if (!res.IsSuccessStatusCode) return new();
        var parsed = JsonSerializer.Deserialize<SeasonResponseDto>(await res.Content.ReadAsStringAsync());
        return parsed?.Episodes ?? new();
    }
}
