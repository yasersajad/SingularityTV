using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.UI;
using Microsoft.UI.Windowing;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Media.Imaging;
using Microsoft.Web.WebView2.Core;
using SingularityTV.Desktop.Services;
using Windows.System;

namespace SingularityTV.Desktop;

public sealed partial class MainWindow : Window
{
    private readonly DesktopBackendService _backend = new();
    private string? _currentStreamUrl;
    private bool _isFullScreen;
    private string _homeScope = "all";

    private static readonly string[] BlockedAdDomains =
    {
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "googletagmanager.com", "google-analytics.com", "popads.net", "popcash.net",
        "propellerads.com", "adsterra.com", "adskeeper.com", "mgid.com", "taboola.com",
        "outbrain.com", "exoclick.com", "juicyads.com", "trafficjunky.com", "histats.com",
        "4rabet", "1xbet", "betway", "onclickalgo", "adsco.re", "a-ads.com"
    };

    public MainWindow()
    {
        InitializeComponent();
        Title = "SingularityTV 1.1.6";
        _ = BootstrapAsync();
    }

    private async Task BootstrapAsync()
    {
        if (_backend.Session == null)
        {
            ShowStage("auth");
            return;
        }
        var ok = await _backend.CheckTelegramGateAsync();
        if (!ok)
        {
            ShowStage("telegram");
            return;
        }
        await _backend.LoadProfilesAsync();
        RenderProfiles();
        ShowStage("profiles");
    }

    private void ShowStage(string stage)
    {
        AuthPanel.Visibility = stage == "auth" ? Visibility.Visible : Visibility.Collapsed;
        TelegramPanel.Visibility = stage == "telegram" ? Visibility.Visible : Visibility.Collapsed;
        ProfilesPanel.Visibility = stage == "profiles" ? Visibility.Visible : Visibility.Collapsed;
        MainNavView.Visibility = stage == "main" ? Visibility.Visible : Visibility.Collapsed;
    }

    private async void SignInButton_Click(object sender, RoutedEventArgs e)
    {
        AuthErrorText.Visibility = Visibility.Collapsed;
        var (ok, err) = await _backend.SignInAsync(EmailBox.Text.Trim(), PasswordBox.Password);
        if (!ok)
        {
            AuthErrorText.Text = err ?? "Sign in failed";
            AuthErrorText.Visibility = Visibility.Visible;
            return;
        }
        await BootstrapAsync();
    }

    private async void VerifyTelegram_Click(object sender, RoutedEventArgs e)
    {
        if (await _backend.CheckTelegramGateAsync())
        {
            await _backend.LoadProfilesAsync();
            RenderProfiles();
            ShowStage("profiles");
        }
    }

    private void RenderProfiles()
    {
        ProfilesListPanel.Children.Clear();
        foreach (var profile in _backend.Profiles)
        {
            var btn = new Button
            {
                Content = profile.Name,
                Width = 120,
                Height = 120,
                FontSize = 18,
                Background = new SolidColorBrush(ColorHelper.FromArgb(255, 229, 9, 20)),
                Foreground = new SolidColorBrush(Colors.White)
            };
            btn.Click += async (_, _) =>
            {
                await _backend.SelectProfileAsync(profile);
                ShowStage("main");
                PopulateSettingsUI();
                await LoadHomeAsync();
            };
            ProfilesListPanel.Children.Add(btn);
        }
    }

    private async Task LoadHomeAsync()
    {
        HomeRowsPanel.Children.Clear();
        var trending = await _backend.FetchTmdbListAsync("trending/all/week?language=en-US");
        var movies = await _backend.FetchTmdbListAsync("movie/popular?language=en-US", "movie");
        var series = await _backend.FetchTmdbListAsync("tv/popular?language=en-US", "tv");

        var filteredTrending = _homeScope switch
        {
            "series" => trending.Where(x => !x.IsMovie).ToList(),
            "films" => trending.Where(x => x.IsMovie).ToList(),
            _ => trending
        };

        if (filteredTrending.FirstOrNull() is { } hero)
        {
            AddHeroBanner(hero);
        }
        AddMediaRow("Top 10 Today", filteredTrending.Take(10).ToList());
        if (_homeScope != "series") AddMediaRow("Popular Movies", movies);
        if (_homeScope != "films") AddMediaRow("Popular Series", series);
        if (_backend.MyList.Count > 0) AddMediaRow("My List", _backend.MyList);
    }

    private void AddHeroBanner(MediaItemDto hero)
    {
        var grid = new Grid { Height = 320, CornerRadius = new CornerRadius(12) };
        if (!string.IsNullOrEmpty(hero.BackdropUrl))
        {
            grid.Children.Add(new Image { Source = new BitmapImage(new Uri(hero.BackdropUrl)), Stretch = Stretch.UniformToFill, Opacity = 0.65 });
        }
        var info = new StackPanel { VerticalAlignment = VerticalAlignment.Bottom, Margin = new Thickness(24), Spacing = 10, MaxWidth = 520, HorizontalAlignment = HorizontalAlignment.Left };
        info.Children.Add(new TextBlock { Text = hero.DisplayTitle, Foreground = new SolidColorBrush(Colors.White), FontSize = 30, FontWeight = Microsoft.UI.Text.FontWeights.Black });
        info.Children.Add(new TextBlock { Text = hero.Overview, Foreground = new SolidColorBrush(Colors.LightGray), MaxLines = 2, TextWrapping = TextWrapping.Wrap });
        var btns = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 10 };
        var playBtn = new Button { Content = "Play", Background = new SolidColorBrush(Colors.White), Foreground = new SolidColorBrush(Colors.Black) };
        playBtn.Click += async (_, _) => await OpenPlayerAsync(hero);
        var detBtn = new Button { Content = "Details & More" };
        detBtn.Click += async (_, _) => await OpenDetailAsync(hero);
        btns.Children.Add(playBtn);
        btns.Children.Add(detBtn);
        info.Children.Add(btns);
        grid.Children.Add(info);
        HomeRowsPanel.Children.Add(grid);
    }

    private void AddMediaRow(string title, List<MediaItemDto> items)
    {
        var header = new TextBlock { Text = title, Foreground = new SolidColorBrush(Colors.White), FontSize = 20, FontWeight = Microsoft.UI.Text.FontWeights.Bold };
        HomeRowsPanel.Children.Add(header);

        var row = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 14 };
        foreach (var item in items.Take(16))
        {
            var cardGrid = new Grid { Width = 150, Height = 225, CornerRadius = new CornerRadius(8) };
            if (!string.IsNullOrEmpty(item.PosterUrl))
            {
                cardGrid.Children.Add(new Image { Source = new BitmapImage(new Uri(item.PosterUrl)), Stretch = Stretch.UniformToFill });
            }
            if (item.IsArabicOrGulfContent)
            {
                cardGrid.Children.Add(new Border
                {
                    Background = new SolidColorBrush(ColorHelper.FromArgb(190, 0, 0, 0)),
                    CornerRadius = new CornerRadius(10),
                    Padding = new Thickness(6, 2, 6, 2),
                    Margin = new Thickness(6),
                    HorizontalAlignment = HorizontalAlignment.Left,
                    VerticalAlignment = VerticalAlignment.Top,
                    Child = new TextBlock { Text = "May Not Stream", Foreground = new SolidColorBrush(Colors.White), FontSize = 10 }
                });
            }
            var btn = new Button
            {
                Content = cardGrid,
                Padding = new Thickness(0),
                Background = new SolidColorBrush(Colors.Transparent),
                BorderThickness = new Thickness(0)
            };
            ToolTipService.SetToolTip(btn, item.DisplayTitle);
            btn.Click += async (_, _) => await OpenDetailAsync(item);
            row.Children.Add(btn);
        }

        HomeRowsPanel.Children.Add(new ScrollViewer
        {
            HorizontalScrollMode = ScrollMode.Enabled,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
            VerticalScrollMode = ScrollMode.Disabled,
            Content = row
        });
    }

    private async Task OpenDetailAsync(MediaItemDto item)
    {
        DetailContentPanel.Children.Clear();
        DetailPanel.Visibility = Visibility.Visible;

        var backBtn = new Button { Content = "Back" };
        backBtn.Click += (_, _) => DetailPanel.Visibility = Visibility.Collapsed;
        DetailContentPanel.Children.Add(backBtn);

        DetailContentPanel.Children.Add(new TextBlock { Text = item.DisplayTitle, Foreground = new SolidColorBrush(Colors.White), FontSize = 28, FontWeight = Microsoft.UI.Text.FontWeights.Bold });
        if (item.IsArabicOrGulfContent)
        {
            DetailContentPanel.Children.Add(new TextBlock { Text = "Arabic/Gulf titles may have limited availability on external servers.", Foreground = new SolidColorBrush(Colors.Orange), FontSize = 13 });
        }
        DetailContentPanel.Children.Add(new TextBlock { Text = item.Overview, Foreground = new SolidColorBrush(Colors.LightGray), TextWrapping = TextWrapping.Wrap });

        var actions = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 10 };
        var playBtn = new Button { Content = "Play", Background = new SolidColorBrush(Colors.White), Foreground = new SolidColorBrush(Colors.Black) };
        playBtn.Click += async (_, _) => await OpenPlayerAsync(item);
        var listBtn = new Button { Content = _backend.MyList.Any(x => x.Id == item.Id) ? "In My List" : "+ My List" };
        listBtn.Click += (_, _) =>
        {
            _backend.ToggleMyList(item);
            listBtn.Content = _backend.MyList.Any(x => x.Id == item.Id) ? "In My List" : "+ My List";
        };
        actions.Children.Add(playBtn);
        actions.Children.Add(listBtn);
        DetailContentPanel.Children.Add(actions);

        if (!item.IsMovie)
        {
            var eps = await _backend.FetchSeasonEpisodesAsync(item.Id, 1);
            if (eps.Count > 0)
            {
                DetailContentPanel.Children.Add(new TextBlock { Text = "Season 1 Episodes", Foreground = new SolidColorBrush(Colors.White), FontSize = 18, FontWeight = Microsoft.UI.Text.FontWeights.SemiBold });
                foreach (var ep in eps.Take(20))
                {
                    var epBtn = new Button { Content = $"{ep.EpisodeNumber}. {ep.Name}", HorizontalAlignment = HorizontalAlignment.Stretch, HorizontalContentAlignment = HorizontalAlignment.Left };
                    epBtn.Click += async (_, _) => await OpenPlayerAsync(item, 1, ep.EpisodeNumber);
                    DetailContentPanel.Children.Add(epBtn);
                }
            }
        }
    }

    private async Task OpenPlayerAsync(MediaItemDto item, int season = 1, int episode = 1)
    {
        _currentStreamUrl = item.BuildStreamUrl(_backend.AppSettings.StreamingProviderBaseURL, _backend.AppSettings.AccentColorHex, season, episode);
        PlayerErrorTitle.Text = item.DisplayTitle;
        PlayerErrorPanel.Visibility = Visibility.Collapsed;
        PlayerPanel.Visibility = Visibility.Visible;

        await PlayerWebView.EnsureCoreWebView2Async();
        var core = PlayerWebView.CoreWebView2;
        core.NewWindowRequested += (_, args) => { args.Handled = true; };
        core.AddWebResourceRequestedFilter("*", CoreWebView2WebResourceContext.All);
        core.WebResourceRequested += (_, args) =>
        {
            var uri = args.Request.Uri.ToLowerInvariant();
            if (BlockedAdDomains.Any(d => uri.Contains(d)))
            {
                args.Response = core.Environment.CreateWebResourceResponse(null, 403, "Blocked", "");
            }
        };
        core.NavigationStarting += (_, args) =>
        {
            if (Uri.TryCreate(args.Uri, UriKind.Absolute, out var u) && !u.Host.Contains("vidly", StringComparison.OrdinalIgnoreCase))
            {
                args.Cancel = true;
            }
        };
        core.WebMessageReceived += (_, args) =>
        {
            try
            {
                using var doc = JsonDocument.Parse(args.TryGetWebMessageAsString());
                var type = doc.RootElement.GetProperty("type").GetString();
                if (type == "pref")
                {
                    var p = doc.RootElement.GetProperty("payload");
                    var k = p.GetProperty("key").GetString();
                    var v = p.GetProperty("value").GetString() ?? "";
                    if (k == "preferredQuality") _backend.PlayerPrefs.PreferredQuality = v;
                    else if (k == "subtitleLanguage") _backend.PlayerPrefs.SubtitleLanguage = v;
                    else if (k == "playbackSpeed") _backend.PlayerPrefs.PlaybackSpeed = v;
                    _ = _backend.PushActiveProfileAsync();
                }
                else if (type == "error")
                {
                    PlayerErrorPanel.Visibility = Visibility.Visible;
                }
            }
            catch { }
        };
        core.NavigationCompleted += async (_, args) =>
        {
            if (!args.IsSuccess)
            {
                PlayerErrorPanel.Visibility = Visibility.Visible;
                return;
            }
            var jsPath = Path.Combine(AppContext.BaseDirectory, "Assets", "WebPlayer", "vidly-player.js");
            var cssPath = Path.Combine(AppContext.BaseDirectory, "Assets", "WebPlayer", "vidly-player.css");
            var js = File.Exists(jsPath) ? File.ReadAllText(jsPath) : "";
            var css = File.Exists(cssPath) ? File.ReadAllText(cssPath).Replace("\\", "\\\\").Replace("'", "\\'").Replace("\n", "\\n") : "";
            var prefsJson = JsonSerializer.Serialize(_backend.PlayerPrefs);
            var initScript = $"document.documentElement.style.setProperty('--sg-accent', '#{_backend.AppSettings.AccentColorHex}'); var st = document.createElement('style'); st.textContent = '{css}'; document.head.appendChild(st); window.__sgSavedPrefs = {prefsJson}; {js}";
            await core.ExecuteScriptAsync(initScript);
        };
        PlayerWebView.Source = new Uri(_currentStreamUrl);
    }

    private void PopulateSettingsUI()
    {
        SettingsAccountInfo.Text = $"Profile: {_backend.ActiveProfile?.Name ?? "Main"} · {_backend.Session?.Email ?? ""}";
        ServerHostBox.Text = _backend.AppSettings.StreamingProviderBaseURL;
        TmdbKeyBox.Text = _backend.AppSettings.CustomTmdbToken;
        QualityCombo.SelectedItem = _backend.PlayerPrefs.PreferredQuality;
        SubtitleCombo.SelectedItem = _backend.PlayerPrefs.SubtitleLanguage;

        AccentSwatchesPanel.Children.Clear();
        foreach (var preset in SingularityConstants.AccentPresets)
        {
            var b = new Button { Content = preset.Name, Tag = preset.Hex };
            b.Click += (_, _) =>
            {
                _backend.AppSettings.AccentColorHex = preset.Hex;
                _backend.SaveAppSettings();
            };
            AccentSwatchesPanel.Children.Add(b);
        }
    }

    private void SaveServer_Click(object sender, RoutedEventArgs e)
    {
        _backend.AppSettings.StreamingProviderBaseURL = ServerHostBox.Text.Trim();
        _backend.SaveAppSettings();
    }

    private void SaveTmdbKey_Click(object sender, RoutedEventArgs e)
    {
        _backend.AppSettings.CustomTmdbToken = TmdbKeyBox.Text.Trim();
        _backend.SaveAppSettings();
    }

    private void QualityCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (QualityCombo.SelectedItem is string q)
        {
            _backend.PlayerPrefs.PreferredQuality = q;
            _ = _backend.PushActiveProfileAsync();
        }
    }

    private void SubtitleCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (SubtitleCombo.SelectedItem is string s)
        {
            _backend.PlayerPrefs.SubtitleLanguage = s;
            _ = _backend.PushActiveProfileAsync();
        }
    }

    private void DeleteHistory_Click(object sender, RoutedEventArgs e)
    {
        _backend.History.Clear();
        _ = _backend.PushActiveProfileAsync();
    }

    private async void FilterAll_Click(object sender, RoutedEventArgs e) { _homeScope = "all"; await LoadHomeAsync(); }
    private async void FilterSeries_Click(object sender, RoutedEventArgs e) { _homeScope = "series"; await LoadHomeAsync(); }
    private async void FilterFilms_Click(object sender, RoutedEventArgs e) { _homeScope = "films"; await LoadHomeAsync(); }

    private void RetryPlayer_Click(object sender, RoutedEventArgs e)
    {
        if (_currentStreamUrl == null) return;
        PlayerErrorPanel.Visibility = Visibility.Collapsed;
        PlayerWebView.Source = new Uri(_currentStreamUrl);
    }

    private void ClosePlayer_Click(object sender, RoutedEventArgs e)
    {
        PlayerPanel.Visibility = Visibility.Collapsed;
        PlayerWebView.Source = new Uri("about:blank");
    }

    private async void MainNavView_SelectionChanged(NavigationView sender, NavigationViewSelectionChangedEventArgs args)
    {
        DetailPanel.Visibility = Visibility.Collapsed;
        var tag = (args.SelectedItem as NavigationViewItem)?.Tag?.ToString();
        HomeScroll.Visibility = tag == "home" ? Visibility.Visible : Visibility.Collapsed;
        NewHotScroll.Visibility = tag == "newhot" ? Visibility.Visible : Visibility.Collapsed;
        SearchPanel.Visibility = tag == "search" ? Visibility.Visible : Visibility.Collapsed;
        MyPanel.Visibility = tag == "my" ? Visibility.Visible : Visibility.Collapsed;
        SettingsScroll.Visibility = tag == "settings" ? Visibility.Visible : Visibility.Collapsed;

        if (tag == "newhot")
        {
            NewHotPanel.Children.Clear();
            var upcoming = await _backend.FetchTmdbListAsync("movie/upcoming?language=en-US", "movie");
            foreach (var u in upcoming.Take(12))
            {
                var btn = new Button { Content = $"{u.DisplayTitle} ({u.DisplayYear})", HorizontalAlignment = HorizontalAlignment.Left };
                btn.Click += async (_, _) => await OpenDetailAsync(u);
                NewHotPanel.Children.Add(btn);
            }
        }
        else if (tag == "my")
        {
            MyContentPanel.Children.Clear();
            MyContentPanel.Children.Add(new TextBlock { Text = $"{_backend.ActiveProfile?.Name ?? "Profile"} · {_backend.MyList.Count} in My List", Foreground = new SolidColorBrush(Colors.White), FontSize = 22, FontWeight = Microsoft.UI.Text.FontWeights.Bold });
            foreach (var m in _backend.MyList)
            {
                var btn = new Button { Content = m.DisplayTitle };
                btn.Click += async (_, _) => await OpenDetailAsync(m);
                MyContentPanel.Children.Add(btn);
            }
        }
    }

    private async void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
    {
        var q = SearchBox.Text.Trim();
        if (q.Length < 2) return;
        SearchResultsPanel.Children.Clear();
        var results = await _backend.FetchTmdbListAsync($"search/multi?query={Uri.EscapeDataString(q)}&include_adult=false&language=en-US");
        foreach (var r in results.Take(20))
        {
            var btn = new Button { Content = r.DisplayTitle };
            btn.Click += async (_, _) => await OpenDetailAsync(r);
            SearchResultsPanel.Children.Add(btn);
        }
    }

    private void SwitchProfile_Click(object sender, RoutedEventArgs e) => ShowStage("profiles");

    private void SignOut_Click(object sender, RoutedEventArgs e)
    {
        _backend.SignOut();
        ShowStage("auth");
    }

    private void RootGrid_KeyDown(object sender, KeyRoutedEventArgs e)
    {
        if (e.Key == VirtualKey.F)
        {
            _isFullScreen = !_isFullScreen;
            AppWindow.SetPresenter(_isFullScreen ? AppWindowPresenterKind.FullScreen : AppWindowPresenterKind.Default);
        }
        else if (e.Key == VirtualKey.Escape && PlayerPanel.Visibility == Visibility.Visible)
        {
            ClosePlayer_Click(sender, e);
        }
    }
}
