using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.UI;
using Microsoft.UI.Windowing;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Media.Imaging;
using Microsoft.Web.WebView2.Core;
using SingularityTV.Desktop.Services;
using Windows.System;

namespace SingularityTV.Desktop;

public sealed partial class MainWindow : Window
{
    private readonly DesktopBackendService _backend = new();
    private string? _currentStreamUrl;
    private bool _isFullScreen;
    private static readonly string[] BlockedAdDomains =
    {
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "googletagmanager.com", "google-analytics.com", "popads.net", "popcash.net",
        "propellerads.com", "adsterra.com", "adskeeper.com", "mgid.com", "taboola.com",
        "outbrain.com", "exoclick.com", "juicyads.com", "trafficjunky.com", "histats.com",
        "4rabet", "1xbet", "betway", "onclickalgo", "adsco.re", "a-ads.com"
    };

    public MainWindow()
    {
        InitializeComponent();
        Title = "SingularityTV 1.1.6";
        _ = BootstrapAsync();
    }

    private async Task BootstrapAsync()
    {
        if (_backend.Session == null)
        {
            ShowStage("auth");
            return;
        }
        var ok = await _backend.CheckTelegramGateAsync();
        if (!ok)
        {
            ShowStage("telegram");
            return;
        }
        await _backend.LoadProfilesAsync();
        RenderProfiles();
        ShowStage("profiles");
    }

    private void ShowStage(string stage)
    {
        AuthPanel.Visibility = stage == "auth" ? Visibility.Visible : Visibility.Collapsed;
        TelegramPanel.Visibility = stage == "telegram" ? Visibility.Visible : Visibility.Collapsed;
        ProfilesPanel.Visibility = stage == "profiles" ? Visibility.Visible : Visibility.Collapsed;
        MainNavView.Visibility = stage == "main" ? Visibility.Visible : Visibility.Collapsed;
    }

    private async void SignInButton_Click(object sender, RoutedEventArgs e)
    {
        AuthErrorText.Visibility = Visibility.Collapsed;
        var (ok, err) = await _backend.SignInAsync(EmailBox.Text.Trim(), PasswordBox.Password);
        if (!ok)
        {
            AuthErrorText.Text = err ?? "Sign in failed";
            AuthErrorText.Visibility = Visibility.Visible;
            return;
        }
        await BootstrapAsync();
    }

    private async void VerifyTelegram_Click(object sender, RoutedEventArgs e)
    {
        if (await _backend.CheckTelegramGateAsync())
        {
            await _backend.LoadProfilesAsync();
            RenderProfiles();
            ShowStage("profiles");
        }
    }

    private void RenderProfiles()
    {
        ProfilesListPanel.Children.Clear();
        foreach (var profile in _backend.Profiles)
        {
            var btn = new Button
            {
                Content = profile.Name,
                Width = 120,
                Height = 120,
                FontSize = 18,
                Background = new SolidColorBrush(ColorHelper.FromArgb(255, 229, 9, 20)),
                Foreground = new SolidColorBrush(Colors.White)
            };
            btn.Click += async (_, _) =>
            {
                await _backend.SelectProfileAsync(profile);
                ShowStage("main");
                await LoadHomeAsync();
            };
            ProfilesListPanel.Children.Add(btn);
        }
    }

    private async Task LoadHomeAsync()
    {
        HomeRowsPanel.Children.Clear();
        var trending = await _backend.FetchTmdbListAsync("trending/all/week?language=en-US");
        var movies = await _backend.FetchTmdbListAsync("movie/popular?language=en-US", "movie");
        var series = await _backend.FetchTmdbListAsync("tv/popular?language=en-US", "tv");
        AddMediaRow("Trending Now", trending);
        AddMediaRow("Popular Movies", movies);
        AddMediaRow("Popular Series", series);
    }

    private void AddMediaRow(string title, List<MediaItemDto> items)
    {
        var header = new TextBlock { Text = title, Foreground = new SolidColorBrush(Colors.White), FontSize = 20, FontWeight = Microsoft.UI.Text.FontWeights.Bold };
        HomeRowsPanel.Children.Add(header);

        var row = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 14 };
        foreach (var item in items.Take(16))
        {
            var cardGrid = new Grid { Width = 150, Height = 225, CornerRadius = new CornerRadius(8) };
            if (!string.IsNullOrEmpty(item.PosterUrl))
            {
                cardGrid.Children.Add(new Image { Source = new BitmapImage(new Uri(item.PosterUrl)), Stretch = Stretch.UniformToFill });
            }
            if (item.IsArabicOrGulfContent)
            {
                cardGrid.Children.Add(new Border
                {
                    Background = new SolidColorBrush(ColorHelper.FromArgb(190, 0, 0, 0)),
                    CornerRadius = new CornerRadius(10),
                    Padding = new Thickness(6, 2, 6, 2),
                    Margin = new Thickness(6),
                    HorizontalAlignment = HorizontalAlignment.Left,
                    VerticalAlignment = VerticalAlignment.Top,
                    Child = new TextBlock { Text = "May Not Stream", Foreground = new SolidColorBrush(Colors.White), FontSize = 10 }
                });
            }
            var btn = new Button
            {
                Content = cardGrid,
                Padding = new Thickness(0),
                Background = new SolidColorBrush(Colors.Transparent),
                BorderThickness = new Thickness(0)
            };
            ToolTipService.SetToolTip(btn, item.DisplayTitle);
            btn.Click += async (_, _) => await OpenPlayerAsync(item);
            row.Children.Add(btn);
        }

        HomeRowsPanel.Children.Add(new ScrollViewer
        {
            HorizontalScrollMode = ScrollMode.Enabled,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
            VerticalScrollMode = ScrollMode.Disabled,
            Content = row
        });
    }

    private async Task OpenPlayerAsync(MediaItemDto item)
    {
        _currentStreamUrl = item.BuildStreamUrl();
        PlayerErrorTitle.Text = item.DisplayTitle;
        PlayerErrorPanel.Visibility = Visibility.Collapsed;
        PlayerPanel.Visibility = Visibility.Visible;

        await PlayerWebView.EnsureCoreWebView2Async();
        var core = PlayerWebView.CoreWebView2;
        core.NewWindowRequested += (_, args) => { args.Handled = true; };
        core.AddWebResourceRequestedFilter("*", CoreWebView2WebResourceContext.All);
        core.WebResourceRequested += (_, args) =>
        {
            var uri = args.Request.Uri.ToLowerInvariant();
            if (BlockedAdDomains.Any(d => uri.Contains(d)))
            {
                args.Response = core.Environment.CreateWebResourceResponse(null, 403, "Blocked", "");
            }
        };
        core.NavigationStarting += (_, args) =>
        {
            if (Uri.TryCreate(args.Uri, UriKind.Absolute, out var u) && !u.Host.Contains("vidly", StringComparison.OrdinalIgnoreCase))
            {
                args.Cancel = true;
            }
        };
        core.NavigationCompleted += (_, args) =>
        {
            if (!args.IsSuccess)
            {
                PlayerErrorPanel.Visibility = Visibility.Visible;
            }
        };
        PlayerWebView.Source = new Uri(_currentStreamUrl);
    }

    private void RetryPlayer_Click(object sender, RoutedEventArgs e)
    {
        if (_currentStreamUrl == null) return;
        PlayerErrorPanel.Visibility = Visibility.Collapsed;
        PlayerWebView.Source = new Uri(_currentStreamUrl);
    }

    private void ClosePlayer_Click(object sender, RoutedEventArgs e)
    {
        PlayerPanel.Visibility = Visibility.Collapsed;
        PlayerWebView.Source = new Uri("about:blank");
    }

    private async void MainNavView_SelectionChanged(NavigationView sender, NavigationViewSelectionChangedEventArgs args)
    {
        var tag = (args.SelectedItem as NavigationViewItem)?.Tag?.ToString();
        if (tag == "profiles")
        {
            ShowStage("profiles");
            return;
        }
        HomeScroll.Visibility = tag == "home" ? Visibility.Visible : Visibility.Collapsed;
        SearchPanel.Visibility = tag == "search" ? Visibility.Visible : Visibility.Collapsed;
        if (tag == "search" && string.IsNullOrWhiteSpace(SearchBox.Text))
        {
            SearchRepeater.ItemsSource = await _backend.FetchTmdbListAsync("trending/all/week?language=en-US");
        }
    }

    private async void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
    {
        var q = SearchBox.Text.Trim();
        if (q.Length < 2) return;
        var results = await _backend.FetchTmdbListAsync($"search/multi?query={Uri.EscapeDataString(q)}&include_adult=false&language=en-US");
        SearchRepeater.ItemsSource = results.Select(r =>
        {
            var b = new Button { Content = r.DisplayTitle, Margin = new Thickness(4) };
            b.Click += async (_, _) => await OpenPlayerAsync(r);
            return b;
        }).ToList();
    }

    private void SignOut_Click(object sender, RoutedEventArgs e)
    {
        _backend.SignOut();
        ShowStage("auth");
    }

    private void RootGrid_KeyDown(object sender, KeyRoutedEventArgs e)
    {
        if (e.Key == VirtualKey.F)
        {
            _isFullScreen = !_isFullScreen;
            AppWindow.SetPresenter(_isFullScreen ? AppWindowPresenterKind.FullScreen : AppWindowPresenterKind.Default);
        }
        else if (e.Key == VirtualKey.Escape && PlayerPanel.Visibility == Visibility.Visible)
        {
            ClosePlayer_Click(sender, e);
        }
    }
}
