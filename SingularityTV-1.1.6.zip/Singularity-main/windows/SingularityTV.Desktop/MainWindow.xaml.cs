using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.UI;
using Microsoft.UI.Windowing;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Media.Imaging;
using Microsoft.Web.WebView2.Core;
using SingularityTV.Desktop.Services;
using Windows.System;

namespace SingularityTV.Desktop;

public sealed partial class MainWindow : Window
{
    private readonly DesktopBackendService _backend = new();
    private string? _currentStreamUrl;
    private bool _isFullScreen;
    private string _homeScope = "all";

    private static readonly string[] BlockedAdDomains =
    {
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "googletagmanager.com", "google-analytics.com", "popads.net", "popcash.net",
        "propellerads.com", "adsterra.com", "adskeeper.com", "mgid.com", "taboola.com",
        "outbrain.com", "exoclick.com", "juicyads.com", "trafficjunky.com", "histats.com",
        "4rabet", "1xbet", "betway", "onclickalgo", "adsco.re", "a-ads.com"
    };

    public MainWindow()
    {
        InitializeComponent();
        Title = "SingularityTV 1.1.6";
        _ = BootstrapAsync();
    }

    private async Task BootstrapAsync()
    {
        if (_backend.Session == null)
        {
            ShowStage("auth");
            return;
        }
        var ok = await _backend.CheckTelegramGateAsync();
        if (!ok)
        {
            ShowStage("telegram");
            return;
        }
        await _backend.LoadProfilesAsync();
        RenderProfiles();
        ShowStage("profiles");
    }

    private void ShowStage(string stage)
    {
        AuthPanel.Visibility = stage == "auth" ? Visibility.Visible : Visibility.Collapsed;
        TelegramPanel.Visibility = stage == "telegram" ? Visibility.Visible : Visibility.Collapsed;
        ProfilesPanel.Visibility = stage == "profiles" ? Visibility.Visible : Visibility.Collapsed;
        MainNavView.Visibility = stage == "main" ? Visibility.Visible : Visibility.Collapsed;
    }

    private async void SignInButton_Click(object sender, RoutedEventArgs e)
    {
        AuthErrorBanner.Visibility = Visibility.Collapsed;
        var (ok, err) = await _backend.SignInAsync(EmailBox.Text.Trim(), PasswordBox.Password);
        if (!ok)
        {
            AuthErrorText.Text = err ?? "Sign in failed";
            AuthErrorBanner.Visibility = Visibility.Visible;
            return;
        }
        await BootstrapAsync();
    }

    private async void VerifyTelegram_Click(object sender, RoutedEventArgs e)
    {
        if (await _backend.CheckTelegramGateAsync())
        {
            await _backend.LoadProfilesAsync();
            RenderProfiles();
            ShowStage("profiles");
        }
    }

    private void RenderProfiles()
    {
        ProfilesListPanel.Children.Clear();
        foreach (var profile in _backend.Profiles)
        {
            var btn = new Button
            {
                Content = profile.Name,
                Width = 120,
                Height = 120,
                FontSize = 18,
                Background = new SolidColorBrush(ColorHelper.FromArgb(255, 229, 9, 20)),
                Foreground = new SolidColorBrush(Colors.White)
            };
            btn.Click += async (_, _) =>
            {
                await _backend.SelectProfileAsync(profile);
                ShowStage("main");
                PopulateSettingsUI();
                await LoadHomeAsync();
            };
            ProfilesListPanel.Children.Add(btn);
        }
    }

    private async Task LoadHomeAsync()
    {
        HomeRowsPanel.Children.Clear();
        var trending = await _backend.FetchTmdbListAsync("trending/all/week?language=en-US");
        var nowPlaying = await _backend.FetchTmdbListAsync("movie/now_playing?language=en-US&page=1", "movie");
        var onAir = await _backend.FetchTmdbListAsync("tv/on_the_air?language=en-US&page=1", "tv");
        var movies = await _backend.FetchTmdbListAsync("movie/popular?language=en-US&page=1", "movie");
        var series = await _backend.FetchTmdbListAsync("tv/popular?language=en-US&page=1", "tv");

        var filteredTrending = _homeScope switch
        {
            "series" => trending.Where(x => !x.IsMovie).ToList(),
            "films" => trending.Where(x => x.IsMovie).ToList(),
            _ => trending
        };

        if (filteredTrending.FirstOrDefault() is { } hero)
        {
            AddHeroBanner(hero);
        }
        AddMediaRow("Top 10 Today", filteredTrending.Take(10).ToList());
        if (_homeScope != "series" && nowPlaying.Count > 0) AddMediaRow("New Releases", nowPlaying);
        if (_homeScope != "films" && onAir.Count > 0) AddMediaRow("New Episodes", onAir);
        if (_homeScope != "series") AddMediaRow("Popular Movies", movies);
        if (_homeScope != "films") AddMediaRow("Popular Series", series);
        if (_backend.MyList.Count > 0) AddMediaRow("My List", _backend.MyList);
    }

    private void AddHeroBanner(MediaItemDto hero)
    {
        var grid = new Grid { Height = 320, CornerRadius = new CornerRadius(12) };
        if (!string.IsNullOrEmpty(hero.BackdropUrl))
        {
            grid.Children.Add(new Image { Source = new BitmapImage(new Uri(hero.BackdropUrl)), Stretch = Stretch.UniformToFill, Opacity = 0.65 });
        }
        var info = new StackPanel { VerticalAlignment = VerticalAlignment.Bottom, Margin = new Thickness(24), Spacing = 10, MaxWidth = 520, HorizontalAlignment = HorizontalAlignment.Left };
        info.Children.Add(new TextBlock { Text = hero.DisplayTitle, Foreground = new SolidColorBrush(Colors.White), FontSize = 30, FontWeight = Microsoft.UI.Text.FontWeights.Black });
        info.Children.Add(new TextBlock { Text = hero.Overview, Foreground = new SolidColorBrush(Colors.LightGray), MaxLines = 2, TextWrapping = TextWrapping.Wrap });
        var btns = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 10 };
        var playBtn = new Button { Content = "Play", Background = new SolidColorBrush(Colors.White), Foreground = new SolidColorBrush(Colors.Black) };
        playBtn.Click += async (_, _) => await OpenPlayerAsync(hero);
        var detBtn = new Button { Content = "Details & More" };
        detBtn.Click += async (_, _) => await OpenDetailAsync(hero);
        btns.Children.Add(playBtn);
        btns.Children.Add(detBtn);
        info.Children.Add(btns);
        grid.Children.Add(info);
        HomeRowsPanel.Children.Add(grid);
    }

    private void AddMediaRow(string title, List<MediaItemDto> items)
    {
        var header = new TextBlock { Text = title, Foreground = new SolidColorBrush(Colors.White), FontSize = 20, FontWeight = Microsoft.UI.Text.FontWeights.Bold };
        HomeRowsPanel.Children.Add(header);

        var row = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 14 };
        foreach (var item in items.Take(16))
        {
            var cardGrid = new Grid { Width = 150, Height = 225, CornerRadius = new CornerRadius(8) };
            if (!string.IsNullOrEmpty(item.PosterUrl))
            {
                cardGrid.Children.Add(new Image { Source = new BitmapImage(new Uri(item.PosterUrl)), Stretch = Stretch.UniformToFill });
            }
            if (item.IsArabicOrGulfContent)
            {
                cardGrid.Children.Add(new Border
                {
                    Background = new SolidColorBrush(ColorHelper.FromArgb(190, 0, 0, 0)),
                    CornerRadius = new CornerRadius(10),
                    Padding = new Thickness(6, 2, 6, 2),
                    Margin = new Thickness(6),
                    HorizontalAlignment = HorizontalAlignment.Left,
                    VerticalAlignment = VerticalAlignment.Top,
                    Child = new TextBlock { Text = "May Not Stream", Foreground = new SolidColorBrush(Colors.White), FontSize = 10 }
                });
            }
            var btn = new Button
            {
                Content = cardGrid,
                Padding = new Thickness(0),
                Background = new SolidColorBrush(Colors.Transparent),
                BorderThickness = new Thickness(0)
            };
            ToolTipService.SetToolTip(btn, item.DisplayTitle);
            btn.Click += async (_, _) => await OpenDetailAsync(item);
            row.Children.Add(btn);
        }

        HomeRowsPanel.Children.Add(new ScrollViewer
        {
            HorizontalScrollMode = ScrollMode.Enabled,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
            VerticalScrollMode = ScrollMode.Disabled,
            Content = row
        });
    }

    private async Task OpenDetailAsync(MediaItemDto item)
    {
        DetailContentPanel.Children.Clear();
        DetailPanel.Visibility = Visibility.Visible;

        var backBtn = new Button { Content = "← Back" };
        backBtn.Click += (_, _) => DetailPanel.Visibility = Visibility.Collapsed;
        DetailContentPanel.Children.Add(backBtn);

        var detail = await _backend.FetchTitleDetailAsync(item.MediaType, item.Id);

        var heroGrid = new Grid { Height = 340, CornerRadius = new CornerRadius(12) };
        if (!string.IsNullOrEmpty(item.BackdropUrl))
        {
            heroGrid.Children.Add(new Image { Source = new BitmapImage(new Uri(item.BackdropUrl)), Stretch = Stretch.UniformToFill, Opacity = 0.55 });
        }
        var heroOverlay = new StackPanel { VerticalAlignment = VerticalAlignment.Bottom, Margin = new Thickness(24), Spacing = 8 };
        heroOverlay.Children.Add(new TextBlock { Text = item.DisplayTitle, Foreground = new SolidColorBrush(Colors.White), FontSize = 32, FontWeight = Microsoft.UI.Text.FontWeights.Black });
        var origTitle = item.IsMovie ? detail?.OriginalTitle : detail?.OriginalName;
        if (!string.IsNullOrWhiteSpace(origTitle) && origTitle != item.DisplayTitle)
        {
            heroOverlay.Children.Add(new TextBlock { Text = origTitle, Foreground = new SolidColorBrush(Colors.LightGray), FontSize = 14 });
        }
        if (!string.IsNullOrWhiteSpace(detail?.Tagline))
        {
            heroOverlay.Children.Add(new TextBlock { Text = detail!.Tagline, Foreground = new SolidColorBrush(Colors.Silver), FontSize = 14 });
        }
        var metaParts = new List<string>();
        if (item.MatchPercent is int mp) metaParts.Add($"{mp}% Match");
        if (!string.IsNullOrEmpty(item.DisplayYear)) metaParts.Add(item.DisplayYear);
        var cert = detail?.UsCertification(item.IsMovie);
        if (!string.IsNullOrWhiteSpace(cert)) metaParts.Add(cert!);
        if (item.IsMovie && detail?.Runtime is > 0) metaParts.Add($"{detail.Runtime.Value / 60}h {detail.Runtime.Value % 60}m");
        if (!item.IsMovie && detail?.NumberOfSeasons is > 0) metaParts.Add($"{detail.NumberOfSeasons} Seasons");
        if (!string.IsNullOrWhiteSpace(detail?.Status)) metaParts.Add(detail!.Status!);
        if (metaParts.Count > 0)
        {
            heroOverlay.Children.Add(new TextBlock { Text = string.Join("  •  ", metaParts), Foreground = new SolidColorBrush(ColorHelper.FromArgb(255, 69, 212, 120)), FontSize = 13, FontWeight = Microsoft.UI.Text.FontWeights.SemiBold });
        }
        heroGrid.Children.Add(heroOverlay);
        DetailContentPanel.Children.Add(heroGrid);

        if (item.IsArabicOrGulfContent)
        {
            DetailContentPanel.Children.Add(new TextBlock { Text = "Arabic/Gulf titles may have limited availability on external servers.", Foreground = new SolidColorBrush(Colors.Orange), FontSize = 13 });
        }
        DetailContentPanel.Children.Add(new TextBlock { Text = item.Overview, Foreground = new SolidColorBrush(Colors.LightGray), TextWrapping = TextWrapping.Wrap, FontSize = 15 });

        var cast = detail?.Credits?.Cast.Take(14).ToList() ?? new();
        if (cast.Count > 0)
        {
            DetailContentPanel.Children.Add(new TextBlock { Text = $"Starring: {string.Join(", ", cast.Take(4).Select(c => c.Name))}", Foreground = new SolidColorBrush(Colors.Gray), FontSize = 13 });
        }
        var dir = detail?.DirectorOrCreators(item.IsMovie);
        if (!string.IsNullOrWhiteSpace(dir))
        {
            DetailContentPanel.Children.Add(new TextBlock { Text = $"{(item.IsMovie ? "Director" : "Creators")}: {dir}", Foreground = new SolidColorBrush(Colors.Gray), FontSize = 13 });
        }

        var actions = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 10 };
        var relDate = item.ReleaseDateParsed;
        if (item.ReleaseStatus == ReleaseStatus.Upcoming && relDate.HasValue)
        {
            DetailContentPanel.Children.Add(new TextBlock { Text = SingularityDateHelper.ComingLabel(relDate.Value, item.IsMovie), Foreground = new SolidColorBrush(Colors.White), FontSize = 16, FontWeight = Microsoft.UI.Text.FontWeights.SemiBold });
            var remBtn = new Button { Content = _backend.HasReminder(item) ? "Reminder Set" : "Remind Me", Background = new SolidColorBrush(Colors.White), Foreground = new SolidColorBrush(Colors.Black) };
            remBtn.Click += (_, _) =>
            {
                var added = _backend.ToggleReminder(item, relDate.Value);
                remBtn.Content = added ? "Reminder Set" : "Remind Me";
            };
            actions.Children.Add(remBtn);
        }
        else
        {
            var playBtn = new Button { Content = "▶ Play", Background = new SolidColorBrush(Colors.White), Foreground = new SolidColorBrush(Colors.Black) };
            playBtn.Click += async (_, _) => await OpenPlayerAsync(item);
            actions.Children.Add(playBtn);
        }

        var trailer = detail?.Videos?.Results.FirstOrDefault(v => v.IsYouTube && v.Type.Equals("Trailer", StringComparison.OrdinalIgnoreCase))
            ?? detail?.Videos?.Results.FirstOrDefault(v => v.IsYouTube);
        if (trailer != null && !string.IsNullOrEmpty(trailer.WatchUrl))
        {
            var trBtn = new Button { Content = "Trailer" };
            trBtn.Click += async (_, _) => await Windows.System.Launcher.LaunchUriAsync(new Uri(trailer.WatchUrl));
            actions.Children.Add(trBtn);
        }

        var listBtn = new Button { Content = _backend.MyList.Any(x => x.Id == item.Id && x.MediaType == item.MediaType) ? "✓ My List" : "+ My List" };
        listBtn.Click += (_, _) =>
        {
            _backend.ToggleMyList(item);
            listBtn.Content = _backend.MyList.Any(x => x.Id == item.Id && x.MediaType == item.MediaType) ? "✓ My List" : "+ My List";
        };
        actions.Children.Add(listBtn);

        var rateBtn = new Button { Content = _backend.Liked.Any(x => x.Id == item.Id && x.MediaType == item.MediaType) ? "Rated" : "Rate" };
        rateBtn.Click += (_, _) =>
        {
            _backend.ToggleLike(item);
            rateBtn.Content = _backend.Liked.Any(x => x.Id == item.Id && x.MediaType == item.MediaType) ? "Rated" : "Rate";
        };
        actions.Children.Add(rateBtn);
        DetailContentPanel.Children.Add(actions);

        if (cast.Count > 0)
        {
            DetailContentPanel.Children.Add(new TextBlock { Text = "Cast & Crew", Foreground = new SolidColorBrush(Colors.White), FontSize = 18, FontWeight = Microsoft.UI.Text.FontWeights.Bold });
            var castRow = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 14 };
            foreach (var p in cast)
            {
                var card = new StackPanel { Width = 100, Spacing = 4 };
                if (!string.IsNullOrEmpty(p.ProfileUrl))
                {
                    card.Children.Add(new Image { Source = new BitmapImage(new Uri(p.ProfileUrl)), Width = 80, Height = 80, Stretch = Stretch.UniformToFill });
                }
                card.Children.Add(new TextBlock { Text = p.Name, Foreground = new SolidColorBrush(Colors.White), FontSize = 12, FontWeight = Microsoft.UI.Text.FontWeights.SemiBold, TextTrimming = TextTrimming.CharacterEllipsis });
                if (!string.IsNullOrWhiteSpace(p.Character))
                {
                    card.Children.Add(new TextBlock { Text = p.Character, Foreground = new SolidColorBrush(Colors.Gray), FontSize = 11, TextTrimming = TextTrimming.CharacterEllipsis });
                }
                castRow.Children.Add(card);
            }
            DetailContentPanel.Children.Add(new ScrollViewer { HorizontalScrollMode = ScrollMode.Enabled, HorizontalScrollBarVisibility = ScrollBarVisibility.Auto, VerticalScrollMode = ScrollMode.Disabled, Content = castRow });
        }

        if (!item.IsMovie)
        {
            var seasons = detail?.Seasons.Where(s => s.SeasonNumber > 0).ToList() ?? new();
            var episodesHost = new StackPanel { Spacing = 8 };
            async Task LoadSeasonAsync(int seasonNum)
            {
                episodesHost.Children.Clear();
                var eps = await _backend.FetchSeasonEpisodesAsync(item.Id, seasonNum);
                foreach (var ep in eps)
                {
                    var aired = ep.HasAired;
                    var epLabel = aired
                        ? $"{ep.EpisodeNumber}. {ep.Name} {(ep.Runtime is > 0 ? $"({ep.Runtime}m)" : "")}"
                        : $"{ep.EpisodeNumber}. {ep.Name} (Coming {ep.AirDate})";
                    var epBtn = new Button
                    {
                        Content = epLabel,
                        IsEnabled = aired,
                        HorizontalAlignment = HorizontalAlignment.Stretch,
                        HorizontalContentAlignment = HorizontalAlignment.Left
                    };
                    epBtn.Click += async (_, _) => await OpenPlayerAsync(item, seasonNum, ep.EpisodeNumber);
                    episodesHost.Children.Add(epBtn);
                }
            }
            if (seasons.Count > 0)
            {
                var seasonRow = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
                foreach (var s in seasons)
                {
                    var sBtn = new Button { Content = s.DisplayName };
                    sBtn.Click += async (_, _) => await LoadSeasonAsync(s.SeasonNumber);
                    seasonRow.Children.Add(sBtn);
                }
                DetailContentPanel.Children.Add(seasonRow);
                await LoadSeasonAsync(seasons[0].SeasonNumber);
            }
            else
            {
                await LoadSeasonAsync(1);
            }
            DetailContentPanel.Children.Add(episodesHost);
        }

        var related = (detail?.Recommendations?.Results ?? new()).Concat(detail?.Similar?.Results ?? new())
            .Where(r => r.Id != item.Id && !string.IsNullOrEmpty(r.PosterPath))
            .GroupBy(r => $"{r.MediaType}-{r.Id}")
            .Select(g => g.First())
            .Take(12)
            .ToList();
        if (related.Count > 0)
        {
            DetailContentPanel.Children.Add(new TextBlock { Text = "More Like This", Foreground = new SolidColorBrush(Colors.White), FontSize = 18, FontWeight = Microsoft.UI.Text.FontWeights.Bold });
            var relRow = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 12 };
            foreach (var r in related)
            {
                if (string.IsNullOrEmpty(r.MediaType)) r.MediaType = item.MediaType;
                var rb = new Button
                {
                    Content = new Image { Source = new BitmapImage(new Uri(r.PosterUrl)), Width = 120, Height = 180, Stretch = Stretch.UniformToFill },
                    Padding = new Thickness(0),
                    Background = new SolidColorBrush(Colors.Transparent),
                    BorderThickness = new Thickness(0)
                };
                rb.Click += async (_, _) => await OpenDetailAsync(r);
                relRow.Children.Add(rb);
            }
            DetailContentPanel.Children.Add(new ScrollViewer { HorizontalScrollMode = ScrollMode.Enabled, HorizontalScrollBarVisibility = ScrollBarVisibility.Auto, VerticalScrollMode = ScrollMode.Disabled, Content = relRow });
        }
    }

    private async Task OpenPlayerAsync(MediaItemDto item, int season = 1, int episode = 1)
    {
        _currentStreamUrl = item.BuildStreamUrl(_backend.AppSettings.StreamingProviderBaseURL, _backend.AppSettings.AccentColorHex, season, episode);
        PlayerErrorTitle.Text = item.DisplayTitle;
        PlayerErrorPanel.Visibility = Visibility.Collapsed;
        PlayerPanel.Visibility = Visibility.Visible;

        await PlayerWebView.EnsureCoreWebView2Async();
        var core = PlayerWebView.CoreWebView2;
        core.NewWindowRequested += (_, args) => { args.Handled = true; };
        core.AddWebResourceRequestedFilter("*", CoreWebView2WebResourceContext.All);
        core.WebResourceRequested += (_, args) =>
        {
            var uri = args.Request.Uri.ToLowerInvariant();
            if (BlockedAdDomains.Any(d => uri.Contains(d)))
            {
                args.Response = core.Environment.CreateWebResourceResponse(null, 403, "Blocked", "");
            }
        };
        core.NavigationStarting += (_, args) =>
        {
            if (Uri.TryCreate(args.Uri, UriKind.Absolute, out var u) && !u.Host.Contains("vidly", StringComparison.OrdinalIgnoreCase))
            {
                args.Cancel = true;
            }
        };
        core.WebMessageReceived += (_, args) =>
        {
            try
            {
                using var doc = JsonDocument.Parse(args.TryGetWebMessageAsString());
                var type = doc.RootElement.GetProperty("type").GetString();
                if (type == "pref")
                {
                    var p = doc.RootElement.GetProperty("payload");
                    var k = p.GetProperty("key").GetString();
                    var v = p.GetProperty("value").GetString() ?? "";
                    if (k == "preferredQuality") _backend.PlayerPrefs.PreferredQuality = v;
                    else if (k == "subtitleLanguage") _backend.PlayerPrefs.SubtitleLanguage = v;
                    else if (k == "playbackSpeed") _backend.PlayerPrefs.PlaybackSpeed = v;
                    _ = _backend.PushActiveProfileAsync();
                }
                else if (type == "error")
                {
                    PlayerErrorPanel.Visibility = Visibility.Visible;
                }
            }
            catch { }
        };
        core.NavigationCompleted += async (_, args) =>
        {
            if (!args.IsSuccess)
            {
                PlayerErrorPanel.Visibility = Visibility.Visible;
                return;
            }
            var jsPath = Path.Combine(AppContext.BaseDirectory, "Assets", "WebPlayer", "vidly-player.js");
            var cssPath = Path.Combine(AppContext.BaseDirectory, "Assets", "WebPlayer", "vidly-player.css");
            var js = File.Exists(jsPath) ? File.ReadAllText(jsPath) : "";
            var css = File.Exists(cssPath) ? File.ReadAllText(cssPath).Replace("\\", "\\\\").Replace("'", "\\'").Replace("\n", "\\n") : "";
            var prefsJson = JsonSerializer.Serialize(_backend.PlayerPrefs);
            var metaJson = JsonSerializer.Serialize(new { title = item.DisplayTitle, isMovie = item.IsMovie, subtitle = item.IsMovie ? "" : $"S{season}:E{episode}", poster = item.PosterUrl });
            var initScript = $"document.documentElement.style.setProperty('--sg-accent', '#{_backend.AppSettings.AccentColorHex}'); var st = document.createElement('style'); st.textContent = '{css}'; document.head.appendChild(st); window.__singularityMeta = {metaJson}; window.__sgIsTV = false; window.__sgSavedPrefs = {prefsJson}; {js}";
            await core.ExecuteScriptAsync(initScript);
        };
        PlayerWebView.Source = new Uri(_currentStreamUrl);
    }

    private void PopulateSettingsUI()
    {
        SettingsAccountInfo.Text = $"Profile: {_backend.ActiveProfile?.Name ?? "Main"} · {_backend.Session?.Email ?? ""}";
        ServerHostBox.Text = _backend.AppSettings.StreamingProviderBaseURL;
        TmdbKeyBox.Text = _backend.AppSettings.CustomTmdbToken;
        QualityCombo.SelectedItem = _backend.PlayerPrefs.PreferredQuality;
        SubtitleCombo.SelectedItem = _backend.PlayerPrefs.SubtitleLanguage;

        AccentSwatchesPanel.Children.Clear();
        foreach (var preset in SingularityConstants.AccentPresets)
        {
            var b = new Button { Content = preset.Name, Tag = preset.Hex };
            b.Click += (_, _) =>
            {
                _backend.AppSettings.AccentColorHex = preset.Hex;
                _backend.SaveAppSettings();
            };
            AccentSwatchesPanel.Children.Add(b);
        }
    }

    private void SaveServer_Click(object sender, RoutedEventArgs e)
    {
        _backend.AppSettings.StreamingProviderBaseURL = ServerHostBox.Text.Trim();
        _backend.SaveAppSettings();
    }

    private void SaveTmdbKey_Click(object sender, RoutedEventArgs e)
    {
        _backend.AppSettings.CustomTmdbToken = TmdbKeyBox.Text.Trim();
        _backend.SaveAppSettings();
    }

    private void QualityCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (QualityCombo.SelectedItem is string q)
        {
            _backend.PlayerPrefs.PreferredQuality = q;
            _ = _backend.PushActiveProfileAsync();
        }
    }

    private void SubtitleCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (SubtitleCombo.SelectedItem is string s)
        {
            _backend.PlayerPrefs.SubtitleLanguage = s;
            _ = _backend.PushActiveProfileAsync();
        }
    }

    private void DeleteHistory_Click(object sender, RoutedEventArgs e)
    {
        _backend.History.Clear();
        _ = _backend.PushActiveProfileAsync();
    }

    private async void FilterAll_Click(object sender, RoutedEventArgs e) { _homeScope = "all"; await LoadHomeAsync(); }
    private async void FilterSeries_Click(object sender, RoutedEventArgs e) { _homeScope = "series"; await LoadHomeAsync(); }
    private async void FilterFilms_Click(object sender, RoutedEventArgs e) { _homeScope = "films"; await LoadHomeAsync(); }

    private void RetryPlayer_Click(object sender, RoutedEventArgs e)
    {
        if (_currentStreamUrl == null) return;
        PlayerErrorPanel.Visibility = Visibility.Collapsed;
        PlayerWebView.Source = new Uri(_currentStreamUrl);
    }

    private void ClosePlayer_Click(object sender, RoutedEventArgs e)
    {
        PlayerPanel.Visibility = Visibility.Collapsed;
        PlayerWebView.Source = new Uri("about:blank");
    }

    private async void MainNavView_SelectionChanged(NavigationView sender, NavigationViewSelectionChangedEventArgs args)
    {
        DetailPanel.Visibility = Visibility.Collapsed;
        var tag = (args.SelectedItem as NavigationViewItem)?.Tag?.ToString();
        HomeScroll.Visibility = tag == "home" ? Visibility.Visible : Visibility.Collapsed;
        NewHotScroll.Visibility = tag == "newhot" ? Visibility.Visible : Visibility.Collapsed;
        SearchPanel.Visibility = tag == "search" ? Visibility.Visible : Visibility.Collapsed;
        MyPanel.Visibility = tag == "my" ? Visibility.Visible : Visibility.Collapsed;
        SettingsScroll.Visibility = tag == "settings" ? Visibility.Visible : Visibility.Collapsed;

        if (tag == "newhot")
        {
            NewHotPanel.Children.Clear();
            NewHotPanel.Children.Add(new TextBlock { Text = "Coming Soon", Foreground = new SolidColorBrush(Colors.White), FontSize = 24, FontWeight = Microsoft.UI.Text.FontWeights.Bold });
            var upcoming = await _backend.FetchUpcomingComingSoonAsync();
            foreach (var u in upcoming)
            {
                var relDate = u.ReleaseDateParsed;
                var row = new Grid { ColumnSpacing = 16, Margin = new Thickness(0, 6, 0, 12) };
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(64) });
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(240) });
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

                if (relDate.HasValue)
                {
                    var dateCol = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center };
                    dateCol.Children.Add(new TextBlock { Text = relDate.Value.ToString("MMM").ToUpperInvariant(), Foreground = new SolidColorBrush(Colors.LightGray), FontSize = 13, HorizontalAlignment = HorizontalAlignment.Center });
                    dateCol.Children.Add(new TextBlock { Text = relDate.Value.Day.ToString(), Foreground = new SolidColorBrush(Colors.White), FontSize = 28, FontWeight = Microsoft.UI.Text.FontWeights.Bold, HorizontalAlignment = HorizontalAlignment.Center });
                    Grid.SetColumn(dateCol, 0);
                    row.Children.Add(dateCol);
                }

                var imgBtn = new Button { Padding = new Thickness(0), Background = new SolidColorBrush(Colors.Transparent), BorderThickness = new Thickness(0) };
                if (!string.IsNullOrEmpty(u.BackdropUrl))
                {
                    imgBtn.Content = new Image { Source = new BitmapImage(new Uri(u.BackdropUrl)), Width = 240, Height = 135, Stretch = Stretch.UniformToFill };
                }
                imgBtn.Click += async (_, _) => await OpenDetailAsync(u);
                Grid.SetColumn(imgBtn, 1);
                row.Children.Add(imgBtn);

                var infoCol = new StackPanel { Spacing = 6 };
                infoCol.Children.Add(new TextBlock { Text = u.DisplayTitle, Foreground = new SolidColorBrush(Colors.White), FontSize = 18, FontWeight = Microsoft.UI.Text.FontWeights.Bold });
                if (relDate.HasValue)
                {
                    infoCol.Children.Add(new TextBlock { Text = SingularityDateHelper.ComingLabel(relDate.Value, u.IsMovie), Foreground = new SolidColorBrush(Colors.White), FontSize = 13, FontWeight = Microsoft.UI.Text.FontWeights.SemiBold });
                }
                infoCol.Children.Add(new TextBlock { Text = u.Overview, Foreground = new SolidColorBrush(Colors.LightGray), FontSize = 13, MaxLines = 3, TextWrapping = TextWrapping.Wrap });
                var btnBar = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
                var remBtn = new Button { Content = _backend.HasReminder(u) ? "Reminder Set" : "Remind Me" };
                remBtn.Click += (_, _) =>
                {
                    var d = relDate ?? DateTime.Today.AddDays(1);
                    remBtn.Content = _backend.ToggleReminder(u, d) ? "Reminder Set" : "Remind Me";
                };
                var infoBtn = new Button { Content = "Info" };
                infoBtn.Click += async (_, _) => await OpenDetailAsync(u);
                btnBar.Children.Add(remBtn);
                btnBar.Children.Add(infoBtn);
                infoCol.Children.Add(btnBar);
                Grid.SetColumn(infoCol, 2);
                row.Children.Add(infoCol);

                NewHotPanel.Children.Add(row);
            }
        }
        else if (tag == "my")
        {
            MyContentPanel.Children.Clear();
            MyContentPanel.Children.Add(new TextBlock { Text = $"{_backend.ActiveProfile?.Name ?? "Profile"} · {_backend.MyList.Count} in My List", Foreground = new SolidColorBrush(Colors.White), FontSize = 22, FontWeight = Microsoft.UI.Text.FontWeights.Bold });
            foreach (var m in _backend.MyList)
            {
                var btn = new Button { Content = m.DisplayTitle };
                btn.Click += async (_, _) => await OpenDetailAsync(m);
                MyContentPanel.Children.Add(btn);
            }
        }
    }

    private async void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
    {
        var q = SearchBox.Text.Trim();
        if (q.Length < 2) return;
        SearchResultsPanel.Children.Clear();
        var results = await _backend.FetchTmdbListAsync($"search/multi?query={Uri.EscapeDataString(q)}&include_adult=false&language=en-US");
        foreach (var r in results.Take(20))
        {
            var btn = new Button { Content = r.DisplayTitle };
            btn.Click += async (_, _) => await OpenDetailAsync(r);
            SearchResultsPanel.Children.Add(btn);
        }
    }

    private void SwitchProfile_Click(object sender, RoutedEventArgs e) => ShowStage("profiles");

    private void SignOut_Click(object sender, RoutedEventArgs e)
    {
        _backend.SignOut();
        ShowStage("auth");
    }

    private void RootGrid_KeyDown(object sender, KeyRoutedEventArgs e)
    {
        if (e.Key == VirtualKey.F)
        {
            _isFullScreen = !_isFullScreen;
            AppWindow.SetPresenter(_isFullScreen ? AppWindowPresenterKind.FullScreen : AppWindowPresenterKind.Default);
        }
        else if (e.Key == VirtualKey.Escape && PlayerPanel.Visibility == Visibility.Visible)
        {
            ClosePlayer_Click(sender, e);
        }
    }
}
