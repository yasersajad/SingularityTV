#ifndef ARCH
  #define ARCH "x64"
#endif

#if ARCH == "ARM64"
  #define ARCH_ALLOWED "arm64"
  #define ARCH_INSTALL "arm64"
  #define PUBLISH_DIR "..\SingularityTV.Desktop\bin\ARM64\Release\net8.0-windows10.0.19041.0\win-arm64\publish"
#else
  #define ARCH_ALLOWED "x64compatible"
  #define ARCH_INSTALL "x64compatible"
  #define PUBLISH_DIR "..\SingularityTV.Desktop\bin\x64\Release\net8.0-windows10.0.19041.0\win-x64\publish"
#endif

[Setup]
AppId={{8F9B3C12-4A7D-4C9E-9A11-7B2F0196E116}
AppName=SingularityTV
AppVersion=1.1.6
AppVerName=SingularityTV 1.1.6
AppPublisher=SingularityTV
DefaultDirName={autopf}\SingularityTV
DefaultGroupName=SingularityTV
AllowNoIcons=yes
OutputDir=output
OutputBaseFilename=SingularityTV-Desktop-1.1.6-Windows-{#ARCH}
Compression=lzma2/ultra64
SolidCompression=yes
WizardStyle=modern
ArchitecturesAllowed={#ARCH_ALLOWED}
ArchitecturesInstallIn64BitMode={#ARCH_INSTALL}

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "{cm:CreateDesktopIcon}"; GroupDescription: "{cm:AdditionalIcons}"

[Files]
Source: "{#PUBLISH_DIR}\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\SingularityTV"; Filename: "{app}\SingularityTV.exe"
Name: "{group}\{cm:UninstallProgram,SingularityTV}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\SingularityTV"; Filename: "{app}\SingularityTV.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\SingularityTV.exe"; Description: "{cm:LaunchProgram,SingularityTV}"; Flags: nowait postinstall skipifsilent
