# SingularityTV Design System (Canonical Reference: iOS)

## 1. Color Tokens
- **Canvas (`NF.canvas`)**: `#000000`
- **Surface (`NF.surface`)**: `#1C1C1C` (`Color(white: 0.11)`)
- **Surface Raised (`NF.surfaceRaised`)**: `#2B2B2B` (`Color(white: 0.17)`)
- **Card / Border**: `#1F1F1F`, Hairline `rgba(255,255,255,0.10)`
- **Text Primary**: `#FFFFFF`
- **Text Secondary**: `#B8B8B8` (`Color(white: 0.72)`)
- **Text Tertiary**: `#808080` (`Color(white: 0.50)`)
- **Positive Match**: `#45D478` (`rgb(0.27, 0.83, 0.47)`)
- **Default Accent (`Nightflix Red`)**: `#E50914`
- **Accent Palette Presets**:
  1. Singularity Red: `#E50914`
  2. Electric Blue: `#0071EB`
  3. Royal Purple: `#7C3AED`
  4. Emerald: `#059669`
  5. Amber Gold: `#D97706`
  6. Neon Pink: `#DB2777`
  7. Cyan: `#0891B2`
  8. Lime: `#65A30D`

## 2. Typography & Metrics
- **Gutter**: `16dp` / `16pt`
- **Poster Corner Radius**: `4dp` / `4pt` (Aspect Ratio `2:3` / `0.67`)
- **Card Corner Radius**: `6dp` / `6pt`
- **Button Corner Radius**: `5dp` / `5pt`
- **Headers**: Bold `19sp`–`26sp`; Display Hero Title: Heavy Condensed `28sp`–`34sp`

## 3. Shared Canonical Web Player
- Source: `Shared/WebPlayer/vidly-player.js` & `Shared/WebPlayer/vidly-player.css`
- Unified bridge protocol (`progress`, `pref`, `error`, `back`) across WKWebView (iOS), Android WebView (`SingularityBridge`), and Windows WebView2 (`postMessage`).
