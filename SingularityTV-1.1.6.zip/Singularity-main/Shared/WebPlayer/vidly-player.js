(function () {
    if (window.__sgCanonicalInitialized) return;
    window.__sgCanonicalInitialized = true;

    window.__sgSavedPrefs = window.__sgSavedPrefs || {};
    window.__sgAppliedQualitySrc = '';
    window.__sgAppliedSubSrc = '';
    window.__sgReportedPageError = false;

    function postToNative(type, payload) {
        try {
            if (window.webkit && window.webkit.messageHandlers) {
                if (type === 'back' && window.webkit.messageHandlers.vidlyBack) {
                    window.webkit.messageHandlers.vidlyBack.postMessage(true);
                } else if (type === 'pref' && window.webkit.messageHandlers.vidlyPrefsChanged) {
                    window.webkit.messageHandlers.vidlyPrefsChanged.postMessage(payload);
                } else if (type === 'error' && window.webkit.messageHandlers.vidlyError) {
                    window.webkit.messageHandlers.vidlyError.postMessage(payload);
                } else if (type === 'progress' && window.webkit.messageHandlers.vidlyProgress) {
                    window.webkit.messageHandlers.vidlyProgress.postMessage(payload);
                }
            }
        } catch (e) {}

        try {
            if (window.SingularityBridge) {
                if (type === 'back' && window.SingularityBridge.onRequestBack) {
                    window.SingularityBridge.onRequestBack();
                } else if (type === 'pref' && window.SingularityBridge.onPreference) {
                    window.SingularityBridge.onPreference(payload.key, payload.value);
                } else if (type === 'error' && window.SingularityBridge.onFatalError) {
                    window.SingularityBridge.onFatalError(payload);
                } else if (type === 'progress' && window.SingularityBridge.onProgressUpdate) {
                    window.SingularityBridge.onProgressUpdate(payload.currentTime, payload.duration);
                }
            }
        } catch (e) {}

        try {
            if (window.chrome && window.chrome.webview && window.chrome.webview.postMessage) {
                window.chrome.webview.postMessage(JSON.stringify({ type: type, payload: payload }));
            }
        } catch (e) {}
    }

    try { window.open = function () { return null; }; } catch (e) {}

    var noop = function () { return Promise.resolve(); };
    try {
        Element.prototype.requestFullscreen = noop;
        Element.prototype.webkitRequestFullscreen = noop;
        Element.prototype.webkitRequestFullScreen = noop;
        HTMLVideoElement.prototype.webkitEnterFullscreen = function () {};
        HTMLVideoElement.prototype.webkitEnterFullScreen = function () {};
        Document.prototype.exitFullscreen = noop;
        Document.prototype.webkitExitFullscreen = noop;
    } catch (e) {}

    function savePref(key, value) {
        window.__sgSavedPrefs[key] = value;
        postToNative('pref', { key: key, value: value });
    }

    function qualityTargetHeight(pref) {
        var p = (pref || '').toLowerCase();
        if (p.indexOf('2160') !== -1 || p.indexOf('4k') !== -1) return 2160;
        if (p.indexOf('1080') !== -1 || p.indexOf('cinematic') !== -1) return 1080;
        if (p.indexOf('720') !== -1 || p.indexOf('theatrical') !== -1) return 720;
        if (p.indexOf('480') !== -1 || p.indexOf('smooth') !== -1) return 480;
        if (p.indexOf('360') !== -1) return 360;
        return 0;
    }

    function applySavedPrefsToPlayer() {
        var prefs = window.__sgSavedPrefs || {};
        var v = document.querySelector('video');
        var srcKey = v ? (v.currentSrc || v.src || '') : '';

        if (prefs.preferredQuality && prefs.preferredQuality.toLowerCase() !== 'auto') {
            var targetH = qualityTargetHeight(prefs.preferredQuality);
            if (window.__sgHlsInstance && window.__sgHlsInstance.levels && window.__sgHlsInstance.levels.length > 0 && targetH > 0) {
                var levels = window.__sgHlsInstance.levels;
                var bestIdx = -1;
                var bestDiff = 999999;
                for (var i = 0; i < levels.length; i++) {
                    var h = levels[i].height || 0;
                    if (h > 0 && Math.abs(h - targetH) < bestDiff) {
                        bestDiff = Math.abs(h - targetH);
                        bestIdx = i;
                    }
                }
                if (bestIdx !== -1 && window.__sgHlsInstance.currentLevel !== bestIdx) {
                    window.__sgHlsInstance.currentLevel = bestIdx;
                }
            }
            if (srcKey && window.__sgAppliedQualitySrc !== srcKey) {
                var qBtns = document.querySelectorAll('[role="dialog"] button, [role="menu"] button');
                for (var qb = 0; qb < qBtns.length; qb++) {
                    var qt = (qBtns[qb].innerText || '').toLowerCase();
                    if (qt.indexOf(prefs.preferredQuality.toLowerCase()) !== -1 || (targetH > 0 && qt.indexOf(targetH + 'p') !== -1)) {
                        qBtns[qb].click();
                        window.__sgAppliedQualitySrc = srcKey;
                        break;
                    }
                }
            }
        }

        if (prefs.subtitleLanguage && v && v.textTracks && v.textTracks.length > 0 && window.__sgAppliedSubSrc !== srcKey) {
            var subPref = prefs.subtitleLanguage.toLowerCase();
            for (var t = 0; t < v.textTracks.length; t++) {
                var tr = v.textTracks[t];
                var lbl = ((tr.label || '') + ' ' + (tr.language || '')).toLowerCase();
                if (subPref === 'off' || subPref === 'none') {
                    tr.mode = 'disabled';
                } else if (lbl.indexOf(subPref) !== -1) {
                    tr.mode = 'showing';
                    window.__sgAppliedSubSrc = srcKey;
                } else {
                    tr.mode = 'disabled';
                }
            }
        }

        if (prefs.playbackSpeed && v) {
            var spd = parseFloat(prefs.playbackSpeed);
            if (isFinite(spd) && spd >= 0.5 && spd <= 2.0 && v.playbackRate !== spd) {
                v.playbackRate = spd;
            }
        }
    }

    document.addEventListener('click', function (ev) {
        var a = ev.target && ev.target.closest ? ev.target.closest('a[href]') : null;
        if (a) {
            var href = (a.getAttribute('href') || '').toLowerCase();
            if (href.indexOf('http') === 0 && href.indexOf('vidly') === -1) {
                ev.preventDefault();
                ev.stopPropagation();
                return;
            }
        }
        var btn = ev.target && ev.target.closest ? ev.target.closest('button, [role="button"], [role="menuitem"], [role="option"]') : null;
        if (!btn || !btn.closest('[role="dialog"], [role="menu"]')) return;
        var txt = (btn.innerText || btn.textContent || '').trim();
        var low = txt.toLowerCase();
        if (!txt || txt.length > 60) return;

        if (low.indexOf('auto') === 0 || low.indexOf('cinematic') !== -1 || low.indexOf('theatrical') !== -1 || low.indexOf('smooth') !== -1 || /\b(2160|1080|720|480|360)p\b/.test(low)) {
            var qVal = low.indexOf('auto') === 0 ? 'Auto' : (low.indexOf('1080') !== -1 ? '1080p' : (low.indexOf('720') !== -1 ? '720p' : (low.indexOf('480') !== -1 ? '480p' : (low.indexOf('360') !== -1 ? '360p' : (low.indexOf('2160') !== -1 ? '2160p' : txt)))));
            savePref('preferredQuality', qVal);
            return;
        }
        if (/^(0\.5|0\.75|1|1\.25|1\.5|2)x$/i.test(low)) {
            savePref('playbackSpeed', low.replace('x', ''));
            return;
        }
        if (low === 'off' || low === 'disabled' || low === 'arabic' || low === 'العربية' || low === 'english' || low === 'french' || low === 'spanish') {
            savePref('subtitleLanguage', txt);
        }
    }, true);

    var lastProgressSent = 0;
    setInterval(function () {
        applySavedPrefsToPlayer();
        var v = document.querySelector('video');
        if (v && isFinite(v.currentTime) && isFinite(v.duration) && v.duration > 0) {
            var now = Date.now();
            if (now - lastProgressSent >= 2000) {
                lastProgressSent = now;
                postToNative('progress', { currentTime: v.currentTime, duration: v.duration });
            }
        }
        if (!window.__sgReportedPageError && document.body) {
            var txt = (document.body.innerText || '').toLowerCase();
            if ((!v || v.readyState < 2) && (txt.indexOf('gateway time-out') !== -1 || txt.indexOf('error code 504') !== -1 || txt.indexOf('error code 502') !== -1 || txt.indexOf('stream unavailable') !== -1 || txt.indexOf('no sources') !== -1)) {
                window.__sgReportedPageError = true;
                postToNative('error', 'The streaming server is temporarily unavailable.');
            }
        }
    }, 800);
})();
