(function () {
    if (window.__sgCanonicalInitialized) return;
    window.__sgCanonicalInitialized = true;

    window.__singularityMeta = window.__singularityMeta || { title: 'SingularityTV', isMovie: true, subtitle: '', poster: '' };
    window.__sgSavedPrefs = window.__sgSavedPrefs || {};
    window.__sgAppliedQualitySrc = '';
    window.__sgAppliedSubSrc = '';
    window.__sgReportedPageError = false;
    window.__sgLastFocusedEl = null;
    window.__sgPreMenuFocusedEl = null;

    function postToNative(type, payload) {
        try {
            if (window.webkit && window.webkit.messageHandlers) {
                if (type === 'back' && window.webkit.messageHandlers.vidlyBack) {
                    window.webkit.messageHandlers.vidlyBack.postMessage(true);
                } else if (type === 'pref' && window.webkit.messageHandlers.vidlyPrefsChanged) {
                    window.webkit.messageHandlers.vidlyPrefsChanged.postMessage(payload);
                } else if (type === 'error' && window.webkit.messageHandlers.vidlyError) {
                    window.webkit.messageHandlers.vidlyError.postMessage(payload);
                } else if (type === 'progress' && window.webkit.messageHandlers.vidlyProgress) {
                    window.webkit.messageHandlers.vidlyProgress.postMessage(payload);
                }
            }
        } catch (e) {}

        try {
            if (window.SingularityBridge) {
                if (type === 'back' && window.SingularityBridge.onRequestBack) {
                    window.SingularityBridge.onRequestBack();
                } else if (type === 'pref' && window.SingularityBridge.onPreference) {
                    window.SingularityBridge.onPreference(payload.key, payload.value);
                } else if (type === 'error' && window.SingularityBridge.onFatalError) {
                    window.SingularityBridge.onFatalError(payload);
                } else if (type === 'progress' && window.SingularityBridge.onProgressUpdate) {
                    window.SingularityBridge.onProgressUpdate(payload.currentTime, payload.duration);
                }
            }
        } catch (e) {}

        try {
            if (window.chrome && window.chrome.webview && window.chrome.webview.postMessage) {
                window.chrome.webview.postMessage(JSON.stringify({ type: type, payload: payload }));
            }
        } catch (e) {}
    }

    try { window.open = function () { return null; }; } catch (e) {}

    var noop = function () { return Promise.resolve(); };
    try {
        Element.prototype.requestFullscreen = noop;
        Element.prototype.webkitRequestFullscreen = noop;
        Element.prototype.webkitRequestFullScreen = noop;
        HTMLVideoElement.prototype.webkitEnterFullscreen = function () {};
        HTMLVideoElement.prototype.webkitEnterFullScreen = function () {};
        Document.prototype.exitFullscreen = noop;
        Document.prototype.webkitExitFullscreen = noop;
        Object.defineProperty(document, 'fullscreenEnabled', { get: function () { return false; } });
        Object.defineProperty(document, 'webkitFullscreenEnabled', { get: function () { return false; } });
    } catch (e) {}

    function savePref(key, value) {
        window.__sgSavedPrefs[key] = value;
        postToNative('pref', { key: key, value: value });
    }

    function checkFatalPageError() {
        if (window !== window.top || window.__sgReportedPageError || !document.body) return;
        var v = document.querySelector('video');
        if (v && (v.readyState >= 2 || v.currentTime > 0)) return;
        var txt = (document.body.innerText || '').toLowerCase();
        if (!txt) return;
        var msg = null;
        if (txt.indexOf('gateway time-out') !== -1 || txt.indexOf('error code 504') !== -1 || txt.indexOf('error code 502') !== -1 || txt.indexOf('bad gateway') !== -1) {
            msg = 'The streaming server timed out. Please try again in a moment.';
        } else if (txt.indexOf('stream unavailable') !== -1 || txt.indexOf('no sources') !== -1 || txt.indexOf('media not found') !== -1) {
            msg = 'No working stream was found for this title right now.';
        }
        if (msg) {
            window.__sgReportedPageError = true;
            postToNative('error', msg);
        }
    }

    var _hlsVal = window.Hls;
    if (!_hlsVal) {
        try {
            Object.defineProperty(window, 'Hls', {
                configurable: true,
                enumerable: true,
                get: function () { return _hlsVal; },
                set: function (HlsCtor) {
                    _hlsVal = HlsCtor;
                    if (HlsCtor && HlsCtor.prototype && !HlsCtor.prototype.__sgHooked) {
                        HlsCtor.prototype.__sgHooked = true;
                        var origAttach = HlsCtor.prototype.attachMedia;
                        if (typeof origAttach === 'function') {
                            HlsCtor.prototype.attachMedia = function () {
                                window.__sgHlsInstance = this;
                                window.__sgAppliedQualitySrc = '';
                                return origAttach.apply(this, arguments);
                            };
                        }
                    }
                }
            });
        } catch (e) {}
    }

    function qualityTargetHeight(pref) {
        var p = (pref || '').toLowerCase();
        if (p.indexOf('2160') !== -1 || p.indexOf('4k') !== -1) return 2160;
        if (p.indexOf('1080') !== -1 || p.indexOf('cinematic') !== -1) return 1080;
        if (p.indexOf('720') !== -1 || p.indexOf('theatrical') !== -1) return 720;
        if (p.indexOf('480') !== -1 || p.indexOf('smooth') !== -1) return 480;
        if (p.indexOf('360') !== -1) return 360;
        return 0;
    }

    function applySavedPrefsToPlayer() {
        var prefs = window.__sgSavedPrefs || {};
        var v = document.querySelector('video');
        var srcKey = v ? (v.currentSrc || v.src || '') : '';

        if (prefs.preferredQuality && prefs.preferredQuality.toLowerCase() !== 'auto') {
            var targetH = qualityTargetHeight(prefs.preferredQuality);
            if (window.__sgHlsInstance && window.__sgHlsInstance.levels && window.__sgHlsInstance.levels.length > 0 && targetH > 0) {
                var levels = window.__sgHlsInstance.levels;
                var bestIdx = -1;
                var bestDiff = 999999;
                for (var i = 0; i < levels.length; i++) {
                    var h = levels[i].height || 0;
                    if (h > 0 && Math.abs(h - targetH) < bestDiff) {
                        bestDiff = Math.abs(h - targetH);
                        bestIdx = i;
                    }
                }
                if (bestIdx !== -1 && window.__sgHlsInstance.currentLevel !== bestIdx) {
                    window.__sgHlsInstance.currentLevel = bestIdx;
                }
            }
            if (srcKey && window.__sgAppliedQualitySrc !== srcKey) {
                var qBtns = document.querySelectorAll('[role="dialog"] button, [role="menu"] button');
                for (var qb = 0; qb < qBtns.length; qb++) {
                    var qt = (qBtns[qb].innerText || '').toLowerCase();
                    if (qt.indexOf(prefs.preferredQuality.toLowerCase()) !== -1 || (targetH > 0 && qt.indexOf(targetH + 'p') !== -1)) {
                        qBtns[qb].click();
                        window.__sgAppliedQualitySrc = srcKey;
                        break;
                    }
                }
            }
        }

        if (prefs.subtitleLanguage && v && v.textTracks && v.textTracks.length > 0 && window.__sgAppliedSubSrc !== srcKey) {
            var subPref = prefs.subtitleLanguage.toLowerCase();
            for (var t = 0; t < v.textTracks.length; t++) {
                var tr = v.textTracks[t];
                var lbl = ((tr.label || '') + ' ' + (tr.language || '')).toLowerCase();
                if (subPref === 'off' || subPref === 'none') {
                    tr.mode = 'disabled';
                } else if (lbl.indexOf(subPref) !== -1) {
                    tr.mode = 'showing';
                    window.__sgAppliedSubSrc = srcKey;
                } else {
                    tr.mode = 'disabled';
                }
            }
        }

        if (prefs.playbackSpeed && v) {
            var spd = parseFloat(prefs.playbackSpeed);
            if (isFinite(spd) && spd >= 0.5 && spd <= 2.0 && v.playbackRate !== spd) {
                v.playbackRate = spd;
            }
        }
    }

    function lockTitleAndFavicon() {
        try {
            if (document.title !== 'SingularityTV') {
                document.title = 'SingularityTV';
            }
            if (!window.__sgTitleLocked) {
                window.__sgTitleLocked = true;
                Object.defineProperty(document, 'title', {
                    configurable: true,
                    get: function () { return 'SingularityTV'; },
                    set: function () {}
                });
            }
        } catch (e) {}

        var poster = (window.__singularityMeta && window.__singularityMeta.poster) || '';
        if (poster && window.__sgLastFavicon !== poster) {
            window.__sgLastFavicon = poster;
            var icons = document.querySelectorAll('link[rel*="icon" i], link[rel*="apple-touch-icon" i]');
            for (var i = 0; i < icons.length; i++) {
                if (icons[i].href !== poster) icons[i].href = poster;
            }
            if (icons.length === 0 && document.head) {
                var lnk = document.createElement('link');
                lnk.rel = 'apple-touch-icon';
                lnk.href = poster;
                document.head.appendChild(lnk);
            }
        }
    }

    function syncMediaSession() {
        try {
            if (!('mediaSession' in navigator) || typeof MediaMetadata === 'undefined') return;
            var meta = window.__singularityMeta || {};
            var key = (meta.title || '') + '|' + (meta.subtitle || '') + '|' + (meta.poster || '');
            if (window.__sgLastMediaKey === key) return;
            window.__sgLastMediaKey = key;
            var art = meta.poster ? [{ src: meta.poster, sizes: '512x512', type: 'image/jpeg' }] : [];
            navigator.mediaSession.metadata = new MediaMetadata({
                title: meta.title || 'SingularityTV',
                artist: 'SingularityTV',
                album: meta.subtitle || 'SingularityTV',
                artwork: art
            });
        } catch (e) {}
    }
    window.__singularitySyncMediaSession = syncMediaSession;

    function hideEl(el) {
        if (!el || el.dataset.sgHidden === '1' || el.tagName === 'VIDEO' || el.tagName === 'BODY' || el.tagName === 'HTML') return;
        if (el.id === '__sgTopBackBtn' || el.id === '__sgMovieSub' || el.id === '__sgWatermark') return;
        el.dataset.sgHidden = '1';
        el.style.setProperty('display', 'none', 'important');
        el.style.setProperty('opacity', '0', 'important');
        el.style.setProperty('visibility', 'hidden', 'important');
        el.style.setProperty('pointer-events', 'none', 'important');
    }

    function isMaximizeSvg(el) {
        var svg = el.tagName === 'SVG' ? el : (el.querySelector ? el.querySelector('svg') : null);
        if (!svg) return false;
        var html = (svg.innerHTML || '').toLowerCase();
        return html.indexOf('m15 3h6v6') !== -1 ||
               html.indexOf('m8 3h5') !== -1 ||
               html.indexOf('m3 8v5') !== -1 ||
               html.indexOf('15 3 21 3 21 9') !== -1 ||
               html.indexOf('9 21 3 21 3 15') !== -1 ||
               html.indexOf('fullscreen') !== -1;
    }

    function effOp(el) {
        var op = 1, cur = el;
        while (cur && cur.nodeType === 1) {
            var cs = getComputedStyle(cur);
            if (cs.display === 'none' || cs.visibility === 'hidden') return 0;
            op *= parseFloat(cs.opacity);
            if (op <= 0.02) return 0;
            cur = cur.parentElement;
        }
        return op;
    }

    function hasFullScreenDrawer() {
        var vw = window.innerWidth || 0;
        var vh = window.innerHeight || 0;
        var dialogs = document.querySelectorAll('[role="dialog"], [class*="drawer" i]');
        for (var i = 0; i < dialogs.length; i++) {
            var d = dialogs[i];
            var r = d.getBoundingClientRect ? d.getBoundingClientRect() : null;
            if (r && r.width > vw * 0.72 && r.height > vh * 0.72 && effOp(d) > 0.1) {
                return true;
            }
        }
        return false;
    }

    function ensureWatermark() {
        if (window !== window.top) return;
        var root = document.body || document.documentElement;
        if (!root) return;
        var wm = document.getElementById('__sgWatermark');
        if (!wm) {
            wm = document.createElement('div');
            wm.id = '__sgWatermark';
            wm.style.cssText = 'position:fixed;top:18px;right:18px;z-index:2147483644;pointer-events:none;user-select:none;opacity:0;transition:opacity 140ms ease;filter:drop-shadow(0 1px 4px rgba(0,0,0,0.7));display:inline-flex;align-items:center;justify-content:center;';
            wm.innerHTML = '<svg width="20" height="20" viewBox="0 0 64 64" fill="none"><path d="M46 13H25C19 13 14.5 17 14.5 22.5C14.5 28 19 31.5 25 31.5H39C44.5 31.5 49 35 49 40.5C49 46.5 44.5 51 38.5 51H16.5" stroke="#FFFFFF" stroke-width="7.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
            root.appendChild(wm);
        }
        if (hasFullScreenDrawer()) {
            wm.style.opacity = '0';
            return;
        }
        var topBtns = document.querySelectorAll('button, [role="button"]');
        var alignedTop = null;
        var alignedOp = 0;
        for (var i = 0; i < topBtns.length; i++) {
            var b = topBtns[i];
            if (b.id === '__sgTopBackBtn') continue;
            var r = b.getBoundingClientRect ? b.getBoundingClientRect() : null;
            if (r && r.top >= 4 && r.top < 76 && r.right > (window.innerWidth || 0) * 0.5 && r.height > 12) {
                var op = effOp(b);
                if (op > 0.15) {
                    alignedTop = Math.round(r.top + (r.height - 20) / 2);
                    alignedOp = op;
                    break;
                }
            }
        }
        if (alignedTop !== null) {
            wm.style.top = alignedTop + 'px';
            wm.style.right = '18px';
            wm.style.opacity = String(Math.min(0.68, alignedOp));
        } else {
            wm.style.opacity = '0';
        }
    }

    function fmtRuntime(sec) {
        var meta = window.__singularityMeta || {};
        if (meta.subtitle && meta.subtitle.length > 0) return meta.subtitle;
        if (!isFinite(sec) || sec < 60) return '';
        var m = Math.round(sec / 60);
        var h = Math.floor(m / 60), rm = m % 60;
        return h > 0 ? (rm > 0 ? (h + 'h ' + rm + 'm') : (h + 'h')) : (rm + 'm');
    }

    function ensureTopBack() {
        if (window !== window.top || !document.body) return;
        var bk = document.getElementById('__sgTopBackBtn');
        if (!bk) {
            bk = document.createElement('button');
            bk.id = '__sgTopBackBtn';
            bk.type = 'button';
            bk.setAttribute('aria-label', 'Back');
            bk.style.cssText = 'position:fixed;z-index:2147483645;display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;background:transparent;border:none;color:#FFFFFF;cursor:pointer;padding:0;margin:0;opacity:0;pointer-events:none;transition:opacity 120ms ease;';
            bk.innerHTML = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5"></path><path d="M12 19l-7-7 7-7"></path></svg>';
            bk.addEventListener('pointerdown', function (e) { e.stopPropagation(); }, true);
            bk.addEventListener('click', function (ev) {
                ev.stopPropagation();
                ev.preventDefault();
                postToNative('back', true);
            }, true);
            document.body.appendChild(bk);
        }

        if (hasFullScreenDrawer()) {
            bk.style.opacity = '0';
            bk.style.pointerEvents = 'none';
            return;
        }

        var titleEl = null, titleOp = 0;
        var tCands = document.querySelectorAll('h1,h2,h3,div,span,p');
        for (var j = 0; j < tCands.length; j++) {
            var el = tCands[j];
            if (el.id === '__sgTopBackBtn' || el.id === '__sgMovieSub' || el.id === '__sgWatermark' || el.closest('button')) continue;
            if (el.closest('[role="dialog"], [role="menu"], [class*="drawer" i]')) continue;
            if (el.children.length > 0) continue;
            var ttx = (el.textContent || '').trim();
            if (ttx.length < 2 || ttx.length > 85) continue;
            var low = ttx.toLowerCase();
            if (low === 'episodes' || low.indexOf('quality') !== -1 || low.indexOf('server') !== -1 || low.indexOf('audio') !== -1 || low.indexOf('subtitle') !== -1) continue;
            var tr = el.getBoundingClientRect();
            if (tr.width > 10 && tr.top >= 2 && tr.top < 105 && tr.left >= 4 && tr.left < 400 && tr.height >= 14 && tr.height < 60) {
                var op = effOp(el);
                if (op > 0.15) {
                    titleEl = el;
                    titleOp = op;
                    break;
                }
            }
        }

        if (titleEl && titleOp > 0.15) {
            var titleBox = titleEl.parentElement;
            var isTvUrl = (location.pathname || '').toLowerCase().indexOf('/tv/') !== -1 || !(window.__singularityMeta && window.__singularityMeta.isMovie);
            var subEl = document.getElementById('__sgMovieSub');
            var existingSub = null;
            if (titleBox) {
                var sibs = titleBox.children;
                for (var si = 0; si < sibs.length; si++) {
                    var sb = sibs[si];
                    if (sb === titleEl || sb.id === '__sgMovieSub') continue;
                    var st = (sb.textContent || '').trim();
                    if (st.length > 1 && sb.getBoundingClientRect().top >= titleEl.getBoundingClientRect().top + 8) {
                        existingSub = sb;
                        break;
                    }
                }
            }

            if (!existingSub && titleBox) {
                var v = document.querySelector('video');
                var subTxt = fmtRuntime(v ? v.duration : 0);
                if (subTxt.length > 0) {
                    if (!subEl) {
                        subEl = document.createElement('div');
                        subEl.id = '__sgMovieSub';
                        subEl.style.cssText = 'font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:12.5px;font-weight:500;color:rgba(255,255,255,0.68);margin-top:2px;line-height:1.25;white-space:nowrap;pointer-events:none;';
                    }
                    if (subEl.textContent !== subTxt) subEl.textContent = subTxt;
                    if (subEl.parentElement !== titleBox) {
                        var pcs = getComputedStyle(titleBox);
                        if (pcs.display === 'flex' && pcs.flexDirection !== 'column') {
                            titleBox.style.setProperty('flex-direction', 'column', 'important');
                            titleBox.style.setProperty('align-items', 'flex-start', 'important');
                        }
                        titleBox.appendChild(subEl);
                    }
                    existingSub = subEl;
                }
            } else if (isTvUrl && existingSub && subEl) {
                subEl.remove();
            }

            var shiftTarget = titleBox || titleEl;
            if (!shiftTarget.dataset.sgBackShifted && titleEl.getBoundingClientRect().left < 56) {
                shiftTarget.dataset.sgBackShifted = '1';
                shiftTarget.style.setProperty('padding-left', '40px', 'important');
            }

            var tr2 = titleEl.getBoundingClientRect();
            var sr2 = existingSub ? existingSub.getBoundingClientRect() : tr2;
            var midY = (tr2.top + Math.max(tr2.bottom, sr2.bottom)) / 2;
            var bx = Math.max(10, Math.round(tr2.left - 42));
            var by = Math.max(4, Math.round(midY - 18));
            bk.style.left = bx + 'px';
            bk.style.top = by + 'px';
            bk.style.opacity = String(titleOp);
            bk.style.pointerEvents = 'auto';
        } else {
            bk.style.left = '16px';
            bk.style.top = '14px';
            bk.style.opacity = '0';
            bk.style.pointerEvents = 'none';
        }

        var topBtns = document.querySelectorAll('button, [role="button"]');
        for (var tb = 0; tb < topBtns.length; tb++) {
            var btn = topBtns[tb];
            if (btn.id === '__sgTopBackBtn') continue;
            var br = btn.getBoundingClientRect ? btn.getBoundingClientRect() : null;
            if (br && br.top >= 0 && br.top < 70 && br.right > (window.innerWidth || 0) - 52) {
                if (btn.parentElement && !btn.parentElement.dataset.sgRightShifted && !btn.closest('[role="dialog"], [role="menu"]')) {
                    btn.parentElement.dataset.sgRightShifted = '1';
                    btn.parentElement.style.setProperty('padding-right', '40px', 'important');
                }
            }
        }
    }

    window.__singularitySyncHeader = ensureTopBack;

    function cleanQuickNodes() {
        lockTitleAndFavicon();
        syncMediaSession();

        var vw = window.innerWidth || document.documentElement.clientWidth || 0;
        var candidates = document.querySelectorAll('button, [role="button"], a, img, svg, div, span');
        for (var i = 0; i < candidates.length; i++) {
            var el = candidates[i];
            if (!el || el.dataset.sgHidden === '1' || el.tagName === 'VIDEO' || el.id === '__sgTopBackBtn' || el.id === '__sgMovieSub' || el.id === '__sgWatermark') continue;

            var aria = (el.getAttribute('aria-label') || '').toLowerCase();
            var title = (el.getAttribute('title') || '').toLowerCase();
            var cls = (typeof el.className === 'string' ? el.className : '').toLowerCase();
            var id = (el.id || '').toLowerCase();
            var testId = (el.getAttribute('data-testid') || '').toLowerCase();
            var href = (el.getAttribute('href') || '').toLowerCase();
            var src = (el.getAttribute('src') || '').toLowerCase();
            var alt = (el.getAttribute('alt') || '').toLowerCase();

            if (aria.indexOf('fullscreen') !== -1 || aria.indexOf('full screen') !== -1 ||
                title.indexOf('fullscreen') !== -1 || title.indexOf('full screen') !== -1 ||
                testId.indexOf('fullscreen') !== -1 || id.indexOf('fullscreen') !== -1 ||
                (el.tagName === 'BUTTON' && (cls.indexOf('fullscreen') !== -1 || isMaximizeSvg(el)))) {
                hideEl(el);
                continue;
            }

            if (href.indexOf('vidly') !== -1 || src.indexOf('vidly') !== -1 || alt.indexOf('vidly') !== -1 ||
                aria.indexOf('vidly') !== -1 || title.indexOf('vidly') !== -1 ||
                cls.indexOf('vidly') !== -1 || id.indexOf('vidly') !== -1) {
                if (el.tagName === 'A' || el.tagName === 'IMG' || el.tagName === 'SVG' || el.children.length <= 2) {
                    hideEl(el);
                    continue;
                }
            }

            if ((el.tagName === 'SPAN' || el.tagName === 'DIV' || el.tagName === 'A') && el.children.length === 0) {
                var ownTxt = (el.textContent || '').trim().toLowerCase();
                if (ownTxt === 'vidly' || ownTxt === 'vidly.pro') {
                    hideEl(el);
                    continue;
                }
            }

            if (vw > 0 && (el.tagName === 'A' || el.tagName === 'IMG' || el.tagName === 'SVG' || el.tagName === 'DIV')) {
                var rect = el.getBoundingClientRect ? el.getBoundingClientRect() : null;
                if (rect && rect.top >= 2 && rect.top <= 76 && rect.right >= vw - 80 && rect.width >= 12 && rect.width <= 64 && rect.height >= 12 && rect.height <= 64) {
                    var txt = (el.innerText || el.textContent || '').trim();
                    var isModal = !!el.closest('[role="dialog"], [role="menu"], [class*="drawer" i]');
                    var isControl = el.tagName === 'BUTTON' ||
                        el.getAttribute('role') === 'button' ||
                        el.hasAttribute('tabindex') ||
                        !!el.closest('button, [role="button"]');
                    if (!isModal && !isControl && !txt) {
                        hideEl(el);
                    }
                }
            }
        }
    }

    function wakePlayerControls() {
        try {
            var cx = Math.round((window.innerWidth || 1280) / 2);
            var cy = Math.round((window.innerHeight || 720) / 2);
            var target = document.querySelector('video') || document.body || document.documentElement;
            if (!target) return;
            target.dispatchEvent(new MouseEvent('mousemove', { bubbles: true, cancelable: true, clientX: cx, clientY: cy }));
            target.dispatchEvent(new PointerEvent('pointermove', { bubbles: true, cancelable: true, clientX: cx, clientY: cy }));
        } catch (e) {}
    }

    function getOpenMenuContainer() {
        var nodes = document.querySelectorAll('[role="dialog"], [role="menu"], [class*="drawer" i]');
        for (var i = nodes.length - 1; i >= 0; i--) {
            if (effOp(nodes[i]) > 0.1 && nodes[i].getBoundingClientRect().height > 30) {
                return nodes[i];
            }
        }
        return null;
    }

    function getFocusableElements(scopeRoot) {
        var root = scopeRoot || document;
        var raw = root.querySelectorAll('button, [role="button"], [role="menuitem"], [role="option"], input[type="range"], [role="slider"], a[href]');
        var list = [];
        for (var i = 0; i < raw.length; i++) {
            var el = raw[i];
            if (el.dataset.sgHidden === '1' || el.disabled) continue;
            if (effOp(el) <= 0.1) continue;
            var r = el.getBoundingClientRect();
            if (r.width < 8 || r.height < 8) continue;
            list.push({ el: el, rect: r, cx: r.left + r.width / 2, cy: r.top + r.height / 2 });
        }
        return list;
    }

    function setTvFocus(el) {
        if (!el) return;
        if (window.__sgLastFocusedEl && window.__sgLastFocusedEl !== el) {
            try { window.__sgLastFocusedEl.classList.remove('sg-tv-focused'); } catch (e) {}
        }
        window.__sgLastFocusedEl = el;
        try {
            el.classList.add('sg-tv-focused');
            if (typeof el.focus === 'function') el.focus({ preventScroll: true });
            if (typeof el.scrollIntoView === 'function' && el.closest('[role="dialog"], [role="menu"]')) {
                el.scrollIntoView({ block: 'nearest', inline: 'nearest' });
            }
        } catch (e) {}
    }

    function isSliderElement(el) {
        if (!el) return false;
        if (el.tagName === 'INPUT' && el.type === 'range') return true;
        if (el.getAttribute('role') === 'slider') return true;
        return false;
    }

    function findNextSpatial(current, items, dir) {
        if (!items.length) return null;
        if (!current) return items[0].el;
        var cr = current.getBoundingClientRect();
        var cx = cr.left + cr.width / 2;
        var cy = cr.top + cr.height / 2;
        var best = null;
        var bestScore = 1e12;
        for (var i = 0; i < items.length; i++) {
            var cand = items[i];
            if (cand.el === current) continue;
            var dx = cand.cx - cx;
            var dy = cand.cy - cy;
            if (dir === 'left' && dx >= -6) continue;
            if (dir === 'right' && dx <= 6) continue;
            if (dir === 'up' && dy >= -6) continue;
            if (dir === 'down' && dy <= 6) continue;
            var primary = (dir === 'left' || dir === 'right') ? Math.abs(dx) : Math.abs(dy);
            var secondary = (dir === 'left' || dir === 'right') ? Math.abs(dy) : Math.abs(dx);
            var score = primary + secondary * 2.4;
            if (score < bestScore) {
                bestScore = score;
                best = cand.el;
            }
        }
        return best;
    }

    function closeOpenMenu() {
        var menu = getOpenMenuContainer();
        if (!menu) return false;
        var closeBtn = menu.querySelector('[aria-label*="close" i], [title*="close" i], button svg');
        if (closeBtn) {
            var targetBtn = closeBtn.tagName === 'BUTTON' ? closeBtn : closeBtn.closest('button');
            if (targetBtn) {
                targetBtn.click();
                setTimeout(function () {
                    if (window.__sgPreMenuFocusedEl && document.contains(window.__sgPreMenuFocusedEl)) {
                        setTvFocus(window.__sgPreMenuFocusedEl);
                    }
                }, 80);
                return true;
            }
        }
        document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape', code: 'Escape', keyCode: 27, bubbles: true }));
        var vid = document.querySelector('video');
        if (vid) vid.click();
        setTimeout(function () {
            if (window.__sgPreMenuFocusedEl && document.contains(window.__sgPreMenuFocusedEl)) {
                setTvFocus(window.__sgPreMenuFocusedEl);
            }
        }, 80);
        return true;
    }

    window.__sgHandleRemoteKey = function (keyName) {
        wakePlayerControls();
        var menu = getOpenMenuContainer();
        var focusable = getFocusableElements(menu);
        var current = window.__sgLastFocusedEl && document.contains(window.__sgLastFocusedEl) && effOp(window.__sgLastFocusedEl) > 0.1
            ? window.__sgLastFocusedEl
            : (document.activeElement && document.activeElement !== document.body ? document.activeElement : null);

        if (menu && (!current || !menu.contains(current))) {
            current = focusable.length ? focusable[0].el : null;
            if (current) setTvFocus(current);
        }

        if (keyName === 'BACK') {
            if (menu) {
                closeOpenMenu();
                return true;
            }
            postToNative('back', true);
            return true;
        }

        if (keyName === 'PLAY_PAUSE') {
            var v = document.querySelector('video');
            if (v) {
                if (v.paused) v.play(); else v.pause();
                return true;
            }
        }

        if (keyName === 'MENU') {
            var btns = getFocusableElements(null);
            for (var mb = 0; mb < btns.length; mb++) {
                var lbl = ((btns[mb].el.getAttribute('aria-label') || '') + ' ' + (btns[mb].el.getAttribute('title') || '')).toLowerCase();
                if (lbl.indexOf('setting') !== -1 || lbl.indexOf('quality') !== -1 || lbl.indexOf('subtitle') !== -1 || lbl.indexOf('audio') !== -1 || lbl.indexOf('server') !== -1) {
                    window.__sgPreMenuFocusedEl = current;
                    btns[mb].el.click();
                    return true;
                }
            }
        }

        if (!current && focusable.length > 0) {
            var midPlay = focusable[0].el;
            for (var fp = 0; fp < focusable.length; fp++) {
                var a = (focusable[fp].el.getAttribute('aria-label') || '').toLowerCase();
                if (a.indexOf('play') !== -1 || a.indexOf('pause') !== -1) {
                    midPlay = focusable[fp].el;
                    break;
                }
            }
            setTvFocus(midPlay);
            return true;
        }

        if ((keyName === 'LEFT' || keyName === 'RIGHT') && current && isSliderElement(current) && !menu) {
            var vid = document.querySelector('video');
            if (vid && isFinite(vid.duration) && vid.duration > 0) {
                var delta = keyName === 'RIGHT' ? 10 : -10;
                vid.currentTime = Math.max(0, Math.min(vid.duration, vid.currentTime + delta));
                return true;
            }
        }

        if (keyName === 'UP' || keyName === 'DOWN' || keyName === 'LEFT' || keyName === 'RIGHT') {
            var dirMap = { UP: 'up', DOWN: 'down', LEFT: 'left', RIGHT: 'right' };
            var nextEl = findNextSpatial(current, focusable, dirMap[keyName]);
            if (nextEl) {
                setTvFocus(nextEl);
                return true;
            }
            return true;
        }

        if (keyName === 'OK') {
            if (current) {
                if (!menu) window.__sgPreMenuFocusedEl = current;
                current.click();
                setTimeout(function () {
                    var opened = getOpenMenuContainer();
                    if (opened) {
                        var mItems = getFocusableElements(opened);
                        if (mItems.length) setTvFocus(mItems[0].el);
                    }
                    syncUI();
                }, 120);
                return true;
            }
            var v2 = document.querySelector('video');
            if (v2) {
                if (v2.paused) v2.play(); else v2.pause();
                return true;
            }
        }
        return false;
    };

    document.addEventListener('click', function (ev) {
        var a = ev.target && ev.target.closest ? ev.target.closest('a[href]') : null;
        if (a) {
            var href = (a.getAttribute('href') || '').toLowerCase();
            if (href.indexOf('http') === 0 && href.indexOf('vidly') === -1) {
                ev.preventDefault();
                ev.stopPropagation();
                return;
            }
        }
        var btn = ev.target && ev.target.closest ? ev.target.closest('button, [role="button"], [role="menuitem"], [role="option"]') : null;
        if (!btn || !btn.closest('[role="dialog"], [role="menu"]')) return;
        var txt = (btn.innerText || btn.textContent || '').trim();
        var low = txt.toLowerCase();
        if (!txt || txt.length > 60) return;

        if (low.indexOf('auto') === 0 || low.indexOf('cinematic') !== -1 || low.indexOf('theatrical') !== -1 || low.indexOf('smooth') !== -1 || /\b(2160|1080|720|480|360)p\b/.test(low)) {
            var qVal = low.indexOf('auto') === 0 ? 'Auto' : (low.indexOf('1080') !== -1 ? '1080p' : (low.indexOf('720') !== -1 ? '720p' : (low.indexOf('480') !== -1 ? '480p' : (low.indexOf('360') !== -1 ? '360p' : (low.indexOf('2160') !== -1 ? '2160p' : txt)))));
            savePref('preferredQuality', qVal);
            return;
        }
        if (/^(0\.5|0\.75|1|1\.25|1\.5|2)x$/i.test(low)) {
            savePref('playbackSpeed', low.replace('x', ''));
            return;
        }
        if (low === 'off' || low === 'disabled' || low === 'arabic' || low === 'العربية' || low === 'english' || low === 'french' || low === 'spanish') {
            savePref('subtitleLanguage', txt);
        }
    }, true);

    window.addEventListener('message', function (event) {
        var payload = event.data;
        if (typeof payload === 'string') {
            try { payload = JSON.parse(payload); } catch (e) { return; }
        }
        if (!payload || typeof payload !== 'object') return;
        var d = payload.type === 'PLAYER_EVENT' && payload.data ? payload.data : payload;
        var ct = Number(d.currentTime !== undefined ? d.currentTime : d.timestamp);
        var dur = Number(d.duration);
        if (isFinite(ct) && isFinite(dur) && dur > 0) {
            postToNative('progress', { currentTime: ct, duration: dur });
        }
    }, false);

    function syncUI() {
        checkFatalPageError();
        applySavedPrefsToPlayer();
        ensureWatermark();
        ensureTopBack();
    }

    var lastCleanAt = 0;
    var scheduledClean = false;
    function scheduleClean() {
        if (scheduledClean) return;
        scheduledClean = true;
        var now = Date.now();
        var delay = Math.max(0, 200 - (now - lastCleanAt));
        setTimeout(function () {
            scheduledClean = false;
            lastCleanAt = Date.now();
            cleanQuickNodes();
            syncUI();
        }, delay);
    }

    cleanQuickNodes();
    syncUI();
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', function () {
            cleanQuickNodes();
            syncUI();
        });
    }

    var obs = new MutationObserver(function () { scheduleClean(); });
    try {
        obs.observe(document.documentElement || document, { childList: true, subtree: true });
    } catch (e) {}

    document.addEventListener('pointerup', function () {
        setTimeout(syncUI, 90);
    }, true);

    var lastProgressSent = 0;
    setInterval(function () {
        syncUI();
        var v = document.querySelector('video');
        if (v && isFinite(v.currentTime) && isFinite(v.duration) && v.duration > 0) {
            var now = Date.now();
            if (now - lastProgressSent >= 2000) {
                lastProgressSent = now;
                postToNative('progress', { currentTime: v.currentTime, duration: v.duration });
            }
        }
    }, 500);
})();
