using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.UI;
using Microsoft.UI.Windowing;
using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using Microsoft.UI.Xaml.Input;
using Microsoft.UI.Xaml.Media;
using Microsoft.UI.Xaml.Media.Imaging;
using Microsoft.Web.WebView2.Core;
using SingularityTV.Desktop.Services;
using Windows.Storage.Pickers;
using Windows.System;
using WinRT.Interop;

namespace SingularityTV.Desktop;

public sealed partial class MainWindow : Window
{
    private readonly DesktopBackendService _backend = new();
    private string? _currentStreamUrl;
    private bool _isFullScreen;
    private int _searchGeneration;
    private int _searchPage = 1;
    private bool _searchInitialized;
    private MediaItemDto? _activePlayerMedia;
    private int _activePlayerSeason = 1;
    private int _activePlayerEpisode = 1;
    private string _homeScope = "all";

    private static readonly string[] BlockedAdDomains =
    {
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "googletagmanager.com", "google-analytics.com", "popads.net", "popcash.net",
        "propellerads.com", "adsterra.com", "adskeeper.com", "mgid.com", "taboola.com",
        "outbrain.com", "exoclick.com", "juicyads.com", "trafficjunky.com", "histats.com",
        "4rabet", "1xbet", "betway", "onclickalgo", "adsco.re", "a-ads.com"
    };

    public MainWindow()
    {
        InitializeComponent();
        Title = "SingularityTV 1.1.6";
        _ = BootstrapAsync();
    }

    private async Task BootstrapAsync()
    {
        if (_backend.Session == null)
        {
            ShowStage("auth");
            return;
        }
        var ok = await _backend.CheckTelegramGateAsync();
        if (!ok)
        {
            ShowStage("telegram");
            return;
        }
        await _backend.LoadProfilesAsync();
        _backend.StartRealtimeSync(() =>
        {
            DispatcherQueue.TryEnqueue(async () =>
            {
                await _backend.LoadProfilesAsync();
                if (_backend.ActiveProfile != null)
                {
                    await _backend.SelectProfileAsync(_backend.ActiveProfile);
                }
                if (ProfilesPanel.Visibility == Visibility.Visible) RenderProfiles();
                if (HomeScroll.Visibility == Visibility.Visible) await LoadHomeAsync();
            });
        });
        RenderProfiles();
        ShowStage("profiles");
    }

    private void ShowStage(string stage)
    {
        AuthPanel.Visibility = stage == "auth" ? Visibility.Visible : Visibility.Collapsed;
        TelegramPanel.Visibility = stage == "telegram" ? Visibility.Visible : Visibility.Collapsed;
        ProfilesPanel.Visibility = stage == "profiles" ? Visibility.Visible : Visibility.Collapsed;
        MainNavView.Visibility = stage == "main" ? Visibility.Visible : Visibility.Collapsed;
    }

    private string _authMode = "signin";

    private void SetAuthMode(string mode)
    {
        _authMode = mode;
        AuthErrorBanner.Visibility = Visibility.Collapsed;
        AuthModeTabs.Visibility = (mode is "signin" or "signup") ? Visibility.Visible : Visibility.Collapsed;
        TabSignInBtn.Background = new SolidColorBrush(mode == "signin" ? ColorHelper.FromArgb(255, 229, 9, 20) : Colors.Transparent);
        TabSignUpBtn.Background = new SolidColorBrush(mode == "signup" ? ColorHelper.FromArgb(255, 229, 9, 20) : Colors.Transparent);
        NameBox.Visibility = mode == "signup" ? Visibility.Visible : Visibility.Collapsed;
        EmailBox.Visibility = (mode is "signin" or "signup" or "forgot") ? Visibility.Visible : Visibility.Collapsed;
        OtpBox.Visibility = (mode is "verify" or "reset") ? Visibility.Visible : Visibility.Collapsed;
        PasswordBox.Visibility = (mode is "signin" or "signup" or "reset") ? Visibility.Visible : Visibility.Collapsed;
        ConfirmPasswordBox.Visibility = (mode is "signup" or "reset") ? Visibility.Visible : Visibility.Collapsed;
        ForgotPasswordBtn.Visibility = mode == "signin" ? Visibility.Visible : Visibility.Collapsed;
        ResendOtpBtn.Visibility = (mode is "verify" or "reset") ? Visibility.Visible : Visibility.Collapsed;
        BackAuthBtn.Visibility = (mode is "verify" or "forgot" or "reset") ? Visibility.Visible : Visibility.Collapsed;
        SignInButton.Content = mode switch
        {
            "signup" => "Send Verification Code",
            "verify" => "Verify & Enter App",
            "forgot" => "Send Reset Code",
            "reset" => "Reset Password & Sign In",
            _ => "Sign In"
        };
        AuthSubtitleText.Text = mode switch
        {
            "signup" => "Create your account with email verification",
            "verify" => $"Enter the 6-digit code sent to {EmailBox.Text.Trim()}",
            "forgot" => "Enter your email to receive a 6-digit reset code",
            "reset" => "Enter your reset code and choose a new password",
            _ => "Sign in to sync your watch progress & profiles"
        };
    }

    private void TabSignIn_Click(object sender, RoutedEventArgs e) => SetAuthMode("signin");
    private void TabSignUp_Click(object sender, RoutedEventArgs e) => SetAuthMode("signup");
    private void ForgotPassword_Click(object sender, RoutedEventArgs e) => SetAuthMode("forgot");

    private async void ResendOtp_Click(object sender, RoutedEventArgs e)
    {
        if (_authMode == "verify") await _backend.ResendSignupOtpAsync(EmailBox.Text);
        else if (_authMode == "reset") await _backend.RequestPasswordResetAsync(EmailBox.Text);
    }

    private async void SignInButton_Click(object sender, RoutedEventArgs e)
    {
        AuthErrorBanner.Visibility = Visibility.Collapsed;
        SignInButton.IsEnabled = false;
        bool ok = false;
        string? err = null;
        if (_authMode == "signin")
        {
            (ok, err) = await _backend.SignInAsync(EmailBox.Text.Trim(), PasswordBox.Password);
        }
        else if (_authMode == "signup")
        {
            if (PasswordBox.Password != ConfirmPasswordBox.Password) { err = "Passwords do not match."; }
            else
            {
                var (sOk, needsVerify, sErr) = await _backend.SignUpAsync(EmailBox.Text, PasswordBox.Password, NameBox.Text);
                if (sOk && needsVerify) { SignInButton.IsEnabled = true; SetAuthMode("verify"); return; }
                ok = sOk; err = sErr;
            }
        }
        else if (_authMode == "verify")
        {
            (ok, err) = await _backend.VerifyEmailOtpAsync(EmailBox.Text, OtpBox.Text, "signup");
        }
        else if (_authMode == "forgot")
        {
            (ok, err) = await _backend.RequestPasswordResetAsync(EmailBox.Text);
            if (ok) { SignInButton.IsEnabled = true; SetAuthMode("reset"); return; }
        }
        else if (_authMode == "reset")
        {
            if (PasswordBox.Password != ConfirmPasswordBox.Password) { err = "Passwords do not match."; }
            else (ok, err) = await _backend.CompletePasswordResetAsync(EmailBox.Text, OtpBox.Text, PasswordBox.Password);
        }
        SignInButton.IsEnabled = true;
        if (!ok)
        {
            AuthErrorText.Text = err ?? "Authentication failed.";
            AuthErrorBanner.Visibility = Visibility.Visible;
            return;
        }
        await BootstrapAsync();
    }

    private async void VerifyTelegram_Click(object sender, RoutedEventArgs e)
    {
        if (await _backend.CheckTelegramGateAsync())
        {
            await _backend.LoadProfilesAsync();
            RenderProfiles();
            ShowStage("profiles");
        }
    }

    private bool _manageProfilesMode;

    private static Windows.UI.Color ParseHexColor(string hex)
    {
        var clean = hex.TrimStart('#');
        if (clean.Length == 6 && uint.TryParse(clean, System.Globalization.NumberStyles.HexNumber, null, out var rgb))
            return ColorHelper.FromArgb(255, (byte)((rgb >> 16) & 0xFF), (byte)((rgb >> 8) & 0xFF), (byte)(rgb & 0xFF));
        return ColorHelper.FromArgb(255, 229, 9, 20);
    }

    private void ManageProfilesBtn_Click(object sender, RoutedEventArgs e)
    {
        _manageProfilesMode = !_manageProfilesMode;
        ProfilesHeadingText.Text = _manageProfilesMode ? "Manage Profiles" : "Who's Watching?";
        ManageProfilesBtn.Content = _manageProfilesMode ? "Done" : "Manage Profiles";
        RenderProfiles();
    }

    private void RenderProfiles()
    {
        ProfilesEmailText.Text = _backend.Session?.Email ?? "";
        ProfilesListPanel.Children.Clear();
        foreach (var profile in _backend.Profiles)
        {
            var isActive = _backend.ActiveProfile?.Id == profile.Id;
            var stack = new StackPanel { Spacing = 8, HorizontalAlignment = HorizontalAlignment.Center };
            var avatar = new Border
            {
                Width = 96,
                Height = 96,
                CornerRadius = new CornerRadius(24),
                Background = new SolidColorBrush(ParseHexColor(profile.AvatarColor)),
                BorderBrush = new SolidColorBrush(isActive && !_manageProfilesMode ? Colors.White : Colors.Transparent),
                BorderThickness = new Thickness(isActive && !_manageProfilesMode ? 2 : 0)
            };
            if (!string.IsNullOrWhiteSpace(profile.AvatarUrl) && !profile.AvatarUrl.StartsWith("data:", StringComparison.OrdinalIgnoreCase))
            {
                avatar.Child = new Image { Source = new BitmapImage(new Uri(profile.AvatarUrl)), Stretch = Stretch.UniformToFill };
            }
            else
            {
                avatar.Child = new TextBlock
                {
                    Text = string.IsNullOrEmpty(profile.Name) ? "S" : profile.Name[..1].ToUpperInvariant(),
                    Foreground = new SolidColorBrush(Colors.White),
                    FontSize = 36,
                    FontWeight = Microsoft.UI.Text.FontWeights.Bold,
                    HorizontalAlignment = HorizontalAlignment.Center,
                    VerticalAlignment = VerticalAlignment.Center
                };
            }
            stack.Children.Add(avatar);
            stack.Children.Add(new TextBlock { Text = _manageProfilesMode ? $"Edit {profile.Name}" : profile.Name, Foreground = new SolidColorBrush(Colors.White), FontSize = 14, HorizontalAlignment = HorizontalAlignment.Center });
            if (profile.IsKids)
                stack.Children.Add(new TextBlock { Text = "KIDS", Foreground = new SolidColorBrush(Colors.LightGray), FontSize = 10, FontWeight = Microsoft.UI.Text.FontWeights.Bold, HorizontalAlignment = HorizontalAlignment.Center });
            if (isActive && !_manageProfilesMode)
                stack.Children.Add(new TextBlock { Text = "ACTIVE", Foreground = new SolidColorBrush(ColorHelper.FromArgb(255, 229, 9, 20)), FontSize = 10, FontWeight = Microsoft.UI.Text.FontWeights.Bold, HorizontalAlignment = HorizontalAlignment.Center });

            var btn = new Button { Content = stack, Padding = new Thickness(10), Background = new SolidColorBrush(Colors.Transparent), BorderThickness = new Thickness(0) };
            btn.Click += async (_, _) =>
            {
                if (_manageProfilesMode)
                {
                    var nameBox = new TextBox { Text = profile.Name, PlaceholderText = "Profile Name" };
                    var urlBox = new TextBox { Text = profile.AvatarUrl ?? "", PlaceholderText = "Avatar Image URL (https://...)" };
                    string? pickedDataUrl = null;
                    var clearPhoto = false;
                    var pickBtn = new Button { Content = "Choose Image File..." };
                    var clearBtn = new Button { Content = "Remove Photo" };
                    pickBtn.Click += async (_, _) =>
                    {
                        var picker = new FileOpenPicker();
                        InitializeWithWindow.Initialize(picker, WindowNative.GetWindowHandle(this));
                        picker.FileTypeFilter.Add(".png");
                        picker.FileTypeFilter.Add(".jpg");
                        picker.FileTypeFilter.Add(".jpeg");
                        var file = await picker.PickSingleFileAsync();
                        if (file != null)
                        {
                            var bytes = await File.ReadAllBytesAsync(file.Path);
                            if (bytes.Length <= 220_000)
                            {
                                var ext = Path.GetExtension(file.Path).TrimStart('.').ToLowerInvariant();
                                var mime = ext == "png" ? "image/png" : "image/jpeg";
                                pickedDataUrl = $"data:{mime};base64,{Convert.ToBase64String(bytes)}";
                                urlBox.Text = "[Local Image Selected]";
                                clearPhoto = false;
                            }
                        }
                    };
                    clearBtn.Click += (_, _) => { pickedDataUrl = null; urlBox.Text = ""; clearPhoto = true; };
                    var panel = new StackPanel { Spacing = 10 };
                    panel.Children.Add(nameBox);
                    panel.Children.Add(urlBox);
                    var rowBtns = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
                    rowBtns.Children.Add(pickBtn);
                    rowBtns.Children.Add(clearBtn);
                    panel.Children.Add(rowBtns);
                    var dlg = new ContentDialog
                    {
                        Title = $"Edit {profile.Name}",
                        Content = panel,
                        PrimaryButtonText = "Save",
                        SecondaryButtonText = _backend.Profiles.Count > 1 ? "Delete" : null,
                        CloseButtonText = "Cancel",
                        XamlRoot = Content.XamlRoot
                    };
                    var res = await dlg.ShowAsync();
                    if (res == ContentDialogResult.Primary && !string.IsNullOrWhiteSpace(nameBox.Text))
                    {
                        var finalUrl = pickedDataUrl ?? (urlBox.Text.StartsWith("http", StringComparison.OrdinalIgnoreCase) ? urlBox.Text.Trim() : profile.AvatarUrl);
                        await _backend.UpdateProfileAsync(profile.Id, nameBox.Text.Trim(), profile.AvatarColor, profile.IsKids, clearPhoto ? null : finalUrl, clearPhoto);
                        RenderProfiles();
                    }
                    else if (res == ContentDialogResult.Secondary && _backend.Profiles.Count > 1)
                    {
                        await _backend.DeleteProfileAsync(profile.Id);
                        RenderProfiles();
                    }
                    return;
                }
                await _backend.SelectProfileAsync(profile);
                ShowStage("main");
                PopulateSettingsUI();
                await LoadHomeAsync();
            };
            ProfilesListPanel.Children.Add(btn);
        }
        if (_backend.Profiles.Count < 5)
        {
            var addStack = new StackPanel { Spacing = 8, HorizontalAlignment = HorizontalAlignment.Center };
            var addBox = new Border { Width = 96, Height = 96, CornerRadius = new CornerRadius(24), Background = new SolidColorBrush(ColorHelper.FromArgb(24, 255, 255, 255)), BorderBrush = new SolidColorBrush(ColorHelper.FromArgb(45, 255, 255, 255)), BorderThickness = new Thickness(1) };
            addBox.Child = new TextBlock { Text = "+", Foreground = new SolidColorBrush(Colors.White), FontSize = 36, HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
            addStack.Children.Add(addBox);
            addStack.Children.Add(new TextBlock { Text = "Add Profile", Foreground = new SolidColorBrush(Colors.LightGray), FontSize = 14, HorizontalAlignment = HorizontalAlignment.Center });
            var addBtn = new Button { Content = addStack, Padding = new Thickness(10), Background = new SolidColorBrush(Colors.Transparent), BorderThickness = new Thickness(0) };
            addBtn.Click += async (_, _) =>
            {
                var input = new TextBox { PlaceholderText = "Profile Name" };
                var dlg = new ContentDialog { Title = "Add Profile", Content = input, PrimaryButtonText = "Create", CloseButtonText = "Cancel", XamlRoot = Content.XamlRoot };
                if (await dlg.ShowAsync() == ContentDialogResult.Primary && !string.IsNullOrWhiteSpace(input.Text))
                {
                    await _backend.CreateProfileAsync(input.Text.Trim(), "#E50914", false);
                    RenderProfiles();
                }
            };
            ProfilesListPanel.Children.Add(addBtn);
        }
    }

    private async Task LoadHomeAsync()
    {
        HomeRowsPanel.Children.Clear();
        var trending = await _backend.FetchTmdbListAsync("trending/all/week?language=en-US");
        var nowPlaying = await _backend.FetchTmdbListAsync("movie/now_playing?language=en-US&page=1", "movie");
        var onAir = await _backend.FetchTmdbListAsync("tv/on_the_air?language=en-US&page=1", "tv");
        var movies = await _backend.FetchTmdbListAsync("movie/popular?language=en-US&page=1", "movie");
        var series = await _backend.FetchTmdbListAsync("tv/popular?language=en-US&page=1", "tv");

        var filteredTrending = _homeScope switch
        {
            "series" => trending.Where(x => !x.IsMovie).ToList(),
            "films" => trending.Where(x => x.IsMovie).ToList(),
            _ => trending
        };

        if (filteredTrending.FirstOrDefault() is { } hero)
        {
            AddHeroBanner(hero);
        }
        var topSeries = await _backend.FetchTmdbListAsync("trending/tv/day?language=en-US", "tv");
        var topFilms = await _backend.FetchTmdbListAsync("trending/movie/day?language=en-US", "movie");
        var action = await _backend.FetchTmdbListAsync("discover/movie?with_genres=28&sort_by=popularity.desc&language=en-US", "movie");
        if (_backend.ContinueWatching.Count > 0)
        {
            var cwItems = _backend.ContinueWatching.Select(c => new MediaItemDto
            {
                Id = int.TryParse(c.TmdbId, out var tid) ? tid : 0,
                MediaType = c.Type,
                Title = c.Type == "movie" ? c.Title : null,
                Name = c.Type == "tv" ? c.Title : null,
                PosterPath = c.PosterPath
            }).Where(x => x.Id > 0).ToList();
            if (cwItems.Count > 0) AddMediaRow("Continue Watching", cwItems);
        }
        AddMediaRow("Trending Now", filteredTrending);
        if (_homeScope != "films" && topSeries.Count > 0) AddMediaRow("Top 10 Series Today", topSeries.Take(10).ToList());
        if (_homeScope != "series" && nowPlaying.Count > 0) AddMediaRow("New Releases", nowPlaying);
        if (_backend.MyList.Count > 0) AddMediaRow("My List", _backend.MyList);
        if (_homeScope != "series" && topFilms.Count > 0) AddMediaRow("Top 10 Films Today", topFilms.Take(10).ToList());
        if (_homeScope != "films" && onAir.Count > 0) AddMediaRow("New Episodes", onAir);
        if (_homeScope != "series") AddMediaRow("Popular Movies", movies);
        if (_homeScope != "films") AddMediaRow("Popular Series", series);
        if (_homeScope != "series" && action.Count > 0) AddMediaRow("Action & Adventure", action);
    }

    private void AddHeroBanner(MediaItemDto hero)
    {
        var grid = new Grid { Height = 320, CornerRadius = new CornerRadius(12) };
        if (!string.IsNullOrEmpty(hero.BackdropUrl))
        {
            grid.Children.Add(new Image { Source = new BitmapImage(new Uri(hero.BackdropUrl)), Stretch = Stretch.UniformToFill, Opacity = 0.65 });
        }
        var info = new StackPanel { VerticalAlignment = VerticalAlignment.Bottom, Margin = new Thickness(24), Spacing = 10, MaxWidth = 520, HorizontalAlignment = HorizontalAlignment.Left };
        info.Children.Add(new TextBlock { Text = hero.DisplayTitle, Foreground = new SolidColorBrush(Colors.White), FontSize = 30, FontWeight = Microsoft.UI.Text.FontWeights.Black });
        info.Children.Add(new TextBlock { Text = hero.Overview, Foreground = new SolidColorBrush(Colors.LightGray), MaxLines = 2, TextWrapping = TextWrapping.Wrap });
        var btns = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 10 };
        var playBtn = new Button { Content = "Play", Background = new SolidColorBrush(Colors.White), Foreground = new SolidColorBrush(Colors.Black) };
        playBtn.Click += async (_, _) => await OpenPlayerAsync(hero);
        var detBtn = new Button { Content = "Details & More" };
        detBtn.Click += async (_, _) => await OpenDetailAsync(hero);
        btns.Children.Add(playBtn);
        btns.Children.Add(detBtn);
        info.Children.Add(btns);
        grid.Children.Add(info);
        HomeRowsPanel.Children.Add(grid);
    }

    private void AddMediaRow(string title, List<MediaItemDto> items)
    {
        var header = new TextBlock { Text = title, Foreground = new SolidColorBrush(Colors.White), FontSize = 20, FontWeight = Microsoft.UI.Text.FontWeights.Bold };
        HomeRowsPanel.Children.Add(header);

        var row = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 14 };
        foreach (var item in items.Take(16))
        {
            var cardGrid = new Grid { Width = 150, Height = 225, CornerRadius = new CornerRadius(8) };
            if (!string.IsNullOrEmpty(item.PosterUrl))
            {
                cardGrid.Children.Add(new Image { Source = new BitmapImage(new Uri(item.PosterUrl)), Stretch = Stretch.UniformToFill });
            }
            if (item.IsArabicOrGulfContent)
            {
                cardGrid.Children.Add(new Border
                {
                    Background = new SolidColorBrush(ColorHelper.FromArgb(190, 0, 0, 0)),
                    CornerRadius = new CornerRadius(10),
                    Padding = new Thickness(6, 2, 6, 2),
                    Margin = new Thickness(6),
                    HorizontalAlignment = HorizontalAlignment.Left,
                    VerticalAlignment = VerticalAlignment.Top,
                    Child = new TextBlock { Text = "May Not Stream", Foreground = new SolidColorBrush(Colors.White), FontSize = 10 }
                });
            }
            var btn = new Button
            {
                Content = cardGrid,
                Padding = new Thickness(0),
                Background = new SolidColorBrush(Colors.Transparent),
                BorderThickness = new Thickness(0)
            };
            ToolTipService.SetToolTip(btn, item.DisplayTitle);
            btn.Click += async (_, _) => await OpenDetailAsync(item);
            row.Children.Add(btn);
        }

        HomeRowsPanel.Children.Add(new ScrollViewer
        {
            HorizontalScrollMode = ScrollMode.Enabled,
            HorizontalScrollBarVisibility = ScrollBarVisibility.Auto,
            VerticalScrollMode = ScrollMode.Disabled,
            Content = row
        });
    }

    private async Task OpenDetailAsync(MediaItemDto item)
    {
        DetailContentPanel.Children.Clear();
        DetailPanel.Visibility = Visibility.Visible;

        var backBtn = new Button { Content = "← Back" };
        backBtn.Click += (_, _) => DetailPanel.Visibility = Visibility.Collapsed;
        DetailContentPanel.Children.Add(backBtn);

        var detail = await _backend.FetchTitleDetailAsync(item.MediaType, item.Id);

        var heroGrid = new Grid { Height = 320, CornerRadius = new CornerRadius(10) };
        if (!string.IsNullOrEmpty(item.BackdropUrl))
        {
            heroGrid.Children.Add(new Image { Source = new BitmapImage(new Uri(item.BackdropUrl)), Stretch = Stretch.UniformToFill, Opacity = 0.60 });
        }
        DetailContentPanel.Children.Add(heroGrid);

        var logoUrl = detail?.BestLogoUrl();
        if (!string.IsNullOrWhiteSpace(logoUrl))
        {
            DetailContentPanel.Children.Add(new Image { Source = new BitmapImage(new Uri(logoUrl)), MaxWidth = 300, MaxHeight = 76, Stretch = Stretch.Uniform, HorizontalAlignment = HorizontalAlignment.Left });
        }
        else
        {
            DetailContentPanel.Children.Add(new TextBlock { Text = item.DisplayTitle, Foreground = new SolidColorBrush(Colors.White), FontSize = 30, FontWeight = Microsoft.UI.Text.FontWeights.Black });
        }

        var metaRow = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 10 };
        if (item.MatchPercent is int mp)
        {
            metaRow.Children.Add(new TextBlock { Text = $"{mp}% rating", Foreground = new SolidColorBrush(ColorHelper.FromArgb(255, 69, 212, 120)), FontSize = 13, FontWeight = Microsoft.UI.Text.FontWeights.Bold, VerticalAlignment = VerticalAlignment.Center });
        }
        if (!string.IsNullOrEmpty(item.DisplayYear))
        {
            metaRow.Children.Add(new TextBlock { Text = item.DisplayYear, Foreground = new SolidColorBrush(ColorHelper.FromArgb(255, 184, 184, 184)), FontSize = 13, VerticalAlignment = VerticalAlignment.Center });
        }
        var cert = detail?.UsCertification(item.IsMovie);
        if (!string.IsNullOrWhiteSpace(cert))
        {
            metaRow.Children.Add(new Border
            {
                BorderBrush = new SolidColorBrush(ColorHelper.FromArgb(255, 128, 128, 128)),
                BorderThickness = new Thickness(1),
                CornerRadius = new CornerRadius(3),
                Padding = new Thickness(5, 1, 5, 1),
                Child = new TextBlock { Text = cert, Foreground = new SolidColorBrush(ColorHelper.FromArgb(255, 184, 184, 184)), FontSize = 11, FontWeight = Microsoft.UI.Text.FontWeights.Bold }
            });
        }
        if (item.IsMovie && detail?.Runtime is > 0)
        {
            metaRow.Children.Add(new TextBlock { Text = $"{detail.Runtime.Value / 60}h {detail.Runtime.Value % 60}m", Foreground = new SolidColorBrush(ColorHelper.FromArgb(255, 184, 184, 184)), FontSize = 13, VerticalAlignment = VerticalAlignment.Center });
        }
        else if (!item.IsMovie && detail?.NumberOfSeasons is > 0)
        {
            metaRow.Children.Add(new TextBlock { Text = $"{detail.NumberOfSeasons} {(detail.NumberOfSeasons == 1 ? "Season" : "Seasons")}", Foreground = new SolidColorBrush(ColorHelper.FromArgb(255, 184, 184, 184)), FontSize = 13, VerticalAlignment = VerticalAlignment.Center });
        }
        DetailContentPanel.Children.Add(metaRow);

        var savedCw = _backend.ContinueWatching.FirstOrDefault(x => x.Type == item.MediaType && x.TmdbId == item.Id.ToString());
        var resumeSec = savedCw?.ProgressSeconds is >= 5.0 ? savedCw.ProgressSeconds : null;

        var actions = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 10 };
        var relDate = item.ReleaseDateParsed;
        if (item.ReleaseStatus == ReleaseStatus.Upcoming && relDate.HasValue)
        {
            DetailContentPanel.Children.Add(new TextBlock { Text = SingularityDateHelper.ComingLabel(relDate.Value, item.IsMovie), Foreground = new SolidColorBrush(Colors.White), FontSize = 15, FontWeight = Microsoft.UI.Text.FontWeights.SemiBold });
            var remBtn = new Button { Content = _backend.HasReminder(item) ? "Reminder Set" : "Remind Me", Background = new SolidColorBrush(Colors.White), Foreground = new SolidColorBrush(Colors.Black), CornerRadius = new CornerRadius(5) };
            remBtn.Click += (_, _) =>
            {
                var added = _backend.ToggleReminder(item, relDate.Value);
                remBtn.Content = added ? "Reminder Set" : "Remind Me";
            };
            actions.Children.Add(remBtn);
        }
        else
        {
            var playLabel = resumeSec.HasValue
                ? (!item.IsMovie && savedCw?.Season != null && savedCw.Episode != null ? $"▶ Resume S{savedCw.Season}:E{savedCw.Episode}" : "▶ Resume")
                : "▶ Play";
            var playBtn = new Button { Content = playLabel, Background = new SolidColorBrush(Colors.White), Foreground = new SolidColorBrush(Colors.Black), CornerRadius = new CornerRadius(5), FontWeight = Microsoft.UI.Text.FontWeights.Bold };
            playBtn.Click += async (_, _) => await OpenPlayerAsync(item, savedCw?.Season ?? 1, savedCw?.Episode ?? 1, (int)(resumeSec ?? 0));
            actions.Children.Add(playBtn);
            playBtn.Focus(FocusState.Programmatic);
        }

        var trailer = detail?.Videos?.Results.FirstOrDefault(v => v.IsYouTube && v.Type.Equals("Trailer", StringComparison.OrdinalIgnoreCase))
            ?? detail?.Videos?.Results.FirstOrDefault(v => v.IsYouTube);
        if (trailer != null && !string.IsNullOrEmpty(trailer.WatchUrl))
        {
            var trBtn = new Button { Content = "Trailer", Background = new SolidColorBrush(ColorHelper.FromArgb(255, 43, 43, 43)), Foreground = new SolidColorBrush(Colors.White), CornerRadius = new CornerRadius(5) };
            trBtn.Click += async (_, _) => await Windows.System.Launcher.LaunchUriAsync(new Uri(trailer.WatchUrl));
            actions.Children.Add(trBtn);
        }

        var listBtn = new Button { Content = _backend.MyList.Any(x => x.Id == item.Id && x.MediaType == item.MediaType) ? "✓ My List" : "+ My List", Background = new SolidColorBrush(ColorHelper.FromArgb(255, 31, 31, 31)), Foreground = new SolidColorBrush(Colors.White), CornerRadius = new CornerRadius(5) };
        listBtn.Click += (_, _) =>
        {
            _backend.ToggleMyList(item);
            listBtn.Content = _backend.MyList.Any(x => x.Id == item.Id && x.MediaType == item.MediaType) ? "✓ My List" : "+ My List";
        };
        actions.Children.Add(listBtn);

        var rateBtn = new Button { Content = _backend.Liked.Any(x => x.Id == item.Id && x.MediaType == item.MediaType) ? "Rated" : "Rate", Background = new SolidColorBrush(ColorHelper.FromArgb(255, 31, 31, 31)), Foreground = new SolidColorBrush(Colors.White), CornerRadius = new CornerRadius(5) };
        rateBtn.Click += (_, _) =>
        {
            _backend.ToggleLike(item);
            rateBtn.Content = _backend.Liked.Any(x => x.Id == item.Id && x.MediaType == item.MediaType) ? "Rated" : "Rate";
        };
        actions.Children.Add(rateBtn);
        DetailContentPanel.Children.Add(actions);

        if (resumeSec.HasValue && savedCw != null)
        {
            var progRow = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 10 };
            progRow.Children.Add(new ProgressBar { Value = savedCw.ProgressFraction * 100.0, Maximum = 100.0, Width = 180, Height = 3, Foreground = new SolidColorBrush(ParseHexColor(_backend.AppSettings.AccentColorHex)) });
            var remStr = SingularityPlaybackFormatter.FormatRemaining(savedCw.ProgressSeconds, savedCw.DurationSeconds);
            if (!string.IsNullOrEmpty(remStr))
            {
                progRow.Children.Add(new TextBlock { Text = remStr, Foreground = new SolidColorBrush(ColorHelper.FromArgb(255, 184, 184, 184)), FontSize = 12, VerticalAlignment = VerticalAlignment.Center });
            }
            DetailContentPanel.Children.Add(progRow);
        }

        if (item.IsArabicOrGulfContent)
        {
            DetailContentPanel.Children.Add(new TextBlock { Text = "Arabic/Gulf titles may have limited availability on external servers.", Foreground = new SolidColorBrush(Colors.Orange), FontSize = 13 });
        }
        DetailContentPanel.Children.Add(new TextBlock { Text = item.Overview, Foreground = new SolidColorBrush(Colors.White), TextWrapping = TextWrapping.Wrap, FontSize = 14.5 });

        var cast = detail?.Credits?.Cast.Take(14).ToList() ?? new();
        if (cast.Count > 0)
        {
            DetailContentPanel.Children.Add(new TextBlock { Text = $"Starring: {string.Join(", ", cast.Take(4).Select(c => c.Name))}", Foreground = new SolidColorBrush(ColorHelper.FromArgb(255, 184, 184, 184)), FontSize = 12.5 });
        }
        var dir = detail?.DirectorOrCreators(item.IsMovie);
        if (!string.IsNullOrWhiteSpace(dir))
        {
            DetailContentPanel.Children.Add(new TextBlock { Text = $"{(item.IsMovie ? "Directors" : "Creators")}: {dir}", Foreground = new SolidColorBrush(ColorHelper.FromArgb(255, 184, 184, 184)), FontSize = 12.5 });
        }

        if (cast.Count > 0)
        {
            DetailContentPanel.Children.Add(new TextBlock { Text = "Cast & Crew", Foreground = new SolidColorBrush(Colors.White), FontSize = 18, FontWeight = Microsoft.UI.Text.FontWeights.Bold });
            var castRow = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 14 };
            foreach (var p in cast)
            {
                var card = new StackPanel { Width = 100, Spacing = 4 };
                if (!string.IsNullOrEmpty(p.ProfileUrl))
                {
                    card.Children.Add(new Image { Source = new BitmapImage(new Uri(p.ProfileUrl)), Width = 80, Height = 80, Stretch = Stretch.UniformToFill });
                }
                card.Children.Add(new TextBlock { Text = p.Name, Foreground = new SolidColorBrush(Colors.White), FontSize = 12, FontWeight = Microsoft.UI.Text.FontWeights.SemiBold, TextTrimming = TextTrimming.CharacterEllipsis });
                if (!string.IsNullOrWhiteSpace(p.Character))
                {
                    card.Children.Add(new TextBlock { Text = p.Character, Foreground = new SolidColorBrush(Colors.Gray), FontSize = 11, TextTrimming = TextTrimming.CharacterEllipsis });
                }
                castRow.Children.Add(card);
            }
            DetailContentPanel.Children.Add(new ScrollViewer { HorizontalScrollMode = ScrollMode.Enabled, HorizontalScrollBarVisibility = ScrollBarVisibility.Auto, VerticalScrollMode = ScrollMode.Disabled, Content = castRow });
        }

        if (!item.IsMovie)
        {
            var seasons = detail?.Seasons.Where(s => s.SeasonNumber > 0).ToList() ?? new();
            var episodesHost = new StackPanel { Spacing = 8 };
            async Task LoadSeasonAsync(int seasonNum)
            {
                episodesHost.Children.Clear();
                var eps = await _backend.FetchSeasonEpisodesAsync(item.Id, seasonNum);
                foreach (var ep in eps)
                {
                    var aired = ep.HasAired;
                    var epLabel = aired
                        ? $"{ep.EpisodeNumber}. {ep.Name} {(ep.Runtime is > 0 ? $"({ep.Runtime}m)" : "")}"
                        : $"{ep.EpisodeNumber}. {ep.Name} (Coming {ep.AirDate})";
                    var epBtn = new Button
                    {
                        Content = epLabel,
                        IsEnabled = aired,
                        HorizontalAlignment = HorizontalAlignment.Stretch,
                        HorizontalContentAlignment = HorizontalAlignment.Left
                    };
                    epBtn.Click += async (_, _) => await OpenPlayerAsync(item, seasonNum, ep.EpisodeNumber);
                    episodesHost.Children.Add(epBtn);
                }
            }
            if (seasons.Count > 0)
            {
                var seasonRow = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
                foreach (var s in seasons)
                {
                    var sBtn = new Button { Content = s.DisplayName };
                    sBtn.Click += async (_, _) => await LoadSeasonAsync(s.SeasonNumber);
                    seasonRow.Children.Add(sBtn);
                }
                DetailContentPanel.Children.Add(seasonRow);
                await LoadSeasonAsync(seasons[0].SeasonNumber);
            }
            else
            {
                await LoadSeasonAsync(1);
            }
            DetailContentPanel.Children.Add(episodesHost);
        }

        var related = (detail?.Recommendations?.Results ?? new()).Concat(detail?.Similar?.Results ?? new())
            .Where(r => r.Id != item.Id && !string.IsNullOrEmpty(r.PosterPath))
            .GroupBy(r => $"{r.MediaType}-{r.Id}")
            .Select(g => g.First())
            .Take(12)
            .ToList();
        if (related.Count > 0)
        {
            DetailContentPanel.Children.Add(new TextBlock { Text = "More Like This", Foreground = new SolidColorBrush(Colors.White), FontSize = 18, FontWeight = Microsoft.UI.Text.FontWeights.Bold });
            var relRow = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 12 };
            foreach (var r in related)
            {
                if (string.IsNullOrEmpty(r.MediaType)) r.MediaType = item.MediaType;
                var rb = new Button
                {
                    Content = new Image { Source = new BitmapImage(new Uri(r.PosterUrl)), Width = 120, Height = 180, Stretch = Stretch.UniformToFill },
                    Padding = new Thickness(0),
                    Background = new SolidColorBrush(Colors.Transparent),
                    BorderThickness = new Thickness(0)
                };
                rb.Click += async (_, _) => await OpenDetailAsync(r);
                relRow.Children.Add(rb);
            }
            DetailContentPanel.Children.Add(new ScrollViewer { HorizontalScrollMode = ScrollMode.Enabled, HorizontalScrollBarVisibility = ScrollBarVisibility.Auto, VerticalScrollMode = ScrollMode.Disabled, Content = relRow });
        }
    }

    private async Task OpenPlayerAsync(MediaItemDto item, int season = 1, int episode = 1, int startSeconds = 0)
    {
        _activePlayerMedia = item;
        _activePlayerSeason = season;
        _activePlayerEpisode = episode;
        var resolvedStart = startSeconds >= 5 ? startSeconds : (int)(_backend.ProgressSecondsFor(item.MediaType, item.Id, item.IsMovie ? null : season, item.IsMovie ? null : episode) ?? 0);
        _currentStreamUrl = item.BuildStreamUrl(_backend.AppSettings.StreamingProviderBaseURL, _backend.AppSettings.AccentColorHex, season, episode, resolvedStart);
        PlayerErrorTitle.Text = item.DisplayTitle;
        PlayerErrorPanel.Visibility = Visibility.Collapsed;
        PlayerPanel.Visibility = Visibility.Visible;

        await PlayerWebView.EnsureCoreWebView2Async();
        var core = PlayerWebView.CoreWebView2;
        core.NewWindowRequested += (_, args) => { args.Handled = true; };
        core.AddWebResourceRequestedFilter("*", CoreWebView2WebResourceContext.All);
        core.WebResourceRequested += (_, args) =>
        {
            var uri = args.Request.Uri.ToLowerInvariant();
            if (BlockedAdDomains.Any(d => uri.Contains(d)))
            {
                AdTrackerService.RecordBlocked(uri, AdEventType.AdBlocked, item.DisplayTitle);
                args.Response = core.Environment.CreateWebResourceResponse(null, 403, "Blocked", "");
            }
        };
        core.NavigationStarting += (_, args) =>
        {
            if (Uri.TryCreate(args.Uri, UriKind.Absolute, out var u) && !u.Host.Contains("vidly", StringComparison.OrdinalIgnoreCase))
            {
                AdTrackerService.RecordBlocked(u.Host, AdEventType.RedirectBlocked, item.DisplayTitle);
                args.Cancel = true;
            }
        };
        core.WebMessageReceived += (s, args) =>
        {
            try
            {
                using var doc = JsonDocument.Parse(args.TryGetWebMessageAsString());
                var type = doc.RootElement.GetProperty("type").GetString();
                if (type == "pref")
                {
                    var p = doc.RootElement.GetProperty("payload");
                    var k = p.GetProperty("key").GetString();
                    var v = p.GetProperty("value").GetString() ?? "";
                    if (k == "preferredQuality") _backend.PlayerPrefs.PreferredQuality = v;
                    else if (k == "subtitleLanguage") _backend.PlayerPrefs.SubtitleLanguage = v;
                    else if (k == "playbackSpeed") _backend.PlayerPrefs.PlaybackSpeed = v;
                    _ = _backend.PushActiveProfileAsync();
                }
                else if (type == "progress" && _activePlayerMedia != null)
                {
                    var p = doc.RootElement.GetProperty("payload");
                    var ct = p.TryGetProperty("currentTime", out var ctEl) ? ctEl.GetDouble() : 0.0;
                    var dur = p.TryGetProperty("duration", out var durEl) ? durEl.GetDouble() : 0.0;
                    var paused = p.TryGetProperty("paused", out var pEl) && pEl.GetBoolean();
                    _ = _backend.RecordProgressAsync(_activePlayerMedia, _activePlayerSeason, _activePlayerEpisode, ct, dur, !paused);
                }
                else if (type == "error")
                {
                    PlayerErrorPanel.Visibility = Visibility.Visible;
                }
            }
            catch { }
        };
        core.NavigationCompleted += async (_, args) =>
        {
            if (!args.IsSuccess)
            {
                PlayerErrorPanel.Visibility = Visibility.Visible;
                return;
            }
            var jsPath = Path.Combine(AppContext.BaseDirectory, "Assets", "WebPlayer", "vidly-player.js");
            var cssPath = Path.Combine(AppContext.BaseDirectory, "Assets", "WebPlayer", "vidly-player.css");
            var js = File.Exists(jsPath) ? File.ReadAllText(jsPath) : "";
            var css = File.Exists(cssPath) ? File.ReadAllText(cssPath).Replace("\\", "\\\\").Replace("'", "\\'").Replace("\n", "\\n") : "";
            var prefsJson = JsonSerializer.Serialize(_backend.PlayerPrefs);
            var metaJson = JsonSerializer.Serialize(new { title = item.DisplayTitle, isMovie = item.IsMovie, subtitle = item.IsMovie ? "" : $"S{season}:E{episode}", poster = item.PosterUrl });
            var initScript = $"document.documentElement.style.setProperty('--sg-accent', '#{_backend.AppSettings.AccentColorHex}'); var st = document.createElement('style'); st.textContent = '{css}'; document.head.appendChild(st); window.__singularityMeta = {metaJson}; window.__sgIsTV = false; window.__sgSavedPrefs = {prefsJson}; {js}";
            await core.ExecuteScriptAsync(initScript);
        };
        PlayerWebView.Source = new Uri(_currentStreamUrl);
    }

    private void PopulateSettingsUI()
    {
        SettingsAccountInfo.Text = $"Profile: {_backend.ActiveProfile?.Name ?? "Main"} · {_backend.Session?.Email ?? ""}";
        ServerHostBox.Text = _backend.AppSettings.StreamingProviderBaseURL;
        TmdbKeyBox.Text = _backend.AppSettings.CustomTmdbToken;
        QualityCombo.SelectedItem = _backend.PlayerPrefs.PreferredQuality;
        SubtitleCombo.SelectedItem = _backend.PlayerPrefs.SubtitleLanguage;

        AccentSwatchesPanel.Children.Clear();
        foreach (var preset in SingularityConstants.AccentPresets)
        {
            var b = new Button { Content = preset.Name, Tag = preset.Hex };
            b.Click += (_, _) =>
            {
                _backend.AppSettings.AccentColorHex = preset.Hex;
                _backend.SaveAppSettings();
            };
            AccentSwatchesPanel.Children.Add(b);
        }
    }

    private void SaveServer_Click(object sender, RoutedEventArgs e)
    {
        _backend.AppSettings.StreamingProviderBaseURL = ServerHostBox.Text.Trim();
        _backend.SaveAppSettings();
    }

    private void SaveTmdbKey_Click(object sender, RoutedEventArgs e)
    {
        _backend.AppSettings.CustomTmdbToken = TmdbKeyBox.Text.Trim();
        _backend.SaveAppSettings();
    }

    private void QualityCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (QualityCombo.SelectedItem is string q)
        {
            _backend.PlayerPrefs.PreferredQuality = q;
            _ = _backend.PushActiveProfileAsync();
        }
    }

    private void SubtitleCombo_SelectionChanged(object sender, SelectionChangedEventArgs e)
    {
        if (SubtitleCombo.SelectedItem is string s)
        {
            _backend.PlayerPrefs.SubtitleLanguage = s;
            _ = _backend.PushActiveProfileAsync();
        }
    }

    private void DeleteHistory_Click(object sender, RoutedEventArgs e)
    {
        _backend.History.Clear();
        _ = _backend.PushActiveProfileAsync();
    }

    private async void FilterAll_Click(object sender, RoutedEventArgs e) { _homeScope = "all"; await LoadHomeAsync(); }
    private async void FilterSeries_Click(object sender, RoutedEventArgs e) { _homeScope = "series"; await LoadHomeAsync(); }
    private async void FilterFilms_Click(object sender, RoutedEventArgs e) { _homeScope = "films"; await LoadHomeAsync(); }

    private void RetryPlayer_Click(object sender, RoutedEventArgs e)
    {
        if (_currentStreamUrl == null) return;
        PlayerErrorPanel.Visibility = Visibility.Collapsed;
        PlayerWebView.Source = new Uri(_currentStreamUrl);
    }

    private void ClosePlayer_Click(object sender, RoutedEventArgs e)
    {
        PlayerPanel.Visibility = Visibility.Collapsed;
        PlayerWebView.Source = new Uri("about:blank");
    }

    private async void MainNavView_SelectionChanged(NavigationView sender, NavigationViewSelectionChangedEventArgs args)
    {
        DetailPanel.Visibility = Visibility.Collapsed;
        var tag = (args.SelectedItem as NavigationViewItem)?.Tag?.ToString();
        HomeScroll.Visibility = tag == "home" ? Visibility.Visible : Visibility.Collapsed;
        NewHotScroll.Visibility = tag == "newhot" ? Visibility.Visible : Visibility.Collapsed;
        SearchPanel.Visibility = tag == "search" ? Visibility.Visible : Visibility.Collapsed;
        if (tag == "search")
        {
            EnsureSearchInitialized();
            SearchBox.Focus(FocusState.Programmatic);
            _ = ExecuteAdvancedSearchAsync(resetPage: true);
        }
        MyPanel.Visibility = tag == "my" ? Visibility.Visible : Visibility.Collapsed;
        SettingsScroll.Visibility = tag == "settings" ? Visibility.Visible : Visibility.Collapsed;

        if (tag == "newhot")
        {
            NewHotPanel.Children.Clear();
            NewHotPanel.Children.Add(new TextBlock { Text = "Coming Soon", Foreground = new SolidColorBrush(Colors.White), FontSize = 24, FontWeight = Microsoft.UI.Text.FontWeights.Bold });
            var upcoming = await _backend.FetchUpcomingComingSoonAsync();
            foreach (var u in upcoming)
            {
                var relDate = u.ReleaseDateParsed;
                var row = new Grid { ColumnSpacing = 16, Margin = new Thickness(0, 6, 0, 12) };
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(64) });
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(240) });
                row.ColumnDefinitions.Add(new ColumnDefinition { Width = new GridLength(1, GridUnitType.Star) });

                if (relDate.HasValue)
                {
                    var dateCol = new StackPanel { HorizontalAlignment = HorizontalAlignment.Center };
                    dateCol.Children.Add(new TextBlock { Text = relDate.Value.ToString("MMM").ToUpperInvariant(), Foreground = new SolidColorBrush(Colors.LightGray), FontSize = 13, HorizontalAlignment = HorizontalAlignment.Center });
                    dateCol.Children.Add(new TextBlock { Text = relDate.Value.Day.ToString(), Foreground = new SolidColorBrush(Colors.White), FontSize = 28, FontWeight = Microsoft.UI.Text.FontWeights.Bold, HorizontalAlignment = HorizontalAlignment.Center });
                    Grid.SetColumn(dateCol, 0);
                    row.Children.Add(dateCol);
                }

                var imgBtn = new Button { Padding = new Thickness(0), Background = new SolidColorBrush(Colors.Transparent), BorderThickness = new Thickness(0) };
                if (!string.IsNullOrEmpty(u.BackdropUrl))
                {
                    imgBtn.Content = new Image { Source = new BitmapImage(new Uri(u.BackdropUrl)), Width = 240, Height = 135, Stretch = Stretch.UniformToFill };
                }
                imgBtn.Click += async (_, _) => await OpenDetailAsync(u);
                Grid.SetColumn(imgBtn, 1);
                row.Children.Add(imgBtn);

                var infoCol = new StackPanel { Spacing = 6 };
                infoCol.Children.Add(new TextBlock { Text = u.DisplayTitle, Foreground = new SolidColorBrush(Colors.White), FontSize = 18, FontWeight = Microsoft.UI.Text.FontWeights.Bold });
                if (relDate.HasValue)
                {
                    infoCol.Children.Add(new TextBlock { Text = SingularityDateHelper.ComingLabel(relDate.Value, u.IsMovie), Foreground = new SolidColorBrush(Colors.White), FontSize = 13, FontWeight = Microsoft.UI.Text.FontWeights.SemiBold });
                }
                infoCol.Children.Add(new TextBlock { Text = u.Overview, Foreground = new SolidColorBrush(Colors.LightGray), FontSize = 13, MaxLines = 3, TextWrapping = TextWrapping.Wrap });
                var btnBar = new StackPanel { Orientation = Orientation.Horizontal, Spacing = 8 };
                var remBtn = new Button { Content = _backend.HasReminder(u) ? "Reminder Set" : "Remind Me" };
                remBtn.Click += (_, _) =>
                {
                    var d = relDate ?? DateTime.Today.AddDays(1);
                    remBtn.Content = _backend.ToggleReminder(u, d) ? "Reminder Set" : "Remind Me";
                };
                var infoBtn = new Button { Content = "Info" };
                infoBtn.Click += async (_, _) => await OpenDetailAsync(u);
                btnBar.Children.Add(remBtn);
                btnBar.Children.Add(infoBtn);
                infoCol.Children.Add(btnBar);
                Grid.SetColumn(infoCol, 2);
                row.Children.Add(infoCol);

                NewHotPanel.Children.Add(row);
            }
        }
        else if (tag == "my")
        {
            MyContentPanel.Children.Clear();
            MyContentPanel.Children.Add(new TextBlock { Text = $"{_backend.ActiveProfile?.Name ?? "Profile"} · {_backend.MyList.Count} in My List", Foreground = new SolidColorBrush(Colors.White), FontSize = 22, FontWeight = Microsoft.UI.Text.FontWeights.Bold });
            foreach (var m in _backend.MyList)
            {
                var btn = new Button { Content = m.DisplayTitle };
                btn.Click += async (_, _) => await OpenDetailAsync(m);
                MyContentPanel.Children.Add(btn);
            }
        }
    }

    private void EnsureSearchInitialized()
    {
        if (_searchInitialized) return;
        _searchInitialized = true;
        SearchTypeCombo.SelectedIndex = 0;
        SearchSortCombo.SelectedIndex = 0;
        SearchYearCombo.SelectedIndex = 0;
        SearchCategoryCombo.Items.Clear();
        SearchCategoryCombo.Items.Add("All Genres");
        foreach (var cat in SingularityCategories.Catalog) SearchCategoryCombo.Items.Add(cat.Title);
        SearchCategoryCombo.SelectedIndex = 0;
    }

    private async void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
    {
        var gen = ++_searchGeneration;
        await Task.Delay(300);
        if (gen != _searchGeneration) return;
        await ExecuteAdvancedSearchAsync(resetPage: true);
    }

    private async void SearchFilter_Changed(object sender, SelectionChangedEventArgs e)
    {
        if (!_searchInitialized) return;
        await ExecuteAdvancedSearchAsync(resetPage: true);
    }

    private async void ClearSearch_Click(object sender, RoutedEventArgs e)
    {
        SearchBox.Text = "";
        SearchTypeCombo.SelectedIndex = 0;
        SearchCategoryCombo.SelectedIndex = 0;
        SearchSortCombo.SelectedIndex = 0;
        SearchYearCombo.SelectedIndex = 0;
        await ExecuteAdvancedSearchAsync(resetPage: true);
    }

    private async void LoadMoreSearch_Click(object sender, RoutedEventArgs e)
    {
        _searchPage++;
        await ExecuteAdvancedSearchAsync(resetPage: false);
    }

    private async Task ExecuteAdvancedSearchAsync(bool resetPage)
    {
        var gen = ++_searchGeneration;
        if (resetPage)
        {
            _searchPage = 1;
            SearchResultsPanel.Children.Clear();
        }
        var q = SearchBox.Text.Trim();
        var typeFilter = SearchTypeCombo.SelectedItem as string ?? "All";
        var catTitle = SearchCategoryCombo.SelectedItem as string ?? "All Genres";
        var cat = SingularityCategories.Catalog.FirstOrDefault(c => c.Title == catTitle);
        var sortOpt = SearchSortCombo.SelectedItem as string ?? "Popularity";
        var yearStr = SearchYearCombo.SelectedItem as string;
        int? year = int.TryParse(yearStr, out var y) ? y : null;

        var hasFilters = !string.IsNullOrEmpty(q) || typeFilter != "All" || cat != null || sortOpt != "Popularity" || year.HasValue;
        List<MediaItemDto> results;
        if (!hasFilters)
        {
            results = await _backend.FetchTmdbListAsync("trending/all/day?language=en-US");
            LoadMoreSearchBtn.Visibility = Visibility.Collapsed;
        }
        else if (!string.IsNullOrEmpty(q))
        {
            results = await _backend.FetchTmdbListAsync($"search/multi?query={Uri.EscapeDataString(q)}&include_adult=false&language=en-US&page={_searchPage}");
            LoadMoreSearchBtn.Visibility = results.Count >= 16 ? Visibility.Visible : Visibility.Collapsed;
        }
        else
        {
            results = await _backend.DiscoverAdvancedAsync(typeFilter, cat, sortOpt, year, _searchPage);
            LoadMoreSearchBtn.Visibility = results.Count >= 16 ? Visibility.Visible : Visibility.Collapsed;
        }
        if (gen != _searchGeneration) return;
        foreach (var r in results)
        {
            var label = string.IsNullOrEmpty(r.DisplayYear) ? r.DisplayTitle : $"{r.DisplayTitle} ({r.DisplayYear})";
            var btn = new Button { Content = label, HorizontalAlignment = HorizontalAlignment.Stretch, HorizontalContentAlignment = HorizontalAlignment.Left };
            btn.Click += async (_, _) => await OpenDetailAsync(r);
            SearchResultsPanel.Children.Add(btn);
        }
    }

    private void SwitchProfile_Click(object sender, RoutedEventArgs e) => ShowStage("profiles");

    private void SignOut_Click(object sender, RoutedEventArgs e)
    {
        _backend.SignOut();
        ShowStage("auth");
    }

    private void RootGrid_KeyDown(object sender, KeyRoutedEventArgs e)
    {
        if (e.Key == VirtualKey.F)
        {
            _isFullScreen = !_isFullScreen;
            AppWindow.SetPresenter(_isFullScreen ? AppWindowPresenterKind.FullScreen : AppWindowPresenterKind.Default);
        }
        else if (e.Key == VirtualKey.Escape && PlayerPanel.Visibility == Visibility.Visible)
        {
            ClosePlayer_Click(sender, e);
        }
    }
}
