package com.singularity.tv.core.model

import java.util.Locale

data class AppLanguageOption(val code: String, val nativeName: String)

data class SingularityLocalizedStrings(
    val home: String,
    val newAndHot: String,
    val search: String,
    val mySingularity: String,
    val settings: String,
    val series: String,
    val films: String,
    val categories: String,
    val play: String,
    val resume: String,
    val trailer: String,
    val myList: String,
    val rate: String,
    val rated: String,
    val share: String,
    val remindMe: String,
    val reminderSet: String,
    val continueWatching: String,
    val trendingNow: String,
    val top10Today: String,
    val popularMovies: String,
    val popularSeries: String,
    val episodes: String,
    val moreLikeThis: String,
    val trailersAndMore: String,
    val comingSoon: String,
    val topSearches: String,
    val searchHint: String,
    val all: String,
    val movies: String,
    val loadMore: String,
    val language: String,
    val followSystem: String,
    val switchProfile: String,
    val signOut: String,
    val back: String
)

object SingularityLocalization {
    val supportedLanguages = listOf(
        AppLanguageOption("system", "Follow System"),
        AppLanguageOption("en", "English"),
        AppLanguageOption("ar", "العربية"),
        AppLanguageOption("fr", "Français"),
        AppLanguageOption("es", "Español"),
        AppLanguageOption("de", "Deutsch"),
        AppLanguageOption("tr", "Türkçe"),
        AppLanguageOption("hi", "हिन्दी"),
        AppLanguageOption("ja", "日本語"),
        AppLanguageOption("ko", "한국어")
    )

    fun resolveCode(configuredCode: String): String {
        if (configuredCode != "system" && configuredCode.isNotBlank()) return configuredCode
        val sys = Locale.getDefault().language.lowercase(Locale.US)
        return if (supportedLanguages.any { it.code == sys }) sys else "en"
    }

    fun isRtl(configuredCode: String): Boolean = resolveCode(configuredCode) == "ar"

    fun strings(configuredCode: String): SingularityLocalizedStrings {
        return when (resolveCode(configuredCode)) {
            "ar" -> SingularityLocalizedStrings(
                home = "الرئيسية", newAndHot = "الجديد والقريب", search = "بحث", mySingularity = "حسابي",
                settings = "الإعدادات", series = "مسلسلات", films = "أفلام", categories = "التصنيفات",
                play = "تشغيل", resume = "استكمال", trailer = "الإعلان", myList = "قائمتي",
                rate = "تقييم", rated = "تم التقييم", share = "مشاركة", remindMe = "ذكّرني",
                reminderSet = "تم التذكير", continueWatching = "متابعة المشاهدة", trendingNow = "الأكثر رواجاً",
                top10Today = "أفضل 10 اليوم", popularMovies = "أفلام شائعة", popularSeries = "مسلسلات شائعة",
                episodes = "الحلقات", moreLikeThis = "أعمال مشابهة", trailersAndMore = "الإعلانات والمزيد",
                comingSoon = "قريباً", topSearches = "الأكثر بحثاً", searchHint = "ابحث عن أفلام ومسلسلات...",
                all = "الكل", movies = "أفلام", loadMore = "عرض المزيد", language = "لغة التطبيق",
                followSystem = "اتّباع لغة النظام", switchProfile = "تبديل الملف", signOut = "تسجيل الخروج", back = "رجوع"
            )
            "fr" -> SingularityLocalizedStrings(
                home = "Accueil", newAndHot = "Nouveautés", search = "Rechercher", mySingularity = "Mon Espace",
                settings = "Paramètres", series = "Séries", films = "Films", categories = "Catégories",
                play = "Lecture", resume = "Reprendre", trailer = "Bande-annonce", myList = "Ma liste",
                rate = "Noter", rated = "Noté", share = "Partager", remindMe = "Me rappeler",
                reminderSet = "Rappel activé", continueWatching = "Reprendre", trendingNow = "Tendances",
                top10Today = "Top 10", popularMovies = "Films populaires", popularSeries = "Séries populaires",
                episodes = "Épisodes", moreLikeThis = "Titres similaires", trailersAndMore = "Bandes-annonces",
                comingSoon = "Bientôt", topSearches = "Meilleures recherches", searchHint = "Rechercher films, séries...",
                all = "Tout", movies = "Films", loadMore = "Charger plus", language = "Langue",
                followSystem = "Langue du système", switchProfile = "Changer de profil", signOut = "Déconnexion", back = "Retour"
            )
            "es" -> SingularityLocalizedStrings(
                home = "Inicio", newAndHot = "Novedades", search = "Buscar", mySingularity = "Mi Espacio",
                settings = "Ajustes", series = "Series", films = "Películas", categories = "Categorías",
                play = "Reproducir", resume = "Reanudar", trailer = "Tráiler", myList = "Mi lista",
                rate = "Calificar", rated = "Calificado", share = "Compartir", remindMe = "Recordarme",
                reminderSet = "Recordatorio", continueWatching = "Seguir viendo", trendingNow = "Tendencias",
                top10Today = "Top 10 hoy", popularMovies = "Películas populares", popularSeries = "Series populares",
                episodes = "Episodios", moreLikeThis = "Más títulos similares", trailersAndMore = "Tráilers y más",
                comingSoon = "Próximamente", topSearches = "Más buscados", searchHint = "Buscar películas, series...",
                all = "Todo", movies = "Películas", loadMore = "Cargar más", language = "Idioma",
                followSystem = "Idioma del sistema", switchProfile = "Cambiar perfil", signOut = "Cerrar sesión", back = "Atrás"
            )
            "de" -> SingularityLocalizedStrings(
                home = "Start", newAndHot = "Neu & beliebt", search = "Suche", mySingularity = "Mein Bereich",
                settings = "Einstellungen", series = "Serien", films = "Filme", categories = "Kategorien",
                play = "Abspielen", resume = "Fortsetzen", trailer = "Trailer", myList = "Meine Liste",
                rate = "Bewerten", rated = "Bewertet", share = "Teilen", remindMe = "Erinnern",
                reminderSet = "Erinnerung aktiv", continueWatching = "Weiterschauen", trendingNow = "Aktuell beliebt",
                top10Today = "Top 10 heute", popularMovies = "Beliebte Filme", popularSeries = "Beliebte Serien",
                episodes = "Folgen", moreLikeThis = "Ähnliche Titel", trailersAndMore = "Trailer & mehr",
                comingSoon = "Demnächst", topSearches = "Top-Suchen", searchHint = "Filme & Serien suchen...",
                all = "Alle", movies = "Filme", loadMore = "Mehr laden", language = "App-Sprache",
                followSystem = "Systemsprache", switchProfile = "Profil wechseln", signOut = "Abmelden", back = "Zurück"
            )
            "tr" -> SingularityLocalizedStrings(
                home = "Ana Sayfa", newAndHot = "Yeni ve Popüler", search = "Ara", mySingularity = "Profilim",
                settings = "Ayarlar", series = "Diziler", films = "Filmler", categories = "Kategoriler",
                play = "Oynat", resume = "Devam Et", trailer = "Fragman", myList = "Listem",
                rate = "Puanla", rated = "Puanlandı", share = "Paylaş", remindMe = "Hatırlat",
                reminderSet = "Hatırlatıcı Açık", continueWatching = "İzlemeye Devam Et", trendingNow = "Gündemdekiler",
                top10Today = "Bugünün İlk 10'u", popularMovies = "Popüler Filmler", popularSeries = "Popüler Diziler",
                episodes = "Bölümler", moreLikeThis = "Benzer İçerikler", trailersAndMore = "Fragmanlar",
                comingSoon = "Yakında", topSearches = "En Çok Arananlar", searchHint = "Film, dizi ara...",
                all = "Tümü", movies = "Filmler", loadMore = "Daha Fazla", language = "Uygulama Dili",
                followSystem = "Sistem Dilini Takip Et", switchProfile = "Profil Değiştir", signOut = "Çıkış Yap", back = "Geri"
            )
            "hi" -> SingularityLocalizedStrings(
                home = "होम", newAndHot = "नया और चर्चित", search = "खोजें", mySingularity = "मेरा स्पेस",
                settings = "सेटिंग्स", series = "सीरीज़", films = "फ़िल्में", categories = "श्रेणियाँ",
                play = "चलाएँ", resume = "जारी रखें", trailer = "ट्रेलर", myList = "मेरी सूची",
                rate = "रेट करें", rated = "रेटेड", share = "शेयर", remindMe = "रिमाइंडर",
                reminderSet = "रिमाइंडर सेट", continueWatching = "देखना जारी रखें", trendingNow = "ट्रेंडिंग",
                top10Today = "आज के टॉप 10", popularMovies = "लोकप्रिय फ़िल्में", popularSeries = "लोकप्रिय सीरीज़",
                episodes = "एपिसोड", moreLikeThis = "मिलते-जुलते", trailersAndMore = "ट्रेलर और अधिक",
                comingSoon = "जल्द आ रहा है", topSearches = "शीर्ष खोजें", searchHint = "फ़िल्में और सीरीज़ खोजें...",
                all = "सभी", movies = "फ़िल्में", loadMore = "और लोड करें", language = "ऐप भाषा",
                followSystem = "सिस्टम भाषा का पालन करें", switchProfile = "प्रोफ़ाइल बदलें", signOut = "साइन आउट", back = "वापस"
            )
            "ja" -> SingularityLocalizedStrings(
                home = "ホーム", newAndHot = "新着", search = "検索", mySingularity = "マイページ",
                settings = "設定", series = "ドラマ", films = "映画", categories = "ジャンル",
                play = "再生", resume = "続きから再生", trailer = "予告編", myList = "マイリスト",
                rate = "評価", rated = "評価済み", share = "共有", remindMe = "リマインド",
                reminderSet = "設定済み", continueWatching = "視聴中", trendingNow = "急上昇",
                top10Today = "今日のTOP10", popularMovies = "人気の映画", popularSeries = "人気のドラマ",
                episodes = "エピソード", moreLikeThis = "おすすめ", trailersAndMore = "予告編など",
                comingSoon = "近日公開", topSearches = "人気の検索", searchHint = "映画・ドラマを検索...",
                all = "すべて", movies = "映画", loadMore = "もっと見る", language = "言語",
                followSystem = "システム言語に従う", switchProfile = "プロフィール切替", signOut = "ログアウト", back = "戻る"
            )
            "ko" -> SingularityLocalizedStrings(
                home = "홈", newAndHot = "NEW & 핫", search = "검색", mySingularity = "MY",
                settings = "설정", series = "시리즈", films = "영화", categories = "카테고리",
                play = "재생", resume = "이어보기", trailer = "예고편", myList = "찜한 콘텐츠",
                rate = "평가", rated = "평가함", share = "공유", remindMe = "알림 받기",
                reminderSet = "알림 설정됨", continueWatching = "시청 중인 콘텐츠", trendingNow = "지금 뜨는 콘텐츠",
                top10Today = "오늘의 TOP 10", popularMovies = "인기 영화", popularSeries = "인기 시리즈",
                episodes = "회차", moreLikeThis = "비슷한 콘텐츠", trailersAndMore = "예고편 및 다른 영상",
                comingSoon = "공개 예정", topSearches = "인기 검색", searchHint = "영화, 시리즈 검색...",
                all = "전체", movies = "영화", loadMore = "더 보기", language = "앱 언어",
                followSystem = "시스템 언어 따르기", switchProfile = "프로필 전환", signOut = "로그아웃", back = "뒤로"
            )
            else -> SingularityLocalizedStrings(
                home = "Home", newAndHot = "New & Hot", search = "Search", mySingularity = "My SingularityTV",
                settings = "Settings", series = "Series", films = "Films", categories = "Categories",
                play = "Play", resume = "Resume", trailer = "Trailer", myList = "My List",
                rate = "Rate", rated = "Rated", share = "Share", remindMe = "Remind Me",
                reminderSet = "Reminder Set", continueWatching = "Continue Watching", trendingNow = "Trending Now",
                top10Today = "Top 10 Today", popularMovies = "Popular Movies", popularSeries = "Popular Series",
                episodes = "Episodes", moreLikeThis = "More Like This", trailersAndMore = "Trailers & More",
                comingSoon = "Coming Soon", topSearches = "Top Searches", searchHint = "Search movies, series, genres...",
                all = "All", movies = "Movies", loadMore = "Load More", language = "App Language",
                followSystem = "Follow System", switchProfile = "Switch Profile", signOut = "Sign Out", back = "Back"
            )
        }
    }
}
