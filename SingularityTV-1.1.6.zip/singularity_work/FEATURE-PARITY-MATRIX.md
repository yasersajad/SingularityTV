# SingularityTV 1.1.6 — Cross-Platform Feature Parity Matrix

| Feature / Subsystem | iOS (Master) | Android Mobile | Android TV | Windows Desktop |
| :--- | :--- | :--- | :--- | :--- |
| **5-Mode Supabase Auth** | SignIn, SignUp, VerifyOTP, Forgot, Reset | 5-Mode Parity | 5-Mode Parity (`380dp` scaled card) | 5-Mode Parity |
| **Telegram Gate** | Bot link + live verify | Bot link + live verify | Bot link + live verify | Bot link + live verify |
| **Profiles & Custom Avatars** | Create, Delete, Sync | Create, Edit, Delete + Gallery Photo Upload (`avatarUrl`) | Create, Edit, Delete + Avatar URL + Smart Default Focus | Create, Edit, Delete + File Picker / URL |
| **Advanced Search (20 Genres)** | Type, 20 Categories, Sort, Year, Debounce, Gen Guard, Pagination | Full 20 Categories, Type, Sort, Year, Debounce, Gen Guard, Pagination | Full 20 Categories, Type, Sort, Year, Debounce, Gen Guard, Pagination | Full 20 Categories, Type, Sort, Year, Debounce, Gen Guard, Pagination |
| **Continue Watching & Resume** | `Continue 1:32:08` + Progress Bars + `startSeconds` | `Continue 1:32:08` + Progress Bars + `t`/`start`/`progress` | `Continue 1:32:08` + Progress Bars + `t`/`start`/`progress` | `Continue 1:32:08` + Progress Bars + `t`/`start`/`progress` |
| **Real-Time Cross-Device Sync** | `sync_progress` + Realtime WebSocket | `sync_progress` + `RealtimeSyncClient` WebSocket + Offline Queue | `sync_progress` + `RealtimeSyncClient` WebSocket + Offline Queue | `sync_progress` + `ClientWebSocket` Realtime Sync |
| **TV Web Player Hover** | N/A | Touch Controls + `S` Logo | True Hover-Equivalent D-pad (No Visible Cursor, Play/Pause Initial Focus, No Back-Trap) | Mouse/Keyboard + `S` Logo |
| **Smart Default Focus** | Native | Search Input + Detail Play/Continue | Profiles Active Card, Search Input, Detail Play/Continue | Search Input + Detail Play/Continue |
