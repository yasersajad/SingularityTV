# SingularityTV 1.1.6 — Verification & Build Report

## Static Verification Completed in Sandbox
- **XML / XAML Well-Formedness:** Passed (`AndroidManifest.xml` for Mobile & TV, `MainWindow.xaml`, `App.xaml`).
- **WebPlayer Asset Sync & Cursor Removal:** Passed (`Shared/WebPlayer/vidly-player.js` & `.css` match Android & Windows copies via SHA-256; zero references to `#__sgTvCursor`).
- **Brace & Structural Checks:** Passed across all modified Kotlin, C#, and TypeScript files (`telegram-gate/index.ts`, `SingularityModels.kt`, `StreamingProviderBuilder.kt`, `TMDBApiClient.kt`, `SupabaseClient.kt`, `RealtimeSyncClient.kt`, `SessionManager.kt`, `MainActivity.kt`, `TvMainActivity.kt`, `SingularityServices.cs`, `MainWindow.xaml.cs`).

## Target CI / Device Verification Required
- **Linux Sandbox Limitations:** `xcodebuild`, `gradle`, `dotnet`, `iscc`, and `adb` are not installed in this Linux container, so native compilation and runtime/WebSocket tests must be run via GitHub Actions (`.github/workflows/build-all.yml`) and physical devices.
- **Supabase Edge Function Deployment:** Deploy updated `supabase/functions/telegram-gate/index.ts` so `avatarUrl` persistence on `sync_profiles` is active in production.
