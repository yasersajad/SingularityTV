#!/usr/bin/env bash
set -euo pipefail

# Verify that every release APK is a real, installable launcher package.
# Usage: verify-android-launchers.sh <expected-application-id> <apk> [apk...]
if [[ $# -lt 2 ]]; then
  echo "Usage: $0 <expected-application-id> <apk> [apk...]" >&2
  exit 2
fi
expected_id="$1"
shift

build_tools_dir="${ANDROID_HOME:-}/build-tools"
if [[ -z "${ANDROID_HOME:-}" || ! -d "$build_tools_dir" ]]; then
  echo "ANDROID_HOME/build-tools is unavailable; cannot inspect APK manifests." >&2
  exit 3
fi

latest_build_tools="$(find "$build_tools_dir" -mindepth 1 -maxdepth 1 -type d -printf '%f\n' | sort -V | tail -n 1)"
aapt="$build_tools_dir/$latest_build_tools/aapt"
if [[ ! -x "$aapt" ]]; then
  echo "aapt not found at $aapt" >&2
  exit 3
fi

for apk in "$@"; do
  [[ -s "$apk" ]] || { echo "Missing or empty APK: $apk" >&2; exit 1; }
  badging="$($aapt dump badging "$apk")"
  package_id="$(sed -n "s/^package: name='\([^']*\)'.*/\1/p" <<<"$badging" | head -n 1)"
  launch_activity="$(sed -n "s/^launchable-activity: name='\([^']*\)'.*/\1/p" <<<"$badging" | head -n 1)"

  if [[ "$package_id" != "$expected_id" ]]; then
    echo "Wrong application ID in $apk: expected '$expected_id', got '${package_id:-<missing>}'" >&2
    exit 1
  fi
  if [[ -z "$launch_activity" ]]; then
    echo "No MAIN/LAUNCHER activity was packaged in $apk. The app may install but not appear in the launcher." >&2
    echo "$badging" >&2
    exit 1
  fi

  echo "Verified launcher APK: $apk"
  echo "  applicationId: $package_id"
  echo "  launchActivity: $launch_activity"
done
