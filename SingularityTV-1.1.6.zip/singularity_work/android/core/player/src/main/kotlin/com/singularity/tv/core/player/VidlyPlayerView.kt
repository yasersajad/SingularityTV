package com.singularity.tv.core.player

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.view.KeyEvent
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.PlayDisabled
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import coil.compose.AsyncImage
import com.singularity.tv.core.data.AdEventType
import com.singularity.tv.core.data.AdTrackerService
import com.singularity.tv.core.model.WatchItem
import com.singularity.tv.core.model.WatchType
import com.singularity.tv.core.model.WebPlayerPrefs
import java.io.ByteArrayInputStream

private val BLOCKED_AD_DOMAINS = setOf(
    "doubleclick.net", "googlesyndication.com", "googleadservices.com",
    "googletagmanager.com", "google-analytics.com", "popads.net", "popcash.net",
    "propellerads.com", "adsterra.com", "adskeeper.com", "mgid.com", "taboola.com",
    "outbrain.com", "exoclick.com", "juicyads.com", "trafficjunky.com", "histats.com",
    "mc.yandex.ru", "4rabet", "1xbet", "betway", "onclickalgo", "adsco.re",
    "a-ads.com", "realsrv.com", "tsyndicate.com", "acscdn.com", "dtscout.com",
    "richpush.co", "pushub.net", "onclickperformance.com", "adnxs.com",
    "rubiconproject.com", "pubmatic.com", "criteo.com"
)

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun SingularityPlayerHost(
    item: WatchItem,
    savedPrefs: WebPlayerPrefs,
    accentHex: String = "E50914",
    isTvMode: Boolean = false,
    onProgress: (Double, Double) -> Unit,
    onPrefChanged: (String, String) -> Unit,
    onBack: () -> Unit
) {
    var isLoading by remember { mutableStateOf(true) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var reloadKey by remember { mutableIntStateOf(0) }
    var webViewRef by remember { mutableStateOf<WebView?>(null) }

    Box(modifier = Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color.Black)) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                WebView(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                    setBackgroundColor(Color.BLACK)
                    isFocusable = true
                    isFocusableInTouchMode = true
                    requestFocus()
                    settings.apply {
                        javaScriptEnabled = true
                        domStorageEnabled = true
                        mediaPlaybackRequiresUserGesture = false
                        mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
                        userAgentString = if (isTvMode) {
                            "Mozilla/5.0 (Linux; Android 14; Android TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
                        } else {
                            "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
                        }
                    }
                    setOnKeyListener { view, keyCode, event ->
                        if (!isTvMode) return@setOnKeyListener false
                        val mapped = when (keyCode) {
                            KeyEvent.KEYCODE_DPAD_UP -> "UP"
                            KeyEvent.KEYCODE_DPAD_DOWN -> "DOWN"
                            KeyEvent.KEYCODE_DPAD_LEFT -> "LEFT"
                            KeyEvent.KEYCODE_DPAD_RIGHT -> "RIGHT"
                            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> "OK"
                            KeyEvent.KEYCODE_BACK -> "BACK"
                            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PAUSE -> "PLAY_PAUSE"
                            KeyEvent.KEYCODE_MENU -> "MENU"
                            else -> null
                        } ?: return@setOnKeyListener false
                        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                            (view as? WebView)?.evaluateJavascript("window.__sgHandleRemoteKey && window.__sgHandleRemoteKey('$mapped');", null)
                        }
                        true
                    }
                    addJavascriptInterface(
                        object {
                            @JavascriptInterface
                            fun onProgressUpdate(ct: Double, dur: Double) {
                                onProgress(ct, dur)
                            }

                            @JavascriptInterface
                            fun onPreference(key: String, value: String) {
                                onPrefChanged(key, value)
                            }

                            @JavascriptInterface
                            fun onFatalError(msg: String) {
                                errorMessage = msg
                                isLoading = false
                            }

                            @JavascriptInterface
                            fun onRequestBack() {
                                post { onBack() }
                            }
                        },
                        "SingularityBridge"
                    )
                    webViewClient = object : WebViewClient() {
                        override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                            val host = request?.url?.host?.lowercase().orEmpty()
                            if (BLOCKED_AD_DOMAINS.any { host.contains(it) }) {
                                AdTrackerService.recordBlocked(host, AdEventType.AD_BLOCKED, if (isTvMode) "AndroidTV" else "AndroidMobile", item.title)
                                return WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
                            }
                            return super.shouldInterceptRequest(view, request)
                        }

                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                            val host = request?.url?.host?.lowercase().orEmpty()
                            if (request?.isForMainFrame == true && !host.contains("vidly")) {
                                AdTrackerService.recordBlocked(host, AdEventType.REDIRECT_BLOCKED, if (isTvMode) "AndroidTV" else "AndroidMobile", item.title)
                                return true
                            }
                            return BLOCKED_AD_DOMAINS.any { host.contains(it) }
                        }

                        override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                            super.onPageStarted(view, url, favicon)
                            view?.evaluateJavascript(loadCanonicalScript(ctx, item, savedPrefs, accentHex, isTvMode), null)
                        }

                        override fun onPageFinished(view: WebView?, url: String?) {
                            isLoading = false
                            view?.evaluateJavascript(loadCanonicalScript(ctx, item, savedPrefs, accentHex, isTvMode), null)
                            if (isTvMode) {
                                view?.post { view.requestFocus() }
                            }
                        }

                        override fun onReceivedHttpError(view: WebView?, request: WebResourceRequest?, errorResponse: WebResourceResponse?) {
                            if (request?.isForMainFrame == true && (errorResponse?.statusCode ?: 0) >= 400) {
                                isLoading = false
                                errorMessage = "The streaming server returned an error (${errorResponse?.statusCode}). Please try again."
                            }
                        }

                        override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                            if (request?.isForMainFrame == true) {
                                isLoading = false
                                errorMessage = "Unable to reach the streaming server. Check your connection or try again."
                            }
                        }
                    }
                    webViewRef = this
                    loadUrl(item.generatedURL)
                }
            },
            update = { webView ->
                webViewRef = webView
                if (webView.tag != reloadKey) {
                    webView.tag = reloadKey
                    if (reloadKey > 0) {
                        errorMessage = null
                        isLoading = true
                        webView.loadUrl(item.generatedURL)
                    }
                }
            }
        )

        if (isLoading && errorMessage == null) {
            CircularProgressIndicator(
                color = androidx.compose.ui.graphics.Color.White,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        errorMessage?.let { msg ->
            NativeErrorOverlay(
                title = item.title,
                posterUrl = item.posterUrl,
                message = msg,
                onRetry = {
                    errorMessage = null
                    isLoading = true
                    reloadKey++
                },
                onBack = onBack
            )
        }
    }
}

@Composable
private fun NativeErrorOverlay(
    title: String,
    posterUrl: String?,
    message: String,
    onRetry: () -> Unit,
    onBack: () -> Unit
) {
    Box(modifier = Modifier.fillMaxSize().background(androidx.compose.ui.graphics.Color.Black)) {
        if (!posterUrl.isNullOrEmpty()) {
            AsyncImage(
                model = posterUrl,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize().blur(36.dp),
                alpha = 0.28f
            )
        }
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(
                            androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.75f),
                            androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.94f)
                        )
                    )
                )
        )
        IconButton(
            onClick = onBack,
            modifier = Modifier
                .padding(18.dp)
                .size(40.dp)
                .background(androidx.compose.ui.graphics.Color.White.copy(alpha = 0.12f), CircleShape)
                .align(Alignment.TopStart)
        ) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = androidx.compose.ui.graphics.Color.White)
        }

        Column(
            modifier = Modifier.align(Alignment.Center).padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(72.dp)
                    .background(androidx.compose.ui.graphics.Color.White.copy(alpha = 0.08f), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.PlayDisabled, contentDescription = null, tint = androidx.compose.ui.graphics.Color.White, modifier = Modifier.size(30.dp))
            }
            Text(title, color = androidx.compose.ui.graphics.Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Text(message, color = androidx.compose.ui.graphics.Color.White.copy(alpha = 0.7f), fontSize = 14.sp, textAlign = TextAlign.Center)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(
                    onClick = onRetry,
                    colors = ButtonDefaults.buttonColors(containerColor = androidx.compose.ui.graphics.Color.White, contentColor = androidx.compose.ui.graphics.Color.Black),
                    shape = RoundedCornerShape(50)
                ) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                    Text(" Try Again", fontWeight = FontWeight.SemiBold)
                }
                OutlinedButton(
                    onClick = onBack,
                    shape = RoundedCornerShape(50)
                ) {
                    Text("Go Back", color = androidx.compose.ui.graphics.Color.White)
                }
            }
        }
    }
}

private fun jsEsc(s: String): String = s.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ").replace("\r", " ")

private fun loadCanonicalScript(
    context: Context,
    item: WatchItem,
    prefs: WebPlayerPrefs,
    accentHex: String,
    isTvMode: Boolean
): String {
    val css = runCatching {
        context.assets.open("webplayer/vidly-player.css").bufferedReader().use { it.readText() }
    }.getOrDefault("").replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n")

    val js = runCatching {
        context.assets.open("webplayer/vidly-player.js").bufferedReader().use { it.readText() }
    }.getOrDefault("")

    val subtitle = if (item.type == WatchType.TV) {
        val s = item.season ?: 1
        val e = item.episode ?: 1
        if (!item.episodeName.isNullOrBlank()) "S$s:E$e · ${item.episodeName}" else "S$s:E$e"
    } else ""
    val cleanAccent = "#" + accentHex.removePrefix("#").ifEmpty { "E50914" }

    return """
    (function () {
        document.documentElement.style.setProperty('--sg-accent', '$cleanAccent');
        window.__sgIsTV = $isTvMode;
        window.__singularityMeta = {
            title: '${jsEsc(item.title)}',
            isMovie: ${item.type == WatchType.MOVIE},
            subtitle: '${jsEsc(subtitle)}',
            poster: '${jsEsc(item.posterUrl.orEmpty())}'
        };
        if (!document.getElementById('singularity-vidly-cleanup-css')) {
            var st = document.createElement('style');
            st.id = 'singularity-vidly-cleanup-css';
            st.textContent = '$css';
            (document.head || document.documentElement).appendChild(st);
        }
        window.__sgSavedPrefs = {
            preferredQuality: '${jsEsc(prefs.preferredQuality)}',
            subtitleLanguage: '${jsEsc(prefs.subtitleLanguage)}',
            playbackSpeed: '${jsEsc(prefs.playbackSpeed)}'
        };
    })();
    $js
    """.trimIndent()
}
