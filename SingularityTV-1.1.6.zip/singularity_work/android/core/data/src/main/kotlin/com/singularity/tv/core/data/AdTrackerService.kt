package com.singularity.tv.core.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

enum class AdEventType {
    AD_REQUEST,
    AD_RESPONSE,
    AD_LOADED,
    AD_IMPRESSION,
    AD_STARTED,
    AD_PROGRESS,
    AD_COMPLETED,
    AD_SKIPPED,
    AD_CLICKED,
    AD_FAILED,
    AD_DISMISSED,
    AD_BLOCKED,
    REDIRECT_BLOCKED
}

data class AdTrackerEvent(
    val eventType: AdEventType,
    val timestampMs: Long = System.currentTimeMillis(),
    val provider: String,
    val placementId: String = "player_webview",
    val creativeId: String? = null,
    val sessionId: String,
    val requestId: String = UUID.randomUUID().toString(),
    val contentContext: String? = null,
    val failureReason: String? = null,
    val platform: String
)

object AdTrackerService {
    private const val MAX_EVENTS = 200
    private val sessionId = UUID.randomUUID().toString()
    private val _events = MutableStateFlow<List<AdTrackerEvent>>(emptyList())
    val events: StateFlow<List<AdTrackerEvent>> = _events.asStateFlow()

    @Volatile
    var trackingEnabled: Boolean = true

    fun record(event: AdTrackerEvent) {
        if (!trackingEnabled) return
        val current = _events.value
        val last = current.firstOrNull()
        if (last != null &&
            last.eventType == event.eventType &&
            last.provider == event.provider &&
            (event.timestampMs - last.timestampMs) < 250L
        ) {
            return
        }
        _events.value = (listOf(event) + current).take(MAX_EVENTS)
    }

    fun recordBlocked(domain: String, type: AdEventType, platform: String, contentContext: String? = null) {
        record(
            AdTrackerEvent(
                eventType = type,
                provider = domain.take(64),
                placementId = "webview_guard",
                sessionId = sessionId,
                contentContext = contentContext?.take(64),
                platform = platform
            )
        )
    }

    fun diagnosticsSummary(): String {
        val list = _events.value
        val adsBlocked = list.count { it.eventType == AdEventType.AD_BLOCKED }
        val redirectsBlocked = list.count { it.eventType == AdEventType.REDIRECT_BLOCKED }
        return "Consent=${if (trackingEnabled) "On" else "Off"} · Ads Blocked=$adsBlocked · Redirects Blocked=$redirectsBlocked · Total=${list.size}"
    }

    fun clear() {
        _events.value = emptyList()
    }
}
