package com.singularity.tv.core.network

import com.singularity.tv.core.model.EpisodeSummary
import com.singularity.tv.core.model.MediaItem
import com.singularity.tv.core.model.ReleaseStatus
import com.singularity.tv.core.model.SearchCategory
import com.singularity.tv.core.model.SearchMediaFilter
import com.singularity.tv.core.model.SearchSortOption
import com.singularity.tv.core.model.SingularityDateHelper
import com.singularity.tv.core.model.TitleDetailPayload
import com.singularity.tv.core.model.WatchType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

@Serializable
private data class TMDBPagedResponse(
    val results: List<MediaItem> = emptyList()
)

@Serializable
private data class TMDBSeasonResponse(
    val episodes: List<EpisodeSummary> = emptyList()
)

object TMDBApiClient {
    @Volatile var customTokenOverride: String = ""
    private val json = Json { ignoreUnknownKeys = true; coerceInputValues = true }
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private fun activeToken(): String =
        customTokenOverride.trim().ifEmpty { SingularityConfig.TMDB_READ_TOKEN }

    private suspend fun get(path: String): String? = withContext(Dispatchers.IO) {
        val req = Request.Builder()
            .url("https://api.themoviedb.org/3/$path")
            .header("Authorization", "Bearer ${activeToken()}")
            .header("Accept", "application/json")
            .build()
        runCatching {
            http.newCall(req).execute().use { res ->
                if (res.isSuccessful) res.body?.string() else null
            }
        }.getOrNull()
    }

    private fun decodePaged(body: String?, fallbackType: String?): List<MediaItem> {
        if (body == null) return emptyList()
        val list = runCatching { json.decodeFromString<TMDBPagedResponse>(body).results }.getOrDefault(emptyList())
        return if (fallbackType != null) list.map { it.copy(mediaType = fallbackType) } else list
    }

    suspend fun trendingAll(): List<MediaItem> =
        decodePaged(get("trending/all/week?language=en-US"), null)
            .filter { (it.mediaType == "movie" || it.mediaType == "tv") && it.isBrowsable }

    suspend fun trendingToday(): List<MediaItem> =
        decodePaged(get("trending/all/day?language=en-US"), null)
            .filter { (it.mediaType == "movie" || it.mediaType == "tv") && it.isBrowsable }

    suspend fun trendingTodayMovies(): List<MediaItem> =
        decodePaged(get("trending/movie/day?language=en-US"), "movie")
            .filter { it.isBrowsable }

    suspend fun trendingTodaySeries(): List<MediaItem> =
        decodePaged(get("trending/tv/day?language=en-US"), "tv")
            .filter { it.isBrowsable }

    suspend fun popularMovies(): List<MediaItem> {
        val p1 = decodePaged(get("movie/popular?language=en-US&page=1"), "movie")
        val p2 = decodePaged(get("movie/popular?language=en-US&page=2"), "movie")
        return (p1 + p2).distinctBy { it.id }.filter { it.isBrowsable }
    }

    suspend fun popularSeries(): List<MediaItem> {
        val p1 = decodePaged(get("tv/popular?language=en-US&page=1"), "tv")
        val p2 = decodePaged(get("tv/popular?language=en-US&page=2"), "tv")
        return (p1 + p2).distinctBy { it.id }.filter { it.isBrowsable }
    }

    suspend fun nowPlayingMovies(): List<MediaItem> {
        val p1 = decodePaged(get("movie/now_playing?language=en-US&page=1"), "movie")
        val p2 = decodePaged(get("movie/now_playing?language=en-US&page=2"), "movie")
        return (p1 + p2).distinctBy { it.id }.filter { it.isBrowsable }
    }

    suspend fun onTheAirSeries(): List<MediaItem> =
        decodePaged(get("tv/on_the_air?language=en-US&page=1"), "tv")
            .filter { it.isBrowsable }

    suspend fun topRatedMovies(): List<MediaItem> =
        decodePaged(get("movie/top_rated?language=en-US"), "movie")
            .filter { it.isBrowsable }

    suspend fun topRatedSeries(): List<MediaItem> =
        decodePaged(get("tv/top_rated?language=en-US"), "tv")
            .filter { it.isBrowsable }

    suspend fun upcomingComingSoon(): List<MediaItem> {
        val tomorrow = SingularityDateHelper.tmdbDay(1)
        val horizon = SingularityDateHelper.tmdbDay(120)
        val m1 = decodePaged(get("movie/upcoming?region=US&language=en-US&page=1"), "movie")
        val m2 = decodePaged(get("movie/upcoming?region=US&language=en-US&page=2"), "movie")
        val t1 = decodePaged(get("discover/tv?first_air_date.gte=$tomorrow&first_air_date.lte=$horizon&sort_by=popularity.desc&without_genres=10763,10767,10766,10764&language=en-US&page=1"), "tv")
        val t2 = decodePaged(get("discover/tv?first_air_date.gte=$tomorrow&first_air_date.lte=$horizon&sort_by=popularity.desc&without_genres=10763,10767,10766,10764&language=en-US&page=2"), "tv")
        return (m1 + m2 + t1 + t2)
            .distinctBy { "${it.mediaType}-${it.id}" }
            .filter {
                !it.posterPath.isNullOrBlank() &&
                    !it.backdropPath.isNullOrBlank() &&
                    it.overview.isNotBlank() &&
                    it.releaseStatus == ReleaseStatus.UPCOMING
            }
            .sortedBy { it.releaseDateParsed?.time ?: Long.MAX_VALUE }
            .take(24)
    }

    suspend fun discoverByGenre(type: WatchType, genreId: Int): List<MediaItem> {
        val kind = type.rawValue
        val today = SingularityDateHelper.tmdbDay(0)
        val dateFilter = if (type == WatchType.MOVIE) "primary_release_date.lte=$today" else "first_air_date.lte=$today"
        val body = get("discover/$kind?with_genres=$genreId&sort_by=popularity.desc&$dateFilter&language=en-US") ?: return emptyList()
        return decodePaged(body, kind).filter { it.isBrowsable }
    }

    suspend fun discoverAdvanced(
        typeFilter: SearchMediaFilter,
        category: SearchCategory?,
        sortOption: SearchSortOption,
        year: Int?,
        page: Int = 1
    ): List<MediaItem> = coroutineScope {
        val today = SingularityDateHelper.tmdbDay(0)
        val safePage = page.coerceAtLeast(1)

        suspend fun fetchKind(kind: String, genres: String?): List<MediaItem> {
            val sb = StringBuilder("discover/$kind?language=en-US&include_adult=false&page=$safePage&without_genres=10763,10767")
            val sortParam = if (kind == "movie") sortOption.movieSort else sortOption.tvSort
            sb.append("&sort_by=$sortParam")
            if (sortOption == SearchSortOption.RATING) {
                sb.append("&vote_count.gte=25")
            }
            if (!genres.isNullOrBlank()) {
                sb.append("&with_genres=${URLEncoder.encode(genres, "UTF-8")}")
            }
            if (year != null) {
                if (kind == "movie") sb.append("&primary_release_year=$year") else sb.append("&first_air_date_year=$year")
            }
            if (kind == "movie") {
                sb.append("&primary_release_date.lte=$today")
            } else {
                sb.append("&first_air_date.lte=$today")
            }
            return decodePaged(get(sb.toString()), kind).filter { it.isBrowsable }
        }

        val wantMovie = typeFilter != SearchMediaFilter.TV && (category == null || category.movieGenres != null)
        val wantTv = typeFilter != SearchMediaFilter.MOVIE && (category == null || category.tvGenres != null)

        val movieDeferred = if (wantMovie) async { fetchKind("movie", category?.movieGenres) } else null
        val tvDeferred = if (wantTv) async { fetchKind("tv", category?.tvGenres) } else null

        val movies = movieDeferred?.await().orEmpty()
        val tv = tvDeferred?.await().orEmpty()

        val merged = mutableListOf<MediaItem>()
        val maxLen = maxOf(movies.size, tv.size)
        for (i in 0 until maxLen) {
            if (i < movies.size) merged.add(movies[i])
            if (i < tv.size) merged.add(tv[i])
        }
        merged.distinctBy { "${it.mediaType}_${it.id}" }
    }

    suspend fun recommendations(type: WatchType, id: Int): List<MediaItem> {
        val kind = type.rawValue
        val body = get("$kind/$id/recommendations?language=en-US") ?: return emptyList()
        return decodePaged(body, kind).filter { it.isBrowsable }
    }

    suspend fun searchMulti(query: String, page: Int = 1): List<MediaItem> {
        val q = withContext(Dispatchers.IO) { URLEncoder.encode(query.trim(), "UTF-8") }
        if (q.isBlank()) return emptyList()
        val safePage = page.coerceAtLeast(1)
        val body = get("search/multi?query=$q&include_adult=false&language=en-US&page=$safePage") ?: return emptyList()
        return decodePaged(body, null)
            .filter { (it.mediaType == "movie" || it.mediaType == "tv") && !it.posterPath.isNullOrBlank() }
    }

    suspend fun titleDetail(type: WatchType, id: Int): TitleDetailPayload? {
        val kind = type.rawValue
        val append = if (type == WatchType.MOVIE) {
            "credits,videos,images,release_dates,recommendations,similar"
        } else {
            "credits,videos,images,content_ratings,recommendations,similar"
        }
        val body = get("$kind/$id?append_to_response=$append&include_image_language=en,null&include_video_language=en,null&language=en-US") ?: return null
        return runCatching { json.decodeFromString<TitleDetailPayload>(body) }.getOrNull()
    }

    suspend fun seasonEpisodes(tvId: Int, seasonNumber: Int): List<EpisodeSummary> {
        val body = get("tv/$tvId/season/$seasonNumber?language=en-US") ?: return emptyList()
        return runCatching { json.decodeFromString<TMDBSeasonResponse>(body).episodes }.getOrDefault(emptyList())
    }
}
