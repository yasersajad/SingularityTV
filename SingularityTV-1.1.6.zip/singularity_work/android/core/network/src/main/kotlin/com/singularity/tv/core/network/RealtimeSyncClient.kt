package com.singularity.tv.core.network

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

class RealtimeSyncClient(
    private val onRemoteSyncChanged: () -> Unit
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val http = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .pingInterval(25, TimeUnit.SECONDS)
        .build()

    private val refCounter = AtomicInteger(1)
    private var webSocket: WebSocket? = null
    private var heartbeatJob: Job? = null
    private var reconnectJob: Job? = null
    private var activeUserId: String? = null
    private var activeAccessToken: String? = null
    private var reconnectAttempt = 0
    @Volatile private var stopped = true

    fun start(userId: String, accessToken: String) {
        if (userId.isBlank() || accessToken.isBlank()) return
        if (!stopped && activeUserId == userId && activeAccessToken == accessToken && webSocket != null) {
            return
        }
        stop()
        stopped = false
        activeUserId = userId
        activeAccessToken = accessToken
        reconnectAttempt = 0
        connect()
    }

    fun updateToken(accessToken: String) {
        if (stopped || accessToken.isBlank()) return
        activeAccessToken = accessToken
        val ws = webSocket ?: return
        val tokenMsg = JSONObject()
            .put("topic", "realtime:public:user_sync")
            .put("event", "access_token")
            .put("payload", JSONObject().put("access_token", accessToken))
            .put("ref", refCounter.getAndIncrement().toString())
        ws.send(tokenMsg.toString())
    }

    fun stop() {
        stopped = true
        heartbeatJob?.cancel()
        heartbeatJob = null
        reconnectJob?.cancel()
        reconnectJob = null
        webSocket?.close(1000, "logout")
        webSocket = null
        activeUserId = null
        activeAccessToken = null
    }

    private fun connect() {
        val uid = activeUserId ?: return
        val token = activeAccessToken ?: return
        if (stopped) return

        val baseWs = SingularityConfig.SUPABASE_URL
            .replace("https://", "wss://")
            .replace("http://", "ws://")
        val apikey = URLEncoder.encode(SingularityConfig.SUPABASE_PUBLISHABLE_KEY, "UTF-8")
        val wsUrl = "$baseWs/realtime/v1/websocket?apikey=$apikey&vsn=1.0.0"

        val req = Request.Builder().url(wsUrl).build()
        webSocket = http.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                reconnectAttempt = 0
                val pgFilter = JSONObject()
                    .put("event", "*")
                    .put("schema", "public")
                    .put("table", "user_sync")
                    .put("filter", "user_id=eq.$uid")
                val joinConfig = JSONObject()
                    .put("broadcast", JSONObject().put("self", false))
                    .put("presence", JSONObject().put("key", ""))
                    .put("postgres_changes", JSONArray().put(pgFilter))
                val joinPayload = JSONObject()
                    .put("config", joinConfig)
                    .put("access_token", token)
                val joinMsg = JSONObject()
                    .put("topic", "realtime:public:user_sync")
                    .put("event", "phx_join")
                    .put("payload", joinPayload)
                    .put("ref", refCounter.getAndIncrement().toString())
                webSocket.send(joinMsg.toString())
                startHeartbeat(webSocket)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                val obj = runCatching { JSONObject(text) }.getOrNull() ?: return
                val event = obj.optString("event", "")
                if (event == "postgres_changes") {
                    onRemoteSyncChanged()
                }
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                heartbeatJob?.cancel()
                scheduleReconnect()
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                heartbeatJob?.cancel()
                scheduleReconnect()
            }
        })
    }

    private fun startHeartbeat(ws: WebSocket) {
        heartbeatJob?.cancel()
        heartbeatJob = scope.launch {
            while (isActive && !stopped) {
                delay(25_000L)
                val hb = JSONObject()
                    .put("topic", "phoenix")
                    .put("event", "heartbeat")
                    .put("payload", JSONObject())
                    .put("ref", refCounter.getAndIncrement().toString())
                ws.send(hb.toString())
            }
        }
    }

    private fun scheduleReconnect() {
        if (stopped) return
        reconnectJob?.cancel()
        val delayMs = (2000L * (1 shl reconnectAttempt.coerceAtMost(4))).coerceAtMost(30_000L)
        reconnectAttempt++
        reconnectJob = scope.launch {
            delay(delayMs)
            if (!stopped) connect()
        }
    }
}
