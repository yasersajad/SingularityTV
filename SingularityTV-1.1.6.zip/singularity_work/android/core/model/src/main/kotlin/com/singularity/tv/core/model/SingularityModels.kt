package com.singularity.tv.core.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Serializable
enum class WatchType(val rawValue: String) {
    @SerialName("movie") MOVIE("movie"),
    @SerialName("tv") TV("tv")
}

enum class ReleaseStatus {
    UPCOMING,
    RELEASED,
    IN_PRODUCTION,
    UNKNOWN
}

enum class ReminderResult {
    ADDED,
    REMOVED,
    NOTIFICATIONS_DENIED
}

enum class SearchMediaFilter(val label: String) {
    ALL("All"),
    MOVIE("Movies"),
    TV("Series")
}

enum class SearchSortOption(val label: String, val movieSort: String, val tvSort: String) {
    POPULARITY("Popularity", "popularity.desc", "popularity.desc"),
    RELEASE_DATE("Release Date", "primary_release_date.desc", "first_air_date.desc"),
    RATING("Rating", "vote_average.desc", "vote_average.desc")
}

data class SearchCategory(
    val id: String,
    val title: String,
    val movieGenres: String?,
    val tvGenres: String?
)

object SingularityCategories {
    val catalog = listOf(
        SearchCategory("action", "Action", "28", "10759"),
        SearchCategory("adventure", "Adventure", "12", "10759"),
        SearchCategory("animation", "Animation", "16", "16"),
        SearchCategory("comedy", "Comedy", "35", "35"),
        SearchCategory("crime", "Crime", "80", "80"),
        SearchCategory("documentaries", "Documentaries", "99", "99"),
        SearchCategory("drama", "Drama", "18", "18"),
        SearchCategory("family", "Family", "10751", "10751"),
        SearchCategory("fantasy", "Fantasy", "14", "10765"),
        SearchCategory("history", "History", "36", null),
        SearchCategory("horror", "Horror", "27", null),
        SearchCategory("kids", "Kids", "10751|16", "10762"),
        SearchCategory("music", "Music", "10402", null),
        SearchCategory("mystery", "Mystery", "9648", "9648"),
        SearchCategory("reality", "Reality", null, "10764"),
        SearchCategory("romance", "Romance", "10749", null),
        SearchCategory("scifi", "Sci-Fi", "878", "10765"),
        SearchCategory("thrillers", "Thrillers", "53", "80|9648"),
        SearchCategory("war", "War", "10752", "10768"),
        SearchCategory("westerns", "Westerns", "37", "37")
    )
}

object SingularityPlaybackFormatter {
    fun formatPlaybackPosition(seconds: Double): String {
        val total = seconds.toLong().coerceAtLeast(0L)
        val hours = total / 3600L
        val minutes = (total % 3600L) / 60L
        val secs = total % 60L
        return if (hours > 0L) {
            String.format(Locale.US, "%d:%02d:%02d", hours, minutes, secs)
        } else {
            String.format(Locale.US, "%d:%02d", minutes, secs)
        }
    }

    fun formatRemainingTime(progressSeconds: Double?, durationSeconds: Double?): String? {
        if (progressSeconds == null || durationSeconds == null || durationSeconds <= 0.0) return null
        val remaining = (durationSeconds - progressSeconds).toLong()
        if (remaining <= 0L) return null
        val hours = remaining / 3600L
        val mins = (remaining % 3600L) / 60L
        return when {
            hours > 0L && mins > 0L -> "${hours}h ${mins}m left"
            hours > 0L -> "${hours}h left"
            mins > 0L -> "${mins}m left"
            else -> "${remaining}s left"
        }
    }
}

object SingularityDateHelper {
    fun parseTmdbDate(value: String?): Date? {
        if (value.isNullOrBlank() || value.length < 10) return null
        val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false }
        return runCatching { fmt.parse(value.take(10)) }.getOrNull()
    }

    fun startOfToday(): Date {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.time
    }

    fun startOfTomorrow(): Date {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        cal.add(Calendar.DAY_OF_YEAR, 1)
        return cal.time
    }

    fun tmdbDay(offsetDays: Int): String {
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, offsetDays)
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
    }

    fun comingLabel(releaseDate: Date, isMovie: Boolean): String {
        val today = startOfToday()
        val diffDays = ((releaseDate.time - today.time) / (24L * 60L * 60L * 1000L)).toInt()
        val verb = if (isMovie) "Coming" else "Premieres"
        if (diffDays <= 1) return "$verb Tomorrow"
        if (diffDays < 7) {
            val weekday = SimpleDateFormat("EEEE", Locale.US).format(releaseDate)
            return "$verb $weekday"
        }
        val calNow = Calendar.getInstance()
        val calRel = Calendar.getInstance().apply { time = releaseDate }
        val sameYear = calNow.get(Calendar.YEAR) == calRel.get(Calendar.YEAR)
        val pattern = if (sameYear) "MMMM d" else "MMMM d, yyyy"
        return "$verb ${SimpleDateFormat(pattern, Locale.US).format(releaseDate)}"
    }

    fun monthAbbrev(date: Date): String = SimpleDateFormat("MMM", Locale.US).format(date).uppercase(Locale.US)
    fun dayNumber(date: Date): String = SimpleDateFormat("d", Locale.US).format(date)
}

@Serializable
data class MediaItem(
    val id: Int,
    @SerialName("media_type") val mediaType: String = "movie",
    val title: String? = null,
    val name: String? = null,
    val overview: String = "",
    @SerialName("release_date") val releaseDate: String? = null,
    @SerialName("first_air_date") val firstAirDate: String? = null,
    @SerialName("poster_path") val posterPath: String? = null,
    @SerialName("backdrop_path") val backdropPath: String? = null,
    @SerialName("vote_average") val voteAverage: Double? = null,
    @SerialName("vote_count") val voteCount: Int? = null,
    @SerialName("genre_ids") val genreIds: List<Int>? = null,
    @SerialName("original_language") val originalLanguage: String? = null,
    @SerialName("origin_country") val originCountry: List<String>? = null,
    val status: String? = null
) {
    val isMovie: Boolean get() = mediaType == "movie"
    val watchType: WatchType get() = if (isMovie) WatchType.MOVIE else WatchType.TV
    val displayTitle: String get() = if (isMovie) (title ?: name ?: "Untitled Movie") else (name ?: title ?: "Untitled Series")
    val rawDateString: String? get() = if (isMovie) releaseDate else firstAirDate
    val displayYear: String? get() = rawDateString?.take(4)
    val releaseDateParsed: Date? get() = SingularityDateHelper.parseTmdbDate(rawDateString)
    val posterUrl: String? get() = posterPath?.let { "https://image.tmdb.org/t/p/w500$it" }
    val backdropUrl: String? get() = backdropPath?.let { "https://image.tmdb.org/t/p/w1280$it" }
    val matchPercent: Int? get() = voteAverage?.takeIf { it > 0 }?.let { (it * 10).toInt() }
    val genreTags: List<String> get() = genreIds?.mapNotNull { SingularityGenres.names[it] }?.distinct()?.take(3) ?: emptyList()

    val releaseStatus: ReleaseStatus
        get() {
            val date = releaseDateParsed
            val st = status?.lowercase().orEmpty()
            if (date != null) {
                return if (date.time >= SingularityDateHelper.startOfTomorrow().time) {
                    ReleaseStatus.UPCOMING
                } else {
                    ReleaseStatus.RELEASED
                }
            }
            if (st.contains("production") || st.contains("planned") || st.contains("rumored")) {
                return ReleaseStatus.IN_PRODUCTION
            }
            return ReleaseStatus.UNKNOWN
        }

    val isUpcoming: Boolean get() = releaseStatus == ReleaseStatus.UPCOMING
    val isListable: Boolean
        get() = !posterPath.isNullOrBlank() && (genreIds == null || genreIds.none { it == 10763 || it == 10767 })
    val isBrowsable: Boolean
        get() = isListable && releaseStatus != ReleaseStatus.UPCOMING

    val isArabicOrGulfContent: Boolean
        get() {
            if (originalLanguage.equals("ar", ignoreCase = true)) return true
            val arabCountries = setOf("SA", "AE", "KW", "QA", "BH", "OM", "EG", "LB", "SY", "JO", "IQ", "MA", "TN", "DZ", "YE", "SD", "LY", "PS")
            if (originCountry?.any { it.uppercase() in arabCountries } == true) return true
            val text = "${title.orEmpty()} ${name.orEmpty()}"
            return Regex("\\p{InArabic}").containsMatchIn(text)
        }
}

@Serializable
data class WatchItem(
    val id: String,
    val type: WatchType,
    val title: String,
    val tmdbId: String,
    val season: Int? = null,
    val episode: Int? = null,
    val episodeName: String? = null,
    val posterPath: String? = null,
    val generatedURL: String,
    val dateWatchedEpochMs: Long = System.currentTimeMillis()
) {
    val posterUrl: String? get() = posterPath?.let { "https://image.tmdb.org/t/p/w500$it" }
}

@Serializable
data class ContinueWatchingItem(
    val id: String,
    val type: WatchType,
    val title: String,
    val tmdbId: String,
    val season: Int? = null,
    val episode: Int? = null,
    val episodeName: String? = null,
    val posterPath: String? = null,
    val playableURL: String? = null,
    val lastWatchedEpochMs: Long = System.currentTimeMillis(),
    val progressSeconds: Double? = null,
    val durationSeconds: Double? = null
) {
    val progressFraction: Double?
        get() = if (progressSeconds != null && durationSeconds != null && durationSeconds > 0.0) {
            (progressSeconds / durationSeconds).coerceIn(0.0, 1.0)
        } else null

    val formattedPosition: String?
        get() = progressSeconds?.takeIf { it >= 5.0 }?.let { SingularityPlaybackFormatter.formatPlaybackPosition(it) }

    val posterUrl: String? get() = posterPath?.let { "https://image.tmdb.org/t/p/w500$it" }
}

@Serializable
data class MyListItem(
    val mediaType: WatchType,
    val tmdbId: Int,
    val title: String,
    val posterPath: String? = null,
    val backdropPath: String? = null,
    val overview: String? = null,
    val year: String? = null,
    val dateAddedEpochMs: Long = System.currentTimeMillis()
) {
    fun toMediaItem(): MediaItem = MediaItem(
        id = tmdbId,
        mediaType = mediaType.rawValue,
        title = if (mediaType == WatchType.MOVIE) title else null,
        name = if (mediaType == WatchType.TV) title else null,
        overview = overview ?: "",
        releaseDate = if (mediaType == WatchType.MOVIE) year else null,
        firstAirDate = if (mediaType == WatchType.TV) year else null,
        posterPath = posterPath,
        backdropPath = backdropPath
    )
}

@Serializable
data class ReminderItem(
    val title: MyListItem,
    val releaseDateEpochMs: Long = System.currentTimeMillis()
)

@Serializable
data class UserProfile(
    val id: String,
    val name: String,
    val avatarColor: String = "#E50914",
    val isKids: Boolean = false,
    val avatarUrl: String? = null,
    val createdAt: Long = System.currentTimeMillis()
)

@Serializable
data class SupabaseSession(
    val accessToken: String,
    val refreshToken: String,
    val userId: String,
    val email: String,
    val name: String,
    val expiresAtEpochSec: Long
)

@Serializable
data class WebPlayerPrefs(
    val preferredQuality: String = "Auto",
    val subtitleLanguage: String = "Off",
    val playbackSpeed: String = "1"
)

@Serializable
data class AppSettingsState(
    val accentColorHex: String = "E50914",
    val streamingProviderBaseURL: String = "vidly.pro",
    val hapticsEnabled: Boolean = true,
    val automaticUpdateChecksEnabled: Boolean = true,
    val customTmdbToken: String = ""
)

data class AccentPreset(val name: String, val hex: String)

object SingularityAccentPalette {
    val presets = listOf(
        AccentPreset("Singularity Red", "E50914"),
        AccentPreset("Electric Blue", "0071EB"),
        AccentPreset("Royal Purple", "7C3AED"),
        AccentPreset("Emerald", "059669"),
        AccentPreset("Amber Gold", "D97706"),
        AccentPreset("Neon Pink", "DB2777"),
        AccentPreset("Cyan", "0891B2"),
        AccentPreset("Lime", "65A30D")
    )
}

object SingularityGenres {
    val all = listOf(
        28 to "Action", 12 to "Adventure", 16 to "Animation", 35 to "Comedy",
        80 to "Crime", 99 to "Documentary", 18 to "Drama", 10751 to "Family",
        14 to "Fantasy", 36 to "History", 27 to "Horror", 9648 to "Mystery",
        10749 to "Romance", 878 to "Sci-Fi", 53 to "Thriller", 10752 to "War",
        37 to "Western"
    )
    val names = all.toMap() + mapOf(
        10759 to "Action & Adventure",
        10762 to "Kids",
        10402 to "Music",
        10764 to "Reality",
        10765 to "Sci-Fi & Fantasy",
        10768 to "War & Politics"
    )
}

@Serializable
data class NamedGenre(val id: Int, val name: String = "")

@Serializable
data class CastMember(
    val id: Int,
    val name: String = "",
    val character: String? = null,
    @SerialName("profile_path") val profilePath: String? = null
) {
    val profileUrl: String? get() = profilePath?.let { "https://image.tmdb.org/t/p/w185$it" }
}

@Serializable
data class CrewMember(
    val id: Int,
    val name: String = "",
    val job: String? = null
)

@Serializable
data class CreditsPayload(
    val cast: List<CastMember> = emptyList(),
    val crew: List<CrewMember> = emptyList()
)

@Serializable
data class VideoItem(
    val id: String = "",
    val key: String = "",
    val name: String = "",
    val site: String = "",
    val type: String = ""
) {
    val isYouTube: Boolean get() = site.equals("YouTube", ignoreCase = true) && key.isNotBlank()
    val thumbnailUrl: String? get() = if (isYouTube) "https://img.youtube.com/vi/$key/hqdefault.jpg" else null
    val watchUrl: String? get() = if (isYouTube) "https://www.youtube.com/watch?v=$key" else null
}

@Serializable
data class VideosPayload(val results: List<VideoItem> = emptyList())

@Serializable
data class LogoFile(
    @SerialName("file_path") val filePath: String = "",
    @SerialName("iso_639_1") val language: String? = null,
    @SerialName("vote_average") val voteAverage: Double? = null,
    @SerialName("aspect_ratio") val aspectRatio: Double? = null
)

@Serializable
data class ImagesPayload(
    val logos: List<LogoFile> = emptyList()
)

@Serializable
data class MediaListPayload(val results: List<MediaItem> = emptyList())

@Serializable
data class ReleaseDateEntry(val certification: String? = null)

@Serializable
data class ReleaseDateCountry(
    @SerialName("iso_3166_1") val country: String = "",
    @SerialName("release_dates") val releaseDates: List<ReleaseDateEntry> = emptyList()
)

@Serializable
data class ReleaseDatesPayload(val results: List<ReleaseDateCountry> = emptyList())

@Serializable
data class ContentRatingEntry(
    @SerialName("iso_3166_1") val country: String = "",
    val rating: String? = null
)

@Serializable
data class ContentRatingsPayload(val results: List<ContentRatingEntry> = emptyList())

@Serializable
data class SeasonSummary(
    val id: Int,
    @SerialName("season_number") val seasonNumber: Int,
    val name: String = "",
    @SerialName("episode_count") val episodeCount: Int = 0
)

@Serializable
data class EpisodeSummary(
    val id: Int,
    @SerialName("episode_number") val episodeNumber: Int,
    @SerialName("season_number") val seasonNumber: Int = 1,
    val name: String = "",
    val overview: String = "",
    @SerialName("still_path") val stillPath: String? = null,
    val runtime: Int? = null,
    @SerialName("air_date") val airDate: String? = null
) {
    val stillUrl: String? get() = stillPath?.let { "https://image.tmdb.org/t/p/w500$it" }
    val hasAired: Boolean
        get() {
            val d = SingularityDateHelper.parseTmdbDate(airDate) ?: return true
            return d.time < SingularityDateHelper.startOfTomorrow().time
        }
}

@Serializable
data class TitleDetailPayload(
    val id: Int,
    val title: String? = null,
    val name: String? = null,
    @SerialName("original_title") val originalTitle: String? = null,
    @SerialName("original_name") val originalName: String? = null,
    val tagline: String? = null,
    val overview: String = "",
    val status: String? = null,
    @SerialName("poster_path") val posterPath: String? = null,
    @SerialName("backdrop_path") val backdropPath: String? = null,
    @SerialName("release_date") val releaseDate: String? = null,
    @SerialName("first_air_date") val firstAirDate: String? = null,
    @SerialName("vote_average") val voteAverage: Double? = null,
    val runtime: Int? = null,
    @SerialName("episode_run_time") val episodeRunTime: List<Int> = emptyList(),
    @SerialName("number_of_seasons") val numberOfSeasons: Int? = null,
    val genres: List<NamedGenre> = emptyList(),
    @SerialName("created_by") val createdBy: List<NamedGenre> = emptyList(),
    val seasons: List<SeasonSummary> = emptyList(),
    val credits: CreditsPayload? = null,
    val videos: VideosPayload? = null,
    val images: ImagesPayload? = null,
    val recommendations: MediaListPayload? = null,
    val similar: MediaListPayload? = null,
    @SerialName("release_dates") val releaseDates: ReleaseDatesPayload? = null,
    @SerialName("content_ratings") val contentRatings: ContentRatingsPayload? = null,
    @SerialName("original_language") val originalLanguage: String? = null,
    @SerialName("origin_country") val originCountry: List<String>? = null
) {
    fun usCertification(isMovie: Boolean): String? {
        return if (isMovie) {
            releaseDates?.results?.firstOrNull { it.country == "US" }
                ?.releaseDates?.firstOrNull { !it.certification.isNullOrBlank() }?.certification
        } else {
            contentRatings?.results?.firstOrNull { it.country == "US" }?.rating?.takeIf { it.isNotBlank() }
        }
    }

    fun bestLogoUrl(): String? {
        val candidates = images?.logos.orEmpty()
            .filter { it.filePath.isNotBlank() && !it.filePath.endsWith(".svg", ignoreCase = true) }
        if (candidates.isEmpty()) return null
        val picked = candidates
            .sortedWith(
                compareByDescending<LogoFile> { it.language.equals("en", ignoreCase = true) }
                    .thenByDescending { it.language.isNullOrBlank() }
                    .thenByDescending { it.voteAverage ?: 0.0 }
            )
            .firstOrNull() ?: return null
        return "https://image.tmdb.org/t/p/w500${picked.filePath}"
    }

    fun directorOrCreators(isMovie: Boolean): String? {
        if (isMovie) {
            val dirs = credits?.crew?.filter { it.job == "Director" }?.map { it.name }?.take(3).orEmpty()
            return if (dirs.isNotEmpty()) dirs.joinToString(", ") else null
        }
        val creators = createdBy.map { it.name }.take(3)
        return if (creators.isNotEmpty()) creators.joinToString(", ") else null
    }
}
