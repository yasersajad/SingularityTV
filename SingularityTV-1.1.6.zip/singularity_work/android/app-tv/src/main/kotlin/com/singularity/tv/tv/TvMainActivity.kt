package com.singularity.tv.tv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.ThumbUpOffAlt
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsNone
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.tv.material3.Border
import androidx.tv.material3.Button
import androidx.tv.material3.ButtonDefaults
import androidx.tv.material3.ClickableSurfaceDefaults
import androidx.tv.material3.ExperimentalTvMaterial3Api
import androidx.tv.material3.Icon
import androidx.tv.material3.MaterialTheme
import androidx.tv.material3.Surface
import androidx.tv.material3.Text
import androidx.tv.material3.darkColorScheme
import coil.compose.AsyncImage
import com.singularity.tv.core.data.GateStage
import com.singularity.tv.core.data.SessionManager
import com.singularity.tv.core.model.EpisodeSummary
import com.singularity.tv.core.model.MediaItem
import com.singularity.tv.core.model.MyListItem
import com.singularity.tv.core.model.SingularityAccentPalette
import com.singularity.tv.core.model.SingularityGenres
import com.singularity.tv.core.model.SingularityDateHelper
import com.singularity.tv.core.model.TitleDetailPayload
import com.singularity.tv.core.model.WatchItem
import com.singularity.tv.core.model.SearchCategory
import com.singularity.tv.core.model.SearchMediaFilter
import com.singularity.tv.core.model.SearchSortOption
import com.singularity.tv.core.model.SingularityCategories
import com.singularity.tv.core.model.SingularityPlaybackFormatter
import com.singularity.tv.core.model.UserProfile
import com.singularity.tv.core.model.WatchType
import com.singularity.tv.core.network.EmailNotConfirmedException
import com.singularity.tv.core.network.SignUpOutcome
import com.singularity.tv.core.network.SingularityConfig
import com.singularity.tv.core.network.StreamingProviderBuilder
import com.singularity.tv.core.network.TMDBApiClient
import com.singularity.tv.core.player.SingularityPlayerHost
import kotlinx.coroutines.delay
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private fun tvAccent(hex: String): Color {
    val clean = hex.removePrefix("#").trim()
    val rgb = clean.toLongOrNull(16) ?: 0xE50914L
    return Color(0xFF000000L or rgb)
}

@OptIn(ExperimentalTvMaterial3Api::class)
class TvMainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sessionManager = SessionManager.getInstance(applicationContext)
        setContent {
            val appSettings by sessionManager.appSettings.collectAsState()
            val accent = tvAccent(appSettings.accentColorHex)
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = accent,
                    background = Color.Black,
                    surface = Color(0xFF141414),
                    onBackground = Color.White,
                    onSurface = Color.White
                )
            ) {
                SingularityTvRoot(sessionManager, accent)
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun SingularityTvRoot(sessionManager: SessionManager, accent: Color) {
    val stage by sessionManager.stage.collectAsState()
    val isHydrating by sessionManager.isHydratingProfile.collectAsState()
    val appSettings by sessionManager.appSettings.collectAsState()
    var activePlayerItem by remember { mutableStateOf<WatchItem?>(null) }
    var detailItem by remember { mutableStateOf<MediaItem?>(null) }

    if (activePlayerItem != null) {
        val item = activePlayerItem!!
        val prefs by sessionManager.webPlayerPrefs.collectAsState()
        BackHandler { activePlayerItem = null }
        SingularityPlayerHost(
            item = item,
            savedPrefs = prefs,
            accentHex = appSettings.accentColorHex,
            isTvMode = true,
            onProgress = { ct, dur ->
                sessionManager.recordProgress(
                    type = item.type,
                    tmdbId = item.tmdbId,
                    title = item.title,
                    posterPath = item.posterPath,
                    season = item.season,
                    episode = item.episode,
                    episodeName = item.episodeName,
                    positionSeconds = ct,
                    durationSeconds = dur
                )
            },
            onPrefChanged = { key, value ->
                sessionManager.updateWebPlayerPrefs { cur ->
                    when (key) {
                        "preferredQuality" -> cur.copy(preferredQuality = value)
                        "subtitleLanguage" -> cur.copy(subtitleLanguage = value)
                        "playbackSpeed" -> cur.copy(playbackSpeed = value)
                        else -> cur
                    }
                }
            },
            onBack = { activePlayerItem = null }
        )
        return
    }

    if (detailItem != null) {
        BackHandler { detailItem = null }
        TvDetailScreen(
            item = detailItem!!,
            sessionManager = sessionManager,
            accent = accent,
            onOpenRelated = { detailItem = it },
            onPlay = {
                sessionManager.recordHistory(it)
                activePlayerItem = it
            },
            onBack = { detailItem = null }
        )
        return
    }

    when (stage) {
        GateStage.CHECKING_AUTH -> Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
            CircularProgressIndicator(color = accent)
        }
        GateStage.AUTH_REQUIRED -> TvAuthScreen(sessionManager, accent)
        GateStage.TELEGRAM_REQUIRED -> TvTelegramScreen(sessionManager, accent)
        GateStage.PROFILE_SELECT -> TvProfilesScreen(sessionManager, isHydrating, accent)
        GateStage.READY -> TvMainShell(
            sessionManager = sessionManager,
            accent = accent,
            onOpenDetail = { detailItem = it },
            onPlay = {
                sessionManager.recordHistory(it)
                activePlayerItem = it
            }
        )
    }
}

private enum class TvAuthMode { SIGN_IN, SIGN_UP, VERIFY_SIGN_UP, FORGOT_PASSWORD, RESET_VERIFY }

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvAuthScreen(sessionManager: SessionManager, accent: Color) {
    val scope = rememberCoroutineScope()
    var mode by remember { mutableStateOf(TvAuthMode.SIGN_IN) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirmPassword by remember { mutableStateOf("") }
    var otp by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var info by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF22070B), Color(0xFF0A0A0F), Color(0xFF050508)))),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier
                .width(380.dp)
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xEB141414))
                .border(1.dp, Color.White.copy(alpha = 0.10f), RoundedCornerShape(20.dp))
                .padding(22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(accent.copy(alpha = 0.15f))
                    .border(1.dp, accent.copy(alpha = 0.45f), RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("S", color = accent, fontSize = 26.sp, fontWeight = FontWeight.Black)
            }
            Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(color = Color.White)) { append("Singularity") }
                    withStyle(SpanStyle(color = accent)) { append("TV") }
                },
                fontSize = 22.sp,
                fontWeight = FontWeight.ExtraBold
            )
            if (mode == TvAuthMode.SIGN_IN || mode == TvAuthMode.SIGN_UP) {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Button(
                        onClick = { mode = TvAuthMode.SIGN_IN; error = null; info = null },
                        colors = ButtonDefaults.colors(containerColor = if (mode == TvAuthMode.SIGN_IN) accent else Color(0xFF262626), contentColor = Color.White),
                        modifier = Modifier.weight(1f)
                    ) { Text("Sign In", fontWeight = FontWeight.Bold) }
                    Button(
                        onClick = { mode = TvAuthMode.SIGN_UP; error = null; info = null },
                        colors = ButtonDefaults.colors(containerColor = if (mode == TvAuthMode.SIGN_UP) accent else Color(0xFF262626), contentColor = Color.White),
                        modifier = Modifier.weight(1f)
                    ) { Text("Sign Up", fontWeight = FontWeight.Bold) }
                }
            }
            error?.let {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(accent.copy(alpha = 0.15f))
                        .border(1.dp, accent.copy(alpha = 0.42f), RoundedCornerShape(10.dp))
                        .padding(10.dp)
                ) { Text(it, color = Color(0xFFFF8C92), fontSize = 13.sp) }
            }
            info?.let {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFF45D478).copy(alpha = 0.15f))
                        .border(1.dp, Color(0xFF45D478).copy(alpha = 0.42f), RoundedCornerShape(10.dp))
                        .padding(10.dp)
                ) { Text(it, color = Color(0xFF7BE3A2), fontSize = 13.sp) }
            }

            when (mode) {
                TvAuthMode.SIGN_IN -> {
                    OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email Address") }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(6.dp), textStyle = LocalTextStyle.current.copy(color = Color.White, fontFamily = FontFamily.SansSerif), colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF1C1C1C),
                        unfocusedContainerColor = Color(0xFF1C1C1C),
                        focusedBorderColor = accent,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.18f),
                        cursorColor = accent,
                        focusedLabelColor = Color.White,
                        unfocusedLabelColor = Color(0xFF9E9E9E)
                    ))
                    OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(6.dp), textStyle = LocalTextStyle.current.copy(color = Color.White, fontFamily = FontFamily.SansSerif), colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF1C1C1C),
                        unfocusedContainerColor = Color(0xFF1C1C1C),
                        focusedBorderColor = accent,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.18f),
                        cursorColor = accent,
                        focusedLabelColor = Color.White,
                        unfocusedLabelColor = Color(0xFF9E9E9E)
                    ))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = {
                                if (busy) return@Button
                                busy = true; error = null; info = null
                                scope.launch {
                                    val res = sessionManager.signIn(email.trim(), password)
                                    busy = false
                                    res.onFailure { ex ->
                                        if (ex is EmailNotConfirmedException) {
                                            sessionManager.resendSignupOtp(email.trim())
                                            otp = ""
                                            mode = TvAuthMode.VERIFY_SIGN_UP
                                            info = "Email not verified. Fresh 6-digit code sent."
                                        } else error = ex.message
                                    }
                                }
                            },
                            colors = ButtonDefaults.colors(containerColor = accent, contentColor = Color.White),
                            modifier = Modifier.weight(1f)
                        ) { Text(if (busy) "Signing In..." else "Sign In", fontWeight = FontWeight.Bold) }
                        Button(
                            onClick = { mode = TvAuthMode.FORGOT_PASSWORD; error = null; info = null },
                            colors = ButtonDefaults.colors(containerColor = Color(0xFF262626), contentColor = Color.White)
                        ) { Text("Forgot?") }
                    }
                }
                TvAuthMode.SIGN_UP -> {
                    OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Display Name") }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(6.dp), textStyle = LocalTextStyle.current.copy(color = Color.White, fontFamily = FontFamily.SansSerif), colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF1C1C1C),
                        unfocusedContainerColor = Color(0xFF1C1C1C),
                        focusedBorderColor = accent,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.18f),
                        cursorColor = accent,
                        focusedLabelColor = Color.White,
                        unfocusedLabelColor = Color(0xFF9E9E9E)
                    ))
                    OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Email Address") }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(6.dp), textStyle = LocalTextStyle.current.copy(color = Color.White, fontFamily = FontFamily.SansSerif), colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF1C1C1C),
                        unfocusedContainerColor = Color(0xFF1C1C1C),
                        focusedBorderColor = accent,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.18f),
                        cursorColor = accent,
                        focusedLabelColor = Color.White,
                        unfocusedLabelColor = Color(0xFF9E9E9E)
                    ))
                    OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("Password (min 6)") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(6.dp), textStyle = LocalTextStyle.current.copy(color = Color.White, fontFamily = FontFamily.SansSerif), colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF1C1C1C),
                        unfocusedContainerColor = Color(0xFF1C1C1C),
                        focusedBorderColor = accent,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.18f),
                        cursorColor = accent,
                        focusedLabelColor = Color.White,
                        unfocusedLabelColor = Color(0xFF9E9E9E)
                    ))
                    OutlinedTextField(value = confirmPassword, onValueChange = { confirmPassword = it }, label = { Text("Confirm Password") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(6.dp), textStyle = LocalTextStyle.current.copy(color = Color.White, fontFamily = FontFamily.SansSerif), colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF1C1C1C),
                        unfocusedContainerColor = Color(0xFF1C1C1C),
                        focusedBorderColor = accent,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.18f),
                        cursorColor = accent,
                        focusedLabelColor = Color.White,
                        unfocusedLabelColor = Color(0xFF9E9E9E)
                    ))
                    Button(
                        onClick = {
                            if (busy) return@Button
                            if (password != confirmPassword) { error = "Passwords do not match."; return@Button }
                            busy = true; error = null
                            scope.launch {
                                val res = sessionManager.signUpDetailed(email.trim(), password, name.trim())
                                busy = false
                                res.onSuccess { out ->
                                    if (out is SignUpOutcome.NeedsVerification) {
                                        otp = ""
                                        mode = TvAuthMode.VERIFY_SIGN_UP
                                        info = "6-digit verification code sent."
                                    }
                                }.onFailure { error = it.message }
                            }
                        },
                        colors = ButtonDefaults.colors(containerColor = accent, contentColor = Color.White),
                        modifier = Modifier.fillMaxWidth()
                    ) { Text(if (busy) "Sending..." else "Send Verification Code", fontWeight = FontWeight.Bold) }
                }
                TvAuthMode.VERIFY_SIGN_UP -> {
                    OutlinedTextField(value = otp, onValueChange = { otp = it.filter(Char::isDigit).take(6) }, label = { Text("6-Digit Code") }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(6.dp), textStyle = LocalTextStyle.current.copy(color = Color.White, fontFamily = FontFamily.SansSerif), colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF1C1C1C),
                        unfocusedContainerColor = Color(0xFF1C1C1C),
                        focusedBorderColor = accent,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.18f),
                        cursorColor = accent,
                        focusedLabelColor = Color.White,
                        unfocusedLabelColor = Color(0xFF9E9E9E)
                    ))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = {
                                if (busy) return@Button
                                busy = true; error = null
                                scope.launch {
                                    val res = sessionManager.verifyEmailOtp(email.trim(), otp, "signup")
                                    busy = false
                                    res.onFailure { error = it.message }
                                }
                            },
                            colors = ButtonDefaults.colors(containerColor = accent, contentColor = Color.White),
                            modifier = Modifier.weight(1f)
                        ) { Text("Verify") }
                        Button(onClick = { scope.launch { sessionManager.resendSignupOtp(email.trim()); info = "Code resent." } }, colors = ButtonDefaults.colors(containerColor = Color(0xFF2B2B2B), contentColor = Color.White, focusedContainerColor = Color.White, focusedContentColor = Color.Black), shape = ButtonDefaults.shape(RoundedCornerShape(5.dp))) { Text("Resend") }
                        Button(onClick = { mode = TvAuthMode.SIGN_UP; error = null }, colors = ButtonDefaults.colors(containerColor = Color(0xFF2B2B2B), contentColor = Color.White, focusedContainerColor = Color.White, focusedContentColor = Color.Black), shape = ButtonDefaults.shape(RoundedCornerShape(5.dp))) { Text("Back") }
                    }
                }
                TvAuthMode.FORGOT_PASSWORD -> {
                    OutlinedTextField(value = email, onValueChange = { email = it }, label = { Text("Account Email Address") }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(6.dp), textStyle = LocalTextStyle.current.copy(color = Color.White, fontFamily = FontFamily.SansSerif), colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF1C1C1C),
                        unfocusedContainerColor = Color(0xFF1C1C1C),
                        focusedBorderColor = accent,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.18f),
                        cursorColor = accent,
                        focusedLabelColor = Color.White,
                        unfocusedLabelColor = Color(0xFF9E9E9E)
                    ))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = {
                                if (busy) return@Button
                                busy = true; error = null
                                scope.launch {
                                    val res = sessionManager.requestPasswordReset(email.trim())
                                    busy = false
                                    res.onSuccess {
                                        otp = ""; password = ""; confirmPassword = ""
                                        mode = TvAuthMode.RESET_VERIFY
                                        info = "6-digit reset code sent."
                                    }.onFailure { error = it.message }
                                }
                            },
                            colors = ButtonDefaults.colors(containerColor = accent, contentColor = Color.White),
                            modifier = Modifier.weight(1f)
                        ) { Text("Send Reset Code") }
                        Button(onClick = { mode = TvAuthMode.SIGN_IN; error = null }, colors = ButtonDefaults.colors(containerColor = Color(0xFF2B2B2B), contentColor = Color.White, focusedContainerColor = Color.White, focusedContentColor = Color.Black), shape = ButtonDefaults.shape(RoundedCornerShape(5.dp))) { Text("Back") }
                    }
                }
                TvAuthMode.RESET_VERIFY -> {
                    OutlinedTextField(value = otp, onValueChange = { otp = it.filter(Char::isDigit).take(6) }, label = { Text("6-Digit Reset Code") }, singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(6.dp), textStyle = LocalTextStyle.current.copy(color = Color.White, fontFamily = FontFamily.SansSerif), colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF1C1C1C),
                        unfocusedContainerColor = Color(0xFF1C1C1C),
                        focusedBorderColor = accent,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.18f),
                        cursorColor = accent,
                        focusedLabelColor = Color.White,
                        unfocusedLabelColor = Color(0xFF9E9E9E)
                    ))
                    OutlinedTextField(value = password, onValueChange = { password = it }, label = { Text("New Password") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(6.dp), textStyle = LocalTextStyle.current.copy(color = Color.White, fontFamily = FontFamily.SansSerif), colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF1C1C1C),
                        unfocusedContainerColor = Color(0xFF1C1C1C),
                        focusedBorderColor = accent,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.18f),
                        cursorColor = accent,
                        focusedLabelColor = Color.White,
                        unfocusedLabelColor = Color(0xFF9E9E9E)
                    ))
                    OutlinedTextField(value = confirmPassword, onValueChange = { confirmPassword = it }, label = { Text("Confirm New Password") }, visualTransformation = PasswordVisualTransformation(), singleLine = true, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(6.dp), textStyle = LocalTextStyle.current.copy(color = Color.White, fontFamily = FontFamily.SansSerif), colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF1C1C1C),
                        unfocusedContainerColor = Color(0xFF1C1C1C),
                        focusedBorderColor = accent,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.18f),
                        cursorColor = accent,
                        focusedLabelColor = Color.White,
                        unfocusedLabelColor = Color(0xFF9E9E9E)
                    ))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = {
                                if (busy) return@Button
                                if (password != confirmPassword) { error = "Passwords do not match."; return@Button }
                                busy = true; error = null
                                scope.launch {
                                    val res = sessionManager.completePasswordReset(email.trim(), otp, password)
                                    busy = false
                                    res.onFailure { error = it.message }
                                }
                            },
                            colors = ButtonDefaults.colors(containerColor = accent, contentColor = Color.White),
                            modifier = Modifier.weight(1f)
                        ) { Text("Reset Password") }
                        Button(onClick = { mode = TvAuthMode.SIGN_IN; error = null }, colors = ButtonDefaults.colors(containerColor = Color(0xFF2B2B2B), contentColor = Color.White, focusedContainerColor = Color.White, focusedContentColor = Color.Black), shape = ButtonDefaults.shape(RoundedCornerShape(5.dp))) { Text("Back") }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvTelegramScreen(sessionManager: SessionManager, accent: Color) {
    val scope = rememberCoroutineScope()
    var busy by remember { mutableStateOf(false) }
    Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
        Column(modifier = Modifier.width(520.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Text("Telegram Verification", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Text("Link your account via @${SingularityConfig.TELEGRAM_BOT_USERNAME} and join our channel.", color = Color.Gray, fontSize = 16.sp)
            Button(
                onClick = {
                    busy = true
                    scope.launch {
                        sessionManager.recheckTelegramGate()
                        busy = false
                    }
                },
                colors = ButtonDefaults.colors(containerColor = accent, contentColor = Color.White)
            ) {
                Text(if (busy) "Checking..." else "Verify Membership")
            }
        }
    }
}


@Composable
private fun TvProfileAvatarBox(
    profile: UserProfile?,
    size: androidx.compose.ui.unit.Dp,
    cornerRadius: androidx.compose.ui.unit.Dp,
    fontSize: androidx.compose.ui.unit.TextUnit,
    modifier: Modifier = Modifier
) {
    val avatarUrl = profile?.avatarUrl
    Box(
        modifier = modifier
            .size(size)
            .clip(RoundedCornerShape(cornerRadius))
            .background(tvAccent(profile?.avatarColor ?: "E50914")),
        contentAlignment = Alignment.Center
    ) {
        if (!avatarUrl.isNullOrBlank()) {
            AsyncImage(
                model = avatarUrl,
                contentDescription = profile?.name ?: "Profile",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Text((profile?.name ?: "S").take(1).uppercase(), color = Color.White, fontSize = fontSize, fontWeight = FontWeight.Bold)
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvProfilesScreen(sessionManager: SessionManager, isHydrating: Boolean, accent: Color) {
    val profiles by sessionManager.profiles.collectAsState()
    val activeProfile by sessionManager.activeProfile.collectAsState()
    val session by sessionManager.session.collectAsState()
    val defaultProfileFocus = remember { FocusRequester() }
    var selectedName by remember { mutableStateOf<String?>(null) }
    var manageMode by remember { mutableStateOf(false) }
    var showCreateDialog by remember { mutableStateOf(false) }
    var newName by remember { mutableStateOf("") }
    var newColor by remember { mutableStateOf("#E50914") }
    var newIsKids by remember { mutableStateOf(false) }
    var newAvatarUrl by remember { mutableStateOf("") }
    var editTarget by remember { mutableStateOf<UserProfile?>(null) }
    var editName by remember { mutableStateOf("") }
    var editColor by remember { mutableStateOf("#E50914") }
    var editIsKids by remember { mutableStateOf(false) }
    var editAvatarUrl by remember { mutableStateOf("") }
    var deleteTarget by remember { mutableStateOf<UserProfile?>(null) }

    LaunchedEffect(profiles.size) {
        if (profiles.isNotEmpty()) {
            runCatching { defaultProfileFocus.requestFocus() }
        }
    }

    if (showCreateDialog) {
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Add Profile") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(value = newName, onValueChange = { newName = it }, label = { Text("Profile Name") }, singleLine = true, shape = RoundedCornerShape(6.dp), textStyle = LocalTextStyle.current.copy(color = Color.White, fontFamily = FontFamily.SansSerif), colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF1C1C1C),
                        unfocusedContainerColor = Color(0xFF1C1C1C),
                        focusedBorderColor = accent,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.18f),
                        cursorColor = accent,
                        focusedLabelColor = Color.White,
                        unfocusedLabelColor = Color(0xFF9E9E9E)
                    ))
                    OutlinedTextField(value = newAvatarUrl, onValueChange = { newAvatarUrl = it }, label = { Text("Avatar Image URL (Optional)") }, singleLine = true, shape = RoundedCornerShape(6.dp), textStyle = LocalTextStyle.current.copy(color = Color.White, fontFamily = FontFamily.SansSerif), colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF1C1C1C),
                        unfocusedContainerColor = Color(0xFF1C1C1C),
                        focusedBorderColor = accent,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.18f),
                        cursorColor = accent,
                        focusedLabelColor = Color.White,
                        unfocusedLabelColor = Color(0xFF9E9E9E)
                    ))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SingularityAccentPalette.presets.take(6).forEach { preset ->
                            Surface(
                                onClick = { newColor = "#${preset.hex}" },
                                border = ClickableSurfaceDefaults.border(focusedBorder = Border(BorderStroke(2.dp, Color.White))),
                                shape = ClickableSurfaceDefaults.shape(CircleShape),
                                colors = ClickableSurfaceDefaults.colors(containerColor = tvAccent(preset.hex)),
                                modifier = Modifier.size(30.dp)
                            ) {
                                if (newColor.equals("#${preset.hex}", true)) {
                                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Kids Profile")
                        Switch(checked = newIsKids, onCheckedChange = { newIsKids = it })
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val trimmed = newName.trim()
                    if (trimmed.isNotEmpty()) {
                        sessionManager.createProfile(trimmed, newColor, newIsKids, newAvatarUrl.trim().ifBlank { null })
                        newName = ""
                        newIsKids = false
                        newAvatarUrl = ""
                        showCreateDialog = false
                    }
                }) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { showCreateDialog = false }) { Text("Cancel") } }
        )
    }

    editTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { editTarget = null },
            title = { Text("Edit ${target.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    OutlinedTextField(value = editName, onValueChange = { editName = it }, label = { Text("Profile Name") }, singleLine = true, shape = RoundedCornerShape(6.dp), textStyle = LocalTextStyle.current.copy(color = Color.White, fontFamily = FontFamily.SansSerif), colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF1C1C1C),
                        unfocusedContainerColor = Color(0xFF1C1C1C),
                        focusedBorderColor = accent,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.18f),
                        cursorColor = accent,
                        focusedLabelColor = Color.White,
                        unfocusedLabelColor = Color(0xFF9E9E9E)
                    ))
                    OutlinedTextField(value = editAvatarUrl, onValueChange = { editAvatarUrl = it }, label = { Text("Avatar Image URL (https://...)") }, singleLine = true, shape = RoundedCornerShape(6.dp), textStyle = LocalTextStyle.current.copy(color = Color.White, fontFamily = FontFamily.SansSerif), colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = Color.White,
                        unfocusedTextColor = Color.White,
                        focusedContainerColor = Color(0xFF1C1C1C),
                        unfocusedContainerColor = Color(0xFF1C1C1C),
                        focusedBorderColor = accent,
                        unfocusedBorderColor = Color.White.copy(alpha = 0.18f),
                        cursorColor = accent,
                        focusedLabelColor = Color.White,
                        unfocusedLabelColor = Color(0xFF9E9E9E)
                    ))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        SingularityAccentPalette.presets.take(6).forEach { preset ->
                            Surface(
                                onClick = { editColor = "#${preset.hex}" },
                                border = ClickableSurfaceDefaults.border(focusedBorder = Border(BorderStroke(2.dp, Color.White))),
                                shape = ClickableSurfaceDefaults.shape(CircleShape),
                                colors = ClickableSurfaceDefaults.colors(containerColor = tvAccent(preset.hex)),
                                modifier = Modifier.size(30.dp)
                            ) {
                                if (editColor.equals("#${preset.hex}", true)) {
                                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                                        Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Text("Kids Profile")
                        Switch(checked = editIsKids, onCheckedChange = { editIsKids = it })
                    }
                    if (profiles.size > 1) {
                        TextButton(onClick = { editTarget = null; deleteTarget = target }) { Text("Delete Profile", color = accent) }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    val trimmed = editName.trim()
                    if (trimmed.isNotEmpty()) {
                        val cleanUrl = editAvatarUrl.trim()
                        sessionManager.updateProfile(
                            id = target.id,
                            name = trimmed,
                            avatarColor = editColor,
                            isKids = editIsKids,
                            avatarUrl = cleanUrl.ifBlank { null },
                            clearAvatar = cleanUrl.isBlank() && !target.avatarUrl.isNullOrBlank()
                        )
                        editTarget = null
                    }
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { editTarget = null }) { Text("Cancel") } }
        )
    }

    deleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete ${target.name}?") },
            text = { Text("This will remove the profile and its local watch progress.") },
            confirmButton = {
                TextButton(onClick = {
                    sessionManager.deleteProfile(target.id)
                    deleteTarget = null
                }) { Text("Delete", color = accent) }
            },
            dismissButton = { TextButton(onClick = { deleteTarget = null }) { Text("Cancel") } }
        )
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF1B0609), Color(0xFF08080C), Color(0xFF040406))))
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(horizontal = 42.dp, vertical = 26.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("S", color = accent, fontSize = 24.sp, fontWeight = FontWeight.Black)
                    Text("SingularityTV", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                }
                Button(
                    onClick = { manageMode = !manageMode },
                    colors = ButtonDefaults.colors(containerColor = Color.White.copy(alpha = 0.12f), contentColor = Color.White)
                ) {
                    Text(if (manageMode) "Done" else "Manage Profiles", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }
            }

            Column(
                modifier = Modifier.weight(1f).fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(if (manageMode) "Manage Profiles" else "Who's Watching?", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                session?.email?.takeIf { it.isNotBlank() }?.let { email ->
                    Spacer(Modifier.height(4.dp))
                    Text(email, color = Color.White.copy(alpha = 0.55f), fontSize = 13.sp)
                }
                Spacer(Modifier.height(26.dp))
                LazyRow(horizontalArrangement = Arrangement.spacedBy(20.dp), contentPadding = PaddingValues(horizontal = 16.dp)) {
                    itemsIndexed(profiles, key = { _, p -> p.id }) { idx, profile ->
                        val isActive = profile.id == activeProfile?.id
                        val isDefaultTarget = isActive || (activeProfile == null && idx == 0)
                        Surface(
                            onClick = {
                                if (manageMode) {
                                    editTarget = profile
                                    editName = profile.name
                                    editColor = profile.avatarColor
                                    editIsKids = profile.isKids
                                    editAvatarUrl = profile.avatarUrl.orEmpty()
                                } else if (!isHydrating) {
                                    selectedName = profile.name
                                    sessionManager.selectProfile(profile)
                                }
                            },
                            border = ClickableSurfaceDefaults.border(
                                border = if (isActive && !manageMode) Border(BorderStroke(1.5.dp, Color.White.copy(alpha = 0.7f))) else Border.None,
                                focusedBorder = Border(BorderStroke(2.5.dp, accent))
                            ),
                            scale = ClickableSurfaceDefaults.scale(focusedScale = 1.06f),
                            shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(18.dp)),
                            colors = ClickableSurfaceDefaults.colors(containerColor = Color.Transparent, focusedContainerColor = Color.White.copy(alpha = 0.08f)),
                            modifier = if (isDefaultTarget) Modifier.focusRequester(defaultProfileFocus) else Modifier
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(14.dp)) {
                                Box(
                                    modifier = Modifier.size(88.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    TvProfileAvatarBox(profile = profile, size = 88.dp, cornerRadius = 22.dp, fontSize = 34.sp)
                                    if (profile.isKids) {
                                        Text(
                                            "KIDS",
                                            color = Color.Black,
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Black,
                                            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 6.dp).background(Color.White, RoundedCornerShape(4.dp)).padding(horizontal = 5.dp, vertical = 1.dp)
                                        )
                                    }
                                    if (manageMode) {
                                        Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.45f), RoundedCornerShape(22.dp)), contentAlignment = Alignment.Center) {
                                            Icon(if (profiles.size > 1) Icons.Default.Delete else Icons.Default.Edit, null, tint = Color.White)
                                        }
                                    }
                                }
                                Spacer(Modifier.height(8.dp))
                                Text(profile.name, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                                if (isActive && !manageMode) {
                                    Text("ACTIVE", color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                                }
                            }
                        }
                    }
                    if (profiles.size < 5) {
                        item {
                            Surface(
                                onClick = { showCreateDialog = true },
                                border = ClickableSurfaceDefaults.border(focusedBorder = Border(BorderStroke(2.5.dp, accent))),
                                scale = ClickableSurfaceDefaults.scale(focusedScale = 1.06f),
                                shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(18.dp)),
                                colors = ClickableSurfaceDefaults.colors(containerColor = Color.Transparent, focusedContainerColor = Color.White.copy(alpha = 0.08f))
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(14.dp)) {
                                    Box(
                                        modifier = Modifier.size(88.dp).background(Color.White.copy(alpha = 0.08f), RoundedCornerShape(22.dp)).border(1.dp, Color.White.copy(alpha = 0.16f), RoundedCornerShape(22.dp)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.Add, null, tint = Color.White, modifier = Modifier.size(32.dp))
                                    }
                                    Spacer(Modifier.height(8.dp))
                                    Text("Add Profile", color = Color.White.copy(alpha = 0.85f), fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
            }
        }
        if (isHydrating) {
            Box(Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.90f)), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("S", color = accent, fontSize = 48.sp, fontWeight = FontWeight.Black)
                    CircularProgressIndicator(color = accent)
                    Text("Loading ${selectedName ?: "profile"}...", color = Color.White.copy(alpha = 0.75f), fontSize = 15.sp)
                }
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvMainShell(sessionManager: SessionManager, accent: Color, onOpenDetail: (MediaItem) -> Unit, onPlay: (WatchItem) -> Unit) {
    var selectedNav by remember { mutableIntStateOf(0) }
    val screenW = LocalConfiguration.current.screenWidthDp
    val sidebarWidth = (screenW * 0.165f).coerceIn(148f, 176f).dp

    Row(Modifier.fillMaxSize().background(Color.Black)) {
        Column(
            modifier = Modifier.width(sidebarWidth).fillMaxHeight().background(Color(0xFF09090C)).padding(vertical = 20.dp, horizontal = 10.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(bottom = 14.dp, start = 6.dp)) {
                Text("S", color = accent, fontSize = 20.sp, fontWeight = FontWeight.Black)
                Text("SingularityTV", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1)
            }
            TvNavRailButton("Home", Icons.Default.Home, selectedNav == 0, accent) { selectedNav = 0 }
            TvNavRailButton("New & Hot", Icons.Default.Whatshot, selectedNav == 1, accent) { selectedNav = 1 }
            TvNavRailButton("Search", Icons.Default.Search, selectedNav == 2, accent) { selectedNav = 2 }
            TvNavRailButton("Settings", Icons.Default.Settings, selectedNav == 3, accent) { selectedNav = 3 }
            TvNavRailButton("Profiles", Icons.Default.Person, false, accent) { sessionManager.switchToProfilePicker() }
            Spacer(Modifier.weight(1f))
            Text("v${SingularityConfig.APP_VERSION}", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.padding(start = 8.dp))
        }
        Box(Modifier.width(1.dp).fillMaxHeight().background(Color.White.copy(alpha = 0.07f)))
        Box(Modifier.weight(1f).fillMaxHeight()) {
            when (selectedNav) {
                0 -> TvHomeContent(sessionManager, accent, onOpenDetail, onPlay)
                1 -> TvNewHotContent(sessionManager, accent, onOpenDetail)
                2 -> TvSearchContent(onOpenDetail)
                3 -> TvSettingsContent(sessionManager, accent)
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvNavRailButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, accent: Color, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        colors = ClickableSurfaceDefaults.colors(
            containerColor = if (selected) accent.copy(alpha = 0.18f) else Color.Transparent,
            focusedContainerColor = Color.White.copy(alpha = 0.22f)
        ),
        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.04f),
        border = ClickableSurfaceDefaults.border(focusedBorder = Border(BorderStroke(2.dp, accent))),
        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(4.dp)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(modifier = Modifier.padding(horizontal = 10.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(icon, null, tint = if (selected) Color.White else Color.Gray, modifier = Modifier.size(18.dp))
            Text(label, color = if (selected) Color.White else Color.Gray, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvHomeContent(sessionManager: SessionManager, accent: Color, onOpenDetail: (MediaItem) -> Unit, onPlay: (WatchItem) -> Unit) {
    val cfg = LocalConfiguration.current
    val contentW = (cfg.screenWidthDp - 170).coerceAtLeast(600)
    val posterW = (contentW / 6.8f).coerceIn(104f, 128f)
    val heroH = (cfg.screenHeightDp * 0.44f).coerceIn(220f, 280f).dp

    var scopeFilter by remember { mutableStateOf("all") }
    var selectedGenre by remember { mutableStateOf<Pair<Int, String>?>(null) }
    var trending by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var topSeries by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var topFilms by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var nowPlaying by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var onTheAir by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var movies by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var series by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var actionItems by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var comedyItems by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var genreResults by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    val cw by sessionManager.continueWatching.collectAsState()
    val myList by sessionManager.myList.collectAsState()

    LaunchedEffect(Unit) {
        trending = TMDBApiClient.trendingAll()
        topSeries = TMDBApiClient.trendingTodaySeries().take(10)
        topFilms = TMDBApiClient.trendingTodayMovies().take(10)
        nowPlaying = TMDBApiClient.nowPlayingMovies()
        onTheAir = TMDBApiClient.onTheAirSeries()
        movies = TMDBApiClient.popularMovies()
        series = TMDBApiClient.popularSeries()
        actionItems = TMDBApiClient.discoverByGenre(WatchType.MOVIE, 28)
        comedyItems = TMDBApiClient.discoverByGenre(WatchType.MOVIE, 35)
    }

    LaunchedEffect(selectedGenre, scopeFilter) {
        val g = selectedGenre
        genreResults = if (g != null) {
            val type = if (scopeFilter == "series") WatchType.TV else WatchType.MOVIE
            TMDBApiClient.discoverByGenre(type, g.first)
        } else emptyList()
    }

    val heroPool = when (scopeFilter) {
        "series" -> topSeries.ifEmpty { series }
        "films" -> topFilms.ifEmpty { movies }
        else -> trending
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 28.dp)) {
        item {
            LazyRow(
                contentPadding = PaddingValues(horizontal = 24.dp, vertical = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(listOf("all" to "All", "series" to "Series", "films" to "Films")) { (key, label) ->
                    val sel = scopeFilter == key && selectedGenre == null
                    Button(
                        onClick = { scopeFilter = key; selectedGenre = null },
                        colors = ButtonDefaults.colors(containerColor = if (sel) Color.White else Color.White.copy(alpha = 0.12f), contentColor = if (sel) Color.Black else Color.White)
                    ) { Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                }
                items(SingularityGenres.all.take(6)) { g ->
                    val sel = selectedGenre?.first == g.first
                    Button(
                        onClick = { selectedGenre = if (sel) null else g },
                        colors = ButtonDefaults.colors(containerColor = if (sel) accent else Color.White.copy(alpha = 0.10f), contentColor = Color.White)
                    ) { Text(g.second, fontSize = 12.sp) }
                }
            }
        }
        heroPool.firstOrNull()?.let { hero ->
            val inList = myList.any { it.mediaType == hero.watchType && it.tmdbId == hero.id }
            val savedHero = MyListItem(hero.watchType, hero.id, hero.displayTitle, hero.posterPath, hero.backdropPath, hero.overview, hero.displayYear)
            item {
                Box(Modifier.fillMaxWidth().height(heroH).padding(horizontal = 24.dp).clip(RoundedCornerShape(12.dp))) {
                    AsyncImage(model = hero.backdropUrl ?: hero.posterUrl, contentDescription = hero.displayTitle, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(listOf(Color.Black.copy(alpha = 0.92f), Color.Black.copy(alpha = 0.45f), Color.Transparent))))
                    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f)))))
                    Column(modifier = Modifier.align(Alignment.CenterStart).padding(24.dp).width(460.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(hero.displayTitle, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Black, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            hero.matchPercent?.let { Text("$it% rating", color = Color(0xFF45D478), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                            hero.displayYear?.let { Text(it, color = Color.LightGray, fontSize = 12.sp) }
                            if (hero.genreTags.isNotEmpty()) Text(hero.genreTags.joinToString(" • "), color = Color(0xFFB8B8B8), fontSize = 12.sp)
                        }
                        Text(hero.overview, color = Color.LightGray, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(
                                onClick = {
                                    onPlay(WatchItem(id = "${hero.watchType.rawValue}_${hero.id}", type = hero.watchType, title = hero.displayTitle, tmdbId = hero.id.toString(), season = if (hero.isMovie) null else 1, episode = if (hero.isMovie) null else 1, posterPath = hero.posterPath, generatedURL = StreamingProviderBuilder.buildUrl(hero.watchType, hero.id, 1, 1)))
                                },
                                colors = ButtonDefaults.colors(containerColor = Color.White, contentColor = Color.Black, focusedContainerColor = accent, focusedContentColor = Color.White),
                                shape = ButtonDefaults.shape(RoundedCornerShape(5.dp))
                            ) {
                                Icon(Icons.Default.PlayArrow, null, modifier = Modifier.size(16.dp))
                                Text(" Play", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            }
                            Button(
                                onClick = { sessionManager.toggleMyList(savedHero) },
                                colors = ButtonDefaults.colors(containerColor = Color(0xFF2B2B2B), contentColor = Color.White, focusedContainerColor = Color.White, focusedContentColor = Color.Black),
                                shape = ButtonDefaults.shape(RoundedCornerShape(5.dp))
                            ) {
                                Icon(if (inList) Icons.Default.Check else Icons.Default.Add, null, modifier = Modifier.size(16.dp))
                                Text(" My List", fontSize = 13.sp)
                            }
                            Button(
                                onClick = { onOpenDetail(hero) },
                                colors = ButtonDefaults.colors(containerColor = Color(0xFF2B2B2B), contentColor = Color.White, focusedContainerColor = Color.White, focusedContentColor = Color.Black),
                                shape = ButtonDefaults.shape(RoundedCornerShape(5.dp))
                            ) { Text("Details", fontSize = 13.sp) }
                        }
                    }
                }
            }
        }
        if (selectedGenre != null && genreResults.isNotEmpty()) {
            item { TvMediaRow("${selectedGenre!!.second} Picks", genreResults, accent, onOpenDetail, posterW) }
        }
        if (cw.isNotEmpty()) {
            item {
                Column(Modifier.padding(top = 16.dp)) {
                    Text("Continue Watching", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 24.dp, vertical = 6.dp))
                    LazyRow(contentPadding = PaddingValues(horizontal = 24.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        items(cw, key = { it.id }) { entry ->
                            TvContinueCard(
                                entry = entry,
                                accent = accent,
                                posterWidthDp = posterW,
                                onPlay = {
                                    onPlay(
                                        WatchItem(
                                            id = entry.id,
                                            type = entry.type,
                                            title = entry.title,
                                            tmdbId = entry.tmdbId,
                                            season = entry.season,
                                            episode = entry.episode,
                                            episodeName = entry.episodeName,
                                            posterPath = entry.posterPath,
                                            generatedURL = StreamingProviderBuilder.buildUrl(entry.type, entry.tmdbId.toIntOrNull() ?: 0, entry.season, entry.episode, entry.progressSeconds?.toInt())
                                        )
                                    )
                                },
                                onRemove = { sessionManager.removeContinueWatching(entry.type, entry.tmdbId) }
                            )
                        }
                    }
                }
            }
        }
        if (scopeFilter == "all" && trending.isNotEmpty()) item { TvMediaRow("Trending Now", trending, accent, onOpenDetail, posterW) }
        if (scopeFilter != "films" && topSeries.isNotEmpty()) item { TvMediaRow("Top 10 Series Today", topSeries, accent, onOpenDetail, posterW, showRank = true) }
        if (scopeFilter != "series" && nowPlaying.isNotEmpty()) item { TvMediaRow("New Releases", nowPlaying, accent, onOpenDetail, posterW) }
        if (myList.isNotEmpty()) item { TvMediaRow("My List", myList.map { it.toMediaItem() }, accent, onOpenDetail, posterW) }
        if (scopeFilter != "series" && topFilms.isNotEmpty()) item { TvMediaRow("Top 10 Films Today", topFilms, accent, onOpenDetail, posterW, showRank = true) }
        if (scopeFilter != "films" && onTheAir.isNotEmpty()) item { TvMediaRow("New Episodes", onTheAir, accent, onOpenDetail, posterW) }
        if (scopeFilter != "series" && movies.isNotEmpty()) item { TvMediaRow("Popular Movies", movies, accent, onOpenDetail, posterW) }
        if (scopeFilter != "films" && series.isNotEmpty()) item { TvMediaRow("Popular Series", series, accent, onOpenDetail, posterW) }
        if (scopeFilter != "series" && actionItems.isNotEmpty()) item { TvMediaRow("Action & Adventure", actionItems, accent, onOpenDetail, posterW) }
        if (scopeFilter != "series" && comedyItems.isNotEmpty()) item { TvMediaRow("Comedies", comedyItems, accent, onOpenDetail, posterW) }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvContinueCard(
    entry: ContinueWatchingItem,
    accent: Color,
    posterWidthDp: Float,
    onPlay: () -> Unit,
    onRemove: () -> Unit
) {
    val w = posterWidthDp.dp
    val h = (posterWidthDp * 1.48f).dp
    val remShort = SingularityPlaybackFormatter.formatRemainingTime(entry.progressSeconds, entry.durationSeconds)?.removeSuffix(" left")
    val leftLabel = when {
        entry.type == WatchType.TV && remShort != null -> "S${entry.season ?: 1}:E${entry.episode ?: 1} · $remShort"
        entry.type == WatchType.TV -> "S${entry.season ?: 1}:E${entry.episode ?: 1}"
        remShort != null -> remShort
        entry.formattedPosition != null -> entry.formattedPosition!!
        else -> entry.durationSeconds?.takeIf { it > 0 }?.let { "${(it / 60).toInt()}m" }.orEmpty()
    }
    Column(
        modifier = Modifier
            .width(w)
            .clip(RoundedCornerShape(4.dp))
            .background(Color(0xFF1F1F1F))
    ) {
        Surface(
            onClick = onPlay,
            border = ClickableSurfaceDefaults.border(focusedBorder = Border(BorderStroke(2.5.dp, accent))),
            scale = ClickableSurfaceDefaults.scale(focusedScale = 1.04f),
            shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(topStart = 4.dp, topEnd = 4.dp)),
            modifier = Modifier.width(w).height(h)
        ) {
            Box(Modifier.fillMaxSize()) {
                AsyncImage(model = entry.posterUrl, contentDescription = entry.title, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .align(Alignment.Center)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.55f))
                        .border(1.5.dp, Color.White, CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.PlayArrow, null, tint = Color.White, modifier = Modifier.size(20.dp))
                }
                LinearProgressIndicator(
                    progress = { (entry.progressFraction ?: 0.04).toFloat() },
                    color = accent,
                    trackColor = Color(0xFF333333),
                    modifier = Modifier.fillMaxWidth().height(3.dp).align(Alignment.BottomCenter)
                )
            }
        }
        Row(
            modifier = Modifier.fillMaxWidth().height(32.dp).padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(leftLabel, color = Color(0xFFB8B8B8), fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, modifier = Modifier.weight(1f))
            Surface(
                onClick = onRemove,
                colors = ClickableSurfaceDefaults.colors(containerColor = Color.Transparent, focusedContainerColor = accent),
                shape = ClickableSurfaceDefaults.shape(CircleShape),
                modifier = Modifier.size(24.dp)
            ) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Close, contentDescription = "Remove", tint = Color.White, modifier = Modifier.size(14.dp))
                }
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvMediaRow(
    title: String,
    items: List<MediaItem>,
    accent: Color,
    onClick: (MediaItem) -> Unit,
    posterWidthDp: Float = 114f,
    showRank: Boolean = false
) {
    val w = posterWidthDp.dp
    val h = (posterWidthDp * 1.48f).dp
    Column(Modifier.padding(top = 16.dp)) {
        Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 24.dp, vertical = 6.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 24.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            itemsIndexed(items, key = { idx, it -> "${title}_${idx}_${it.mediaType}_${it.id}" }) { index, item ->
                Row(verticalAlignment = Alignment.Bottom) {
                    if (showRank) {
                        Text(
                            "${index + 1}",
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 44.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.padding(end = 4.dp)
                        )
                    }
                    Surface(
                        onClick = { onClick(item) },
                        border = ClickableSurfaceDefaults.border(focusedBorder = Border(BorderStroke(2.5.dp, accent))),
                        scale = ClickableSurfaceDefaults.scale(focusedScale = 1.06f),
                        shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(4.dp)),
                        modifier = Modifier.width(w).height(h)
                    ) {
                        Box(Modifier.fillMaxSize()) {
                            AsyncImage(model = item.posterUrl, contentDescription = item.displayTitle, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                            if (showRank) {
                                Column(
                                    modifier = Modifier
                                        .align(Alignment.TopEnd)
                                        .background(accent, RoundedCornerShape(bottomStart = 3.dp))
                                        .padding(horizontal = 4.dp, vertical = 2.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text("TOP", color = Color.White, fontSize = 6.5.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 7.sp)
                                    Text("10", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Black, lineHeight = 11.sp)
                                }
                            }
                            if (item.isArabicOrGulfContent) {
                                Text("May Not Stream", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(5.dp).background(Color.Black.copy(alpha = 0.72f), RoundedCornerShape(50)).padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvNewHotContent(sessionManager: SessionManager, accent: Color, onOpenDetail: (MediaItem) -> Unit) {
    var upcoming by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var everyonesWatching by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var topSeries by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var topFilms by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    val reminders by sessionManager.reminders.collectAsState()

    LaunchedEffect(Unit) {
        upcoming = TMDBApiClient.upcomingComingSoon()
        everyonesWatching = TMDBApiClient.trendingToday().take(10)
        topSeries = TMDBApiClient.trendingTodaySeries().take(10)
        topFilms = TMDBApiClient.trendingTodayMovies().take(10)
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(vertical = 24.dp, horizontal = 24.dp), verticalArrangement = Arrangement.spacedBy(20.dp)) {
        item { Text("Coming Soon", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        if (upcoming.isNotEmpty()) {
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(18.dp)) {
                    items(upcoming, key = { "${it.mediaType}_${it.id}" }) { item ->
                        val relDate = item.releaseDateParsed
                        val saved = MyListItem(item.watchType, item.id, item.displayTitle, item.posterPath, item.backdropPath, item.overview, item.displayYear)
                        val reminded = reminders.any { it.title.mediaType == item.watchType && it.title.tmdbId == item.id }
                        Column(
                            modifier = Modifier
                                .width(340.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Color(0xFF141414))
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Surface(
                                onClick = { onOpenDetail(item) },
                                scale = ClickableSurfaceDefaults.scale(focusedScale = 1.06f),
                    border = ClickableSurfaceDefaults.border(focusedBorder = Border(BorderStroke(2.5.dp, accent))),
                                shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(4.dp)),
                                modifier = Modifier.fillMaxWidth().height(175.dp)
                            ) {
                                AsyncImage(model = item.backdropUrl ?: item.posterUrl, contentDescription = item.displayTitle, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                            }
                            if (relDate != null) {
                                Text(SingularityDateHelper.comingLabel(relDate, item.isMovie), color = accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                            Text(item.displayTitle, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(item.overview, color = Color.LightGray, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = { sessionManager.toggleReminder(saved, relDate?.time ?: SingularityDateHelper.startOfTomorrow().time, scheduleNotification = false) },
                                    colors = ButtonDefaults.colors(containerColor = Color.White, contentColor = Color.Black, focusedContainerColor = accent, focusedContentColor = Color.White),
                                    shape = ButtonDefaults.shape(RoundedCornerShape(5.dp))
                                ) {
                                    Icon(if (reminded) Icons.Default.Notifications else Icons.Default.NotificationsNone, null)
                                    Text(if (reminded) " Reminder Set" else " Remind Me")
                                }
                                Button(onClick = { onOpenDetail(item) }) {
                                    Text("Info")
                                }
                            }
                        }
                    }
                }
            }
        }
        item { TvMediaRow("Everyone's Watching", everyonesWatching, accent, onOpenDetail) }
        item { TvMediaRow("Top 10 Series", topSeries, accent, onOpenDetail) }
        item { TvMediaRow("Top 10 Films", topFilms, accent, onOpenDetail) }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvSearchContent(onOpenDetail: (MediaItem) -> Unit) {
    val scope = rememberCoroutineScope()
    val searchFocusRequester = remember { FocusRequester() }
    var query by remember { mutableStateOf("") }
    var selectedType by remember { mutableStateOf(SearchMediaFilter.ALL) }
    var selectedCategory by remember { mutableStateOf<SearchCategory?>(null) }
    var selectedSort by remember { mutableStateOf(SearchSortOption.POPULARITY) }
    var selectedYear by remember { mutableStateOf<Int?>(null) }
    var topSearches by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var results by remember { mutableStateOf<List<MediaItem>>(emptyList()) }
    var page by remember { mutableIntStateOf(1) }
    var canLoadMore by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var searchGeneration by remember { mutableIntStateOf(0) }

    val hasActiveFilters = query.isNotBlank() ||
        selectedType != SearchMediaFilter.ALL ||
        selectedCategory != null ||
        selectedSort != SearchSortOption.POPULARITY ||
        selectedYear != null

    LaunchedEffect(Unit) {
        runCatching { searchFocusRequester.requestFocus() }
        topSearches = TMDBApiClient.trendingToday()
    }

    LaunchedEffect(query, selectedType, selectedCategory, selectedSort, selectedYear) {
        val gen = ++searchGeneration
        if (!hasActiveFilters) {
            results = emptyList()
            page = 1
            canLoadMore = false
            isLoading = false
            return@LaunchedEffect
        }
        if (query.isNotBlank()) delay(300L)
        if (gen != searchGeneration) return@LaunchedEffect
        isLoading = true
        val fetched = if (query.isNotBlank()) {
            TMDBApiClient.searchMulti(query, page = 1).filter { item ->
                val typeOk = when (selectedType) {
                    SearchMediaFilter.ALL -> true
                    SearchMediaFilter.MOVIE -> item.isMovie
                    SearchMediaFilter.TV -> !item.isMovie
                }
                val yearOk = selectedYear == null || item.displayYear == selectedYear.toString()
                val catOk = selectedCategory == null || run {
                    val gStr = if (item.isMovie) selectedCategory?.movieGenres else selectedCategory?.tvGenres
                    if (gStr == null) false else {
                        val wanted = gStr.split("|").mapNotNull { it.toIntOrNull() }.toSet()
                        item.genreIds?.any { it in wanted } == true
                    }
                }
                typeOk && yearOk && catOk
            }
        } else {
            TMDBApiClient.discoverAdvanced(selectedType, selectedCategory, selectedSort, selectedYear, page = 1)
        }
        if (gen == searchGeneration) {
            results = fetched
            page = 1
            canLoadMore = fetched.size >= 16
            isLoading = false
        }
    }

    LazyColumn(Modifier.fillMaxSize().padding(28.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    label = { Text("Search movies, series, genres...") },
                    singleLine = true,
                    textStyle = LocalTextStyle.current.copy(color = Color.White, fontFamily = FontFamily.SansSerif),
                    shape = RoundedCornerShape(6.dp),
                    colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedContainerColor = Color(0xFF1C1C1C), unfocusedContainerColor = Color(0xFF1C1C1C), focusedBorderColor = Color(0xFFE50914), unfocusedBorderColor = Color.White.copy(alpha = 0.18f), cursorColor = Color(0xFFE50914), focusedLabelColor = Color.White, unfocusedLabelColor = Color(0xFF9E9E9E)),
                    modifier = Modifier.width(420.dp).focusRequester(searchFocusRequester)
                )
                if (hasActiveFilters) {
                    Button(
                        onClick = {
                            query = ""
                            selectedType = SearchMediaFilter.ALL
                            selectedCategory = null
                            selectedSort = SearchSortOption.POPULARITY
                            selectedYear = null
                        },
                        colors = ButtonDefaults.colors(containerColor = Color(0xFF262626), contentColor = Color.White)
                    ) { Text("Clear") }
                }
            }
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(SearchMediaFilter.entries) { filter ->
                    val sel = selectedType == filter
                    Button(
                        onClick = { selectedType = filter },
                        colors = ButtonDefaults.colors(containerColor = if (sel) Color.White else Color(0xFF222222), contentColor = if (sel) Color.Black else Color.White)
                    ) { Text(filter.label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold) }
                }
                items(SearchSortOption.entries) { sort ->
                    val sel = selectedSort == sort
                    Button(
                        onClick = { selectedSort = sort },
                        colors = ButtonDefaults.colors(containerColor = if (sel) Color(0xFFE50914) else Color(0xFF222222), contentColor = Color.White)
                    ) { Text(sort.label, fontSize = 12.sp) }
                }
                items(listOf<Int?>(null, 2026, 2025, 2024, 2023, 2022, 2020)) { yr ->
                    val sel = selectedYear == yr
                    Button(
                        onClick = { selectedYear = if (sel) null else yr },
                        colors = ButtonDefaults.colors(containerColor = if (sel) Color.White else Color(0xFF222222), contentColor = if (sel) Color.Black else Color.White)
                    ) { Text(yr?.toString() ?: "All Years", fontSize = 12.sp) }
                }
            }
        }
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    val sel = selectedCategory == null
                    Button(
                        onClick = { selectedCategory = null },
                        colors = ButtonDefaults.colors(containerColor = if (sel) Color(0xFFE50914) else Color(0xFF1E1E1E), contentColor = Color.White)
                    ) { Text("All Genres", fontSize = 12.sp) }
                }
                items(SingularityCategories.catalog, key = { it.id }) { cat ->
                    val sel = selectedCategory?.id == cat.id
                    Button(
                        onClick = { selectedCategory = if (sel) null else cat },
                        colors = ButtonDefaults.colors(containerColor = if (sel) Color(0xFFE50914) else Color(0xFF1E1E1E), contentColor = Color.White)
                    ) { Text(cat.title, fontSize = 12.sp) }
                }
            }
        }
        if (!hasActiveFilters) {
            item { TvMediaRow("Top Searches", topSearches, Color(0xFFE50914), onOpenDetail) }
        } else if (isLoading && results.isEmpty()) {
            item { CircularProgressIndicator(color = Color(0xFFE50914)) }
        } else if (results.isEmpty()) {
            item { Text("No matching titles found.", color = Color.Gray, fontSize = 15.sp) }
        } else {
            item { TvMediaRow("Results (${results.size})", results, Color(0xFFE50914), onOpenDetail) }
            if (canLoadMore) {
                item {
                    Button(
                        onClick = {
                            if (isLoading) return@Button
                            val gen = searchGeneration
                            val nextPage = page + 1
                            isLoading = true
                            scope.launch {
                                val more = if (query.isNotBlank()) {
                                    TMDBApiClient.searchMulti(query, page = nextPage)
                                } else {
                                    TMDBApiClient.discoverAdvanced(selectedType, selectedCategory, selectedSort, selectedYear, page = nextPage)
                                }
                                if (gen == searchGeneration) {
                                    results = (results + more).distinctBy { "${it.mediaType}_${it.id}" }
                                    page = nextPage
                                    canLoadMore = more.size >= 16
                                    isLoading = false
                                }
                            }
                        },
                        colors = ButtonDefaults.colors(containerColor = Color(0xFF262626), contentColor = Color.White)
                    ) { Text(if (isLoading) "Loading..." else "Load More") }
                }
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvSettingsContent(sessionManager: SessionManager, accent: Color) {
    val settings by sessionManager.appSettings.collectAsState()
    val webPrefs by sessionManager.webPlayerPrefs.collectAsState()
    val profile by sessionManager.activeProfile.collectAsState()

    LazyColumn(Modifier.fillMaxSize().padding(32.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        item { Text("Settings", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold) }
        item {
            Text("Profile: ${profile?.name ?: "Main"} · v${SingularityConfig.APP_VERSION}", color = Color.LightGray, fontSize = 15.sp)
        }
        item {
            Text("Accent Color", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                SingularityAccentPalette.presets.forEach { opt ->
                    Surface(
                        onClick = { sessionManager.updateAppSettings { it.copy(accentColorHex = opt.hex) } },
                        border = ClickableSurfaceDefaults.border(focusedBorder = Border(BorderStroke(3.dp, Color.White))),
                        shape = ClickableSurfaceDefaults.shape(CircleShape),
                        colors = ClickableSurfaceDefaults.colors(containerColor = tvAccent(opt.hex)),
                        modifier = Modifier.size(44.dp)
                    ) {
                        if (settings.accentColorHex.equals(opt.hex, true)) {
                            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Icon(Icons.Default.Check, null, tint = Color.White) }
                        }
                    }
                }
            }
        }
        item {
            Text("Preferred Quality: ${webPrefs.preferredQuality}", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("Auto", "1080p", "720p", "480p").forEach { q ->
                    Button(onClick = { sessionManager.updateWebPlayerPrefs { it.copy(preferredQuality = q) } }, colors = ButtonDefaults.colors(containerColor = if (webPrefs.preferredQuality == q) Color.White else Color(0xFF2B2B2B), contentColor = if (webPrefs.preferredQuality == q) Color.Black else Color.White, focusedContainerColor = accent, focusedContentColor = Color.White), shape = ButtonDefaults.shape(RoundedCornerShape(5.dp))) { Text(q) }
                }
            }
        }
        item {
            Text("Subtitle Language: ${webPrefs.subtitleLanguage}", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("Off", "Arabic", "English").forEach { s ->
                    Button(onClick = { sessionManager.updateWebPlayerPrefs { it.copy(subtitleLanguage = s) } }, colors = ButtonDefaults.colors(containerColor = if (webPrefs.subtitleLanguage == s) Color.White else Color(0xFF2B2B2B), contentColor = if (webPrefs.subtitleLanguage == s) Color.Black else Color.White, focusedContainerColor = accent, focusedContentColor = Color.White), shape = ButtonDefaults.shape(RoundedCornerShape(5.dp))) { Text(s) }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                Button(onClick = { sessionManager.clearHistory() }, colors = ButtonDefaults.colors(containerColor = Color(0xFF2B2B2B), contentColor = Color.White, focusedContainerColor = Color.White, focusedContentColor = Color.Black), shape = ButtonDefaults.shape(RoundedCornerShape(5.dp))) { Text("Delete History") }
                Button(onClick = { sessionManager.clearCache() }, colors = ButtonDefaults.colors(containerColor = Color(0xFF2B2B2B), contentColor = Color.White, focusedContainerColor = Color.White, focusedContentColor = Color.Black), shape = ButtonDefaults.shape(RoundedCornerShape(5.dp))) { Text("Delete Cache") }
                Button(onClick = { sessionManager.signOut() }, colors = ButtonDefaults.colors(containerColor = accent, contentColor = Color.White)) { Text("Sign Out") }
            }
        }
    }
}

@OptIn(ExperimentalTvMaterial3Api::class)
@Composable
private fun TvDetailScreen(
    item: MediaItem,
    sessionManager: SessionManager,
    accent: Color,
    onOpenRelated: (MediaItem) -> Unit,
    onPlay: (WatchItem) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var payload by remember { mutableStateOf<TitleDetailPayload?>(null) }
    var selectedSeason by remember { mutableIntStateOf(1) }
    var episodes by remember { mutableStateOf<List<EpisodeSummary>>(emptyList()) }
    var activeTab by remember { mutableIntStateOf(if (item.isMovie) 1 else 0) }
    val reminders by sessionManager.reminders.collectAsState()
    val cwList by sessionManager.continueWatching.collectAsState()
    val savedCw = cwList.firstOrNull { it.type == item.watchType && it.tmdbId == item.id.toString() }
    val resumeSec = savedCw?.progressSeconds?.takeIf { it >= 5.0 }
    val playLabel = when {
        resumeSec == null -> "Play"
        !item.isMovie && savedCw?.season != null && savedCw.episode != null -> "Resume S${savedCw.season}:E${savedCw.episode}"
        else -> "Resume"
    }
    val remainingLabel = SingularityPlaybackFormatter.formatRemainingTime(savedCw?.progressSeconds, savedCw?.durationSeconds)
    val primaryFocusRequester = remember { FocusRequester() }

    LaunchedEffect(item.id, item.mediaType) {
        runCatching { primaryFocusRequester.requestFocus() }
        payload = TMDBApiClient.titleDetail(item.watchType, item.id)
        if (!item.isMovie) {
            selectedSeason = savedCw?.season ?: payload?.seasons?.firstOrNull { it.seasonNumber > 0 }?.seasonNumber ?: 1
            episodes = TMDBApiClient.seasonEpisodes(item.id, selectedSeason)
        }
    }

    LaunchedEffect(selectedSeason) {
        if (!item.isMovie) episodes = TMDBApiClient.seasonEpisodes(item.id, selectedSeason)
    }

    val saved = MyListItem(item.watchType, item.id, item.displayTitle, item.posterPath, item.backdropPath, item.overview, item.displayYear)
    val inList = sessionManager.isInMyList(item.watchType, item.id)
    val liked = sessionManager.isLiked(item.watchType, item.id)
    val reminded = reminders.any { it.title.mediaType == item.watchType && it.title.tmdbId == item.id }
    val relDate = item.releaseDateParsed
    val logoUrl = payload?.bestLogoUrl()
    val trailer = payload?.videos?.results?.firstOrNull { it.isYouTube && it.type.equals("Trailer", true) }
        ?: payload?.videos?.results?.firstOrNull { it.isYouTube }
    val videos = payload?.videos?.results?.filter { it.isYouTube }?.take(12).orEmpty()
    val cast = payload?.credits?.cast?.take(6).orEmpty()
    val related = (payload?.recommendations?.results.orEmpty() + payload?.similar?.results.orEmpty())
        .map { if (it.mediaType != "movie" && it.mediaType != "tv") it.copy(mediaType = item.mediaType) else it }
        .distinctBy { "${it.mediaType}_${it.id}" }
        .filter { it.id != item.id && !it.posterPath.isNullOrBlank() }
        .take(14)
    val cert = payload?.usCertification(item.isMovie)
    val directorOrCreators = payload?.directorOrCreators(item.isMovie)

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AsyncImage(
            model = item.backdropUrl ?: item.posterUrl,
            contentDescription = item.displayTitle,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
            alpha = 0.45f
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.horizontalGradient(listOf(Color.Black.copy(alpha = 0.96f), Color.Black.copy(alpha = 0.72f), Color.Black.copy(alpha = 0.28f)))
            )
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.25f), Color.Transparent, Color.Black))
            )
        )

        LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 40.dp, vertical = 28.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
            item {
                Column(modifier = Modifier.width(620.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (!logoUrl.isNullOrBlank()) {
                        AsyncImage(
                            model = logoUrl,
                            contentDescription = item.displayTitle,
                            contentScale = ContentScale.Fit,
                            alignment = Alignment.CenterStart,
                            modifier = Modifier.widthIn(max = 320.dp).heightIn(max = 84.dp)
                        )
                    } else {
                        Text(item.displayTitle, color = Color.White, fontSize = 36.sp, fontWeight = FontWeight.Black)
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        item.matchPercent?.let { Text("$it% rating", color = Color(0xFF45D478), fontSize = 14.sp, fontWeight = FontWeight.Bold) }
                        item.displayYear?.let { Text(it, color = Color(0xFFB8B8B8), fontSize = 14.sp) }
                        cert?.let {
                            Box(
                                modifier = Modifier
                                    .border(1.dp, Color(0xFF808080), RoundedCornerShape(3.dp))
                                    .padding(horizontal = 6.dp, vertical = 1.dp)
                            ) {
                                Text(it, color = Color(0xFFB8B8B8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        if (item.isMovie) {
                            payload?.runtime?.takeIf { it > 0 }?.let { Text("${it / 60}h ${it % 60}m", color = Color(0xFFB8B8B8), fontSize = 14.sp) }
                        } else {
                            payload?.numberOfSeasons?.let { Text("$it ${if (it == 1) "Season" else "Seasons"}", color = Color(0xFFB8B8B8), fontSize = 14.sp) }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        if (item.isUpcoming && relDate != null) {
                            Button(
                                onClick = { sessionManager.toggleReminder(saved, relDate.time, scheduleNotification = false) },
                                colors = ButtonDefaults.colors(containerColor = Color.White, contentColor = Color.Black, focusedContainerColor = accent, focusedContentColor = Color.White),
                                shape = ButtonDefaults.shape(RoundedCornerShape(5.dp)),
                                modifier = Modifier.focusRequester(primaryFocusRequester)
                            ) {
                                Icon(if (reminded) Icons.Default.Notifications else Icons.Default.NotificationsNone, null)
                                Spacer(Modifier.width(6.dp))
                                Text(if (reminded) "Reminder Set" else "Remind Me", fontWeight = FontWeight.Bold)
                            }
                        } else {
                            val targetSeason = if (item.isMovie) null else (savedCw?.season ?: selectedSeason)
                            val targetEp = if (item.isMovie) null else (savedCw?.episode ?: 1)
                            Button(
                                onClick = {
                                    onPlay(
                                        WatchItem(
                                            id = "${item.watchType.rawValue}_${item.id}",
                                            type = item.watchType,
                                            title = item.displayTitle,
                                            tmdbId = item.id.toString(),
                                            season = targetSeason,
                                            episode = targetEp,
                                            posterPath = item.posterPath,
                                            generatedURL = StreamingProviderBuilder.buildUrl(item.watchType, item.id, targetSeason, targetEp, resumeSec?.toInt())
                                        )
                                    )
                                },
                                colors = ButtonDefaults.colors(containerColor = Color.White, contentColor = Color.Black, focusedContainerColor = accent, focusedContentColor = Color.White),
                                shape = ButtonDefaults.shape(RoundedCornerShape(5.dp)),
                                modifier = Modifier.focusRequester(primaryFocusRequester)
                            ) {
                                Icon(Icons.Default.PlayArrow, null)
                                Spacer(Modifier.width(6.dp))
                                Text(playLabel, fontWeight = FontWeight.Bold)
                            }
                        }

                        if (trailer?.watchUrl != null) {
                            Button(
                                onClick = { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(trailer.watchUrl))) },
                                colors = ButtonDefaults.colors(containerColor = Color(0xFF2B2B2B), contentColor = Color.White, focusedContainerColor = Color.White, focusedContentColor = Color.Black),
                                shape = ButtonDefaults.shape(RoundedCornerShape(5.dp))
                            ) {
                                Icon(Icons.Default.PlayArrow, null)
                                Spacer(Modifier.width(6.dp))
                                Text("Trailer", fontWeight = FontWeight.SemiBold)
                            }
                        }

                        Button(
                            onClick = { sessionManager.toggleMyList(saved) },
                            colors = ButtonDefaults.colors(containerColor = Color(0xFF1F1F1F), contentColor = Color.White, focusedContainerColor = Color.White, focusedContentColor = Color.Black),
                            shape = ButtonDefaults.shape(RoundedCornerShape(5.dp))
                        ) {
                            Icon(if (inList) Icons.Default.Check else Icons.Default.Add, null)
                            Spacer(Modifier.width(6.dp))
                            Text("My List", fontWeight = FontWeight.Medium)
                        }

                        Button(
                            onClick = { sessionManager.toggleLike(saved) },
                            colors = ButtonDefaults.colors(containerColor = Color(0xFF1F1F1F), contentColor = if (liked) accent else Color.White, focusedContainerColor = Color.White, focusedContentColor = Color.Black),
                            shape = ButtonDefaults.shape(RoundedCornerShape(5.dp))
                        ) {
                            Icon(if (liked) Icons.Default.ThumbUp else Icons.Default.ThumbUpOffAlt, null)
                            Spacer(Modifier.width(6.dp))
                            Text(if (liked) "Rated" else "Rate", fontWeight = FontWeight.Medium)
                        }

                        Button(
                            onClick = onBack,
                            colors = ButtonDefaults.colors(containerColor = Color(0xFF1F1F1F), contentColor = Color.White, focusedContainerColor = Color.White, focusedContentColor = Color.Black),
                            shape = ButtonDefaults.shape(RoundedCornerShape(5.dp))
                        ) { Text("Back", fontWeight = FontWeight.Medium) }
                    }

                    if (resumeSec != null && savedCw?.progressFraction != null) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            LinearProgressIndicator(
                                progress = { savedCw.progressFraction!!.toFloat() },
                                color = accent,
                                trackColor = Color(0xFF333333),
                                modifier = Modifier.width(220.dp).height(3.dp).clip(CircleShape)
                            )
                            if (!remainingLabel.isNullOrBlank()) {
                                Text(remainingLabel, color = Color(0xFFB8B8B8), fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            }
                        }
                    }

                    Text(item.overview, color = Color.White, fontSize = 14.5.sp, lineHeight = 20.sp, maxLines = 4, overflow = TextOverflow.Ellipsis)

                    if (cast.isNotEmpty()) {
                        Text("Starring: ${cast.take(4).joinToString(", ") { it.name }}", color = Color(0xFFB8B8B8), fontSize = 12.5.sp)
                    }
                    directorOrCreators?.let {
                        Text("${if (item.isMovie) "Directors" else "Creators"}: $it", color = Color(0xFFB8B8B8), fontSize = 12.5.sp)
                    }
                }
            }

            item {
                Column {
                    HorizontalDivider(color = Color.White.copy(alpha = 0.12f))
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                        val tabs = buildList {
                            if (!item.isMovie) add(0 to "Episodes")
                            add(1 to "More Like This")
                            if (videos.isNotEmpty()) add(2 to "Trailers & More")
                        }
                        tabs.forEach { (tabId, label) ->
                            val isSelected = activeTab == tabId
                            Surface(
                                onClick = { activeTab = tabId },
                                colors = ClickableSurfaceDefaults.colors(containerColor = Color.Transparent, focusedContainerColor = Color.White.copy(alpha = 0.10f)),
                                border = ClickableSurfaceDefaults.border(focusedBorder = Border(BorderStroke(2.dp, accent))),
                                shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(4.dp))
                            ) {
                                Column(modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)) {
                                    Box(Modifier.width(72.dp).height(3.dp).background(if (isSelected) accent else Color.Transparent))
                                    Spacer(Modifier.height(6.dp))
                                    Text(label, color = if (isSelected) Color.White else Color(0xFF808080), fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            if (activeTab == 0 && !item.isMovie) {
                val seasons = payload?.seasons?.filter { it.seasonNumber > 0 }.orEmpty()
                if (seasons.isNotEmpty()) {
                    item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(seasons) { s ->
                                Button(
                                    onClick = { selectedSeason = s.seasonNumber },
                                    colors = ButtonDefaults.colors(
                                        containerColor = if (selectedSeason == s.seasonNumber) accent else Color(0xFF2B2B2B),
                                        contentColor = Color.White,
                                        focusedContainerColor = Color.White,
                                        focusedContentColor = Color.Black
                                    ),
                                    shape = ButtonDefaults.shape(RoundedCornerShape(5.dp))
                                ) { Text(s.name.ifBlank { "Season ${s.seasonNumber}" }) }
                            }
                        }
                    }
                }
                if (episodes.isNotEmpty()) {
                    item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            itemsIndexed(episodes) { _, ep ->
                                val aired = ep.hasAired
                                Surface(
                                    onClick = {
                                        if (aired) {
                                            onPlay(WatchItem(id = "tv_${item.id}_s${selectedSeason}_e${ep.episodeNumber}", type = WatchType.TV, title = item.displayTitle, tmdbId = item.id.toString(), season = selectedSeason, episode = ep.episodeNumber, episodeName = ep.name, posterPath = item.posterPath, generatedURL = StreamingProviderBuilder.buildUrl(WatchType.TV, item.id, selectedSeason, ep.episodeNumber)))
                                        }
                                    },
                                    scale = ClickableSurfaceDefaults.scale(focusedScale = 1.05f),
                                    border = ClickableSurfaceDefaults.border(focusedBorder = Border(BorderStroke(2.5.dp, accent))),
                                    shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(6.dp)),
                                    colors = ClickableSurfaceDefaults.colors(containerColor = Color(0xFF1C1C1C)),
                                    modifier = Modifier.width(240.dp).alpha(if (aired) 1f else 0.55f)
                                ) {
                                    Column(Modifier.padding(10.dp)) {
                                        AsyncImage(model = ep.stillUrl ?: item.backdropUrl, contentDescription = ep.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().height(120.dp).clip(RoundedCornerShape(4.dp)))
                                        Spacer(Modifier.height(6.dp))
                                        Text("${ep.episodeNumber}. ${ep.name.ifBlank { "Episode ${ep.episodeNumber}" }}", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        if (!aired && !ep.airDate.isNullOrBlank()) {
                                            Text("Coming ${ep.airDate}", color = accent, fontSize = 11.sp)
                                        } else if (ep.overview.isNotBlank()) {
                                            Text(ep.overview, color = Color(0xFFB8B8B8), fontSize = 11.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else if (activeTab == 1 && related.isNotEmpty()) {
                item { TvMediaRow("More Like This", related, accent, onOpenRelated) }
            } else if (activeTab == 2 && videos.isNotEmpty()) {
                item {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                        items(videos, key = { it.id }) { vid ->
                            Surface(
                                onClick = { vid.watchUrl?.let { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(it))) } },
                                scale = ClickableSurfaceDefaults.scale(focusedScale = 1.05f),
                                border = ClickableSurfaceDefaults.border(focusedBorder = Border(BorderStroke(2.5.dp, accent))),
                                shape = ClickableSurfaceDefaults.shape(RoundedCornerShape(6.dp)),
                                colors = ClickableSurfaceDefaults.colors(containerColor = Color(0xFF1C1C1C)),
                                modifier = Modifier.width(240.dp)
                            ) {
                                Column(Modifier.padding(10.dp)) {
                                    AsyncImage(model = vid.thumbnailUrl, contentDescription = vid.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxWidth().height(124.dp).clip(RoundedCornerShape(4.dp)))
                                    Spacer(Modifier.height(6.dp))
                                    Text(vid.name, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text(vid.type, color = Color(0xFF808080), fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
