-keep class com.singularity.tv.tv.TvMainActivity { *; }
-keep class com.singularity.tv.core.data.ReminderReceiver { *; }
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
-keepattributes *Annotation*,InnerClasses,Signature
-keepclassmembers class kotlinx.serialization.** { *; }
-keepclassmembers class com.singularity.tv.core.model.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
