import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const BOT_TOKEN = Deno.env.get("TELEGRAM_BOT_TOKEN") || "";
const SUPABASE_URL = Deno.env.get("SUPABASE_URL") || "https://soufctreejgcpvqftxeb.supabase.co";
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
const ADMIN_ID = Deno.env.get("ADMIN_TELEGRAM_ID") || "6798616395";
const CHANNEL_ID = Deno.env.get("CHANNEL_TELEGRAM_ID") || "-1004347079304";
const CHANNEL_URL = Deno.env.get("CHANNEL_INVITE_URL") || "https://t.me/+IUpscNRqcqc4Y2Zk";

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS"
};

const VALID_MEMBER_STATUSES = new Set(["creator", "administrator", "member", "restricted"]);

type QueuedFile = { file_id: string; file_name: string };

type BotState = {
  files: QueuedFile[];
  otaFiles: QueuedFile[];
  lastMessageIds: number[];
  draftRelease: { version: string; changelog: string; files: QueuedFile[]; caption: string } | null;
  draftOta: { ota_version: string; notes: string; files: QueuedFile[] } | null;
};

type OtaManifest = {
  ota_version: string;
  min_app_version: string;
  notes: string;
  has_bundle: boolean;
  has_css: boolean;
  bundle_sha256?: string;
  css_sha256?: string;
  player_config: {
    embedMovieTemplate: string;
    embedTvTemplate: string;
    embedAnimeTemplate: string;
    cachingMs: number;
  };
  updated_at: string;
};

const DEFAULT_OTA_MANIFEST: OtaManifest = {
  ota_version: "",
  min_app_version: "1.1.3",
  notes: "",
  has_bundle: false,
  has_css: false,
  player_config: {
    embedMovieTemplate: "https://vidy.st/movie/{TMDBID}?color=DC2626&autoplay=true",
    embedTvTemplate: "https://vidy.st/tv/{TMDBID}/{SEASON}/{EPISODE}?color=DC2626&autoplay=true",
    embedAnimeTemplate: "https://vidy.st/anime/{TMDBID}/{EPISODE}?color=DC2626&autoplay=true",
    cachingMs: 700
  },
  updated_at: ""
};

const PLAYER_PREF_KEYS = [
  "subtitleLang",
  "subTextSize",
  "subTextColor",
  "subBgStyle",
  "subBottomOffset",
  "subtitleTextColor",
  "subtitleBgStyle",
  "subtitleFontSizeSp",
  "subtitleDelayMs",
  "subtitlePosition",
  "playerSource",
  "hianimeDubMode",
  "introSkipMode",
  "autoplayNextEnabled",
  "autoplayNextDuration",
  "autoplayNextLayout",
  "webPlayerPrefs",
  "seriesPrefs",
  "accentInPlayer",
  "preferNativeExoPlayer"
];

function normalizeProfileBucketOrder(bucket: Record<string, any>): Record<string, any> {
  const out: Record<string, any> = { ...bucket };
  if (out.saved && typeof out.saved === "object" && !Array.isArray(out.saved)) {
    const entries = Object.entries(out.saved as Record<string, any>);
    const existingOrder = Array.isArray(out.savedOrder) ? out.savedOrder.map(String) : [];
    const orderIndex = new Map<string, number>();
    existingOrder.forEach((k, idx) => orderIndex.set(k, idx));
    entries.sort(([ka, va], [kb, vb]) => {
      const ta = Number((va as any)?.dateAdded ?? 0);
      const tb = Number((vb as any)?.dateAdded ?? 0);
      if (ta > 0 && tb > 0 && ta !== tb) return ta - tb;
      const ia = orderIndex.has(ka) ? orderIndex.get(ka)! : Number.MAX_SAFE_INTEGER;
      const ib = orderIndex.has(kb) ? orderIndex.get(kb)! : Number.MAX_SAFE_INTEGER;
      return ia - ib;
    });
    const orderedSaved: Record<string, any> = {};
    const orderedKeys: string[] = [];
    for (const [k, v] of entries) {
      orderedSaved[k] = v;
      orderedKeys.push(k);
    }
    out.saved = orderedSaved;
    out.savedOrder = orderedKeys;
  }
  if (Array.isArray(out.history)) {
    out.history = [...out.history].sort((a: any, b: any) => Number(a?.watchedAt ?? 0) - Number(b?.watchedAt ?? 0));
  }
  return out;
}

function extractPlayerPrefsFromSource(src: Record<string, any> = {}): Record<string, any> {
  const out: Record<string, any> = {};
  if (src.playerPrefs && typeof src.playerPrefs === "object") {
    for (const [k, v] of Object.entries(src.playerPrefs)) {
      if (v !== undefined) out[k] = v;
    }
  }
  for (const k of PLAYER_PREF_KEYS) {
    if (src[k] !== undefined) out[k] = src[k];
  }
  return out;
}

async function sha256Hex(text: string): Promise<string> {
  const bytes = new TextEncoder().encode(text);
  const hash = await crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(hash)).map(b => b.toString(16).padStart(2, "0")).join("");
}

function escapeHtml(s: string): string {
  return String(s || "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}

function formatReleaseCaption(version: string, changelog: string): string {
  const cleanLog = escapeHtml(changelog.trim() || "New SingularityTV update available!");
  return `<b>🚀 SingularityTV v${escapeHtml(version)}</b>

<b>What's New:</b>
<pre><code>${cleanLog}</code></pre>

<i>Download and install the latest build for your device below.</i>`;
}

async function tgCall(method: string, payload: Record<string, unknown>) {
  const res = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/${method}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  return res.json().catch(() => ({ ok: false }));
}

async function downloadTelegramFileText(fileId: string): Promise<string | null> {
  const info = await tgCall("getFile", { file_id: fileId });
  const fp = info?.result?.file_path;
  if (!fp) return null;
  const res = await fetch(`https://api.telegram.org/file/bot${BOT_TOKEN}/${fp}`);
  if (!res.ok) return null;
  return await res.text();
}

async function isChannelMember(telegramUserId: number | string): Promise<boolean> {
  if (!BOT_TOKEN || !telegramUserId) return false;
  const res = await tgCall("getChatMember", {
    chat_id: CHANNEL_ID,
    user_id: Number(telegramUserId)
  });
  if (!res?.ok || !res?.result?.status) return false;
  return VALID_MEMBER_STATUSES.has(String(res.result.status));
}

function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS_HEADERS, "Content-Type": "application/json" }
  });
}

async function getBotState(supabase: ReturnType<typeof createClient>): Promise<BotState> {
  const { data } = await supabase.from("app_releases").select("changelog").eq("id", 2).maybeSingle();
  const empty: BotState = { files: [], otaFiles: [], lastMessageIds: [], draftRelease: null, draftOta: null };
  if (!data?.changelog) return empty;
  try {
    const parsed = JSON.parse(data.changelog);
    if (Array.isArray(parsed)) {
      return { ...empty, files: parsed };
    }
    return {
      files: Array.isArray(parsed.files) ? parsed.files : [],
      otaFiles: Array.isArray(parsed.otaFiles) ? parsed.otaFiles : [],
      lastMessageIds: Array.isArray(parsed.lastMessageIds) ? parsed.lastMessageIds : [],
      draftRelease: parsed.draftRelease || null,
      draftOta: parsed.draftOta || null
    };
  } catch {
    return empty;
  }
}

async function saveBotState(supabase: ReturnType<typeof createClient>, state: BotState) {
  await supabase.from("app_releases").upsert(
    {
      id: 2,
      latest_version: "state",
      min_required_version: "state",
      force_update: false,
      changelog: JSON.stringify(state),
      channel_url: CHANNEL_URL,
      update_post_url: CHANNEL_URL,
      updated_at: new Date().toISOString()
    },
    { onConflict: "id" }
  );
}

async function getOtaManifest(supabase: ReturnType<typeof createClient>): Promise<OtaManifest> {
  const { data } = await supabase.from("app_releases").select("changelog").eq("id", 3).maybeSingle();
  if (!data?.changelog) return { ...DEFAULT_OTA_MANIFEST };
  try {
    const parsed = JSON.parse(data.changelog);
    return {
      ...DEFAULT_OTA_MANIFEST,
      ...parsed,
      player_config: {
        ...DEFAULT_OTA_MANIFEST.player_config,
        ...(parsed?.player_config || {})
      }
    };
  } catch {
    return { ...DEFAULT_OTA_MANIFEST };
  }
}

async function saveOtaManifest(supabase: ReturnType<typeof createClient>, manifest: OtaManifest) {
  await supabase.from("app_releases").upsert(
    {
      id: 3,
      latest_version: manifest.ota_version || "ota",
      min_required_version: manifest.min_app_version || "1.1.3",
      force_update: false,
      changelog: JSON.stringify(manifest),
      channel_url: CHANNEL_URL,
      update_post_url: CHANNEL_URL,
      updated_at: new Date().toISOString()
    },
    { onConflict: "id" }
  );
}

async function saveOtaAsset(supabase: ReturnType<typeof createClient>, rowId: number, label: string, content: string) {
  await supabase.from("app_releases").upsert(
    {
      id: rowId,
      latest_version: label,
      min_required_version: label,
      force_update: false,
      changelog: content,
      channel_url: CHANNEL_URL,
      update_post_url: CHANNEL_URL,
      updated_at: new Date().toISOString()
    },
    { onConflict: "id" }
  );
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: CORS_HEADERS });
  }

  const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);
  const url = new URL(req.url);
  const qAction = url.searchParams.get("action") || "";

  if (qAction === "ota_manifest") {
    const manifest = await getOtaManifest(supabase);
    return jsonResponse(manifest);
  }

  const PROFILE_KEYS = ["saved", "savedOrder", "history", "continueWatching", "liked", "reminders", "progress", "watched", "_dlTimes", "_progressTs", "_watchedTs", "_savedTs", "_historyDeletedTs", "_livePlayback", "playerPrefs", "_playerPrefsTs", "subtitleStyle", "profilePlayerPrefs"];

  function sanitizeProfilesList(rawList: any[], fallbackName: string, serverNow: number): { list: any[]; changed: boolean } {
    let changed = false;
    const seen = new Set<string>();
    const out: any[] = [];
    for (const item of (Array.isArray(rawList) ? rawList : [])) {
      if (!item || typeof item !== "object") { changed = true; continue; }
      const pid = String(item.id || "").trim();
      if (!pid || seen.has(pid)) { changed = true; continue; }
      seen.add(pid);
      const cleanName = String(item.name || "Profile").trim().slice(0, 24) || "Profile";
      if (cleanName !== item.name) changed = true;
      out.push({
        id: pid,
        name: cleanName,
        avatarColor: String(item.avatarColor || "#E50914"),
        isKids: !!item.isKids,
        createdAt: Number(item.createdAt || serverNow)
      });
      if (out.length >= 5) break;
    }
    if (out.length === 0) {
      out.push({
        id: "prof_main",
        name: fallbackName || "Main",
        avatarColor: "#E50914",
        isKids: false,
        createdAt: serverNow
      });
      changed = true;
    }
    return { list: out, changed };
  }

  function ensureProfilesMigrated(curData: Record<string, any>, fallbackName: string, serverNow: number): boolean {
    let changed = false;
    const sanitized = sanitizeProfilesList(curData.profiles, fallbackName, serverNow);
    if (sanitized.changed) {
      curData.profiles = sanitized.list;
      changed = true;
    }
    if (!curData.profileData || typeof curData.profileData !== "object") {
      curData.profileData = {};
      changed = true;
    }
    const firstId = String(curData.profiles[0].id || "prof_main");
    if (!curData.profileData[firstId] || typeof curData.profileData[firstId] !== "object") {
      const migrated: Record<string, any> = {};
      for (const k of PROFILE_KEYS) {
        if (curData[k] !== undefined) migrated[k] = curData[k];
      }
      migrated.playerPrefs = extractPlayerPrefsFromSource(curData);
      curData.profileData[firstId] = migrated;
      changed = true;
    } else if (!curData.profileData[firstId].playerPrefs || typeof curData.profileData[firstId].playerPrefs !== "object") {
      curData.profileData[firstId].playerPrefs = extractPlayerPrefsFromSource({ ...curData, ...curData.profileData[firstId] });
      changed = true;
    }
    return changed;
  }

  if (qAction === "sync_pull") {
    const authHeader = req.headers.get("Authorization") || "";
    const token = authHeader.replace(/^Bearer\s+/i, "").trim();
    if (!token) return jsonResponse({ error: "Unauthorized" }, 401);
    const { data: userRes, error: userErr } = await supabase.auth.getUser(token);
    if (userErr || !userRes?.user) return jsonResponse({ error: "Invalid session" }, 401);
    const { data: syncRow, error: syncErr } = await supabase.from("user_sync").select("data, updated_at").eq("user_id", userRes.user.id).maybeSingle();
    if (syncErr) {
      return jsonResponse({ error: "Database query failed while loading sync data." }, 500);
    }
    const serverNow = Date.now();
    if (!syncRow) {
      return jsonResponse({ exists: false, data: null, serverNow });
    }
    if (syncRow.data === null || syncRow.data === undefined) {
      return jsonResponse({ exists: true, data: null, serverNow });
    }
    if (typeof syncRow.data !== "object" || Array.isArray(syncRow.data)) {
      return jsonResponse({ error: "Corrupted cloud sync payload." }, 422);
    }
    const curData = { ...syncRow.data };
    const fallbackName = String(userRes.user.user_metadata?.name || userRes.user.email?.split("@")[0] || "Main");
    if (ensureProfilesMigrated(curData, fallbackName, serverNow)) {
      const { error: migErr } = await supabase.from("user_sync").update({ data: curData, updated_at: new Date(serverNow).toISOString() }).eq("user_id", userRes.user.id);
      if (migErr) {
        return jsonResponse({ error: "Failed to persist migrated profile data." }, 500);
      }
    }
    return jsonResponse({ exists: true, data: curData, serverNow });
  }

  if (qAction === "sync_profile_pull" || qAction === "sync_push") {
    const authHeader = req.headers.get("Authorization") || "";
    const token = authHeader.replace(/^Bearer\s+/i, "").trim();
    if (!token) return jsonResponse({ error: "Unauthorized" }, 401);
    const { data: userRes, error: userErr } = await supabase.auth.getUser(token);
    if (userErr || !userRes?.user) return jsonResponse({ error: "Invalid session" }, 401);
    const userId = userRes.user.id;
    const email = String(userRes.user.email || "");
    const serverNow = Date.now();
    const fallbackName = String(userRes.user.user_metadata?.name || email.split("@")[0] || "Main");

    if (qAction === "sync_profile_pull") {
      const targetPid = String(url.searchParams.get("profileId") || "").trim();
      const { data: syncRow, error: syncErr } = await supabase.from("user_sync").select("data, updated_at").eq("user_id", userId).maybeSingle();
      if (syncErr) return jsonResponse({ error: "Database query failed while loading profile data." }, 500);
      const curData: Record<string, any> = (syncRow?.data && typeof syncRow.data === "object" && !Array.isArray(syncRow.data)) ? { ...syncRow.data } : {};
      const migrated = ensureProfilesMigrated(curData, fallbackName, serverNow);
      if (migrated && syncRow) {
        await supabase.from("user_sync").update({ data: curData, updated_at: new Date(serverNow).toISOString() }).eq("user_id", userId);
      }
      const profiles = Array.isArray(curData.profiles) ? curData.profiles : [];
      const pid = targetPid || String(profiles[0]?.id || "prof_main");
      const matchedProfile = profiles.find((p: any) => String(p.id) === pid);
      if (!matchedProfile) {
        return jsonResponse({ error: "Profile not found for this account.", profiles }, 404);
      }
      const profileMap = (curData.profileData && typeof curData.profileData === "object") ? curData.profileData : {};
      const rawBucket = (profileMap[pid] && typeof profileMap[pid] === "object") ? profileMap[pid] : {};
      const bucket = normalizeProfileBucketOrder(rawBucket);
      return jsonResponse({
        ok: true,
        profile: matchedProfile,
        profileId: pid,
        profileData: bucket,
        profiles,
        _profilesTs: Number(curData._profilesTs || 0),
        serverNow
      });
    }

    if (qAction === "sync_push") {
      const reqBody = await req.json().catch(() => ({}));
      const incoming = (reqBody?.data && typeof reqBody.data === "object") ? reqBody.data : reqBody;
      if (!incoming || typeof incoming !== "object" || Array.isArray(incoming)) {
        return jsonResponse({ error: "Invalid sync payload." }, 400);
      }
      const { data: syncRow, error: syncReadErr } = await supabase.from("user_sync").select("data").eq("user_id", userId).maybeSingle();
      if (syncReadErr) return jsonResponse({ error: "Failed to read existing sync state." }, 500);
      const curData: Record<string, any> = (syncRow?.data && typeof syncRow.data === "object" && !Array.isArray(syncRow.data)) ? { ...syncRow.data } : {};
      ensureProfilesMigrated(curData, fallbackName, serverNow);

      const inProfilesTs = Number(incoming._profilesTs || 0);
      const curProfilesTs = Number(curData._profilesTs || 0);
      if (Array.isArray(incoming.profiles) && incoming.profiles.length > 0 && inProfilesTs >= curProfilesTs) {
        const sanitized = sanitizeProfilesList(incoming.profiles, fallbackName, serverNow);
        curData.profiles = sanitized.list;
        curData._profilesTs = inProfilesTs || serverNow;
      }

      const curMap = (curData.profileData && typeof curData.profileData === "object") ? { ...curData.profileData } : {};
      const inMap = (incoming.profileData && typeof incoming.profileData === "object") ? incoming.profileData : {};
      for (const [pid, rawInBucket] of Object.entries(inMap)) {
        if (!rawInBucket || typeof rawInBucket !== "object") continue;
        const inBucket = rawInBucket as Record<string, any>;
        const existingBucket = (curMap[pid] && typeof curMap[pid] === "object") ? { ...curMap[pid] } : {};
        const inTs = Number(inBucket._playerPrefsTs || inBucket.updatedAt || 0);
        const curTs = Number(existingBucket._playerPrefsTs || existingBucket.updatedAt || 0);
        if (inTs >= curTs || Object.keys(existingBucket).length === 0) {
          curMap[pid] = normalizeProfileBucketOrder({ ...existingBucket, ...inBucket, _playerPrefsTs: inTs || serverNow });
        }
      }
      curData.profileData = curMap;
      curData.schemaVersion = 2;

      const { error: upsertErr } = await supabase.from("user_sync").upsert(
        {
          user_id: userId,
          email,
          data: curData,
          updated_at: new Date(serverNow).toISOString()
        },
        { onConflict: "user_id" }
      );
      if (upsertErr) return jsonResponse({ error: "Failed to persist sync payload." }, 500);
      return jsonResponse({ ok: true, serverNow });
    }
  }

  if (qAction === "ota_file") {
    const file = url.searchParams.get("file") || "";
    const rowId = file === "bundle.js" ? 4 : file === "global.css" ? 5 : 0;
    if (!rowId) return new Response("Not found", { status: 404, headers: CORS_HEADERS });
    const { data } = await supabase.from("app_releases").select("changelog").eq("id", rowId).maybeSingle();
    if (!data?.changelog) return new Response("Not found", { status: 404, headers: CORS_HEADERS });
    const ct = file === "bundle.js" ? "application/javascript; charset=utf-8" : "text/css; charset=utf-8";
    return new Response(data.changelog, {
      status: 200,
      headers: { ...CORS_HEADERS, "Content-Type": ct, "Cache-Control": "no-store" }
    });
  }

  const body = await req.json().catch(() => ({}));

  if (body && body.action === "ota_manifest") {
    const manifest = await getOtaManifest(supabase);
    return jsonResponse(manifest);
  }

  if (qAction === "sync_profiles" || (body && body.action === "sync_profiles")) {
    const authHeader = req.headers.get("Authorization") || "";
    const token = authHeader.replace(/^Bearer\s+/i, "").trim();
    if (!token) return jsonResponse({ error: "Unauthorized" }, 401);
    const { data: userRes, error: userErr } = await supabase.auth.getUser(token);
    if (userErr || !userRes?.user) return jsonResponse({ error: "Invalid session" }, 401);
    const userId = userRes.user.id;
    const email = String(userRes.user.email || "");
    const { data: syncRow, error: syncReadErr } = await supabase.from("user_sync").select("data").eq("user_id", userId).maybeSingle();
    if (syncReadErr) return jsonResponse({ error: "Failed to read account profiles." }, 500);
    const curData: Record<string, any> = (syncRow?.data && typeof syncRow.data === "object") ? { ...syncRow.data } : {};
    const serverNow = Date.now();
    const fallbackName = String(userRes.user.user_metadata?.name || email.split("@")[0] || "Main");
    ensureProfilesMigrated(curData, fallbackName, serverNow);
    const op = String(body.op || "");
    const profiles = Array.isArray(curData.profiles) ? [...curData.profiles] : [];
    const profileData = (curData.profileData && typeof curData.profileData === "object") ? { ...curData.profileData } : {};

    if (op === "create") {
      if (profiles.length >= 5) {
        return jsonResponse({ error: "Maximum 5 profiles per account." }, 400);
      }
      let id = String(body.id || "").trim();
      if (!id) {
        id = `prof_${serverNow.toString(36)}_${Math.random().toString(36).slice(2, 6)}`;
      }
      if (profiles.some((p: any) => String(p.id) === id)) {
        return jsonResponse({ error: "Profile ID already exists." }, 409);
      }
      const rawName = String(body.name || "").trim();
      if (!rawName) {
        return jsonResponse({ error: "Profile name is required." }, 400);
      }
      const name = rawName.slice(0, 24);
      const avatarColor = String(body.avatarColor || "#e50914");
      const isKids = !!body.isKids;
      const rawAvatar = typeof body.avatarUrl === "string" ? body.avatarUrl.trim() : "";
      const avatarUrl = (rawAvatar.startsWith("https://") || rawAvatar.startsWith("data:image/")) && rawAvatar.length <= 260000 ? rawAvatar : undefined;
      profiles.push({ id, name, avatarColor, isKids, ...(avatarUrl ? { avatarUrl } : {}), createdAt: serverNow });
      profileData[id] = { playerPrefs: {}, _playerPrefsTs: serverNow };
    } else if (op === "update") {
      const targetId = String(body.id || "");
      const idx = profiles.findIndex((p: any) => String(p.id) === targetId);
      if (idx === -1) return jsonResponse({ error: "Profile not found." }, 404);
      const rawAvatar = body.avatarUrl === null ? null : (typeof body.avatarUrl === "string" ? body.avatarUrl.trim() : undefined);
      const nextAvatar = rawAvatar === null ? undefined : ((rawAvatar && (rawAvatar.startsWith("https://") || rawAvatar.startsWith("data:image/")) && rawAvatar.length <= 260000) ? rawAvatar : profiles[idx].avatarUrl);
      const updatedProfile: Record<string, any> = {
        ...profiles[idx],
        name: String(body.name || profiles[idx].name || "Profile").trim().slice(0, 24) || "Profile",
        avatarColor: String(body.avatarColor || profiles[idx].avatarColor || "#e50914"),
        isKids: body.isKids !== undefined ? !!body.isKids : !!profiles[idx].isKids
      };
      if (nextAvatar) updatedProfile.avatarUrl = nextAvatar; else delete updatedProfile.avatarUrl;
      profiles[idx] = updatedProfile;
    } else if (op === "save_prefs") {
      const targetId = String(body.profileId || body.id || "");
      if (!targetId) return jsonResponse({ error: "Missing profileId." }, 400);
      const bucket: Record<string, any> = (profileData[targetId] && typeof profileData[targetId] === "object") ? { ...profileData[targetId] } : {};
      const incomingPrefs = (body.playerPrefs && typeof body.playerPrefs === "object") ? body.playerPrefs : {};
      bucket.playerPrefs = { ...(bucket.playerPrefs || {}), ...incomingPrefs };
      bucket._playerPrefsTs = Number(body.updatedAt || serverNow);
      profileData[targetId] = bucket;
    } else if (op === "delete") {
      if (profiles.length <= 1) {
        return jsonResponse({ error: "Cannot delete the last profile." }, 400);
      }
      const targetId = String(body.id || "").trim();
      if (!targetId || !profiles.some((p: any) => String(p.id) === targetId)) {
        return jsonResponse({ error: "Profile not found." }, 404);
      }
      const filtered = profiles.filter((p: any) => String(p.id) !== targetId);
      profiles.length = 0;
      profiles.push(...filtered);
      delete profileData[targetId];
    }

    curData.profiles = profiles;
    curData.profileData = profileData;
    curData._profilesTs = serverNow;
    const { error: upsertErr } = await supabase.from("user_sync").upsert(
      {
        user_id: userId,
        email,
        data: curData,
        updated_at: new Date(serverNow).toISOString()
      },
      { onConflict: "user_id" }
    );
    if (upsertErr) {
      return jsonResponse({ error: "Failed to save profile changes." }, 500);
    }
    return jsonResponse({ ok: true, profiles, profileData, serverNow });
  }

  if (qAction === "sync_progress" || (body && body.action === "sync_progress")) {
    const authHeader = req.headers.get("Authorization") || "";
    const token = authHeader.replace(/^Bearer\s+/i, "").trim();
    if (!token) return jsonResponse({ error: "Unauthorized" }, 401);
    const { data: userRes, error: userErr } = await supabase.auth.getUser(token);
    if (userErr || !userRes?.user) return jsonResponse({ error: "Invalid session" }, 401);
    const userId = userRes.user.id;
    const email = String(userRes.user.email || "");
    const { data: syncRow, error: syncReadErr } = await supabase.from("user_sync").select("data").eq("user_id", userId).maybeSingle();
    if (syncReadErr) return jsonResponse({ error: "Failed to read account profiles." }, 500);
    const curData: Record<string, any> = (syncRow?.data && typeof syncRow.data === "object") ? { ...syncRow.data } : {};
    const serverNow = Date.now();
    const fallbackName = String(userRes.user.user_metadata?.name || email.split("@")[0] || "Main");
    ensureProfilesMigrated(curData, fallbackName, serverNow);
    const pid = String(body.profileId || curData.profiles[0]?.id || "").trim();
    if (!pid || !curData.profiles.some((p: any) => String(p.id) === pid)) {
      return jsonResponse({ error: "Target profile not found for this account." }, 404);
    }
    const profileMap = (curData.profileData && typeof curData.profileData === "object") ? { ...curData.profileData } : {};
    const targetBucket: Record<string, any> = (profileMap[pid] && typeof profileMap[pid] === "object") ? { ...profileMap[pid] } : {};

    const pk = String(body.progressKey || "");
    const pct = Math.min(100, Math.max(1, Math.round(Number(body.percent || 1))));
    const posSec = Math.max(0, Math.floor(Number(body.positionSec || 0)));
    const durSec = Math.max(0, Math.floor(Number(body.durationSec || 0)));
    const watchedFlag = !!body.watched;
    const playingNow = body.isPlaying !== false && !watchedFlag;

    if (pk) {
      const prog = (targetBucket.progress && typeof targetBucket.progress === "object") ? { ...targetBucket.progress } : {};
      const progTs = (targetBucket._progressTs && typeof targetBucket._progressTs === "object") ? { ...targetBucket._progressTs } : {};
      const dlTimes = (targetBucket._dlTimes && typeof targetBucket._dlTimes === "object") ? { ...targetBucket._dlTimes } : {};
      const watchedMap = (targetBucket.watched && typeof targetBucket.watched === "object") ? { ...targetBucket.watched } : {};
      const watchedTs = (targetBucket._watchedTs && typeof targetBucket._watchedTs === "object") ? { ...targetBucket._watchedTs } : {};
      const dlKey = "dlTime_" + pk;

      if (durSec > 0 || watchedFlag) {
        const prevPct = Number(prog[pk] || 0);
        const prevSec = Number(dlTimes[dlKey] || 0);
        const isValidPos = posSec > 0 || watchedFlag;
        const nextPos = isValidPos ? Math.max(posSec, prevSec > 0 && posSec === 0 && !watchedFlag ? prevSec : posSec) : prevSec;
        const nextPct = watchedFlag ? 100 : Math.max(pct, prevPct > 0 && pct <= 1 && prevSec > 5 ? prevPct : pct);

        prog[pk] = nextPct;
        progTs[pk] = serverNow;
        if (nextPos > 0) dlTimes[dlKey] = nextPos;
        if (watchedFlag) {
          watchedMap[pk] = true;
          watchedTs[pk] = serverNow;
        } else if (nextPct < 92) {
          delete watchedMap[pk];
          watchedTs[pk] = serverNow;
        }
        targetBucket.progress = prog;
        targetBucket._progressTs = progTs;
        targetBucket._dlTimes = dlTimes;
        targetBucket.watched = watchedMap;
        targetBucket._watchedTs = watchedTs;
      }

      if (body.playerPrefs && typeof body.playerPrefs === "object") {
        targetBucket.playerPrefs = { ...(targetBucket.playerPrefs || {}), ...body.playerPrefs };
        targetBucket._playerPrefsTs = serverNow;
      }

      targetBucket._livePlayback = {
        progressKey: pk,
        profileId: pid,
        percent: pct,
        positionSec: posSec,
        durationSec: durSec,
        isPlaying: playingNow,
        deviceId: String(body.deviceId || ""),
        deviceName: String(body.deviceName || "Another Device"),
        updatedAt: serverNow
      };
      profileMap[pid] = targetBucket;
      curData.profileData = profileMap;
    }

    const { error: progUpsertErr } = await supabase.from("user_sync").upsert(
      {
        user_id: userId,
        email,
        data: curData,
        updated_at: new Date(serverNow).toISOString()
      },
      { onConflict: "user_id" }
    );
    if (progUpsertErr) {
      return jsonResponse({ error: "Failed to save playback progress." }, 500);
    }
    return jsonResponse({ ok: true, serverNow });
  }

  if (body && body.action === "check") {
    const authHeader = req.headers.get("Authorization") || "";
    const token = authHeader.replace(/^Bearer\s+/i, "").trim();
    if (!token) return jsonResponse({ error: "Unauthorized" }, 401);
    const { data: userRes, error: userErr } = await supabase.auth.getUser(token);
    if (userErr || !userRes?.user) return jsonResponse({ error: "Invalid session" }, 401);
    const userId = userRes.user.id;
    const { data: releaseRow } = await supabase.from("app_releases").select("*").eq("id", 1).maybeSingle();
    const { data: syncRow } = await supabase.from("user_sync").select("telegram_user_id, telegram_verified").eq("user_id", userId).maybeSingle();
    const tgId = syncRow?.telegram_user_id || null;
    if (!tgId) {
      return jsonResponse({
        member: false,
        linked: false,
        leftChannel: false,
        channelUrl: releaseRow?.channel_url || CHANNEL_URL,
        release: releaseRow || null
      });
    }
    const stillMember = await isChannelMember(tgId);
    if (stillMember !== Boolean(syncRow?.telegram_verified)) {
      await supabase.from("user_sync").update({ telegram_verified: stillMember }).eq("user_id", userId);
    }
    return jsonResponse({
      member: stillMember,
      linked: true,
      leftChannel: !stillMember,
      channelUrl: releaseRow?.channel_url || CHANNEL_URL,
      release: releaseRow || null
    });
  }

  const cb = body?.callback_query;
  if (cb) {
    const cbFrom = String(cb.from?.id || "");
    const cbChatId = cb.message?.chat?.id;
    const cbMsgId = cb.message?.message_id;
    const cbData = String(cb.data || "");
    await tgCall("answerCallbackQuery", { callback_query_id: cb.id });
    if (cbFrom !== ADMIN_ID) return jsonResponse({ ok: true });

    const state = await getBotState(supabase);

    if (cbData === "cb_cancel_release") {
      state.draftRelease = null;
      await saveBotState(supabase, state);
      await tgCall("editMessageText", {
        chat_id: cbChatId,
        message_id: cbMsgId,
        text: "❌ Release publish cancelled. Queued files are still kept (use /clear to reset)."
      });
      return jsonResponse({ ok: true });
    }

    if (cbData === "cb_publish_release") {
      const draft = state.draftRelease;
      if (!draft) {
        await tgCall("editMessageText", { chat_id: cbChatId, message_id: cbMsgId, text: "⚠️ No pending release draft found." });
        return jsonResponse({ ok: true });
      }
      const prevIds = [...state.lastMessageIds];
      const newIds: number[] = [];
      const filesToSend = draft.files || [];

      if (filesToSend.length >= 2) {
        const media = filesToSend.slice(0, 10).map((f, idx, arr) => ({
          type: "document",
          media: f.file_id,
          ...(idx === arr.length - 1 ? { caption: draft.caption, parse_mode: "HTML" } : {})
        }));
        const mgRes = await tgCall("sendMediaGroup", { chat_id: CHANNEL_ID, media });
        if (mgRes?.ok && Array.isArray(mgRes.result)) {
          for (const m of mgRes.result) {
            if (m?.message_id) newIds.push(Number(m.message_id));
          }
        } else {
          const tRes = await tgCall("sendMessage", { chat_id: CHANNEL_ID, text: draft.caption, parse_mode: "HTML" });
          if (tRes?.result?.message_id) newIds.push(Number(tRes.result.message_id));
          for (const f of filesToSend) {
            const dRes = await tgCall("sendDocument", { chat_id: CHANNEL_ID, document: f.file_id });
            if (dRes?.result?.message_id) newIds.push(Number(dRes.result.message_id));
          }
        }
      } else if (filesToSend.length === 1) {
        const dRes = await tgCall("sendDocument", {
          chat_id: CHANNEL_ID,
          document: filesToSend[0].file_id,
          caption: draft.caption,
          parse_mode: "HTML"
        });
        if (dRes?.result?.message_id) newIds.push(Number(dRes.result.message_id));
      } else {
        const tRes = await tgCall("sendMessage", { chat_id: CHANNEL_ID, text: draft.caption, parse_mode: "HTML" });
        if (tRes?.result?.message_id) newIds.push(Number(tRes.result.message_id));
      }

      let deletedCount = 0;
      for (const oldId of prevIds) {
        const delRes = await tgCall("deleteMessage", { chat_id: CHANNEL_ID, message_id: oldId });
        if (delRes?.ok) deletedCount++;
      }

      state.files = [];
      state.draftRelease = null;
      state.lastMessageIds = newIds;
      await saveBotState(supabase, state);

      await supabase.from("app_releases").upsert(
        {
          id: 1,
          latest_version: draft.version,
          min_required_version: draft.version,
          force_update: true,
          changelog: draft.changelog,
          channel_url: CHANNEL_URL,
          update_post_url: CHANNEL_URL,
          updated_at: new Date().toISOString()
        },
        { onConflict: "id" }
      );

      await tgCall("editMessageText", {
        chat_id: cbChatId,
        message_id: cbMsgId,
        parse_mode: "HTML",
        text: `✅ <b>Published SingularityTV v${escapeHtml(draft.version)}</b>
Files: ${filesToSend.length} · Old posts deleted: ${deletedCount}`
      });
      return jsonResponse({ ok: true });
    }

    if (cbData === "cb_cancel_ota") {
      state.draftOta = null;
      await saveBotState(supabase, state);
      await tgCall("editMessageText", { chat_id: cbChatId, message_id: cbMsgId, text: "❌ OTA hot-update cancelled." });
      return jsonResponse({ ok: true });
    }

    if (cbData === "cb_publish_ota") {
      const draft = state.draftOta;
      if (!draft) {
        await tgCall("editMessageText", { chat_id: cbChatId, message_id: cbMsgId, text: "⚠️ No pending OTA draft found." });
        return jsonResponse({ ok: true });
      }
      const manifest = await getOtaManifest(supabase);
      let updatedBundle = manifest.has_bundle;
      let updatedCss = manifest.has_css;
      for (const f of draft.files) {
        const lower = f.file_name.toLowerCase();
        const content = await downloadTelegramFileText(f.file_id);
        if (!content || content.length < 50) continue;
        if (lower.endsWith(".js")) {
          await saveOtaAsset(supabase, 4, draft.ota_version, content);
          updatedBundle = true;
          manifest.bundle_sha256 = await sha256Hex(content);
        } else if (lower.endsWith(".css")) {
          await saveOtaAsset(supabase, 5, draft.ota_version, content);
          updatedCss = true;
          manifest.css_sha256 = await sha256Hex(content);
        }
      }
      manifest.ota_version = draft.ota_version;
      manifest.notes = draft.notes;
      manifest.has_bundle = updatedBundle;
      manifest.has_css = updatedCss;
      manifest.updated_at = new Date().toISOString();
      await saveOtaManifest(supabase, manifest);

      state.otaFiles = [];
      state.draftOta = null;
      await saveBotState(supabase, state);

      await tgCall("editMessageText", {
        chat_id: cbChatId,
        message_id: cbMsgId,
        parse_mode: "HTML",
        text: `⚡ <b>OTA Hot-Update Live: <code>${escapeHtml(manifest.ota_version)}</code></b>
Bundle JS: ${updatedBundle ? "✅" : "—"} · Global CSS: ${updatedCss ? "✅" : "—"}
All Android, Android TV, and iOS apps will auto-update on next open.`
      });
      return jsonResponse({ ok: true });
    }

    return jsonResponse({ ok: true });
  }

  const msg = body?.message;
  if (!msg) return jsonResponse({ ok: true });

  const chatId = msg.chat?.id;
  const fromId = String(msg.from?.id || "");
  const text = String(msg.text || msg.caption || "").trim();

  if (text.startsWith("/start")) {
    const parts = text.split(/\s+/);
    const param = parts[1] || "";
    if (param.startsWith("verify_")) {
      const userId = param.slice(7).trim();
      if (!userId) {
        await tgCall("sendMessage", { chat_id: chatId, text: "Invalid verification link. Open SingularityTV and tap Verify again." });
        return jsonResponse({ ok: true });
      }
      const joined = await isChannelMember(fromId);
      if (!joined) {
        await tgCall("sendMessage", {
          chat_id: chatId,
          text: `You must join the official SingularityTV channel first:
${CHANNEL_URL}

After joining, tap /start verify_${userId} or return to the app.`
        });
        return jsonResponse({ ok: true });
      }
      const { data: authUser } = await supabase.auth.admin.getUserById(userId);
      const userEmail = authUser?.user?.email || "";
      if (!userEmail) {
        await tgCall("sendMessage", { chat_id: chatId, text: "Account not found. Please sign in to SingularityTV first." });
        return jsonResponse({ ok: true });
      }
      await supabase.from("user_sync").upsert(
        {
          user_id: userId,
          email: userEmail,
          telegram_user_id: Number(fromId),
          telegram_verified: true,
          updated_at: new Date().toISOString()
        },
        { onConflict: "user_id" }
      );
      await tgCall("sendMessage", {
        chat_id: chatId,
        text: "Verified! Your SingularityTV account is unlocked. Return to the app and tap Check Now."
      });
      return jsonResponse({ ok: true });
    }
    if (fromId === ADMIN_ID) {
      await tgCall("sendMessage", {
        chat_id: chatId,
        parse_mode: "HTML",
        text: `<b>⚡ SingularityTV Admin Control</b>

<b>Full App Releases (APK / IPA):</b>
1. Send <code>.apk</code> &amp; <code>.ipa</code> files
2. <code>/release 1.1.5 | Changelog lines</code> (shows preview + confirm, auto-deletes old post)

<b>Instant OTA Hot-Updates (No Reinstall):</b>
1. Send <code>bundle.js</code> and/or <code>global.css</code>
2. <code>/ota 1.1.5-ota1 | Notes</code> (shows preview + confirm)

<b>Live Player Server Config:</b>
<code>/player_config movieTpl | tvTpl | animeTpl</code>

<b>Tools:</b>
<code>/status</code> · <code>/queue</code> · <code>/clear</code> · <code>/force on|off</code>`
      });
      return jsonResponse({ ok: true });
    }
    await tgCall("sendMessage", {
      chat_id: chatId,
      text: `Welcome to SingularityTV Official Bot!

Join our channel: ${CHANNEL_URL}
Then tap Verify inside the SingularityTV app.`
    });
    return jsonResponse({ ok: true });
  }

  if (fromId !== ADMIN_ID) return jsonResponse({ ok: true });

  if (text.startsWith("/help")) {
    await tgCall("sendMessage", {
      chat_id: chatId,
      parse_mode: "HTML",
      text: `<b>⚡ SingularityTV Commands</b>

<code>/status</code> — Live release &amp; OTA status
<code>/queue</code> — View queued files
<code>/clear</code> — Clear queue &amp; drafts
<code>/force on</code> or <code>/force off</code> — Lock old versions
<code>/release 1.1.5 | Changelog</code> — Preview &amp; publish APK/IPA
<code>/ota 1.1.5-ota1 | Notes</code> — Preview &amp; push JS/CSS hot-update
<code>/player_config movie | tv | anime</code> — Live update embed URLs`
    });
    return jsonResponse({ ok: true });
  }

  if (text.startsWith("/clear")) {
    const state = await getBotState(supabase);
    state.files = [];
    state.otaFiles = [];
    state.draftRelease = null;
    state.draftOta = null;
    await saveBotState(supabase, state);
    await tgCall("sendMessage", { chat_id: chatId, text: "🧹 Cleared queued files and drafts." });
    return jsonResponse({ ok: true });
  }

  if (text.startsWith("/queue")) {
    const state = await getBotState(supabase);
    const appList = state.files.length ? state.files.map((f, i) => `${i + 1}. <code>${escapeHtml(f.file_name)}</code>`).join("\n") : "None";
    const otaList = state.otaFiles.length ? state.otaFiles.map((f, i) => `${i + 1}. <code>${escapeHtml(f.file_name)}</code>`).join("\n") : "None";
    await tgCall("sendMessage", {
      chat_id: chatId,
      parse_mode: "HTML",
      text: `<b>📦 Queued App Builds:</b>
${appList}

<b>⚡ Queued OTA Files:</b>
${otaList}`
    });
    return jsonResponse({ ok: true });
  }

  if (text.startsWith("/status")) {
    const { data: rel } = await supabase.from("app_releases").select("*").eq("id", 1).maybeSingle();
    const state = await getBotState(supabase);
    const ota = await getOtaManifest(supabase);
    await tgCall("sendMessage", {
      chat_id: chatId,
      parse_mode: "HTML",
      text: `<b>📊 SingularityTV Live Status</b>

<b>App Release:</b> <code>v${escapeHtml(rel?.latest_version || "1.0.0")}</code> (Force: ${rel?.force_update ? "ON" : "OFF"})
<b>Last Channel Posts:</b> ${state.lastMessageIds.length}
<b>OTA Hot-Update:</b> <code>${escapeHtml(ota.ota_version || "None")}</code> (JS: ${ota.has_bundle ? "✅" : "—"} · CSS: ${ota.has_css ? "✅" : "—"})
<b>Queued Builds:</b> ${state.files.length} · <b>Queued OTA:</b> ${state.otaFiles.length}`
    });
    return jsonResponse({ ok: true });
  }

  if (text.startsWith("/force")) {
    const arg = text.split(/\s+/)[1]?.toLowerCase();
    const enabled = arg !== "off";
    await supabase.from("app_releases").update({ force_update: enabled, updated_at: new Date().toISOString() }).eq("id", 1);
    await tgCall("sendMessage", { chat_id: chatId, text: `Force update is now ${enabled ? "ON" : "OFF"}.` });
    return jsonResponse({ ok: true });
  }

  if (text.startsWith("/player_config")) {
    const raw = text.replace(/^\/player_config\s*/i, "").trim();
    const parts = raw.split("|").map(s => s.trim()).filter(Boolean);
    if (parts.length < 2) {
      await tgCall("sendMessage", {
        chat_id: chatId,
        parse_mode: "HTML",
        text: "Usage:\n<code>/player_config https://vidy.st/movie/{TMDBID}?color=DC2626&amp;autoplay=true | https://vidy.st/tv/{TMDBID}/{SEASON}/{EPISODE}?color=DC2626&amp;autoplay=true</code>"
      });
      return jsonResponse({ ok: true });
    }
    const manifest = await getOtaManifest(supabase);
    manifest.player_config.embedMovieTemplate = parts[0];
    manifest.player_config.embedTvTemplate = parts[1];
    if (parts[2]) manifest.player_config.embedAnimeTemplate = parts[2];
    manifest.updated_at = new Date().toISOString();
    await saveOtaManifest(supabase, manifest);
    await tgCall("sendMessage", {
      chat_id: chatId,
      parse_mode: "HTML",
      text: `✅ <b>Player Config Updated Live!</b>
Movie: <code>${escapeHtml(manifest.player_config.embedMovieTemplate)}</code>
TV: <code>${escapeHtml(manifest.player_config.embedTvTemplate)}</code>`
    });
    return jsonResponse({ ok: true });
  }

  if (msg.document?.file_id && !text.startsWith("/release") && !text.startsWith("/ota")) {
    const fileName = String(msg.document.file_name || "file");
    const lower = fileName.toLowerCase();
    const state = await getBotState(supabase);
    if (lower.endsWith(".js") || lower.endsWith(".css")) {
      state.otaFiles = [...state.otaFiles.filter(f => f.file_name.toLowerCase() !== lower), { file_id: msg.document.file_id, file_name: fileName }];
      await saveBotState(supabase, state);
      const list = state.otaFiles.map((f, i) => `${i + 1}. <code>${escapeHtml(f.file_name)}</code>`).join("\n");
      await tgCall("sendMessage", {
        chat_id: chatId,
        parse_mode: "HTML",
        text: `⚡ <b>Queued for OTA Hot-Update:</b>
${list}

Send <code>/ota 1.1.5-ota1 | Your notes</code> to preview &amp; push live.`
      });
      return jsonResponse({ ok: true });
    }
    state.files = [...state.files.filter(f => f.file_id !== msg.document.file_id), { file_id: msg.document.file_id, file_name: fileName }];
    await saveBotState(supabase, state);
    const listText = state.files.map((f, i) => `${i + 1}. <code>${escapeHtml(f.file_name)}</code>`).join("\n");
    await tgCall("sendMessage", {
      chat_id: chatId,
      parse_mode: "HTML",
      text: `📦 <b>Queued (${state.files.length}):</b>
${listText}

Send <code>/release 1.1.5 | Changelog</code> to preview before publishing.`
    });
    return jsonResponse({ ok: true });
  }

  if (text.startsWith("/ota")) {
    const rawArgs = text.replace(/^\/ota\s*/i, "").trim();
    const [verPart, ...rest] = rawArgs.split("|");
    const otaVersion = (verPart || "").trim();
    const notes = rest.join("|").trim() || "Performance & bug fixes";
    if (!otaVersion) {
      await tgCall("sendMessage", { chat_id: chatId, parse_mode: "HTML", text: "Usage:\n1. Send <code>bundle.js</code> / <code>global.css</code>\n2. <code>/ota 1.1.5-ota1 | Notes</code>" });
      return jsonResponse({ ok: true });
    }
    const state = await getBotState(supabase);
    const files = [...state.otaFiles];
    if (msg.document?.file_id) {
      files.push({ file_id: msg.document.file_id, file_name: String(msg.document.file_name || "bundle.js") });
    }
    if (files.length === 0) {
      await tgCall("sendMessage", { chat_id: chatId, text: "Send bundle.js or global.css first before running /ota." });
      return jsonResponse({ ok: true });
    }
    state.draftOta = { ota_version: otaVersion, notes, files };
    await saveBotState(supabase, state);
    const fList = files.map(f => `• <code>${escapeHtml(f.file_name)}</code>`).join("\n");
    await tgCall("sendMessage", {
      chat_id: chatId,
      parse_mode: "HTML",
      text: `<b>⚡ OTA Hot-Update Preview</b>

Version: <code>${escapeHtml(otaVersion)}</code>
Files:
${fList}

Notes:
<pre><code>${escapeHtml(notes)}</code></pre>`,
      reply_markup: {
        inline_keyboard: [[
          { text: "✅ Push OTA Live", callback_data: "cb_publish_ota" },
          { text: "❌ Cancel", callback_data: "cb_cancel_ota" }
        ]]
      }
    });
    return jsonResponse({ ok: true });
  }

  if (text.startsWith("/release")) {
    const rawArgs = text.replace(/^\/release\s*/i, "").trim();
    const [verPart, ...rest] = rawArgs.split("|");
    const version = (verPart || "").replace(/^v/i, "").trim();
    const changelog = rest.join("|").trim() || "New SingularityTV update available!";
    if (!version) {
      await tgCall("sendMessage", { chat_id: chatId, parse_mode: "HTML", text: "Usage:\n1. Send APK/IPA files\n2. <code>/release 1.1.5 | Changelog</code>" });
      return jsonResponse({ ok: true });
    }
    const state = await getBotState(supabase);
    const filesToSend = [...state.files];
    if (msg.document?.file_id) {
      filesToSend.push({ file_id: msg.document.file_id, file_name: String(msg.document.file_name || "file") });
    }
    const caption = formatReleaseCaption(version, changelog);
    state.draftRelease = { version, changelog, files: filesToSend, caption };
    await saveBotState(supabase, state);

    const fileSummary = filesToSend.length > 0
      ? filesToSend.map(f => `📎 <code>${escapeHtml(f.file_name)}</code>`).join("\n")
      : "<i>No files attached (text-only post)</i>";

    await tgCall("sendMessage", {
      chat_id: chatId,
      parse_mode: "HTML",
      text: `<b>👀 Release Preview (Not Published Yet)</b>

${caption}

<b>Attachments (${filesToSend.length}):</b>
${fileSummary}

<i>Previous channel release (${state.lastMessageIds.length} msg) will be auto-deleted upon publish.</i>`,
      reply_markup: {
        inline_keyboard: [[
          { text: "✅ Publish to Channel", callback_data: "cb_publish_release" },
          { text: "❌ Cancel", callback_data: "cb_cancel_release" }
        ]]
      }
    });
    return jsonResponse({ ok: true });
  }

  return jsonResponse({ ok: true });
});
