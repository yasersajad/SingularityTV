import React, { useState, useEffect } from "react";
import {
  getProfilesList,
  getActiveProfileId,
  switchActiveProfile,
  createProfileOnServer,
  updateProfileOnServer,
  deleteProfileOnServer,
  getAuthUser
} from "../utils/supabaseSync";
import { CloseIcon } from "./Icons";

const AVATAR_COLORS = [
  "#e50914",
  "#2563eb",
  "#16a34a",
  "#d97706",
  "#9333ea",
  "#0891b2",
  "#db2777"
];

export default function ProfilesModal({ onClose, onProfileSwitched }) {
  const [profiles, setProfiles] = useState(() => getProfilesList());
  const [activeId, setActiveId] = useState(() => getActiveProfileId());
  const [manageMode, setManageMode] = useState(false);
  const [editing, setEditing] = useState(null);
  const [nameInput, setNameInput] = useState("");
  const [colorInput, setColorInput] = useState(AVATAR_COLORS[0]);
  const [kidsInput, setKidsInput] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  useEffect(() => {
    const sync = () => {
      setProfiles(getProfilesList());
      setActiveId(getActiveProfileId());
    };
    window.addEventListener("singularity:profile-changed", sync);
    window.addEventListener("singularity:live-sync-updated", sync);
    return () => {
      window.removeEventListener("singularity:profile-changed", sync);
      window.removeEventListener("singularity:live-sync-updated", sync);
    };
  }, []);

  const authUser = getAuthUser();

  const openCreate = () => {
    if (profiles.length >= 5) return;
    setErr("");
    setEditing({ mode: "create" });
    setNameInput("");
    setColorInput(AVATAR_COLORS[profiles.length % AVATAR_COLORS.length]);
    setKidsInput(false);
  };

  const openEdit = p => {
    setErr("");
    setEditing({ mode: "edit", id: p.id });
    setNameInput(p.name || "");
    setColorInput(p.avatarColor || AVATAR_COLORS[0]);
    setKidsInput(!!p.isKids);
  };

  const handleSave = async e => {
    e.preventDefault();
    const clean = nameInput.trim();
    if (!clean) {
      setErr("Please enter a profile name.");
      return;
    }
    setBusy(true);
    setErr("");
    try {
      if (editing.mode === "create") {
        const res = await createProfileOnServer({
          name: clean.slice(0, 24),
          avatarColor: colorInput,
          isKids: kidsInput
        });
        setProfiles(res.profiles);
      } else {
        const res = await updateProfileOnServer({
          id: editing.id,
          name: clean.slice(0, 24),
          avatarColor: colorInput,
          isKids: kidsInput
        });
        setProfiles(res.profiles);
      }
      setEditing(null);
      onProfileSwitched?.();
    } catch (ex) {
      setErr(ex?.message || "Could not save profile.");
    } finally {
      setBusy(false);
    }
  };

  const handleDelete = async id => {
    if (profiles.length <= 1) return;
    setBusy(true);
    setErr("");
    try {
      const res = await deleteProfileOnServer(id);
      setProfiles(res.profiles);
      setActiveId(getActiveProfileId());
      setEditing(null);
      onProfileSwitched?.();
    } catch (ex) {
      setErr(ex?.message || "Could not delete profile.");
    } finally {
      setBusy(false);
    }
  };

  const handleSelectProfile = async p => {
    if (manageMode) {
      openEdit(p);
      return;
    }
    if (p.id === activeId) {
      onClose?.();
      return;
    }
    setBusy(true);
    try {
      await switchActiveProfile(p.id);
      setActiveId(p.id);
      onProfileSwitched?.(p);
      onClose?.();
    } finally {
      setBusy(false);
    }
  };

  return (
    <div
      className="modal-overlay"
      onClick={e => e.target === e.currentTarget && !busy && onClose?.()}
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 9999,
        background: "rgba(6, 8, 14, 0.92)",
        backdropFilter: "blur(14px)",
        WebkitBackdropFilter: "blur(14px)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 20,
        direction: "ltr"
      }}
    >
      <div
        style={{
          width: "100%",
          maxWidth: 680,
          background: "linear-gradient(160deg, rgba(22, 24, 34, 0.98), rgba(12, 13, 20, 0.99))",
          border: "1px solid rgba(255,255,255,0.12)",
          borderRadius: 22,
          padding: "26px 24px",
          boxShadow: "0 24px 64px rgba(0,0,0,0.65)",
          position: "relative"
        }}
      >
        <button
          type="button"
          className="nf-player-btn"
          data-gamepad-close="1"
          onClick={onClose}
          aria-label="Close"
          style={{ position: "absolute", top: 18, right: 18 }}
        >
          <CloseIcon />
        </button>

        {!editing ? (
          <>
            <div style={{ textAlign: "center", marginBottom: 22 }}>
              <div style={{ fontSize: 24, fontWeight: 800, color: "#fff", marginBottom: 6 }}>
                {manageMode ? "Manage Profiles" : "Who's Watching?"}
              </div>
              <div style={{ fontSize: 13, color: "rgba(255,255,255,0.6)" }}>
                {authUser ? `${authUser.email} · ${profiles.length}/5 profiles synced` : `${profiles.length}/5 profiles`}
              </div>
            </div>

            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(110px, 1fr))",
                gap: 14,
                justifyItems: "center",
                marginBottom: 22
              }}
            >
              {profiles.map(p => {
                const isActive = p.id === activeId;
                return (
                  <button
                    key={p.id}
                    type="button"
                    disabled={busy}
                    onClick={() => handleSelectProfile(p)}
                    style={{
                      background: isActive ? "rgba(255,255,255,0.08)" : "rgba(255,255,255,0.03)",
                      border: isActive ? "2px solid #fff" : "1px solid rgba(255,255,255,0.12)",
                      borderRadius: 16,
                      padding: "16px 12px",
                      width: "100%",
                      maxWidth: 136,
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "center",
                      gap: 10,
                      cursor: "pointer",
                      position: "relative"
                    }}
                  >
                    <div
                      style={{
                        width: 62,
                        height: 62,
                        borderRadius: 14,
                        background: p.avatarColor || "#e50914",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontSize: 26,
                        fontWeight: 800,
                        color: "#fff",
                        boxShadow: "0 8px 20px rgba(0,0,0,0.35)"
                      }}
                    >
                      {(p.name || "P").charAt(0).toUpperCase()}
                    </div>
                    <div
                      style={{
                        fontSize: 14,
                        fontWeight: 700,
                        color: "#fff",
                        maxWidth: "100%",
                        overflow: "hidden",
                        textOverflow: "ellipsis",
                        whiteSpace: "nowrap"
                      }}
                    >
                      {p.name}
                    </div>
                    <div style={{ display: "flex", gap: 4, flexWrap: "wrap", justifyContent: "center" }}>
                      {p.isKids && (
                        <span
                          style={{
                            fontSize: 10,
                            fontWeight: 800,
                            background: "#facc15",
                            color: "#000",
                            padding: "2px 7px",
                            borderRadius: 999
                          }}
                        >
                          KIDS
                        </span>
                      )}
                      {isActive && !manageMode && (
                        <span
                          style={{
                            fontSize: 10,
                            fontWeight: 700,
                            background: "rgba(34,197,94,0.22)",
                            color: "#4ade80",
                            padding: "2px 7px",
                            borderRadius: 999
                          }}
                        >
                          ACTIVE
                        </span>
                      )}
                      {manageMode && (
                        <span
                          style={{
                            fontSize: 10,
                            fontWeight: 700,
                            background: "rgba(255,255,255,0.14)",
                            color: "#fff",
                            padding: "2px 7px",
                            borderRadius: 999
                          }}
                        >
                          EDIT
                        </span>
                      )}
                    </div>
                  </button>
                );
              })}

              {profiles.length < 5 && (
                <button
                  type="button"
                  disabled={busy}
                  onClick={openCreate}
                  style={{
                    background: "rgba(255,255,255,0.02)",
                    border: "1px dashed rgba(255,255,255,0.25)",
                    borderRadius: 16,
                    padding: "16px 12px",
                    width: "100%",
                    maxWidth: 136,
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: 10,
                    cursor: "pointer"
                  }}
                >
                  <div
                    style={{
                      width: 62,
                      height: 62,
                      borderRadius: 14,
                      background: "rgba(255,255,255,0.08)",
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontSize: 28,
                      fontWeight: 500,
                      color: "#fff"
                    }}
                  >
                    +
                  </div>
                  <div style={{ fontSize: 13, fontWeight: 700, color: "rgba(255,255,255,0.8)" }}>
                    Add Profile
                  </div>
                </button>
              )}
            </div>

            {err && (
              <div style={{ color: "#f87171", fontSize: 13, textAlign: "center", marginBottom: 12 }}>
                {err}
              </div>
            )}

            <div style={{ display: "flex", justifyContent: "center", gap: 12 }}>
              <button
                type="button"
                className="btn btn-secondary"
                onClick={() => setManageMode(v => !v)}
                style={{ padding: "10px 22px", borderRadius: 999, fontWeight: 700 }}
              >
                {manageMode ? "Done" : "Manage Profiles"}
              </button>
            </div>
          </>
        ) : (
          <form onSubmit={handleSave}>
            <div style={{ fontSize: 20, fontWeight: 800, color: "#fff", marginBottom: 16 }}>
              {editing.mode === "create" ? "Add Profile" : "Edit Profile"}
            </div>

            <div style={{ marginBottom: 14 }}>
              <div style={{ fontSize: 12, color: "rgba(255,255,255,0.65)", marginBottom: 6 }}>
                Profile Name (e.g. TV, iPhone, Kids)
              </div>
              <input
                type="text"
                value={nameInput}
                onChange={e => setNameInput(e.target.value)}
                maxLength={24}
                placeholder="Enter name..."
                autoFocus
                style={{
                  width: "100%",
                  padding: "12px 14px",
                  borderRadius: 12,
                  background: "rgba(255,255,255,0.07)",
                  border: "1px solid rgba(255,255,255,0.18)",
                  color: "#fff",
                  fontSize: 15,
                  outline: "none",
                  boxSizing: "border-box"
                }}
              />
            </div>

            <div style={{ marginBottom: 16 }}>
              <div style={{ fontSize: 12, color: "rgba(255,255,255,0.65)", marginBottom: 8 }}>
                Avatar Color
              </div>
              <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                {AVATAR_COLORS.map(c => (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setColorInput(c)}
                    style={{
                      width: 34,
                      height: 34,
                      borderRadius: 10,
                      background: c,
                      border: colorInput === c ? "3px solid #fff" : "2px solid transparent",
                      cursor: "pointer"
                    }}
                  />
                ))}
              </div>
            </div>

            <label
              style={{
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                padding: "12px 14px",
                borderRadius: 12,
                background: "rgba(255,255,255,0.05)",
                border: "1px solid rgba(255,255,255,0.1)",
                marginBottom: 18,
                cursor: "pointer"
              }}
            >
              <div>
                <div style={{ fontSize: 14, fontWeight: 700, color: "#fff" }}>Kids Profile</div>
                <div style={{ fontSize: 12, color: "rgba(255,255,255,0.6)" }}>
                  Restricts content to family-friendly & kids ratings (G / PG)
                </div>
              </div>
              <input
                type="checkbox"
                checked={kidsInput}
                onChange={e => setKidsInput(e.target.checked)}
                style={{ width: 20, height: 20, accentColor: "#e50914" }}
              />
            </label>

            {err && (
              <div style={{ color: "#f87171", fontSize: 13, marginBottom: 12 }}>{err}</div>
            )}

            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", flexWrap: "wrap" }}>
              {editing.mode === "edit" && profiles.length > 1 && (
                <button
                  type="button"
                  disabled={busy}
                  onClick={() => handleDelete(editing.id)}
                  style={{
                    marginRight: "auto",
                    padding: "10px 18px",
                    borderRadius: 10,
                    background: "rgba(239,68,68,0.16)",
                    border: "1px solid rgba(239,68,68,0.45)",
                    color: "#fca5a5",
                    fontWeight: 700,
                    cursor: "pointer"
                  }}
                >
                  Delete
                </button>
              )}
              <button
                type="button"
                disabled={busy}
                className="btn btn-secondary"
                onClick={() => setEditing(null)}
                style={{ padding: "10px 18px", borderRadius: 10 }}
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={busy}
                className="btn btn-primary"
                style={{ padding: "10px 22px", borderRadius: 10 }}
              >
                {busy ? "Saving..." : "Save"}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
