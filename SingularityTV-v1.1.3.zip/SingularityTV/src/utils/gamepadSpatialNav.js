const FOCUSABLE_SELECTOR = [
  ".topnav-btn",
  ".hero-action-btn",
  ".hero-dot",
  ".nf-player-btn",
  ".nf-progress",
  ".nf-key",
  ".nf-trending-chip",
  ".nf-result-card",
  ".card",
  ".episode-card",
  ".season-btn",
  ".settings-select-option",
  ".source-dropdown__item",
  ".search-result",
  ".offline-card",
  ".ep-dl-btn",
  ".history-remove-btn",
  ".context-menu-item",
  "button:not(:disabled)",
  "a[href]",
  "input:not([disabled])",
  "select:not([disabled])",
  "textarea:not([disabled])",
  '[role="button"]:not([aria-disabled="true"])',
  '[tabindex]:not([tabindex="-1"])'
].join(",");

const FOCUS_CLASS = "gamepad-focused";
let currentEl = null;
let touchClearInstalled = false;
let activeScrollRaf = 0;

function smoothScrollContainer(container, targetTop) {
  if (!container) return;
  if (activeScrollRaf) {
    cancelAnimationFrame(activeScrollRaf);
    activeScrollRaf = 0;
  }
  const startTop = container.scrollTop;
  const maxTop = Math.max(0, container.scrollHeight - container.clientHeight);
  const clamped = Math.max(0, Math.min(maxTop, targetTop));
  const delta = clamped - startTop;
  if (Math.abs(delta) < 2) {
    container.scrollTop = clamped;
    return;
  }
  const duration = 220;
  const startTime = performance.now();
  const step = now => {
    const t = Math.min(1, (now - startTime) / duration);
    const eased = 1 - Math.pow(1 - t, 3);
    container.scrollTop = startTop + delta * eased;
    if (t < 1) {
      activeScrollRaf = requestAnimationFrame(step);
    } else {
      activeScrollRaf = 0;
    }
  };
  activeScrollRaf = requestAnimationFrame(step);
}

function scrollElementSmoothly(el) {
  if (!el) return;
  const hRow = el.closest(".tv-scroll-row, .cards-row, .episodes-row");
  if (hRow) {
    const rowRect = hRow.getBoundingClientRect();
    const elRect = el.getBoundingClientRect();
    const pad = 28;
    if (elRect.left < rowRect.left + pad) {
      hRow.scrollTo({
        left: Math.max(0, hRow.scrollLeft - (rowRect.left + pad - elRect.left)),
        behavior: "smooth"
      });
    } else if (elRect.right > rowRect.right - pad) {
      hRow.scrollTo({
        left: hRow.scrollLeft + (elRect.right - (rowRect.right - pad)),
        behavior: "smooth"
      });
    }
  }

  if (el.closest(".topnav")) return;

  const mainEl = el.closest(".main");
  if (mainEl) {
    const mainRect = mainEl.getBoundingClientRect();
    const elRect = el.getBoundingClientRect();
    const topSafe = mainRect.top + 86;
    const bottomSafe = mainRect.bottom - 36;
    if (elRect.top < topSafe) {
      smoothScrollContainer(mainEl, mainEl.scrollTop - (topSafe - elRect.top));
    } else if (elRect.bottom > bottomSafe) {
      smoothScrollContainer(mainEl, mainEl.scrollTop + (elRect.bottom - bottomSafe));
    }
    return;
  }

  const scrollBox = el.closest(".nf-results-grid, .nf-search-left, .modal, .settings-content");
  if (scrollBox) {
    const boxRect = scrollBox.getBoundingClientRect();
    const elRect = el.getBoundingClientRect();
    const pad = 16;
    if (elRect.top < boxRect.top + pad) {
      smoothScrollContainer(scrollBox, scrollBox.scrollTop - (boxRect.top + pad - elRect.top));
    } else if (elRect.bottom > boxRect.bottom - pad) {
      smoothScrollContainer(scrollBox, scrollBox.scrollTop + (elRect.bottom - (boxRect.bottom - pad)));
    }
    return;
  }

  el.scrollIntoView?.({ block: "nearest", inline: "nearest", behavior: "smooth" });
}

function installTouchClear() {
  if (touchClearInstalled || typeof window === "undefined") return;
  touchClearInstalled = true;
  window.addEventListener(
    "touchstart",
    () => {
      if (currentEl) {
        currentEl.classList.remove(FOCUS_CLASS);
        currentEl = null;
      }
    },
    { passive: true }
  );
}

function isVisibleFast(el) {
  if (!el || !(el instanceof HTMLElement)) return false;
  if (el.offsetWidth < 8 || el.offsetHeight < 8) return false;
  if (el.closest("[data-gamepad-ignore]")) return false;
  return true;
}

function isModalRoot(el) {
  if (!(el instanceof HTMLElement)) return false;
  if (el.offsetWidth < window.innerWidth * 0.5 || el.offsetHeight < window.innerHeight * 0.5) return false;
  return getComputedStyle(el).position === "fixed";
}

function getScopeRoot() {
  const nfPlayer = document.querySelector(".nf-player-overlay");
  if (nfPlayer && isVisibleFast(nfPlayer)) return nfPlayer;
  const overlays = Array.from(
    document.querySelectorAll(".modal-overlay, .blocked-modal-overlay, .ep-desc-overlay, .context-menu, .source-dropdown, .settings-select-menu")
  ).filter(el => isVisibleFast(el));
  if (overlays.length > 0) return overlays[overlays.length - 1];
  const modals = Array.from(document.querySelectorAll('[class*="overlay"]')).filter(
    el => isVisibleFast(el) && isModalRoot(el)
  );
  if (modals.length > 0) return modals[modals.length - 1];
  return document;
}

function getCandidates() {
  installTouchClear();
  const root = getScopeRoot();
  const nodes = root.querySelectorAll(FOCUSABLE_SELECTOR);
  const seen = new Set();
  const out = [];
  for (const el of nodes) {
    if (!isVisibleFast(el) || seen.has(el)) continue;
    const rect = el.getBoundingClientRect();
    if (rect.width < 8 || rect.height < 8) continue;
    seen.add(el);
    out.push({ el, rect });
  }
  return out;
}

function clearHighlight() {
  if (currentEl) {
    currentEl.classList.remove(FOCUS_CLASS);
  }
  document.querySelectorAll("." + FOCUS_CLASS).forEach(el => {
    if (el !== currentEl) el.classList.remove(FOCUS_CLASS);
  });
}

export function setGamepadFocus(el, { scroll = true } = {}) {
  installTouchClear();
  currentEl = el || null;
  clearHighlight();
  if (!currentEl) return;
  currentEl.classList.add(FOCUS_CLASS);
  const tag = (currentEl.tagName || "").toUpperCase();
  if (tag !== "INPUT" && tag !== "TEXTAREA") {
    try {
      currentEl.focus?.({ preventScroll: true });
    } catch {}
  }
  if (scroll) {
    scrollElementSmoothly(currentEl);
  }
}

export function getGamepadFocus() {
  return currentEl && document.contains(currentEl) && isVisibleFast(currentEl) ? currentEl : null;
}

export function clearGamepadFocus() {
  currentEl = null;
  clearHighlight();
}

export function confirmGamepadFocus() {
  const el = getGamepadFocus();
  if (!el) return false;
  if (el.classList.contains("player-wrap")) {
    try {
      const r = el.getBoundingClientRect();
      const rx = (r.left + r.width / 2) / Math.max(1, window.innerWidth);
      const ry = (r.top + r.height / 2) / Math.max(1, window.innerHeight);
      if (window.AndroidBridge?.tapPlayerCenter && ry > 0.05 && ry < 0.95) {
        window.AndroidBridge.tapPlayerCenter(rx, ry);
        return true;
      }
    } catch {}
  }
  const tag = (el.tagName || "").toUpperCase();
  if (tag === "INPUT" || tag === "TEXTAREA") {
    el.focus?.();
  }
  el.click();
  return true;
}

export function dismissActiveOverlay() {
  const root = getScopeRoot();
  if (root === document) return false;
  const closeBtn = root.querySelector(
    '[data-gamepad-close], [aria-label="Close" i], .modal-close, .close-btn, .blocked-modal-close, .ep-desc-popup-close'
  );
  if (closeBtn instanceof HTMLElement) {
    closeBtn.click();
    return true;
  }
  if (root.classList.contains("settings-select-menu")) {
    document.dispatchEvent(new MouseEvent("mousedown", { bubbles: true }));
    return true;
  }
  if (root instanceof HTMLElement) {
    root.click();
    return true;
  }
  return false;
}

function pickInitial(candidates) {
  if (candidates.length === 0) return null;
  const mainHit = candidates.find(({ el }) =>
    el.closest(".nf-player-main-controls, .nf-keyboard-grid, .hero-actions, .detail-actions, .tv-scroll-row, .cards-grid")
  );
  if (mainHit) return mainHit.el;
  let best = null;
  let bestScore = Infinity;
  for (const { el, rect } of candidates) {
    if (el.closest(".topnav")) continue;
    const score = Math.max(0, rect.top) * 2 + Math.max(0, rect.left);
    if (score < bestScore) {
      bestScore = score;
      best = el;
    }
  }
  return best || candidates[0].el;
}

export function handleGamepadPageScroll(direction) {
  const mainEl = document.querySelector(".main");
  if (!mainEl) {
    moveGamepadFocus(direction);
    return;
  }
  if (direction === "up") {
    if (mainEl.scrollTop > 8) {
      smoothScrollContainer(mainEl, Math.max(0, mainEl.scrollTop - Math.round(mainEl.clientHeight * 0.5)));
      return;
    }
    const candidates = getCandidates().filter(({ el }) => el.closest(".topnav"));
    if (candidates.length > 0) {
      const activeTop = candidates.find(({ el }) => el.classList.contains("active")) || candidates[0];
      setGamepadFocus(activeTop.el, { scroll: false });
    }
    return;
  }
  smoothScrollContainer(mainEl, mainEl.scrollTop + Math.round(mainEl.clientHeight * 0.5));
}

export function moveGamepadFocus(direction) {
  const activeScope = getScopeRoot();
  if (
    activeScope !== document &&
    activeScope instanceof HTMLElement &&
    (activeScope.classList.contains("settings-select-menu") ||
      activeScope.classList.contains("source-dropdown") ||
      activeScope.classList.contains("context-menu"))
  ) {
    const items = Array.from(
      activeScope.querySelectorAll(".settings-select-option, .source-dropdown__item, .context-menu-item")
    ).filter(el => el instanceof HTMLElement);
    if (items.length > 0 && (direction === "down" || direction === "up")) {
      const cur = getGamepadFocus();
      const idx = cur ? items.indexOf(cur) : -1;
      if (direction === "down") {
        if (idx === -1) {
          setGamepadFocus(items[0], { scroll: false });
          items[0].scrollIntoView?.({ block: "nearest", behavior: "auto" });
          return;
        }
        if (idx < items.length - 1) {
          const nxt = items[idx + 1];
          setGamepadFocus(nxt, { scroll: false });
          nxt.scrollIntoView?.({ block: "nearest", behavior: "auto" });
          return;
        }
        const triggerBtn = activeScope.parentElement?.querySelector("button");
        dismissActiveOverlay();
        requestAnimationFrame(() => {
          if (triggerBtn instanceof HTMLElement) {
            setGamepadFocus(triggerBtn, { scroll: false });
          }
          moveGamepadFocus("down");
        });
        return;
      }
      if (direction === "up") {
        if (idx > 0) {
          const prv = items[idx - 1];
          setGamepadFocus(prv, { scroll: false });
          prv.scrollIntoView?.({ block: "nearest", behavior: "auto" });
          return;
        }
        const triggerBtn = activeScope.parentElement?.querySelector("button");
        dismissActiveOverlay();
        if (triggerBtn instanceof HTMLElement) {
          requestAnimationFrame(() => setGamepadFocus(triggerBtn, { scroll: false }));
        }
        return;
      }
    }
  }
  const candidates = getCandidates();
  if (candidates.length === 0) return;
  const from = getGamepadFocus();
  const fromEntry = from ? candidates.find(c => c.el === from) : null;
  if (!fromEntry) {
    setGamepadFocus(pickInitial(candidates));
    return;
  }

  const fromRect = fromEntry.rect;
  const fromCx = fromRect.left + fromRect.width / 2;
  const fromCy = fromRect.top + fromRect.height / 2;
  const fromInTopnav = Boolean(from.closest(".topnav"));

  let best = null;
  let bestScore = Infinity;

  if (direction === "left" || direction === "right") {
    const dir = direction === "right" ? 1 : -1;
    const sameRowTolerance = Math.max(fromRect.height * 0.75, 24);

    for (const { el, rect: r } of candidates) {
      if (el === from) continue;
      if (fromInTopnav && !el.closest(".topnav")) continue;
      const cx = r.left + r.width / 2;
      const cy = r.top + r.height / 2;
      const dx = (cx - fromCx) * dir;
      if (dx <= 4) continue;

      const dy = Math.abs(cy - fromCy);
      if (dy > sameRowTolerance) continue;

      const score = dx + dy * 2;
      if (score < bestScore) {
        bestScore = score;
        best = el;
      }
    }
  } else {
    const dir = direction === "down" ? 1 : -1;
    const minRowStep = Math.max(fromRect.height * 0.45, 14);

    for (const { el, rect: r } of candidates) {
      if (el === from) continue;
      if (direction === "up" && !fromInTopnav && el.closest(".topnav")) continue;
      const cx = r.left + r.width / 2;
      const cy = r.top + r.height / 2;
      const dy = (cy - fromCy) * dir;
      if (dy <= minRowStep) continue;

      const dx = Math.abs(cx - fromCx);
      const horizontalOverlap = Math.max(
        0,
        Math.min(fromRect.right, r.right) - Math.max(fromRect.left, r.left)
      );
      const overlapBonus = horizontalOverlap > 0 ? -120 : 0;
      const score = dy * 2.2 + dx + overlapBonus;

      if (score < bestScore) {
        bestScore = score;
        best = el;
      }
    }

    if (!best && direction === "up" && !fromInTopnav) {
      const mainEl = document.querySelector(".main");
      if (mainEl && mainEl.scrollTop > 8) {
        smoothScrollContainer(mainEl, Math.max(0, mainEl.scrollTop - Math.round(mainEl.clientHeight * 0.45)));
        return;
      }
      const topBtns = candidates.filter(({ el }) => el.closest(".topnav"));
      if (topBtns.length > 0) {
        let closestTop = topBtns[0].el;
        let minDx = Infinity;
        for (const { el, rect: r } of topBtns) {
          const cx = r.left + r.width / 2;
          const dx = Math.abs(cx - fromCx);
          if (dx < minDx) {
            minDx = dx;
            closestTop = el;
          }
        }
        setGamepadFocus(closestTop, { scroll: false });
      }
      return;
    }
  }

  if (best) setGamepadFocus(best);
}

export function ensureInitialFocus() {
  if (getGamepadFocus()) return;
  setGamepadFocus(pickInitial(getCandidates()));
}
