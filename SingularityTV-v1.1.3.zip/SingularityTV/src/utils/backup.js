const PREFIX = "streambert_";
export const BACKUP_KEYS = ["saved", "savedOrder", "history", "progress", "watched", "homeRowOrder", "homeRowVisible", "homeViewMode", "startPage", "playerSource", "hianimeDubMode", "introSkipMode", "ageLimit", "ratingCountry", "watchedThreshold", "autoplayNextEnabled", "autoplayNextDuration", "autoplayNextLayout", "subtitleDownload", "subtitleLang", "downloadPath", "downloaderFolder", "invidiousBase", "autoCheckUpdates", "searchHistory", "accentColor", "fontSize", "compactMode", "reduceAnimations", "librarySort", "historyEnabled", "tmdbLang", "notifyDownloadComplete", "notifyNewEpisode", "episodeReleaseCache", "favorites", "subTextSize", "subTextColor", "subBgStyle", "subBottomOffset", "seriesPrefs", "embedMovieTemplate", "embedTvTemplate", "theme", "customThemeVars", "accentInPlayer", "liveFavorites", "customLiveM3u", "_progressTs", "_watchedTs", "_savedTs", "_liveFavTs", "_settingsTs", "_livePlayback", "_historyDeletedTs"];

const NON_SCALAR_KEYS = new Set(["saved", "savedOrder", "history", "progress", "watched", "liveFavorites", "_progressTs", "_watchedTs", "_savedTs", "_liveFavTs", "_settingsTs", "_livePlayback", "_historyDeletedTs", "_dlTimes"]);

export function touchBackupTimestamp(mapKey, itemKey) {
  try {
    const raw = localStorage.getItem(PREFIX + mapKey);
    const obj = raw ? JSON.parse(raw) : {};
    obj[itemKey] = Date.now();
    localStorage.setItem(PREFIX + mapKey, JSON.stringify(obj));
  } catch {}
}

export function touchSettingsTimestamp() {
  try {
    localStorage.setItem(PREFIX + "_settingsTs", JSON.stringify(Date.now()));
  } catch {}
}

export function collectBackupData() {
  const data = {};
  for (const key of BACKUP_KEYS) {
    try {
      const raw = localStorage.getItem(PREFIX + key);
      if (raw !== null) data[key] = JSON.parse(raw);
    } catch {}
  }
  const dlTimes = {};
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(PREFIX + "dlTime_")) {
        const raw = localStorage.getItem(k);
        if (raw !== null) dlTimes[k.slice(PREFIX.length)] = JSON.parse(raw);
      }
    }
  } catch {}
  if (Object.keys(dlTimes).length > 0) {
    data._dlTimes = dlTimes;
  }
  return data;
}

export function clearBackupData() {
  for (const key of BACKUP_KEYS) {
    try {
      localStorage.removeItem(PREFIX + key);
    } catch {}
  }
  try {
    const toRemove = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && (k.startsWith(PREFIX + "dlTime_") || k.startsWith("dlTime_"))) {
        toRemove.push(k);
      }
    }
    for (const k of toRemove) {
      localStorage.removeItem(k);
    }
  } catch {}
}

function normalizeShowTitle(t) {
  return String(t || "").trim().toLowerCase().replace(/[^a-z0-9\u0600-\u06ff]+/g, " ").trim();
}

export function deduplicateHistoryList(list) {
  const arr = Array.isArray(list) ? list : [];
  const sorted = [...arr].filter(h => h && h.id).sort((a, b) => Number(b.watchedAt || 0) - Number(a.watchedAt || 0));
  const seenKeys = new Set();
  const seenTvTitles = new Set();
  const out = [];
  for (const h of sorted) {
    if (h.media_type === "tv") {
      const idKey = `tv_${String(h.id)}`;
      const titleKey = normalizeShowTitle(h.title || h.name);
      if (seenKeys.has(idKey) || (titleKey && seenTvTitles.has(titleKey))) continue;
      seenKeys.add(idKey);
      if (titleKey) seenTvTitles.add(titleKey);
      out.push(h);
    } else {
      const mk = `movie_${String(h.id)}`;
      if (seenKeys.has(mk)) continue;
      seenKeys.add(mk);
      out.push(h);
    }
  }
  return out.slice(0, 100);
}

export function mergeBackupData(localData = {}, remoteData = {}) {
  const loc = localData && typeof localData === "object" ? localData : {};
  const rem = remoteData && typeof remoteData === "object" ? remoteData : {};
  const locSetTs = Number(loc._settingsTs || 0);
  const remSetTs = Number(rem._settingsTs || 0);
  const settingsWinner = remSetTs > locSetTs ? rem : loc;
  const merged = {};
  for (const key of BACKUP_KEYS) {
    if (NON_SCALAR_KEYS.has(key)) continue;
    if (settingsWinner[key] !== undefined) {
      merged[key] = settingsWinner[key];
    }
  }
  merged._settingsTs = Math.max(locSetTs, remSetTs);

  const locLp = loc._livePlayback && typeof loc._livePlayback === "object" ? loc._livePlayback : null;
  const remLp = rem._livePlayback && typeof rem._livePlayback === "object" ? rem._livePlayback : null;
  const locLpTs = Number(locLp?.updatedAt || 0);
  const remLpTs = Number(remLp?.updatedAt || 0);
  if (remLpTs > locLpTs && remLp) {
    merged._livePlayback = remLp;
  } else if (locLp) {
    merged._livePlayback = locLp;
  } else if (remLp) {
    merged._livePlayback = remLp;
  }

  const locProgTs = loc._progressTs && typeof loc._progressTs === "object" ? loc._progressTs : {};
  const remProgTs = rem._progressTs && typeof rem._progressTs === "object" ? rem._progressTs : {};
  const locProg = loc.progress && typeof loc.progress === "object" ? loc.progress : {};
  const remProg = rem.progress && typeof rem.progress === "object" ? rem.progress : {};
  const locDl = loc._dlTimes && typeof loc._dlTimes === "object" ? loc._dlTimes : {};
  const remDl = rem._dlTimes && typeof rem._dlTimes === "object" ? rem._dlTimes : {};

  const outProg = {};
  const outProgTs = {};
  const outDl = { ...remDl, ...locDl };
  const progKeys = new Set([...Object.keys(locProg), ...Object.keys(remProg), ...Object.keys(locProgTs), ...Object.keys(remProgTs)]);
  for (const k of progKeys) {
    const lt = Number(locProgTs[k] || 0);
    const rt = Number(remProgTs[k] || 0);
    const dlKey = "dlTime_" + k;
    if (rt > lt) {
      if (remProg[k] !== undefined) outProg[k] = remProg[k];
      else delete outDl[dlKey];
      outProgTs[k] = rt;
      if (remDl[dlKey] !== undefined && remProg[k] !== undefined) outDl[dlKey] = remDl[dlKey];
    } else if (lt > rt) {
      if (locProg[k] !== undefined) outProg[k] = locProg[k];
      else delete outDl[dlKey];
      outProgTs[k] = lt;
      if (locDl[dlKey] !== undefined && locProg[k] !== undefined) outDl[dlKey] = locDl[dlKey];
    } else {
      const lv = locProg[k] !== undefined ? Number(locProg[k] || 0) : null;
      const rv = remProg[k] !== undefined ? Number(remProg[k] || 0) : null;
      if (lv !== null || rv !== null) {
        outProg[k] = Math.max(lv || 0, rv || 0);
        if ((rv || 0) > (lv || 0) && remDl[dlKey] !== undefined) outDl[dlKey] = remDl[dlKey];
      }
      if (Math.max(lt, rt) > 0) outProgTs[k] = Math.max(lt, rt);
    }
  }
  merged.progress = outProg;
  merged._progressTs = outProgTs;
  merged._dlTimes = outDl;

  const locWatchTs = loc._watchedTs && typeof loc._watchedTs === "object" ? loc._watchedTs : {};
  const remWatchTs = rem._watchedTs && typeof rem._watchedTs === "object" ? rem._watchedTs : {};
  const locWatch = loc.watched && typeof loc.watched === "object" ? loc.watched : {};
  const remWatch = rem.watched && typeof rem.watched === "object" ? rem.watched : {};
  const outWatch = {};
  const outWatchTs = {};
  const watchKeys = new Set([...Object.keys(locWatch), ...Object.keys(remWatch), ...Object.keys(locWatchTs), ...Object.keys(remWatchTs)]);
  for (const k of watchKeys) {
    const lt = Number(locWatchTs[k] || 0);
    const rt = Number(remWatchTs[k] || 0);
    const val = rt > lt ? !!remWatch[k] : lt > rt ? !!locWatch[k] : !!(locWatch[k] || remWatch[k]);
    if (val) outWatch[k] = true;
    const ts = Math.max(lt, rt);
    if (ts > 0) outWatchTs[k] = ts;
  }
  merged.watched = outWatch;
  merged._watchedTs = outWatchTs;

  const locSavedTs = loc._savedTs && typeof loc._savedTs === "object" ? loc._savedTs : {};
  const remSavedTs = rem._savedTs && typeof rem._savedTs === "object" ? rem._savedTs : {};
  const locSaved = loc.saved && typeof loc.saved === "object" ? loc.saved : {};
  const remSaved = rem.saved && typeof rem.saved === "object" ? rem.saved : {};
  const outSaved = {};
  const outSavedTs = {};
  const savedKeys = new Set([...Object.keys(locSaved), ...Object.keys(remSaved), ...Object.keys(locSavedTs), ...Object.keys(remSavedTs)]);
  for (const k of savedKeys) {
    const lt = Number(locSavedTs[k] || 0);
    const rt = Number(remSavedTs[k] || 0);
    const entry = rt > lt ? remSaved[k] : lt > rt ? locSaved[k] : (locSaved[k] || remSaved[k]);
    if (entry) outSaved[k] = entry;
    const ts = Math.max(lt, rt);
    if (ts > 0) outSavedTs[k] = ts;
  }
  merged.saved = outSaved;
  merged._savedTs = outSavedTs;

  const locOrder = Array.isArray(loc.savedOrder) ? loc.savedOrder : [];
  const remOrder = Array.isArray(rem.savedOrder) ? rem.savedOrder : [];
  const orderSet = new Set();
  const outOrder = [];
  for (const k of [...locOrder, ...remOrder, ...Object.keys(outSaved)]) {
    if (outSaved[k] && !orderSet.has(k)) {
      orderSet.add(k);
      outOrder.push(k);
    }
  }
  merged.savedOrder = outOrder;

  const locHistDel = loc._historyDeletedTs && typeof loc._historyDeletedTs === "object" ? loc._historyDeletedTs : {};
  const remHistDel = rem._historyDeletedTs && typeof rem._historyDeletedTs === "object" ? rem._historyDeletedTs : {};
  const outHistDel = {};
  for (const k of new Set([...Object.keys(locHistDel), ...Object.keys(remHistDel)])) {
    const ts = Math.max(Number(locHistDel[k] || 0), Number(remHistDel[k] || 0));
    if (ts > 0) outHistDel[k] = ts;
  }
  merged._historyDeletedTs = outHistDel;

  const allHist = [...(Array.isArray(rem.history) ? rem.history : []), ...(Array.isArray(loc.history) ? loc.history : [])].filter(h => {
    if (!h || !h.id) return false;
    const wAt = Number(h.watchedAt || 0);
    const idDelKey = h.media_type === "tv" ? `tv_${String(h.id)}` : `movie_${String(h.id)}`;
    if (Number(outHistDel[idDelKey] || 0) >= wAt && Number(outHistDel[idDelKey] || 0) > 0) return false;
    if (h.media_type === "tv") {
      const tk = normalizeShowTitle(h.title || h.name);
      if (tk && Number(outHistDel["tv_t_" + tk] || 0) >= wAt && Number(outHistDel["tv_t_" + tk] || 0) > 0) return false;
    }
    return true;
  });
  merged.history = deduplicateHistoryList(allHist);

  const locFavTs = loc._liveFavTs && typeof loc._liveFavTs === "object" ? loc._liveFavTs : {};
  const remFavTs = rem._liveFavTs && typeof rem._liveFavTs === "object" ? rem._liveFavTs : {};
  const locFavMap = new Map();
  for (const f of Array.isArray(loc.liveFavorites) ? loc.liveFavorites : []) {
    if (f && f.url) locFavMap.set(f.url, f);
  }
  const remFavMap = new Map();
  for (const f of Array.isArray(rem.liveFavorites) ? rem.liveFavorites : []) {
    if (f && f.url) remFavMap.set(f.url, f);
  }
  const outFavs = [];
  const outFavTs = {};
  const allFavUrls = new Set([...locFavMap.keys(), ...remFavMap.keys(), ...Object.keys(locFavTs), ...Object.keys(remFavTs)]);
  for (const u of allFavUrls) {
    const lt = Number(locFavTs[u] || 0);
    const rt = Number(remFavTs[u] || 0);
    const entry = rt > lt ? remFavMap.get(u) : lt > rt ? locFavMap.get(u) : (locFavMap.get(u) || remFavMap.get(u));
    if (entry) outFavs.push(entry);
    const ts = Math.max(lt, rt);
    if (ts > 0) outFavTs[u] = ts;
  }
  merged.liveFavorites = outFavs;
  merged._liveFavTs = outFavTs;

  return merged;
}

export function restoreBackupData(data) {
  if (!data || typeof data !== "object") throw new Error("Invalid backup data");
  clearBackupData();
  for (const key of BACKUP_KEYS) {
    if (data[key] !== undefined && data[key] !== null) {
      localStorage.setItem(PREFIX + key, JSON.stringify(data[key]));
    }
  }
  if (data._dlTimes && typeof data._dlTimes === "object") {
    for (const [k, v] of Object.entries(data._dlTimes)) {
      try {
        localStorage.setItem(PREFIX + k, JSON.stringify(v));
      } catch {}
    }
  }
}
