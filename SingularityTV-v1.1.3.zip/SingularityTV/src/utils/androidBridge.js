import { APP_VERSION } from "./supabaseSync";
if (typeof window !== "undefined" && !window.AndroidBridge && window.webkit?.messageHandlers?.SingularityBridge) {
  const postIos = (method, args) => {
    try {
      window.webkit.messageHandlers.SingularityBridge.postMessage({ method, args });
    } catch {}
  };
  window.AndroidBridge = {
    openExoPlayer: payloadJson => { postIos("openExoPlayer", [payloadJson]); return JSON.stringify({ ok: true }); },
    openExternal: url => { postIos("openExternal", [String(url || "")]); return JSON.stringify({ ok: true }); },
    deliverNextServerStream: (url, sourceId) => { postIos("deliverNextServerStream", [url || "", sourceId || ""]); },
    startGoogleOAuth: (authUrl, scheme) => { postIos("startGoogleOAuth", [authUrl || "", scheme || ""]); return JSON.stringify({ ok: true }); },
    downloadAndInstallUpdate: payloadJson => { postIos("downloadAndInstallUpdate", [payloadJson || "{}"]); return JSON.stringify({ ok: true }); },
    cancelUpdate: () => { postIos("cancelUpdate", []); return JSON.stringify({ ok: true }); },
    openDownloadedIpa: () => { postIos("openDownloadedIpa", []); return JSON.stringify({ ok: true }); },
    preprobeStream: payloadJson => { postIos("preprobeStream", [payloadJson || "{}"]); return JSON.stringify({ ok: true }); },
    setImmersiveMode: enabled => { postIos("setImmersiveMode", [!!enabled]); },
    isTvDevice: () => false,
    getDownloads: () => "[]",
    saveData: (k, v) => { try { localStorage.setItem("sb_" + k, v); } catch {} },
    loadData: k => { try { return localStorage.getItem("sb_" + k) || ""; } catch { return ""; } }
  };
}

const listeners = new Map();
function addEventListenerChannel(channel, cb) {
  if (!listeners.has(channel)) {
    listeners.set(channel, new Set());
  }
  listeners.get(channel).add(cb);
  return cb;
}
function removeEventListenerChannel(channel, cb) {
  const set = listeners.get(channel);
  if (set) set.delete(cb);
}
export function emitNativeEvent(channel, payload) {
  try {
    window.dispatchEvent(new CustomEvent("streambert:" + channel, { detail: payload }));
  } catch {}
  const set = listeners.get(channel);
  if (!set) return;
  for (const cb of set) {
    try {
      cb(payload);
    } catch (e) {
      console.error(`[AndroidBridge] listener error on ${channel}:`, e);
    }
  }
}
if (typeof window !== "undefined") {
  window.__streambertDispatch = (channel, payload) => {
    let parsed = payload;
    if (typeof payload === "string") {
      try {
        parsed = JSON.parse(payload);
      } catch {
        parsed = payload;
      }
    }
    emitNativeEvent(channel, parsed);
  };
}
function getNative() {
  if (typeof window !== "undefined" && window.AndroidBridge) {
    return window.AndroidBridge;
  }
  return null;
}
function callNativeJson(method, ...args) {
  const native = getNative();
  if (!native || typeof native[method] !== "function") return null;
  try {
    const raw = native[method](...args);
    if (raw === undefined || raw === null || raw === "") return null;
    if (typeof raw === "string") {
      try {
        return JSON.parse(raw);
      } catch {
        return raw;
      }
    }
    return raw;
  } catch (e) {
    console.warn(`[AndroidBridge] ${method} failed:`, e);
    return null;
  }
}
export function isAndroidNative() {
  return !!getNative();
}
export function isAndroidTvDevice() {
  const native = getNative();
  if (native && typeof native.isTvDevice === "function") {
    try {
      return !!native.isTvDevice();
    } catch {}
  }
  if (typeof window !== "undefined") {
    const ua = (navigator.userAgent || "").toLowerCase();
    if (ua.includes("android tv") || ua.includes("aftm") || ua.includes("aftt") || ua.includes("aftb") || ua.includes("bravia") || ua.includes("shield") || ua.includes("leanback") || ua.includes("crkey") || ua.includes("googletv")) {
      return true;
    }
    if (localStorage.getItem("streambert_forceTvMode") === "1") {
      return true;
    }
  }
  return false;
}
export function isStrictAndroidTvHardware() {
  if (typeof window !== "undefined" && window.webkit?.messageHandlers?.singularityBridge) {
    return false;
  }
  const native = getNative();
  if (native && typeof native.isTvDevice === "function") {
    try {
      if (native.isTvDevice()) return true;
    } catch {}
  }
  if (typeof window !== "undefined") {
    const ua = (navigator.userAgent || "").toLowerCase();
    if (ua.includes("android tv") || ua.includes("aftm") || ua.includes("aftt") || ua.includes("aftb") || ua.includes("bravia") || ua.includes("shield") || ua.includes("leanback") || ua.includes("googletv") || ua.includes("mibox") || ua.includes("mi box")) {
      return true;
    }
  }
  return false;
}
const fallbackDownloadsKey = "streambert_android_downloads_v1";
function getFallbackDownloads() {
  try {
    return JSON.parse(localStorage.getItem(fallbackDownloadsKey) || "[]");
  } catch {
    return [];
  }
}
function saveFallbackDownloads(list) {
  try {
    localStorage.setItem(fallbackDownloadsKey, JSON.stringify(list));
  } catch {}
}
export const androidBridge = {
  cleanUserAgent: typeof navigator !== "undefined" && navigator.userAgent || "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
  isNative: isAndroidNative,
  isTv: isAndroidTvDevice,
  onM3u8Found: cb => addEventListenerChannel("m3u8-found", cb),
  offM3u8Found: h => removeEventListenerChannel("m3u8-found", h),
  onSubtitleFound: cb => addEventListenerChannel("subtitle-found", cb),
  offSubtitleFound: h => removeEventListenerChannel("subtitle-found", h),
  onServerChallenge: cb => addEventListenerChannel("server-challenge-detected", cb),
  offServerChallenge: h => removeEventListenerChannel("server-challenge-detected", h),
  onNeedNextServer: cb => addEventListenerChannel("player-need-next-server", cb),
  offNeedNextServer: h => removeEventListenerChannel("player-need-next-server", h),
  onPreferredSourceUpdated: cb => addEventListenerChannel("preferred-source-updated", cb),
  offPreferredSourceUpdated: h => removeEventListenerChannel("preferred-source-updated", h),
  deliverNextServerStream: (url, sourceId) => callNative("deliverNextServerStream", String(url || ""), String(sourceId || "")),
  openNativePlayer: async (args = {}) => {
    const res = callNativeJson("openExoPlayer", JSON.stringify(args));
    if (res) return res;
    emitNativeEvent("open-inapp-exo-fallback", args);
    return {
      ok: true,
      mode: "inapp"
    };
  },
  onExoProgress: cb => addEventListenerChannel("exo-progress", cb),
  offExoProgress: h => removeEventListenerChannel("exo-progress", h),
  onExoEpisodeEnded: cb => addEventListenerChannel("exo-episode-ended", cb),
  offExoEpisodeEnded: h => removeEventListenerChannel("exo-episode-ended", h),
  openPipWindow: async (url, title, userAgent = null) => {
    const res = callNativeJson("enterPipMode", JSON.stringify({
      url,
      title,
      userAgent
    }));
    if (res) {
      emitNativeEvent("pip-window-opened", {});
      return res;
    }
    return {
      ok: false,
      reason: "pip-not-supported"
    };
  },
  closePipWindow: async () => {
    callNativeJson("exitPipMode");
    emitNativeEvent("pip-window-closed", {});
    return {
      ok: true
    };
  },
  getPipWebContentsId: async () => null,
  onPipOpened: cb => addEventListenerChannel("pip-window-opened", cb),
  offPipOpened: h => removeEventListenerChannel("pip-window-opened", h),
  onPipClosed: cb => addEventListenerChannel("pip-window-closed", cb),
  offPipClosed: h => removeEventListenerChannel("pip-window-closed", h),
  onDownloadProgress: cb => addEventListenerChannel("download-progress", cb),
  offDownloadProgress: h => removeEventListenerChannel("download-progress", h),
  checkDownloader: async _folder => {
    return {
      exists: true,
      token: "android-native-workmanager"
    };
  },
  runDownload: async args => {
    const res = callNativeJson("enqueueDownload", JSON.stringify(args));
    if (res && res.ok) return res;
    const id = "dl_" + Date.now() + "_" + Math.random().toString(36).slice(2, 7);
    const entry = {
      id,
      name: args.name || "Media Download",
      m3u8Url: args.m3u8Url,
      downloadPath: args.downloadPath || ((typeof window !== "undefined" && window.webkit?.messageHandlers?.SingularityBridge) ? "Documents/SingularityTV/Downloads" : "/storage/emulated/0/Download/SingularityTV"),
      filePath: `${args.downloadPath || ((typeof window !== "undefined" && window.webkit?.messageHandlers?.SingularityBridge) ? "Documents/SingularityTV/Downloads" : "/storage/emulated/0/Download/SingularityTV")}/${(args.name || "video").replace(/[^a-zA-Z0-9._ -]/g, "")}.mp4`,
      status: "downloading",
      progress: 0,
      speed: "0 KB/s",
      eta: "Calculating…",
      size: "Pending",
      totalFragments: 0,
      completedFragments: 0,
      lastMessage: "Queued in Android WorkManager…",
      startedAt: Date.now(),
      completedAt: null,
      mediaId: args.mediaId || null,
      mediaType: args.mediaType || null,
      season: args.season ?? null,
      episode: args.episode ?? null,
      posterPath: args.posterPath || null,
      subtitles: Array.isArray(args.subtitles) ? args.subtitles : [],
      subtitlePaths: []
    };
    const list = [entry, ...getFallbackDownloads().filter(d => d.id !== id)];
    saveFallbackDownloads(list);
    return {
      ok: true,
      id
    };
  },
  pauseDownload: async id => {
    const res = callNativeJson("pauseDownload", String(id));
    if (res) return res;
    const list = getFallbackDownloads().map(d => d.id === id ? {
      ...d,
      status: "paused",
      speed: "0 B/s",
      lastMessage: "Paused"
    } : d);
    saveFallbackDownloads(list);
    emitNativeEvent("download-progress", {
      id,
      status: "paused",
      speed: "0 B/s",
      lastMessage: "Paused"
    });
    return {
      ok: true
    };
  },
  resumeDownload: async id => {
    const res = callNativeJson("resumeDownload", String(id));
    if (res) return res;
    const list = getFallbackDownloads().map(d => d.id === id ? {
      ...d,
      status: "downloading",
      lastMessage: "Resuming…"
    } : d);
    saveFallbackDownloads(list);
    emitNativeEvent("download-progress", {
      id,
      status: "downloading",
      lastMessage: "Resuming…"
    });
    return {
      ok: true
    };
  },
  cancelDownload: async id => {
    const res = callNativeJson("cancelDownload", String(id));
    if (res) return res;
    const list = getFallbackDownloads().map(d => d.id === id ? {
      ...d,
      status: "cancelled",
      speed: "",
      lastMessage: "Cancelled by user"
    } : d);
    saveFallbackDownloads(list);
    emitNativeEvent("download-progress", {
      id,
      status: "cancelled",
      speed: "",
      lastMessage: "Cancelled by user"
    });
    return {
      ok: true
    };
  },
  retryDownload: async id => {
    const res = callNativeJson("retryDownload", String(id));
    if (res) return res;
    const list = getFallbackDownloads().map(d => d.id === id ? {
      ...d,
      status: "downloading",
      progress: 0,
      lastMessage: "Retrying download…"
    } : d);
    saveFallbackDownloads(list);
    emitNativeEvent("download-progress", {
      id,
      status: "downloading",
      progress: 0,
      lastMessage: "Retrying download…"
    });
    return {
      ok: true
    };
  },
  getDownloads: async () => {
    const res = callNativeJson("getDownloads");
    if (Array.isArray(res)) return res;
    return getFallbackDownloads();
  },
  deleteDownload: async ({
    id,
    filePath
  }) => {
    const res = callNativeJson("deleteDownload", JSON.stringify({
      id,
      filePath
    }));
    if (res) return res;
    const list = getFallbackDownloads().filter(d => d.id !== id);
    saveFallbackDownloads(list);
    return {
      ok: true
    };
  },
  deleteAllDownloads: async () => {
    const res = callNativeJson("deleteAllDownloads");
    if (res) return res;
    const count = getFallbackDownloads().length;
    saveFallbackDownloads([]);
    return {
      ok: true,
      deleted: count,
      errors: 0
    };
  },
  getDownloadsSize: async () => {
    const res = callNativeJson("getDownloadsSize");
    if (res && typeof res.bytes === "number") return res;
    return {
      bytes: 0
    };
  },
  fileExists: async filePath => {
    const res = callNativeJson("fileExists", String(filePath || ""));
    if (typeof res === "boolean") return res;
    if (res && typeof res.exists === "boolean") return res.exists;
    return !!filePath;
  },
  scanDirectory: async folderPath => {
    const res = callNativeJson("scanDirectory", String(folderPath || ""));
    if (Array.isArray(res)) return res;
    return [];
  },
  pickFolder: async () => {
    const res = callNativeJson("pickFolder");
    if (res && typeof res.path === "string") return res.path;
    return ((typeof window !== "undefined" && window.webkit?.messageHandlers?.SingularityBridge) ? "Documents/SingularityTV/Downloads" : "/storage/emulated/0/Download/SingularityTV");
  },
  showInFolder: async filePath => {
    callNativeJson("showInFolder", String(filePath || ""));
  },
  openExternal: async url => {
    const res = callNativeJson("openExternal", String(url || ""));
    if (!res && typeof window !== "undefined" && url) {
      window.open(url, "_blank", "noopener,noreferrer");
    }
  },
  openPath: async filePath => {
    const res = callNativeJson("openExoPlayer", JSON.stringify({
      url: filePath,
      title: (filePath || "").split("/").pop() || "Local Video",
      isLocal: true
    }));
    return res || {
      ok: true
    };
  },
  openPathAtTime: async (filePath, seconds, subtitlePaths) => {
    const res = callNativeJson("openExoPlayer", JSON.stringify({
      url: filePath,
      title: (filePath || "").split("/").pop() || "Local Video",
      startTimeSec: seconds || 0,
      subtitlePaths: subtitlePaths || [],
      isLocal: true
    }));
    return res || {
      ok: true
    };
  },
  openStreamExternal: async args => {
    const res = callNativeJson("openExoPlayer", JSON.stringify(args));
    if (res) return {
      ok: true,
      player: "ExoPlayer"
    };
    emitNativeEvent("open-inapp-exo-fallback", args);
    return {
      ok: true,
      player: "ExoPlayer"
    };
  },
  getInstallPath: async () => "/data/data/com.Singularity.streambert",
  getVideoDuration: async filePath => {
    const res = callNativeJson("getVideoDuration", String(filePath || ""));
    if (res && res.ok) return res;
    return {
      ok: false
    };
  },
  resolveHiAnime: async args => {
    const res = callNativeJson("resolveHiAnime", JSON.stringify(args));
    if (res) return res;
    return {
      ok: false,
      error: "Native HiAnime resolver requires Android runtime or fallback source"
    };
  },
  setPlayerVideo: async args => {
    const res = callNativeJson("setPlayerVideo", JSON.stringify(args));
    if (res && res.playerUrl) return res;
    return {
      playerUrl: args.url
    };
  },
  onHiAnimeProgress: cb => {
    const h = data => cb(typeof data === "string" ? data : data?.stage);
    addEventListenerChannel("hianime-progress", h);
    return () => removeEventListenerChannel("hianime-progress", h);
  },
  setImmersiveMode: enabled => {
    callNativeJson("setImmersiveMode", !!enabled);
  },
  searchSubtitles: async (args = {}) => {
    const scoreRelease = (name = "") => {
      const u = String(name).toUpperCase();
      let score = 0;
      if (/WEB[-_. ]?DL|WEBRIP|WEB[-_. ]?HDRIP|AMZN|NF|DSNP|ATVP|HMAX|PCOK/.test(u)) score += 50;
      if (/1080P|720P|X264|H264|H\.264/.test(u)) score += 20;
      if (/23\.976|23\.98|24FPS/.test(u)) score += 15;
      if (/BLURAY|BDRIP|BRRIP/.test(u)) score += 10;
      if (/EXTENDED|DIRECTORS[._ ]?CUT|UNRATED|THEATRICAL/.test(u)) score -= 45;
      if (/CAM|HDTS|TS|TC|WORKPRINT|25FPS/.test(u)) score -= 60;
      return score;
    };
    const decorateAndSort = list => {
      return list.map(item => {
        const syncScore = scoreRelease(item.release || item.file_name || "");
        const isWebSynced = syncScore >= 40;
        return {
          ...item,
          syncScore,
          release: isWebSynced && !String(item.release || "").includes("✓") ? `✓ WEB-Synced · ${item.release || item.file_name}` : item.release || item.file_name
        };
      }).sort((a, b) => b.syncScore - a.syncScore || (b.download_count || 0) - (a.download_count || 0));
    };
    const {
      mediaId,
      tmdbId,
      imdbId,
      mediaType,
      season,
      episode,
      languages,
      subdlApiKey,
      wyzieApiKey
    } = args;
    const lookupId = imdbId || tmdbId || mediaId;
    if (!lookupId) return {
      ok: false,
      error: "No media ID for subtitle lookup"
    };
    const errors = [];
    const collected = [];
    if (subdlApiKey) {
      try {
        const params = new URLSearchParams({
          api_key: subdlApiKey,
          type: mediaType === "tv" ? "tv" : "movie",
          subs_per_page: "30"
        });
        if (String(lookupId).startsWith("tt")) {
          params.set("imdb_id", String(lookupId));
        } else {
          params.set("tmdb_id", String(lookupId));
        }
        if (mediaType === "tv" && season != null) params.set("season_number", String(season));
        if (mediaType === "tv" && episode != null) params.set("episode_number", String(episode));
        if (languages) params.set("languages", languages.split("-")[0].toUpperCase());
        const res = await fetch(`https://api.subdl.com/api/v1/subtitles?${params}`);
        if (res.ok) {
          const data = await res.json();
          if (data.status && Array.isArray(data.subtitles)) {
            for (const s of data.subtitles) {
              collected.push({
                file_id: `subdl_${s.sd_id}_${encodeURIComponent(s.url)}`,
                file_name: s.name || s.release_name || "",
                language: (s.lang || "").toLowerCase(),
                release: s.release_name || s.name || "",
                uploader: s.author || "SubDL",
                download_count: s.downloads || 0,
                hearing_impaired: !!s.hi,
                ai_translated: false,
                via_subdl: true
              });
            }
          }
        }
      } catch (e) {
        errors.push(e.message);
      }
    }
    try {
      const params = new URLSearchParams({
        id: String(lookupId),
        format: "srt"
      });
      if (languages) params.set("language", languages.split("-")[0]);
      if (mediaType === "tv" && season != null) params.set("season", String(season));
      if (mediaType === "tv" && episode != null) params.set("episode", String(episode));
      if (wyzieApiKey) params.set("key", wyzieApiKey);
      const baseUrl = wyzieApiKey ? "https://sub.wyzie.io/search" : "https://subs.wyzie.ru/search";
      const res = await fetch(`${baseUrl}?${params}`);
      if (res.ok) {
        const data = await res.json();
        const items = (Array.isArray(data) ? data : []).filter(r => r.url);
        items.forEach((r, i) => {
          const rawUrl = r.url || "";
          const fullUrl = rawUrl.startsWith("http") ? rawUrl : `https://subs.wyzie.ru${rawUrl.startsWith("/") ? "" : "/"}${rawUrl}`;
          const displayName = r.display_name || r.name || r.release_name || r.fileName || `WEB-DL Subtitle #${i + 1}`;
          collected.push({
            file_id: `wyzie_${i}_${encodeURIComponent(fullUrl)}`,
            direct_url: fullUrl,
            file_name: displayName,
            language: r.language || languages || "en",
            release: displayName,
            uploader: "Wyzie",
            download_count: r.download_count || 100 - i,
            hearing_impaired: !!r.isHearingImpaired,
            ai_translated: !!r.isAiTranslated,
            via_wyzie: true
          });
        });
      }
    } catch (e) {
      errors.push(e.message);
    }
    if (String(lookupId).startsWith("tt")) {
      try {
        const osType = mediaType === "tv" ? "series" : "movie";
        const osTarget = mediaType === "tv" && season != null && episode != null ? `${lookupId}:${season}:${episode}` : String(lookupId);
        const res = await fetch(`https://opensubtitles-v3.strem.io/subtitles/${osType}/${encodeURIComponent(osTarget)}.json`);
        if (res.ok) {
          const data = await res.json();
          const subs = Array.isArray(data?.subtitles) ? data.subtitles : [];
          const wantLang = (languages || "en").split("-")[0].toLowerCase();
          subs.forEach((s, idx) => {
            if (!s.url) return;
            const sLang = String(s.lang || "").toLowerCase();
            if (wantLang && !sLang.startsWith(wantLang) && !(wantLang === "ar" && sLang === "ara") && !(wantLang === "en" && sLang === "eng")) {
              return;
            }
            collected.push({
              file_id: `wyzie_os_${idx}_${encodeURIComponent(s.url)}`,
              direct_url: s.url,
              file_name: `OpenSubtitles WEB-DL #${idx + 1} (${s.lang})`,
              language: wantLang,
              release: `WEB-DL 1080p Synced (${s.lang})`,
              uploader: "OpenSubtitles",
              download_count: 50,
              hearing_impaired: false,
              ai_translated: false,
              via_wyzie: true
            });
          });
        }
      } catch {}
    }
    if (collected.length > 0) {
      const sorted = decorateAndSort(collected);
      return {
        ok: true,
        results: sorted,
        via_wyzie: true
      };
    }
    return {
      ok: false,
      error: errors.join(" · ") || "No subtitles found for this language."
    };
  },
  getSubtitleUrl: async ({
    fileId
  }) => {
    const nativeRes = callNativeJson("getSubtitleUrl", String(fileId || ""));
    if (nativeRes && nativeRes.ok) return nativeRes;
    if (String(fileId).startsWith("wyzie_")) {
      const url = decodeURIComponent(String(fileId).split("_").slice(2).join("_"));
      return {
        ok: true,
        url,
        file_name: "",
        via_wyzie: true
      };
    }
    return {
      ok: false,
      error: "Unable to resolve subtitle URL"
    };
  },
  downloadSubtitlesForFile: async args => {
    const res = callNativeJson("downloadSubtitlesForFile", JSON.stringify(args));
    if (res) return res;
    return {
      ok: false,
      error: "Native storage required to write subtitle files"
    };
  },
  deleteSubtitleFile: async args => {
    const res = callNativeJson("deleteSubtitleFile", JSON.stringify(args));
    return res || {
      ok: true
    };
  },
  pruneSubtitlePaths: async ({
    downloadId
  }) => {
    const res = callNativeJson("pruneSubtitlePaths", String(downloadId || ""));
    return res || {
      ok: true,
      subtitlePaths: []
    };
  },
  getAppVersion: async () => {
    const isIos = !!(window.webkit?.messageHandlers?.SingularityBridge) || /iPhone|iPad|iPod/i.test(navigator.userAgent || "");
    if (isIos) return APP_VERSION;
    const v = callNativeJson("getAppVersion");
    return typeof v === "string" && v ? v : APP_VERSION;
  },
  getPlatform: async () => {
    const ua = navigator.userAgent || "";
    if (window.webkit?.messageHandlers?.SingularityBridge || /iPhone|iPad|iPod/i.test(ua)) {
      return /iPad/i.test(ua) ? "iPadOS" : "iOS";
    }
    return isAndroidTvDevice() ? "Android TV" : "Android";
  },
  setZoomFactor: factor => {
    try {
      document.documentElement.style.fontSize = `${Math.round((factor || 1) * 100)}%`;
    } catch {}
  },
  onConfirmClose: cb => addEventListenerChannel("confirm-close", cb),
  offConfirmClose: h => removeEventListenerChannel("confirm-close", h),
  respondClose: confirm => callNativeJson("respondClose", !!confirm),
  onWebviewEnterFullscreen: cb => addEventListenerChannel("webview-enter-fullscreen", cb),
  offWebviewEnterFullscreen: h => removeEventListenerChannel("webview-enter-fullscreen", h),
  onWebviewLeaveFullscreen: cb => addEventListenerChannel("webview-leave-fullscreen", cb),
  offWebviewLeaveFullscreen: h => removeEventListenerChannel("webview-leave-fullscreen", h),
  onBlockedUpdate: cb => addEventListenerChannel("blocked-stats-update", cb),
  offBlockedUpdate: h => removeEventListenerChannel("blocked-stats-update", h),
  getBlockStats: async () => {
    const res = callNativeJson("getBlockStats");
    if (res && typeof res.total === "number") return res;
    return {
      total: 0,
      domains: {}
    };
  },
  showNotification: async ({
    title,
    body,
    silent
  }) => {
    callNativeJson("showNotification", JSON.stringify({
      title,
      body,
      silent: !!silent
    }));
  },
  quitApp: async () => {
    callNativeJson("quitApp");
  },
  playerStopped: () => {
    callNativeJson("playerStopped");
  },
  getCacheSize: async () => {
    const res = callNativeJson("getCacheSize");
    return res && typeof res.bytes === "number" ? res : {
      bytes: 0
    };
  },
  clearAppCache: async () => {
    callNativeJson("clearAppCache");
    return {
      ok: true
    };
  },
  clearWatchData: async () => {
    callNativeJson("clearWatchData");
    return {
      ok: true
    };
  },
  resetApp: async () => {
    callNativeJson("resetApp");
    return {
      ok: true
    };
  },
  queryVideoProgress: async _id => {
    const res = callNativeJson("queryVideoProgress");
    return res || null;
  },
  secureGet: async key => {
    const res = callNativeJson("secureGet", String(key));
    if (res !== null && res !== undefined) {
      return typeof res === "object" ? res.value ?? null : String(res);
    }
    try {
      return localStorage.getItem(`streambert_sec_${key}`) || null;
    } catch {
      return null;
    }
  },
  secureSet: async (key, value) => {
    callNativeJson("secureSet", String(key), String(value ?? ""));
    try {
      if (!value) localStorage.removeItem(`streambert_sec_${key}`);else localStorage.setItem(`streambert_sec_${key}`, String(value));
    } catch {}
    return {
      ok: true
    };
  },
  getScheduledBackupSettings: async () => {
    const res = callNativeJson("getScheduledBackupSettings");
    if (res) return res;
    try {
      return JSON.parse(localStorage.getItem("streambert_sched_backup") || "null") || {
        enabled: false,
        path: ((typeof window !== "undefined" && window.webkit?.messageHandlers?.SingularityBridge) ? "Documents/SingularityTV/Backups" : "/storage/emulated/0/Download/SingularityTV/Backups"),
        keepCount: 5,
        frequency: "startup",
        lastRun: null
      };
    } catch {
      return {
        enabled: false,
        path: "",
        keepCount: 5,
        frequency: "startup",
        lastRun: null
      };
    }
  },
  setScheduledBackupSettings: async settings => {
    callNativeJson("setScheduledBackupSettings", JSON.stringify(settings));
    try {
      localStorage.setItem("streambert_sched_backup", JSON.stringify(settings));
    } catch {}
    return {
      ok: true
    };
  },
  performScheduledBackup: async args => {
    const res = callNativeJson("performScheduledBackup", JSON.stringify(args));
    return res || {
      ok: true
    };
  },
  onScheduledBackupRequested: cb => addEventListenerChannel("scheduled-backup-requested", cb),
  offScheduledBackupRequested: h => removeEventListenerChannel("scheduled-backup-requested", h),
  detectUpdateFormat: async () => ((typeof window !== "undefined" && window.webkit?.messageHandlers?.SingularityBridge) ? "ipa" : "apk"),
  downloadAndInstallUpdate: async args => {
    const res = callNativeJson("downloadAndInstallUpdate", JSON.stringify(args));
    return res || {
      ok: false,
      error: "Use Android package installer for APK updates"
    };
  },
  cancelUpdate: async () => {
    callNativeJson("cancelUpdate");
  },
  openDownloadedIpa: async () => {
    callNativeJson("openDownloadedIpa");
  },
  preprobeStream: payloadJson => {
    callNativeJson("preprobeStream", String(payloadJson || "{}"));
  },
  onUpdateProgress: cb => addEventListenerChannel("update-progress", cb),
  offUpdateProgress: h => removeEventListenerChannel("update-progress", h),
  fetchReleaseImage: async ({
    url
  }) => url,
  discordRpcSetEnabled: async () => ({
    ok: true
  }),
  discordRpcUpdateActivity: async () => ({
    ok: true
  }),
  startGoogleOAuth: (authUrl, scheme) => {
    const native = getNative();
    if (native && typeof native.startGoogleOAuth === "function") {
      try {
        if (typeof window !== "undefined" && window.webkit?.messageHandlers?.SingularityBridge) {
          return native.startGoogleOAuth(String(authUrl || ""), String(scheme || ""));
        }
        return native.startGoogleOAuth(String(authUrl || ""));
      } catch {}
    }
    return callNativeJson("openExternal", String(authUrl || ""));
  },
  onGoogleOAuthCallback: cb => addEventListenerChannel("google-oauth-callback", cb),
  offGoogleOAuthCallback: h => removeEventListenerChannel("google-oauth-callback", h)
};
if (typeof window !== "undefined") {
  window.androidBridge = androidBridge;
  if (!window.electron) {
    window.electron = androidBridge;
  }
}
