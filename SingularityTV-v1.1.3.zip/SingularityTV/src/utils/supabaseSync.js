import { collectBackupData, restoreBackupData, clearBackupData, mergeBackupData } from "./backup";
import { isStrictAndroidTvHardware } from "./androidBridge";

export const APP_VERSION = "1.1.3";
export const TELEGRAM_BOT_USERNAME = "SingularityTV_Official_Bot";
export const TELEGRAM_CHANNEL_URL = "https://t.me/+IUpscNRqcqc4Y2Zk";

const SUPABASE_URL = "https://soufctreejgcpvqftxeb.supabase.co";
const SUPABASE_WS_URL = "wss://soufctreejgcpvqftxeb.supabase.co/realtime/v1/websocket";
const SUPABASE_KEY = "sb_publishable_CRHhsCu1wvqdK7lUok8VfQ_IOBUqwJI";
const SESSION_KEY = "singularity_sb_session";
const LAST_SYNC_KEY = "singularity_sb_last_sync";
const LOCAL_VAULT_PREFIX = "singularity_vault_";

function authHeaders(accessToken) {
  const h = {
    apikey: SUPABASE_KEY,
    "Content-Type": "application/json"
  };
  if (accessToken) {
    h.Authorization = `Bearer ${accessToken}`;
  }
  return h;
}

export function compareVersions(a, b) {
  const pa = String(a || "0").replace(/^v/i, "").split(".").map(n => parseInt(n, 10) || 0);
  const pb = String(b || "0").replace(/^v/i, "").split(".").map(n => parseInt(n, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const x = pa[i] || 0;
    const y = pb[i] || 0;
    if (x > y) return 1;
    if (x < y) return -1;
  }
  return 0;
}

function normalizeUser(rawUser, fallbackEmail = "", fallbackName = "") {
  if (!rawUser) return null;
  const email = String(rawUser.email || fallbackEmail || "").trim().toLowerCase();
  const metaName = rawUser.user_metadata?.name || rawUser.user_metadata?.full_name || "";
  const name = String(metaName || fallbackName || (email ? email.split("@")[0] : "User")).trim();
  return {
    id: rawUser.id || "",
    email,
    name
  };
}

function saveSession(payload, fallbackEmail = "", fallbackName = "") {
  if (!payload || !payload.access_token || !payload.user) return null;
  const user = normalizeUser(payload.user, fallbackEmail, fallbackName);
  const expiresIn = Number(payload.expires_in || 3600);
  const expiresAt = payload.expires_at ? Number(payload.expires_at) * 1000 : Date.now() + expiresIn * 1000;
  const session = {
    access_token: payload.access_token,
    refresh_token: payload.refresh_token || "",
    expires_at: expiresAt,
    user
  };
  try {
    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  } catch {}
  return session;
}

export function getAuthSession() {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || !parsed.access_token || !parsed.user?.id) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function getAuthUser() {
  return getAuthSession()?.user || null;
}

export function getLastCloudSyncTime() {
  try {
    return Number(localStorage.getItem(LAST_SYNC_KEY) || 0);
  } catch {
    return 0;
  }
}

export function saveAccountSnapshotLocally(user = getAuthUser()) {
  if (!user || !user.email) return null;
  const payload = {
    email: user.email,
    name: user.name || user.email.split("@")[0],
    updatedAt: Date.now(),
    data: collectBackupData()
  };
  try {
    localStorage.setItem(LOCAL_VAULT_PREFIX + user.email.toLowerCase(), JSON.stringify(payload));
    localStorage.setItem(LAST_SYNC_KEY, String(payload.updatedAt));
  } catch {}
  return payload;
}

export function restoreAccountSnapshotLocally(email) {
  const clean = String(email || "").trim().toLowerCase();
  if (!clean) return false;
  try {
    const raw = localStorage.getItem(LOCAL_VAULT_PREFIX + clean);
    if (!raw) return false;
    const parsed = JSON.parse(raw);
    if (parsed && parsed.data && typeof parsed.data === "object") {
      restoreBackupData(parsed.data);
      return true;
    }
  } catch {}
  return false;
}

function extractApiError(json, fallback) {
  return json?.msg || json?.error_description || json?.message || json?.error || fallback;
}

export async function signUpWithEmail(email, password, name) {
  const cleanEmail = String(email || "").trim().toLowerCase();
  const cleanName = String(name || "").trim() || cleanEmail.split("@")[0];
  if (!cleanEmail || !cleanEmail.includes("@")) {
    throw new Error("Please enter a valid email address.");
  }
  if (!password || password.length < 6) {
    throw new Error("Password must be at least 6 characters.");
  }
  const res = await fetch(`${SUPABASE_URL}/auth/v1/signup`, {
    method: "POST",
    headers: authHeaders(),
    body: JSON.stringify({
      email: cleanEmail,
      password,
      data: { name: cleanName }
    })
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(extractApiError(json, "Could not create account."));
  }
  if (json.access_token && json.user) {
    clearBackupData();
    const session = saveSession(json, cleanEmail, cleanName);
    await pushToSupabase().catch(() => {});
    window.dispatchEvent(new CustomEvent("singularity:auth-changed", { detail: session.user }));
    return { needsVerification: false, user: session.user };
  }
  if (Array.isArray(json.identities) && json.identities.length === 0) {
    throw new Error("An account with this email already exists. Please sign in instead.");
  }
  return { needsVerification: true, email: cleanEmail };
}

export async function resendSignupOtp(email) {
  const cleanEmail = String(email || "").trim().toLowerCase();
  const res = await fetch(`${SUPABASE_URL}/auth/v1/resend`, {
    method: "POST",
    headers: authHeaders(),
    body: JSON.stringify({
      type: "signup",
      email: cleanEmail
    })
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(extractApiError(json, "Could not resend verification code."));
  }
  return true;
}

export async function verifyEmailOtp(email, token, type = "signup") {
  const cleanEmail = String(email || "").trim().toLowerCase();
  const cleanToken = String(token || "").replace(/\D/g, "").trim();
  if (cleanToken.length !== 6) {
    throw new Error("Please enter the 6-digit verification code.");
  }
  const res = await fetch(`${SUPABASE_URL}/auth/v1/verify`, {
    method: "POST",
    headers: authHeaders(),
    body: JSON.stringify({
      email: cleanEmail,
      token: cleanToken,
      type
    })
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok || !json.access_token) {
    throw new Error(extractApiError(json, "Invalid or expired verification code."));
  }
  clearBackupData();
  const session = saveSession(json, cleanEmail);
  const restored = await pullFromSupabase(false).catch(() => false);
  if (!restored) {
    await pushToSupabase().catch(() => {});
  }
  window.dispatchEvent(new CustomEvent("singularity:auth-changed", { detail: session.user }));
  return { user: session.user, restoredFromCloud: restored };
}

export async function signInWithEmail(email, password) {
  const cleanEmail = String(email || "").trim().toLowerCase();
  if (!cleanEmail || !cleanEmail.includes("@")) {
    throw new Error("Please enter a valid email address.");
  }
  if (!password) {
    throw new Error("Please enter your password.");
  }
  const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
    method: "POST",
    headers: authHeaders(),
    body: JSON.stringify({
      email: cleanEmail,
      password
    })
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok || !json.access_token) {
    const msg = extractApiError(json, "Invalid email or password.");
    const err = new Error(msg);
    if (/not confirmed/i.test(msg)) {
      err.code = "EMAIL_NOT_CONFIRMED";
    }
    throw err;
  }
  clearBackupData();
  const session = saveSession(json, cleanEmail);
  let restored = false;
  try {
    restored = await pullFromSupabase(false);
  } catch {}
  if (!restored) {
    restoreAccountSnapshotLocally(cleanEmail);
    await pushToSupabase().catch(() => {});
  }
  window.dispatchEvent(new CustomEvent("singularity:auth-changed", { detail: session.user }));
  return { user: session.user, restoredFromCloud: restored };
}

export async function requestPasswordReset(email) {
  const cleanEmail = String(email || "").trim().toLowerCase();
  if (!cleanEmail || !cleanEmail.includes("@")) {
    throw new Error("Please enter a valid email address.");
  }
  const res = await fetch(`${SUPABASE_URL}/auth/v1/recover`, {
    method: "POST",
    headers: authHeaders(),
    body: JSON.stringify({
      email: cleanEmail
    })
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(extractApiError(json, "Could not send password reset code."));
  }
  return true;
}

export async function completePasswordReset(email, token, newPassword) {
  const cleanEmail = String(email || "").trim().toLowerCase();
  const cleanToken = String(token || "").replace(/\D/g, "").trim();
  if (cleanToken.length !== 6) {
    throw new Error("Please enter the 6-digit reset code.");
  }
  if (!newPassword || newPassword.length < 6) {
    throw new Error("New password must be at least 6 characters.");
  }
  const verifyRes = await fetch(`${SUPABASE_URL}/auth/v1/verify`, {
    method: "POST",
    headers: authHeaders(),
    body: JSON.stringify({
      email: cleanEmail,
      token: cleanToken,
      type: "recovery"
    })
  });
  const verifyJson = await verifyRes.json().catch(() => ({}));
  if (!verifyRes.ok || !verifyJson.access_token) {
    throw new Error(extractApiError(verifyJson, "Invalid or expired reset code."));
  }
  clearBackupData();
  const session = saveSession(verifyJson, cleanEmail);
  const updateRes = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
    method: "PUT",
    headers: authHeaders(session.access_token),
    body: JSON.stringify({
      password: newPassword
    })
  });
  const updateJson = await updateRes.json().catch(() => ({}));
  if (!updateRes.ok) {
    throw new Error(extractApiError(updateJson, "Could not update password."));
  }
  const restored = await pullFromSupabase(false).catch(() => false);
  window.dispatchEvent(new CustomEvent("singularity:auth-changed", { detail: session.user }));
  return { user: session.user, restoredFromCloud: restored };
}

export async function refreshSupabaseSession() {
  const current = getAuthSession();
  if (!current?.refresh_token) return null;
  const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
    method: "POST",
    headers: authHeaders(),
    body: JSON.stringify({
      refresh_token: current.refresh_token
    })
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok || !json.access_token) return null;
  return saveSession(json, current.user?.email, current.user?.name);
}

export async function ensureValidSession(forceRefresh = false) {
  const current = getAuthSession();
  if (!current) return null;
  const needsRefresh = forceRefresh || (current.expires_at && Date.now() >= current.expires_at - 120000);
  if (needsRefresh && current.refresh_token) {
    const fresh = await refreshSupabaseSession().catch(() => null);
    if (fresh) return fresh;
  }
  return current;
}

async function fetchRemoteSyncData(session) {
  const url = `${SUPABASE_URL}/rest/v1/user_sync?user_id=eq.${encodeURIComponent(session.user.id)}&select=data,updated_at`;
  let res = await fetch(url, {
    method: "GET",
    headers: authHeaders(session.access_token)
  });
  if (res.status === 401) {
    const refreshed = await ensureValidSession(true);
    if (refreshed) {
      res = await fetch(url, {
        method: "GET",
        headers: authHeaders(refreshed.access_token)
      });
    }
  }
  if (!res.ok) return null;
  const rows = await res.json().catch(() => []);
  const row = Array.isArray(rows) ? rows[0] : null;
  return row && row.data && typeof row.data === "object" ? row.data : null;
}

let _lastLocalMutationAt = 0;
let _pushInFlight = false;

export function markLocalSyncMutation() {
  _lastLocalMutationAt = Date.now();
}

export async function pushToSupabase() {
  _pushInFlight = true;
  _lastLocalMutationAt = Date.now();
  try {
    return await _pushToSupabaseInner();
  } finally {
    _pushInFlight = false;
  }
}

async function _pushToSupabaseInner() {
  let session = await ensureValidSession(false);
  if (!session || !session.user?.id) return { ok: false, mode: "signed_out" };
  const localData = collectBackupData();
  const remoteData = await fetchRemoteSyncData(session).catch(() => null);
  const mergedData = remoteData ? mergeBackupData(localData, remoteData) : localData;
  if (remoteData) {
    restoreBackupData(mergedData);
  }
  saveAccountSnapshotLocally(session.user);
  const body = JSON.stringify({
    user_id: session.user.id,
    email: session.user.email,
    data: mergedData,
    updated_at: new Date().toISOString()
  });
  const url = `${SUPABASE_URL}/rest/v1/user_sync?on_conflict=user_id`;
  const headers = token => ({
    ...authHeaders(token),
    Prefer: "resolution=merge-duplicates,return=minimal"
  });
  let res = await fetch(url, {
    method: "POST",
    headers: headers(session.access_token),
    body
  });
  if (res.status === 401) {
    const refreshed = await ensureValidSession(true);
    if (refreshed) {
      session = refreshed;
      res = await fetch(url, {
        method: "POST",
        headers: headers(session.access_token),
        body
      });
    }
  }
  if (!res.ok) {
    throw new Error("Could not sync account data to cloud.");
  }
  const now = Date.now();
  try {
    localStorage.setItem(LAST_SYNC_KEY, String(now));
  } catch {}
  return { ok: true, mode: "supabase", updatedAt: now };
}

export async function pullFromSupabase(shouldMerge = true) {
  const session = await ensureValidSession(false);
  if (!session || !session.user?.id) return false;
  const remoteData = await fetchRemoteSyncData(session);
  if (!remoteData) return false;
  const finalData = shouldMerge ? mergeBackupData(collectBackupData(), remoteData) : remoteData;
  restoreBackupData(finalData);
  try {
    localStorage.setItem(LAST_SYNC_KEY, String(Date.now()));
  } catch {}
  return true;
}


const DEVICE_ID_KEY = "singularity_device_id";

export function getDeviceId() {
  try {
    let id = localStorage.getItem(DEVICE_ID_KEY);
    if (!id) {
      id = "dev_" + Math.random().toString(36).slice(2, 10) + "_" + Date.now().toString(36);
      localStorage.setItem(DEVICE_ID_KEY, id);
    }
    return id;
  } catch {
    return "dev_default";
  }
}

export function getDeviceName() {
  try {
    const ua = navigator.userAgent || "";
    if (window.webkit?.messageHandlers?.SingularityBridge || /iPhone|iPad|iPod/i.test(ua)) {
      return /iPad/i.test(ua) ? "iPad" : "iPhone";
    }
    if (window.AndroidBridge?.isAndroidTv?.() || /Android TV|SmartTV|AFT|BRAVIA|SHIELD|MIBOX|GoogleTV/i.test(ua)) {
      return "Android TV";
    }
    if (/Android/i.test(ua)) return "Android Phone";
    return "Web Player";
  } catch {
    return "Another Device";
  }
}

export function setLocalLivePlayback(info) {
  try {
    const payload = {
      ...(info || {}),
      deviceId: getDeviceId(),
      deviceName: getDeviceName(),
      updatedAt: Date.now()
    };
    localStorage.setItem("streambert__livePlayback", JSON.stringify(payload));
    window.dispatchEvent(new CustomEvent("singularity:live-sync-updated"));
  } catch {}
}

export function getActiveRemotePlayback() {
  try {
    const raw = localStorage.getItem("streambert__livePlayback");
    if (!raw) return null;
    const lp = JSON.parse(raw);
    if (!lp || !lp.isPlaying) return null;
    if (lp.deviceId && lp.deviceId === getDeviceId()) return null;
    const age = Date.now() - Number(lp.updatedAt || 0);
    if (age < 0 || age > 25000) return null;
    return lp;
  } catch {
    return null;
  }
}

export function formatLiveTime(sec) {
  const s = Math.max(0, Math.floor(Number(sec || 0)));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const rem = s % 60;
  return h > 0 ? `${h}:${String(m).padStart(2, "0")}:${String(rem).padStart(2, "0")}` : `${m}:${String(rem).padStart(2, "0")}`;
}

export function subscribeRealtimeSync(onRemoteMerged) {
  let closed = false;
  let ws = null;
  let hbTimer = null;
  let reconnectTimer = null;
  let refCounter = 1;

  const connect = async () => {
    if (closed) return;
    const session = await ensureValidSession(false);
    if (!session?.access_token || !session?.user?.id) return;
    try {
      ws = new WebSocket(`${SUPABASE_WS_URL}?apikey=${encodeURIComponent(SUPABASE_KEY)}&vsn=1.0.0`);
    } catch {
      reconnectTimer = setTimeout(connect, 5000);
      return;
    }

    ws.onopen = () => {
      if (closed || !ws) return;
      const joinMsg = {
        topic: "realtime:public:user_sync",
        event: "phx_join",
        payload: {
          config: {
            broadcast: { self: false },
            presence: { key: "" },
            postgres_changes: [
              {
                event: "*",
                schema: "public",
                table: "user_sync",
                filter: `user_id=eq.${session.user.id}`
              }
            ]
          },
          access_token: session.access_token
        },
        ref: String(refCounter++)
      };
      try {
        ws.send(JSON.stringify(joinMsg));
      } catch {}
      hbTimer = setInterval(() => {
        if (ws && ws.readyState === WebSocket.OPEN) {
          try {
            ws.send(JSON.stringify({ topic: "phoenix", event: "heartbeat", payload: {}, ref: String(refCounter++) }));
          } catch {}
        }
      }, 25000);
    };

    ws.onmessage = evt => {
      try {
        const msg = JSON.parse(evt.data);
        if (msg?.event === "postgres_changes") {
          if (_pushInFlight || (Date.now() - _lastLocalMutationAt < 2500)) return;
          const rec = msg?.payload?.data?.record;
          if (rec && rec.data && typeof rec.data === "object") {
            const merged = mergeBackupData(collectBackupData(), rec.data);
            restoreBackupData(merged);
            localStorage.setItem(LAST_SYNC_KEY, String(Date.now()));
            onRemoteMerged?.(merged);
          }
        }
      } catch {}
    };

    ws.onclose = () => {
      if (hbTimer) clearInterval(hbTimer);
      hbTimer = null;
      if (!closed) {
        reconnectTimer = setTimeout(connect, 4500);
      }
    };

    ws.onerror = () => {
      try {
        ws?.close();
      } catch {}
    };
  };

  connect();

  let lastPollSignature = "";
  let pollBusy = false;
  const pollTimer = setInterval(async () => {
    if (closed || pollBusy || _pushInFlight || (Date.now() - _lastLocalMutationAt < 3500)) return;
    if (typeof document !== "undefined" && document.visibilityState !== "visible") return;
    pollBusy = true;
    try {
      const session = await ensureValidSession(false);
      if (!session?.access_token || !session?.user?.id) return;
      const remoteData = await fetchRemoteSyncData(session);
      if (!remoteData) return;
      const sig = JSON.stringify({
        st: remoteData._settingsTs || 0,
        lp: remoteData._livePlayback?.updatedAt || 0,
        lpp: remoteData._livePlayback?.positionSec || 0,
        lpi: !!remoteData._livePlayback?.isPlaying,
        pt: Object.keys(remoteData._progressTs || {}).length,
        pm: Math.max(0, ...Object.values(remoteData._progressTs || {}).map(Number)),
        hl: Array.isArray(remoteData.history) ? remoteData.history[0]?.watchedAt || 0 : 0
      });
      if (sig !== lastPollSignature) {
        lastPollSignature = sig;
        const merged = mergeBackupData(collectBackupData(), remoteData);
        restoreBackupData(merged);
        localStorage.setItem(LAST_SYNC_KEY, String(Date.now()));
        onRemoteMerged?.(merged);
      }
    } catch {} finally {
      pollBusy = false;
    }
  }, 4000);

  return () => {
    closed = true;
    clearInterval(pollTimer);
    if (hbTimer) clearInterval(hbTimer);
    if (reconnectTimer) clearTimeout(reconnectTimer);
    try {
      ws?.close();
    } catch {}
  };
}

export async function checkTelegramAndReleaseGate() {
  const session = await ensureValidSession(false);
  if (!session?.access_token) {
    return { ready: true, member: false, release: null };
  }
  try {
    const res = await fetch(`${SUPABASE_URL}/functions/v1/telegram-gate`, {
      method: "POST",
      headers: authHeaders(session.access_token),
      body: JSON.stringify({ action: "check" })
    });
    if (res.ok) {
      const json = await res.json().catch(() => null);
      if (json && typeof json.member === "boolean") {
        const rel = json.release || null;
        const needsUpdate = !!(rel && rel.force_update && compareVersions(APP_VERSION, rel.min_required_version) < 0);
        const tvExempt = isStrictAndroidTvHardware();
        return {
          ready: true,
          edgeActive: true,
          member: tvExempt ? true : json.member,
          linked: !!json.linked,
          leftChannel: tvExempt ? false : !!json.leftChannel,
          channelUrl: json.channelUrl || rel?.channel_url || TELEGRAM_CHANNEL_URL,
          release: rel,
          needsUpdate
        };
      }
    }
  } catch {}

  try {
    const relRes = await fetch(`${SUPABASE_URL}/rest/v1/app_releases?id=eq.1&select=*`, {
      headers: authHeaders(session.access_token)
    });
    if (relRes.ok) {
      const rows = await relRes.json().catch(() => []);
      const rel = Array.isArray(rows) ? rows[0] : null;
      const needsUpdate = !!(rel && rel.force_update && compareVersions(APP_VERSION, rel.min_required_version) < 0);
      return {
        ready: true,
        edgeActive: false,
        member: true,
        linked: false,
        leftChannel: false,
        channelUrl: rel?.channel_url || TELEGRAM_CHANNEL_URL,
        release: rel,
        needsUpdate
      };
    }
  } catch {}

  return {
    ready: true,
    edgeActive: false,
    member: true,
    linked: false,
    leftChannel: false,
    channelUrl: TELEGRAM_CHANNEL_URL,
    release: null,
    needsUpdate: false
  };
}

export async function signOutAccount() {
  const current = getAuthSession();
  if (current) {
    try {
      await pushToSupabase();
    } catch {}
    try {
      await fetch(`${SUPABASE_URL}/auth/v1/logout`, {
        method: "POST",
        headers: authHeaders(current.access_token)
      });
    } catch {}
  }
  try {
    localStorage.removeItem(SESSION_KEY);
    localStorage.removeItem(LAST_SYNC_KEY);
  } catch {}
  clearBackupData();
  window.dispatchEvent(new CustomEvent("singularity:auth-changed", { detail: null }));
}
