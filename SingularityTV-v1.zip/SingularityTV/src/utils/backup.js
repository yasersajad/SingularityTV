const PREFIX = "streambert_";
export const BACKUP_KEYS = ["saved", "savedOrder", "history", "progress", "watched", "homeRowOrder", "homeRowVisible", "homeViewMode", "startPage", "playerSource", "hianimeDubMode", "introSkipMode", "ageLimit", "ratingCountry", "watchedThreshold", "autoplayNextEnabled", "autoplayNextDuration", "autoplayNextLayout", "subtitleDownload", "subtitleLang", "downloadPath", "downloaderFolder", "invidiousBase", "autoCheckUpdates", "searchHistory", "accentColor", "fontSize", "compactMode", "reduceAnimations", "librarySort", "historyEnabled", "tmdbLang", "notifyDownloadComplete", "notifyNewEpisode", "episodeReleaseCache", "favorites", "subTextSize", "subTextColor", "subBgStyle", "subBottomOffset", "seriesPrefs", "embedMovieTemplate", "embedTvTemplate", "theme", "customThemeVars", "accentInPlayer"];
export function collectBackupData() {
  const data = {};
  for (const key of BACKUP_KEYS) {
    try {
      const raw = localStorage.getItem(PREFIX + key);
      if (raw !== null) data[key] = JSON.parse(raw);
    } catch {}
  }
  const dlTimes = {};
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(PREFIX + "dlTime_")) {
        const raw = localStorage.getItem(k);
        if (raw !== null) dlTimes[k.slice(PREFIX.length)] = JSON.parse(raw);
      }
    }
  } catch {}
  if (Object.keys(dlTimes).length > 0) {
    data._dlTimes = dlTimes;
  }
  return data;
}
export function clearBackupData() {
  for (const key of BACKUP_KEYS) {
    try {
      localStorage.removeItem(PREFIX + key);
    } catch {}
  }
  try {
    const toRemove = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && (k.startsWith(PREFIX + "dlTime_") || k.startsWith("dlTime_"))) {
        toRemove.push(k);
      }
    }
    for (const k of toRemove) {
      localStorage.removeItem(k);
    }
  } catch {}
}
export function restoreBackupData(data) {
  if (!data || typeof data !== "object") throw new Error("Invalid backup data");
  clearBackupData();
  for (const key of BACKUP_KEYS) {
    if (data[key] !== undefined && data[key] !== null) {
      localStorage.setItem(PREFIX + key, JSON.stringify(data[key]));
    }
  }
  if (data._dlTimes && typeof data._dlTimes === "object") {
    for (const [k, v] of Object.entries(data._dlTimes)) {
      try {
        localStorage.setItem(PREFIX + k, JSON.stringify(v));
      } catch {}
    }
  }
}
