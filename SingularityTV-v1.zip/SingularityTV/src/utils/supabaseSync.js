import { collectBackupData, restoreBackupData, clearBackupData } from "./backup";

const SUPABASE_URL = "https://soufctreejgcpvqftxeb.supabase.co";
const SUPABASE_KEY = "sb_publishable_CRHhsCu1wvqdK7lUok8VfQ_IOBUqwJI";
const SESSION_KEY = "singularity_sb_session";
const LAST_SYNC_KEY = "singularity_sb_last_sync";
const LOCAL_VAULT_PREFIX = "singularity_vault_";

function authHeaders(accessToken) {
  const h = {
    apikey: SUPABASE_KEY,
    "Content-Type": "application/json"
  };
  if (accessToken) {
    h.Authorization = `Bearer ${accessToken}`;
  }
  return h;
}

function normalizeUser(rawUser, fallbackEmail = "", fallbackName = "") {
  if (!rawUser) return null;
  const email = String(rawUser.email || fallbackEmail || "").trim().toLowerCase();
  const metaName = rawUser.user_metadata?.name || rawUser.user_metadata?.full_name || "";
  const name = String(metaName || fallbackName || (email ? email.split("@")[0] : "User")).trim();
  return {
    id: rawUser.id || "",
    email,
    name
  };
}

function saveSession(payload, fallbackEmail = "", fallbackName = "") {
  if (!payload || !payload.access_token || !payload.user) return null;
  const user = normalizeUser(payload.user, fallbackEmail, fallbackName);
  const expiresIn = Number(payload.expires_in || 3600);
  const expiresAt = payload.expires_at ? Number(payload.expires_at) * 1000 : Date.now() + expiresIn * 1000;
  const session = {
    access_token: payload.access_token,
    refresh_token: payload.refresh_token || "",
    expires_at: expiresAt,
    user
  };
  try {
    localStorage.setItem(SESSION_KEY, JSON.stringify(session));
  } catch {}
  return session;
}

export function getAuthSession() {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw);
    if (!parsed || !parsed.access_token || !parsed.user?.id) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function getAuthUser() {
  return getAuthSession()?.user || null;
}

export function getLastCloudSyncTime() {
  try {
    return Number(localStorage.getItem(LAST_SYNC_KEY) || 0);
  } catch {
    return 0;
  }
}

export function saveAccountSnapshotLocally(user = getAuthUser()) {
  if (!user || !user.email) return null;
  const payload = {
    email: user.email,
    name: user.name || user.email.split("@")[0],
    updatedAt: Date.now(),
    data: collectBackupData()
  };
  try {
    localStorage.setItem(LOCAL_VAULT_PREFIX + user.email.toLowerCase(), JSON.stringify(payload));
    localStorage.setItem(LAST_SYNC_KEY, String(payload.updatedAt));
  } catch {}
  return payload;
}

export function restoreAccountSnapshotLocally(email) {
  const clean = String(email || "").trim().toLowerCase();
  if (!clean) return false;
  try {
    const raw = localStorage.getItem(LOCAL_VAULT_PREFIX + clean);
    if (!raw) return false;
    const parsed = JSON.parse(raw);
    if (parsed && parsed.data && typeof parsed.data === "object") {
      restoreBackupData(parsed.data);
      return true;
    }
  } catch {}
  return false;
}

function extractApiError(json, fallback) {
  return json?.msg || json?.error_description || json?.message || json?.error || fallback;
}

export async function signUpWithEmail(email, password, name) {
  const cleanEmail = String(email || "").trim().toLowerCase();
  const cleanName = String(name || "").trim() || cleanEmail.split("@")[0];
  if (!cleanEmail || !cleanEmail.includes("@")) {
    throw new Error("Please enter a valid email address.");
  }
  if (!password || password.length < 6) {
    throw new Error("Password must be at least 6 characters.");
  }
  const res = await fetch(`${SUPABASE_URL}/auth/v1/signup`, {
    method: "POST",
    headers: authHeaders(),
    body: JSON.stringify({
      email: cleanEmail,
      password,
      data: { name: cleanName }
    })
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(extractApiError(json, "Could not create account."));
  }
  if (json.access_token && json.user) {
    clearBackupData();
    const session = saveSession(json, cleanEmail, cleanName);
    await pushToSupabase().catch(() => {});
    window.dispatchEvent(new CustomEvent("singularity:auth-changed", { detail: session.user }));
    return { needsVerification: false, user: session.user };
  }
  if (Array.isArray(json.identities) && json.identities.length === 0) {
    throw new Error("An account with this email already exists. Please sign in instead.");
  }
  return { needsVerification: true, email: cleanEmail };
}

export async function resendSignupOtp(email) {
  const cleanEmail = String(email || "").trim().toLowerCase();
  const res = await fetch(`${SUPABASE_URL}/auth/v1/resend`, {
    method: "POST",
    headers: authHeaders(),
    body: JSON.stringify({
      type: "signup",
      email: cleanEmail
    })
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(extractApiError(json, "Could not resend verification code."));
  }
  return true;
}

export async function verifyEmailOtp(email, token, type = "signup") {
  const cleanEmail = String(email || "").trim().toLowerCase();
  const cleanToken = String(token || "").replace(/\D/g, "").trim();
  if (cleanToken.length !== 6) {
    throw new Error("Please enter the 6-digit verification code.");
  }
  const res = await fetch(`${SUPABASE_URL}/auth/v1/verify`, {
    method: "POST",
    headers: authHeaders(),
    body: JSON.stringify({
      email: cleanEmail,
      token: cleanToken,
      type
    })
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok || !json.access_token) {
    throw new Error(extractApiError(json, "Invalid or expired verification code."));
  }
  clearBackupData();
  const session = saveSession(json, cleanEmail);
  const restored = await pullFromSupabase().catch(() => false);
  if (!restored) {
    await pushToSupabase().catch(() => {});
  }
  window.dispatchEvent(new CustomEvent("singularity:auth-changed", { detail: session.user }));
  return { user: session.user, restoredFromCloud: restored };
}

export async function signInWithEmail(email, password) {
  const cleanEmail = String(email || "").trim().toLowerCase();
  if (!cleanEmail || !cleanEmail.includes("@")) {
    throw new Error("Please enter a valid email address.");
  }
  if (!password) {
    throw new Error("Please enter your password.");
  }
  const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=password`, {
    method: "POST",
    headers: authHeaders(),
    body: JSON.stringify({
      email: cleanEmail,
      password
    })
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok || !json.access_token) {
    const msg = extractApiError(json, "Invalid email or password.");
    const err = new Error(msg);
    if (/not confirmed/i.test(msg)) {
      err.code = "EMAIL_NOT_CONFIRMED";
    }
    throw err;
  }
  clearBackupData();
  const session = saveSession(json, cleanEmail);
  let restored = false;
  try {
    restored = await pullFromSupabase();
  } catch {}
  if (!restored) {
    restoreAccountSnapshotLocally(cleanEmail);
    await pushToSupabase().catch(() => {});
  }
  window.dispatchEvent(new CustomEvent("singularity:auth-changed", { detail: session.user }));
  return { user: session.user, restoredFromCloud: restored };
}

export async function requestPasswordReset(email) {
  const cleanEmail = String(email || "").trim().toLowerCase();
  if (!cleanEmail || !cleanEmail.includes("@")) {
    throw new Error("Please enter a valid email address.");
  }
  const res = await fetch(`${SUPABASE_URL}/auth/v1/recover`, {
    method: "POST",
    headers: authHeaders(),
    body: JSON.stringify({
      email: cleanEmail
    })
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(extractApiError(json, "Could not send password reset code."));
  }
  return true;
}

export async function completePasswordReset(email, token, newPassword) {
  const cleanEmail = String(email || "").trim().toLowerCase();
  const cleanToken = String(token || "").replace(/\D/g, "").trim();
  if (cleanToken.length !== 6) {
    throw new Error("Please enter the 6-digit reset code.");
  }
  if (!newPassword || newPassword.length < 6) {
    throw new Error("New password must be at least 6 characters.");
  }
  const verifyRes = await fetch(`${SUPABASE_URL}/auth/v1/verify`, {
    method: "POST",
    headers: authHeaders(),
    body: JSON.stringify({
      email: cleanEmail,
      token: cleanToken,
      type: "recovery"
    })
  });
  const verifyJson = await verifyRes.json().catch(() => ({}));
  if (!verifyRes.ok || !verifyJson.access_token) {
    throw new Error(extractApiError(verifyJson, "Invalid or expired reset code."));
  }
  clearBackupData();
  const session = saveSession(verifyJson, cleanEmail);
  const updateRes = await fetch(`${SUPABASE_URL}/auth/v1/user`, {
    method: "PUT",
    headers: authHeaders(session.access_token),
    body: JSON.stringify({
      password: newPassword
    })
  });
  const updateJson = await updateRes.json().catch(() => ({}));
  if (!updateRes.ok) {
    throw new Error(extractApiError(updateJson, "Could not update password."));
  }
  const restored = await pullFromSupabase().catch(() => false);
  window.dispatchEvent(new CustomEvent("singularity:auth-changed", { detail: session.user }));
  return { user: session.user, restoredFromCloud: restored };
}

export async function refreshSupabaseSession() {
  const current = getAuthSession();
  if (!current?.refresh_token) return null;
  const res = await fetch(`${SUPABASE_URL}/auth/v1/token?grant_type=refresh_token`, {
    method: "POST",
    headers: authHeaders(),
    body: JSON.stringify({
      refresh_token: current.refresh_token
    })
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok || !json.access_token) return null;
  return saveSession(json, current.user?.email, current.user?.name);
}

export async function ensureValidSession(forceRefresh = false) {
  const current = getAuthSession();
  if (!current) return null;
  const needsRefresh = forceRefresh || (current.expires_at && Date.now() >= current.expires_at - 120000);
  if (needsRefresh && current.refresh_token) {
    const fresh = await refreshSupabaseSession().catch(() => null);
    if (fresh) return fresh;
  }
  return current;
}

export async function pushToSupabase() {
  let session = await ensureValidSession(false);
  if (!session || !session.user?.id) return { ok: false, mode: "signed_out" };
  const snapshot = saveAccountSnapshotLocally(session.user);
  const body = JSON.stringify({
    user_id: session.user.id,
    email: session.user.email,
    data: snapshot.data,
    updated_at: new Date().toISOString()
  });
  const url = `${SUPABASE_URL}/rest/v1/user_sync?on_conflict=user_id`;
  const headers = token => ({
    ...authHeaders(token),
    Prefer: "resolution=merge-duplicates,return=minimal"
  });
  let res = await fetch(url, {
    method: "POST",
    headers: headers(session.access_token),
    body
  });
  if (res.status === 401) {
    const refreshed = await ensureValidSession(true);
    if (refreshed) {
      session = refreshed;
      res = await fetch(url, {
        method: "POST",
        headers: headers(session.access_token),
        body
      });
    }
  }
  if (!res.ok) {
    throw new Error("Could not sync account data to cloud.");
  }
  const now = Date.now();
  try {
    localStorage.setItem(LAST_SYNC_KEY, String(now));
  } catch {}
  return { ok: true, mode: "supabase", updatedAt: now };
}

export async function pullFromSupabase() {
  let session = await ensureValidSession(false);
  if (!session || !session.user?.id) return false;
  const url = `${SUPABASE_URL}/rest/v1/user_sync?user_id=eq.${encodeURIComponent(session.user.id)}&select=data,updated_at`;
  let res = await fetch(url, {
    method: "GET",
    headers: authHeaders(session.access_token)
  });
  if (res.status === 401) {
    const refreshed = await ensureValidSession(true);
    if (refreshed) {
      session = refreshed;
      res = await fetch(url, {
        method: "GET",
        headers: authHeaders(session.access_token)
      });
    }
  }
  if (!res.ok) return false;
  const rows = await res.json().catch(() => []);
  const row = Array.isArray(rows) ? rows[0] : null;
  if (row && row.data && typeof row.data === "object") {
    restoreBackupData(row.data);
    try {
      localStorage.setItem(LAST_SYNC_KEY, String(Date.now()));
    } catch {}
    return true;
  }
  return false;
}

export async function signOutAccount() {
  const current = getAuthSession();
  if (current) {
    try {
      await pushToSupabase();
    } catch {}
    try {
      await fetch(`${SUPABASE_URL}/auth/v1/logout`, {
        method: "POST",
        headers: authHeaders(current.access_token)
      });
    } catch {}
  }
  try {
    localStorage.removeItem(SESSION_KEY);
    localStorage.removeItem(LAST_SYNC_KEY);
  } catch {}
  clearBackupData();
  window.dispatchEvent(new CustomEvent("singularity:auth-changed", { detail: null }));
}
