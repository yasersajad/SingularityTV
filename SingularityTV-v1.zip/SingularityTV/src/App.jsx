import { useState, useEffect, useCallback, useMemo, useRef, lazy, Suspense } from "react";
import "./utils/androidBridge";
import { isAndroidTvDevice, androidBridge } from "./utils/androidBridge";
import ErrorBoundary from "./components/ErrorBoundary";
import ExoPlayerOverlay from "./components/ExoPlayerOverlay";
import { storage, STORAGE_KEYS, clearAppCaches } from "./utils/storage";
import { applyAccentColor, applyTheme, ACCENT_PRESETS } from "./utils/appearance";
import { collectBackupData } from "./utils/backup";
import { getAuthUser, saveAccountSnapshotLocally, pushToSupabase, pullFromSupabase } from "./utils/supabaseSync";
import { LaunchSplash, AuthGate } from "./components/SplashAndAuthGate";
import { tmdbFetch, imgUrl } from "./utils/api";
import TopNav from "./components/TopNav";
import { initLiveTouch } from "./utils/liveTouch";
import SearchModal from "./components/SearchModal";
import CloseConfirmModal from "./components/CloseConfirmModal";
import UpdateModal from "./components/UpdateModal";
import { useGamepadNav } from "./utils/useGamepadNav";
const HomePage = lazy(() => import("./pages/HomePage"));
const MoviePage = lazy(() => import("./pages/MoviePage"));
const TVPage = lazy(() => import("./pages/TVPage"));
const LibraryPage = lazy(() => import("./pages/LibraryPage"));
const SettingsPage = lazy(() => import("./pages/SettingsPage"));
const DownloadsPage = lazy(() => import("./pages/DownloadsPage"));
import { checkForUpdatesWithFallback, DEFAULT_UPDATE_SOURCE } from "./utils/updates";
export default function App() {
  const apiKey = "KEYLESS_ANDROID_MODE";
  const [showSplash, setShowSplash] = useState(true);
  const [authUser, setAuthUser] = useState(() => getAuthUser());
  const [authVersion, setAuthVersion] = useState(0);
  const [page, setPage] = useState(() => storage.get("startPage") || "home");
  const [selected, setSelected] = useState(null);
  const [showSearch, setShowSearch] = useState(false);
  const [savedSearchQuery, setSavedSearchQuery] = useState("");
  const [savedSearchLang, setSavedSearchLang] = useState("en");
  const showSearchRef = useRef(false);
  useEffect(() => {
    showSearchRef.current = showSearch;
  }, [showSearch]);
  const [dlSearchOpen, setDlSearchOpen] = useState(false);
  const [librarySort, setLibrarySort] = useState(() => storage.get(STORAGE_KEYS.LIBRARY_SORT) || "manual");
  const [isTvMode, setIsTvMode] = useState(() => isAndroidTvDevice());
  const [exoSession, setExoSession] = useState(null);
  const [navStack, setNavStack] = useState([]);
  const [saved, setSaved] = useState(() => storage.get("saved") || {});
  const [savedOrder, setSavedOrder] = useState(() => storage.get("savedOrder") || null);
  const [progress, setProgress] = useState(() => storage.get("progress") || {});
  const [history, setHistory] = useState(() => storage.get("history") || []);
  const [watched, setWatched] = useState(() => storage.get("watched") || {});
  const [toast, setToast] = useState(null);
  const [updateBanner, setUpdateBanner] = useState(null);
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [episodeCheckStatus, setEpisodeCheckStatus] = useState(null);
  const episodeDismissTimerRef = useRef(null);
  const [trending, setTrending] = useState([]);
  const [trendingTV, setTrendingTV] = useState([]);
  const [loadingHome, setLoadingHome] = useState(false);
  const [offline, setOffline] = useState(() => !navigator.onLine);
  const readPlayerSettings = () => {
    const accentId = storage.get(STORAGE_KEYS.ACCENT_COLOR) || "red";
    const inPlayer = storage.get(STORAGE_KEYS.ACCENT_IN_PLAYER) !== false;
    const accentHex = inPlayer ? ACCENT_PRESETS.find(p => p.id === accentId)?.color ?? null : null;
    const subtitleLang = storage.get(STORAGE_KEYS.SUBTITLE_LANG) || null;
    return {
      accentColor: accentHex,
      subtitleLang
    };
  };
  const [playerSettings, setPlayerSettings] = useState(readPlayerSettings);
  useEffect(() => {
    initLiveTouch();
    const h = window.electron?.onPreferredSourceUpdated?.(srcId => {
      if (srcId && typeof srcId === "string") {
        storage.set("playerSource", srcId);
      }
    });
    return () => {
      if (h) window.electron?.offPreferredSourceUpdated?.(h);
    };
  }, []);
  useEffect(() => {
    const updateDeviceClass = () => {
      const tv = isAndroidTvDevice();
      setIsTvMode(tv);
      document.documentElement.setAttribute("data-device-type", tv ? "tv" : "mobile");
      document.body.classList.toggle("tv-mode", tv);
    };
    updateDeviceClass();
    window.addEventListener("streambert:tv-mode-changed", updateDeviceClass);
    return () => window.removeEventListener("streambert:tv-mode-changed", updateDeviceClass);
  }, []);
  useEffect(() => {
    const h = androidBridge.onM3u8Found ? null : null;
    const handler = args => setExoSession(args);
    window.addEventListener("streambert:open-exo-overlay", e => setExoSession(e.detail));
    return () => {};
  }, []);
  useEffect(() => {
    if (!window.electron?.onScheduledBackupRequested) return;
    const handler = window.electron.onScheduledBackupRequested(async () => {
      try {
        const settings = await window.electron.getScheduledBackupSettings();
        if (!settings?.enabled || !settings?.path) return;
        const data = collectBackupData();
        await window.electron.performScheduledBackup({
          data,
          settings
        });
      } catch {}
    });
    return () => window.electron.offScheduledBackupRequested(handler);
  }, []);
  useEffect(() => {
    if (!window.electron?.getAppVersion) return;
    window.electron.getAppVersion().then(version => {
      const lastVersion = localStorage.getItem("streambert_lastVersion");
      if (lastVersion && lastVersion !== version) {
        clearAppCaches();
      }
      localStorage.setItem("streambert_lastVersion", version);
    });
  }, []);
  useEffect(() => {
    const source = storage.get(STORAGE_KEYS.UPDATE_SOURCE) || DEFAULT_UPDATE_SOURCE;
    checkForUpdatesWithFallback(source).then(r => {
      if (r.hasUpdate) {
        setUpdateBanner(r);
        setShowUpdateModal(true);
      }
    }).catch(() => {});
  }, []);
  useEffect(() => {
    const notifyPref = storage.get(STORAGE_KEYS.NOTIFY_NEW_EPISODE);
    if (notifyPref === false || notifyPref === 0) return;
    let cancelled = false;
    async function checkNewEpisodes() {
      await new Promise(r => setTimeout(r, 1500));
      if (cancelled) return;
      const tvSeries = Object.values(saved).filter(item => item && item.media_type === "tv" && item.id);
      if (!tvSeries.length) return;
      const cache = storage.get(STORAGE_KEYS.EPISODE_RELEASE_CACHE) || {};
      const now = Date.now();
      const CACHE_TTL = 12 * 60 * 60 * 1000;
      const toCheck = tvSeries.filter(s => !cache[s.id] || now - (cache[s.id].checkedAt || 0) > CACHE_TTL);
      if (!toCheck.length) return;
      setEpisodeCheckStatus("checking");
      const newEpisodeEntries = [];
      for (const series of toCheck.slice(0, 6)) {
        if (cancelled) break;
        try {
          const data = await tmdbFetch(`/tv/${series.id}`);
          if (cancelled) return;
          cache[series.id] = {
            checkedAt: now
          };
        } catch {}
      }
      if (!cancelled) {
        storage.set(STORAGE_KEYS.EPISODE_RELEASE_CACHE, cache);
        setEpisodeCheckStatus(newEpisodeEntries.length ? {
          entries: newEpisodeEntries
        } : "none");
        if (newEpisodeEntries.length === 0) {
          episodeDismissTimerRef.current = setTimeout(() => {
            if (!cancelled) setEpisodeCheckStatus(null);
          }, 2000);
        }
      }
    }
    checkNewEpisodes().catch(() => {
      if (!cancelled) setEpisodeCheckStatus(null);
    });
    return () => {
      cancelled = true;
      clearTimeout(episodeDismissTimerRef.current);
    };
  }, []);
  const [downloads, setDownloads] = useState([]);
  const [highlightDownload, setHighlightDownload] = useState(null);
  const [closeConfirm, setCloseConfirm] = useState(null);
  useEffect(() => {
    if (!window.electron) return;
    const handler = window.electron.onConfirmClose(data => setCloseConfirm(data));
    return () => window.electron.offConfirmClose(handler);
  }, []);
  useEffect(() => {
    if (!window.electron) return;
    let mounted = true;
    window.electron.getDownloads().then(list => {
      if (mounted && Array.isArray(list)) {
        setDownloads(list);
      }
    });
    return () => {
      mounted = false;
    };
  }, []);
  useEffect(() => {
    if (!window.electron) return;
    const handler = window.electron.onDownloadProgress(update => {
      if (update.status === "completed" && storage.get(STORAGE_KEYS.NOTIFY_DOWNLOAD_COMPLETE) !== false && window.electron.showNotification) {
        window.electron.showNotification({
          title: "Download complete",
          body: update.name || "Your download has finished.",
          silent: false
        });
      }
      setDownloads(prev => {
        const idx = prev.findIndex(d => d.id === update.id);
        if (idx === -1) {
          if (!update.name) return prev;
          return [update, ...prev];
        }
        const updated = [...prev];
        updated[idx] = {
          ...updated[idx],
          ...update
        };
        return updated;
      });
    });
    return () => window.electron.offDownloadProgress(handler);
  }, []);
  const handleDownloadStarted = useCallback(newEntry => {
    setDownloads(prev => {
      const idx = prev.findIndex(d => d.id === newEntry.id);
      if (idx !== -1) {
        const updated = [...prev];
        updated[idx] = {
          ...updated[idx],
          ...newEntry
        };
        return updated;
      }
      return [newEntry, ...prev];
    });
  }, []);
  const handleDeleteDownload = useCallback(id => {
    setDownloads(prev => prev.filter(d => d.id !== id));
  }, []);
  const activeDownloadCount = useMemo(() => downloads.filter(d => d.status === "downloading" || d.status === "paused").length, [downloads]);
  const fetchTrending = useCallback(() => {
    const cached = storage.get("trendingCache");
    const CACHE_TTL = 30 * 60 * 1000;
    const currentLang = storage.get(STORAGE_KEYS.TMDB_LANG) || "en-US";
    if (cached && cached.ts && cached.lang === currentLang && Array.isArray(cached.movies) && cached.movies.length > 0 && Date.now() - cached.ts < CACHE_TTL) {
      setTrending(cached.movies);
      setTrendingTV(cached.tv || []);
      return;
    }
    setLoadingHome(true);
    Promise.all([tmdbFetch("/trending/movie/week"), tmdbFetch("/trending/tv/week")]).then(([m, t]) => {
      const movies = m.results || [];
      const tv = t.results || [];
      setTrending(movies);
      setTrendingTV(tv);
      storage.set("trendingCache", {
        movies,
        tv,
        ts: Date.now(),
        lang: currentLang
      });
    }).catch(() => {}).finally(() => setLoadingHome(false));
  }, []);
  useEffect(() => {
    fetchTrending();
  }, [fetchTrending]);
  const retryHome = useCallback(() => {
    if (offline) return;
    fetchTrending();
  }, [offline, fetchTrending]);
  useEffect(() => {
    const handler = e => setLibrarySort(e.detail);
    window.addEventListener("streambert:library-sort-changed", handler);
    return () => window.removeEventListener("streambert:library-sort-changed", handler);
  }, []);
  useEffect(() => {
    const handler = () => fetchTrending();
    window.addEventListener("streambert:tmdb-lang-changed", handler);
    return () => window.removeEventListener("streambert:tmdb-lang-changed", handler);
  }, [fetchTrending]);
  useEffect(() => {
    const handler = () => setPlayerSettings(readPlayerSettings());
    window.addEventListener("streambert:player-settings-changed", handler);
    return () => window.removeEventListener("streambert:player-settings-changed", handler);
  }, []);
  useEffect(() => {
    const accent = storage.get(STORAGE_KEYS.ACCENT_COLOR) || "red";
    applyAccentColor(accent);
    const theme = storage.get(STORAGE_KEYS.THEME) || "dark";
    const customVars = storage.get(STORAGE_KEYS.CUSTOM_THEME_VARS) || null;
    applyTheme(theme, customVars);
    const font = storage.get(STORAGE_KEYS.FONT_SIZE) || "normal";
    document.documentElement.style.zoom = "";
    document.documentElement.setAttribute("data-font-size", font);
    const compact = !!storage.get(STORAGE_KEYS.COMPACT_MODE);
    document.body.classList.toggle("compact-mode", compact);
    const noAnim = !!storage.get(STORAGE_KEYS.REDUCE_ANIMATIONS);
    document.body.classList.toggle("no-anim", noAnim);
  }, []);
  useEffect(() => {
    const goOnline = () => setOffline(false);
    const goOffline = () => setOffline(true);
    window.addEventListener("online", goOnline);
    window.addEventListener("offline", goOffline);
    return () => {
      window.removeEventListener("online", goOnline);
      window.removeEventListener("offline", goOffline);
    };
  }, []);
  const pageRef = useRef(page);
  const selectedRef = useRef(selected);
  useEffect(() => {
    pageRef.current = page;
  }, [page]);
  useEffect(() => {
    selectedRef.current = selected;
  }, [selected]);
  const navigateBack = useCallback(() => {
    if (document.documentElement.hasAttribute("data-player-fullscreen") && window.__streambertExitFullscreen) {
      window.__streambertExitFullscreen();
      return true;
    }
    if (showSearch) {
      setShowSearch(false);
      return true;
    }
    if (exoSession) {
      setExoSession(null);
      return true;
    }
    let handled = false;
    setNavStack(prev => {
      if (prev.length === 0) {
        if (pageRef.current !== "home") {
          setPage("home");
          setSelected(null);
          handled = true;
        }
        return prev;
      }
      handled = true;
      const last = prev[prev.length - 1];
      setPage(last.page);
      setSelected(last.selected);
      if (last.reopenSearch) {
        setShowSearch(true);
      }
      if (typeof last.scrollTop === "number") {
        setTimeout(() => {
          const m = document.querySelector(".main");
          if (m) m.scrollTop = last.scrollTop;
        }, 40);
      }
      return prev.slice(0, -1);
    });
    return handled;
  }, [showSearch, exoSession]);
  useEffect(() => {
    window.__streambertHandleBack = () => {
      return navigateBack();
    };
    const onPopState = () => {
      navigateBack();
    };
    window.addEventListener("popstate", onPopState);
    return () => window.removeEventListener("popstate", onPopState);
  }, [navigateBack]);
  const navigate = useCallback((pg, data = null) => {
    const mainEl = document.querySelector(".main");
    const currentScroll = mainEl ? mainEl.scrollTop : 0;
    const fromSearch = !!showSearchRef.current;
    setNavStack(prev => [...prev, {
      page: pageRef.current,
      selected: selectedRef.current,
      scrollTop: currentScroll,
      reopenSearch: fromSearch
    }]);
    setSelected(data);
    setPage(pg);
    setShowSearch(false);
  }, []);
  useEffect(() => {
    const handler = e => {
      if ((e.metaKey || e.ctrlKey) && e.key === "f") {
        e.preventDefault();
        setShowSearch(true);
      }
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        if (pageRef.current === "downloads") {
          e.preventDefault();
          setDlSearchOpen(true);
        }
      }
      if ((e.metaKey || e.ctrlKey) && e.key === "z" && !e.shiftKey) {
        e.preventDefault();
        navigateBack();
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [navigateBack]);
  const [gamepadEnabled, setGamepadEnabled] = useState(() => storage.get(STORAGE_KEYS.GAMEPAD_ENABLED) !== false);
  useEffect(() => {
    const handler = () => setGamepadEnabled(storage.get(STORAGE_KEYS.GAMEPAD_ENABLED) !== false);
    window.addEventListener("streambert:gamepad-settings-changed", handler);
    return () => window.removeEventListener("streambert:gamepad-settings-changed", handler);
  }, []);
  const toastTimerRef = useRef(null);
  const showToast = useCallback(msg => {
    if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    setToast(msg);
    toastTimerRef.current = setTimeout(() => setToast(null), 2500);
  }, []);
  const gamepadToastedRef = useRef(false);
  const {
    connected: gamepadConnected
  } = useGamepadNav({
    enabled: gamepadEnabled,
    onBack: navigateBack,
    onOpenSearch: () => setShowSearch(true)
  });
  useEffect(() => {
    if (!gamepadEnabled) return;
    if (gamepadConnected && !gamepadToastedRef.current) {
      gamepadToastedRef.current = true;
      showToast("Controller / Remote connected");
    }
    if (!gamepadConnected) gamepadToastedRef.current = false;
  }, [gamepadConnected, gamepadEnabled, showToast]);
  const getMediaType = useCallback(item => item.media_type || (item.first_air_date ? "tv" : "movie"), []);
  const handleSelectResult = useCallback(item => {
    navigate(item.media_type === "tv" ? "tv" : "movie", item);
  }, [navigate]);
  const savedRef = useRef(saved);
  useEffect(() => {
    savedRef.current = saved;
  }, [saved]);
  const toggleSave = useCallback(item => {
    const mt = getMediaType(item);
    const id = `${mt}_${item.id}`;
    const currentSaved = savedRef.current;
    const isRemoving = !!currentSaved[id];
    const next = {
      ...currentSaved
    };
    if (isRemoving) {
      delete next[id];
      showToast("Removed from watchlist");
      setSavedOrder(prev => {
        const currentOrder = prev || Object.keys(currentSaved);
        const newOrder = currentOrder.filter(k => k !== id);
        storage.set("savedOrder", newOrder);
        return newOrder;
      });
    } else {
      next[id] = {
        id: item.id,
        title: item.title || item.name,
        poster_path: item.poster_path,
        media_type: mt,
        vote_average: item.vote_average,
        year: (item.release_date || item.first_air_date || "").slice(0, 4)
      };
      showToast("Added to watchlist");
      setSavedOrder(prev => {
        const currentOrder = prev || Object.keys(currentSaved);
        const newOrder = [...currentOrder, id];
        storage.set("savedOrder", newOrder);
        return newOrder;
      });
    }
    setSaved(next);
    storage.set("saved", next);
  }, [showToast, getMediaType]);
  const isSaved = useCallback(item => {
    const id = `${getMediaType(item)}_${item.id}`;
    return !!saved[id];
  }, [saved, getMediaType]);
  const addHistory = useCallback(item => {
    const historyEnabled = storage.get(STORAGE_KEYS.HISTORY_ENABLED);
    if (historyEnabled === 0 || historyEnabled === false) return;
    const entry = {
      id: item.id,
      title: item.title || item.name,
      poster_path: item.poster_path,
      media_type: getMediaType(item),
      watchedAt: Date.now(),
      season: item.season != null ? Number(item.season) : null,
      episode: item.episode != null ? Number(item.episode) : null,
      episodeName: item.episodeName || null
    };
    setHistory(prev => {
      const filtered = prev.filter(h => {
        if (h.id !== entry.id || h.media_type !== entry.media_type) return true;
        if (entry.media_type === "tv") {
          return !(h.season === entry.season && h.episode === entry.episode);
        }
        return false;
      });
      const next = [entry, ...filtered].slice(0, 100);
      storage.set("history", next);
      return next;
    });
  }, [getMediaType]);
  const saveProgress = useCallback((key, pct) => {
    setProgress(prev => {
      if (prev[key] === pct) return prev;
      const next = {
        ...prev,
        [key]: pct
      };
      storage.set("progress", next);
      return next;
    });
  }, []);
  const markWatched = useCallback(key => {
    setWatched(prev => {
      const next = {
        ...prev,
        [key]: true
      };
      storage.set("watched", next);
      return next;
    });
  }, []);
  const markUnwatched = useCallback(key => {
    setWatched(prev => {
      const next = {
        ...prev
      };
      delete next[key];
      storage.set("watched", next);
      return next;
    });
  }, []);
  const removeHistory = useCallback(item => {
    setHistory(prev => {
      const next = prev.filter(h => {
        if (h.id !== item.id || h.media_type !== item.media_type) return true;
        if (item.media_type === "tv") {
          return !(h.season === item.season && h.episode === item.episode);
        }
        return false;
      });
      storage.set("history", next);
      return next;
    });
  }, []);
  useEffect(() => {
    const handler = androidBridge.onExoProgress(data => {
      if (!data || !data.progressKey) return;
      if (typeof data.percent === "number") {
        saveProgress(data.progressKey, Math.min(100, Math.round(data.percent)));
      }
      if (typeof data.positionSec === "number") {
        storage.set("dlTime_" + data.progressKey, Math.floor(data.positionSec));
      }
      if (data.watched) {
        markWatched(data.progressKey);
      } else if (typeof data.percent === "number" && data.percent > 0 && data.percent < 92) {
        markUnwatched(data.progressKey);
      }
    });
    return () => androidBridge.offExoProgress(handler);
  }, [saveProgress, markWatched, markUnwatched]);
  useEffect(() => {
    document.documentElement.setAttribute("dir", "ltr");
    document.documentElement.setAttribute("lang", "en");
  }, []);
  const reloadLocalUserState = useCallback((resetNav = false) => {
    setSaved(storage.get("saved") || {});
    setSavedOrder(storage.get("savedOrder") || null);
    setProgress(storage.get("progress") || {});
    setHistory(storage.get("history") || []);
    setWatched(storage.get("watched") || {});
    setLibrarySort(storage.get(STORAGE_KEYS.LIBRARY_SORT) || "manual");
    setPlayerSettings(readPlayerSettings());
    const accent = storage.get(STORAGE_KEYS.ACCENT_COLOR) || "red";
    applyAccentColor(accent);
    const theme = storage.get(STORAGE_KEYS.THEME) || "dark";
    const customVars = storage.get(STORAGE_KEYS.CUSTOM_THEME_VARS) || null;
    applyTheme(theme, customVars);
    const font = storage.get(STORAGE_KEYS.FONT_SIZE) || "normal";
    document.documentElement.setAttribute("data-font-size", font);
    document.body.classList.toggle("compact-mode", !!storage.get(STORAGE_KEYS.COMPACT_MODE));
    document.body.classList.toggle("no-anim", !!storage.get(STORAGE_KEYS.REDUCE_ANIMATIONS));
    if (resetNav) {
      setPage(storage.get("startPage") || "home");
      setSelected(null);
      setNavStack([]);
      setShowSearch(false);
      setExoSession(null);
      setAuthVersion(v => v + 1);
    }
  }, []);
  useEffect(() => {
    const onAuthChanged = () => {
      const u = getAuthUser();
      setAuthUser(u);
      reloadLocalUserState(true);
    };
    window.addEventListener("singularity:auth-changed", onAuthChanged);
    return () => window.removeEventListener("singularity:auth-changed", onAuthChanged);
  }, [reloadLocalUserState]);
  useEffect(() => {
    if (!authUser) return;
    let active = true;
    pullFromSupabase().then(restored => {
      if (active && restored) {
        reloadLocalUserState(false);
        setAuthVersion(v => v + 1);
      }
    }).catch(() => {});
    return () => {
      active = false;
    };
  }, [authUser, reloadLocalUserState]);
  useEffect(() => {
    const u = getAuthUser();
    if (!u) return;
    const tid = setTimeout(() => {
      saveAccountSnapshotLocally(u);
      pushToSupabase().catch(() => {});
    }, 1200);
    return () => clearTimeout(tid);
  }, [saved, savedOrder, history, progress, watched]);
  useEffect(() => {
    const onSyncNeeded = () => {
      const u = getAuthUser();
      if (u) {
        saveAccountSnapshotLocally(u);
        pushToSupabase().catch(() => {});
      }
    };
    window.addEventListener("streambert:cloud-sync-needed", onSyncNeeded);
    return () => window.removeEventListener("streambert:cloud-sync-needed", onSyncNeeded);
  }, []);
  const historyWithKeys = useMemo(() => history.filter(h => {
    if (h.media_type === "tv" && (h.season == null || h.episode == null)) return false;
    return true;
  }).map(h => ({
    ...h,
    _pk: h.media_type === "movie" ? `movie_${h.id}` : `tv_${h.id}_s${h.season}e${h.episode}`
  })), [history]);
  const { inProgress, effectiveWatched } = useMemo(() => {
    const seenShows = new Set();
    const out = [];
    const mergedWatched = { ...watched };
    for (const h of historyWithKeys) {
      const pct = progress[h._pk] || 0;
      const isEpDone = !!watched[h._pk] || pct >= 92;
      if (h.media_type === "movie") {
        if (isEpDone) {
          mergedWatched[h._pk] = true;
          continue;
        }
        if (pct > 0 && pct < 92) {
          out.push(h);
        }
        continue;
      }
      const showKey = `tv_${h.id}`;
      if (seenShows.has(showKey)) continue;
      seenShows.add(showKey);
      if (mergedWatched[showKey]) continue;
      if (!isEpDone) {
        if (pct > 0 && pct < 92) {
          out.push(h);
        }
        continue;
      }
      const validSeasons = Array.isArray(h.seasons)
        ? h.seasons.filter(s => s.season_number > 0 && s.episode_count > 0).sort((a, b) => a.season_number - b.season_number)
        : [];
      let nextS = null;
      let nextE = null;
      let seriesFinished = false;
      if (validSeasons.length > 0) {
        const curSObj = validSeasons.find(s => s.season_number === h.season);
        const nextSObj = validSeasons.find(s => s.season_number > h.season);
        if (curSObj && h.episode < curSObj.episode_count) {
          nextS = h.season;
          nextE = h.episode + 1;
        } else if (nextSObj) {
          nextS = nextSObj.season_number;
          nextE = 1;
        } else if (curSObj && h.episode >= curSObj.episode_count && !nextSObj) {
          seriesFinished = true;
        }
      } else {
        const totEp = h.totalEpisodes || 0;
        const numS = h.number_of_seasons || 0;
        if (totEp > 0 && h.episode < totEp) {
          nextS = h.season;
          nextE = h.episode + 1;
        } else if (totEp > 0 && h.episode >= totEp && numS > 0 && h.season >= numS) {
          seriesFinished = true;
        } else if (totEp > 0 && h.episode >= totEp && numS > h.season) {
          nextS = h.season + 1;
          nextE = 1;
        } else {
          nextS = h.season;
          nextE = h.episode + 1;
        }
      }
      if (seriesFinished) {
        mergedWatched[showKey] = true;
        continue;
      }
      if (nextS != null && nextE != null) {
        const nextPk = `tv_${h.id}_s${nextS}e${nextE}`;
        if (!watched[nextPk]) {
          out.push({
            ...h,
            season: nextS,
            episode: nextE,
            _pk: nextPk
          });
        }
      }
    }
    return { inProgress: out, effectiveWatched: mergedWatched };
  }, [historyWithKeys, progress, watched]);
  const savedList = useMemo(() => {
    const orderedKeys = savedOrder ? savedOrder.filter(k => saved[k]) : Object.keys(saved);
    const list = orderedKeys.map(k => saved[k]).filter(Boolean);
    if (librarySort === "title") return [...list].sort((a, b) => (a.title || "").localeCompare(b.title || ""));
    if (librarySort === "rating") return [...list].sort((a, b) => (b.vote_average || 0) - (a.vote_average || 0));
    if (librarySort === "year") return [...list].sort((a, b) => (b.year || "").localeCompare(a.year || ""));
    return list;
  }, [saved, savedOrder, librarySort]);
  const handleReorderSaved = useCallback(newOrder => {
    setSavedOrder(newOrder);
    storage.set("savedOrder", newOrder);
  }, []);
  const handleGoToDownloads = useCallback(id => {
    setHighlightDownload(id || null);
    navigate("downloads");
  }, [navigate]);
  const isDetailPage = page === "movie" || page === "tv" || page === "settings";
  if (!authUser) {
    return React.createElement(ErrorBoundary, null, React.createElement(React.Fragment, null, showSplash && React.createElement(LaunchSplash, {
      onComplete: () => setShowSplash(false)
    }), React.createElement(AuthGate, {
      onAuthenticated: () => {
        setAuthUser(getAuthUser());
        reloadLocalUserState(true);
      }
    })));
  }
  return React.createElement(ErrorBoundary, null, React.createElement(React.Fragment, null, showSplash && React.createElement(LaunchSplash, {
    onComplete: () => setShowSplash(false)
  }), React.createElement("div", {
    key: `${authUser.id || "u"}_${authVersion}`,
    className: `app-shell app-shell--topnav${isTvMode ? " app-shell--tv" : ""}${isDetailPage ? " app-shell--detail" : ""}`
  }, !isDetailPage && React.createElement(TopNav, {
    page: page,
    onNavigate: navigate,
    onSearch: () => setShowSearch(true),
    savedList: savedList,
    activeDownloads: activeDownloadCount,
    onReorderSaved: handleReorderSaved,
    onRemoveSaved: toggleSave,

  }), React.createElement("div", {
    className: "main main--full"
  }, React.createElement(Suspense, {
    fallback: React.createElement("div", {
      style: {
        color: "var(--text2)",
        padding: 48,
        textAlign: "center",
        fontSize: 15
      }
    }, "Loading\u2026")
  }, page === "home" && React.createElement(HomePage, {
    trending: trending,
    trendingTV: trendingTV,
    loading: loadingHome,
    onSelect: handleSelectResult,
    progress: progress,
    inProgress: inProgress,
    offline: offline,
    onRetry: retryHome,
    watched: effectiveWatched,
    onMarkWatched: markWatched,
    onMarkUnwatched: markUnwatched,
    history: history,
    apiKey: apiKey
  }), page === "movie" && selected && React.createElement(MoviePage, {
    item: selected,
    apiKey: apiKey,
    playerSettings: playerSettings,
    onSave: () => toggleSave(selected),
    isSaved: isSaved(selected),
    onHistory: addHistory,
    progress: progress,
    saveProgress: saveProgress,
    onBack: () => navigateBack(),
    onSettings: section => navigate("settings", {
      section: section || null
    }),
    onDownloadStarted: handleDownloadStarted,
    watched: effectiveWatched,
    onMarkWatched: markWatched,
    onMarkUnwatched: markUnwatched,
    downloads: downloads,
    onGoToDownloads: handleGoToDownloads,
    onSelect: handleSelectResult,
    onOpenExoPlayer: sessionData => setExoSession(sessionData)
  }), page === "tv" && selected && React.createElement(TVPage, {
    item: selected,
    history: history,
    apiKey: apiKey,
    playerSettings: playerSettings,
    onSave: () => toggleSave(selected),
    isSaved: isSaved(selected),
    onHistory: addHistory,
    progress: progress,
    saveProgress: saveProgress,
    onBack: () => navigateBack(),
    onSettings: section => navigate("settings", {
      section: section || null
    }),
    onDownloadStarted: handleDownloadStarted,
    watched: effectiveWatched,
    onMarkWatched: markWatched,
    onMarkUnwatched: markUnwatched,
    downloads: downloads,
    onGoToDownloads: handleGoToDownloads,
    onOpenExoPlayer: sessionData => setExoSession(sessionData)
  }), page === "history" && React.createElement(LibraryPage, {
    history: history,
    inProgress: inProgress,
    saved: savedList,
    progress: progress,
    onSelect: handleSelectResult,
    watched: effectiveWatched,
    onMarkWatched: markWatched,
    onMarkUnwatched: markUnwatched,
    onRemoveHistory: removeHistory,
    downloads: downloads,
    onOpenExoPlayer: sessionData => setExoSession(sessionData)
  }), page === "settings" && React.createElement(SettingsPage, {
    initialSection: selected?.section,
    onBack: () => {
      const moved = navigateBack();
      if (!moved || pageRef.current === "settings") {
        setPage("home");
        setSelected(null);
        setNavStack([]);
      }
    }
  }), page === "downloads" && React.createElement(DownloadsPage, {
    downloads: downloads,
    onDeleteDownload: handleDeleteDownload,
    onHistory: addHistory,
    onSaveProgress: saveProgress,
    progress: progress,
    watched: effectiveWatched,
    onMarkWatched: markWatched,
    onMarkUnwatched: markUnwatched,
    highlightId: highlightDownload,
    onClearHighlight: () => setHighlightDownload(null),
    onSelect: handleSelectResult,
    searchOpen: dlSearchOpen,
    onSearchClose: () => setDlSearchOpen(false),
    onSettings: section => navigate("settings", {
      section: section || null
    }),
    onUpdateDownload: (id, updates) => setDownloads(prev => prev.map(d => d.id === id ? {
      ...d,
      ...updates
    } : d)),
    onOpenExoPlayer: sessionData => setExoSession(sessionData)
  }))), showSearch && React.createElement(SearchModal, {
    apiKey: apiKey,
    onSelect: handleSelectResult,
    onClose: () => setShowSearch(false),
    offline: offline,
    trending: trending,
    trendingTV: trendingTV,
    watched: effectiveWatched,
    initialQuery: savedSearchQuery,
    onQueryChange: setSavedSearchQuery,
    initialLangMode: savedSearchLang,
    onLangModeChange: setSavedSearchLang
  }), exoSession && React.createElement(ExoPlayerOverlay, {
    session: exoSession,
    onClose: () => setExoSession(null),
    onProgressUpdate: (ct, dur) => {
      if (exoSession.progressKey && dur > 0) {
        const p = Math.min(100, Math.floor(ct / dur * 100));
        saveProgress(exoSession.progressKey, p);
        storage.set("dlTime_" + exoSession.progressKey, Math.floor(ct));
      }
    }
  }), updateBanner && React.createElement("div", {
    style: {
      position: "fixed",
      top: 0,
      left: 0,
      right: 0,
      zIndex: 9999,
      background: "rgba(229,9,20,0.92)",
      backdropFilter: "blur(8px)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      gap: 16,
      padding: "10px 24px",
      boxShadow: "0 2px 16px rgba(0,0,0,0.4)",
      fontSize: 14,
      fontWeight: 500,
      color: "#fff"
    }
  }, React.createElement("span", null, "SingularityTV v", updateBanner.latest, " is available!"), React.createElement("button", {
    onClick: () => setShowUpdateModal(true),
    style: {
      color: "#fff",
      fontWeight: 700,
      background: "rgba(255,255,255,0.18)",
      border: "1px solid rgba(255,255,255,0.4)",
      borderRadius: 6,
      padding: "4px 12px",
      fontSize: 13,
      cursor: "pointer"
    }
  }, "View Update"), React.createElement("button", {
    onClick: () => setUpdateBanner(null),
    style: {
      background: "transparent",
      border: "none",
      color: "rgba(255,255,255,0.7)",
      cursor: "pointer",
      fontSize: 18,
      lineHeight: 1,
      padding: "0 4px"
    },
    "aria-label": "Dismiss"
  }, "\xD7")), showUpdateModal && updateBanner && React.createElement(UpdateModal, {
    updateInfo: updateBanner,
    activeDownloads: activeDownloadCount,
    mandatory: !!updateBanner.mandatory,
    onClose: () => { if (!updateBanner.mandatory) setShowUpdateModal(false); }
  }), toast && React.createElement("div", {
    className: "toast"
  }, toast), closeConfirm && React.createElement(CloseConfirmModal, {
    count: closeConfirm.count,
    onConfirm: () => {
      setCloseConfirm(null);
      window.electron.respondClose(true);
    },
    onCancel: () => {
      setCloseConfirm(null);
      window.electron.respondClose(false);
    }
  }))));
}
