#!/usr/bin/env node

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
function resolveBabelPkg(name) {
  try { return require.resolve(name); } catch (_) { return "/usr/share/nodejs/" + name; }
}
const babel = require(resolveBabelPkg("@babel/core"));

const ROOT = path.resolve(__dirname, "..");
const SRC_DIR = path.join(ROOT, "src");
const PUBLIC_DIR = path.join(ROOT, "public");
const OUT_DIRS = [
  path.join(ROOT, "dist"),
  path.join(ROOT, "android/app/src/main/assets/public"),
];

function collectSourceFiles(dir, list = []) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      collectSourceFiles(full, list);
    } else if (/\.(jsx|js)$/.test(entry.name)) {
      list.push(full);
    }
  }
  return list;
}

function normalizeModuleId(filePath) {
  const rel = path
    .relative(SRC_DIR, filePath)
    .replace(/\\/g, "/")
    .replace(/\.(jsx|js)$/, "");
  return "./" + rel;
}

const files = collectSourceFiles(SRC_DIR);
const compiledModules = {};

for (const file of files) {
  const modId = normalizeModuleId(file);
  const code = fs.readFileSync(file, "utf8");
  const result = babel.transformSync(code, {
    filename: file,
    presets: [
      [
        resolveBabelPkg("@babel/preset-react"),
        {
          runtime: "classic",
          pragma: "React.createElement",
          pragmaFrag: "React.Fragment",
        },
      ],
    ],
    plugins: [
      resolveBabelPkg("@babel/plugin-transform-modules-commonjs"),
      resolveBabelPkg("babel-plugin-dynamic-import-node"),
    ],
    sourceMaps: false,
    comments: false,
    compact: false,
  });
  compiledModules[modId] = result.code;
}

console.log(
  `[build-android-assets] Compiled ${Object.keys(compiledModules).length} React/JS modules cleanly.`,
);

const runtimeHeader = `
(function() {

  let safeStorage;
  try {
    const testKey = "__sb_test__";
    window.localStorage.setItem(testKey, "1");
    window.localStorage.removeItem(testKey);
    safeStorage = window.localStorage;
  } catch (e) {
    const mem = new Map();
    safeStorage = {
      getItem: (k) => (mem.has(String(k)) ? mem.get(String(k)) : null),
      setItem: (k, v) => { mem.set(String(k), String(v)); },
      removeItem: (k) => { mem.delete(String(k)); },
      clear: () => { mem.clear(); },
      key: (i) => Array.from(mem.keys())[i] ?? null,
      get length() { return mem.size; }
    };
    try {
      Object.defineProperty(window, "localStorage", { value: safeStorage, configurable: true });
    } catch (_) {}
  }
  const localStorage = safeStorage;

  const componentHooksMap = new Map();
  const classInstanceMap = new Map(); 
  let compStack = [];
  let mountedKeysThisPass = new Set();
  let prevMountedKeys = new Set();
  let rootRenderFn = null;
  let renderScheduled = false;
  const pendingEffects = [];

  function getCurrentComp() {
    return compStack[compStack.length - 1] || { key: "root", hookIdx: 0 };
  }

  function getHookSlot() {
    const comp = getCurrentComp();
    if (!componentHooksMap.has(comp.key)) {
      componentHooksMap.set(comp.key, []);
    }
    const slots = componentHooksMap.get(comp.key);
    const idx = comp.hookIdx++;
    return { slots, idx, compKey: comp.key };
  }

  function scheduleRender() {
    if (renderScheduled) return;
    renderScheduled = true;
    Promise.resolve().then(() => {
      renderScheduled = false;
      if (rootRenderFn) rootRenderFn();
    });
  }

  const React = {
    Fragment: Symbol.for("react.fragment"),
    StrictMode: function StrictMode(props) { return props.children; },
    Suspense: function Suspense(props) { return props.children; },
    Component: class Component {
      constructor(props) { this.props = props || {}; this.state = {}; }
      setState(updater) {
        const next = typeof updater === "function" ? updater(this.state) : updater;
        this.state = Object.assign({}, this.state, next);
        scheduleRender();
      }
    },
    createElement(type, props, ...children) {
      const flatChildren = [];
      const pushChild = (c) => {
        if (Array.isArray(c)) c.forEach(pushChild);
        else flatChildren.push(c);
      };
      children.forEach(pushChild);
      return {
        $$typeof: Symbol.for("react.element"),
        type,
        props: Object.assign({}, props, {
          children: flatChildren.length === 0 ? undefined : flatChildren.length === 1 ? flatChildren[0] : flatChildren
        }),
        key: props && props.key !== undefined ? String(props.key) : null,
        ref: props && props.ref !== undefined ? props.ref : null,
      };
    },
    useState(initial) {
      const { slots, idx, compKey } = getHookSlot();
      if (slots[idx] === undefined) {
        slots[idx] = typeof initial === "function" ? initial() : initial;
      }
      const setState = (updater) => {
        const targetSlots = componentHooksMap.get(compKey);
        if (!targetSlots) return;
        const next = typeof updater === "function" ? updater(targetSlots[idx]) : updater;
        if (!Object.is(targetSlots[idx], next)) {
          targetSlots[idx] = next;
          scheduleRender();
        }
      };
      return [slots[idx], setState];
    },
    useRef(initial) {
      const { slots, idx } = getHookSlot();
      if (slots[idx] === undefined) {
        slots[idx] = { current: initial };
      }
      return slots[idx];
    },
    useMemo(factory, deps) {
      const { slots, idx } = getHookSlot();
      const prev = slots[idx];
      if (!prev || !deps || !prev.deps || deps.length !== prev.deps.length || deps.some((d, i) => !Object.is(d, prev.deps[i]))) {
        const val = factory();
        slots[idx] = { val, deps };
        return val;
      }
      return prev.val;
    },
    useCallback(fn, deps) {
      return React.useMemo(() => fn, deps);
    },
    useEffect(effect, deps) {
      const { slots, idx } = getHookSlot();
      const prev = slots[idx];
      const changed = !prev || !deps || !prev.deps || deps.length !== prev.deps.length || deps.some((d, i) => !Object.is(d, prev.deps[i]));
      if (changed) {
        const slotObj = { isEffect: true, deps, cleanup: prev ? prev.cleanup : null };
        slots[idx] = slotObj;
        pendingEffects.push(() => {
          if (typeof slotObj.cleanup === "function") {
            try { slotObj.cleanup(); } catch (e) {}
          }
          const c = effect();
          slotObj.cleanup = typeof c === "function" ? c : null;
        });
      }
    },
    useLayoutEffect(effect, deps) {
      return React.useEffect(effect, deps);
    },
    memo(comp) { return comp; },
    forwardRef(render) {
      return function ForwardRefWrapper(props) {
        return render(props, props.ref || null);
      };
    },
    useImperativeHandle(ref, createHandle) {
      if (ref) {
        const h = createHandle();
        if (typeof ref === "function") ref(h);
        else ref.current = h;
      }
    },
    lazy(loader) {
      let resolved = null;
      let loading = false;
      return function LazyWrapper(props) {
        if (!resolved) {
          if (!loading) {
            loading = true;
            loader().then((m) => {
              resolved = m.default || m;
              scheduleRender();
            });
          }
          return null;
        }
        return React.createElement(resolved, props);
      };
    }
  };

  const SVG_TAGS = new Set([
    "svg", "path", "circle", "rect", "line", "polyline", "polygon", "ellipse", "g", "defs", "linearGradient", "stop", "text"
  ]);
  const UNITLESS_STYLES = new Set([
    "opacity", "zIndex", "flex", "flexGrow", "flexShrink", "fontWeight", "lineHeight", "order", "zoom", "scale"
  ]);


  function expandToHostList(vnode, pathPrefix, out = []) {
    if (vnode === null || vnode === undefined || typeof vnode === "boolean") {
      out.push({ kind: "empty", key: null });
      return out;
    }
    if (typeof vnode === "string" || typeof vnode === "number") {
      out.push({ kind: "text", text: String(vnode), key: null });
      return out;
    }
    if (Array.isArray(vnode)) {
      for (let i = 0; i < vnode.length; i++) {
        expandToHostList(vnode[i], pathPrefix + "." + i, out);
      }
      return out;
    }
    if (vnode.type === React.Fragment) {
      const ch = vnode.props?.children;
      if (Array.isArray(ch)) {
        for (let i = 0; i < ch.length; i++) {
          expandToHostList(ch[i], pathPrefix + ".f" + i, out);
        }
      } else if (ch !== undefined) {
        expandToHostList(ch, pathPrefix + ".f0", out);
      }
      return out;
    }
    if (typeof vnode.type === "function") {
      const compName = vnode.type.displayName || vnode.type.name || "Anon";
      const compKey = pathPrefix + "/" + compName + (vnode.key !== null ? "#" + vnode.key : "");
      mountedKeysThisPass.add(compKey);
      compStack.push({ key: compKey, hookIdx: 0 });
      let rendered;
      try {
        if (vnode.type.prototype && vnode.type.prototype.render) {
          let inst = classInstanceMap.get(compKey);
          if (!inst) {
            inst = new vnode.type(vnode.props || {});
            classInstanceMap.set(compKey, inst);
          } else {
            inst.props = vnode.props || {};
          }
          rendered = inst.render();
        } else {
          rendered = vnode.type(vnode.props || {});
        }
      } finally {
        compStack.pop();
      }
      expandToHostList(rendered, compKey, out);
      return out;
    }
    if (typeof vnode.type === "string") {
      const props = vnode.props || {};
      const ch = props.children;
      const expandedChildren = [];
      if (Array.isArray(ch)) {
        for (let i = 0; i < ch.length; i++) {
          expandToHostList(ch[i], pathPrefix + "." + i, expandedChildren);
        }
      } else if (ch !== undefined) {
        expandToHostList(ch, pathPrefix + ".0", expandedChildren);
      }
      out.push({
        kind: "host",
        type: vnode.type,
        props,
        key: vnode.key,
        ref: vnode.ref,
        children: expandedChildren,
      });
      return out;
    }
    out.push({ kind: "empty", key: null });
    return out;
  }

  function applyProp(el, k, v, prevV, isSvg, tagType) {
    if (k === "children" || k === "key" || k === "ref") return;
    if (k === "className") {
      const nextCls = v || "";
      if (prevV !== nextCls) {
        if (isSvg) el.setAttribute("class", nextCls);
        else el.className = nextCls;
      }
      return;
    }
    if (k === "style") {
      const prevStyle = (prevV && typeof prevV === "object") ? prevV : {};
      const nextStyle = (v && typeof v === "object") ? v : {};
      for (const sk of Object.keys(prevStyle)) {
        if (!(sk in nextStyle) || nextStyle[sk] === undefined || nextStyle[sk] === null) {
          if (sk.startsWith("--")) el.style.removeProperty(sk);
          else el.style[sk] = "";
        }
      }
      for (const [sk, sv] of Object.entries(nextStyle)) {
        if (sv === undefined || sv === null) continue;
        if (prevStyle[sk] === sv) continue;
        if (sk.startsWith("--")) el.style.setProperty(sk, String(sv));
        else if (typeof sv === "number" && !UNITLESS_STYLES.has(sk)) {
          el.style[sk] = sv + "px";
        } else {
          el.style[sk] = sv;
        }
      }
      return;
    }
    if (k.startsWith("on")) {
      const rawEv = k.slice(2).toLowerCase();
      const evName = rawEv === "doubleclick" ? "dblclick" : (rawEv === "change" && tagType === "input" ? "input" : rawEv);
      if (!el.__sbListeners) el.__sbListeners = {};
      if (!el.__sbBound) el.__sbBound = {};
      el.__sbListeners[evName] = typeof v === "function" ? v : null;
      if (!el.__sbBound[evName] && typeof v === "function") {
        const wrapper = (e) => {
          const fn = el.__sbListeners && el.__sbListeners[evName];
          if (typeof fn === "function") fn(e);
        };
        el.__sbBound[evName] = wrapper;
        el.addEventListener(evName, wrapper);
      }
      return;
    }
    if (v === prevV) return;
    if (k === "src" && tagType === "iframe") {
      const nextSrc = v ? String(v) : "about:blank";
      if (el.__sbIframeSrc !== nextSrc) {
        el.__sbIframeSrc = nextSrc;
        el.setAttribute("src", nextSrc);
      }
      return;
    }
    if (k === "value" && (tagType === "input" || tagType === "textarea" || tagType === "select")) {
      const nextStr = v === undefined || v === null ? "" : String(v);
      if (el.value !== nextStr) el.value = nextStr;
      return;
    }
    if (k === "checked" && tagType === "input") {
      el.checked = !!v;
      return;
    }
    if (k === "disabled") {
      if (v) el.setAttribute("disabled", "disabled");
      else el.removeAttribute("disabled");
      return;
    }
    if (v === undefined || v === null || v === false) {
      el.removeAttribute(k);
      return;
    }
    if (v === true) {
      el.setAttribute(k, "");
      return;
    }
    const attrName = k === "viewBox" ? "viewBox" : (isSvg ? k.replace(/([A-Z])/g, (m) => "-" + m.toLowerCase()) : k);
    el.setAttribute(attrName, String(v));
  }

  function patchHostProps(el, prevProps, nextProps, isSvg, tagType) {
    for (const k of Object.keys(prevProps)) {
      if (!(k in nextProps)) {
        applyProp(el, k, undefined, prevProps[k], isSvg, tagType);
      }
    }
    for (const [k, v] of Object.entries(nextProps)) {
      applyProp(el, k, v, prevProps[k], isSvg, tagType);
    }
    el.__sbProps = nextProps;
  }

  function createDomFromDescriptor(desc) {
    if (desc.kind === "empty") {
      const c = document.createComment("sb");
      c.__sbKind = "empty";
      return c;
    }
    if (desc.kind === "text") {
      const t = document.createTextNode(desc.text);
      t.__sbKind = "text";
      return t;
    }
    const isSvg = SVG_TAGS.has(desc.type);
    const el = isSvg
      ? document.createElementNS("http://www.w3.org/2000/svg", desc.type)
      : document.createElement(desc.type);
    el.__sbKind = "host";
    el.__sbType = desc.type;
    el.__sbKey = desc.key;
    el.__sbProps = {};
    patchHostProps(el, {}, desc.props, isSvg, desc.type);
    reconcileChildren(el, desc.children);
    if (desc.ref) {
      if (typeof desc.ref === "function") desc.ref(el);
      else desc.ref.current = el;
    }
    return el;
  }

  function canReuseDom(domNode, desc) {
    if (!domNode) return false;
    if (desc.kind === "empty") return domNode.nodeType === 8 && domNode.__sbKind === "empty";
    if (desc.kind === "text") return domNode.nodeType === 3;
    if (desc.kind === "host") {
      return (
        domNode.nodeType === 1 &&
        domNode.__sbType === desc.type &&
        (domNode.__sbKey ?? null) === (desc.key ?? null)
      );
    }
    return false;
  }

  function reconcileChildren(parentDom, nextDescs) {
    const existingNodes = Array.from(parentDom.childNodes);
    const keyedMap = new Map();
    for (const node of existingNodes) {
      if (node.nodeType === 1 && node.__sbKey != null) {
        keyedMap.set(node.__sbType + "#" + node.__sbKey, node);
      }
    }

    const usedNodes = new Set();
    const finalNodes = new Array(nextDescs.length);

    for (let i = 0; i < nextDescs.length; i++) {
      const desc = nextDescs[i];
      let matched = null;

      if (desc.kind === "host" && desc.key != null) {
        const k = desc.type + "#" + desc.key;
        const cand = keyedMap.get(k);
        if (cand && !usedNodes.has(cand)) {
          matched = cand;
        }
      } else {
        const positional = existingNodes[i];
        if (positional && !usedNodes.has(positional) && canReuseDom(positional, desc)) {
          matched = positional;
        }
      }

      if (matched) {
        usedNodes.add(matched);
        if (desc.kind === "text") {
          if (matched.nodeValue !== desc.text) {
            matched.nodeValue = desc.text;
          }
        } else if (desc.kind === "host") {
          const isSvg = SVG_TAGS.has(desc.type);
          patchHostProps(matched, matched.__sbProps || {}, desc.props, isSvg, desc.type);
          reconcileChildren(matched, desc.children);
          if (desc.ref) {
            if (typeof desc.ref === "function") desc.ref(matched);
            else desc.ref.current = matched;
          }
        }
        finalNodes[i] = matched;
      } else {
        finalNodes[i] = createDomFromDescriptor(desc);
      }
    }

    for (const oldNode of existingNodes) {
      if (!usedNodes.has(oldNode) && oldNode.parentNode === parentDom) {
        parentDom.removeChild(oldNode);
      }
    }

    for (let i = 0; i < finalNodes.length; i++) {
      const node = finalNodes[i];
      const currentAtPos = parentDom.childNodes[i] || null;
      if (currentAtPos !== node) {
        parentDom.insertBefore(node, currentAtPos);
      }
    }
  }

  const ReactDOMClient = {
    createRoot(container) {
      return {
        render(element) {
          rootRenderFn = () => {
            compStack = [];
            mountedKeysThisPass = new Set();
            const hostDescs = expandToHostList(element, "root");
            reconcileChildren(container, hostDescs);

            for (const oldKey of prevMountedKeys) {
              if (!mountedKeysThisPass.has(oldKey)) {
                const slots = componentHooksMap.get(oldKey) || [];
                for (const s of slots) {
                  if (s && s.isEffect && typeof s.cleanup === "function") {
                    try { s.cleanup(); } catch (e) {}
                  }
                }
                componentHooksMap.delete(oldKey);
                classInstanceMap.delete(oldKey);
              }
            }
            prevMountedKeys = new Set(mountedKeysThisPass);
            while (pendingEffects.length > 0) {
              const eff = pendingEffects.shift();
              try { eff(); } catch (e) { console.error(e); }
            }
          };
          rootRenderFn();
        }
      };
    }
  };
  window.React = React;
  window.ReactDOM = ReactDOMClient;

  const moduleFactories = {
`;

const moduleEntries = Object.entries(compiledModules)
  .map(([id, code]) => {
    return `${JSON.stringify(id)}: function(module, exports, require) {\n${code}\n}`;
  })
  .join(",\n");

const runtimeFooter = `
  };

  const moduleCache = {};

  function resolvePath(fromId, req) {
    if (req === "react") return "react";
    if (req === "react-dom/client" || req === "react-dom") return "react-dom/client";
    if (req.endsWith(".css")) return "noop-css";
    if (!req.startsWith(".")) return req;
    const fromParts = fromId.split("/").slice(0, -1);
    const reqParts = req.replace(/\\.(jsx|js)$/, "").split("/");
    for (const part of reqParts) {
      if (part === "." || part === "") continue;
      if (part === "..") fromParts.pop();
      else fromParts.push(part);
    }
    return "./" + fromParts.filter((p) => p !== ".").join("/");
  }

  function requireModule(fromId, req) {
    const resolved = resolvePath(fromId, req);
    if (resolved === "react") return Object.assign({ default: React }, React);
    if (resolved === "react-dom/client") return Object.assign({ default: ReactDOMClient }, ReactDOMClient);
    if (resolved === "noop-css") return {};
    if (moduleCache[resolved]) return moduleCache[resolved].exports;
    const factory = moduleFactories[resolved];
    if (!factory) {
      throw new Error("Module not found: " + resolved + " (from " + fromId + ")");
    }
    const mod = { exports: {} };
    moduleCache[resolved] = mod;
    const localRequire = (childReq) => requireModule(resolved, childReq);
    factory(mod, mod.exports, localRequire);
    return mod.exports;
  }

  requireModule("./main", "./main");
})();
`;

const fullBundle = runtimeHeader + moduleEntries + runtimeFooter;

const indexHtml = `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" />
    <title>SINGULARITY WebOS</title>
    <link rel="icon" type="image/svg+xml" href="./logo.svg" />
    <link rel="stylesheet" href="./global.css?v=2703" />
    <style>*,*::before,*::after,html,body,a,button,input,select,textarea,div,span,img,svg,video,iframe,[role="button"],[tabindex]{-webkit-tap-highlight-color:rgba(0,0,0,0)!important;-webkit-tap-highlight-color:transparent!important;-webkit-focus-ring-color:rgba(0,0,0,0)!important;-webkit-touch-callout:none!important;outline:none!important;outline-color:transparent!important;}*:focus,*:focus-visible,*:active{-webkit-tap-highlight-color:rgba(0,0,0,0)!important;outline:none!important;}::selection{background:rgba(229,9,20,0.25)!important;color:#fff!important;}</style>
  </head>
  <body>
    <div id="root"></div>
    <script src="./bundle.js?v=2703"></script>
  </body>
</html>
`;

let globalCssContent = fs.readFileSync(path.join(SRC_DIR, "styles/global.css"), "utf8");
const fontsDirSrc = path.join(SRC_DIR, "styles/fonts");
if (fs.existsSync(fontsDirSrc)) {
  for (const f of fs.readdirSync(fontsDirSrc)) {
    if (f.endsWith(".woff2")) {
      const b64 = fs.readFileSync(path.join(fontsDirSrc, f)).toString("base64");
      globalCssContent = globalCssContent.split('url("fonts/' + f + '")').join('url("data:font/woff2;base64,' + b64 + '")');
    }
  }
}

const standaloneHtml = `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" />
    <title>SINGULARITY WebOS</title>
    <style>${globalCssContent}</style>
    <style>*,*::before,*::after,html,body,a,button,input,select,textarea,div,span,img,svg,video,iframe,[role="button"],[tabindex]{-webkit-tap-highlight-color:rgba(0,0,0,0)!important;-webkit-tap-highlight-color:transparent!important;-webkit-focus-ring-color:rgba(0,0,0,0)!important;-webkit-touch-callout:none!important;outline:none!important;outline-color:transparent!important;}*:focus,*:focus-visible,*:active{-webkit-tap-highlight-color:rgba(0,0,0,0)!important;outline:none!important;}::selection{background:rgba(229,9,20,0.25)!important;color:#fff!important;}</style>
  </head>
  <body>
    <div id="root"></div>
    <script>${fullBundle}</script>
  </body>
</html>
`;

const otaFingerprintJson = JSON.stringify({
  builtAtMs: Date.now(),
  appVersion: "1.1.4",
  bundleSha256: crypto.createHash("sha256").update(fullBundle, "utf8").digest("hex"),
  cssSha256: crypto.createHash("sha256").update(globalCssContent, "utf8").digest("hex")
});

for (const outDir of OUT_DIRS) {
  fs.mkdirSync(path.join(outDir, "fonts"), { recursive: true });
  fs.writeFileSync(path.join(outDir, "bundle.js"), fullBundle, "utf8");
  fs.writeFileSync(path.join(outDir, "index.html"), indexHtml, "utf8");
  fs.writeFileSync(path.join(outDir, "standalone.html"), standaloneHtml, "utf8");
  fs.writeFileSync(path.join(outDir, "global.css"), globalCssContent, "utf8");
  fs.writeFileSync(path.join(outDir, "ota-fingerprint.json"), otaFingerprintJson, "utf8");
  const fontsDir = path.join(SRC_DIR, "styles/fonts");
  for (const f of fs.readdirSync(fontsDir)) {
    fs.copyFileSync(path.join(fontsDir, f), path.join(outDir, "fonts", f));
  }
  if (fs.existsSync(path.join(PUBLIC_DIR, "logo.svg"))) {
    fs.copyFileSync(
      path.join(PUBLIC_DIR, "logo.svg"),
      path.join(outDir, "logo.svg"),
    );
  }
  if (fs.existsSync(path.join(PUBLIC_DIR, "icon.png"))) {
    fs.copyFileSync(
      path.join(PUBLIC_DIR, "icon.png"),
      path.join(outDir, "icon.png"),
    );
  }
}

console.log(
  "[build-android-assets] Successfully generated dist/ and android/app/src/main/assets/public/!",
);
