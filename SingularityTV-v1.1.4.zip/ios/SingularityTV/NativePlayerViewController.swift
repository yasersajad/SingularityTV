import UIKit
import CoreFoundation
import AVFoundation
import AVKit
import VLC
import MediaPlayer
import WebKit

private struct IosSubCue {
    let startSec: Double
    let endSec: Double
    let text: String
}

private struct IosSubTrack {
    let lang: String
    let url: String
    let score: Int
    let syncMatch: Bool
}

class NativePlayerViewController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate, VLCMediaPlayerDelegate {
    private let payloadJson: String
    var onProgressUpdate: ((String, Int, Int, Int, Bool, Bool) -> Void)?
    var onSubtitleStyleChanged: ((String, String, Double) -> Void)?
    var onWebPrefsUpdate: ((String) -> Void)?
    private var hasRealPlaybackProgress: Bool = false
    private var episodeRuntimeMin: Int = 0
    var onPreferredSource: ((String) -> Void)?
    var onBlockedAd: ((String) -> Void)?

    private var vlcPlayer: VLCMediaPlayer?
    private var vlcPollTimer: Timer?
    private var vlcReadyHandled: Bool = false
    private var vlcSeekPendingSec: Double = 0
    private var vlcLastHoldSpeed: Float = 0
    private var vlcPlaybackToken: Int = 0
    private var activePlayUrl: URL?
    private var pendingSeekTargetSec: Double = -1
    private var lastSeekCommitTime: TimeInterval = 0
    private var seekUiLockUntil: TimeInterval = 0
    private var forceSoftwareDecode: Bool = false
    private var isScreenLocked: Bool = false
    private var unlockHideWorkItem: DispatchWorkItem?
    private var vlcDidEnd: Bool = false
    private var desiredPaused: Bool? = nil
    private var vlcVideoConfirmed: Bool = false
    private var embedMovieTemplate: String = "https://vidly.pro/movie/{TMDBID}"
    private var embedTvTemplate: String = "https://vidly.pro/tv/{TMDBID}/{SEASON}/{EPISODE}" 
    private var aspectModeIndex: Int = 0
    private var sleepTimer: Timer?
    private var sleepAtEndOfEpisode: Bool = false
    private var subBottomPadding: CGFloat = 14

    private let aspectButton = UIButton(type: .system)
    private let lockButton = UIButton(type: .system)
    private let unlockButton = UIButton(type: .system)
    private let sleepButton = UIButton(type: .system)
    private let skip85Button = UIButton(type: .system)
    private let subStyleButton = UIButton(type: .system)
    private let serverPickButton = UIButton(type: .system)
    private var itemStatusObserver: NSKeyValueObservation?

    private var streamUrl: String = ""
    private var streamTitle: String = "SingularityTV"
    private var progressKey: String = ""
    private var startTimeSec: Double = 0
    private var imdbId: String = ""
    private var tmdbId: String = ""
    private var mediaType: String = "movie"
    private var isLiveStream: Bool { return mediaType.lowercased() == "live" }
    private var liveElapsedSec: Double = 0
    private var lastLiveTickTs: TimeInterval = 0
    private weak var topRestartGroupRef: UIStackView?
    private weak var rewBtnRef: UIButton?
    private weak var fwdBtnRef: UIButton?
    private var seasonNum: Int = 1
    private var episodeNum: Int = 1
    private var preferredLang: String = "ar"
    private var subTextColorHex: String = "#FFFFFF"
    private var subBgStyleMode: String = "dark"
    private var subFontSizePt: CGFloat = 20.0
    private var currentSource: String = "vidyst"
    private var currentSpeed: Float = 1.0
    private var subDelaySec: Double = 0.0
    private var lastProgressSaveTime: TimeInterval = 0

    private let serverOrder = ["vidyst"]
    private var failoverAttempts: Int = 0
    private var isSwitchingServer: Bool = false
    private var isCaptchaVisible: Bool = false
    private var adRuleList: WKContentRuleList?
    private var isManualPick: Bool = false
    private let captchaCardView = UIView()
    private var captchaExpanded: Bool = false
    private var captchaSizeConstraints: [NSLayoutConstraint] = []
    private let syncCardView = UIView()
    private let syncValueLabel = UILabel()
    private let syncCenterLabel = UILabel()
    private var syncRepeatTimer: Timer?
    private var multiEmbedSubServers: [(name: String, idx: String)] = []
    private var captchaTitleLabel = UILabel()
    private var pendingNextSource: String = ""
    private var activeReferer: String = ""
    private var streamIsHls: Bool = false
    private var inlineM3u8Text: String = ""
    private var inlineBaseUrl: String = ""
    private var userSelectedSubServer: Bool = false
    private var activeStreamHeaders: [String: String] = [:]
    private let resourceLoaderQueue = DispatchQueue(label: "com.singularity.tv.hlsloader")
    private var activeReleaseHint: String = ""
    private var rawActiveCues: [IosSubCue] = []
    private var activeSubIsStreamNative: Bool = false
    private var usingNativeHlsSubtitle: Bool = false
    private var hlsLegibleOptions: [(lang: String, title: String, option: AVMediaSelectionOption)] = []
    private var resolverWebView: WKWebView?
    private var directWebPlayerMode: Bool = false
    private var directWebBackButton: UIButton?
    private var webErrorRetryCount: Int = 0
    private var initialWebPrefsJson: String = "{}"
    private var failoverTimer: Timer?
    private var verifiedServers: [String: (url: String, referer: String)] = [:]
    private var probedFailedServers: Set<String> = []
    private var failedStreamUrls: Set<String> = []
    private var headerRetryStage: Int = 0
    private var probeQueue: [String] = []
    private var probeWebViews: [WKWebView] = []
    private var probeSlotSources: [ObjectIdentifier: String] = [:]
    private var probeTimers: [ObjectIdentifier: Timer] = [:]
    private var isProbingActive: Bool = false
    private var seriesTitle: String = ""
    private var totalEpisodesInSeason: Int = 0
    private var seasonEpisodesList: [(season: Int, count: Int)] = []
    private var introStartSec: Double = -1
    private var introEndSec: Double = -1
    private var recapStartSec: Double = -1
    private var recapEndSec: Double = -1
    private var outroStartSec: Double = -1
    private var activeSkipTargetSec: Double = -1
    private var nextEpDismissed: Bool = false
    private var nextEpCountdownSec: Int = 10
    private var nextEpTimer: Timer?
    private let skipSegmentButton = UIButton(type: .system)
    private let nextEpCardView = UIView()
    private let nextEpTitleLabel = UILabel()
    private let nextEpCountdownLabel = UILabel()

    private var availableSubs: [IosSubTrack] = []
    private var activeCues: [IosSubCue] = []
    private var activeSubIndex: Int = -1

    private let videoContainer = UIView()
    private let overlayView = UIView()
    private let subtitleLabel = UILabel()
    private let titleLabel = UILabel()
    private let serverBadgeButton = UIButton(type: .system)
    private let switchServerButton = UIButton(type: .system)
    private let recentlyUpdatedSources: Set<String> = ["vidsrcmeru", "vidsrcto", "vidlink", "vidsrccc", "vidfast", "rivestream", "vidsrcxyz", "moviesapi"]
    private let serverCatalogVersion = "v275"
    private let playPauseButton = UIButton(type: .system)
    private let seekSlider = UISlider()
    private let currentPosLabel = UILabel()
    private let durationLabel = UILabel()
    private let subButton = UIButton(type: .system)
    private let topNextButton = UIButton(type: .system)
    private let topNextGroup = UIStackView()
    private let topRestartGroup = UIStackView()
    private let ambientTrackView = UIView()
    private let ambientFillView = UIView()
    private var ambientFillWidthConstraint: NSLayoutConstraint?
    private let gestureHudContainer = UIView()
    private let gestureHudIconView = UIImageView()
    private let gestureHudLabel = UILabel()
    private var swipeSeekBaseSec: Double = 0
    private var swipeSeekTargetSec: Double = 0
    private var hold2xStartX: CGFloat = 0
    private var hold2xWorkItem: DispatchWorkItem?
    private var hold2xSavedRate: Float = 1.0
    private var hold2xWasPlaying: Bool = false
    private let topRestartButton = UIButton(type: .system)
    private let syncButton = UIButton(type: .system)
    private let speedButton = UIButton(type: .system)
    private let pipButton = UIButton(type: .system)
    private let leftSeekBadge = UILabel()
    private let rightSeekBadge = UILabel()
    private let statusToastLabel = UILabel()

    private var isControllerVisible = true
    private var isScrubbing = false
    private var hideControllerWorkItem: DispatchWorkItem?
    private var singleTapWorkItem: DispatchWorkItem?
    private var hideLeftSeekWorkItem: DispatchWorkItem?
    private var hideRightSeekWorkItem: DispatchWorkItem?
    private var accumLeftSeek = 0
    private var accumRightSeek = 0
    private var lastTapTime: TimeInterval = 0
    private var lastTapSide = 0
    private var activeSeekSide = 0
    private var lastSeekEventTime: TimeInterval = 0

    private var gestureMode = 0
    private var gestureStartPoint = CGPoint.zero
    private var gestureStartVal: CGFloat = 0.5
    private let hiddenVolumeView = MPVolumeView(frame: CGRect(x: -1000, y: -1000, width: 100, height: 40))

    private let brightnessHudView = UIView()
    private let brightnessTrackView = UIView()
    private let brightnessFillView = UIView()
    private var brightnessFillHeightConstraint: NSLayoutConstraint?
    private let brightnessPctLabel = UILabel()
    private let volumeHudView = UIView()
    private let volumeTrackView = UIView()
    private let volumeFillView = UIView()
    private var volumeFillHeightConstraint: NSLayoutConstraint?
    private let volumePctLabel = UILabel()
    private var hideHudWorkItem: DispatchWorkItem?

    init(payloadJson: String) {
        self.payloadJson = payloadJson
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .landscape }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.semanticContentAttribute = .forceLeftToRight
        NotificationCenter.default.addObserver(self, selector: #selector(handleAppBackgrounded), name: UIApplication.willResignActiveNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleAppBackgrounded), name: UIApplication.didEnterBackgroundNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleAppForegrounded), name: UIApplication.didBecomeActiveNotification, object: nil)
        view.backgroundColor = .black
        view.addSubview(hiddenVolumeView)
        setupUi()
        parsePayloadAndPlay()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        videoContainer.layoutIfNeeded()
        if directWebPlayerMode, let wv = resolverWebView {
            wv.frame = view.bounds
        }
    }

    private func forceShutdownPlayer() {
        stopBackgroundServerProbing()
        failoverTimer?.invalidate()
        failoverTimer = nil
        nextEpTimer?.invalidate()
        nextEpTimer = nil
        sleepTimer?.invalidate()
        vlcPollTimer?.invalidate()
        vlcPollTimer = nil
        let dyingPlayer = vlcPlayer
        vlcPlayer = nil
        dyingPlayer?.delegate = nil
        dyingPlayer?.drawable = nil
        if let dp = dyingPlayer {
            DispatchQueue.global(qos: .userInitiated).async {
                dp.stop()
            }
        }
        resolverWebView?.evaluateJavaScript("try{document.querySelectorAll('video,audio').forEach(function(v){v.pause();v.muted=true;v.removeAttribute('src');v.load();});}catch(e){}", completionHandler: nil)
        resolverWebView?.stopLoading()
        resolverWebView?.isHidden = true
        resolverWebView?.alpha = 0
        resolverWebView?.loadHTMLString("<html><body style=\"background:#000\"></body></html>", baseURL: nil)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        saveProgress(forceCompleted: false)
        if isBeingDismissed || isMovingFromParent {
            forceShutdownPlayer()
        } else {
            vlcPlayer?.pause()
            if !directWebPlayerMode { resolverWebView?.evaluateJavaScript("try{document.querySelectorAll('video,audio').forEach(function(v){v.pause();v.muted=true;});}catch(e){}", completionHandler: nil) } else { resolverWebView?.evaluateJavaScript("try{document.querySelectorAll('video').forEach(function(v){if(!v.paused){window.__sbWasP=1;v.pause();}});}catch(e){}", completionHandler: nil) }
        }
    }


    @objc private func handleSkipSegment() {
        guard vlcPlayer != nil, activeSkipTargetSec > 0 else { return }
        seekPlayer(to: activeSkipTargetSec)
        skipSegmentButton.isHidden = true
        activeSkipTargetSec = -1
    }

    @objc private func dismissNextEpisodeCard() {
        nextEpDismissed = true
        nextEpTimer?.invalidate()
        nextEpTimer = nil
        nextEpCardView.isHidden = true
    }

    @objc private func playNextEpisodeInPlayer() {
        nextEpTimer?.invalidate()
        nextEpTimer = nil
        nextEpCardView.isHidden = true
        saveProgress(forceCompleted: true)
        stopBackgroundServerProbing()
        nextEpTimer?.invalidate()
        verifiedServers.removeAll()
        probedFailedServers.removeAll()
        availableSubs.removeAll()
        activeCues.removeAll()
        activeSubIndex = -1
        subtitleLabel.isHidden = true
        if episodeStepForCurrentStream() == 2 {
            let idKeyMid = imdbId.isEmpty ? tmdbId : imdbId
            let midKey = "tv_\(idKeyMid)_s\(seasonNum)e\(episodeNum + 1)"
            let durMid = max(1, Int(currentDurationSeconds()))
            onProgressUpdate?(midKey, 100, durMid, durMid, true, false)
        }
        guard let nxtEp = computeNextEpisode() else { return }
        seasonNum = nxtEp.season
        episodeNum = nxtEp.episode
        if let sInfo = seasonEpisodesList.first(where: { $0.season == seasonNum }) {
            totalEpisodesInSeason = sInfo.count
        }
        let idKey = imdbId.isEmpty ? tmdbId : imdbId
        progressKey = "tv_\(idKey)_s\(seasonNum)e\(episodeNum)"
        streamTitle = "\(seriesTitle) · S\(seasonNum)E\(episodeNum)"
        titleLabel.text = streamTitle
        updateTopActionButtons()
        startTimeSec = 0
        streamUrl = ""
        introStartSec = -1
        introEndSec = -1
        recapStartSec = -1
        recapEndSec = -1
        outroStartSec = -1
        nextEpDismissed = false
        updateSwitchServerButtonTitle()
        vlcPollTimer?.invalidate()
        vlcPollTimer = nil
        itemStatusObserver?.invalidate()
        itemStatusObserver = nil
        vlcPlayer?.stop()
        vlcPlayer?.delegate = nil
        vlcPlayer = nil
        startResolvingInitialSource()
        fetchSubtitlesInBackground()
        fetchSkipSegmentsInBackground()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { [weak self] in
            self?.startBackgroundServerProbing()
        }
    }

    private func autoDetectSegmentsFromStreamAndCues() {
        let cues = activeCues
        guard !cues.isEmpty else { return }
        let dur = currentDurationSeconds()
        let validDur = (dur.isFinite && dur > 60) ? dur : 0

        func isMetaOrMusicCue(_ text: String) -> Bool {
            let l = text.lowercased()
            if l.contains("♪") || l.contains("♫") || l.contains("[music") || l.contains("(music") || l.contains("theme song") { return true }
            if l.contains("directed by") || l.contains("produced by") || l.contains("starring") || l.contains("written by") || l.contains("executive producer") || l.contains("created by") || l.contains("based on") { return true }
            if l.contains("synced by") || l.contains("translated by") || l.contains("subtitles by") || l.contains("opensubtitles") || l.contains("osdb.link") { return true }
            return false
        }

        let spoken = cues.filter { !isMetaOrMusicCue($0.text) && !$0.text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty }
        guard let firstSpoken = spoken.first else { return }

        let openingLimit = validDur > 0 ? min(validDur * 0.45, 720.0) : 720.0
        var gapCands: [(st: Double, en: Double, score: Int)] = []

        let isTv = mediaType.lowercased() == "tv"
        if firstSpoken.startSec >= 25.0 && firstSpoken.startSec <= 210.0 {
            let musicBefore = cues.filter { $0.endSec <= firstSpoken.startSec + 1.0 && isMetaOrMusicCue($0.text) }
            if (isTv && firstSpoken.startSec >= 32.0) || !musicBefore.isEmpty {
                let bonus = musicBefore.isEmpty ? 0 : 45
                let startAt = musicBefore.first?.startSec ?? 2.0
                gapCands.append((max(1.5, startAt), max(startAt + 8.0, firstSpoken.startSec - 0.8), 55 + bonus))
            }
        }

        if isTv {
            for i in 0..<(spoken.count - 1) {
                let cur = spoken[i]
                let nxt = spoken[i + 1]
                if cur.endSec > openingLimit { break }
                let gap = nxt.startSec - cur.endSec
                if gap >= 28.0 && gap <= 135.0 {
                    let musicInGap = cues.filter { $0.startSec >= cur.endSec - 1.0 && $0.endSec <= nxt.startSec + 1.0 && isMetaOrMusicCue($0.text) }
                    var sc = 45
                    if gap >= 32.0 && gap <= 98.0 { sc += 25 }
                    if !musicInGap.isEmpty { sc += 50 }
                    gapCands.append((cur.endSec + 0.5, nxt.startSec - 0.8, sc))
                }
            }
        }

        if introEndSec > introStartSec && introStartSec >= 0 {
            let extDur = introEndSec - introStartSec
            let conflictingSpoken = spoken.filter { $0.startSec >= introStartSec + 5.0 && $0.endSec <= introEndSec - 5.0 }.count
            if let bestSync = gapCands.min(by: { a, b in
                let da = abs(a.st - introStartSec) + abs((a.en - a.st) - extDur)
                let db = abs(b.st - introStartSec) + abs((b.en - b.st) - extDur)
                return da < db
            }), abs(bestSync.st - introStartSec) <= 45.0, abs((bestSync.en - bestSync.st) - extDur) <= 25.0 {
                introStartSec = bestSync.st
                introEndSec = bestSync.en
            } else if conflictingSpoken >= 2 {
                if let bestAuto = gapCands.max(by: { $0.score < $1.score }) {
                    introStartSec = bestAuto.st
                    introEndSec = bestAuto.en
                } else {
                    introStartSec = -1
                    introEndSec = -1
                }
            }
        } else if let bestAuto = gapCands.max(by: { $0.score < $1.score }) {
            introStartSec = bestAuto.st
            introEndSec = bestAuto.en
        }

        if validDur > 180, let lastSpoken = spoken.last {
            let rem = validDur - lastSpoken.endSec
            if outroStartSec > 0 {
                let spokenAfterOutro = spoken.filter { $0.startSec >= outroStartSec + 6.0 }.count
                if spokenAfterOutro >= 3 {
                    if rem >= 25.0 && rem <= 300.0 && lastSpoken.endSec >= validDur * 0.78 {
                        outroStartSec = lastSpoken.endSec + 1.5
                    } else {
                        outroStartSec = -1
                    }
                }
            } else if rem >= 25.0 && rem <= 300.0 && lastSpoken.endSec >= validDur * 0.78 {
                outroStartSec = lastSpoken.endSec + 1.5
            }
        }
    }

    private func fetchSkipSegmentsInBackground(durationMs: Int = 0) {
        if durationMs == 0 {
            introStartSec = -1
            introEndSec = -1
            recapStartSec = -1
            recapEndSec = -1
            outroStartSec = -1
        }
        let rawIm = imdbId.trimmingCharacters(in: .whitespacesAndNewlines)
        let tm = tmdbId.trimmingCharacters(in: .whitespacesAndNewlines)
        let isTv = mediaType.lowercased() == "tv"
        let s = seasonNum
        let e = episodeNum
        let durSec = durationMs > 0 ? Double(durationMs) / 1000.0 : currentDurationSeconds()

        DispatchQueue.global(qos: .utility).async { [weak self] in
            var im = rawIm
            if !im.hasPrefix("tt") && !tm.isEmpty && tm.allSatisfy({ $0.isNumber }) {
                let prop = isTv ? "P4983" : "P4947"
                let sparql = "SELECT ?imdb WHERE { ?item wdt:\(prop) \"\(tm)\" . ?item wdt:P345 ?imdb . } LIMIT 1"
                if let enc = sparql.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
                   let wu = URL(string: "https://query.wikidata.org/sparql?format=json&query=\(enc)") {
                    let wGroup = DispatchGroup()
                    wGroup.enter()
                    var wReq = URLRequest(url: wu, timeoutInterval: 3.5)
                    wReq.setValue("application/sparql-results+json", forHTTPHeaderField: "Accept")
                    URLSession.shared.dataTask(with: wReq) { wd, _, _ in
                        if let wd = wd,
                           let wj = try? JSONSerialization.jsonObject(with: wd) as? [String: Any],
                           let res = wj["results"] as? [String: Any],
                           let binds = res["bindings"] as? [[String: Any]],
                           let first = binds.first,
                           let imdbObj = first["imdb"] as? [String: Any],
                           let val = imdbObj["value"] as? String, val.hasPrefix("tt") {
                            im = val
                        }
                        wGroup.leave()
                    }.resume()
                    _ = wGroup.wait(timeout: .now() + 3.8)
                }
            }

            let lock = NSLock()
            var introCands: [(start: Double, end: Double, weight: Int)] = []
            var recapCands: [(start: Double, end: Double, weight: Int)] = []
            var outroCands: [(start: Double, weight: Int)] = []
            let group = DispatchGroup()

            func addIntro(_ st: Double, _ en: Double, _ w: Int) {
                guard st >= 0, en > st + 5, (en - st) <= 240, (durSec <= 0 || st < max(durSec * 0.45, 720.0)) else { return }
                lock.lock(); introCands.append((st, en, w)); lock.unlock()
            }
            func addRecap(_ st: Double, _ en: Double, _ w: Int) {
                guard st >= 0, en > st + 5, st < 150, (durSec <= 0 || en < durSec * 0.25) else { return }
                lock.lock(); recapCands.append((st, en, w)); lock.unlock()
            }
            func addOutro(_ st: Double, _ w: Int) {
                guard st > 30, durSec > 180 else { return }
                let rem = durSec - st
                guard rem >= 12.0 && rem <= 240.0 && st >= durSec * 0.80 else { return }
                lock.lock(); outroCands.append((st, w)); lock.unlock()
            }

            var qParts: [String] = []
            if im.hasPrefix("tt") { qParts.append("imdb_id=\(im)") }
            else if !tm.isEmpty && tm.allSatisfy({ $0.isNumber }) { qParts.append("tmdb_id=\(tm)") }
            if isTv { qParts.append("season=\(s)"); qParts.append("episode=\(e)") }
            if durationMs > 30000 { qParts.append("duration_ms=\(durationMs)") }
            if !qParts.isEmpty, let u1 = URL(string: "https://api.theintrodb.org/v3/media?" + qParts.joined(separator: "&")) {
                group.enter()
                var req1 = URLRequest(url: u1, timeoutInterval: 5.5)
                req1.setValue("SingularityTV/1.0.0", forHTTPHeaderField: "User-Agent")
                URLSession.shared.dataTask(with: req1) { data, _, _ in
                    if let d = data, let json = try? JSONSerialization.jsonObject(with: d) as? [String: Any] {
                        if let arr = json["intro"] as? [[String: Any]], let first = arr.first, let endMs = (first["end_ms"] as? NSNumber)?.doubleValue {
                            addIntro(((first["start_ms"] as? NSNumber)?.doubleValue ?? 0) / 1000.0, endMs / 1000.0, 6)
                        }
                        if let arr = json["recap"] as? [[String: Any]], let first = arr.first, let endMs = (first["end_ms"] as? NSNumber)?.doubleValue {
                            addRecap(((first["start_ms"] as? NSNumber)?.doubleValue ?? 0) / 1000.0, endMs / 1000.0, 6)
                        }
                        if let arr = json["credits"] as? [[String: Any]], let first = arr.first, let stMs = (first["start_ms"] as? NSNumber)?.doubleValue {
                            addOutro(stMs / 1000.0, 6)
                        }
                    }
                    group.leave()
                }.resume()
            }

            if im.hasPrefix("tt") {
                let epStr = isTv ? "season=\(s)&episode=\(e)" : "is_movie=true"
                if let u2 = URL(string: "https://api.introdb.app/segments?imdb_id=\(im)&\(epStr)") {
                    group.enter()
                    var req2 = URLRequest(url: u2, timeoutInterval: 5.5)
                    req2.setValue("SingularityTV/1.0.0", forHTTPHeaderField: "User-Agent")
                    URLSession.shared.dataTask(with: req2) { data, _, _ in
                        if let d = data, let json = try? JSONSerialization.jsonObject(with: d) as? [String: Any] {
                            if let seg = json["intro"] as? [String: Any] {
                                let st = ((seg["start_ms"] as? NSNumber)?.doubleValue ?? ((seg["start_sec"] as? NSNumber)?.doubleValue ?? 0) * 1000.0) / 1000.0
                                let en = ((seg["end_ms"] as? NSNumber)?.doubleValue ?? ((seg["end_sec"] as? NSNumber)?.doubleValue ?? 0) * 1000.0) / 1000.0
                                addIntro(st, en, 5)
                            }
                            if let seg = json["recap"] as? [String: Any] {
                                let st = ((seg["start_ms"] as? NSNumber)?.doubleValue ?? ((seg["start_sec"] as? NSNumber)?.doubleValue ?? 0) * 1000.0) / 1000.0
                                let en = ((seg["end_ms"] as? NSNumber)?.doubleValue ?? ((seg["end_sec"] as? NSNumber)?.doubleValue ?? 0) * 1000.0) / 1000.0
                                addRecap(st, en, 5)
                            }
                            if let seg = (json["outro"] as? [String: Any]) ?? (json["credits"] as? [String: Any]) {
                                let st = ((seg["start_ms"] as? NSNumber)?.doubleValue ?? ((seg["start_sec"] as? NSNumber)?.doubleValue ?? 0) * 1000.0) / 1000.0
                                addOutro(st, 5)
                            }
                        }
                        group.leave()
                    }.resume()
                }
                if isTv, let u2b = URL(string: "https://api.introdb.app/intro?imdb_id=\(im)&season=\(s)&episode=\(e)") {
                    group.enter()
                    var req2b = URLRequest(url: u2b, timeoutInterval: 5.0)
                    req2b.setValue("SingularityTV/1.0.0", forHTTPHeaderField: "User-Agent")
                    URLSession.shared.dataTask(with: req2b) { data, _, _ in
                        if let d = data, let json = try? JSONSerialization.jsonObject(with: d) as? [String: Any] {
                            let st = ((json["start_ms"] as? NSNumber)?.doubleValue ?? ((json["start_sec"] as? NSNumber)?.doubleValue ?? 0) * 1000.0) / 1000.0
                            let en = ((json["end_ms"] as? NSNumber)?.doubleValue ?? ((json["end_sec"] as? NSNumber)?.doubleValue ?? 0) * 1000.0) / 1000.0
                            addIntro(st, en, 4)
                        }
                        group.leave()
                    }.resume()
                }
            }

            if im.hasPrefix("tt") || (!tm.isEmpty && tm.allSatisfy({ $0.isNumber })) {
                var sParts: [String] = []
                if im.hasPrefix("tt") { sParts.append("imdb_id=\(im)") } else { sParts.append("tmdb_id=\(tm)") }
                if isTv { sParts.append("season=\(s)"); sParts.append("episode=\(e)") }
                if durationMs > 30000 { sParts.append("duration_ms=\(durationMs)") }
                let qStr = sParts.joined(separator: "&")
                for base in ["https://api.skipdb.tv/v1/segments", "https://api.skipdb.tv/api/segments"] {
                    if let u3 = URL(string: "\(base)?\(qStr)") {
                        group.enter()
                        var req3 = URLRequest(url: u3, timeoutInterval: 5.5)
                        req3.setValue("SingularityTV/1.0.0", forHTTPHeaderField: "User-Agent")
                        URLSession.shared.dataTask(with: req3) { data, _, _ in
                            if let d = data, let json = try? JSONSerialization.jsonObject(with: d) as? [String: Any] {
                                let arr = (json["segments"] as? [[String: Any]]) ?? (json["results"] as? [[String: Any]]) ?? (json["data"] as? [[String: Any]]) ?? []
                                for seg in arr {
                                    let tp = (seg["type"] as? String ?? seg["segment"] as? String ?? "").lowercased()
                                    let st = ((seg["start_ms"] as? NSNumber)?.doubleValue ?? ((seg["start"] as? NSNumber)?.doubleValue ?? 0) * 1000.0) / 1000.0
                                    let en = ((seg["end_ms"] as? NSNumber)?.doubleValue ?? ((seg["end"] as? NSNumber)?.doubleValue ?? 0) * 1000.0) / 1000.0
                                    if tp.contains("intro") || tp == "op" { addIntro(st, en, 4) }
                                    else if tp.contains("recap") { addRecap(st, en, 4) }
                                    else if tp.contains("credit") || tp.contains("outro") || tp == "ed" { addOutro(st, 4) }
                                }
                            }
                            group.leave()
                        }.resume()
                    }
                }
            }

            if im.hasPrefix("tt") {
                let ihUrlStr = isTv
                    ? "https://api.introhater.com/skip-times?imdb_id=\(im)&season=\(s)&episode=\(e)"
                    : "https://api.introhater.com/skip-times?imdb_id=\(im)"
                if let u4 = URL(string: ihUrlStr) {
                    group.enter()
                    var req4 = URLRequest(url: u4, timeoutInterval: 5.5)
                    req4.setValue("SingularityTV/1.0.0", forHTTPHeaderField: "User-Agent")
                    URLSession.shared.dataTask(with: req4) { data, _, _ in
                        if let d = data, let json = try? JSONSerialization.jsonObject(with: d) as? [String: Any] {
                            let arr = (json["results"] as? [[String: Any]]) ?? (json["segments"] as? [[String: Any]]) ?? []
                            for seg in arr {
                                let tp = (seg["skipType"] as? String ?? seg["type"] as? String ?? "").lowercased()
                                if let iv = seg["interval"] as? [String: Any],
                                   let st = (iv["startTime"] as? NSNumber)?.doubleValue,
                                   let en = (iv["endTime"] as? NSNumber)?.doubleValue {
                                    if tp == "op" || tp.contains("intro") { addIntro(st, en, 3) }
                                    else if tp == "recap" { addRecap(st, en, 3) }
                                    else if tp == "ed" || tp.contains("outro") || tp.contains("credit") { addOutro(st, 3) }
                                }
                            }
                        }
                        group.leave()
                    }.resume()
                }
            }

            if im.hasPrefix("tt"), let armUrl = URL(string: "https://arm.haglund.dev/api/v2/ids?source=imdb&id=\(im)") {
                group.enter()
                URLSession.shared.dataTask(with: URLRequest(url: armUrl, timeoutInterval: 4.5)) { data, _, _ in
                    let epLen = durSec > 60 ? Int(durSec) : 0
                    if let d = data, let armJson = try? JSONSerialization.jsonObject(with: d) as? [String: Any],
                       let malId = (armJson["myanimelist"] as? NSNumber)?.intValue, malId > 0,
                       let aniUrl = URL(string: "https://api.aniskip.com/v2/skip-times/\(malId)/\(isTv ? e : 1)?types[]=op&types[]=ed&types[]=recap&episodeLength=\(epLen)") {
                        URLSession.shared.dataTask(with: URLRequest(url: aniUrl, timeoutInterval: 4.5)) { d2, _, _ in
                            if let d2 = d2, let aniJson = try? JSONSerialization.jsonObject(with: d2) as? [String: Any],
                               let arr = aniJson["results"] as? [[String: Any]] {
                                for seg in arr {
                                    let tp = (seg["skipType"] as? String ?? "").lowercased()
                                    if let iv = seg["interval"] as? [String: Any],
                                       let st = (iv["startTime"] as? NSNumber)?.doubleValue,
                                       let en = (iv["endTime"] as? NSNumber)?.doubleValue {
                                        if tp == "op" { addIntro(st, en, 4) }
                                        else if tp == "recap" { addRecap(st, en, 4) }
                                        else if tp == "ed" { addOutro(st, 4) }
                                    }
                                }
                            }
                            group.leave()
                        }.resume()
                    } else {
                        group.leave()
                    }
                }.resume()
            }

            _ = group.wait(timeout: .now() + 7.0)

            func pickBestSpan(_ cands: [(start: Double, end: Double, weight: Int)]) -> (Double, Double)? {
                if cands.isEmpty { return nil }
                var bestScore = -1
                var bestCenter = cands[0]
                for c in cands {
                    var clusterScore = 0
                    for o in cands {
                        if abs(c.start - o.start) <= 3.5 && abs(c.end - o.end) <= 3.5 {
                            clusterScore += o.weight
                        }
                    }
                    if clusterScore > bestScore {
                        bestScore = clusterScore
                        bestCenter = c
                    }
                }
                var sumSt = 0.0
                var sumEn = 0.0
                var totalW = 0.0
                var count = 0
                var maxW = 0
                for o in cands {
                    if abs(bestCenter.start - o.start) <= 3.5 && abs(bestCenter.end - o.end) <= 3.5 {
                        let w = Double(o.weight)
                        sumSt += o.start * w
                        sumEn += o.end * w
                        totalW += w
                        count += 1
                        if o.weight > maxW { maxW = o.weight }
                    }
                }
                if count < 2 && maxW < 6 { return nil }
                if totalW > 0 { return (sumSt / totalW, sumEn / totalW) }
                return (bestCenter.start, bestCenter.end)
            }

            func pickBestOutro(_ cands: [(start: Double, weight: Int)]) -> Double? {
                if cands.isEmpty { return nil }
                var bestScore = -1
                var bestCenter = cands[0]
                for c in cands {
                    var clusterScore = 0
                    for o in cands {
                        if abs(c.start - o.start) <= 4.0 {
                            clusterScore += o.weight
                        }
                    }
                    if clusterScore > bestScore {
                        bestScore = clusterScore
                        bestCenter = c
                    }
                }
                var sumSt = 0.0
                var totalW = 0.0
                for o in cands {
                    if abs(bestCenter.start - o.start) <= 4.0 {
                        let w = Double(o.weight)
                        sumSt += o.start * w
                        totalW += w
                    }
                }
                if totalW > 0 { return sumSt / totalW }
                return bestCenter.start
            }

            let bestIntro = pickBestSpan(introCands)
            let bestRecap = pickBestSpan(recapCands)
            let bestOutro = pickBestOutro(outroCands)

            DispatchQueue.main.async {
                guard let self = self else { return }
                if let i = bestIntro {
                    self.introStartSec = i.0
                    self.introEndSec = i.1
                }
                if let r = bestRecap {
                    self.recapStartSec = r.0
                    self.recapEndSec = r.1
                }
                if let o = bestOutro {
                    self.outroStartSec = o
                }
                self.autoDetectSegmentsFromStreamAndCues()
            }
        }
    }

    private func updateSkipAndNextEpisodeUi() {
        guard vlcPlayer != nil else { return }
        let cur = currentTimeSeconds()
        let dur = currentDurationSeconds()
        if !cur.isFinite || cur < 0 { return }

        skipSegmentButton.isHidden = true
        activeSkipTargetSec = -1

        if mediaType.lowercased() == "tv" && !nextEpDismissed && dur.isFinite && dur > 120 {
            if let nextPair = computeNextEpisode() {
                let validOutro = outroStartSec > 60 && (dur - outroStartSec) >= 12.0 && (dur - outroStartSec) <= 240.0 && outroStartSec >= dur * 0.80
                let triggerSec = validOutro ? outroStartSec : max(dur * 0.94, dur - 45.0)
                if cur >= triggerSec && cur < dur {
                    if nextEpCardView.isHidden {
                        nextEpTitleLabel.text = "\(seriesTitle) · S\(nextPair.season)E\(nextPair.episode)"
                        nextEpCountdownSec = 10
                        nextEpCountdownLabel.text = "Starting in 10s..."
                        nextEpCardView.isHidden = false
                        nextEpTimer?.invalidate()
                        nextEpTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] t in
                            guard let self = self else { t.invalidate(); return }
                            if self.nextEpDismissed || self.nextEpCardView.isHidden { t.invalidate(); return }
                            self.nextEpCountdownSec -= 1
                            if self.nextEpCountdownSec <= 0 {
                                t.invalidate()
                                self.playNextEpisodeInPlayer()
                            } else {
                                self.nextEpCountdownLabel.text = "Starting in \(self.nextEpCountdownSec)s..."
                            }
                        }
                    }
                } else if !nextEpCardView.isHidden {
                    nextEpTimer?.invalidate()
                    nextEpTimer = nil
                    nextEpCardView.isHidden = true
                }
            }
        }
    }

    deinit {
        stopBackgroundServerProbing()
        nextEpTimer?.invalidate()
        vlcPollTimer?.invalidate()
        vlcPlayer?.stop()
        NotificationCenter.default.removeObserver(self)
        itemStatusObserver?.invalidate()
        failoverTimer?.invalidate()
    }

    @objc private func handleAppForegrounded() {
        if directWebPlayerMode {
            try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .moviePlayback)
            try? AVAudioSession.sharedInstance().setActive(true)
            resolverWebView?.evaluateJavaScript("try{document.querySelectorAll('video,audio').forEach(function(v){v.muted=false;if(window.__sbWasP){window.__sbWasP=0;v.play().catch(function(){});}});}catch(e){}", completionHandler: nil)
        }
    }

    @objc private func handleAppBackgrounded() {
        saveProgress(forceCompleted: false, isPlayingOverride: false)
        vlcPlayer?.pause()
        updatePlayPauseIcon()
        if !directWebPlayerMode { resolverWebView?.evaluateJavaScript("try{document.querySelectorAll('video,audio').forEach(function(v){v.pause();v.muted=true;});}catch(e){}", completionHandler: nil) } else { resolverWebView?.evaluateJavaScript("try{document.querySelectorAll('video').forEach(function(v){if(!v.paused){window.__sbWasP=1;v.pause();}});}catch(e){}", completionHandler: nil) }
    }

    private func applySubtitleStyle() {
        let hex = subTextColorHex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var rgb: UInt64 = 0xFFFFFF
        if hex.count == 6 { Scanner(string: hex).scanHexInt64(&rgb) }
        let r = CGFloat((rgb >> 16) & 0xFF) / 255.0
        let g = CGFloat((rgb >> 8) & 0xFF) / 255.0
        let b = CGFloat(rgb & 0xFF) / 255.0
        subtitleLabel.textColor = UIColor(red: r, green: g, blue: b, alpha: 1.0)
        subtitleLabel.font = .boldSystemFont(ofSize: subFontSizePt)
        switch subBgStyleMode {
        case "none":
            subtitleLabel.backgroundColor = .clear
        case "semi":
            subtitleLabel.backgroundColor = UIColor.black.withAlphaComponent(0.40)
            subtitleLabel.layer.cornerRadius = 6
            subtitleLabel.layer.masksToBounds = true
        default:
            subtitleLabel.backgroundColor = UIColor.black.withAlphaComponent(0.75)
            subtitleLabel.layer.cornerRadius = 6
            subtitleLabel.layer.masksToBounds = true
        }
    }

    private func setupUi() {
        videoContainer.frame = view.bounds
        videoContainer.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        videoContainer.backgroundColor = .black
        videoContainer.isUserInteractionEnabled = false
        view.addSubview(videoContainer)

        subtitleLabel.translatesAutoresizingMaskIntoConstraints = false
        subtitleLabel.textColor = .white
        subtitleLabel.font = .boldSystemFont(ofSize: 20)
        subtitleLabel.textAlignment = .center
        subtitleLabel.numberOfLines = 0
        subtitleLabel.layer.shadowColor = UIColor.black.cgColor
        subtitleLabel.layer.shadowRadius = 4
        subtitleLabel.layer.shadowOpacity = 0.95
        subtitleLabel.layer.shadowOffset = CGSize(width: 0, height: 1)
        subtitleLabel.isHidden = true
        overlayView.frame = view.bounds
        overlayView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        overlayView.backgroundColor = UIColor.black.withAlphaComponent(0.32)
        view.addSubview(overlayView)
        view.addSubview(subtitleLabel)

        let topIconCfg = UIImage.SymbolConfiguration(pointSize: 19, weight: .medium)
        func makeTopLabel(_ title: String) -> UILabel {
            let lbl = UILabel()
            lbl.translatesAutoresizingMaskIntoConstraints = false
            lbl.text = title
            lbl.textColor = UIColor.white.withAlphaComponent(0.88)
            lbl.font = .systemFont(ofSize: 10, weight: .semibold)
            lbl.textAlignment = .center
            return lbl
        }

        let backBtn = UIButton(type: .system)
        backBtn.translatesAutoresizingMaskIntoConstraints = false
        backBtn.setImage(UIImage(systemName: "chevron.backward", withConfiguration: topIconCfg), for: .normal)
        backBtn.tintColor = .white
        backBtn.addTarget(self, action: #selector(handleBack), for: .touchUpInside)

        let backGroup = UIStackView(arrangedSubviews: [backBtn, makeTopLabel("Back")])
        backGroup.translatesAutoresizingMaskIntoConstraints = false
        backGroup.axis = .vertical
        backGroup.alignment = .center
        backGroup.spacing = 2

        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.textColor = .white
        titleLabel.font = .boldSystemFont(ofSize: 17)
        titleLabel.lineBreakMode = .byTruncatingTail

        switchServerButton.isHidden = true
        serverBadgeButton.isHidden = true

        topRestartButton.translatesAutoresizingMaskIntoConstraints = false
        topRestartButton.setTitle(nil, for: .normal)
        topRestartButton.setImage(UIImage(systemName: "arrow.counterclockwise", withConfiguration: topIconCfg), for: .normal)
        topRestartButton.tintColor = .white
        topRestartButton.backgroundColor = .clear
        topRestartButton.layer.cornerRadius = 20
        topRestartButton.layer.masksToBounds = true
        topRestartButton.accessibilityLabel = "Restart"
        topRestartButton.addTarget(self, action: #selector(handleTopRestart), for: .touchUpInside)

        topRestartGroupRef = topRestartGroup
        topRestartGroup.addArrangedSubview(topRestartButton)
        topRestartGroup.addArrangedSubview(makeTopLabel("Restart"))
        topRestartGroup.translatesAutoresizingMaskIntoConstraints = false
        topRestartGroup.axis = .vertical
        topRestartGroup.alignment = .center
        topRestartGroup.spacing = 2

        topNextButton.translatesAutoresizingMaskIntoConstraints = false
        topNextButton.setTitle(nil, for: .normal)
        topNextButton.setImage(UIImage(systemName: "forward.end", withConfiguration: topIconCfg), for: .normal)
        topNextButton.tintColor = .white
        topNextButton.backgroundColor = .clear
        topNextButton.layer.cornerRadius = 20
        topNextButton.layer.masksToBounds = true
        topNextButton.accessibilityLabel = "Next Episode"
        topNextButton.addTarget(self, action: #selector(handleTopNext), for: .touchUpInside)

        topNextGroup.addArrangedSubview(topNextButton)
        topNextGroup.addArrangedSubview(makeTopLabel("Next"))
        topNextGroup.translatesAutoresizingMaskIntoConstraints = false
        topNextGroup.axis = .vertical
        topNextGroup.alignment = .center
        topNextGroup.spacing = 2

        let topActionsStack = UIStackView(arrangedSubviews: [topRestartGroup, topNextGroup])
        topActionsStack.translatesAutoresizingMaskIntoConstraints = false
        topActionsStack.axis = .horizontal
        topActionsStack.spacing = 12

        overlayView.addSubview(backGroup)
        overlayView.addSubview(titleLabel)
        overlayView.addSubview(topActionsStack)

        let rewBtn = UIButton(type: .system)
        rewBtnRef = rewBtn
        rewBtn.translatesAutoresizingMaskIntoConstraints = false
        rewBtn.setImage(UIImage(systemName: "gobackward.10"), for: .normal)
        rewBtn.tintColor = .white
        rewBtn.setPreferredSymbolConfiguration(UIImage.SymbolConfiguration(pointSize: 26, weight: .semibold), forImageIn: .normal)
        rewBtn.addTarget(self, action: #selector(handleRewind10), for: .touchUpInside)

        playPauseButton.translatesAutoresizingMaskIntoConstraints = false
        playPauseButton.setImage(UIImage(systemName: "pause.fill"), for: .normal)
        playPauseButton.tintColor = .white
        playPauseButton.backgroundColor = UIColor.white.withAlphaComponent(0.16)
        playPauseButton.layer.cornerRadius = 32
        playPauseButton.setPreferredSymbolConfiguration(UIImage.SymbolConfiguration(pointSize: 28, weight: .bold), forImageIn: .normal)
        playPauseButton.addTarget(self, action: #selector(handlePlayPause), for: .touchUpInside)

        let fwdBtn = UIButton(type: .system)
        fwdBtnRef = fwdBtn
        fwdBtn.translatesAutoresizingMaskIntoConstraints = false
        fwdBtn.setImage(UIImage(systemName: "goforward.10"), for: .normal)
        fwdBtn.tintColor = .white
        fwdBtn.setPreferredSymbolConfiguration(UIImage.SymbolConfiguration(pointSize: 26, weight: .semibold), forImageIn: .normal)
        fwdBtn.addTarget(self, action: #selector(handleForward10), for: .touchUpInside)

        overlayView.addSubview(rewBtn)
        overlayView.addSubview(playPauseButton)
        overlayView.addSubview(fwdBtn)

        currentPosLabel.translatesAutoresizingMaskIntoConstraints = false
        currentPosLabel.textColor = .white
        currentPosLabel.font = .monospacedDigitSystemFont(ofSize: 12, weight: .semibold)
        currentPosLabel.text = "0:00"

        durationLabel.translatesAutoresizingMaskIntoConstraints = false
        durationLabel.textColor = UIColor.white.withAlphaComponent(0.8)
        durationLabel.font = .monospacedDigitSystemFont(ofSize: 12, weight: .semibold)
        durationLabel.text = "0:00"

        seekSlider.translatesAutoresizingMaskIntoConstraints = false
        seekSlider.minimumTrackTintColor = UIColor(red: 229/255, green: 9/255, blue: 20/255, alpha: 1)
        seekSlider.maximumTrackTintColor = UIColor.white.withAlphaComponent(0.3)
        seekSlider.addTarget(self, action: #selector(onSliderStart), for: .touchDown)
        seekSlider.addTarget(self, action: #selector(onSliderChanged), for: .valueChanged)
        seekSlider.addTarget(self, action: #selector(onSliderEnd), for: [.touchUpInside, .touchUpOutside, .touchCancel])

        overlayView.addSubview(currentPosLabel)
        overlayView.addSubview(seekSlider)
        overlayView.addSubview(durationLabel)

        subButton.translatesAutoresizingMaskIntoConstraints = false
        subButton.setTitle("Subtitles", for: .normal)
        subButton.setTitleColor(.white, for: .normal)
        subButton.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
        subButton.addTarget(self, action: #selector(openSubtitleMenu), for: .touchUpInside)

        speedButton.translatesAutoresizingMaskIntoConstraints = false
        speedButton.setTitle("1x", for: .normal)
        speedButton.setTitleColor(.white, for: .normal)
        speedButton.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
        speedButton.addTarget(self, action: #selector(openSpeedMenu), for: .touchUpInside)

        pipButton.translatesAutoresizingMaskIntoConstraints = false
        pipButton.setTitle("PiP", for: .normal)
        pipButton.setTitleColor(.white, for: .normal)
        pipButton.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
        pipButton.addTarget(self, action: #selector(togglePip), for: .touchUpInside)

        syncButton.translatesAutoresizingMaskIntoConstraints = false
        syncButton.setTitle("Sync 0.0s", for: .normal)
        syncButton.setTitleColor(.white, for: .normal)
        syncButton.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
        syncButton.addTarget(self, action: #selector(openSyncMenu), for: .touchUpInside)

        func styleActionBtn(_ btn: UIButton, _ title: String, _ sel: Selector) {
            btn.translatesAutoresizingMaskIntoConstraints = false
            btn.setTitle(title, for: .normal)
            btn.setTitleColor(.white, for: .normal)
            btn.titleLabel?.font = .systemFont(ofSize: 12.5, weight: .semibold)
            btn.addTarget(self, action: sel, for: .touchUpInside)
        }

        styleActionBtn(subStyleButton, "Style", #selector(openSubtitleStyleMenu))
        styleActionBtn(aspectButton, "Fit", #selector(cycleAspectMode))
        styleActionBtn(skip85Button, "+85s", #selector(handleQuickSkip85))
        styleActionBtn(sleepButton, "Timer", #selector(openSleepTimerMenu))
        styleActionBtn(lockButton, "Lock", #selector(toggleScreenLock))
        styleActionBtn(serverPickButton, "Server", #selector(openServerPickerMenu))

        unlockButton.translatesAutoresizingMaskIntoConstraints = false
        unlockButton.setImage(UIImage(systemName: "lock.fill"), for: .normal)
        unlockButton.setTitle(" Unlock", for: .normal)
        unlockButton.tintColor = .white
        unlockButton.setTitleColor(.white, for: .normal)
        unlockButton.titleLabel?.font = .systemFont(ofSize: 13, weight: .bold)
        unlockButton.backgroundColor = UIColor.black.withAlphaComponent(0.65)
        unlockButton.layer.cornerRadius = 18
        unlockButton.layer.borderWidth = 1
        unlockButton.layer.borderColor = UIColor.white.withAlphaComponent(0.28).cgColor
        unlockButton.contentEdgeInsets = UIEdgeInsets(top: 8, left: 14, bottom: 8, right: 14)
        unlockButton.isHidden = true
        unlockButton.addTarget(self, action: #selector(toggleScreenLock), for: .touchUpInside)
        view.addSubview(unlockButton)

        applyLiveModeUI()
        let pinch = UIPinchGestureRecognizer(target: self, action: #selector(handlePinchZoom(_:)))
        view.addGestureRecognizer(pinch)

        syncButton.isHidden = false
        pipButton.isHidden = true
        serverPickButton.isHidden = true
        let actionsStack = UIStackView(arrangedSubviews: [subButton, subStyleButton, syncButton, speedButton, aspectButton, skip85Button, sleepButton, lockButton])
        actionsStack.translatesAutoresizingMaskIntoConstraints = false
        actionsStack.axis = .horizontal
        actionsStack.spacing = 14
        overlayView.addSubview(actionsStack)

        ambientFillWidthConstraint = ambientFillView.widthAnchor.constraint(equalToConstant: 0)
        ambientFillWidthConstraint?.isActive = true
        setupSeekBadges()
        setupGestureHuds()

        statusToastLabel.translatesAutoresizingMaskIntoConstraints = false
        statusToastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.75)
        statusToastLabel.textColor = .white
        statusToastLabel.font = .systemFont(ofSize: 13, weight: .semibold)
        statusToastLabel.textAlignment = .center
        statusToastLabel.layer.cornerRadius = 14
        statusToastLabel.layer.masksToBounds = true
        statusToastLabel.isHidden = true
        view.addSubview(statusToastLabel)

        gestureHudContainer.translatesAutoresizingMaskIntoConstraints = false
        gestureHudContainer.backgroundColor = UIColor.black.withAlphaComponent(0.78)
        gestureHudContainer.layer.cornerRadius = 18
        gestureHudContainer.layer.borderWidth = 1
        gestureHudContainer.layer.borderColor = UIColor.white.withAlphaComponent(0.22).cgColor
        gestureHudContainer.layer.masksToBounds = true
        gestureHudContainer.isHidden = true
        gestureHudContainer.isUserInteractionEnabled = false

        gestureHudIconView.translatesAutoresizingMaskIntoConstraints = false
        gestureHudIconView.tintColor = .white
        gestureHudIconView.contentMode = .scaleAspectFit
        gestureHudIconView.isHidden = true

        gestureHudLabel.translatesAutoresizingMaskIntoConstraints = false
        gestureHudLabel.textColor = .white
        gestureHudLabel.font = .boldSystemFont(ofSize: 15)
        gestureHudLabel.textAlignment = .center

        let hudStack = UIStackView(arrangedSubviews: [gestureHudIconView, gestureHudLabel])
        hudStack.translatesAutoresizingMaskIntoConstraints = false
        hudStack.axis = .horizontal
        hudStack.alignment = .center
        hudStack.spacing = 6
        gestureHudContainer.addSubview(hudStack)
        view.addSubview(gestureHudContainer)

        ambientTrackView.translatesAutoresizingMaskIntoConstraints = false
        ambientTrackView.backgroundColor = UIColor.white.withAlphaComponent(0.22)
        ambientTrackView.alpha = 0
        ambientTrackView.isHidden = true
        ambientTrackView.isUserInteractionEnabled = false
        ambientFillView.translatesAutoresizingMaskIntoConstraints = false
        ambientFillView.backgroundColor = .white
        ambientTrackView.addSubview(ambientFillView)
        view.addSubview(ambientTrackView)

        skipSegmentButton.translatesAutoresizingMaskIntoConstraints = false
        skipSegmentButton.setTitle("Skip Intro", for: .normal)
        skipSegmentButton.setTitleColor(.black, for: .normal)
        skipSegmentButton.titleLabel?.font = .boldSystemFont(ofSize: 14)
        skipSegmentButton.backgroundColor = UIColor.white.withAlphaComponent(0.94)
        skipSegmentButton.layer.cornerRadius = 8
        skipSegmentButton.contentEdgeInsets = UIEdgeInsets(top: 9, left: 18, bottom: 9, right: 18)
        skipSegmentButton.isHidden = true
        skipSegmentButton.addTarget(self, action: #selector(handleSkipSegment), for: .touchUpInside)
        view.addSubview(skipSegmentButton)

        nextEpCardView.translatesAutoresizingMaskIntoConstraints = false
        nextEpCardView.backgroundColor = UIColor(red: 14/255, green: 16/255, blue: 22/255, alpha: 0.94)
        nextEpCardView.layer.cornerRadius = 12
        nextEpCardView.layer.borderWidth = 1
        nextEpCardView.layer.borderColor = UIColor.white.withAlphaComponent(0.22).cgColor
        nextEpCardView.isHidden = true

        let nextTag = UILabel()
        nextTag.translatesAutoresizingMaskIntoConstraints = false
        nextTag.text = "NEXT EPISODE"
        nextTag.textColor = UIColor(red: 229/255, green: 9/255, blue: 20/255, alpha: 1)
        nextTag.font = .systemFont(ofSize: 11, weight: .heavy)

        nextEpTitleLabel.translatesAutoresizingMaskIntoConstraints = false
        nextEpTitleLabel.textColor = .white
        nextEpTitleLabel.font = .boldSystemFont(ofSize: 15)
        nextEpTitleLabel.text = "Next Episode"

        nextEpCountdownLabel.translatesAutoresizingMaskIntoConstraints = false
        nextEpCountdownLabel.textColor = UIColor.white.withAlphaComponent(0.75)
        nextEpCountdownLabel.font = .systemFont(ofSize: 12, weight: .medium)
        nextEpCountdownLabel.text = "Starting in 10s..."

        let playNextBtn = UIButton(type: .system)
        playNextBtn.translatesAutoresizingMaskIntoConstraints = false
        playNextBtn.setImage(UIImage(systemName: "play.fill"), for: .normal)
        playNextBtn.tintColor = .black
        playNextBtn.setTitle(" Play Next", for: .normal)
        playNextBtn.setTitleColor(.black, for: .normal)
        playNextBtn.titleLabel?.font = .boldSystemFont(ofSize: 13)
        playNextBtn.backgroundColor = .white
        playNextBtn.layer.cornerRadius = 6
        playNextBtn.contentEdgeInsets = UIEdgeInsets(top: 7, left: 14, bottom: 7, right: 14)
        playNextBtn.addTarget(self, action: #selector(playNextEpisodeInPlayer), for: .touchUpInside)

        let dismissNextBtn = UIButton(type: .system)
        dismissNextBtn.translatesAutoresizingMaskIntoConstraints = false
        dismissNextBtn.setTitle("Watch Credits", for: .normal)
        dismissNextBtn.setTitleColor(.white, for: .normal)
        dismissNextBtn.titleLabel?.font = .systemFont(ofSize: 12, weight: .semibold)
        dismissNextBtn.backgroundColor = UIColor.white.withAlphaComponent(0.14)
        dismissNextBtn.layer.cornerRadius = 6
        dismissNextBtn.contentEdgeInsets = UIEdgeInsets(top: 7, left: 12, bottom: 7, right: 12)
        dismissNextBtn.addTarget(self, action: #selector(dismissNextEpisodeCard), for: .touchUpInside)

        nextEpCardView.addSubview(nextTag)
        nextEpCardView.addSubview(nextEpTitleLabel)
        nextEpCardView.addSubview(nextEpCountdownLabel)
        nextEpCardView.addSubview(playNextBtn)
        nextEpCardView.addSubview(dismissNextBtn)
        view.addSubview(nextEpCardView)

        NSLayoutConstraint.activate([
            skipSegmentButton.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -24),
            skipSegmentButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -92),

            nextEpCardView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -24),
            nextEpCardView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -92),
            nextEpCardView.widthAnchor.constraint(equalToConstant: 268),

            nextTag.topAnchor.constraint(equalTo: nextEpCardView.topAnchor, constant: 12),
            nextTag.leadingAnchor.constraint(equalTo: nextEpCardView.leadingAnchor, constant: 14),

            nextEpTitleLabel.topAnchor.constraint(equalTo: nextTag.bottomAnchor, constant: 4),
            nextEpTitleLabel.leadingAnchor.constraint(equalTo: nextEpCardView.leadingAnchor, constant: 14),
            nextEpTitleLabel.trailingAnchor.constraint(equalTo: nextEpCardView.trailingAnchor, constant: -14),

            nextEpCountdownLabel.topAnchor.constraint(equalTo: nextEpTitleLabel.bottomAnchor, constant: 3),
            nextEpCountdownLabel.leadingAnchor.constraint(equalTo: nextEpCardView.leadingAnchor, constant: 14),

            playNextBtn.topAnchor.constraint(equalTo: nextEpCountdownLabel.bottomAnchor, constant: 10),
            playNextBtn.leadingAnchor.constraint(equalTo: nextEpCardView.leadingAnchor, constant: 14),
            playNextBtn.bottomAnchor.constraint(equalTo: nextEpCardView.bottomAnchor, constant: -12),

            dismissNextBtn.centerYAnchor.constraint(equalTo: playNextBtn.centerYAnchor),
            dismissNextBtn.leadingAnchor.constraint(equalTo: playNextBtn.trailingAnchor, constant: 8)
        ])

        NSLayoutConstraint.activate([
            backGroup.topAnchor.constraint(equalTo: overlayView.safeAreaLayoutGuide.topAnchor, constant: 10),
            backGroup.leadingAnchor.constraint(equalTo: overlayView.safeAreaLayoutGuide.leadingAnchor, constant: 18),
            backBtn.widthAnchor.constraint(equalToConstant: 36),
            backBtn.heightAnchor.constraint(equalToConstant: 36),

            titleLabel.centerYAnchor.constraint(equalTo: backGroup.centerYAnchor),
            titleLabel.leadingAnchor.constraint(equalTo: backGroup.trailingAnchor, constant: 12),
            topActionsStack.centerYAnchor.constraint(equalTo: backGroup.centerYAnchor),
            topActionsStack.trailingAnchor.constraint(equalTo: overlayView.safeAreaLayoutGuide.trailingAnchor, constant: -18),
            topNextButton.widthAnchor.constraint(equalToConstant: 36),
            topNextButton.heightAnchor.constraint(equalToConstant: 36),
            topRestartButton.widthAnchor.constraint(equalToConstant: 36),
            topRestartButton.heightAnchor.constraint(equalToConstant: 36),

            titleLabel.trailingAnchor.constraint(lessThanOrEqualTo: topActionsStack.leadingAnchor, constant: -10),

            playPauseButton.centerXAnchor.constraint(equalTo: overlayView.centerXAnchor),
            playPauseButton.centerYAnchor.constraint(equalTo: overlayView.centerYAnchor),
            playPauseButton.widthAnchor.constraint(equalToConstant: 64),
            playPauseButton.heightAnchor.constraint(equalToConstant: 64),

            rewBtn.centerYAnchor.constraint(equalTo: playPauseButton.centerYAnchor),
            rewBtn.trailingAnchor.constraint(equalTo: playPauseButton.leadingAnchor, constant: -42),

            fwdBtn.centerYAnchor.constraint(equalTo: playPauseButton.centerYAnchor),
            fwdBtn.leadingAnchor.constraint(equalTo: playPauseButton.trailingAnchor, constant: 42),

            actionsStack.bottomAnchor.constraint(equalTo: overlayView.safeAreaLayoutGuide.bottomAnchor, constant: -10),
            actionsStack.centerXAnchor.constraint(equalTo: overlayView.centerXAnchor),
            unlockButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -18),
            unlockButton.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 20),

            currentPosLabel.leadingAnchor.constraint(equalTo: overlayView.safeAreaLayoutGuide.leadingAnchor, constant: 22),
            currentPosLabel.bottomAnchor.constraint(equalTo: actionsStack.topAnchor, constant: -14),

            durationLabel.trailingAnchor.constraint(equalTo: overlayView.safeAreaLayoutGuide.trailingAnchor, constant: -22),
            durationLabel.centerYAnchor.constraint(equalTo: currentPosLabel.centerYAnchor),

            seekSlider.leadingAnchor.constraint(equalTo: currentPosLabel.trailingAnchor, constant: 12),
            seekSlider.trailingAnchor.constraint(equalTo: durationLabel.leadingAnchor, constant: -12),
            seekSlider.centerYAnchor.constraint(equalTo: currentPosLabel.centerYAnchor),

            subtitleLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            subtitleLabel.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -14),
            subtitleLabel.widthAnchor.constraint(lessThanOrEqualTo: view.widthAnchor, multiplier: 0.85),

            statusToastLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            statusToastLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            statusToastLabel.heightAnchor.constraint(equalToConstant: 30),
            statusToastLabel.widthAnchor.constraint(greaterThanOrEqualToConstant: 160),

            gestureHudContainer.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 24),
            gestureHudContainer.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            gestureHudContainer.heightAnchor.constraint(equalToConstant: 36),
            hudStack.leadingAnchor.constraint(equalTo: gestureHudContainer.leadingAnchor, constant: 14),
            hudStack.trailingAnchor.constraint(equalTo: gestureHudContainer.trailingAnchor, constant: -14),
            hudStack.centerYAnchor.constraint(equalTo: gestureHudContainer.centerYAnchor),
            gestureHudIconView.widthAnchor.constraint(equalToConstant: 17),
            gestureHudIconView.heightAnchor.constraint(equalToConstant: 17),

            ambientTrackView.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            ambientTrackView.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            ambientTrackView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            ambientTrackView.heightAnchor.constraint(equalToConstant: 2.5),

            ambientFillView.leadingAnchor.constraint(equalTo: ambientTrackView.leadingAnchor),
            ambientFillView.topAnchor.constraint(equalTo: ambientTrackView.topAnchor),
            ambientFillView.bottomAnchor.constraint(equalTo: ambientTrackView.bottomAnchor)
        ])
    }

    private func setupSeekBadges() {
        for (badge, isLeft) in [(leftSeekBadge, true), (rightSeekBadge, false)] {
            badge.translatesAutoresizingMaskIntoConstraints = false
            badge.textColor = .white
            badge.font = .boldSystemFont(ofSize: 17)
            badge.textAlignment = .center
            badge.backgroundColor = UIColor.black.withAlphaComponent(0.55)
            badge.layer.cornerRadius = 20
            badge.layer.masksToBounds = true
            badge.isHidden = true
            view.addSubview(badge)
            NSLayoutConstraint.activate([
                badge.centerYAnchor.constraint(equalTo: view.centerYAnchor),
                badge.widthAnchor.constraint(equalToConstant: 105),
                badge.heightAnchor.constraint(equalToConstant: 42),
                isLeft
                    ? badge.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 60)
                    : badge.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -60)
            ])
        }
    }

    private func setupGestureHuds() {
        func configureHud(container: UIView, track: UIView, fill: UIView, label: UILabel, iconName: String, fillColor: UIColor, isLeft: Bool) -> NSLayoutConstraint {
            container.translatesAutoresizingMaskIntoConstraints = false
            container.isHidden = true
            view.addSubview(container)

            let icon = UIImageView(image: UIImage(systemName: iconName))
            icon.translatesAutoresizingMaskIntoConstraints = false
            icon.tintColor = .white
            icon.contentMode = .scaleAspectFit

            track.translatesAutoresizingMaskIntoConstraints = false
            track.backgroundColor = UIColor.white.withAlphaComponent(0.32)
            track.layer.cornerRadius = 3
            track.clipsToBounds = true

            fill.translatesAutoresizingMaskIntoConstraints = false
            fill.backgroundColor = fillColor
            fill.layer.cornerRadius = 3
            track.addSubview(fill)

            label.translatesAutoresizingMaskIntoConstraints = false
            label.textColor = .white
            label.font = .boldSystemFont(ofSize: 11)
            label.textAlignment = .center

            container.addSubview(icon)
            container.addSubview(track)
            container.addSubview(label)

            let heightConstraint = fill.heightAnchor.constraint(equalToConstant: 64)
            NSLayoutConstraint.activate([
                container.centerYAnchor.constraint(equalTo: view.centerYAnchor),
                container.widthAnchor.constraint(equalToConstant: 42),
                container.heightAnchor.constraint(equalToConstant: 180),
                isLeft
                    ? container.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 22)
                    : container.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -22),

                icon.topAnchor.constraint(equalTo: container.topAnchor),
                icon.centerXAnchor.constraint(equalTo: container.centerXAnchor),
                icon.widthAnchor.constraint(equalToConstant: 20),
                icon.heightAnchor.constraint(equalToConstant: 20),

                label.bottomAnchor.constraint(equalTo: container.bottomAnchor),
                label.centerXAnchor.constraint(equalTo: container.centerXAnchor),

                track.topAnchor.constraint(equalTo: icon.bottomAnchor, constant: 8),
                track.bottomAnchor.constraint(equalTo: label.topAnchor, constant: -8),
                track.centerXAnchor.constraint(equalTo: container.centerXAnchor),
                track.widthAnchor.constraint(equalToConstant: 6),

                fill.leadingAnchor.constraint(equalTo: track.leadingAnchor),
                fill.trailingAnchor.constraint(equalTo: track.trailingAnchor),
                fill.bottomAnchor.constraint(equalTo: track.bottomAnchor),
                heightConstraint
            ])
            return heightConstraint
        }

        brightnessFillHeightConstraint = configureHud(
            container: brightnessHudView,
            track: brightnessTrackView,
            fill: brightnessFillView,
            label: brightnessPctLabel,
            iconName: "sun.max.fill",
            fillColor: UIColor(red: 250/255, green: 204/255, blue: 21/255, alpha: 1),
            isLeft: true
        )
        volumeFillHeightConstraint = configureHud(
            container: volumeHudView,
            track: volumeTrackView,
            fill: volumeFillView,
            label: volumePctLabel,
            iconName: "speaker.wave.2.fill",
            fillColor: UIColor(red: 229/255, green: 9/255, blue: 20/255, alpha: 1),
            isLeft: false
        )
    }

    private func setupResolverWebView() {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = WKWebsiteDataStore.default()
        config.allowsInlineMediaPlayback = true
        config.preferences.isTextInteractionEnabled = false
        config.mediaTypesRequiringUserActionForPlayback = []
        config.preferences.javaScriptCanOpenWindowsAutomatically = false
        let ucc = WKUserContentController()
        ucc.add(self, name: "PlayerSniffer")
        let snifferJs = """
        (function(){
          var hn = (location.hostname || '').toLowerCase();
          if (/cloudflare\\.com|recaptcha\\.net|hcaptcha\\.com|arkoselabs\\.com|geetest\\.com/.test(hn) || (hn.indexOf('google.com') !== -1 && location.pathname.indexOf('/recaptcha') !== -1)) {
            try { window.webkit.messageHandlers.PlayerSniffer.postMessage({ kind: 'challenge', url: location.href }); } catch(e) {}
            return;
          }

          window.__sUserPlayed = true;
          window.__sbSrvIdx = 0;
          window.__sbStopped = false;
          function tryAutoClickServer() {
            if (window.__sbStopped) return;
            try {
              document.querySelectorAll('#pl_but,.play,.btn-play,.vjs-big-play-button,.jw-icon-display,[aria-label*="Play"],button[class*="play"]').forEach(function(b) {
                try { b.click(); } catch(e) {}
              });
              var vids = document.querySelectorAll('video');
              vids.forEach(function(v) { try { if (v.paused) v.play().catch(function(){}); } catch(e) {} });
            } catch(e) {}
          }
          window.addEventListener('message', function(ev) {
            try {
              if (ev && ev.data && ev.data.__sbResume) { window.__sbStopped = false; }
              if (ev && ev.data && ev.data.__sbStop) {
                window.__sbStopped = true;
                document.querySelectorAll('video,audio').forEach(function(v) { try { v.pause(); v.muted = true; } catch(e) {} });
              }
            } catch(e) {}
          });
          setInterval(function() {
            if (window.__sbStopped) return;
            tryAutoClickServer();
          }, 2200);

          window.__sPendingStream = null;
          window.__sPendingInline = null;
          function postAd(u) {
            try { window.webkit.messageHandlers.PlayerSniffer.postMessage({ kind: 'ad_blocked', url: u || location.href }); } catch(e) {}
          }
          function flushPendingStream() {
            if (!window.__sUserPlayed) return;
            if (window.__sPendingInline) {
              try { window.webkit.messageHandlers.PlayerSniffer.postMessage(window.__sPendingInline); } catch(e) {}
              window.__sPendingInline = null;
            }
            if (window.__sPendingStream) {
              try { window.webkit.messageHandlers.PlayerSniffer.postMessage(window.__sPendingStream); } catch(e) {}
              window.__sPendingStream = null;
            }
          }
          function getAllVideos(root) {
            var out = [];
            try {
              var walk = function(node) {
                if (!node || !node.querySelectorAll) return;
                node.querySelectorAll('video').forEach(function(v) { out.push(v); });
                node.querySelectorAll('iframe').forEach(function(fr) {
                  try { if (fr.contentDocument) walk(fr.contentDocument); } catch(e) {}
                });
                node.querySelectorAll('*').forEach(function(el) {
                  if (el.shadowRoot) walk(el.shadowRoot);
                });
              };
              walk(root || document);
            } catch(e) {}
            return out;
          }
          function isInnerPlayerReady() {
            if (window !== window.top) return true;
            if (document.querySelector('[class*="server"], .servers')) return true;
            var vids = getAllVideos(document);
            for (var i = 0; i < vids.length; i++) {
              if (isFinite(vids[i].duration) && vids[i].duration >= 60) return true;
            }
            var bt = (document.body && document.body.innerText || '').toLowerCase();
            return bt.indexOf('servers') !== -1;
          }
          function extractUrlsFromString(str) {
            if (!str || typeof str !== 'string') return [];
            var out = [];
            var parts = str.split(/["'\\s,;|]+/);
            for (var i = 0; i < parts.length; i++) {
              var p = parts[i];
              if (p.indexOf(']') !== -1) p = p.slice(p.lastIndexOf(']') + 1);
              if (p.indexOf('http') === 0) out.push(p);
            }
            return out;
          }
          try {
            var _pjs;
            Object.defineProperty(window, 'Playerjs', {
              configurable: true,
              get: function() { return _pjs; },
              set: function(fn) {
                if (typeof fn === 'function') {
                  _pjs = function(cfg) {
                    try {
                      if (cfg && cfg.file) {
                        extractUrlsFromString(String(cfg.file)).forEach(function(u) { post(u, u.indexOf('.m3u8') !== -1 || u.indexOf('.txt') !== -1, true, false); });
                      }
                    } catch(e) {}
                    return fn.apply(this, arguments);
                  };
                } else {
                  _pjs = fn;
                }
              }
            });
          } catch(e) {}
          document.addEventListener('click', function(ev) {
            if (!isInnerPlayerReady()) return;
            var t = ev && ev.target;
            var el = t && t.closest ? t.closest('[data-s-idx], .servers li, .servers a, [class*="server"] li, [class*="server"] a, [data-server], [data-id], [data-hash]') : null;
            if (el) {
              window.__sUserPlayed = true;
              window.__sPendingStream = null;
              window.__sPendingInline = null;
              try { window.webkit.messageHandlers.PlayerSniffer.postMessage({ kind: 'subserver_selected', url: location.href }); } catch(e) {}
              return;
            }
            var txt = (t && (t.innerText || t.textContent) || '').trim().toLowerCase();
            if (txt === 'servers' || txt.indexOf('servers') === 0 || txt.indexOf('verify') !== -1 || txt.indexOf('robot') !== -1) {
              window.__sUserPlayed = false;
              window.__sPendingStream = null;
              window.__sPendingInline = null;
              return;
            }
            var hasVideo = getAllVideos(document).length > 0 || !!document.querySelector('.jwplayer, .plyr, .video-js, [id*="player"]');
            if (!hasVideo) return;
            window.__sUserPlayed = true;
            setTimeout(flushPendingStream, 100);
          }, true);
          try {
            var origPlay = HTMLMediaElement.prototype.play;
            HTMLMediaElement.prototype.play = function() {
              var isAd = (this.videoHeight > 0 && this.videoWidth > 0 && this.videoHeight > this.videoWidth * 0.95) || (isFinite(this.duration) && this.duration > 0 && this.duration < 60);
              if (!isAd && isInnerPlayerReady()) {
                window.__sUserPlayed = true;
                var dOk = isFinite(this.duration) && this.duration >= 60;
                if (this.currentSrc) post(this.currentSrc, false, dOk, dOk);
                else if (this.src) post(this.src, false, dOk, dOk);
                flushPendingStream();
              }
              return origPlay.apply(this, arguments);
            };
          } catch(e) {}
          try {
            window.open = function(u) { postAd(u || location.href); return null; };
          } catch(e) {}
          function post(u, isHlsHint, forceVideo, forceImmediate) {
            if (!u || typeof u !== 'string') return;
            if (u.indexOf('blob:') === 0 || u.indexOf('data:') === 0) return;
            try { u = new URL(u, location.href).href; } catch(e) {}
            if (u.indexOf('http') !== 0) return;
            var l = u.toLowerCase();
            if ((l.indexOf('.ts') !== -1 || l.indexOf('.m4s') !== -1 || l.indexOf('.aac') !== -1) && l.indexOf('.m3u8') === -1) return;
            if (l.indexOf('.vtt') !== -1 || l.indexOf('.srt') !== -1) {
              try { window.webkit.messageHandlers.PlayerSniffer.postMessage({ kind: 'sub', url: u, ref: location.href }); } catch(e) {}
              return;
            }
            if (/vast|vmap|preroll|doubleclick|exoclick|exosrv|juicyads|trafficjunky|popads|popcash|adsterra|propellerads|monetag|tsyndicate|realsrv|magsrv|hilltopads|admaven|clickadu|galaksion|ero-advertising/i.test(l)) {
              postAd(u);
              return;
            }
            var hlsMatch = !!isHlsHint || l.indexOf('.m3u8') !== -1 || l.indexOf('master.txt') !== -1 || l.indexOf('playlist.txt') !== -1 || l.indexOf('/hls/') !== -1 || l.indexOf('/hls2/') !== -1 || l.indexOf('type=hls') !== -1;
            var isHtmlOrEmbed = l.indexOf('.php') !== -1 || l.indexOf('.html') !== -1 || l.indexOf('/embed') !== -1 || l.indexOf('streamingnow.mov/?play=') !== -1 || l.indexOf('hnembed.cc/embed/') !== -1;
            if (isHtmlOrEmbed && !forceImmediate && !isHlsHint && l.indexOf('.m3u8') === -1 && l.indexOf('.mp4') === -1) return;
            var videoMatch = !!forceVideo || hlsMatch || l.indexOf('.mpd') !== -1 || l.indexOf('.webm') !== -1 || l.indexOf('.mkv') !== -1 || l.indexOf('videoplayback') !== -1 || l.indexOf('googleusercontent.com') !== -1 || (l.indexOf('.mp4') !== -1 && l.indexOf('preview') === -1 && l.indexOf('trailer') === -1) || l.indexOf('mime=video') !== -1 || l.indexOf('/get_file/') !== -1;
            if (videoMatch) {
              var hint = (document.title || '') + ' ' + location.href;
              var payload = { kind: 'stream', url: u, ref: location.href, hint: hint, isHls: hlsMatch, bypass: !!forceImmediate };
              window.__sUserPlayed = true;
              try { window.webkit.messageHandlers.PlayerSniffer.postMessage(payload); } catch(e) {}
            }
          }
          if (window.URL && URL.createObjectURL) {
            var oCreateObj = URL.createObjectURL;
            URL.createObjectURL = function(obj) {
              try {
                if (obj && typeof Response !== 'undefined') {
                  new Response(obj).text().then(function(txt) {
                    if (txt && txt.replace(String.fromCharCode(0xFEFF), '').trim().indexOf('#EXTM3U') === 0) {
                      var payload = { kind: 'm3u8_inline', url: location.href, m3u8: txt, ref: location.href, hint: (document.title || '') + ' ' + location.href };
                      if (window.__sUserPlayed) {
                        window.webkit.messageHandlers.PlayerSniffer.postMessage(payload);
                      } else {
                        window.__sPendingInline = payload;
                      }
                    }
                  }).catch(function(){});
                }
              } catch(e) {}
              return oCreateObj.apply(this, arguments);
            };
          }
          if (window.fetch) {
            var of = window.fetch;
            window.fetch = function(i) {
              var u = typeof i === 'string' ? i : (i && i.url);
              try { post(u, false, false, false); } catch(e) {}
              return of.apply(this, arguments).then(function(res) {
                try {
                  var ct = (res && res.headers && res.headers.get('content-type') || '').toLowerCase();
                  var ru = (res && res.url) || u;
                  var isH = ct.indexOf('mpegurl') !== -1;
                  if (isH || ct.indexOf('video/') === 0 || ct.indexOf('dash+xml') !== -1) {
                    if (ru && typeof ru === 'string' && ru.indexOf('http') === 0) {
                      post(ru, isH, true, false);
                    }
                  } else if (ru && typeof ru === 'string' && ru.indexOf('http') === 0 && !/\\.(css|svg|woff2?|ico)(\\?|$)/i.test(ru)) {
                    res.clone().text().then(function(txt) {
                      if (!txt) return;
                      if (txt.slice(0, 64).replace(String.fromCharCode(0xFEFF), '').trim().indexOf('#EXTM3U') === 0) {
                        var p = { kind: 'm3u8_inline', url: ru, m3u8: txt, ref: location.href, hint: (document.title || '') + ' ' + location.href };
                        if (window.__sUserPlayed) {
                          try { window.webkit.messageHandlers.PlayerSniffer.postMessage(p); } catch(e) {}
                        } else {
                          window.__sPendingInline = p;
                        }
                        post(ru, true, true, false);
                      } else if (txt.length < 300000 && (txt.indexOf('.m3u8') !== -1 || txt.indexOf('.mp4') !== -1)) {
                        extractUrlsFromString(txt).forEach(function(eu) {
                          if (eu.indexOf('.m3u8') !== -1 || eu.indexOf('.mp4') !== -1) {
                            post(eu, eu.indexOf('.m3u8') !== -1, true, false);
                          }
                        });
                      }
                    }).catch(function(){});
                  }
                } catch(e) {}
                return res;
              });
            };
          }
          if (window.XMLHttpRequest) {
            var oo = XMLHttpRequest.prototype.open;
            var os = XMLHttpRequest.prototype.send;
            XMLHttpRequest.prototype.open = function(m, u) {
              this._sUrl = u;
              try { post(u, false, false, false); } catch(e) {}
              return oo.apply(this, arguments);
            };
            XMLHttpRequest.prototype.send = function() {
              try {
                this.addEventListener('readystatechange', function() {
                  if (this.readyState === 4 && this.status >= 200 && this.status < 400) {
                    try {
                      var ct = (this.getResponseHeader('content-type') || '').toLowerCase();
                      var ru = this.responseURL || this._sUrl;
                      var isH = ct.indexOf('mpegurl') !== -1;
                      var bodyHls = false;
                      if (!isH && (this.responseType === '' || this.responseType === 'text') && typeof this.responseText === 'string') {
                        var head = this.responseText.slice(0, 64).replace(String.fromCharCode(0xFEFF), '').trim();
                        if (head.indexOf('#EXTM3U') === 0) {
                          bodyHls = true;
                          var p = { kind: 'm3u8_inline', url: ru || location.href, m3u8: this.responseText, ref: location.href, hint: (document.title || '') + ' ' + location.href };
                          if (window.__sUserPlayed) {
                            try { window.webkit.messageHandlers.PlayerSniffer.postMessage(p); } catch(e) {}
                          } else {
                            window.__sPendingInline = p;
                          }
                        } else if (this.responseText.length < 300000 && (this.responseText.indexOf('.m3u8') !== -1 || this.responseText.indexOf('.mp4') !== -1)) {
                          extractUrlsFromString(this.responseText).forEach(function(eu) {
                            if (eu.indexOf('.m3u8') !== -1 || eu.indexOf('.mp4') !== -1) {
                              post(eu, eu.indexOf('.m3u8') !== -1, true, false);
                            }
                          });
                        }
                      } else if (!isH && this.responseType === 'arraybuffer' && this.response && this.response.byteLength >= 7) {
                        var arr = new Uint8Array(this.response, 0, Math.min(32, this.response.byteLength));
                        var s = '';
                        for (var k = 0; k < arr.length; k++) s += String.fromCharCode(arr[k]);
                        if (s.trim().indexOf('#EXTM3U') === 0) bodyHls = true;
                      }
                      if (isH || bodyHls || ct.indexOf('video/') === 0 || ct.indexOf('dash+xml') !== -1) {
                        if (ru && typeof ru === 'string' && ru.indexOf('http') === 0) {
                          post(ru, isH || bodyHls, true, false);
                        }
                      }
                    } catch(e) {}
                  }
                });
              } catch(e) {}
              return os.apply(this, arguments);
            };
          }
          try {
            var desc = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, 'src');
            if (desc && desc.set) {
              var origSet = desc.set;
              Object.defineProperty(HTMLMediaElement.prototype, 'src', {
                set: function(v) { try { post(v, false, false, false); } catch(e) {} return origSet.call(this, v); },
                get: desc.get,
                configurable: true
              });
            }
            var origSetAttr = Element.prototype.setAttribute;
            Element.prototype.setAttribute = function(k, v) {
              if ((k === 'src' || k === 'SRC') && (this.tagName === 'VIDEO' || this.tagName === 'SOURCE')) {
                try { post(v, false, true, false); } catch(e) {}
              }
              return origSetAttr.apply(this, arguments);
            };
          } catch(e) {}
          try {
            new PerformanceObserver(function(list){ list.getEntries().forEach(function(e){ post(e.name, false, false, false); }); }).observe({ entryTypes: ['resource'] });
          } catch(e) {}
          function scanAndClick() {
            try {
              var txt = ((document.title || '') + ' ' + (document.body ? document.body.innerText.slice(0, 500) : '')).toLowerCase();
              if (txt.indexOf('no sources') !== -1 || txt.indexOf('404 not found') !== -1 || txt.indexOf('502 bad gateway') !== -1 || txt.indexOf('media not found') !== -1 || txt.indexOf('video not found') !== -1) {
                window.webkit.messageHandlers.PlayerSniffer.postMessage({ kind: 'dead', url: location.href });
                return;
              }
              var hasWidget = !!document.querySelector('iframe[src*="challenges.cloudflare.com"], iframe[src*="turnstile"], iframe[src*="challenge"], iframe[src*="captcha"], iframe[src*="recaptcha"], iframe[src*="hcaptcha"], .cf-turnstile, .g-recaptcha, .h-captcha, #cf-turnstile-response, #cf-challenge-running, [id*="turnstile"], [class*="turnstile"], [class*="geetest"]');
              if (hasWidget || txt.indexOf('just a moment') !== -1 || txt.indexOf('verify you are human') !== -1 || txt.indexOf('security check') !== -1 || txt.indexOf('are you a robot') !== -1) {
                window.webkit.messageHandlers.PlayerSniffer.postMessage({ kind: 'challenge', url: location.href });
                return;
              }
              if (false) {}
              if (false) document.querySelectorAll('button, div, span, a').forEach(function(el) {
                var t = (el.innerText || '').trim().toLowerCase();
                if (t === 'skip ad' || t === 'skip ads') {
                  postAd(location.href);
                  try { el.click(); } catch(e) {}
                }
              });
              try {
                var srvList = [];
                var seenSrv = {};
                var cands = document.querySelectorAll('.servers li, .servers a, .servers button, .servers div, [class*="server"] li, [class*="server"] a, [class*="server"] button, [class*="server"] div, [data-server], [data-id], [data-hash]');
                var sIdx = 0;
                cands.forEach(function(el) {
                  var label = (el.innerText || el.textContent || '').replace(/\\s+/g, ' ').trim();
                  if (!label || label.length > 60 || /^servers?$/i.test(label) || /go to website/i.test(label)) return;
                  if (seenSrv[label]) return;
                  seenSrv[label] = 1;
                  var key = 's' + (sIdx++);
                  el.setAttribute('data-s-idx', key);
                  srvList.push({ name: label, idx: key });
                });
                if (srvList.length > 0) {
                  window.webkit.messageHandlers.PlayerSniffer.postMessage({ kind: 'servers_list', url: location.href, servers: srvList });
                }
              } catch(e) {}
              var anyPlaying = false;
              getAllVideos(document).forEach(function(v) {
                v.setAttribute('playsinline', '');
                v.setAttribute('webkit-playsinline', '');
                var isPortraitAd = v.videoHeight > 0 && v.videoWidth > 0 && v.videoHeight > v.videoWidth * 0.95;
                var isShortAd = isFinite(v.duration) && v.duration > 0 && v.duration < 60;
                if (isPortraitAd || isShortAd) {
                  v.muted = true;
                  try {
                    v.style.display = 'none';
                    v.style.opacity = '0';
                    if (isFinite(v.duration) && v.duration > 1 && v.currentTime < v.duration - 0.2) {
                      v.currentTime = v.duration - 0.05;
                    }
                    document.querySelectorAll('div, a, button').forEach(function(el) {
                      var tx = (el.innerText || '').trim().toLowerCase();
                      if (tx === 'go to website' || tx.indexOf('install ') === 0 || tx === 'skip ad' || tx === 'skip ads') {
                        if (tx.indexOf('skip') === 0) { try { el.click(); } catch(e) {} }
                        else { try { el.style.display = 'none'; } catch(e) {} }
                      }
                    });
                  } catch(e) {}
                  postAd(v.currentSrc || v.src || location.href);
                  return;
                }
                if (!v.__sbAutoP) { v.__sbAutoP = 1; if (v.paused && !window.__sbUserPaused) { try { v.autoplay = true; v.play().catch(function(){}); } catch(e) {} } }
                var isFeature = isFinite(v.duration) && v.duration >= 60;
                var isActivelyPlaying = (!v.paused && v.currentTime > 0.2) || v.currentTime > 0.5;
                if (isActivelyPlaying && (isFeature || isInnerPlayerReady())) {
                  anyPlaying = true;
                  window.__sUserPlayed = true;
                }
                var cs = v.currentSrc || v.src || '';
                if (cs.indexOf('blob:') === 0 && (isFeature || isActivelyPlaying) && !v.__blobFetched) {
                  v.__blobFetched = true;
                  setTimeout(function() {
                    try {
                      if (!v.paused && v.currentTime > 1.0) {
                        window.webkit.messageHandlers.PlayerSniffer.postMessage({ kind: 'diag_toast', url: location.href, msg: 'WebView blob stream (' + location.hostname + ')' });
                      }
                    } catch(e) {}
                  }, 1800);
                  try {
                    fetch(cs).then(function(r){ return r.text(); }).then(function(txt){
                      if (txt && txt.replace(String.fromCharCode(0xFEFF), '').trim().indexOf('#EXTM3U') === 0) {
                        window.webkit.messageHandlers.PlayerSniffer.postMessage({ kind: 'm3u8_inline', url: location.href, m3u8: txt, ref: location.href, hint: (document.title || '') + ' ' + location.href });
                      }
                    }).catch(function(){});
                  } catch(e) {}
                }
                if (v.src) post(v.src, false, true, isActivelyPlaying);
                if (v.currentSrc) post(v.currentSrc, false, true, isActivelyPlaying);
                v.querySelectorAll('source').forEach(function(s) {
                  if (s.src) post(s.src, false, true, isActivelyPlaying);
                });
              });
              if (anyPlaying) {
                flushPendingStream();
                try {
                  document.querySelectorAll('a[download], a[href*=".mp4"], a[href*=".m3u8"], a[href*="/dl/"], a[href*="/d/"], a[href*="download"]').forEach(function(a) {
                    if (a.href && a.href.indexOf('http') === 0 && a.href.indexOf('javascript:') === -1) {
                      post(a.href, a.href.indexOf('.m3u8') !== -1, true, true);
                    }
                  });
                } catch(e) {}
                try {
                  if (window.player && typeof window.player.api === 'function') {
                    var pFile = window.player.api('file');
                    if (pFile) extractUrlsFromString(String(pFile)).forEach(function(u) { post(u, u.indexOf('.m3u8') !== -1, true, true); });
                  }
                  if (window.art && window.art.option && window.art.option.url) {
                    post(window.art.option.url, window.art.option.url.indexOf('.m3u8') !== -1, true, true);
                  }
                  if (window.dp && window.dp.options && window.dp.options.video && window.dp.options.video.url) {
                    post(window.dp.options.video.url, window.dp.options.video.url.indexOf('.m3u8') !== -1, true, true);
                  }
                } catch(e) {}
                try {
                  var scanP = function(w) {
                    try {
                      w.performance.getEntriesByType('resource').forEach(function(e) {
                        var en = (e.name || '').toLowerCase();
                        var it = (e.initiatorType || '').toLowerCase();
                        if (it === 'video' || it === 'media') {
                          post(e.name, en.indexOf('m3u8') !== -1, true, true);
                          return;
                        }
                        var isStatic = /\\.(js|css|png|jpg|jpeg|gif|svg|woff2?|ico|ttf)(\\?|$)/i.test(en) || /google|cloudflare|fonts|analytics|jquery|bootstrap|jsdelivr|cdnjs/i.test(en);
                        if (!isStatic && (en.indexOf('.m3u8') !== -1 || en.indexOf('.mp4') !== -1 || en.indexOf('master.txt') !== -1 || en.indexOf('playlist.txt') !== -1 || en.indexOf('/hls/') !== -1 || en.indexOf('/hls2/') !== -1 || en.indexOf('videoplayback') !== -1 || en.indexOf('mime=video') !== -1)) {
                          post(e.name, en.indexOf('m3u8') !== -1 || en.indexOf('master.') !== -1 || en.indexOf('index.') !== -1 || en.indexOf('.txt') !== -1, true, true);
                        }
                      });
                    } catch(e) {}
                  };
                  scanP(window);
                  document.querySelectorAll('iframe').forEach(function(fr) {
                    try { if (fr.contentWindow) scanP(fr.contentWindow); } catch(e) {}
                  });
                } catch(e) {}
              }
            } catch(e) {}
          }
          setTimeout(scanAndClick, 500);
          setInterval(scanAndClick, 450);
        })();
        """
        if !directWebPlayerMode {
            ucc.addUserScript(WKUserScript(source: snifferJs, injectionTime: .atDocumentStart, forMainFrameOnly: false))
        }
        let uiCleanJs = """
        (function(){
          try {
            if (window.__sbUiClean) return;
            window.__sbUiClean = 1;
            try {
              var _sbArt = '';
              function mkArt() {
                if (_sbArt) return _sbArt;
                try {
                  var c = document.createElement('canvas');
                  c.width = 512; c.height = 512;
                  var x = c.getContext('2d');
                  x.fillStyle = '#000';
                  x.fillRect(0, 0, 512, 512);
                  x.save();
                  x.translate(80, 80);
                  x.scale(5.5, 5.5);
                  var p = new Path2D('M46 12H24C18.5 12 14 16.5 14 22C14 27.5 18.5 31 24 31H38C41.5 31 44 33.5 44 37C44 40.5 41.5 43 38 43H16L13 52H39C46.5 52 52 46.5 52 39C52 32.5 47 28 40 28H25C22.2 28 20 25.8 20 23C20 20.2 22.2 18 25 18H43L46 12Z');
                  x.fillStyle = '#fff';
                  x.fill(p);
                  x.restore();
                  _sbArt = c.toDataURL('image/png');
                } catch(e) {}
                return _sbArt;
              }
              function cleanMetaTitle(raw) {
                var s = String(raw || '').replace(/vidly(\\.pro)?/gi, 'SingularityTV');
                s = s.replace(/(\\s*[·•\\-|]\\s*SingularityTV)+$/gi, ' · SingularityTV');
                return s.trim() || 'SingularityTV';
              }
              function syncLockMetadata() {
                try {
                  document.querySelectorAll('link[rel*="icon"], link[rel="apple-touch-icon"]').forEach(function(el) { el.remove(); });
                  var art = mkArt();
                  if (art && document.head) {
                    var lk = document.getElementById('__sgFavicon');
                    if (!lk) {
                      lk = document.createElement('link');
                      lk.id = '__sgFavicon';
                      lk.rel = 'icon';
                      lk.type = 'image/png';
                      lk.href = art;
                      document.head.appendChild(lk);
                    }
                  }
                  if (document.title && /vidly/i.test(document.title)) {
                    document.title = cleanMetaTitle(document.title);
                  }
                  if (navigator.mediaSession && window.MediaMetadata) {
                    var cur = navigator.mediaSession.metadata;
                    var rawTitle = (cur && cur.title) ? cur.title : document.title;
                    var cleanTitle = cleanMetaTitle(rawTitle);
                    var curArt = (cur && cur.artwork && cur.artwork[0]) ? cur.artwork[0].src : '';
                    if (!cur || cur.title !== cleanTitle || cur.artist !== 'SingularityTV' || (art && curArt !== art)) {
                      var OrigRef = window.__SgOrigMM || window.MediaMetadata;
                      navigator.mediaSession.metadata = new OrigRef({
                        title: cleanTitle,
                        artist: 'SingularityTV',
                        album: 'SingularityTV',
                        artwork: art ? [{ src: art, sizes: '512x512', type: 'image/png' }] : []
                      });
                    }
                  }
                } catch(e) {}
              }
              if (navigator.mediaSession && window.MediaMetadata) {
                var OrigMM = window.MediaMetadata;
                window.__SgOrigMM = OrigMM;
                window.MediaMetadata = function(init) {
                  var o = init ? Object.assign({}, init) : {};
                  o.title = cleanMetaTitle(o.title || document.title);
                  o.artist = 'SingularityTV';
                  o.album = 'SingularityTV';
                  var art = mkArt();
                  if (art) o.artwork = [{ src: art, sizes: '512x512', type: 'image/png' }];
                  return new OrigMM(o);
                };
                window.MediaMetadata.prototype = OrigMM.prototype;
                var msDesc = Object.getOwnPropertyDescriptor(MediaSession.prototype, 'metadata');
                if (msDesc && msDesc.set) {
                  Object.defineProperty(navigator.mediaSession, 'metadata', {
                    configurable: true,
                    get: function() { return msDesc.get.call(this); },
                    set: function(v) {
                      if (v && typeof v === 'object') {
                        var art = mkArt();
                        var nt = cleanMetaTitle(v.title || document.title);
                        v = new OrigMM({
                          title: nt,
                          artist: 'SingularityTV',
                          album: 'SingularityTV',
                          artwork: art ? [{ src: art, sizes: '512x512', type: 'image/png' }] : (v.artwork || [])
                        });
                      }
                      return msDesc.set.call(this, v);
                    }
                  });
                }
              }
              syncLockMetadata();
              document.addEventListener('DOMContentLoaded', syncLockMetadata);
              document.addEventListener('play', syncLockMetadata, true);
              document.addEventListener('loadedmetadata', syncLockMetadata, true);
              setInterval(syncLockMetadata, 800);
            } catch(e) {}

            try { window.open = function(){ return null; }; } catch(e) {}
            function applyMeta() {
              var m = document.querySelector('meta[name="viewport"]');
              if (!m) { m = document.createElement('meta'); m.name = 'viewport'; (document.head || document.documentElement).appendChild(m); }
              m.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';
            }
            applyMeta();
            document.addEventListener('DOMContentLoaded', applyMeta);
            document.addEventListener('gesturestart', function(e){ e.preventDefault(); }, { passive: false });
            document.addEventListener('gesturechange', function(e){ e.preventDefault(); }, { passive: false });
            var st = document.createElement('style');
            st.textContent = '*,*::before,*::after{-webkit-user-select:none !important;user-select:none !important;-webkit-touch-callout:none !important;-webkit-tap-highlight-color:transparent !important;} html,body{background:#000 !important;touch-action:pan-x pan-y !important;} [aria-label*="fullscreen" i],[title*="fullscreen" i],[data-plyr="fullscreen"],.vjs-fullscreen-control,.jw-icon-fullscreen,button[class*="fullscreen" i],[class*="fullscreen-btn" i]{display:none !important;visibility:hidden !important;pointer-events:none !important;} #__sbWebBackBtn{display:inline-flex !important;align-items:center;justify-content:center;width:28px;height:28px;min-width:28px;margin-right:8px;background:transparent !important;border:none !important;color:rgba(255,255,255,0.92);cursor:pointer;flex-shrink:0;padding:0;outline:none;} #__sbFallbackBack{position:fixed;top:14px;left:14px;z-index:999998;display:none;align-items:center;justify-content:center;width:30px;height:30px;background:transparent;border:none;color:rgba(255,255,255,0.88);cursor:pointer;padding:0;} #__sbPinPause{position:fixed;left:18px;bottom:14px;z-index:999998;display:none;align-items:center;justify-content:center;width:32px;height:32px;background:transparent;border:none;color:rgba(255,255,255,0.85);cursor:pointer;padding:0;} [role=menu],[role=dialog],[class*=audio i][class*=menu i],[class*=lang i][class*=menu i],[class*=picker i]{background:rgba(12,14,21,0.92)!important;backdrop-filter:blur(16px)!important;-webkit-backdrop-filter:blur(16px)!important;border:1px solid rgba(255,255,255,0.12)!important;border-radius:16px!important;box-shadow:0 18px 44px rgba(0,0,0,0.75)!important;}';
            (document.head || document.documentElement).appendChild(st);
            function mkBack(id) {
              var b = document.createElement('button');
              b.id = id;
              b.type = 'button';
              b.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5"/><path d="M12 19l-7-7 7-7"/></svg>';
              b.onclick = function(ev) {
                ev.stopPropagation();
                try { window.webkit.messageHandlers.PlayerSniffer.postMessage({ kind: 'web_back', url: location.href }); } catch(e) {}
              };
              return b;
            }
            var startTs = Date.now();
            function syncUi() {
              try {
                if (window !== window.top) return;
                var fb = document.getElementById('__sbFallbackBack');
                if (!fb && document.body) { fb = mkBack('__sbFallbackBack'); document.body.appendChild(fb); }
                var t = document.querySelector('h1, h2, [class*="title" i]');
                if (!t || t.getBoundingClientRect().width <= 0) {
                  t = null;
                  var cands = document.querySelectorAll('div, span, p');
                  for (var ci = 0; ci < cands.length; ci++) {
                    var el = cands[ci];
                    if (el.id === '__sbWebBackBtn' || el.id === '__sbFallbackBack' || el.children.length > 0) continue;
                    var tx = (el.textContent || '').trim();
                    if (tx.length < 2 || tx.length > 70) continue;
                    var rr = el.getBoundingClientRect();
                    if (rr.top >= 4 && rr.top < 75 && rr.left >= 8 && rr.left < 240 && rr.height >= 12 && rr.height < 52) { t = el; break; }
                  }
                }
                var inlineBtn = document.getElementById('__sbWebBackBtn');
                if (t && t.parentElement) {
                  var p = t.parentElement;
                  if (!inlineBtn || !p.contains(inlineBtn)) {
                    if (inlineBtn) inlineBtn.remove();
                    inlineBtn = mkBack('__sbWebBackBtn');
                    if (getComputedStyle(p).display !== 'flex') { p.style.display = 'flex'; p.style.alignItems = 'center'; }
                    p.insertBefore(inlineBtn, p.firstChild);
                  }
                  if (fb) fb.style.display = 'none';
                } else {
                  if (fb) fb.style.display = 'inline-flex';
                }
                var btns = Array.from(document.querySelectorAll('button,[role="button"]'));
                var rew = null, fwd = null, pp = null;
                btns.forEach(function(b) {
                  if (b.id === '__sbWebBackBtn' || b.id === '__sbFallbackBack' || b.id === '__sbPinPause') return;
                  var lb = ((b.getAttribute('aria-label') || '') + ' ' + (b.getAttribute('title') || '') + ' ' + (b.className || '')).toLowerCase();
                  if (lb.indexOf('fullscreen') !== -1 || lb.indexOf('full screen') !== -1 || lb.indexOf('maximize') !== -1) {
                    b.style.setProperty('display', 'none', 'important');
                    return;
                  }
                  var r = b.getBoundingClientRect();
                  if (r.width > 10 && r.width <= 56 && r.height <= 56 && r.bottom >= window.innerHeight - 80 && r.right >= window.innerWidth - 56 && lb.indexOf('setting') === -1 && lb.indexOf('gear') === -1) {
                    b.style.setProperty('display', 'none', 'important');
                    return;
                  }
                  if (r.bottom >= window.innerHeight - 95 && r.left <= window.innerWidth * 0.45 && r.width > 10) {
                    var tx = (b.innerText || '').trim();
                    if (lb.indexOf('rewind') !== -1 || lb.indexOf('back') !== -1 || (tx === '10' && !rew)) { if (!rew) rew = b; }
                    else if (lb.indexOf('forward') !== -1 || lb.indexOf('skip') !== -1 || tx === '10') { fwd = b; }
                    else if (lb.indexOf('play') !== -1 || lb.indexOf('pause') !== -1 || (r.left < 120 && !pp)) { pp = b; }
                  }
                });
                if (pp && pp.parentElement) {
                  var ch = Array.from(pp.parentElement.children).filter(function(el){ return el.tagName === 'BUTTON'; });
                  if (ch.length >= 3 && !pp.__sbOrd) {
                    pp.__sbOrd = 1;
                    if (rew && fwd) {
                      rew.style.order = '1'; pp.style.order = '2'; fwd.style.order = '3';
                      ch.forEach(function(el){ if (el !== rew && el !== pp && el !== fwd) el.style.order = '4'; });
                    } else {
                      ch[1].style.order = '1'; ch[0].style.order = '2';
                      for (var k = 2; k < ch.length; k++) ch[k].style.order = String(k + 1);
                    }
                  }
                }
                document.querySelectorAll('img,svg,a,div').forEach(function(el) { if (el.id === '__sbBrandMark' || el.closest('#__sbBrandMark') || el.closest('button')) return; var r = el.getBoundingClientRect(); if (r.width >= 12 && r.width <= 56 && r.height >= 12 && r.height <= 56 && r.top >= 4 && r.top <= 72 && r.right >= window.innerWidth - 72 && (el.tagName === 'IMG' || el.tagName === 'SVG' || el.children.length <= 2)) { var tx = (el.innerText || '').trim(); if (!tx) el.style.setProperty('display', 'none', 'important'); } });
                var bm = document.getElementById('__sbBrandMark'); if (!bm && document.body) { bm = document.createElement('div'); bm.id = '__sbBrandMark'; bm.style.cssText = 'position:fixed;top:14px;right:18px;z-index:999990;pointer-events:none;opacity:0.48;'; bm.innerHTML = '<svg width="26" height="26" viewBox="0 0 64 64" fill="none"><path d="M46 12H24C18.5 12 14 16.5 14 22C14 27.5 18.5 31 24 31H38C41.5 31 44 33.5 44 37C44 40.5 41.5 43 38 43H16L13 52H39C46.5 52 52 46.5 52 39C52 32.5 47 28 40 28H25C22.2 28 20 25.8 20 23C20 20.2 22.2 18 25 18H43L46 12Z" fill="#FFFFFF"/></svg>'; document.body.appendChild(bm); }
                var hasTopHud = !!Array.from(document.querySelectorAll('button')).find(function(b){ var r = b.getBoundingClientRect(); return r.width > 40 && r.top < 80 && r.right > window.innerWidth - 180 && parseFloat(getComputedStyle(b).opacity) > 0.2; }); if (bm) bm.style.display = hasTopHud ? 'none' : 'block';
                document.querySelectorAll('div,section,ul').forEach(function(el) {
                  var cs = getComputedStyle(el);
                  if ((cs.position === 'absolute' || cs.position === 'fixed') && el.getBoundingClientRect().height > 140) {
                    var rr = el.getBoundingClientRect();
                    if (rr.top >= 20 && rr.bottom > window.innerHeight - 14 && rr.width < window.innerWidth * 0.92) {
                      el.style.setProperty('max-height', (window.innerHeight - rr.top - 14) + 'px', 'important');
                      el.style.setProperty('overflow-y', 'auto', 'important');
                    }
                  }
                });
              } catch(e) {}
            }
            try { new MutationObserver(function(){ if (!window.__sbRaf) { window.__sbRaf = requestAnimationFrame(function(){ window.__sbRaf = 0; syncUi(); }); } }).observe(document.documentElement, { childList: true, subtree: true }); } catch(e) {}
            syncUi();
            var lastSavedPrefs = '';
            function syncResume(v) {
              try {
                if (!v || !isFinite(v.duration) || v.duration <= 30) return;
                var srcKey = v.currentSrc || v.src || '1';
                var target = window.__sbLivePosSec || window.__sbStartSec || 0;
                if (v.__sbResumedSrc !== srcKey) {
                  v.__sbResumedSrc = srcKey;
                  if (target > 5 && v.duration > target + 5 && v.currentTime < 5) {
                    v.currentTime = target;
                  }
                }
              } catch(e) {}
            }
            document.addEventListener('loadedmetadata', function(e){ if (e.target && e.target.tagName === 'VIDEO') syncResume(e.target); }, true);
            function reportProg(force) {
              try {
                var v = document.querySelector('video');
                if (v && isFinite(v.duration) && v.duration > 30) {
                  syncResume(v);
                  if (v.currentTime > 5) window.__sbLivePosSec = Math.floor(v.currentTime);
                  window.webkit.messageHandlers.PlayerSniffer.postMessage({ kind: 'web_progress', pos: Math.floor(v.currentTime || 0), dur: Math.floor(v.duration || 0), playing: !v.paused });
                }
                if (force || Math.random() < 0.4) {
                  var obj = {};
                  for (var i = 0; i < localStorage.length; i++) {
                    var k = localStorage.key(i);
                    if (k && k.length < 80) {
                      var val = localStorage.getItem(k);
                      if (val && val.length < 2000) obj[k] = val;
                    }
                  }
                  var s = JSON.stringify(obj);
                  if (s !== lastSavedPrefs && s.length > 2) {
                    lastSavedPrefs = s;
                    window.webkit.messageHandlers.PlayerSniffer.postMessage({ kind: 'web_prefs', prefs: s });
                  }
                }
              } catch(e) {}
            }
            document.addEventListener('pause', function(e){ if (e.target && e.target.tagName === 'VIDEO') reportProg(true); }, true);
            setInterval(function(){ reportProg(false); }, 5000);
            var __sbLastCt = -1, __sbStallMs = 0, __sbLoopHits = 0, __sbUserSeekAt = 0, __sbLastNudgeAt = 0;
            ['pointerdown', 'touchstart', 'keydown'].forEach(function(ev) {
              document.addEventListener(ev, function() { __sbUserSeekAt = Date.now(); }, true);
            });
            setInterval(function() {
              try {
                var v = document.querySelector('video');
                if (!v || v.paused || v.ended || !isFinite(v.duration) || v.duration <= 30 || window.__sbUserPaused) return;
                var now = Date.now(), ct = v.currentTime || 0;
                if (now - __sbUserSeekAt < 3500) { __sbLastCt = ct; __sbStallMs = 0; __sbLoopHits = 0; return; }
                var isLoop = (__sbLastCt > 2 && ct < __sbLastCt - 0.35 && (__sbLastCt - ct) < 15);
                var isStall = (__sbLastCt >= 0 && Math.abs(ct - __sbLastCt) < 0.12);
                if (isLoop) { __sbLoopHits++; } else if (!isStall) { __sbLoopHits = 0; __sbStallMs = 0; }
                if (isStall) { __sbStallMs += 1500; }
                if ((__sbLoopHits >= 2 || __sbStallMs >= 4500) && now - __sbLastNudgeAt > 5000) {
                  __sbLastNudgeAt = now; __sbLoopHits = 0; __sbStallMs = 0;
                  var jumpTo = Math.min(v.duration - 1, Math.max(ct, __sbLastCt) + 2.2);
                  try {
                    var bf = v.buffered;
                    for (var bi = 0; bi < bf.length; bi++) {
                      if (bf.start(bi) > ct + 0.2 && bf.start(bi) < ct + 15) {
                        jumpTo = bf.start(bi) + 0.15;
                        break;
                      }
                    }
                  } catch(e) {}
                  try { v.currentTime = jumpTo; v.play().catch(function(){}); } catch(e) {}
                }
                __sbLastCt = ct;
              } catch(e) {}
            }, 1500);
            (function(){try{if(window.__sgSeekTimerInit)return;window.__sgSeekTimerInit=1;document.addEventListener('selectstart',function(e){e.preventDefault();},true);document.addEventListener('contextmenu',function(e){e.preventDefault();},true);var fmtT=function(sec){if(!isFinite(sec)||sec<0)return '--:--';sec=Math.floor(sec);var h=Math.floor(sec/3600),m=Math.floor((sec%3600)/60),s=sec%60;var ms=(m<10&&h>0?'0':'')+m,ss=(s<10?'0':'')+s;return h>0?(h+':'+ms+':'+ss):(ms+':'+ss);};var isTimeTxt=function(tx){if(!tx||tx.length>10)return false;tx=tx.trim();if(tx==='--:--')return true;if(tx.charAt(0)==='-')tx=tx.slice(1);var p=tx.split(':');if(p.length<2||p.length>3)return false;for(var i=0;i<p.length;i++){if(!p[i].length||isNaN(Number(p[i])))return false;}return true;};var effOp=function(el){var op=1,cur=el;while(cur&&cur.nodeType===1){var cs=getComputedStyle(cur);if(cs.display==='none'||cs.visibility==='hidden')return 0;op*=parseFloat(cs.opacity);if(op<=0.02)return 0;cur=cur.parentElement;}return op;};var findBar=function(){var cands=document.querySelectorAll('input[type=range],[role=slider],[class*=progress i],[class*=seek i],[class*=scrubber i],[class*=timeline i]');var best=null,bestW=0;for(var i=0;i<cands.length;i++){var el=cands[i];var r=el.getBoundingClientRect();if(r.width>window.innerWidth*0.28&&r.height>=2&&r.height<=42&&r.bottom>window.innerHeight-150&&r.top>window.innerHeight-180){if(r.width>bestW){bestW=r.width;best=el;}}}return best;};var findCountdown=function(barRect){var best=null,bestDist=9999;var els=document.querySelectorAll('span,div,p,time');for(var i=0;i<els.length;i++){var el=els[i];if(el.id==='__sgElapsedTimer'||el.children.length>0)continue;var tx=(el.textContent||'').trim();if(!isTimeTxt(tx))continue;var r=el.getBoundingClientRect();if(r.width<=0||r.height<=0)continue;if(r.left<window.innerWidth*0.55)continue;if(Math.abs((r.top+r.height/2)-(barRect.top+barRect.height/2))>42)continue;var d=Math.abs(r.left-barRect.right);if(d<bestDist){bestDist=d;best=el;}}return best;};var mountInlineTimer=function(){try{var bar=findBar();if(!bar)return document.getElementById('__sgElapsedTimer');var br=bar.getBoundingClientRect();var cd=findCountdown(br);var row=null,barChild=bar;if(cd){var cur=bar;for(var up=0;up<4&&cur&&cur.parentElement;up++){if(cur.parentElement.contains(cd)){row=cur.parentElement;barChild=cur;break;}cur=cur.parentElement;}}if(!row){row=bar.parentElement;barChild=bar;}if(!row)return null;var t=document.getElementById('__sgElapsedTimer');if(!t){t=document.createElement('span');t.id='__sgElapsedTimer';t.textContent='0:00';}if(t.parentElement!==row){var rcs=getComputedStyle(row);if(rcs.display!=='flex'&&rcs.display!=='inline-flex'){row.style.setProperty('display','flex','important');row.style.setProperty('align-items','center','important');}barChild.style.setProperty('flex','1 1 auto','important');barChild.style.setProperty('min-width','0','important');row.insertBefore(t,barChild);}if(cd){var cs=getComputedStyle(cd);t.style.fontFamily=cs.fontFamily;t.style.fontSize=cs.fontSize;t.style.fontWeight=cs.fontWeight;t.style.color=cs.color;t.style.letterSpacing=cs.letterSpacing;t.style.lineHeight=cs.lineHeight;t.style.textShadow=cs.textShadow;}else{t.style.fontFamily='-apple-system,BlinkMacSystemFont,sans-serif';t.style.fontSize='13px';t.style.fontWeight='600';t.style.color='rgba(255,255,255,0.92)';}t.style.flexShrink='0';t.style.marginRight='12px';t.style.fontVariantNumeric='tabular-nums';t.style.whiteSpace='nowrap';t.style.pointerEvents='none';t.style.userSelect='none';t.style.background='transparent';t.style.padding='0';return t;}catch(e){return null;}};var syncElapsed=function(){try{var t=mountInlineTimer();if(!t)return;var v=document.querySelector('video');if(v&&isFinite(v.duration)&&v.duration>0){t.textContent=fmtT(v.currentTime||0);}else{t.textContent='--:--';}}catch(e){}};var ensureBackOnError=function(){try{if(window!==window.top)return;var fb=document.getElementById('__sbFallbackBack');var inlineBtn=document.getElementById('__sbWebBackBtn');var bodyTxt=(document.body&&document.body.innerText||'').toLowerCase();var isErr=bodyTxt.indexOf('stream unavailable')!==-1||bodyTxt.indexOf('try again')!==-1||bodyTxt.indexOf('no sources')!==-1||bodyTxt.indexOf('failed to load')!==-1;var inlineVis=inlineBtn&&inlineBtn.isConnected&&inlineBtn.getBoundingClientRect().width>0&&effOp(inlineBtn)>0.2;if(fb){if(isErr||!inlineVis){fb.style.setProperty('display','inline-flex','important');fb.style.setProperty('opacity','1','important');fb.style.setProperty('z-index','2147483647','important');fb.style.setProperty('pointer-events','auto','important');}else{fb.style.setProperty('display','none','important');}}}catch(e){}};setInterval(function(){syncElapsed();ensureBackOnError();},600);document.addEventListener('timeupdate',syncElapsed,true);document.addEventListener('seeked',syncElapsed,true);document.addEventListener('loadedmetadata',syncElapsed,true);var ensureSeekHud=function(){var h=document.getElementById('__sgSeekHud');if(!h&&document.body){h=document.createElement('div');h.id='__sgSeekHud';h.style.cssText='position:fixed;top:50%;z-index:2147483646;pointer-events:none;transform:translateY(-50%) scale(0.92);opacity:0;transition:opacity 150ms ease,transform 150ms cubic-bezier(0.22,1,0.36,1);background:rgba(11,13,18,0.84);border:1px solid rgba(230,184,106,0.45);border-radius:18px;padding:12px 20px;text-align:center;box-shadow:0 14px 36px rgba(0,0,0,0.65);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);';document.body.appendChild(h);}return h;};var seekHudHideT=null;var showSeekHud=function(side,deltaSec,targetSec){var h=ensureSeekHud();if(!h)return;clearTimeout(seekHudHideT);var sign=deltaSec>=0?'+':'-';var absS=Math.abs(deltaSec);var chev=side>0?'&#187;&#187;':'&#171;&#171;';h.innerHTML='<div style=color:#F5D99F;font-size:19px;font-weight:800;letter-spacing:0.02em;font-family:-apple-system,sans-serif>'+(side<0?chev+' ':'')+sign+absS+'s'+(side>0?' '+chev:'')+'</div><div style=color:rgba(245,245,247,0.82);font-size:12px;font-weight:600;margin-top:3px;font-variant-numeric:tabular-nums;font-family:-apple-system,sans-serif>'+fmtT(targetSec)+'</div>';if(side>0){h.style.right='7%';h.style.left='auto';}else{h.style.left='7%';h.style.right='auto';}h.style.opacity='1';h.style.transform='translateY(-50%) scale(1.04)';setTimeout(function(){if(h)h.style.transform='translateY(-50%) scale(1)';},90);};var hideSeekHud=function(delay){clearTimeout(seekHudHideT);seekHudHideT=setTimeout(function(){var h=document.getElementById('__sgSeekHud');if(h){h.style.opacity='0';h.style.transform='translateY(-50%) scale(0.92)';}},delay||420);};var holdT=null,stepIv=null,holding=false,holdSide=0,holdBase=0,holdAccum=0,holdWasPlaying=false,downX=0,downY=0,suppressUntil=0;var lastTapAt=0,lastTapSide=0,tapAccum=0,tapResetT=null;var isSafeZone=function(ev){var tg=ev.target;if(tg&&tg.closest&&tg.closest('button,[role=button],[role=menu],[role=dialog],[role=slider],input,select,a'))return false;var y=ev.clientY||0,h=window.innerHeight||1;if(y<64||y>h-96)return false;return true;};var getSide=function(x){var w=window.innerWidth||1;if(x<w*0.30)return -1;if(x>w*0.70)return 1;return 0;};var keepPlaying=function(v,shouldPlay){if(!v||!shouldPlay)return;window.__sbUserPaused=0;try{if(v.paused)v.play().catch(function(){});}catch(e){}setTimeout(function(){try{if(shouldPlay&&v.paused&&!window.__sbUserPaused)v.play().catch(function(){});}catch(e){}},120);};var stopHold=function(commit){clearTimeout(holdT);clearInterval(stepIv);holdT=null;stepIv=null;window.__sgHoldingSeek=false;if(holding){holding=false;suppressUntil=Date.now()+420;var v=document.querySelector('video');if(commit&&holdAccum!==0&&v&&isFinite(v.duration)&&v.duration>5){var nt=Math.max(0,Math.min(v.duration-0.5,holdBase+holdAccum));window.__sbUserSeekAt=Date.now();v.currentTime=nt;syncElapsed();}keepPlaying(v,holdWasPlaying);hideSeekHud(460);}};document.addEventListener('pointerdown',function(ev){try{if(ev.button&&ev.button!==0)return;if(!isSafeZone(ev))return;var side=getSide(ev.clientX||0);if(!side)return;var v=document.querySelector('video');if(!v||!isFinite(v.duration)||v.duration<=5)return;downX=ev.clientX||0;downY=ev.clientY||0;holdSide=side;holdBase=v.currentTime||0;holdAccum=0;holdWasPlaying=!v.paused;clearTimeout(holdT);clearInterval(stepIv);holdT=setTimeout(function(){holding=true;window.__sgHoldingSeek=true;holdAccum=holdSide*10;var nt=Math.max(0,Math.min(v.duration-0.5,holdBase+holdAccum));window.__sbUserSeekAt=Date.now();showSeekHud(holdSide,holdAccum,nt);stepIv=setInterval(function(){holdAccum+=holdSide*10;var nt2=Math.max(0,Math.min(v.duration-0.5,holdBase+holdAccum));window.__sbUserSeekAt=Date.now();showSeekHud(holdSide,holdAccum,nt2);},420);},280);}catch(e){}},true);document.addEventListener('pointermove',function(ev){if(!holdT&&!holding)return;var dx=Math.abs((ev.clientX||0)-downX),dy=Math.abs((ev.clientY||0)-downY);if(!holding&&(dx>22||dy>22)){clearTimeout(holdT);holdT=null;}},true);document.addEventListener('pointerup',function(ev){try{if(holding){ev.stopImmediatePropagation();ev.preventDefault();stopHold(true);return;}clearTimeout(holdT);holdT=null;if(!isSafeZone(ev))return;var side=getSide(ev.clientX||0);if(!side)return;var now=Date.now();if(side===lastTapSide&&now-lastTapAt<320){ev.stopImmediatePropagation();ev.preventDefault();var v=document.querySelector('video');if(v&&isFinite(v.duration)&&v.duration>5){var wp=!v.paused;clearTimeout(tapResetT);tapAccum+=side*10;var nt=Math.max(0,Math.min(v.duration-0.5,(v.currentTime||0)+side*10));window.__sbUserSeekAt=now;v.currentTime=nt;keepPlaying(v,wp);showSeekHud(side,tapAccum,nt);hideSeekHud(620);suppressUntil=now+380;syncElapsed();tapResetT=setTimeout(function(){tapAccum=0;},750);}lastTapAt=now;}else{lastTapAt=now;lastTapSide=side;tapAccum=0;}}catch(e){}},true);['touchend','mouseup','click'].forEach(function(evName){document.addEventListener(evName,function(ev){if(holding||Date.now()<suppressUntil){ev.stopImmediatePropagation();ev.preventDefault();}},true);});document.addEventListener('pointercancel',function(){stopHold(false);},true);}catch(e){}})();
            (function(){try{if(window.__sgTopRestartInit)return;window.__sgTopRestartInit=1;var mkSvg=function(paths,sz,extra){var ns='http://www.w3.org/2000/svg';var s=document.createElementNS(ns,'svg');s.setAttribute('width',String(sz||22));s.setAttribute('height',String(sz||22));s.setAttribute('viewBox','0 0 24 24');s.setAttribute('fill','none');s.setAttribute('stroke','currentColor');s.setAttribute('stroke-width','2.1');s.setAttribute('stroke-linecap','round');s.setAttribute('stroke-linejoin','round');for(var i=0;i<paths.length;i++){var p=document.createElementNS(ns,'path');p.setAttribute('d',paths[i]);s.appendChild(p);}if(extra){extra(ns,s);}return s;};var effOp=function(el){var op=1,cur=el;while(cur&&cur.nodeType===1){var cs=getComputedStyle(cur);if(cs.display==='none'||cs.visibility==='hidden')return 0;op*=parseFloat(cs.opacity);if(op<=0.02)return 0;cur=cur.parentElement;}return op;};var triggerBack=function(ev){if(ev){ev.stopPropagation();ev.preventDefault();}try{if(window.webkit&&window.webkit.messageHandlers&&window.webkit.messageHandlers.PlayerSniffer)window.webkit.messageHandlers.PlayerSniffer.postMessage({kind:'web_back',url:location.href});else if(window.AndroidSniffer&&window.AndroidSniffer.onBack)window.AndroidSniffer.onBack();}catch(e){}};var findLiveTopBtn=function(kind){var btns=document.querySelectorAll('button,[role=button]');for(var i=0;i<btns.length;i++){var b=btns[i];if(b.dataset.sgProxy==='1'||b.id==='__sgRestartBtn'||b.id==='__sgTopBackBtn'||b.id==='__sbWebBackBtn'||b.id==='__sbFallbackBack')continue;var tx=(b.innerText||b.textContent||'').trim().toLowerCase();if(kind==='qual'&&(tx.indexOf('quality')!==-1||tx.indexOf('server')!==-1))return b;if(kind==='audio'&&(tx.indexOf('audio')!==-1||tx.indexOf('subtitle')!==-1)&&tx.indexOf('look')===-1)return b;}return null;};var clickLiveTop=function(kind){var b=findLiveTopBtn(kind);if(!b)return;try{b.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,cancelable:true}));b.dispatchEvent(new MouseEvent('mouseup',{bubbles:true,cancelable:true}));b.click();}catch(e){try{b.click();}catch(e2){}}};var ensureTopBack=function(){if(window!==window.top||!document.body)return;var bk=document.getElementById('__sgTopBackBtn');if(!bk){bk=document.createElement('button');bk.id='__sgTopBackBtn';bk.type='button';bk.style.cssText='position:fixed;z-index:2147483645;display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;background:transparent;border:none;color:#FFFFFF;cursor:pointer;padding:0;margin:0;opacity:0;pointer-events:none;transition:opacity 120ms ease;';bk.appendChild(mkSvg(['M19 12H5','M12 19l-7-7 7-7'],22));bk.addEventListener('pointerdown',function(e){e.stopPropagation();},true);bk.addEventListener('click',triggerBack,true);document.body.appendChild(bk);}var oldIb=document.getElementById('__sbWebBackBtn');if(oldIb)oldIb.style.setProperty('display','none','important');var titleEl=null;var tCands=document.querySelectorAll('h1,h2,div,span,p');for(var j=0;j<tCands.length;j++){var el=tCands[j];if(el.id==='__sgTopBackBtn'||el.id==='__sbWebBackBtn'||el.id==='__sbFallbackBack'||el.id==='__sgRestartBtn'||el.closest('button'))continue;if(el.children.length>0)continue;var ttx=(el.textContent||'').trim();if(ttx.length<2||ttx.length>75)continue;var tr=el.getBoundingClientRect();if(tr.width>10&&tr.top>=2&&tr.top<95&&tr.left>=4&&tr.left<340&&tr.height>=14&&tr.height<60){titleEl=el;break;}}if(titleEl){var tr2=titleEl.getBoundingClientRect();var op=effOp(titleEl);var bx=Math.max(8,Math.round(tr2.left-42));var by=Math.max(4,Math.round(tr2.top+(tr2.height/2)-18));bk.style.left=bx+'px';bk.style.top=by+'px';bk.style.opacity=String(op);bk.style.pointerEvents=op>0.15?'auto':'none';}else{bk.style.left='16px';bk.style.top='14px';var bodyTxt=(document.body.innerText||'').toLowerCase();var isErr=bodyTxt.indexOf('stream unavailable')!==-1||bodyTxt.indexOf('try again')!==-1||bodyTxt.indexOf('no sources')!==-1;bk.style.opacity=isErr?'1':'0';bk.style.pointerEvents=isErr?'auto':'none';}};var ensureUnmuted=function(){try{var v=document.querySelector('video');if(v&&v.muted)v.muted=false;}catch(e){}};var mkBottomIconBtn=function(id,kind){var b=document.createElement('button');b.id=id;b.type='button';b.dataset.sgProxy='1';b.style.cssText='position:absolute!important;top:50%!important;transform:translateY(-50%)!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;width:36px!important;height:36px!important;background:transparent!important;border:none!important;color:#FFFFFF!important;cursor:pointer!important;padding:0!important;margin:0!important;z-index:20!important;';if(kind==='qual'){b.appendChild(mkSvg([],22,function(ns,s){var rc=document.createElementNS(ns,'rect');rc.setAttribute('x','2');rc.setAttribute('y','4');rc.setAttribute('width','20');rc.setAttribute('height','16');rc.setAttribute('rx','3');s.appendChild(rc);var pg=document.createElementNS(ns,'polygon');pg.setAttribute('points','10,8.5 16,12 10,15.5');pg.setAttribute('fill','currentColor');pg.setAttribute('stroke','none');s.appendChild(pg);}));}else{b.appendChild(mkSvg([],22,function(ns,s){var rc=document.createElementNS(ns,'rect');rc.setAttribute('x','2');rc.setAttribute('y','4');rc.setAttribute('width','20');rc.setAttribute('height','16');rc.setAttribute('rx','3');s.appendChild(rc);var p1=document.createElementNS(ns,'path');p1.setAttribute('d','M10.5 9.8a2.3 2.3 0 1 0 0 4.4');s.appendChild(p1);var p2=document.createElementNS(ns,'path');p2.setAttribute('d','M16.5 9.8a2.3 2.3 0 1 0 0 4.4');s.appendChild(p2);}));}b.addEventListener('pointerdown',function(e){e.stopPropagation();},true);b.addEventListener('click',function(e){e.stopPropagation();e.preventDefault();clickLiveTop(kind);},true);return b;};var isVolBtn=function(b){var lb=((b.getAttribute('aria-label')||'')+' '+(b.getAttribute('title')||'')+' '+(b.className||'')).toLowerCase();if(lb.indexOf('volume')!==-1||lb.indexOf('mute')!==-1||lb.indexOf('sound')!==-1)return true;var svg=b.querySelector('svg');if(!svg)return false;var html=(svg.innerHTML||'').toLowerCase();if(html.indexOf('11 5')!==-1||html.indexOf('11,5')!==-1||html.indexOf('m11 5')!==-1||html.indexOf('volume')!==-1)return true;return false;};var findCommonAncestor=function(a,b){var cur=a;for(var i=0;i<6&&cur;i++){if(cur.contains(b))return cur;cur=cur.parentElement;}return null;};var layoutBottomControls=function(){var tEl=document.getElementById('__sgElapsedTimer');var bar=null;var cands=document.querySelectorAll('input[type=range],[role=slider],[class*=progress i],[class*=seek i],[class*=scrubber i],[class*=timeline i]');var bestW=0;for(var i=0;i<cands.length;i++){var r=cands[i].getBoundingClientRect();if(r.width>window.innerWidth*0.22&&r.height>=2&&r.height<=44&&r.bottom>window.innerHeight-160&&r.top>window.innerHeight-190){if(r.width>bestW){bestW=r.width;bar=cands[i];}}}var btns=Array.from(document.querySelectorAll('button,[role=button]'));var botBtns=[];for(var j=0;j<btns.length;j++){var b=btns[j];if(b.dataset.sgProxy==='1'||b.dataset.sgMovedTop==='1'||b.id==='__sgRestartBtn'||b.id==='__sgTopBackBtn'||b.id==='__sbWebBackBtn'||b.id==='__sbFallbackBack')continue;var br=b.getBoundingClientRect();if(br.width>8&&br.height>8&&br.bottom>=window.innerHeight-115&&br.top>=window.innerHeight-140){botBtns.push({el:b,r:br});}}if(!botBtns.length)return;botBtns.sort(function(a,b){return a.r.left-b.r.left;});var rew=null,pp=null,fwd=null,gear=null,vol=null,ep=null;for(var k=0;k<botBtns.length;k++){var item=botBtns[k],el=item.el;var tx=(el.innerText||el.textContent||'').trim().toLowerCase();var lb=((el.getAttribute('aria-label')||'')+' '+(el.getAttribute('title')||'')+' '+(el.className||'')).toLowerCase();if(tx.indexOf('episode')!==-1){ep=el;}else if(isVolBtn(el)){vol=el;}else if(lb.indexOf('setting')!==-1||lb.indexOf('gear')!==-1){gear=el;}else if(lb.indexOf('rewind')!==-1||lb.indexOf('back')!==-1||(tx==='10'&&!rew)){if(!rew)rew=el;}else if(lb.indexOf('forward')!==-1||lb.indexOf('skip')!==-1||tx==='10'){fwd=el;}else if(lb.indexOf('play')!==-1||lb.indexOf('pause')!==-1){pp=el;}}if(!gear){for(var g=botBtns.length-1;g>=0;g--){var ge=botBtns[g].el;if(ge!==rew&&ge!==fwd&&ge!==pp&&ge!==vol&&ge!==ep){gear=ge;break;}}}if(!pp&&rew&&fwd){for(var m=0;m<botBtns.length;m++){var me=botBtns[m].el;if(me!==rew&&me!==fwd&&me!==gear&&me!==vol&&me!==ep&&botBtns[m].r.left>rew.getBoundingClientRect().left&&botBtns[m].r.left<fwd.getBoundingClientRect().left){pp=me;break;}}}if(!vol&&rew){for(var vIdx=0;vIdx<botBtns.length;vIdx++){var ve=botBtns[vIdx].el;if(ve!==rew&&ve!==pp&&ve!==fwd&&ve!==gear&&ve!==ep&&botBtns[vIdx].r.right<rew.getBoundingClientRect().left+8){vol=ve;break;}}}if(vol){vol.style.setProperty('display','none','important');if(vol.parentElement&&vol.parentElement.querySelector('input[type=range]')&&vol.parentElement.children.length<=2){vol.parentElement.style.setProperty('display','none','important');}}if(!pp||!gear)return;var ctrlRow=findCommonAncestor(pp,gear);if(!ctrlRow)return;var progRow=tEl&&tEl.parentElement?tEl.parentElement:(bar?bar.parentElement:null);if(progRow&&ctrlRow!==progRow){var outer=findCommonAncestor(progRow,ctrlRow);if(outer){var ocs=getComputedStyle(outer);if(ocs.flexDirection!=='column'){outer.style.setProperty('display','flex','important');outer.style.setProperty('flex-direction','column','important');outer.style.setProperty('align-items','stretch','important');outer.style.setProperty('gap','10px','important');outer.style.setProperty('width','100%','important');}}progRow.style.setProperty('width','100%','important');progRow.style.setProperty('max-width','100%','important');progRow.style.setProperty('flex','0 0 auto','important');progRow.style.setProperty('order','1','important');ctrlRow.style.setProperty('width','100%','important');ctrlRow.style.setProperty('max-width','100%','important');ctrlRow.style.setProperty('order','2','important');ctrlRow.style.setProperty('display','flex','important');ctrlRow.style.setProperty('align-items','center','important');ctrlRow.style.setProperty('justify-content','center','important');ctrlRow.style.setProperty('position','relative','important');ctrlRow.style.setProperty('min-height','44px','important');ctrlRow.style.setProperty('gap','18px','important');if(rew){rew.style.setProperty('order','1','important');rew.style.setProperty('position','static','important');}if(pp){pp.style.setProperty('order','2','important');pp.style.setProperty('position','static','important');}if(fwd){fwd.style.setProperty('order','3','important');fwd.style.setProperty('position','static','important');}if(ep){ep.style.setProperty('position','absolute','important');ep.style.setProperty('left','0','important');ep.style.setProperty('top','50%','important');ep.style.setProperty('transform','translateY(-50%)','important');}gear.style.setProperty('position','absolute','important');gear.style.setProperty('right','0','important');gear.style.setProperty('top','50%','important');gear.style.setProperty('transform','translateY(-50%)','important');gear.style.setProperty('margin','0','important');var bSub=document.getElementById('__sgBottomSubBtn');if(!bSub){bSub=mkBottomIconBtn('__sgBottomSubBtn','audio');}bSub.style.setProperty('right','44px','important');if(bSub.parentElement!==ctrlRow)ctrlRow.appendChild(bSub);var bQual=document.getElementById('__sgBottomQualBtn');if(!bQual){bQual=mkBottomIconBtn('__sgBottomQualBtn','qual');}bQual.style.setProperty('right','88px','important');if(bQual.parentElement!==ctrlRow)ctrlRow.appendChild(bQual);}else if(progRow&&ctrlRow===progRow){ctrlRow.style.setProperty('display','flex','important');ctrlRow.style.setProperty('flex-wrap','wrap','important');ctrlRow.style.setProperty('align-items','center','important');ctrlRow.style.setProperty('width','100%','important');ctrlRow.style.setProperty('position','relative','important');ctrlRow.style.setProperty('row-gap','10px','important');var chs=Array.from(ctrlRow.children);for(var ci=0;ci<chs.length;ci++){var ch=chs[ci];if(ch.id==='__sgRowBreak'||ch.id==='__sgLeftPad'||ch.id==='__sgRightPad'||ch.dataset.sgProxy==='1')continue;if(ch===rew||ch===pp||ch===fwd||ch===gear||ch===ep||ch===vol||ch.contains(pp)||ch.contains(gear))continue;ch.style.setProperty('order','1','important');}var brk=document.getElementById('__sgRowBreak');if(!brk){brk=document.createElement('div');brk.id='__sgRowBreak';brk.style.cssText='flex-basis:100%!important;height:0!important;order:2!important;pointer-events:none!important;';ctrlRow.appendChild(brk);}var lp=document.getElementById('__sgLeftPad');if(!lp){lp=document.createElement('div');lp.id='__sgLeftPad';lp.style.cssText='flex:1 1 0!important;order:3!important;pointer-events:none!important;';ctrlRow.appendChild(lp);}var rp=document.getElementById('__sgRightPad');if(!rp){rp=document.createElement('div');rp.id='__sgRightPad';rp.style.cssText='flex:1 1 0!important;order:7!important;pointer-events:none!important;';ctrlRow.appendChild(rp);}if(rew){rew.style.setProperty('order','4','important');rew.style.setProperty('margin','0 10px','important');}if(pp){pp.style.setProperty('order','5','important');pp.style.setProperty('margin','0 10px','important');}if(fwd){fwd.style.setProperty('order','6','important');fwd.style.setProperty('margin','0 10px','important');}gear.style.setProperty('position','absolute','important');gear.style.setProperty('right','0','important');gear.style.setProperty('bottom','2px','important');gear.style.setProperty('top','auto','important');gear.style.setProperty('transform','none','important');var bSub2=document.getElementById('__sgBottomSubBtn');if(!bSub2){bSub2=mkBottomIconBtn('__sgBottomSubBtn','audio');}bSub2.style.setProperty('right','44px','important');bSub2.style.setProperty('bottom','2px','important');bSub2.style.setProperty('top','auto','important');bSub2.style.setProperty('transform','none','important');if(bSub2.parentElement!==ctrlRow)ctrlRow.appendChild(bSub2);var bQual2=document.getElementById('__sgBottomQualBtn');if(!bQual2){bQual2=mkBottomIconBtn('__sgBottomQualBtn','qual');}bQual2.style.setProperty('right','88px','important');bQual2.style.setProperty('bottom','2px','important');bQual2.style.setProperty('top','auto','important');bQual2.style.setProperty('transform','none','important');if(bQual2.parentElement!==ctrlRow)ctrlRow.appendChild(bQual2);}};var syncAll=function(){try{if(window!==window.top)return;ensureUnmuted();ensureTopBack();var btns=Array.from(document.querySelectorAll('button,[role=button]'));var nextEpBtn=null,topContainer=null;for(var i=0;i<btns.length;i++){var b=btns[i];if(b.id==='__sgRestartBtn'||b.id==='__sgTopBackBtn'||b.id==='__sbWebBackBtn'||b.id==='__sbFallbackBack'||b.dataset.sgProxy==='1')continue;var tx=(b.innerText||b.textContent||'').trim().toLowerCase();var r=b.getBoundingClientRect();var inTop=(r.top>=0&&r.top<110)||b.dataset.sgMovedTop==='1';if(inTop&&(tx.indexOf('quality')!==-1||tx.indexOf('server')!==-1)){b.dataset.sgMovedTop='1';if(!topContainer&&b.parentElement)topContainer=b.parentElement;b.style.setProperty('position','fixed','important');b.style.setProperty('left','-9999px','important');b.style.setProperty('top','-9999px','important');b.style.setProperty('opacity','0','important');b.style.setProperty('width','1px','important');b.style.setProperty('height','1px','important');b.style.setProperty('overflow','hidden','important');}else if(inTop&&(tx.indexOf('audio')!==-1||tx.indexOf('subtitle')!==-1)&&tx.indexOf('look')===-1){b.dataset.sgMovedTop='1';if(!topContainer&&b.parentElement)topContainer=b.parentElement;b.style.setProperty('position','fixed','important');b.style.setProperty('left','-9999px','important');b.style.setProperty('top','-9999px','important');b.style.setProperty('opacity','0','important');b.style.setProperty('width','1px','important');b.style.setProperty('height','1px','important');b.style.setProperty('overflow','hidden','important');}else if(r.top>=0&&r.top<110&&tx.indexOf('next episode')!==-1){nextEpBtn=b;if(!topContainer&&b.parentElement)topContainer=b.parentElement;}}if(topContainer){var rb=document.getElementById('__sgRestartBtn');if(!rb){rb=document.createElement('button');rb.id='__sgRestartBtn';rb.type='button';rb.style.cssText='display:inline-flex;align-items:center;gap:7px;background:transparent;border:none;color:rgba(255,255,255,0.92);font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:14px;font-weight:600;cursor:pointer;padding:6px 10px;border-radius:10px;white-space:nowrap;';rb.appendChild(mkSvg(['M3 12a9 9 0 1 0 3-6.7L3 8','M3 3v5h5'],18));var rs=document.createElement('span');rs.textContent='Restart';rb.appendChild(rs);rb.onclick=function(ev){ev.stopPropagation();ev.preventDefault();var v=document.querySelector('video');if(v&&isFinite(v.duration)){window.__sbUserSeekAt=Date.now();v.currentTime=0;v.play().catch(function(){});}};}if(rb.parentElement!==topContainer){if(nextEpBtn&&nextEpBtn.parentElement===topContainer)topContainer.insertBefore(rb,nextEpBtn);else topContainer.appendChild(rb);}}layoutBottomControls();}catch(e){}};setInterval(syncAll,300);try{new MutationObserver(function(){syncAll();}).observe(document.documentElement,{childList:true,subtree:true});}catch(e){}}catch(e){}})();
          } catch(e) {}
        })();
        """
        ucc.addUserScript(WKUserScript(source: uiCleanJs, injectionTime: .atDocumentStart, forMainFrameOnly: false))
        config.userContentController = ucc

        config.mediaTypesRequiringUserActionForPlayback = []
        let wv = WKWebView(frame: CGRect(x: -5000, y: 0, width: 360, height: 250), configuration: config)
        wv.isOpaque = false
        wv.backgroundColor = .black
        wv.scrollView.backgroundColor = .black
        wv.alpha = 0.0
        wv.isUserInteractionEnabled = false
                wv.navigationDelegate = self
        wv.uiDelegate = self
        wv.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"
        let adRulesJson = "[{\"trigger\": {\"url-filter\": \".*\", \"if-domain\": [\"*google-analytics.com\", \"*googletagmanager.com\", \"*googletagservices.com\", \"*doubleclick.net\", \"*adservice.google.com\", \"*pagead2.googlesyndication.com\", \"*cdn.adx1.com\", \"*intelligenceadx.com\", \"*adsco.re\", \"*mc.yandex.com\", \"*mc.yandex.ru\", \"*bvtpk.com\", \"*my.rtmark.net\", \"*b7510.com\", \"*gt.unbrownunflat.com\", \"*im.malocacomals.com\", \"*nf.sixmossin.com\", \"*realizationnewestfangs.com\", \"*acscdn.com\", \"*lt.taloseempest.com\", \"*pl26708123.profitableratecpm.com\", \"*preferencenail.com\", \"*protrafficinspector.com\", \"*s10.histats.com\", \"*weirdopt.com\", \"*cloudflareinsights.com\", \"*kettledroopingcontinuation.com\", \"*wayfarerorthodox.com\", \"*woxaglasuy.net\", \"*adeptspiritual.com\", \"*calculating-laugh.com\", \"*amavhxdlofklxjg.xyz\", \"*usrpubtrk.com\", \"*adexchangeclear.com\", \"*rzjzjnavztycv.online\", \"*hameltnoummos.com\", \"*ancillammmm.com\", \"*hubeamily.com\", \"*llvpn.com\", \"*gillyspencie.com\", \"*soakysecrets.com\", \"*mdstats.info\", \"*ads-twitter.com\", \"*connatix.com\", \"*imasdk.googleapis.com\", \"*jwpltx.com\", \"*openfpcdn.io\", \"*phruk.org\", \"*welcomingexpulsion.com\", \"*pgo99.com\", \"*todditehexarch.com\", \"*uniolaicecaps.com\", \"*alloha.tv\", \"*pc.alloviewroll.com\", \"*yadro.ru\", \"*getaim.org\", \"*myangular.life\", \"*rstprgapipt.com\", \"*veselchaga.link\", \"*webvisor.org\", \"*datariaarpent.com\", \"*gamesrevenue.com\", \"*mgid.com\", \"*pushaffiliate.net\", \"*imp-mintads.site\", \"*xadsmart.com\", \"*tsyndicate.com\", \"*rapidadexchange.com\", \"*pxltag.com\", \"*runative-syndicate.com\", \"*cdn4ads.com\", \"*popads.net\", \"*popcash.net\", \"*exoclick.com\", \"*juicyads.com\", \"*propellerads.com\", \"*monetag.com\", \"*adsterra.com\", \"*highperformanceformat.com\", \"*effectivegatecpm.com\", \"*onclickalgo.com\", \"*realsrv.com\", \"*hilltopads.net\", \"*admaven.com\", \"*ad-maven.com\", \"*clickadu.com\", \"*galaksion.com\", \"*onclkds.com\", \"*betteradsystem.com\", \"*a-ads.com\", \"*bidvertiser.com\", \"*richpush.co\", \"*2mdn.net\", \"*outbrain.com\", \"*taboola.com\", \"*exosrv.com\", \"*magsrv.com\", \"*ero-advertising.com\", \"*chaturbate.com\", \"*stripchat.com\", \"*bongacams.com\", \"*livejasmin.com\", \"*cam4.com\", \"*trafficjunky.com\", \"*trafficjunky.net\", \"*juicyads.net\", \"*tsyndicate.net\", \"*adskeeper.com\", \"*mgid.com\", \"*profitablecpmrate.com\", \"*highrevenuegate.com\"]}, \"action\": {\"type\": \"block\"}}]"
        if !directWebPlayerMode {
        WKContentRuleListStore.default().compileContentRuleList(forIdentifier: "SingularityAdBlock", encodedContentRuleList: adRulesJson) { [weak self] list, _ in
            if let list = list {
                DispatchQueue.main.async {
                    self?.adRuleList = list
                    wv.configuration.userContentController.add(list)
                }
            }
        }
        }
        view.insertSubview(wv, at: 0)
        resolverWebView = wv
    }

    func webView(
        _ webView: WKWebView,
        createWebViewWith configuration: WKWebViewConfiguration,
        for navigationAction: WKNavigationAction,
        windowFeatures: WKWindowFeatures
    ) -> WKWebView? {
        return nil
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        guard directWebPlayerMode, webView === resolverWebView else { return }
        let nsErr = error as NSError
        if nsErr.code == NSURLErrorCancelled { return }
        if webErrorRetryCount < 3 {
            webErrorRetryCount += 1
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { [weak self] in
                self?.resolverWebView?.reload()
            }
        }
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        guard directWebPlayerMode, webView === resolverWebView else { return }
        let nsErr = error as NSError
        if nsErr.code == NSURLErrorCancelled { return }
        if webErrorRetryCount < 3 {
            webErrorRetryCount += 1
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.5) { [weak self] in
                self?.resolverWebView?.reload()
            }
        }
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        guard webView === resolverWebView else { return }
        webErrorRetryCount = 0
        if directWebPlayerMode {
            let safeData = (try? JSONSerialization.data(withJSONObject: [initialWebPrefsJson])) ?? Data()
            let quoted = String(data: safeData, encoding: .utf8).map { String($0.dropFirst().dropLast()) } ?? "\"{}\""
            webView.evaluateJavaScript("try{window.__sbStartSec=\(Int(startTimeSec));if(!window.__sbLivePosSec&&\(Int(startTimeSec))>5)window.__sbLivePosSec=\(Int(startTimeSec));var wp=JSON.parse(\(quoted));if(wp&&typeof wp==='object'){Object.keys(wp).forEach(function(k){try{localStorage.setItem(k,wp[k]);}catch(e){}});}}catch(e){}", completionHandler: nil)
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) { [weak self] in
            guard let self = self, self.streamUrl.isEmpty else { return }
            self.triggerResolverPlayFromUserTap()
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.8) { [weak self] in
            guard let self = self, self.streamUrl.isEmpty else { return }
            self.triggerResolverPlayFromUserTap()
        }
    }

    func webView(
        _ webView: WKWebView,
        decidePolicyFor navigationResponse: WKNavigationResponse,
        decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void
    ) {
        if !directWebPlayerMode, webView === resolverWebView,
           let mime = navigationResponse.response.mimeType?.lowercased(),
           let u = navigationResponse.response.url?.absoluteString {
            let ul = u.lowercased()
            let isHlsMime = mime.contains("mpegurl") || ul.contains(".m3u8")
            let isVidUrl = isHlsMime || mime.hasPrefix("video/") || ul.contains(".mp4")
            if isVidUrl && !failedStreamUrls.contains(u) && u != streamUrl {
                DispatchQueue.main.async { [weak self] in
                    guard let self = self else { return }
                    self.failoverTimer?.invalidate()
                    self.isSwitchingServer = false
                    let srcId = self.pendingNextSource.isEmpty ? self.currentSource : self.pendingNextSource
                    self.currentSource = srcId
                    self.pendingNextSource = ""
                    self.headerRetryStage = 0
                    self.streamIsHls = isHlsMime
                    self.streamUrl = u
                    self.updateServerBadge(srcId)
                    self.startPlayback(urlString: u, referer: self.buildReferer(for: srcId), seekSec: self.startTimeSec)
                }
                decisionHandler(.cancel)
                return
            }
        }
        decisionHandler(.allow)
    }

    func webView(
        _ webView: WKWebView,
        decidePolicyFor navigationAction: WKNavigationAction,
        decisionHandler: @escaping (WKNavigationActionPolicy) -> Void
    ) {
        if let u = navigationAction.request.url?.absoluteString.lowercased() {
            if webView === resolverWebView {
                let isCh = u.contains("challenges.cloudflare.com") || u.contains("turnstile/v0/api") || u.contains("recaptcha/api") || u.contains("hcaptcha.com/1/api") || u.contains("arkoselabs.com") || u.contains("geetest.com")
                if isCh && isSwitchingServer && !isCaptchaVisible {
                    DispatchQueue.main.async { [weak self] in
                        guard let self = self else { return }
                        let targetSrc = self.pendingNextSource.isEmpty ? self.currentSource : self.pendingNextSource
                        self.failoverTimer?.invalidate()
                        self.showCaptchaCard(for: targetSrc)
                    }
                }
            }
            let blockedHosts = ["google-analytics.com", "googletagmanager.com", "googletagservices.com", "doubleclick.net", "adservice.google.com", "pagead2.googlesyndication.com", "cdn.adx1.com", "intelligenceadx.com", "adsco.re", "mc.yandex.com", "mc.yandex.ru", "bvtpk.com", "my.rtmark.net", "b7510.com", "gt.unbrownunflat.com", "im.malocacomals.com", "nf.sixmossin.com", "realizationnewestfangs.com", "acscdn.com", "lt.taloseempest.com", "pl26708123.profitableratecpm.com", "preferencenail.com", "protrafficinspector.com", "s10.histats.com", "weirdopt.com", "tsyndicate.com", "mgid.com", "cdn4ads.com", "pxltag.com", "runative-syndicate.com", "rapidadexchange.com", "popads.net", "popcash.net", "exoclick.com", "juicyads.com", "propellerads.com", "monetag.com", "adsterra.com", "highperformanceformat.com", "effectivegatecpm.com", "onclickalgo.com", "realsrv.com", "hilltopads.net", "admaven.com", "ad-maven.com", "clickadu.com", "galaksion.com", "onclkds.com", "betteradsystem.com", "a-ads.com", "bidvertiser.com", "richpush.co", "2mdn.net", "outbrain.com", "taboola.com", "exosrv.com", "magsrv.com", "ero-advertising.com", "chaturbate.com", "stripchat.com", "bongacams.com", "livejasmin.com", "cam4.com", "trafficjunky.com", "trafficjunky.net", "juicyads.net", "tsyndicate.net", "adskeeper.com", "mgid.com", "profitablecpmrate.com", "highrevenuegate.com"]
            let pathOnly = u.components(separatedBy: "?").first ?? u
            let isMediaStream = pathOnly.hasSuffix(".m3u8") || pathOnly.hasSuffix(".ts") || pathOnly.hasSuffix(".m4s") || pathOnly.hasSuffix(".mp4") || pathOnly.hasSuffix(".webm") || pathOnly.hasSuffix(".aac") || pathOnly.hasSuffix(".key") || pathOnly.hasSuffix(".vtt") || u.contains("/hls/") || u.contains("mime=video") || u.contains("videoplayback")
            let isAdPath = u.contains("/vast") || u.contains("/vmap") || u.contains("vmap.xml") || u.contains("preroll") || u.contains("popunder")
            if !isMediaStream && (isAdPath || blockedHosts.contains(where: { u.contains($0) })) {
                let prev = UserDefaults.standard.integer(forKey: "sb_blocked_total")
                UserDefaults.standard.set(prev + 1, forKey: "sb_blocked_total")
                onBlockedAd?(u)
                decisionHandler(.cancel)
                return
            }
        }
        decisionHandler(.allow)
    }

    private func parsePayloadAndPlay() {
        guard let data = payloadJson.data(using: .utf8),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            dismiss(animated: true)
            return
        }
        streamUrl = obj["url"] as? String ?? ""
        streamTitle = obj["title"] as? String ?? "SingularityTV"
        progressKey = obj["progressKey"] as? String ?? ""
        startTimeSec = (obj["startTimeSec"] as? NSNumber)?.doubleValue ?? 0
        imdbId = obj["imdbId"] as? String ?? ""
        tmdbId = obj["tmdbId"] as? String ?? ""
        resolveTmdbIdIfNeeded()
        mediaType = obj["mediaType"] as? String ?? "movie"
        applyLiveModeUI()
        seasonNum = (obj["season"] as? NSNumber)?.intValue ?? 1
        episodeNum = (obj["episode"] as? NSNumber)?.intValue ?? 1
        seriesTitle = obj["seriesTitle"] as? String ?? streamTitle.components(separatedBy: " · S").first ?? streamTitle
        episodeRuntimeMin = (obj["episodeRuntimeMin"] as? NSNumber)?.intValue ?? 0
        totalEpisodesInSeason = (obj["totalEpisodes"] as? NSNumber)?.intValue ?? 0
        seasonEpisodesList = []
        if let sArr = obj["seasons"] as? [[String: Any]] {
            var tmp: [(season: Int, count: Int)] = []
            for so in sArr {
                let sn = (so["season_number"] as? NSNumber)?.intValue ?? 0
                let ec = (so["episode_count"] as? NSNumber)?.intValue ?? 0
                if sn > 0 && ec > 0 { tmp.append((season: sn, count: ec)) }
            }
            tmp.sort { $0.season < $1.season }
            seasonEpisodesList = tmp
        }
        preferredLang = (obj["preferredSubLang"] as? String ?? "ar").lowercased()
        if let mt = obj["embedMovieTemplate"] as? String, !mt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            embedMovieTemplate = mt.trimmingCharacters(in: .whitespacesAndNewlines)
        }
        if let tt = obj["embedTvTemplate"] as? String, !tt.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            embedTvTemplate = tt.trimmingCharacters(in: .whitespacesAndNewlines)
        }
        let udSub = UserDefaults.standard
        if let c = obj["subTextColor"] as? String, !c.isEmpty {
            subTextColorHex = c
            udSub.set(c, forKey: "sub_pref_color")
        } else if let savedC = udSub.string(forKey: "sub_pref_color"), !savedC.isEmpty {
            subTextColorHex = savedC
        } else {
            subTextColorHex = "#FFFFFF"
        }
        if let b = obj["subBgStyle"] as? String, !b.isEmpty {
            subBgStyleMode = b.lowercased()
            udSub.set(subBgStyleMode, forKey: "sub_pref_bg")
        } else if let savedB = udSub.string(forKey: "sub_pref_bg"), !savedB.isEmpty {
            subBgStyleMode = savedB.lowercased()
        } else {
            subBgStyleMode = "dark"
        }
        if let sz = (obj["subFontSizeSp"] as? NSNumber)?.doubleValue, sz > 0 {
            subFontSizePt = CGFloat(min(38.0, max(13.0, sz)))
            udSub.set(Double(subFontSizePt), forKey: "sub_pref_size")
        } else {
            let savedSz = udSub.double(forKey: "sub_pref_size")
            if savedSz >= 12 && savedSz <= 38 { subFontSizePt = CGFloat(savedSz) }
        }
        applySubtitleStyle()
        currentSource = "hnembed"
        activeReferer = obj["referer"] as? String ?? buildReferer(for: currentSource)

        titleLabel.text = streamTitle
        updateTopActionButtons()
        updateServerBadge(currentSource)

        if let subs = obj["subtitles"] as? [[String: Any]] {
            for s in subs {
                let u = (s["url"] as? String) ?? (s["path"] as? String) ?? ""
                if u.isEmpty { continue }
                let lang = (s["lang"] as? String ?? "en").lowercased()
                let label = (s["label"] as? String) ?? "Stream · \(lang.uppercased())"
                availableSubs.append(IosSubTrack(lang: lang, url: u, score: 100, syncMatch: true))
            }
        }
        subButton.setTitle("Subtitles (\(availableSubs.count))", for: .normal)

        if let data = payloadJson.data(using: .utf8), let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any], let wp = obj["webPlayerPrefs"] as? String, !wp.isEmpty { initialWebPrefsJson = wp }
        directWebPlayerMode = !isLiveStream && streamUrl.isEmpty
        setupResolverWebView()
        if streamUrl.isEmpty {
            startResolvingInitialSource()
        } else {
            startPlayback(urlString: streamUrl, referer: activeReferer, seekSec: startTimeSec)
        }
        fetchSubtitlesInBackground()
        fetchSkipSegmentsInBackground()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { [weak self] in
            self?.startBackgroundServerProbing()
        }
        showControllerTemporarily()
    }

    private func showCaptchaCard(for sourceId: String) {
        if directWebPlayerMode { return }
        isCaptchaVisible = false
        captchaCardView.isHidden = true
        view.viewWithTag(99412)?.isHidden = true
        if let wv = resolverWebView {
            wv.frame = CGRect(x: -5000, y: 0, width: 360, height: 250)
            wv.alpha = 0.0
            wv.isUserInteractionEnabled = false
        }

    }

    @objc private func toggleCaptchaExpand() {
        captchaExpanded.toggle()
        if captchaSizeConstraints.count == 2 {
            captchaSizeConstraints[0].constant = captchaExpanded ? view.bounds.width - 16 : 360
            captchaSizeConstraints[1].constant = captchaExpanded ? view.bounds.height - 16 : 290
        }
        UIView.animate(withDuration: 0.2) {
            self.view.layoutIfNeeded()
        }
        resolverWebView?.evaluateJavaScript("try{window.dispatchEvent(new Event('resize'));}catch(e){}", completionHandler: nil)
    }

    @objc private func skipCaptchaServer() {
        failoverTimer?.invalidate()
        failedStreamUrls.removeAll()
        streamUrl = ""
        currentSource = "hnembed"
        pendingNextSource = "hnembed"
        isSwitchingServer = true
        let embed = buildEmbedUrl(for: "hnembed")
        if !embed.isEmpty, let u = URL(string: embed) {
            resolverWebView?.stopLoading()
            loadHnEmbedUrl(u)
        }
        showToast("Reloading HnEmbed...")
    }

    private func hideCaptchaCard() {
        if !isCaptchaVisible { return }
        isCaptchaVisible = false
        if let list = adRuleList { resolverWebView?.configuration.userContentController.add(list) }
        captchaCardView.isHidden = true
        if let wv = resolverWebView {
            wv.removeFromSuperview()
            wv.translatesAutoresizingMaskIntoConstraints = true
            wv.frame = CGRect(x: -5000, y: 0, width: 360, height: 250)
            wv.alpha = 0.0
            wv.isUserInteractionEnabled = false
            view.insertSubview(wv, at: 0)
        }
    }

    private func serverStatusKey(_ sourceId: String) -> String {
        let pk = progressKey.isEmpty ? (imdbId.isEmpty ? streamTitle : imdbId) : progressKey
        return "srv_status_\(pk)_\(sourceId)"
    }

    private func recordServerStatus(_ sourceId: String, status: String) {
        guard !sourceId.isEmpty else { return }
        UserDefaults.standard.set(status, forKey: serverStatusKey(sourceId))
        UserDefaults.standard.set(serverCatalogVersion, forKey: serverStatusKey(sourceId) + "_ver")
    }

    private func getServerStatus(_ sourceId: String) -> String {
        let st = UserDefaults.standard.string(forKey: serverStatusKey(sourceId)) ?? "unknown"
        let ver = UserDefaults.standard.string(forKey: serverStatusKey(sourceId) + "_ver") ?? ""
        if st == "working" { return "working" }
        if st == "failed" {
            if ver != serverCatalogVersion {
                return recentlyUpdatedSources.contains(sourceId) ? "updated" : "unknown"
            }
            return "failed"
        }
        if recentlyUpdatedSources.contains(sourceId) { return "updated" }
        return "unknown"
    }

    private func loadHnEmbedUrl(_ u: URL) {
        var req = URLRequest(url: u)
        if let sc = u.scheme, let h = u.host {
            req.setValue("\(sc)://\(h)/", forHTTPHeaderField: "Referer")
        }
        resolverWebView?.stopLoading()
        resolverWebView?.load(req)
    }

    private func loadSeriesPrefsIfAny() {
        let key = imdbId.isEmpty ? tmdbId : imdbId
        guard !key.isEmpty else { return }
        let ud = UserDefaults.standard
        if let savedLang = ud.string(forKey: "sp_lang_\(key)"), !savedLang.isEmpty {
            preferredLang = savedLang
        }
        if ud.object(forKey: "sp_delay_\(key)") != nil {
            subDelaySec = ud.double(forKey: "sp_delay_\(key)")
            syncButton.setTitle(String(format: "Sync %.1fs", subDelaySec), for: .normal)
        }
        if ud.object(forKey: "sp_speed_\(key)") != nil {
            let sp = ud.float(forKey: "sp_speed_\(key)")
            if sp >= 0.5 && sp <= 3.0 {
                currentSpeed = sp
                speedButton.setTitle(formatSpeedText(Double(sp)), for: .normal)
            }
        }
        applySubtitleStyle()
    }

    private func saveSeriesPrefs() {
        let key = imdbId.isEmpty ? tmdbId : imdbId
        guard !key.isEmpty else { return }
        let ud = UserDefaults.standard
        ud.set(preferredLang, forKey: "sp_lang_\(key)")
        ud.set(subDelaySec, forKey: "sp_delay_\(key)")
        ud.set(currentSpeed, forKey: "sp_speed_\(key)")
    }

    private func ensureNumericTmdbIdThen(_ completion: @escaping () -> Void) {
        let trimmed = tmdbId.trimmingCharacters(in: .whitespacesAndNewlines)
        if !trimmed.isEmpty && trimmed.allSatisfy({ $0.isNumber }) {
            completion()
            return
        }
        guard imdbId.hasPrefix("tt") else {
            completion()
            return
        }
        let cacheKey = "tmdb_map_\(mediaType.lowercased())_\(imdbId)"
        if let cached = UserDefaults.standard.string(forKey: cacheKey), !cached.isEmpty, cached.allSatisfy({ $0.isNumber }) {
            tmdbId = cached
            completion()
            return
        }
        let prop = mediaType.lowercased() == "tv" ? "P4983" : "P4947"
        let sparql = "SELECT ?tid WHERE { ?item wdt:P345 \"\(imdbId)\" . ?item wdt:\(prop) ?tid . } LIMIT 1"
        guard let enc = sparql.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let url = URL(string: "https://query.wikidata.org/sparql?format=json&query=\(enc)") else {
            completion()
            return
        }
        var req = URLRequest(url: url)
        req.timeoutInterval = 6.0
        req.setValue("application/sparql-results+json", forHTTPHeaderField: "Accept")
        req.setValue("SingularityTV/3.0", forHTTPHeaderField: "User-Agent")
        URLSession.shared.dataTask(with: req) { [weak self] data, _, _ in
            DispatchQueue.main.async {
                guard let self = self else { return }
                if let data = data,
                   let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                   let results = root["results"] as? [String: Any],
                   let bindings = results["bindings"] as? [[String: Any]],
                   let first = bindings.first,
                   let tidObj = first["tid"] as? [String: Any],
                   let val = tidObj["value"] as? String,
                   !val.isEmpty, val.allSatisfy({ $0.isNumber }) {
                    self.tmdbId = val
                    UserDefaults.standard.set(val, forKey: cacheKey)
                }
                completion()
            }
        }.resume()
    }

    private func advanceToNextAutoSource() {
        guard let idx = serverOrder.firstIndex(of: currentSource) else { return }
        let nextIdx = (idx + 1) % serverOrder.count
        let nextSrc = serverOrder[nextIdx]
        currentSource = nextSrc
        pendingNextSource = nextSrc
        isSwitchingServer = true
        updateServerBadge(nextSrc)
        let embed = buildEmbedUrl(for: nextSrc)
        if !embed.isEmpty, let u = URL(string: embed) {
            resolverWebView?.stopLoading()
            loadHnEmbedUrl(u)
        }
    }

    private func revealFullscreenEmbedFallback() {
        guard !vlcReadyHandled, let wv = resolverWebView else { return }
        wv.alpha = 0.0
        wv.isUserInteractionEnabled = false
        view.sendSubviewToBack(wv)
        wv.evaluateJavaScript("try{window.__sbStopped=false;window.postMessage({__sbResume:true},'*');}catch(e){}", completionHandler: nil)
    }

    private func enterDirectWebPlayerMode() {
        directWebPlayerMode = true
        if let list = adRuleList {
            resolverWebView?.configuration.userContentController.remove(list)
        }
        videoContainer.isHidden = true
        overlayView.isHidden = true
        overlayView.removeFromSuperview()
        ambientTrackView.isHidden = true
        ambientTrackView.removeFromSuperview()
        captchaCardView.isHidden = true
        subtitleLabel.isHidden = true
        if let wv = resolverWebView {
            wv.scrollView.minimumZoomScale = 1.0
            wv.scrollView.maximumZoomScale = 1.0
            wv.scrollView.bouncesZoom = false
            wv.scrollView.isScrollEnabled = false
            wv.scrollView.bounces = false
            wv.scrollView.pinchGestureRecognizer?.isEnabled = false
        }
        if let wv = resolverWebView {
            wv.translatesAutoresizingMaskIntoConstraints = true
            wv.frame = view.bounds
            wv.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            wv.alpha = 1.0
            wv.isHidden = false
            wv.isUserInteractionEnabled = true
            view.bringSubviewToFront(wv)
        }
        directWebBackButton?.isHidden = true
    }

    private func startResolvingInitialSource() {
        forceSoftwareDecode = false
        loadSeriesPrefsIfAny()
        let firstSrc = "vidyst"
        currentSource = firstSrc
        isSwitchingServer = true
        failoverAttempts = 0
        pendingNextSource = firstSrc
        updateServerBadge(firstSrc)
        enterDirectWebPlayerMode()
        ensureNumericTmdbIdThen { [weak self] in
            guard let self = self else { return }
            let embed = self.buildEmbedUrl(for: firstSrc)
            self.failoverTimer?.invalidate()
            if !embed.isEmpty, let u = URL(string: embed) {
                self.loadHnEmbedUrl(u)
            }
        }
    }

    private func serverDisplayName(_ id: String) -> String {
        switch id.lowercased() {
        case "singularity": return "Singularity"
        case "vidsrcmeru": return "VidSrc.ru"
        case "vidsrcto": return "VidSrc.to"
        case "vidlink": return "VidLink"
        case "videasy": return "VidEasy"
        case "vidsrccc": return "VidSrc.cc"
        case "vidsrcxyz": return "VidSrc.xyz"
        case "vidsrcme": return "VidSrc.me"
        case "vidsrcnet": return "VidSrc Pro"
        case "vidsrcin": return "VidSrc.in"
        case "vidsrcpm": return "VidSrc.pm"
        case "vidsrc": return "VidSrc"
        case "vidsrcicu": return "VidSrc.icu"
        case "vidfast": return "VidFast"
        case "vidnest": return "VidNest"
        case "vidlove": return "VidLove"
        case "autoembed": return "AutoEmbed"
        case "embedsu": return "Embed.su"
        case "smashy": return "Smashy"
        case "hnembed": return "HnEmbed"
        case "superembed": return "SuperEmbed"
        case "rivestream": return "RiveStream"
        case "moviesapi": return "MoviesAPI"
        case "nontongo": return "NontonGo"
        default: return id.capitalized
        }
    }

    private func updateServerBadge(_ sourceId: String) {
        let name = serverDisplayName(sourceId)
        serverBadgeButton.setTitle("\(name)", for: .normal)
    }

    private func buildReferer(for sourceId: String) -> String {
        switch sourceId {
        case "singularity": return "https://proxy.garageband.rocks/"
        case "vidsrcmeru": return "https://vidsrcme.ru/"
        case "vidsrcto": return "https://vidsrc.to/"
        case "vidlink": return "https://vidlink.pro/"
        case "videasy": return "https://player.videasy.net/"
        case "vidsrccc": return "https://vidsrc.cc/"
        case "vidsrcxyz": return "https://vidsrc.xyz/"
        case "vidsrcme": return "https://vidsrc.me/"
        case "hnembed": return "https://hnembed.cc/"
        case "vidyst":
            if let u = URL(string: buildEmbedUrl(for: "vidyst")), let sc = u.scheme, let h = u.host { return "\(sc)://\(h)/" }
            return "https://vidly.pro/"
        case "vidsrccc": return "https://vidsrc.cc/"
        default: return "https://vidly.pro/"
        }
    }

    private func resolveTmdbIdIfNeeded() {
        if !tmdbId.isEmpty || !imdbId.hasPrefix("tt") { return }
        let isTv = mediaType.lowercased() == "tv"
        let prop = isTv ? "P4983" : "P4947"
        let sparql = "SELECT ?tid WHERE { ?item wdt:P345 \"\(imdbId)\" . ?item wdt:\(prop) ?tid . } LIMIT 1"
        guard let q = sparql.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let u = URL(string: "https://query.wikidata.org/sparql?format=json&query=\(q)") else { return }
        var req = URLRequest(url: u)
        req.setValue("application/sparql-results+json", forHTTPHeaderField: "Accept")
        URLSession.shared.dataTask(with: req) { [weak self] data, _, _ in
            guard let self = self, let data = data,
                  let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let results = root["results"] as? [String: Any],
                  let bindings = results["bindings"] as? [[String: Any]],
                  let first = bindings.first,
                  let tidObj = first["tid"] as? [String: Any],
                  let val = tidObj["value"] as? String, !val.isEmpty else { return }
            DispatchQueue.main.async {
                self.tmdbId = val
            }
        }.resume()
    }

    private func buildEmbedUrl(for sourceId: String) -> String {
        let im = imdbId
        let tm = tmdbId.isEmpty ? imdbId : tmdbId
        if im.isEmpty && tm.isEmpty { return "" }
        let isTv = mediaType.lowercased() == "tv"
        let s = max(1, seasonNum)
        let e = max(1, episodeNum)
        if sourceId == "vidyst" {
            let isAnime = mediaType.lowercased() == "anime"
            let tpl = isAnime ? "https://vidly.pro/anime/mal/{TMDBID}/{EPISODE}/sub" : (isTv ? embedTvTemplate : embedMovieTemplate)
            var out = tpl
            let replacements: [(String, String)] = [
                ("{ID}", tm), ("{TMDBID}", tm), ("{TMDB_ID}", tm), ("{ANILISTID}", tm),
                ("{IMDBID}", im.isEmpty ? tm : im), ("{IMDB_ID}", im.isEmpty ? tm : im),
                ("{SEASON}", "\(s)"), ("{SEASONNUMBER}", "\(s)"), ("{SEASON_NUMBER}", "\(s)"), ("{SEASONNO}", "\(s)"), ("{SEASON_NO}", "\(s)"),
                ("{EPISODE}", "\(e)"), ("{EPISODENO}", "\(e)"), ("{EPISODE_NO}", "\(e)"), ("{EPISODENUMBER}", "\(e)"), ("{EPISODE_NUMBER}", "\(e)")
            ]
            for (k, v) in replacements {
                out = out.replacingOccurrences(of: k, with: v, options: String.CompareOptions.caseInsensitive)
            }

            if out.lowercased().contains("vidly.pro") {
                let sep = out.contains("?") ? "&" : "?"
                out += "\(sep)color=e50914&autoplay=1&nextEpisode=1"
                if Int(startTimeSec) > 5 { out += "&t=\(Int(startTimeSec))" }
            }
            return out
        }
        switch sourceId {
        case "singularity": return isTv ? "https://proxy.garageband.rocks/embed/tv/\(im)/\(s)/\(e)" : "https://proxy.garageband.rocks/embed/movie/\(im)"
        case "vidsrcmeru": return isTv ? "https://vidsrcme.ru/embed/tv?imdb=\(im)&season=\(s)&episode=\(e)&autoplay=1" : "https://vidsrcme.ru/embed/movie?imdb=\(im)&autoplay=1"
        case "vidsrcto": return isTv ? "https://vidsrc.to/embed/tv/\(im)/\(s)/\(e)" : "https://vidsrc.to/embed/movie/\(im)"
        case "vidlink": return isTv ? "https://vidlink.pro/tv/\(tm)/\(s)/\(e)?primaryColor=E50914&autoplay=true" : "https://vidlink.pro/movie/\(tm)?primaryColor=E50914&autoplay=true"
        case "videasy": return isTv ? "https://player.videasy.net/tv/\(tm)/\(s)/\(e)" : "https://player.videasy.net/movie/\(tm)"
        case "vidsrccc": return isTv ? "https://vidsrc.cc/v2/embed/tv/\(im.isEmpty ? tm : im)/\(s)/\(e)?poster=true&autoPlay=true" : "https://vidsrc.cc/v2/embed/movie/\(im.isEmpty ? tm : im)?poster=true&autoPlay=true"
        case "vidsrcxyz": return isTv ? "https://vidsrc.xyz/embed/tv?tmdb=\(tm)&season=\(s)&episode=\(e)" : "https://vidsrc.xyz/embed/movie?tmdb=\(tm)"
        case "vidsrcnet": return isTv ? "https://vidsrc.net/embed/tv/\(im)/\(s)-\(e)?autoplay=1" : "https://vidsrc.net/embed/movie/\(im)?autoplay=1"
        case "vidsrcin": return isTv ? "https://vidsrc.in/embed/tv/\(im)/\(s)-\(e)" : "https://vidsrc.in/embed/movie/\(im)"
        case "vidsrc": return isTv ? "https://vsembed.su/embed/tv/\(im)/\(s)/\(e)?autoplay=1" : "https://vsembed.su/embed/movie/\(im)?autoplay=1"
        case "vidsrcicu": return isTv ? "https://vidsrc.icu/embed/tv/\(im)/\(s)/\(e)" : "https://vidsrc.icu/embed/movie/\(im)"
        case "vidfast": return isTv ? "https://vidfast.pro/tv/\(tm)/\(s)/\(e)?autoPlay=true" : "https://vidfast.pro/movie/\(tm)?autoPlay=true"
        case "vidnest": return isTv ? "https://vidnest.fun/tv/\(tm)/\(s)/\(e)" : "https://vidnest.fun/movie/\(tm)"
        case "autoembed": return isTv ? "https://player.autoembed.cc/embed/tv/\(tm)/\(s)/\(e)?server=1" : "https://player.autoembed.cc/embed/movie/\(tm)?server=1"
        case "embedsu": return isTv ? "https://embed.su/embed/tv/\(tm)/\(s)/\(e)" : "https://embed.su/embed/movie/\(tm)"
        case "smashy": return isTv ? "https://player.smashy.stream/tv/\(im)?s=\(s)&e=\(e)" : "https://player.smashy.stream/movie/\(im)"
        case "hnembed": return isTv ? "https://hnembed.cc/embed/tv/\(im.isEmpty ? tm : im)/\(s)/\(e)" : "https://hnembed.cc/embed/movie/\(im.isEmpty ? tm : im)"
        case "superembed": return isTv ? "https://multiembed.mov/directstream.php?video_id=\(im)&s=\(s)&e=\(e)" : "https://multiembed.mov/directstream.php?video_id=\(im)"
        case "rivestream": return isTv ? "https://rivestream.org/embed?type=tv&id=\(tm)&season=\(s)&episode=\(e)" : "https://rivestream.org/embed?type=movie&id=\(tm)"
        case "moviesapi": return isTv ? "https://moviesapi.club/tv/\(tm)-\(s)-\(e)" : "https://moviesapi.club/movie/\(tm)"
        case "vidsrcpro": return isTv ? "https://vidsrc.pro/embed/tv/\(tm)/\(s)/\(e)" : "https://vidsrc.pro/embed/movie/\(tm)"
        case "vidsrcvip": return isTv ? "https://vidsrc.vip/embed/tv/\(tm)/\(s)/\(e)" : "https://vidsrc.vip/embed/movie/\(tm)"
        case "vidsrcrip": return isTv ? "https://vidsrc.rip/embed/tv/\(tm)/\(s)/\(e)" : "https://vidsrc.rip/embed/movie/\(tm)"
        case "111movies": return isTv ? "https://111movies.com/tv/\(tm)/\(s)/\(e)" : "https://111movies.com/movie/\(tm)"
        case "vidjoy": return isTv ? "https://vidjoy.pro/embed/tv/\(tm)/\(s)/\(e)" : "https://vidjoy.pro/embed/movie/\(tm)"
        case "2embed": return isTv ? "https://www.2embed.cc/embedtv/\(im)&s=\(s)&e=\(e)" : "https://www.2embed.cc/embed/\(im)"
        case "embed2": return isTv ? "https://www.2embed.stream/embed/tv/\(im)/\(s)/\(e)" : "https://www.2embed.stream/embed/movie/\(im)"
        case "nontongo": return isTv ? "https://www.NontonGo.win/embed/tv?id=\(im)&s=\(s)&e=\(e)" : "https://www.NontonGo.win/embed/movie?id=\(im)"
        default: return isTv ? "https://vidsrcme.ru/embed/tv?imdb=\(im)&season=\(s)&episode=\(e)" : "https://vidsrcme.ru/embed/movie?imdb=\(im)"
        }
    }

    private func episodeStepForCurrentStream() -> Int {
        let durSec = currentDurationSeconds()
        if episodeRuntimeMin >= 7 && episodeRuntimeMin <= 15 && durSec >= max(1080.0, Double(episodeRuntimeMin) * 60.0 * 1.65) {
            return 2
        }
        return 1
    }

    private func computeNextEpisode() -> (season: Int, episode: Int)? {
        if mediaType.lowercased() != "tv" { return nil }
        let step = episodeStepForCurrentStream()
        let nextEpNum = episodeNum + step
        if !seasonEpisodesList.isEmpty {
            let curCount = seasonEpisodesList.first(where: { $0.season == seasonNum })?.count ?? totalEpisodesInSeason
            if curCount > 0 && nextEpNum <= curCount {
                return (seasonNum, nextEpNum)
            }
            if let nextS = seasonEpisodesList.first(where: { $0.season > seasonNum && $0.count > 0 }) {
                return (nextS.season, 1)
            }
            if curCount > 0 { return nil }
        }
        if totalEpisodesInSeason > 0 {
            return nextEpNum <= totalEpisodesInSeason ? (seasonNum, nextEpNum) : nil
        }
        return (seasonNum, nextEpNum)
    }

    private func updateTopActionButtons() {
        let hasNext = computeNextEpisode() != nil
        topNextButton.isHidden = !hasNext
        topNextGroup.isHidden = !hasNext
        topRestartButton.isHidden = isLiveStream
        topRestartGroupRef?.isHidden = isLiveStream
    }

    @objc private func handleTopNext() {
        if computeNextEpisode() != nil {
            playNextEpisodeInPlayer()
        }
    }

    private func currentTimeSeconds() -> Double {
        guard let vp = vlcPlayer else { return 0 }
        let ms = Double(vp.time.intValue)
        return ms > 0 ? ms / 1000.0 : 0
    }

    private func currentDurationSeconds() -> Double {
        guard let vp = vlcPlayer, let len = vp.media?.length else { return 0 }
        let ms = Double(len.intValue)
        return ms > 0 ? ms / 1000.0 : 0
    }

    private func isPlayerPlaying() -> Bool {
        return vlcPlayer?.isPlaying ?? false
    }

    private func seekPlayer(to sec: Double) {
        guard let vp = vlcPlayer else { return }
        let dur = currentDurationSeconds()
        let clamped = dur > 0 ? min(max(0, sec), dur) : max(0, sec)
        pendingSeekTargetSec = clamped
        let nowTs = Date().timeIntervalSince1970
        lastSeekCommitTime = nowTs
        seekUiLockUntil = nowTs + 3.5
        if vlcDidEnd || vp.state == .ended || vp.state == .stopped {
            vlcDidEnd = false
            vlcSeekPendingSec = clamped
            vp.stop()
            vp.play()
        } else if dur > 0 {
            let frac = Float(min(0.999, max(0.0, clamped / dur)))
            vp.position = frac
        } else {
            vp.time = VLCTime(int: Int32(clamped * 1000.0))
        }
        if dur > 0 {
            let frac = min(1.0, max(0.0, clamped / dur))
            currentPosLabel.text = formatTime(clamped)
            durationLabel.text = "-\(formatTime(max(0, dur - clamped)))"
            seekSlider.value = Float(frac)
            ambientFillWidthConstraint?.constant = view.bounds.width * CGFloat(frac)
        }
    }

    @objc private func handleTopRestart() {
        guard let vp = vlcPlayer else { return }
        startTimeSec = 0
        if vlcDidEnd || vp.state == .ended || vp.state == .stopped {
            vlcDidEnd = false
            vlcSeekPendingSec = 0
            vp.stop()
            vp.play()
        } else {
            seekPlayer(to: 0)
            if !vp.isPlaying { vp.play() }
            if abs(vp.rate - currentSpeed) > 0.01 { vp.rate = currentSpeed }
        }
        updateTimeAndSubtitles()
        showControllerTemporarily()
    }

    private func startPlayback(urlString: String, referer: String, seekSec: Double) {

        failoverTimer?.invalidate()
        resolverWebView?.evaluateJavaScript("try{document.querySelectorAll('video').forEach(function(v){v.pause();});}catch(e){}", completionHandler: nil)
        guard let url = URL(string: urlString) else { return }
        vlcPollTimer?.invalidate()
        vlcPollTimer = nil
        itemStatusObserver?.invalidate()
        vlcPlayer?.stop()
        vlcPlayer?.delegate = nil
        vlcPlayer = nil
        var headers: [String: String] = [
            "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"
        ]
        headers["Accept"] = "*/*"
        let lowUrl = urlString.lowercased()
        let stripRefForHost = lowUrl.contains("googlevideo") || lowUrl.contains("googleusercontent")
        if !stripRefForHost && headerRetryStage == 0 && !referer.isEmpty {
            headers["Referer"] = referer
            if let ru = URL(string: referer), let scheme = ru.scheme, let host = ru.host {
                headers["Origin"] = "\(scheme)://\(host)"
            }
        } else if !stripRefForHost && headerRetryStage == 1 && !referer.isEmpty {
            headers["Referer"] = referer
        }
        WKWebsiteDataStore.default().httpCookieStore.getAllCookies { [weak self] cookies in
            guard let self = self else { return }
            for ck in cookies { HTTPCookieStorage.shared.setCookie(ck) }
            let host = url.host?.lowercased() ?? ""
            let matching = cookies.filter { host.hasSuffix($0.domain.trimmingCharacters(in: CharacterSet(charactersIn: ".")).lowercased()) }
            if !matching.isEmpty {
                headers["Cookie"] = matching.map { "\($0.name)=\($0.value)" }.joined(separator: "; ")
            }
            DispatchQueue.main.async {
                self.beginAvAssetPlayback(url: url, headers: headers, seekSec: seekSec)
            }
        }
    }

    private func beginAvAssetPlayback(url: URL, headers: [String: String], seekSec: Double) {
        activeStreamHeaders = headers
        vlcPlaybackToken += 1
        let myToken = vlcPlaybackToken
        vlcReadyHandled = false
        hasRealPlaybackProgress = false
        vlcSeekPendingSec = seekSec
        try? AVAudioSession.sharedInstance().setCategory(.playback, mode: .moviePlayback, options: [])
        try? AVAudioSession.sharedInstance().setActive(true)
        var playUrl = url
        if url.scheme == "singularity-inline" {
            let tmpPath = (NSTemporaryDirectory() as NSString).appendingPathComponent("singularity_inline_\(myToken).m3u8")
            try? inlineM3u8Text.write(toFile: tmpPath, atomically: true, encoding: .utf8)
            playUrl = URL(fileURLWithPath: tmpPath)
        }
        let media = VLCMedia(url: playUrl)
        var opts: [String: Any] = [
            "network-caching": 900,
            "live-caching": 900,
            "file-caching": 300,
            "audio-desync": 0,

            "avcodec-hw": forceSoftwareDecode ? "none" : "any",
            "avcodec-fast": true,
            "drop-late-frames": true,
            "skip-frames": true,
            "audio-time-stretch": true,
            "http-reconnect": true
        ]
        if let ua = headers["User-Agent"], !ua.isEmpty {
            opts["http-user-agent"] = ua
        }
        if let ref = headers["Referer"], !ref.isEmpty {
            opts["http-referrer"] = ref
        }
        media.addOptions(opts)

        activePlayUrl = url
        let prevPlayer = vlcPlayer
        vlcPlayer = nil
        prevPlayer?.delegate = nil
        prevPlayer?.drawable = nil
        if let pp = prevPlayer {
            DispatchQueue.global(qos: .userInitiated).async {
                pp.stop()
            }
        }
        vlcVideoConfirmed = false
        videoContainer.alpha = 0
        videoContainer.subviews.forEach { $0.removeFromSuperview() }
        videoContainer.frame = view.bounds
        videoContainer.isHidden = false
        videoContainer.isHidden = false
        videoContainer.alpha = 1
        videoContainer.frame = view.bounds
        videoContainer.setNeedsLayout()
        videoContainer.layoutIfNeeded()
        videoContainer.layoutIfNeeded()
        if let wv = resolverWebView {
            view.sendSubviewToBack(wv)
        }
        let vp = VLCMediaPlayer()
        vp.delegate = self
        vp.drawable = videoContainer
        vp.media = media
        vp.audio?.isMuted = false
        vp.audio?.volume = 100
        vlcPlayer = vp
        vp.play()

        DispatchQueue.main.asyncAfter(deadline: .now() + 5.5) { [weak self] in
            guard let self = self, self.vlcPlaybackToken == myToken, !self.vlcReadyHandled else { return }
            if self.headerRetryStage < 2 {
                self.headerRetryStage = 2
                self.activeReferer = ""
                self.startPlayback(urlString: self.streamUrl, referer: "", seekSec: seekSec)
            } else {
                self.headerRetryStage = 0
                self.failedStreamUrls.insert(url.absoluteString)
                self.streamUrl = ""
                self.isSwitchingServer = true
                self.showToast("Trying next source...")
                self.advanceToNextAutoSource()
            }
        }

        vlcPollTimer?.invalidate()
        vlcPollTimer = Timer.scheduledTimer(withTimeInterval: 0.25, repeats: true) { [weak self] _ in
            guard let self = self, self.vlcPlaybackToken == myToken else { return }
            if !self.vlcVideoConfirmed, let curVp = self.vlcPlayer {
                let vs = curVp.videoSize
                if vs.width > 16 && vs.height > 16 {
                    self.vlcVideoConfirmed = true
                    curVp.audio?.isMuted = false
                    self.videoContainer.alpha = 1
                    if self.vlcSeekPendingSec <= 1 {
                        let curSec = self.currentTimeSeconds()
                        if curSec > 0.6 && curSec < 4.5 && !self.isLiveStream {
                            self.seekPlayer(to: 0)
                        }
                    }
                    self.resolverWebView?.stopLoading()
                    self.resolverWebView?.loadHTMLString("", baseURL: nil)
                }
            }
            self.checkVlcReadyIfNeeded(url: url, token: myToken)
            self.ensureOriginalAudioIos()
            if self.vlcReadyHandled && self.currentDurationSeconds() > 0 && self.vlcSeekPendingSec <= 0 && (self.currentTimeSeconds() > 1.0 || (self.startTimeSec <= 1 && self.isPlayerPlaying())) {
                self.hasRealPlaybackProgress = true
            }
            self.updateTimeAndSubtitles()
            self.updateSkipAndNextEpisodeUi()
            let now = Date().timeIntervalSince1970
            if now - self.lastProgressSaveTime >= 2.0 && !self.isScrubbing && self.gestureMode != 4 {
                self.lastProgressSaveTime = now
                self.saveProgress(forceCompleted: false)
            }
        }
    }

    private func checkVlcReadyIfNeeded(url: URL, token: Int) {
        guard !vlcReadyHandled, vlcPlaybackToken == token, let vp = vlcPlayer else { return }
        let dur = currentDurationSeconds()
        let pos = currentTimeSeconds()
        guard vp.isPlaying || dur > 0 || pos > 0 else { return }
        vlcReadyHandled = true
        vp.currentVideoSubTitleIndex = -1
        let minValidSec: Double = mediaType.lowercased() == "tv" ? 60.0 : 180.0
        let vSize = vp.videoSize
        let isPortraitAd = vSize.width > 0 && vSize.height > 0 && vSize.height > vSize.width * 0.95
        if !isLiveStream && !streamUrl.hasPrefix("/") && (isPortraitAd || (dur > 0 && dur < minValidSec)) {
            vp.stop()
            videoContainer.alpha = 0
            let prev = UserDefaults.standard.integer(forKey: "sb_blocked_total")
            UserDefaults.standard.set(prev + 1, forKey: "sb_blocked_total")
            onBlockedAd?(url.absoluteString)
            streamUrl = ""
            isSwitchingServer = true
            showToast("Blocked ad clip")
            showCaptchaCard(for: "hnembed")
            return
        }
        headerRetryStage = 0
        if let wv = resolverWebView {
            wv.alpha = 0.0
            wv.isUserInteractionEnabled = false
            view.sendSubviewToBack(wv)
        }
        hideCaptchaCard()
        resolverWebView?.evaluateJavaScript("try{window.postMessage({__sbStop:true},'*');document.querySelectorAll('video,audio').forEach(function(v){v.pause();v.muted=true;v.volume=0;v.removeAttribute('src');v.load();});}catch(e){}", completionHandler: nil)
        if vSize.width > 16 && vSize.height > 16 {
            vlcVideoConfirmed = true
            vp.audio?.isMuted = false
            videoContainer.alpha = 1
        }
        failoverAttempts = 0
        isSwitchingServer = false
        failoverTimer?.invalidate()
        recordServerStatus(currentSource, status: "working")
        UserDefaults.standard.set(currentSource, forKey: "streambert_lastWorkingSource")
        onPreferredSource?(currentSource)
        if dur > 60 {
            fetchSkipSegmentsInBackground(durationMs: Int(dur * 1000.0))
        }
        if vlcSeekPendingSec > 1 && (dur <= 0 || vlcSeekPendingSec < dur - 15) {
            let pending = vlcSeekPendingSec
            vlcSeekPendingSec = 0
            seekPlayer(to: pending)
        } else {
            vlcSeekPendingSec = 0
        }
        ensureOriginalAudioIos()
        if abs(vp.rate - currentSpeed) > 0.01 { vp.rate = currentSpeed }
        updatePlayPauseIcon()
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.5) { [weak self] in
            guard let self = self, self.vlcPlaybackToken == token, let curVp = self.vlcPlayer else { return }
            let vSz = curVp.videoSize
            let hasVideo = self.vlcVideoConfirmed || (vSz.width > 16 && vSz.height > 16)
            if hasVideo {
                self.vlcVideoConfirmed = true
                curVp.audio?.isMuted = false
                self.videoContainer.alpha = 1
                self.resolverWebView?.stopLoading()
                self.resolverWebView?.loadHTMLString("", baseURL: nil)
                return
            }
            curVp.audio?.isMuted = true
            self.videoContainer.alpha = 0
            if !self.forceSoftwareDecode {
                self.forceSoftwareDecode = true
                self.vlcReadyHandled = false
                self.startPlayback(urlString: self.streamUrl, referer: self.activeReferer, seekSec: self.vlcSeekPendingSec)
            } else {
                self.forceSoftwareDecode = false
                self.failedStreamUrls.insert(url.absoluteString)
                self.vlcReadyHandled = false
                curVp.delegate = nil
                curVp.drawable = nil
                self.vlcPlayer = nil
                DispatchQueue.global(qos: .userInitiated).async { curVp.stop() }
                self.streamUrl = ""
                self.isSwitchingServer = true
                self.advanceToNextAutoSource()
            }
        }
    }

    func mediaPlayerStateChanged(_ aNotification: Notification) {
        DispatchQueue.main.async { [weak self] in
            guard let self = self, let vp = self.vlcPlayer else { return }
            let st = vp.state
            if st == .playing {
                self.vlcDidEnd = false
                self.desiredPaused = nil
                vp.currentVideoSubTitleIndex = -1
                if let u = self.activePlayUrl ?? URL(string: self.streamUrl) {
                    self.checkVlcReadyIfNeeded(url: u, token: self.vlcPlaybackToken)
                }
                if self.vlcSeekPendingSec > 0.5 && self.vlcReadyHandled {
                    let target = self.vlcSeekPendingSec
                    self.vlcSeekPendingSec = 0
                    vp.time = VLCTime(int: Int32(target * 1000.0))
                }
                if abs(vp.rate - self.currentSpeed) > 0.01 {
                    vp.rate = self.currentSpeed
                }
                self.updatePlayPauseIcon()
            } else if st == .paused {
                self.desiredPaused = nil
                self.saveProgress(forceCompleted: false, isPlayingOverride: false)
                self.updatePlayPauseIcon()
            } else if st == .ended {
                self.vlcDidEnd = true
                self.saveProgress(forceCompleted: true)
                self.updatePlayPauseIcon()
                if self.sleepAtEndOfEpisode {
                    self.sleepAtEndOfEpisode = false
                    self.sleepButton.setTitle("Timer", for: .normal)
                    self.nextEpDismissed = true
                    self.showToast("Sleep timer: paused at end of episode")
                } else if self.mediaType.lowercased() == "tv" && !self.nextEpDismissed && self.computeNextEpisode() != nil {
                    self.playNextEpisodeInPlayer()
                }
            } else if st == .error {
                if self.headerRetryStage < 2 {
                    self.headerRetryStage += 1
                    self.startPlayback(urlString: self.streamUrl, referer: self.activeReferer, seekSec: self.vlcSeekPendingSec)
                    return
                }
                if self.headerRetryStage == 2 {
                    self.headerRetryStage = 3
                    if let origUrl = URL(string: self.streamUrl) {
                        var req = URLRequest(url: origUrl)
                        req.setValue("Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1", forHTTPHeaderField: "User-Agent")
                        if !self.activeReferer.isEmpty { req.setValue(self.activeReferer, forHTTPHeaderField: "Referer") }
                        URLSession.shared.dataTask(with: req) { [weak self] data, resp, _ in
                            guard let self = self else { return }
                            DispatchQueue.main.async {
                                let finalUrl = resp?.url?.absoluteString ?? self.streamUrl
                                let ct = (resp as? HTTPURLResponse)?.allHeaderFields["Content-Type"] as? String ?? ""
                                let fullText = data.flatMap { String(data: $0, encoding: .utf8) } ?? ""
                                let detectedHls = ct.lowercased().contains("mpegurl") || fullText.contains("#EXTM3U")
                                if detectedHls && fullText.contains("#EXTM3U") {
                                    self.inlineM3u8Text = fullText
                                    self.inlineBaseUrl = finalUrl
                                    self.streamIsHls = true
                                    self.streamUrl = "singularity-inline://playlist.m3u8"
                                    self.startPlayback(urlString: self.streamUrl, referer: self.activeReferer, seekSec: self.vlcSeekPendingSec)
                                    return
                                }
                                if finalUrl != self.streamUrl {
                                    if finalUrl.lowercased().contains("googlevideo") || finalUrl.lowercased().contains("googleusercontent") {
                                        self.activeReferer = ""
                                    }
                                    self.streamUrl = finalUrl
                                    self.startPlayback(urlString: finalUrl, referer: self.activeReferer, seekSec: self.vlcSeekPendingSec)
                                    return
                                }
                                self.activeReferer = ""
                                self.startPlayback(urlString: self.streamUrl, referer: "", seekSec: self.vlcSeekPendingSec)
                            }
                        }.resume()
                        return
                    }
                }
                self.headerRetryStage = 0
                self.failedStreamUrls.insert(self.streamUrl)
                self.streamUrl = ""
                self.verifiedServers.removeValue(forKey: self.currentSource)
                self.updateSwitchServerButtonTitle()
                self.isSwitchingServer = false
                if self.isCaptchaVisible {
                    self.showToast("Failed — pick another in SERVERS")
                } else {
                    self.triggerNextServerFailover()
                }
            }
        }
    }

    private func updateSwitchServerButtonTitle() {
        let readyCount = verifiedServers.keys.filter { $0 != currentSource }.count
        if readyCount > 0 {
            switchServerButton.setTitle("Servers (\(readyCount)) ▾", for: .normal)
        } else {
            switchServerButton.setTitle("Servers ▾", for: .normal)
        }
    }

    private func bestVerifiedServer(excluding excluded: String) -> (source: String, url: String, referer: String)? {
        let curIdx = serverOrder.firstIndex(of: excluded) ?? -1
        var candidates: [(idx: Int, src: String, url: String, ref: String, isHls: Bool)] = []
        for (src, info) in verifiedServers {
            if src == excluded { continue }
            let idx = serverOrder.firstIndex(of: src) ?? 999
            let l = info.url.lowercased()
            let isHls = l.contains(".m3u8") || l.contains(".mpd")
            candidates.append((idx: idx, src: src, url: info.url, ref: info.referer, isHls: isHls))
        }
        if candidates.isEmpty { return nil }
        candidates.sort { a, b in
            if a.isHls != b.isHls { return a.isHls && !b.isHls }
            let aAfter = a.idx > curIdx ? 0 : 1
            let bAfter = b.idx > curIdx ? 0 : 1
            if aAfter != bAfter { return aAfter < bAfter }
            return a.idx < b.idx
        }
        let pick = candidates[0]
        return (pick.src, pick.url, pick.ref)
    }

    @objc private func handleSwitchServer() {
        showControllerTemporarily()
        let sheet = UIAlertController(title: "HnEmbed Servers", message: "Choose a server or reload HnEmbed", preferredStyle: .actionSheet)
        for srv in multiEmbedSubServers {
            sheet.addAction(UIAlertAction(title: srv.name, style: .default) { [weak self] _ in
                guard let self = self else { return }
                self.userSelectedSubServer = true
                self.failedStreamUrls.removeAll()
                self.streamUrl = ""
                self.isSwitchingServer = true
                self.pendingNextSource = "hnembed"
                self.currentSource = "hnembed"
                let js = "(function(){var el=document.querySelector('[data-s-idx=\"\(srv.idx)\"]');if(el){el.click();return 'ok';}return 'no';})();"
                self.resolverWebView?.evaluateJavaScript(js, completionHandler: nil)
                self.showCaptchaCard(for: "hnembed")
                self.showToast("Selected \(srv.name)")
            })
        }
        sheet.addAction(UIAlertAction(title: "Open HnEmbed Window", style: .default) { [weak self] _ in
            guard let self = self else { return }
            self.isSwitchingServer = true
            self.pendingNextSource = "hnembed"
            self.currentSource = "hnembed"
            let curUrl = self.resolverWebView?.url?.absoluteString ?? ""
            if curUrl.isEmpty || curUrl == "about:blank" {
                let embed = self.buildEmbedUrl(for: "hnembed")
                if !embed.isEmpty, let u = URL(string: embed) {
                    self.loadHnEmbedUrl(u)
                }
            }
            self.showCaptchaCard(for: "hnembed")
        })
        sheet.addAction(UIAlertAction(title: "Reload HnEmbed", style: .destructive) { [weak self] _ in
            guard let self = self else { return }
            self.skipCaptchaServer()
            self.showCaptchaCard(for: "hnembed")
        })
        sheet.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        sheet.popoverPresentationController?.sourceView = switchServerButton
        sheet.popoverPresentationController?.sourceRect = switchServerButton.bounds
        present(sheet, animated: true)
    }

    private func startBackgroundServerProbing() {
        if directWebPlayerMode { return }
        if isProbingActive || (!streamUrl.isEmpty && streamUrl.hasPrefix("/")) { return }
        isProbingActive = true
        probeQueue = serverOrder.filter { $0 != currentSource && !probedFailedServers.contains($0) && verifiedServers[$0] == nil }
        if probeQueue.isEmpty { return }
        let slotCount = min(2, probeQueue.count)
        for _ in 0..<slotCount {
            let cfg = WKWebViewConfiguration()
            cfg.websiteDataStore = WKWebsiteDataStore.default()
            cfg.allowsInlineMediaPlayback = true
            cfg.mediaTypesRequiringUserActionForPlayback = .all
            cfg.preferences.javaScriptCanOpenWindowsAutomatically = false
            let ucc = WKUserContentController()
            ucc.add(self, name: "ProbeSniffer")
        let probeJs = """
        (function(){
          var hn = (location.hostname || '').toLowerCase();
          if (/cloudflare\\.com|recaptcha\\.net|hcaptcha\\.com|arkoselabs\\.com|geetest\\.com/.test(hn)) return;
          if (window.__sbProbeInstalled) return;
          window.__sbProbeInstalled = true;
          try { window.open = function(){ return null; }; } catch(e) {}
          function post(kind, u) {
            if (!u || typeof u !== 'string') return;
            var l = u.toLowerCase();
            if (kind === 'dead' || kind === 'challenge' || l.indexOf('.m3u8') !== -1 || l.indexOf('.mpd') !== -1 || l.indexOf('master.txt') !== -1 || l.indexOf('playlist.txt') !== -1 || l.indexOf('/hls/') !== -1 || (l.indexOf('.mp4') !== -1 && l.indexOf('preview') === -1 && l.indexOf('trailer') === -1 && l.indexOf('favicon') === -1)) {
              try { window.webkit.messageHandlers.ProbeSniffer.postMessage({ kind: kind, url: u, ref: location.href }); } catch(e) {}
            }
          }
          if (window.fetch) {
            var of = window.fetch;
            window.fetch = function(i){ try { post('stream', typeof i === 'string' ? i : (i && i.url)); } catch(e) {} return of.apply(this, arguments); };
          }
          if (window.XMLHttpRequest) {
            var oo = XMLHttpRequest.prototype.open;
            XMLHttpRequest.prototype.open = function(m, u){ try { post('stream', u); } catch(e) {} return oo.apply(this, arguments); };
          }
          try { new PerformanceObserver(function(list){ list.getEntries().forEach(function(e){ post('stream', e.name); }); }).observe({ entryTypes: ['resource'] }); } catch(e) {}
          function checkPage() {
            try {
              var txt = ((document.title || '') + ' ' + (document.body ? document.body.innerText.slice(0, 500) : '')).toLowerCase();
              if (txt.indexOf('no sources') !== -1 || txt.indexOf('try again later') !== -1 || txt.indexOf('404 not found') !== -1 || txt.indexOf('502 bad gateway') !== -1 || txt.indexOf('media not found') !== -1 || txt.indexOf('video not found') !== -1 || txt.indexOf('not available') !== -1) {
                post('dead', location.href);
                return;
              }
              if (txt.indexOf('just a moment') !== -1 || txt.indexOf('verify you are human') !== -1 || txt.indexOf('security check') !== -1 || !!document.querySelector('iframe[src*="turnstile"],iframe[src*="challenge"],iframe[src*="captcha"],.cf-turnstile,.g-recaptcha,.h-captcha')) {
                post('challenge', location.href);
                return;
              }
              document.querySelectorAll('video, source').forEach(function(el){
                if (el.src) post('stream', el.src);
                if (el.currentSrc) post('stream', el.currentSrc);
                if (el.tagName === 'VIDEO') { el.muted = true; try { el.pause(); } catch(e) {} }
              });
              document.querySelectorAll('#pl_but,.play,.btn-play,[class*=play],button').forEach(function(b){ try { b.click(); } catch(e) {} });
            } catch(e) {}
          }
          setTimeout(checkPage, 650);
          setTimeout(checkPage, 1700);
        })();
        """
            ucc.addUserScript(WKUserScript(source: probeJs, injectionTime: .atDocumentStart, forMainFrameOnly: false))
            cfg.userContentController = ucc
            let pwv = WKWebView(frame: CGRect(x: 0, y: 0, width: 64, height: 64), configuration: cfg)
            pwv.alpha = 0.001
            pwv.isUserInteractionEnabled = false
            pwv.navigationDelegate = self
            pwv.uiDelegate = self
            pwv.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"
            view.insertSubview(pwv, at: 0)
            probeWebViews.append(pwv)
            advanceProbeSlot(pwv)
        }
    }

    private func advanceProbeSlot(_ pwv: WKWebView) {
        let oid = ObjectIdentifier(pwv)
        probeTimers[oid]?.invalidate()
        probeTimers[oid] = nil
        probeSlotSources.removeValue(forKey: oid)
        pwv.stopLoading()
        while !probeQueue.isEmpty {
            let nextSrc = probeQueue.removeFirst()
            if nextSrc == currentSource || probedFailedServers.contains(nextSrc) || verifiedServers[nextSrc] != nil { continue }
            let embed = buildEmbedUrl(for: nextSrc)
            if embed.isEmpty { continue }
            guard let u = URL(string: embed) else { continue }
            probeSlotSources[oid] = nextSrc
            pwv.load(URLRequest(url: u))
            probeTimers[oid] = Timer.scheduledTimer(withTimeInterval: 6.5, repeats: false) { [weak self, weak pwv] _ in
                guard let self = self, let pwv = pwv else { return }
                let k = ObjectIdentifier(pwv)
                if let failedSrc = self.probeSlotSources[k] {
                    self.probedFailedServers.insert(failedSrc)
                }
                self.advanceProbeSlot(pwv)
            }
            return
        }
        pwv.loadHTMLString("", baseURL: nil)
    }

    private func stopBackgroundServerProbing() {
        isProbingActive = false
        probeQueue.removeAll()
        for (_, t) in probeTimers { t.invalidate() }
        probeTimers.removeAll()
        probeSlotSources.removeAll()
        for pwv in probeWebViews {
            pwv.stopLoading()
            pwv.removeFromSuperview()
        }
        probeWebViews.removeAll()
    }

    private func triggerNextServerFailover() {
        if isLiveStream { return }
        if isSwitchingServer || isCaptchaVisible { return }
        if let best = bestVerifiedServer(excluding: currentSource) {
            failoverTimer?.invalidate()
            isSwitchingServer = false
            hideCaptchaCard()
            currentSource = best.source
            streamUrl = best.url
            updateServerBadge(best.source)
            updateSwitchServerButtonTitle()
            let cur = currentTimeSeconds() > 0 ? currentTimeSeconds() : startTimeSec
            let resume = cur.isFinite && cur > 0 ? cur : startTimeSec
            startPlayback(urlString: best.url, referer: best.referer, seekSec: resume)
            return
        }
        if serverOrder.count == 1 && serverOrder.first == "hnembed" {
            isSwitchingServer = true
            pendingNextSource = "hnembed"
            currentSource = "hnembed"
            let curUrl = resolverWebView?.url?.absoluteString ?? ""
            if curUrl.isEmpty || curUrl == "about:blank" {
                let embed = buildEmbedUrl(for: "hnembed")
                if !embed.isEmpty, let u = URL(string: embed) {
                    loadHnEmbedUrl(u)
                }
            }
            resolverWebView?.evaluateJavaScript("(function(){document.querySelectorAll('button,div,span').forEach(function(b){var t=(b.innerText||'').trim().toLowerCase();if(t==='servers'||t.indexOf('servers')===0){try{b.click();}catch(e){}}});})();", completionHandler: nil)
            showToast("Pick another server from Servers ▾")
            showCaptchaCard(for: "hnembed")
            return
        }
        if failoverAttempts >= serverOrder.count {
            showToast("No working server found — tap Switch Server to retry")
            return
        }
        isSwitchingServer = true
        failoverAttempts += 1
        var nextSrc: String? = nil
        let idx = serverOrder.firstIndex(of: currentSource) ?? 0
        for step in 1...serverOrder.count {
            let cand = serverOrder[(idx + step) % serverOrder.count]
            if !probedFailedServers.contains(cand) {
                nextSrc = cand
                break
            }
        }
        guard let nextSrc = nextSrc else {
            showToast("No working server found — tap Switch Server to retry")
            return
        }
        pendingNextSource = nextSrc
        updateServerBadge(nextSrc)
        showToast("Switching to \(nextSrc)...")
        let embed = buildEmbedUrl(for: nextSrc)
        if !embed.isEmpty, let u = URL(string: embed) {
            loadHnEmbedUrl(u)
        }
        failoverTimer?.invalidate()
        failoverTimer = Timer.scheduledTimer(withTimeInterval: 7.5, repeats: false) { [weak self] _ in
            guard let self = self, self.isSwitchingServer else { return }
            self.isSwitchingServer = false
            self.currentSource = self.pendingNextSource
            self.triggerNextServerFailover()
        }
    }

    func applyExternalResolvedStream(url: String, sourceId: String) {
        if url.isEmpty { return }
        DispatchQueue.main.async {
            self.failoverTimer?.invalidate()
            self.isSwitchingServer = false
            self.streamUrl = url
            if !sourceId.isEmpty { self.currentSource = sourceId }
            self.updateServerBadge(self.currentSource)
            let cur = self.currentTimeSeconds() > 0 ? self.currentTimeSeconds() : self.startTimeSec
            let resume = cur.isFinite && cur > 0 ? cur : self.startTimeSec
            self.startPlayback(urlString: url, referer: self.buildReferer(for: self.currentSource), seekSec: resume)
        }
    }

    private func isMismatchedTitleOrEpisode(_ hint: String) -> Bool {
        let h = hint.lowercased()
        if h.isEmpty { return false }
        if mediaType.lowercased() == "tv" {
            if let regex = try? NSRegularExpression(pattern: "(?:s(\\d{1,2})\\s*e(\\d{1,2})|\\b(\\d{1,2})x(\\d{1,2})\\b)") {
                let range = NSRange(h.startIndex..<h.endIndex, in: h)
                if let m = regex.firstMatch(in: h, range: range) {
                    let sRange = m.range(at: 1).location != NSNotFound ? m.range(at: 1) : m.range(at: 3)
                    let eRange = m.range(at: 2).location != NSNotFound ? m.range(at: 2) : m.range(at: 4)
                    if let sr = Range(sRange, in: h), let er = Range(eRange, in: h),
                       let sVal = Int(h[sr]), let eVal = Int(h[er]) {
                        if sVal != seasonNum || eVal != episodeNum { return true }
                    }
                }
            }
        }
        return false
    }

    private func isSuspiciousStreamUrl(_ url: String) -> Bool {
        let l = url.lowercased()
        let bad = ["promo", "teaser", "preroll", "/ads/", "banner", "trailer", "preview", "bumper", "doubleclick", "vast", "vmap"]
        return bad.contains { l.contains($0) }
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        if message.name == "ProbeSniffer" {
            guard let pwv = message.webView,
                  let dict = message.body as? [String: Any],
                  let url = dict["url"] as? String else { return }
            let oid = ObjectIdentifier(pwv)
            guard let src = probeSlotSources[oid] else { return }
            let kind = dict["kind"] as? String ?? "stream"
            if kind == "sub" {
            let subTrack = IosSubTrack(lang: preferredLang.isEmpty ? "en" : preferredLang, url: url, score: 160, syncMatch: true)
            mergeSubtitleTracks([subTrack])
            return
        }
        if kind == "servers_list" {
            if let arr = dict["servers"] as? [[String: Any]] {
                var parsed: [(name: String, idx: String)] = []
                for item in arr {
                    if let n = item["name"] as? String, let ix = item["idx"] as? String, !n.isEmpty {
                        parsed.append((name: n, idx: ix))
                    }
                }
                if !parsed.isEmpty {
                    multiEmbedSubServers = parsed
                    switchServerButton.setTitle("Servers (\(parsed.count)) ▾", for: .normal)
                }
            }
            return
        }
        if kind == "servers_list" {
            if let arr = dict["servers"] as? [[String: Any]] {
                var parsed: [(name: String, idx: String)] = []
                for item in arr {
                    if let n = item["name"] as? String, let ix = item["idx"] as? String, !n.isEmpty {
                        parsed.append((name: n, idx: ix))
                    }
                }
                if !parsed.isEmpty {
                    multiEmbedSubServers = parsed
                    switchServerButton.setTitle("Servers (\(parsed.count)) ▾", for: .normal)
                }
            }
            return
        }
        if kind == "ad_blocked" {
            let prev = UserDefaults.standard.integer(forKey: "sb_blocked_total")
            UserDefaults.standard.set(prev + 1, forKey: "sb_blocked_total")
            onBlockedAd?(url)
            return
        }
        if kind == "dead" {
                probedFailedServers.insert(src)
                advanceProbeSlot(pwv)
                return
            }
            if kind == "challenge" {
                advanceProbeSlot(pwv)
                return
            }
            let pHint = (dict["hint"] as? String ?? "")
            if isSuspiciousStreamUrl(url) || isMismatchedTitleOrEpisode(pHint) || probedFailedServers.contains(src) { return }
            let ref = dict["ref"] as? String ?? buildReferer(for: src)
            verifiedServers[src] = (url: url, referer: ref)
            updateSwitchServerButtonTitle()
            if isSwitchingServer && streamUrl.isEmpty {
                failoverTimer?.invalidate()
                isSwitchingServer = false
                hideCaptchaCard()
                currentSource = src
                streamUrl = url
                updateServerBadge(src)
                updateSwitchServerButtonTitle()
                let cur = currentTimeSeconds() > 0 ? currentTimeSeconds() : startTimeSec
                let resume = cur.isFinite && cur > 0 ? cur : startTimeSec
                startPlayback(urlString: url, referer: ref, seekSec: resume)
            }
            advanceProbeSlot(pwv)
            return
        }
        if message.name == "PlayerSniffer",
           let dict = message.body as? [String: Any] {
            let k = dict["kind"] as? String ?? ""
            if k == "web_back" {
                DispatchQueue.main.async { [weak self] in self?.handleBack() }
                return
            }
            if k == "web_progress" {
                let pos = (dict["pos"] as? NSNumber)?.intValue ?? 0
                let dur = (dict["dur"] as? NSNumber)?.intValue ?? 0
                let playing = (dict["playing"] as? Bool) ?? true
                if dur > 10 && !progressKey.isEmpty {
                    let pct = min(100, max(0, (pos * 100) / dur))
                    let watched = pct >= 90
                    DispatchQueue.main.async { [weak self] in
                        guard let self = self else { return }
                        self.onProgressUpdate?(self.progressKey, pct, pos, dur, watched, playing)
                    }
                }
                return
            }
            if k == "web_prefs", let pj = dict["prefs"] as? String, pj.count > 2 {
                DispatchQueue.main.async { [weak self] in
                    self?.onWebPrefsUpdate?(pj)
                }
                return
            }
        }
        if directWebPlayerMode { return }
        guard message.name == "PlayerSniffer",
              let dict = message.body as? [String: Any],
              let url = dict["url"] as? String else { return }
        let kind = dict["kind"] as? String ?? "stream"
        if kind == "ad_blocked" {
            let prev = UserDefaults.standard.integer(forKey: "sb_blocked_total")
            UserDefaults.standard.set(prev + 1, forKey: "sb_blocked_total")
            onBlockedAd?(url)
            return
        }
        if kind == "subserver_selected" {
            userSelectedSubServer = true
            failedStreamUrls.removeAll()
            streamUrl = ""
            return
        }
        if kind == "m3u8_inline" {
            if let m3u8 = dict["m3u8"] as? String, !m3u8.isEmpty {
                inlineM3u8Text = m3u8
                inlineBaseUrl = url
                streamIsHls = true
                let rawRef = (dict["ref"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
                let ref = rawRef.isEmpty ? buildReferer(for: "hnembed") : rawRef
                failoverTimer?.invalidate()
                isSwitchingServer = false
                hideCaptchaCard()
                if !directWebPlayerMode { resolverWebView?.evaluateJavaScript("try{document.querySelectorAll('video,audio').forEach(function(v){v.pause();v.muted=true;});}catch(e){}", completionHandler: nil) } else { resolverWebView?.evaluateJavaScript("try{document.querySelectorAll('video').forEach(function(v){if(!v.paused){window.__sbWasP=1;v.pause();}});}catch(e){}", completionHandler: nil) }
                headerRetryStage = 0
                currentSource = "hnembed"
                pendingNextSource = ""
                streamUrl = "singularity-inline://playlist.m3u8"
                updateServerBadge(currentSource)
                let cur = currentTimeSeconds() > 0 ? currentTimeSeconds() : startTimeSec
                let resume = cur.isFinite && cur > 0 ? cur : startTimeSec
                startPlayback(urlString: streamUrl, referer: ref, seekSec: resume)
            }
            return
        }
        if kind == "dead" {
            if isSwitchingServer && !isCaptchaVisible {
                let failedSrc = pendingNextSource.isEmpty ? currentSource : pendingNextSource
                failoverTimer?.invalidate()
                isSwitchingServer = false
                currentSource = failedSrc
                pendingNextSource = ""
                triggerNextServerFailover()
            }
            return
        }
        if kind == "challenge" {
            if isSwitchingServer && !isCaptchaVisible {
                let targetSrc = pendingNextSource.isEmpty ? currentSource : pendingNextSource
                failoverTimer?.invalidate()
                showCaptchaCard(for: targetSrc)
            }
            return
        }
        let psHint = (dict["hint"] as? String ?? "")
        if kind == "diag_toast" {
            if isCaptchaVisible && streamUrl.isEmpty, let msg = dict["msg"] as? String {
                showToast(msg)
            }
            return
        }
        let bypass = (dict["bypass"] as? Bool) ?? false
        if (!bypass && isSuspiciousStreamUrl(url)) || (currentSource != "vidyst" && isMismatchedTitleOrEpisode(psHint)) || failedStreamUrls.contains(url) || url == streamUrl { return }
        let hint = (dict["hint"] as? String ?? "").lowercased()
        if !hint.isEmpty { activeReleaseHint = hint + " " + url.lowercased() }
        let isHlsFlag = (dict["isHls"] as? Bool) ?? false
        let rawRef = (dict["ref"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let ref = rawRef.isEmpty ? buildReferer(for: pendingNextSource) : rawRef
        if isSwitchingServer || isCaptchaVisible || streamUrl.isEmpty {
            failoverTimer?.invalidate()
            isSwitchingServer = false
            hideCaptchaCard()
            if !directWebPlayerMode { resolverWebView?.evaluateJavaScript("try{document.querySelectorAll('video,audio').forEach(function(v){v.pause();v.muted=true;});}catch(e){}", completionHandler: nil) } else { resolverWebView?.evaluateJavaScript("try{document.querySelectorAll('video').forEach(function(v){if(!v.paused){window.__sbWasP=1;v.pause();}});}catch(e){}", completionHandler: nil) }
            currentSource = pendingNextSource.isEmpty ? currentSource : pendingNextSource
            pendingNextSource = ""
            headerRetryStage = 0
            streamIsHls = isHlsFlag
            streamUrl = url
            updateServerBadge(currentSource)
            let cur = currentTimeSeconds() > 0 ? currentTimeSeconds() : startTimeSec
            let resume = cur.isFinite && cur > 0 ? cur : startTimeSec
            startPlayback(urlString: url, referer: ref, seekSec: resume)
        }
    }

    private func showToast(_ text: String) {
        statusToastLabel.text = "  \(text)  "
        statusToastLabel.isHidden = false
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { [weak self] in
            self?.statusToastLabel.isHidden = true
        }
    }

    private func applyLiveModeUI() {
        guard isLiveStream else { return }
        topRestartGroupRef?.isHidden = true
        topRestartButton.isHidden = true
        rewBtnRef?.isHidden = true
        fwdBtnRef?.isHidden = true
        subButton.isHidden = true
        subStyleButton.isHidden = true
        syncButton.isHidden = true

        speedButton.isHidden = true
        aspectButton.isHidden = true
        skip85Button.isHidden = true
        serverPickButton.isHidden = true
        pipButton.isHidden = true
        sleepButton.isHidden = false
        lockButton.isHidden = false
        seekSlider.isUserInteractionEnabled = false
        seekSlider.value = 1.0
        seekSlider.thumbTintColor = .clear
        let emptyThumb = UIGraphicsImageRenderer(size: CGSize(width: 1, height: 1)).image { _ in }
        seekSlider.setThumbImage(emptyThumb, for: .normal)
        seekSlider.setThumbImage(emptyThumb, for: .highlighted)
        durationLabel.text = "  LIVE  "
        durationLabel.backgroundColor = UIColor(red: 229/255, green: 9/255, blue: 20/255, alpha: 1)
        durationLabel.textColor = .white
        durationLabel.font = .systemFont(ofSize: 11, weight: .heavy)
        durationLabel.layer.cornerRadius = 6
        durationLabel.layer.masksToBounds = true
        durationLabel.clipsToBounds = true
        currentPosLabel.text = "0:00"
    }

    private func updateTimeAndSubtitles() {
        guard let player = vlcPlayer else { return }
        if isLiveStream {
            let nowTs = Date().timeIntervalSince1970
            if player.isPlaying {
                if lastLiveTickTs > 0 {
                    let dt = nowTs - lastLiveTickTs
                    if dt > 0 && dt < 5.0 {
                        liveElapsedSec += dt
                    }
                }
                lastLiveTickTs = nowTs
            } else {
                lastLiveTickTs = 0
            }
            currentPosLabel.text = formatTime(liveElapsedSec)
            durationLabel.text = "  LIVE  "
            seekSlider.value = 1.0
            ambientFillWidthConstraint?.constant = view.bounds.width
            return
        }
        let pos = currentTimeSeconds()
        let dur = currentDurationSeconds()
        if !isScrubbing && pos.isFinite && dur.isFinite && dur > 0 {
            let minValidSec: Double = mediaType.lowercased() == "tv" ? 60.0 : 180.0
            if dur < minValidSec && !streamUrl.hasPrefix("/") {
                player.pause()
                recordServerStatus(currentSource, status: "failed")
                showToast("Short/fake clip on \(serverDisplayName(currentSource)) — switching...")
                if !isSwitchingServer {
                    triggerNextServerFailover()
                }
                return
            }
            let nowTs = Date().timeIntervalSince1970
            let isSeekLocked = nowTs < seekUiLockUntil && pendingSeekTargetSec >= 0 && abs(pos - pendingSeekTargetSec) > 2.0
            if !isSeekLocked {
                if nowTs < seekUiLockUntil && pendingSeekTargetSec >= 0 && abs(pos - pendingSeekTargetSec) <= 2.0 {
                    seekUiLockUntil = 0
                }
                currentPosLabel.text = formatTime(pos)
                let rem = max(0, dur - pos)
                durationLabel.text = "-\(formatTime(rem))"
                let frac = min(1.0, max(0.0, pos / dur))
                seekSlider.value = Float(frac)
                ambientFillWidthConstraint?.constant = view.bounds.width * CGFloat(frac)
            }
            if !isSwitchingServer && dur >= minValidSec && (pos > 0.5 || player.isPlaying) {
                if getServerStatus(currentSource) != "working" {
                    recordServerStatus(currentSource, status: "working")
                }
            }
        }
        if usingNativeHlsSubtitle { return }
        if !activeCues.isEmpty && pos.isFinite {
            let adj = pos - subDelaySec
            if let cue = activeCues.first(where: { adj >= $0.startSec && adj <= $0.endSec }) {
                let lc = cue.text.lowercased()
                if lc.contains("osdb.link") || lc.contains("opensubtitles.org") || lc.contains("advertise your product") {
                    subtitleLabel.isHidden = true
                } else {
                    subtitleLabel.text = cue.text
                    subtitleLabel.isHidden = false
                }
            } else {
                subtitleLabel.isHidden = true
            }
        } else {
            subtitleLabel.isHidden = true
        }
    }

    private func formatTime(_ sec: Double) -> String {
        let total = max(0, Int(sec))
        let h = total / 3600
        let m = (total % 3600) / 60
        let s = total % 60
        return h > 0 ? String(format: "%d:%02d:%02d", h, m, s) : String(format: "%d:%02d", m, s)
    }

    private func updatePlayPauseIcon() {
        let playing = desiredPaused.map { !$0 } ?? isPlayerPlaying()
        playPauseButton.setImage(UIImage(systemName: playing ? "pause.fill" : "play.fill"), for: .normal)
    }

    private func showGestureHud(_ text: String, symbolName: String? = nil) {
        gestureHudLabel.text = text
        if let sym = symbolName {
            let cfg = UIImage.SymbolConfiguration(pointSize: 14, weight: .bold)
            gestureHudIconView.image = UIImage(systemName: sym, withConfiguration: cfg)
            gestureHudIconView.isHidden = false
        } else {
            gestureHudIconView.isHidden = true
        }
        gestureHudContainer.isHidden = false
        gestureHudContainer.alpha = 1
    }

    private func hideGestureHud() {
        UIView.animate(withDuration: 0.16, animations: { self.gestureHudContainer.alpha = 0 }) { _ in
            if self.gestureMode != 3 && self.gestureMode != 4 && self.gestureMode != 5 {
                self.gestureHudContainer.isHidden = true
            }
        }
    }

    private func formatSpeedText(_ sp: Double) -> String {
        let tenths = Int((sp * 10.0).rounded())
        return (tenths % 10 == 0) ? "\(tenths / 10)x" : String(format: "%.1fx", Double(tenths) / 10.0)
    }

    private func endHold2xGesture() {
        hold2xWorkItem?.cancel()
        hold2xWorkItem = nil
        gestureMode = 0
        vlcLastHoldSpeed = 0
        if let p = vlcPlayer {
            p.rate = currentSpeed
        }
        hideGestureHud()
    }

    private func showControllerTemporarily() {
        if directWebPlayerMode { return }
        isControllerVisible = true
        overlayView.isHidden = false
        view.bringSubviewToFront(overlayView)
        ambientTrackView.transform = .identity
        UIView.animate(withDuration: 0.22, delay: 0, options: [.curveEaseOut]) {
            self.overlayView.alpha = 1
            self.ambientTrackView.alpha = 0
        } completion: { _ in
            if self.isControllerVisible { self.ambientTrackView.isHidden = true }
        }
        hideControllerWorkItem?.cancel()
        let item = DispatchWorkItem { [weak self] in
            guard let self = self, self.isPlayerPlaying(), !self.isScrubbing else { return }
            self.setControllerVisible(false)
        }
        hideControllerWorkItem = item
        DispatchQueue.main.asyncAfter(deadline: .now() + 4.0, execute: item)
    }

    private func setControllerVisible(_ visible: Bool) {
        if directWebPlayerMode { return }
        isControllerVisible = visible
        if visible {
            showControllerTemporarily()
        } else {
            hideControllerWorkItem?.cancel()
            ambientTrackView.transform = .identity
            if ambientTrackView.isHidden {
                ambientTrackView.alpha = 0
                ambientTrackView.isHidden = false
            }
            UIView.animate(withDuration: 0.24, delay: 0, options: [.curveEaseOut], animations: {
                self.overlayView.alpha = 0
                self.ambientTrackView.alpha = 1
            }) { _ in
                if !self.isControllerVisible { self.overlayView.isHidden = true }
            }
        }
    }

    @objc private func handleBack() {
        saveProgress(forceCompleted: false, isPlayingOverride: false)
        forceShutdownPlayer()
        dismiss(animated: true)
    }

    private func triggerResolverPlayFromUserTap() {
        if directWebPlayerMode { return }
        guard let wv = resolverWebView else { return }
        let js = """
        (function(){try{
          function firePlay(doc){
            if(!doc)return;
            doc.querySelectorAll('#pl_but,.play,.btn-play,.vjs-big-play-button,.vjs-poster,.jw-icon-display,.jw-display-icon-container,.plyr__control--overlaid,.plyr__poster,[data-plyr="play"],[aria-label*="Play" i],[title*="Play" i],[class*="play-btn" i],[class*="play_btn" i],[id*="play-btn" i],button').forEach(function(b){try{b.click();}catch(e){}});
            doc.querySelectorAll('video').forEach(function(v){try{v.muted=true;v.play().catch(function(){});}catch(e){}});
            var el=doc.elementFromPoint((doc.defaultView?doc.defaultView.innerWidth:360)/2,(doc.defaultView?doc.defaultView.innerHeight:250)/2);
            if(el){try{el.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true}));el.click();}catch(e){}}
            doc.querySelectorAll('iframe').forEach(function(fr){try{if(fr.contentDocument)firePlay(fr.contentDocument);}catch(e){}});
          }
          firePlay(document);
        }catch(e){}})();
        """
        wv.evaluateJavaScript(js, completionHandler: nil)
    }

    @objc private func handlePlayPause() {
        if vlcPlayer == nil || streamUrl.isEmpty || !vlcReadyHandled {
            triggerResolverPlayFromUserTap()
            showToast("Starting stream...")
            showControllerTemporarily()
            if vlcPlayer == nil { return }
        }
        guard let vp = vlcPlayer else { return }
        let currentlyPlaying = desiredPaused.map { !$0 } ?? vp.isPlaying
        if currentlyPlaying {
            desiredPaused = true
            vp.pause()
        } else if vlcDidEnd || vp.state == .ended || vp.state == .stopped {
            desiredPaused = false
            vlcDidEnd = false
            vlcSeekPendingSec = 0
            vp.stop()
            vp.play()
        } else {
            desiredPaused = false
            vp.play()
            if abs(vp.rate - currentSpeed) > 0.01 {
                vp.rate = currentSpeed
            }
        }
        updatePlayPauseIcon()
        showControllerTemporarily()
    }

    @objc private func handleRewind10() { seekBy(-10) }
    @objc private func handleForward10() { seekBy(10) }

    private func seekBy(_ delta: Double) {
        guard vlcPlayer != nil else { return }
        let now = Date().timeIntervalSince1970
        let base = (pendingSeekTargetSec >= 0 && (now - lastSeekCommitTime) < 2.5) ? pendingSeekTargetSec : currentTimeSeconds()
        let dur = currentDurationSeconds()
        var target = max(0, base + delta)
        if dur.isFinite && dur > 0 { target = min(dur, target) }
        seekPlayer(to: target)
    }

    @objc private func onSliderStart() {
        isScrubbing = true
        hideControllerWorkItem?.cancel()
    }

    @objc private func onSliderChanged() {
        let d = currentDurationSeconds()
        if d > 0 {
            let t = Double(seekSlider.value) * d
            currentPosLabel.text = formatTime(t)
            durationLabel.text = "-\(formatTime(max(0, d - t)))"
        }
    }

    @objc private func onSliderEnd() {
        isScrubbing = false
        let d = currentDurationSeconds()
        if d > 0 {
            seekPlayer(to: Double(seekSlider.value) * d)
            saveProgress(forceCompleted: false)
        }
        showControllerTemporarily()
    }


    private func ensureOriginalAudioIos() {
        guard let vp = vlcPlayer else { return }
        if vp.audio?.isMuted == true { vp.audio?.isMuted = false }
        if let vol = vp.audio?.volume, vol < 100 { vp.audio?.volume = 100 }
        if vp.currentAudioTrackIndex == -1 {
            if let indexes = vp.audioTrackIndexes as? [Int32] {
                if let orig = indexes.first(where: { $0 >= 0 }) {
                    vp.currentAudioTrackIndex = orig
                }
            }
        }
    }

    private func applyAspectMode(_ mode: Int) {
        aspectModeIndex = mode % 3
        guard let vp = vlcPlayer else { return }
        if aspectModeIndex == 0 {
            vp.videoAspectRatio = nil
            vp.videoCropGeometry = nil
            aspectButton.setTitle("Fit", for: .normal)
            showGestureHud("Fit")
        } else if aspectModeIndex == 1 {
            let w = Int(view.bounds.width)
            let h = Int(view.bounds.height)
            let ratio = "\(max(1, w)):\(max(1, h))"
            ratio.withCString { vp.videoCropGeometry = UnsafeMutablePointer(mutating: $0) }
            vp.videoAspectRatio = nil
            aspectButton.setTitle("Fill", for: .normal)
            showGestureHud("Fill")
        } else {
            vp.videoCropGeometry = nil
            "16:9".withCString { vp.videoAspectRatio = UnsafeMutablePointer(mutating: $0) }
            aspectButton.setTitle("16:9", for: .normal)
            showGestureHud("16:9")
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.9) { [weak self] in self?.hideGestureHud() }
    }

    @objc private func cycleAspectMode() {
        applyAspectMode(aspectModeIndex + 1)
        showControllerTemporarily()
    }

    @objc private func handlePinchZoom(_ g: UIPinchGestureRecognizer) {
        guard !isScreenLocked, g.state == .ended else { return }
        if g.scale > 1.15 && aspectModeIndex != 1 {
            applyAspectMode(1)
        } else if g.scale < 0.88 && aspectModeIndex != 0 {
            applyAspectMode(0)
        }
    }

    private func showUnlockButtonTemporarily() {
        unlockHideWorkItem?.cancel()
        unlockButton.isHidden = false
        view.bringSubviewToFront(unlockButton)
        UIView.animate(withDuration: 0.18) { self.unlockButton.alpha = 1 }
        let work = DispatchWorkItem { [weak self] in
            guard let self = self, self.isScreenLocked else { return }
            UIView.animate(withDuration: 0.22, animations: { self.unlockButton.alpha = 0 }) { _ in
                if self.isScreenLocked { self.unlockButton.isHidden = true }
            }
        }
        unlockHideWorkItem = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.5, execute: work)
    }

    @objc private func toggleScreenLock() {
        isScreenLocked.toggle()
        if isScreenLocked {
            hideControllerWorkItem?.cancel()
            overlayView.isHidden = true
            overlayView.alpha = 0
            showUnlockButtonTemporarily()
            showToast("Screen Locked")
        } else {
            unlockHideWorkItem?.cancel()
            unlockButton.isHidden = true
            unlockButton.alpha = 0
            showControllerTemporarily()
            showToast("Screen Unlocked")
        }
    }

    @objc private func handleQuickSkip85() {
        seekBy(85)
        showGestureHud("+85s")
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.8) { [weak self] in self?.hideGestureHud() }
        showControllerTemporarily()
    }

    @objc private func openSleepTimerMenu() {
        let isTv = mediaType.lowercased() == "tv"
        let endLabel = isTv ? "End of Episode" : "End of Movie"
        let endShort = isTv ? "End Ep" : "End Mov"
        let endToast = isTv ? "Will pause at end of episode" : "Will pause at end of movie"
        let sheet = UIAlertController(title: "Sleep Timer", message: nil, preferredStyle: .actionSheet)
        let options: [(String, Int)] = isLiveStream
            ? [("Off", 0), ("15 min", 15), ("30 min", 30), ("45 min", 45), ("60 min", 60)]
            : [("Off", 0), ("15 min", 15), ("30 min", 30), ("45 min", 45), ("60 min", 60), (endLabel, -1)]
        for (title, mins) in options {
            sheet.addAction(UIAlertAction(title: title, style: .default) { _ in
                self.sleepTimer?.invalidate()
                self.sleepTimer = nil
                self.sleepAtEndOfEpisode = false
                if mins == 0 {
                    self.sleepButton.setTitle("Timer", for: .normal)
                    self.showToast("Sleep timer off")
                } else if mins == -1 {
                    self.sleepAtEndOfEpisode = true
                    self.sleepButton.setTitle(endShort, for: .normal)
                    self.showToast(endToast)
                } else {
                    self.sleepButton.setTitle("\(mins)m", for: .normal)
                    self.showToast("Sleep timer: \(mins) min")
                    self.sleepTimer = Timer.scheduledTimer(withTimeInterval: Double(mins * 60), repeats: false) { [weak self] _ in
                        guard let self = self else { return }
                        self.vlcPlayer?.pause()
                        self.updatePlayPauseIcon()
                        self.sleepButton.setTitle("Timer", for: .normal)
                        self.showToast("Sleep timer finished")
                    }
                }
            })
        }
        sheet.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        sheet.popoverPresentationController?.sourceView = sleepButton
        present(sheet, animated: true)
    }

    @objc private func openSubtitleStyleMenu() {
        let sheet = UIAlertController(title: "Subtitle Style", message: nil, preferredStyle: .actionSheet)
        for (lbl, sz) in [("Size: Small", 16.0), ("Size: Normal", 22.0), ("Size: Large", 28.0), ("Size: TV XL", 34.0)] {
            sheet.addAction(UIAlertAction(title: lbl, style: .default) { _ in
                self.subFontSizePt = CGFloat(sz)
                UserDefaults.standard.set(sz, forKey: "sub_pref_size")
                self.applySubtitleStyle()
                self.onSubtitleStyleChanged?(self.subTextColorHex, self.subBgStyleMode, Double(self.subFontSizePt))
            })
        }
        for (lbl, hex) in [("Color: White", "#FFFFFF"), ("Color: Yellow", "#FACC15"), ("Color: Cyan", "#38BDF8"), ("Color: Green", "#4ADE80")] {
            sheet.addAction(UIAlertAction(title: lbl, style: .default) { _ in
                self.subTextColorHex = hex
                UserDefaults.standard.set(hex, forKey: "sub_pref_color")
                self.applySubtitleStyle()
                self.onSubtitleStyleChanged?(self.subTextColorHex, self.subBgStyleMode, Double(self.subFontSizePt))
            })
        }
        for (lbl, bg) in [("BG: None", "none"), ("BG: Semi", "semi"), ("BG: Dark", "dark")] {
            sheet.addAction(UIAlertAction(title: lbl, style: .default) { _ in
                self.subBgStyleMode = bg
                UserDefaults.standard.set(bg, forKey: "sub_pref_bg")
                self.applySubtitleStyle()
                self.onSubtitleStyleChanged?(self.subTextColorHex, self.subBgStyleMode, Double(self.subFontSizePt))
            })
        }
        sheet.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        sheet.popoverPresentationController?.sourceView = subStyleButton
        present(sheet, animated: true)
    }

    @objc private func openServerPickerMenu() {
        let sheet = UIAlertController(title: "Switch Server", message: nil, preferredStyle: .actionSheet)
        let choices: [(String, String)] = [
            ("VidLink (TMDB Fast)", "vidlink"),
            ("VidSrc.cc (IMDb & TMDB)", "vidsrccc"),
            ("HnEmbed (IMDb & TMDB)", "hnembed")
        ]
        for (lbl, sid) in choices {
            let prefix = currentSource == sid ? "✓ " : ""
            sheet.addAction(UIAlertAction(title: "\(prefix)\(lbl)", style: .default) { _ in
                let curPos = self.currentTimeSeconds()
                if curPos > 5 { self.startTimeSec = curPos }
                self.vlcPollTimer?.invalidate()
                self.vlcPollTimer = nil
                self.vlcPlayer?.stop()
                self.vlcReadyHandled = false
                self.vlcDidEnd = false
                self.headerRetryStage = 0
                self.failedStreamUrls.removeAll()
                self.streamUrl = ""
                self.currentSource = sid
                self.pendingNextSource = sid
                self.activeReferer = self.buildReferer(for: sid)
                self.isSwitchingServer = true
                self.updateServerBadge(sid)
                let embed = self.buildEmbedUrl(for: sid)
                if !embed.isEmpty, let u = URL(string: embed) {
                    self.resolverWebView?.stopLoading()
                    var req = URLRequest(url: u)
                    let ref = self.buildReferer(for: sid)
                    if !ref.isEmpty { req.setValue(ref, forHTTPHeaderField: "Referer") }
                    self.resolverWebView?.load(req)
                    self.showToast("Switching to \(lbl)...")
                }
            })
        }
        sheet.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        sheet.popoverPresentationController?.sourceView = serverPickButton
        present(sheet, animated: true)
    }

    @objc private func openSpeedMenu() {
        let sheet = UIAlertController(title: "Playback Speed", message: nil, preferredStyle: .actionSheet)
        for s: Float in [0.5, 0.75, 1.0, 1.25, 1.5, 2.0, 2.5, 3.0] {
            let lbl = formatSpeedText(Double(s))
            sheet.addAction(UIAlertAction(title: lbl, style: .default) { _ in
                self.currentSpeed = s
                self.speedButton.setTitle(lbl, for: .normal)
                self.saveSeriesPrefs()
                if self.isPlayerPlaying() { self.vlcPlayer?.rate = s }
            })
        }
        sheet.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        sheet.popoverPresentationController?.sourceView = speedButton
        present(sheet, animated: true)
    }

    private func languageDisplayName(_ code: String) -> String {
        let norm = normalizeSubLang(code)
        switch norm {
        case "ar": return "Arabic"
        case "en": return "English"
        case "ko": return "Korean"
        case "ja": return "Japanese"
        case "fr": return "French"
        case "es": return "Spanish"
        case "de": return "German"
        case "tr": return "Turkish"
        case "pt": return "Portuguese"
        case "pt-br": return "Portuguese (Brazil)"
        case "it": return "Italian"
        case "ru": return "Russian"
        case "hi": return "Hindi"
        case "id": return "Indonesian"
        case "zh": return "Chinese"
        case "nl": return "Dutch"
        case "pl": return "Polish"
        case "sv": return "Swedish"
        case "th": return "Thai"
        case "vi": return "Vietnamese"
        case "fa": return "Persian"
        case "bs": return "Bosnian"
        case "bg": return "Bulgarian"
        case "hr": return "Croatian"
        case "sr": return "Serbian"
        case "cs": return "Czech"
        case "sk": return "Slovak"
        case "ro": return "Romanian"
        case "el": return "Greek"
        case "he": return "Hebrew"
        case "uk": return "Ukrainian"
        case "hu": return "Hungarian"
        case "fi": return "Finnish"
        case "da": return "Danish"
        case "no": return "Norwegian"
        case "sl": return "Slovenian"
        case "sq": return "Albanian"
        case "mk": return "Macedonian"
        case "et": return "Estonian"
        case "lv": return "Latvian"
        case "lt": return "Lithuanian"
        case "ms": return "Malay"
        case "bn": return "Bengali"
        case "ur": return "Urdu"
        case "ta": return "Tamil"
        case "te": return "Telugu"
        case "ca": return "Catalan"
        case "eu": return "Basque"
        case "gl": return "Galician"
        case "is": return "Icelandic"
        case "ka": return "Georgian"
        case "hy": return "Armenian"
        case "az": return "Azerbaijani"
        case "kk": return "Kazakh"
        case "uz": return "Uzbek"
        case "tl": return "Tagalog"
        case "fil": return "Filipino"
        case "sw": return "Swahili"
        case "af": return "Afrikaans"
        case "ml": return "Malayalam"
        case "mr": return "Marathi"
        case "kn": return "Kannada"
        case "pa": return "Punjabi"
        case "si": return "Sinhala"
        case "my": return "Burmese"
        case "km": return "Khmer"
        case "lo": return "Lao"
        case "mn": return "Mongolian"
        case "ne": return "Nepali"
        case "am": return "Amharic"
        case "ku": return "Kurdish"
        case "ps": return "Pashto"
        case "eo": return "Esperanto"
        case "ga": return "Irish"
        case "cy": return "Welsh"
        case "mt": return "Maltese"
        case "be": return "Belarusian"
        default:
            let loc = Locale(identifier: "en")
            if let name = loc.localizedString(forLanguageCode: norm), !name.isEmpty, name.lowercased() != norm.lowercased() {
                return name.prefix(1).uppercased() + name.dropFirst()
            }
            if let name = loc.localizedString(forLanguageCode: code), !name.isEmpty, name.lowercased() != code.lowercased() {
                return name.prefix(1).uppercased() + name.dropFirst()
            }
            return norm.uppercased()
        }
    }

    private func formatSyncValue(_ sec: Double) -> String {
        let ms = Int((sec * 1000.0).rounded())
        if ms == 0 { return "0.00s (0ms)" }
        let sign = ms > 0 ? "+" : ""
        return String(format: "%@%.2fs (%@%dms)", sign, sec, sign, ms)
    }

    @objc private func openSyncMenu() {
        if syncCardView.superview == nil {
            syncCardView.translatesAutoresizingMaskIntoConstraints = false
            syncCardView.backgroundColor = UIColor(red: 16/255, green: 20/255, blue: 30/255, alpha: 0.94)
            syncCardView.layer.cornerRadius = 16
            syncCardView.layer.borderWidth = 1
            syncCardView.layer.borderColor = UIColor.white.withAlphaComponent(0.16).cgColor
            view.addSubview(syncCardView)

            let titleLbl = UILabel()
            titleLbl.translatesAutoresizingMaskIntoConstraints = false
            titleLbl.text = "Subtitle Sync"
            titleLbl.textColor = .white
            titleLbl.font = .boldSystemFont(ofSize: 14)

            syncValueLabel.translatesAutoresizingMaskIntoConstraints = false
            syncValueLabel.textColor = UIColor(red: 229/255, green: 9/255, blue: 20/255, alpha: 1)
            syncValueLabel.font = .monospacedDigitSystemFont(ofSize: 13, weight: .bold)

            let earlierLbl = UILabel()
            earlierLbl.translatesAutoresizingMaskIntoConstraints = false
            earlierLbl.text = "Earlier"
            earlierLbl.textColor = UIColor.white.withAlphaComponent(0.75)
            earlierLbl.font = .systemFont(ofSize: 12, weight: .semibold)

            let minusBtn = UIButton(type: .system)
            minusBtn.translatesAutoresizingMaskIntoConstraints = false
            minusBtn.setTitle("−", for: .normal)
            minusBtn.setTitleColor(.white, for: .normal)
            minusBtn.titleLabel?.font = .boldSystemFont(ofSize: 22)
            minusBtn.backgroundColor = UIColor.white.withAlphaComponent(0.14)
            minusBtn.layer.cornerRadius = 12
            minusBtn.addTarget(self, action: #selector(stepSyncMinus), for: .touchUpInside)
            let minusHold = UILongPressGestureRecognizer(target: self, action: #selector(handleMinusLongPress(_:)))
            minusHold.minimumPressDuration = 0.25
            minusBtn.addGestureRecognizer(minusHold)

            syncCenterLabel.translatesAutoresizingMaskIntoConstraints = false
            syncCenterLabel.textColor = .white
            syncCenterLabel.textAlignment = .center
            syncCenterLabel.font = .monospacedDigitSystemFont(ofSize: 18, weight: .bold)

            let plusBtn = UIButton(type: .system)
            plusBtn.translatesAutoresizingMaskIntoConstraints = false
            plusBtn.setTitle("+", for: .normal)
            plusBtn.setTitleColor(.white, for: .normal)
            plusBtn.titleLabel?.font = .boldSystemFont(ofSize: 22)
            plusBtn.backgroundColor = UIColor.white.withAlphaComponent(0.14)
            plusBtn.layer.cornerRadius = 12
            plusBtn.addTarget(self, action: #selector(stepSyncPlus), for: .touchUpInside)
            let plusHold = UILongPressGestureRecognizer(target: self, action: #selector(handlePlusLongPress(_:)))
            plusHold.minimumPressDuration = 0.25
            plusBtn.addGestureRecognizer(plusHold)

            let laterLbl = UILabel()
            laterLbl.translatesAutoresizingMaskIntoConstraints = false
            laterLbl.text = "Later"
            laterLbl.textColor = UIColor.white.withAlphaComponent(0.75)
            laterLbl.font = .systemFont(ofSize: 12, weight: .semibold)

            let resetBtn = UIButton(type: .system)
            resetBtn.translatesAutoresizingMaskIntoConstraints = false
            resetBtn.setTitle("Reset 0.0", for: .normal)
            resetBtn.setTitleColor(.white, for: .normal)
            resetBtn.titleLabel?.font = .boldSystemFont(ofSize: 12)
            resetBtn.backgroundColor = UIColor.white.withAlphaComponent(0.12)
            resetBtn.layer.cornerRadius = 8
            resetBtn.contentEdgeInsets = UIEdgeInsets(top: 5, left: 10, bottom: 5, right: 10)
            resetBtn.addTarget(self, action: #selector(resetSyncSlider), for: .touchUpInside)

            let doneBtn = UIButton(type: .system)
            doneBtn.translatesAutoresizingMaskIntoConstraints = false
            doneBtn.setTitle("Done", for: .normal)
            doneBtn.setTitleColor(.white, for: .normal)
            doneBtn.titleLabel?.font = .boldSystemFont(ofSize: 12)
            doneBtn.backgroundColor = UIColor(red: 229/255, green: 9/255, blue: 20/255, alpha: 1)
            doneBtn.layer.cornerRadius = 8
            doneBtn.contentEdgeInsets = UIEdgeInsets(top: 5, left: 12, bottom: 5, right: 12)
            doneBtn.addTarget(self, action: #selector(closeSyncCard), for: .touchUpInside)

            syncCardView.addSubview(titleLbl)
            syncCardView.addSubview(syncValueLabel)
            syncCardView.addSubview(earlierLbl)
            syncCardView.addSubview(minusBtn)
            syncCardView.addSubview(syncCenterLabel)
            syncCardView.addSubview(plusBtn)
            syncCardView.addSubview(laterLbl)
            syncCardView.addSubview(resetBtn)
            syncCardView.addSubview(doneBtn)

            NSLayoutConstraint.activate([
                syncCardView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
                syncCardView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -92),
                syncCardView.widthAnchor.constraint(equalToConstant: 360),

                titleLbl.topAnchor.constraint(equalTo: syncCardView.topAnchor, constant: 14),
                titleLbl.leadingAnchor.constraint(equalTo: syncCardView.leadingAnchor, constant: 16),

                syncValueLabel.centerYAnchor.constraint(equalTo: titleLbl.centerYAnchor),
                syncValueLabel.trailingAnchor.constraint(equalTo: syncCardView.trailingAnchor, constant: -16),

                syncCenterLabel.topAnchor.constraint(equalTo: titleLbl.bottomAnchor, constant: 18),
                syncCenterLabel.centerXAnchor.constraint(equalTo: syncCardView.centerXAnchor),
                syncCenterLabel.widthAnchor.constraint(equalToConstant: 82),

                minusBtn.centerYAnchor.constraint(equalTo: syncCenterLabel.centerYAnchor),
                minusBtn.trailingAnchor.constraint(equalTo: syncCenterLabel.leadingAnchor, constant: -10),
                minusBtn.widthAnchor.constraint(equalToConstant: 46),
                minusBtn.heightAnchor.constraint(equalToConstant: 42),

                earlierLbl.centerYAnchor.constraint(equalTo: syncCenterLabel.centerYAnchor),
                earlierLbl.trailingAnchor.constraint(equalTo: minusBtn.leadingAnchor, constant: -8),

                plusBtn.centerYAnchor.constraint(equalTo: syncCenterLabel.centerYAnchor),
                plusBtn.leadingAnchor.constraint(equalTo: syncCenterLabel.trailingAnchor, constant: 10),
                plusBtn.widthAnchor.constraint(equalToConstant: 46),
                plusBtn.heightAnchor.constraint(equalToConstant: 42),

                laterLbl.centerYAnchor.constraint(equalTo: syncCenterLabel.centerYAnchor),
                laterLbl.leadingAnchor.constraint(equalTo: plusBtn.trailingAnchor, constant: 8),

                resetBtn.topAnchor.constraint(equalTo: syncCenterLabel.bottomAnchor, constant: 18),
                resetBtn.leadingAnchor.constraint(equalTo: syncCardView.leadingAnchor, constant: 16),
                resetBtn.bottomAnchor.constraint(equalTo: syncCardView.bottomAnchor, constant: -14),

                doneBtn.centerYAnchor.constraint(equalTo: resetBtn.centerYAnchor),
                doneBtn.trailingAnchor.constraint(equalTo: syncCardView.trailingAnchor, constant: -16)
            ])
        }
        refreshSyncUi()
        syncCardView.isHidden = false
        view.bringSubviewToFront(syncCardView)
    }

    private func refreshSyncUi() {
        let sign = subDelaySec > 0.001 ? "+" : ""
        syncCenterLabel.text = String(format: "%@%.1fs", sign, subDelaySec)
        syncValueLabel.text = formatSyncValue(subDelaySec)
        syncButton.setTitle(String(format: "Sync %@%.1fs", sign, subDelaySec), for: .normal)
        updateTimeAndSubtitles()
    }

    private func adjustSync(by delta: Double) {
        subDelaySec = ((subDelaySec + delta) * 10.0).rounded() / 10.0
        refreshSyncUi()
    }

    @objc private func stepSyncMinus() { adjustSync(by: -0.1) }
    @objc private func stepSyncPlus() { adjustSync(by: 0.1) }

    @objc private func handleMinusLongPress(_ g: UILongPressGestureRecognizer) {
        if g.state == .began {
            syncRepeatTimer?.invalidate()
            syncRepeatTimer = Timer.scheduledTimer(withTimeInterval: 0.07, repeats: true) { [weak self] _ in
                self?.adjustSync(by: -0.1)
            }
        } else if g.state == .ended || g.state == .cancelled || g.state == .failed {
            syncRepeatTimer?.invalidate()
            syncRepeatTimer = nil
        }
    }

    @objc private func handlePlusLongPress(_ g: UILongPressGestureRecognizer) {
        if g.state == .began {
            syncRepeatTimer?.invalidate()
            syncRepeatTimer = Timer.scheduledTimer(withTimeInterval: 0.07, repeats: true) { [weak self] _ in
                self?.adjustSync(by: 0.1)
            }
        } else if g.state == .ended || g.state == .cancelled || g.state == .failed {
            syncRepeatTimer?.invalidate()
            syncRepeatTimer = nil
        }
    }

    @objc private func resetSyncSlider() {
        subDelaySec = 0.0
        refreshSyncUi()
    }

    @objc private func closeSyncCard() {
        syncRepeatTimer?.invalidate()
        syncRepeatTimer = nil
        syncCardView.isHidden = true
    }

    @objc private func openSubtitleMenu() {
        let sheet = UIAlertController(title: "Subtitles", message: nil, preferredStyle: .actionSheet)
        sheet.addAction(UIAlertAction(title: "Off", style: .default) { _ in
            self.usingNativeHlsSubtitle = false
            self.activeSubIndex = -1
            self.activeCues = []
            self.rawActiveCues = []
            self.subtitleLabel.isHidden = true
            self.vlcPlayer?.currentVideoSubTitleIndex = -1
        })
        for hlsOpt in hlsLegibleOptions {
            let label = "\(languageDisplayName(hlsOpt.lang)) (Stream)"
            sheet.addAction(UIAlertAction(title: label, style: .default) { _ in
                self.usingNativeHlsSubtitle = false
                self.vlcPlayer?.currentVideoSubTitleIndex = -1
            })
        }
        var langCounts: [String: Int] = [:]
        for (idx, sub) in availableSubs.enumerated() {
            let num = (langCounts[sub.lang] ?? 0) + 1
            langCounts[sub.lang] = num
            let langName = languageDisplayName(sub.lang)
            let prefix = (!usingNativeHlsSubtitle && idx == activeSubIndex) ? "✓ " : ""
            sheet.addAction(UIAlertAction(title: "\(prefix)\(langName) #\(num)", style: .default) { _ in
                self.usingNativeHlsSubtitle = false
                self.vlcPlayer?.currentVideoSubTitleIndex = -1
                self.activeSubIndex = idx
                self.activeSubIsStreamNative = sub.score >= 150
                self.loadSubtitleFile(url: sub.url)
            })
        }
        sheet.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        sheet.popoverPresentationController?.sourceView = subButton
        present(sheet, animated: true)
    }

    @objc private func togglePip() {
        showToast("PiP unavailable with VLC engine")
    }

    private func normalizeSubLang(_ raw: String) -> String {
        let full = raw.trimmingCharacters(in: .whitespacesAndNewlines).lowercased().replacingOccurrences(of: "_", with: "-")
        if full == "pt-br" || full == "pob" || full == "pb" || full == "portuguese (brazil)" { return "pt-br" }
        let c = full.components(separatedBy: "-").first ?? "en"
        switch c {
        case "ara", "arabic", "ar": return "ar"
        case "eng", "english", "en": return "en"
        case "kor", "korean", "ko": return "ko"
        case "jpn", "japanese", "ja": return "ja"
        case "fre", "fra", "french", "fr": return "fr"
        case "spa", "spanish", "es": return "es"
        case "ger", "deu", "german", "de": return "de"
        case "tur", "turkish", "tr": return "tr"
        case "por", "portuguese", "pt": return "pt"
        case "pob", "pb": return "pt-br"
        case "ita", "italian", "it": return "it"
        case "rus", "russian", "ru": return "ru"
        case "hin", "hindi", "hi": return "hi"
        case "ind", "indonesian", "id": return "id"
        case "chi", "zho", "chinese", "zh", "zht", "zhs": return "zh"
        case "dut", "nld", "dutch", "nl": return "nl"
        case "pol", "polish", "pl": return "pl"
        case "swe", "swedish", "sv": return "sv"
        case "tha", "thai", "th": return "th"
        case "vie", "vietnamese", "vi": return "vi"
        case "per", "fas", "persian", "fa": return "fa"
        case "bos", "bosnian", "bs": return "bs"
        case "bul", "bulgarian", "bg": return "bg"
        case "hrv", "scr", "croatian", "hr": return "hr"
        case "srp", "scc", "serbian", "sr": return "sr"
        case "ces", "cze", "czech", "cs": return "cs"
        case "slk", "slo", "slovak", "sk": return "sk"
        case "ron", "rum", "romanian", "ro": return "ro"
        case "ell", "gre", "greek", "el": return "el"
        case "heb", "hebrew", "he", "iw": return "he"
        case "ukr", "ukrainian", "uk": return "uk"
        case "hun", "hungarian", "hu": return "hu"
        case "fin", "finnish", "fi": return "fi"
        case "dan", "danish", "da": return "da"
        case "nor", "nob", "nno", "norwegian", "no": return "no"
        case "slv", "slovenian", "sl": return "sl"
        case "alb", "sqi", "albanian", "sq": return "sq"
        case "mac", "mkd", "macedonian", "mk": return "mk"
        case "est", "estonian", "et": return "et"
        case "lav", "latvian", "lv": return "lv"
        case "lit", "lithuanian", "lt": return "lt"
        case "may", "msa", "malay", "ms": return "ms"
        case "ben", "bengali", "bn": return "bn"
        case "urd", "urdu", "ur": return "ur"
        case "tam", "tamil", "ta": return "ta"
        case "tel", "telugu", "te": return "te"
        case "cat", "catalan", "ca": return "ca"
        case "baq", "eus", "basque", "eu": return "eu"
        case "glg", "galician", "gl": return "gl"
        case "ice", "isl", "icelandic", "is": return "is"
        case "geo", "kat", "georgian", "ka": return "ka"
        case "arm", "hye", "armenian", "hy": return "hy"
        case "aze", "azerbaijani", "az": return "az"
        case "kaz", "kazakh", "kk": return "kk"
        case "uzb", "uzbek", "uz": return "uz"
        case "tgl", "tagalog", "tl": return "tl"
        case "fil", "filipino": return "fil"
        case "swa", "swahili", "sw": return "sw"
        case "afr", "afrikaans", "af": return "af"
        case "mal", "malayalam", "ml": return "ml"
        case "mar", "marathi", "mr": return "mr"
        case "kan", "kannada", "kn": return "kn"
        case "pan", "punjabi", "pa": return "pa"
        case "sin", "sinhala", "si": return "si"
        case "bur", "mya", "burmese", "my": return "my"
        case "khm", "khmer", "km": return "km"
        case "lao", "la": return "lo"
        case "mon", "mongolian", "mn": return "mn"
        case "nep", "nepali", "ne": return "ne"
        case "amh", "amharic", "am": return "am"
        case "kur", "kurdish", "ku": return "ku"
        case "pus", "pashto", "ps": return "ps"
        case "epo", "esperanto", "eo": return "eo"
        case "gle", "irish", "ga": return "ga"
        case "wel", "cym", "welsh", "cy": return "cy"
        case "mlt", "maltese", "mt": return "mt"
        case "bel", "belarusian", "be": return "be"
        default: return c.isEmpty ? "en" : c
        }
    }

    private func scoreRelease(_ name: String) -> (Int, Bool) {
        let l = name.lowercased()
        var score = 40
        var syncMatch = false
        let h = activeReleaseHint
        let isBdStream = h.contains("bdrip") || h.contains("brrip") || h.contains("bluray") || h.contains("xvid")
        let isBdSub = l.contains("bdrip") || l.contains("brrip") || l.contains("bluray")
        let isWebSub = l.contains("web-dl") || l.contains("webrip") || l.contains("web.")
        if isBdStream && isBdSub {
            score += 75
            syncMatch = true
        } else if !isBdStream && isWebSub {
            score += 55
            syncMatch = true
        } else if isBdSub || isWebSub || l.contains("1080p") || l.contains("720p") {
            score += 35
            syncMatch = true
        }
        if l.contains("cam") || l.contains("ts") || l.contains("hdcam") {
            score -= 20
        }
        return (score, syncMatch)
    }

    private func mergeSubtitleTracks(_ tracks: [IosSubTrack]) {
        if tracks.isEmpty { return }
        DispatchQueue.main.async {
            let activeUrl = (self.activeSubIndex >= 0 && self.activeSubIndex < self.availableSubs.count)
                ? self.availableSubs[self.activeSubIndex].url : nil
            var byUrl: [String: IosSubTrack] = [:]
            for t in self.availableSubs { byUrl[t.url] = t }
            for t in tracks {
                if let ex = byUrl[t.url] {
                    if t.score > ex.score { byUrl[t.url] = t }
                } else {
                    byUrl[t.url] = t
                }
            }
            var byLang: [String: [IosSubTrack]] = [:]
            for t in byUrl.values {
                byLang[t.lang, default: []].append(t)
            }
            var merged: [IosSubTrack] = []
            for (_, list) in byLang {
                let sortedList = list.sorted { $0.score > $1.score }
                merged.append(contentsOf: sortedList)
            }
            merged.sort { a, b in
                let aRank = a.lang == self.preferredLang ? 0 : (a.lang == "ar" ? 1 : (a.lang == "en" ? 2 : 3))
                let bRank = b.lang == self.preferredLang ? 0 : (b.lang == "ar" ? 1 : (b.lang == "en" ? 2 : 3))
                if aRank != bRank { return aRank < bRank }
                if a.lang != b.lang { return a.lang < b.lang }
                return a.score > b.score
            }
            let upgradedActiveUrl: String? = nil
            self.availableSubs = merged
            self.subButton.setTitle("Subtitles (\(self.availableSubs.count))", for: .normal)
            if let upUrl = upgradedActiveUrl, let idx = self.availableSubs.firstIndex(where: { $0.url == upUrl }) {
                self.activeSubIndex = idx
                self.activeSubIsStreamNative = self.availableSubs[idx].score >= 150
                self.loadSubtitleFile(url: upUrl)
            } else if let aUrl = activeUrl, let idx = self.availableSubs.firstIndex(where: { $0.url == aUrl }) {
                self.activeSubIndex = idx
            } else if self.activeSubIndex == -1, let firstPref = self.availableSubs.firstIndex(where: { $0.lang == self.preferredLang || $0.lang == "ar" }) {
                self.activeSubIndex = firstPref
                self.activeSubIsStreamNative = self.availableSubs[firstPref].score >= 150
                self.loadSubtitleFile(url: self.availableSubs[firstPref].url)
            }
        }
    }

    private func applySmartAutoSync(to cues: [IosSubCue]) -> [IosSubCue] {
        return cues.filter { cue in
            let lc = cue.text.lowercased()
            return !lc.contains("osdb.link") && !lc.contains("opensubtitles") && !lc.contains("subscene") && !lc.contains("advertise your product")
        }
    }

    func legibleOutput(_ output: AVPlayerItemLegibleOutput, didOutputAttributedStrings strings: [NSAttributedString], nativeSampleBuffers: [Any], forItemTime itemTime: CMTime) {
        guard usingNativeHlsSubtitle else { return }
        let text = strings.map { $0.string.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }.joined(separator: "\n")
        if text.isEmpty {
            subtitleLabel.isHidden = true
        } else {
            subtitleLabel.text = text
            subtitleLabel.isHidden = false
        }
    }

    private func isSubtitleMatchingCurrentEpisode(_ relName: String, seasonField: String = "", episodeField: String = "", kindField: String = "", requireExplicitOnTv: Bool = false) -> Bool {
        let isTv = mediaType.lowercased() == "tv"
        let sInt = Int(seasonField.trimmingCharacters(in: .whitespacesAndNewlines)) ?? 0
        let eInt = Int(episodeField.trimmingCharacters(in: .whitespacesAndNewlines)) ?? 0
        let kTrim = kindField.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        let hasExactFields = isTv && sInt > 0 && eInt > 0
        if isTv {
            if sInt > 0 && sInt != seasonNum { return false }
            if eInt > 0 && eInt != episodeNum { return false }
        } else {
            if kTrim == "episode" { return false }
            if sInt > 0 || eInt > 0 { return false }
        }
        let l = relName.lowercased()
        if l.isEmpty {
            return isTv ? (hasExactFields || !requireExplicitOnTv) : true
        }
        if let regex = try? NSRegularExpression(pattern: "(?:s(\\d{1,2})[\\s._-]*e(\\d{1,2})|\\b(\\d{1,2})x(\\d{1,2})\\b)") {
            let range = NSRange(l.startIndex..<l.endIndex, in: l)
            let matches = regex.matches(in: l, range: range)
            if !matches.isEmpty {
                if !isTv { return false }
                var foundMatch = false
                for m in matches {
                    let sRange = m.range(at: 1).location != NSNotFound ? m.range(at: 1) : m.range(at: 3)
                    let eRange = m.range(at: 2).location != NSNotFound ? m.range(at: 2) : m.range(at: 4)
                    if let sr = Range(sRange, in: l), let er = Range(eRange, in: l),
                       let sVal = Int(l[sr]), let eVal = Int(l[er]) {
                        if sVal == seasonNum && eVal == episodeNum {
                            foundMatch = true
                            break
                        }
                    }
                }
                return foundMatch
            }
        }
        if isTv {
            if l.contains("complete") || l.contains("season pack") || l.contains("full season") {
                return false
            }
            if let epOnly = try? NSRegularExpression(pattern: "(?:\\bepisode[\\s._-]*(\\d{1,2})\\b|\\bep[\\s._-]*(\\d{1,2})\\b|\\be(\\d{1,2})\\b)") {
                let range = NSRange(l.startIndex..<l.endIndex, in: l)
                let epMatches = epOnly.matches(in: l, range: range)
                if !epMatches.isEmpty {
                    var foundEp = false
                    for m in epMatches {
                        let r = m.range(at: 1).location != NSNotFound ? m.range(at: 1) : (m.range(at: 2).location != NSNotFound ? m.range(at: 2) : m.range(at: 3))
                        if let er = Range(r, in: l), let eVal = Int(l[er]), eVal == episodeNum {
                            foundEp = true
                            break
                        }
                    }
                    if !foundEp { return false }
                    return true
                }
            }
            if requireExplicitOnTv && !hasExactFields {
                return false
            }
        }
        return true
    }

    private func fetchSubtitlesInBackground() {
        let isTv = mediaType.lowercased() == "tv"
        let wyzieId = !tmdbId.isEmpty ? tmdbId : imdbId
        if !wyzieId.isEmpty {
            let wyzieStr = isTv
                ? "https://sub.wyzie.ru/search?id=\(wyzieId)&season=\(seasonNum)&episode=\(episodeNum)"
                : "https://sub.wyzie.ru/search?id=\(wyzieId)"
            if let wu = URL(string: wyzieStr) {
                var wreq = URLRequest(url: wu)
                wreq.setValue("SingularityTV/3.0", forHTTPHeaderField: "User-Agent")
                URLSession.shared.dataTask(with: wreq) { [weak self] data, _, _ in
                    guard let self = self, let data = data,
                          let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { return }
                    var added: [IosSubTrack] = []
                    for item in arr.prefix(200) {
                        guard let subUrl = item["url"] as? String, !subUrl.isEmpty else { continue }
                        let rawLang = (item["language"] as? String) ?? (item["display"] as? String) ?? "en"
                        let lang = self.normalizeSubLang(rawLang)
                        added.append(IosSubTrack(lang: lang, url: subUrl, score: 85, syncMatch: true))
                    }
                    self.mergeSubtitleTracks(added)
                }.resume()
            }
        }
        guard imdbId.hasPrefix("tt") else { return }
        let osType = isTv ? "series" : "movie"
        let osTarget = isTv ? "\(imdbId):\(seasonNum):\(episodeNum)" : imdbId

        if let encoded = osTarget.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) {
            let stremioBases = [
                "https://opensubtitles-v3.strem.io/subtitles/\(osType)/\(encoded).json"
            ]
            for baseStr in stremioBases {
                guard let osUrl = URL(string: baseStr) else { continue }
                var req = URLRequest(url: osUrl)
                req.setValue("SingularityTV/2.7.3", forHTTPHeaderField: "User-Agent")
                URLSession.shared.dataTask(with: req) { [weak self] data, _, _ in
                    guard let self = self, let data = data,
                          let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                          let arr = root["subtitles"] as? [[String: Any]] else { return }
                    var added: [IosSubTrack] = []
                    for item in arr.prefix(300) {
                        guard let subUrl = item["url"] as? String, !subUrl.isEmpty else { continue }
                        let relHint = [
                            item["SubFileName"] as? String,
                            item["title"] as? String,
                            item["name"] as? String,
                            item["release"] as? String,
                            item["id"] as? String,
                            subUrl
                        ].compactMap { $0 }.joined(separator: " ")
                        if !self.isSubtitleMatchingCurrentEpisode(relHint) { continue }
                        let lang = self.normalizeSubLang(item["lang"] as? String ?? "en")
                        added.append(IosSubTrack(lang: lang, url: subUrl, score: 75, syncMatch: true))
                    }
                    self.mergeSubtitleTracks(added)
                }.resume()
            }
        }

        let numericImdb = imdbId.replacingOccurrences(of: "tt", with: "")
        if !numericImdb.isEmpty {
            let worldLangs = ["ara", "eng", "spa", "fre", "ger", "tur", "por", "ita", "rus", "jpn", "kor", "hin", "all"]
            for wLang in worldLangs {
                let restStr = isTv
                    ? "https://rest.opensubtitles.org/search/episode-\(episodeNum)/imdbid-\(numericImdb)/season-\(seasonNum)/sublanguageid-\(wLang)"
                    : "https://rest.opensubtitles.org/search/imdbid-\(numericImdb)/sublanguageid-\(wLang)"
                guard let ru = URL(string: restStr) else { continue }
                var rreq = URLRequest(url: ru)
                rreq.setValue("TemporaryUserAgent", forHTTPHeaderField: "X-User-Agent")
                rreq.setValue("TemporaryUserAgent", forHTTPHeaderField: "User-Agent")
                URLSession.shared.dataTask(with: rreq) { [weak self] data, _, _ in
                    guard let self = self, let data = data,
                          let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { return }
                    var added: [IosSubTrack] = []
                    for item in arr.prefix(60) {
                        let rawDl = (item["SubDownloadLink"] as? String) ?? ""
                        if rawDl.isEmpty { continue }
                        let dlUrl = rawDl.replacingOccurrences(of: ".gz", with: "")
                        let iso = (item["ISO639"] as? String) ?? (item["SubLanguageID"] as? String) ?? "en"
                        let lang = self.normalizeSubLang(iso)
                        let relName = (item["MovieReleaseName"] as? String) ?? (item["SubFileName"] as? String) ?? ""
                        let itemImdb = String(describing: item["IDMovieImdb"] ?? "").replacingOccurrences(of: "tt", with: "").trimmingCharacters(in: .whitespacesAndNewlines)
                        let parentImdb = String(describing: item["SeriesIMDBParent"] ?? "").replacingOccurrences(of: "tt", with: "").trimmingCharacters(in: .whitespacesAndNewlines)
                        let cleanNum = numericImdb.trimmingCharacters(in: CharacterSet(charactersIn: "0"))
                        if !isTv && !itemImdb.isEmpty && itemImdb != "0" {
                            let cleanItem = itemImdb.trimmingCharacters(in: CharacterSet(charactersIn: "0"))
                            if !cleanItem.isEmpty && cleanItem != cleanNum { continue }
                        }
                        if isTv && !parentImdb.isEmpty && parentImdb != "0" {
                            let cleanParent = parentImdb.trimmingCharacters(in: CharacterSet(charactersIn: "0"))
                            if !cleanParent.isEmpty && cleanParent != cleanNum { continue }
                        }
                        let sField = String(describing: item["SeriesSeason"] ?? "")
                        let eField = String(describing: item["SeriesEpisode"] ?? "")
                        let kField = (item["MovieKind"] as? String) ?? ""
                        if !self.isSubtitleMatchingCurrentEpisode(relName, seasonField: sField, episodeField: eField, kindField: kField, requireExplicitOnTv: true) { continue }
                        let (sc, sm) = self.scoreRelease(relName)
                        added.append(IosSubTrack(lang: lang, url: dlUrl, score: sc + 20, syncMatch: sm))
                    }
                    self.mergeSubtitleTracks(added)
                }.resume()
            }
        }
    }

    private func decodeSubtitleData(_ data: Data) -> String? {
        if let utf8 = String(data: data, encoding: .utf8) {
            return utf8
        }
        let cp1256 = String.Encoding(rawValue: CFStringConvertEncodingToNSStringEncoding(CFStringEncoding(0x0506)))
        if let ar = String(data: data, encoding: cp1256) {
            return ar
        }
        if let latin = String(data: data, encoding: .isoLatin1) {
            return latin
        }
        return nil
    }

    private func loadSubtitleFile(url: String) {
        guard let u = URL(string: url) else { return }
        var req = URLRequest(url: u)
        req.setValue("SingularityTV/2.7.3", forHTTPHeaderField: "User-Agent")
        URLSession.shared.dataTask(with: req) { [weak self] data, _, _ in
            guard let self = self, let data = data, let text = self.decodeSubtitleData(data) else { return }
            let parsed = self.parseSrtOrVtt(text)
            DispatchQueue.main.async {
                self.rawActiveCues = parsed
                self.activeCues = self.applySmartAutoSync(to: parsed)
                self.autoDetectSegmentsFromStreamAndCues()
                self.updateTimeAndSubtitles()
            }
        }.resume()
    }

    private func parseSrtOrVtt(_ raw: String) -> [IosSubCue] {
        var cues: [IosSubCue] = []
        let cleaned = raw
            .replacingOccurrences(of: "\u{FEFF}", with: "")
            .replacingOccurrences(of: "\r\n", with: "\n")
            .replacingOccurrences(of: "\r", with: "\n")
        let lines = cleaned.components(separatedBy: "\n")
        var i = 0
        while i < lines.count {
            let line = lines[i].trimmingCharacters(in: .whitespaces)
            if line.contains("-->") {
                let parts = line.components(separatedBy: "-->")
                if parts.count >= 2 {
                    let startStr = parts[0].trimmingCharacters(in: .whitespaces).components(separatedBy: " ").first ?? parts[0]
                    let endStr = parts[1].trimmingCharacters(in: .whitespaces).components(separatedBy: " ").first ?? parts[1]
                    let start = parseTimestamp(startStr)
                    let end = parseTimestamp(endStr)
                    var bodyLines: [String] = []
                    var j = i + 1
                    while j < lines.count {
                        let nextLine = lines[j].trimmingCharacters(in: .whitespaces)
                        if nextLine.isEmpty || nextLine.contains("-->") { break }
                        bodyLines.append(nextLine)
                        j += 1
                    }
                    let body = bodyLines.joined(separator: "\n")
                        .replacingOccurrences(of: "<[^>]+>|\\{[^}]+\\}", with: "", options: .regularExpression)
                        .trimmingCharacters(in: .whitespacesAndNewlines)
                    if !body.isEmpty && end > start {
                        cues.append(IosSubCue(startSec: start, endSec: end, text: body))
                    }
                    i = j
                    continue
                }
            }
            i += 1
        }
        return cues
    }

    private func parseTimestamp(_ raw: String) -> Double {
        let clean = raw.trimmingCharacters(in: .whitespaces).replacingOccurrences(of: ",", with: ".")
        let comps = clean.components(separatedBy: ":")
        if comps.count == 3 {
            return (Double(comps[0]) ?? 0) * 3600 + (Double(comps[1]) ?? 0) * 60 + (Double(comps[2]) ?? 0)
        } else if comps.count == 2 {
            return (Double(comps[0]) ?? 0) * 60 + (Double(comps[1]) ?? 0)
        }
        return Double(clean) ?? 0
    }

    private func saveProgress(forceCompleted: Bool, isPlayingOverride: Bool? = nil) {
        guard !progressKey.isEmpty else { return }
        let playingNow = isPlayingOverride ?? (isPlayerPlaying() && !forceCompleted)
        let pos = currentTimeSeconds()
        let dur = currentDurationSeconds()
        if !forceCompleted && (!pos.isFinite || !dur.isFinite || dur <= 0 || !hasRealPlaybackProgress || vlcSeekPendingSec > 0) {
            return
        }
        if !pos.isFinite || !dur.isFinite || dur <= 0 {
            onProgressUpdate?(progressKey, 100, max(0, Int(pos.isFinite ? pos : 0)), 0, true, false)
            return
        }
        let rawPct = Int((pos / dur) * 100)
        let pct = forceCompleted ? 100 : min(100, max(1, rawPct))
        let watched = forceCompleted || pct >= 92 || (dur - pos <= 45)
        onProgressUpdate?(progressKey, pct, Int(pos), Int(dur), watched, playingNow)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        if directWebPlayerMode { return }
        if isScreenLocked { showUnlockButtonTemporarily(); return }
        guard let touch = touches.first else { return }
        gestureMode = 0
        gestureStartPoint = touch.location(in: view)
        swipeSeekBaseSec = currentTimeSeconds()
        if !swipeSeekBaseSec.isFinite { swipeSeekBaseSec = 0 }
        swipeSeekTargetSec = swipeSeekBaseSec
        hold2xWorkItem?.cancel()
        let holdItem = DispatchWorkItem { [weak self] in
            guard let self = self, self.gestureMode == 0, !self.isCaptchaVisible, let pl = self.vlcPlayer else { return }
            self.gestureMode = 4
            self.hold2xStartX = self.gestureStartPoint.x
            self.hold2xSavedRate = pl.isPlaying ? pl.rate : self.currentSpeed
            self.hold2xWasPlaying = pl.isPlaying
            self.singleTapWorkItem?.cancel()
            if !pl.isPlaying { pl.play() }
            pl.rate = 2.0
            self.vlcLastHoldSpeed = 2.0
            self.showGestureHud(self.formatSpeedText(2.0), symbolName: "forward.fill")
        }
        hold2xWorkItem = holdItem
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.36, execute: holdItem)
        if gestureStartPoint.x < view.bounds.width * 0.5 {
            gestureStartVal = UIScreen.main.brightness
        } else {
            gestureStartVal = CGFloat(AVAudioSession.sharedInstance().outputVolume)
        }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        if directWebPlayerMode { return }
        if isScreenLocked { return }
        guard let touch = touches.first else { return }
        let p = touch.location(in: view)
        let w = max(1, view.bounds.width)
        let h = max(1, view.bounds.height)
        let dx = p.x - gestureStartPoint.x
        let dy = gestureStartPoint.y - p.y
        if hypot(dx, dy) > 16 {
            hold2xWorkItem?.cancel()
        }
        if gestureMode == 4 {
            if let pl = vlcPlayer {
                let hdx = p.x - hold2xStartX
                let rawVal = 2.0 + Double(hdx / (w * 0.30))
                let sp = (min(3.0, max(1.0, rawVal)) * 10.0).rounded() / 10.0
                let spF = Float(sp)
                if abs(spF - vlcLastHoldSpeed) >= 0.05 {
                    vlcLastHoldSpeed = spF
                    pl.rate = spF
                }
                showGestureHud(formatSpeedText(sp), symbolName: "forward.fill")
            }
            return
        }
        let inSafeY = gestureStartPoint.y >= h * 0.14 && gestureStartPoint.y <= h * 0.84
        let inLeft = gestureStartPoint.x >= 20 && gestureStartPoint.x <= w * 0.24
        let inRight = gestureStartPoint.x >= w * 0.76 && gestureStartPoint.x <= w - 20

        if gestureMode == 0 && inSafeY && (inLeft || inRight) && abs(dy) > 20 && abs(dy) > abs(dx) * 1.25 {
            gestureMode = inLeft ? 1 : 2
        } else if gestureMode == 0 && abs(dx) > 22 && abs(dx) > abs(dy) * 1.35 {
            gestureMode = 3
            swipeSeekBaseSec = currentTimeSeconds()
            if !swipeSeekBaseSec.isFinite { swipeSeekBaseSec = 0 }
            swipeSeekTargetSec = swipeSeekBaseSec
        }
        if gestureMode == 3 {
            let dur = currentDurationSeconds()
            let validDur = (dur.isFinite && dur > 0) ? dur : 0
            let deltaSec = Double(dx / w) * 150.0
            var target = max(0, swipeSeekBaseSec + deltaSec)
            if validDur > 0 { target = min(validDur, target) }
            swipeSeekTargetSec = target
            let actualDelta = Int(target - swipeSeekBaseSec)
            let sign = actualDelta >= 0 ? "+" : ""
            showGestureHud("\(formatTime(target)) (\(sign)\(actualDelta)s)")
            if validDur > 0 {
                let frac = min(1.0, max(0.0, target / validDur))
                seekSlider.value = Float(frac)
                ambientFillWidthConstraint?.constant = view.bounds.width * CGFloat(frac)
                currentPosLabel.text = formatTime(target)
                durationLabel.text = "-\(formatTime(max(0, validDur - target)))"
            }
        } else if gestureMode == 1 || gestureMode == 2 {
            let nextVal = min(1, max(0, gestureStartVal + dy / (h * 0.6)))
            hideHudWorkItem?.cancel()
            if gestureMode == 1 {
                UIScreen.main.brightness = max(0.04, nextVal)
                brightnessPctLabel.text = "\(Int(nextVal * 100))%"
                brightnessHudView.isHidden = false
                let trackH = brightnessTrackView.bounds.height > 10 ? brightnessTrackView.bounds.height : 128
                brightnessFillHeightConstraint?.constant = max(2, trackH * nextVal)
                brightnessHudView.layoutIfNeeded()
            } else {
                if let slider = hiddenVolumeView.subviews.compactMap({ $0 as? UISlider }).first {
                    slider.value = Float(nextVal)
                }
                volumePctLabel.text = "\(Int(nextVal * 100))%"
                volumeHudView.isHidden = false
                let trackH = volumeTrackView.bounds.height > 10 ? volumeTrackView.bounds.height : 128
                volumeFillHeightConstraint?.constant = max(2, trackH * nextVal)
                volumeHudView.layoutIfNeeded()
            }
            let item = DispatchWorkItem { [weak self] in
                self?.brightnessHudView.isHidden = true
                self?.volumeHudView.isHidden = true
            }
            hideHudWorkItem = item
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.9, execute: item)
        }
    }

    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        hold2xWorkItem?.cancel()
        if gestureMode == 4 {
            endHold2xGesture()
        } else if gestureMode == 3 {
            gestureMode = 0
            hideGestureHud()
        } else {
            gestureMode = 0
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if directWebPlayerMode { return }
        hold2xWorkItem?.cancel()
        if gestureMode == 4 {
            endHold2xGesture()
            return
        }
        if gestureMode == 3 {
            gestureMode = 0
            seekPlayer(to: swipeSeekTargetSec)
            hideGestureHud()
            updateTimeAndSubtitles()
            return
        }
        if gestureMode != 0 {
            gestureMode = 0
            return
        }
        guard let touch = touches.first else { return }
        let p = touch.location(in: view)
        let dist = hypot(p.x - gestureStartPoint.x, p.y - gestureStartPoint.y)
        if dist > 18 { return }

        let now = Date().timeIntervalSince1970
        let w = view.bounds.width
        let tapSide = p.x < w * 0.42 ? -1 : (p.x > w * 0.58 ? 1 : 0)

        if tapSide != 0 && activeSeekSide == tapSide && (now - lastSeekEventTime) < 1.25 {
            singleTapWorkItem?.cancel()
            triggerMultiTapSeek(side: tapSide)
        } else if tapSide != 0 && tapSide == lastTapSide && (now - lastTapTime) < 0.52 {
            singleTapWorkItem?.cancel()
            lastTapTime = 0
            triggerMultiTapSeek(side: tapSide)
        } else if tapSide == 0 {
            singleTapWorkItem?.cancel()
            lastTapTime = 0
            lastTapSide = 0
            setControllerVisible(!isControllerVisible)
        } else {
            lastTapTime = now
            lastTapSide = tapSide
            singleTapWorkItem?.cancel()
            let item = DispatchWorkItem { [weak self] in
                guard let self = self, self.activeSeekSide == 0 else { return }
                self.setControllerVisible(!self.isControllerVisible)
            }
            singleTapWorkItem = item
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.36, execute: item)
        }
    }

    private func triggerMultiTapSeek(side: Int) {
        activeSeekSide = side
        lastSeekEventTime = Date().timeIntervalSince1970
        seekBy(side < 0 ? -10 : 10)
        if side < 0 {
            accumLeftSeek += 10
            leftSeekBadge.text = "« -\(accumLeftSeek)s"
            leftSeekBadge.isHidden = false
            hideLeftSeekWorkItem?.cancel()
            let item = DispatchWorkItem { [weak self] in
                self?.accumLeftSeek = 0
                if self?.activeSeekSide == -1 { self?.activeSeekSide = 0 }
                self?.leftSeekBadge.isHidden = true
            }
            hideLeftSeekWorkItem = item
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.1, execute: item)
        } else {
            accumRightSeek += 10
            rightSeekBadge.text = "+\(accumRightSeek)s »"
            rightSeekBadge.isHidden = false
            hideRightSeekWorkItem?.cancel()
            let item = DispatchWorkItem { [weak self] in
                self?.accumRightSeek = 0
                if self?.activeSeekSide == 1 { self?.activeSeekSide = 0 }
                self?.rightSeekBadge.isHidden = true
            }
            hideRightSeekWorkItem = item
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.1, execute: item)
        }
    }

    func resourceLoader(_ resourceLoader: AVAssetResourceLoader, shouldWaitForLoadingOfRequestedResource loadingRequest: AVAssetResourceLoadingRequest) -> Bool {
        guard let reqUrl = loadingRequest.request.url,
              var comps = URLComponents(url: reqUrl, resolvingAgainstBaseURL: false) else {
            return false
        }
        if comps.scheme == "singularity-inline" {
            var text = inlineM3u8Text
            if let r = text.range(of: "#EXTM3U") {
                text = String(text[r.lowerBound...])
            }
            let isMaster = text.contains("#EXT-X-STREAM-INF")
            if let baseUrl = URL(string: inlineBaseUrl) {
                let lines = text.components(separatedBy: .newlines)
                var resolved: [String] = []
                for line in lines {
                    let trimmed = line.trimmingCharacters(in: .whitespaces)
                    if trimmed.isEmpty || trimmed.hasPrefix("#") {
                        var updatedLine = line
                        if let range = updatedLine.range(of: "URI=\"") {
                            let after = updatedLine[range.upperBound...]
                            if let endQ = after.firstIndex(of: "\"") {
                                let rawUri = String(after[..<endQ])
                                if !rawUri.hasPrefix("http"), let abs = URL(string: rawUri, relativeTo: baseUrl)?.absoluteString {
                                    updatedLine.replaceSubrange(range.upperBound..<endQ, with: abs)
                                }
                            }
                        }
                        resolved.append(updatedLine)
                    } else if var abs = URL(string: trimmed, relativeTo: baseUrl)?.absoluteString {
                        if isMaster {
                            if abs.hasPrefix("https://") {
                                abs = "singularity-hlss://" + abs.dropFirst("https://".count)
                            } else if abs.hasPrefix("http://") {
                                abs = "singularity-hlsp://" + abs.dropFirst("http://".count)
                            }
                        }
                        resolved.append(abs)
                    } else {
                        resolved.append(line)
                    }
                }
                text = resolved.joined(separator: "\n")
            }
            if let outData = text.data(using: .utf8) {
                if let info = loadingRequest.contentInformationRequest {
                    info.contentType = "public.m3u-playlist"
                    info.isByteRangeAccessSupported = false
                    info.contentLength = Int64(outData.count)
                }
                loadingRequest.dataRequest?.respond(with: outData)
                loadingRequest.finishLoading()
                return true
            }
            return false
        }
        var isSegment = false
        if comps.scheme == "singularity-hlss" {
            comps.scheme = "https"
        } else if comps.scheme == "singularity-hlsp" {
            comps.scheme = "http"
        } else if comps.scheme == "singularity-segs" {
            comps.scheme = "https"
            isSegment = true
        } else if comps.scheme == "singularity-segp" {
            comps.scheme = "http"
            isSegment = true
        } else {
            return false
        }
        guard let targetUrl = comps.url else { return false }
        var req = URLRequest(url: targetUrl)
        for (k, v) in activeStreamHeaders {
            req.setValue(v, forHTTPHeaderField: k)
        }
        URLSession.shared.dataTask(with: req) { data, response, error in
            if let error = error {
                loadingRequest.finishLoading(with: error)
                return
            }
            guard let data = data else {
                loadingRequest.finishLoading(with: NSError(domain: "SingularityHLS", code: -1))
                return
            }
            if isSegment {
                if let info = loadingRequest.contentInformationRequest {
                    info.contentType = "public.mpeg-2-transport-stream"
                    info.isByteRangeAccessSupported = true
                    info.contentLength = Int64(data.count)
                }
                loadingRequest.dataRequest?.respond(with: data)
                loadingRequest.finishLoading()
                return
            }
            let baseUrl = response?.url ?? targetUrl
            var outData = data
            if let rawText = String(data: data, encoding: .utf8) {
                var text = rawText
                if let r = text.range(of: "#EXTM3U") {
                    text = String(text[r.lowerBound...])
                }
                if text.hasPrefix("#EXTM3U") {
                    let isMaster = text.contains("#EXT-X-STREAM-INF")
                    let lines = text.components(separatedBy: .newlines)
                    var resolved: [String] = []
                    for line in lines {
                        let trimmed = line.trimmingCharacters(in: .whitespaces)
                        if trimmed.isEmpty || trimmed.hasPrefix("#") {
                            var updatedLine = line
                            if let range = updatedLine.range(of: "URI=\"") {
                                let after = updatedLine[range.upperBound...]
                                if let endQ = after.firstIndex(of: "\"") {
                                    let rawUri = String(after[..<endQ])
                                    if !rawUri.hasPrefix("http"), let abs = URL(string: rawUri, relativeTo: baseUrl)?.absoluteString {
                                        updatedLine.replaceSubrange(range.upperBound..<endQ, with: abs)
                                    }
                                }
                            }
                            resolved.append(updatedLine)
                        } else if var abs = URL(string: trimmed, relativeTo: baseUrl)?.absoluteString {
                            if isMaster {
                                if abs.hasPrefix("https://") {
                                    abs = "singularity-hlss://" + abs.dropFirst("https://".count)
                                } else if abs.hasPrefix("http://") {
                                    abs = "singularity-hlsp://" + abs.dropFirst("http://".count)
                                }
                            } else {
                                let low = abs.lowercased().components(separatedBy: "?").first ?? abs.lowercased()
                                let isNormalSeg = low.hasSuffix(".ts") || low.hasSuffix(".m4s") || low.hasSuffix(".mp4") || low.hasSuffix(".aac") || low.hasSuffix(".m4a")
                                if !isNormalSeg {
                                    if abs.hasPrefix("https://") {
                                        abs = "singularity-segs://" + abs.dropFirst("https://".count)
                                    } else if abs.hasPrefix("http://") {
                                        abs = "singularity-segp://" + abs.dropFirst("http://".count)
                                    }
                                }
                            }
                            resolved.append(abs)
                        } else {
                            resolved.append(line)
                        }
                    }
                    if let d = resolved.joined(separator: "\n").data(using: .utf8) {
                        outData = d
                    }
                }
            }
            if let info = loadingRequest.contentInformationRequest {
                info.contentType = "public.m3u-playlist"
                info.isByteRangeAccessSupported = false
                info.contentLength = Int64(outData.count)
            }
            loadingRequest.dataRequest?.respond(with: outData)
            loadingRequest.finishLoading()
        }.resume()
        return true
    }
}
