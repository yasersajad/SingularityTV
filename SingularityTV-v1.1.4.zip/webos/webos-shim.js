(function() {
  window.__isWebOS = true;
  window.addEventListener("keydown", function(e) {
    if (e.keyCode === 461 || e.key === "GoBack" || e.key === "BrowserBack") {
      e.preventDefault();
      var esc = new KeyboardEvent("keydown", { key: "Escape", code: "Escape", keyCode: 27, which: 27, bubbles: true });
      document.dispatchEvent(esc);
      window.dispatchEvent(esc);
    }
  }, true);
})();
