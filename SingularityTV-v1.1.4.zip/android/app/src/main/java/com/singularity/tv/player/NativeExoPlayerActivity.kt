package com.singularity.tv.player

import android.app.PictureInPictureParams
import android.content.Intent
import android.content.Context
import android.content.res.Configuration
import android.media.AudioManager
import android.view.MotionEvent
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.ClipDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Rational
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.CaptionStyleCompat
import org.videolan.libvlc.LibVLC
import org.videolan.libvlc.Media
import org.videolan.libvlc.MediaPlayer
import org.videolan.libvlc.util.VLCVideoLayout
import com.singularity.tv.StreambertApp
import com.singularity.tv.data.PlaybackProgressEntity
import com.singularity.tv.webview.AdBlockerInterceptor
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.concurrent.thread

data class PlayerSubTrack(
    val label: String,
    val lang: String,
    val urlOrPath: String,
    val score: Int = 0
)

data class ParsedSubCue(
    val startMs: Long,
    val endMs: Long,
    val text: String
)

private class VectorIconDrawable(
    private val kind: String,
    private val tintColor: Int = Color.WHITE
) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = tintColor
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        val cx = b.centerX().toFloat()
        val cy = b.centerY().toFloat()
        val s = minOf(w, h)

        when (kind) {
            "back" -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = s * 0.09f
                val path = Path().apply {
                    moveTo(cx + s * 0.24f, cy)
                    lineTo(cx - s * 0.24f, cy)
                    moveTo(cx - s * 0.04f, cy - s * 0.2f)
                    lineTo(cx - s * 0.24f, cy)
                    lineTo(cx - s * 0.04f, cy + s * 0.2f)
                }
                canvas.drawPath(path, paint)
            }
            "play" -> {
                paint.style = Paint.Style.FILL
                val path = Path().apply {
                    moveTo(cx - s * 0.16f, cy - s * 0.24f)
                    lineTo(cx + s * 0.26f, cy)
                    lineTo(cx - s * 0.16f, cy + s * 0.24f)
                    close()
                }
                canvas.drawPath(path, paint)
            }
            "pause" -> {
                paint.style = Paint.Style.FILL
                val barW = s * 0.12f
                val barH = s * 0.44f
                val gap = s * 0.09f
                canvas.drawRoundRect(
                    RectF(cx - gap - barW, cy - barH / 2f, cx - gap, cy + barH / 2f),
                    barW * 0.35f,
                    barW * 0.35f,
                    paint
                )
                canvas.drawRoundRect(
                    RectF(cx + gap, cy - barH / 2f, cx + gap + barW, cy + barH / 2f),
                    barW * 0.35f,
                    barW * 0.35f,
                    paint
                )
            }
            "rew10", "fwd10" -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = s * 0.075f
                val r = s * 0.29f
                val oval = RectF(cx - r, cy - r, cx + r, cy + r)
                val topY = cy - r
                val aw = s * 0.11f
                val ah = s * 0.09f
                if (kind == "rew10") {
                    canvas.drawArc(oval, -90f, 275f, false, paint)
                    val arrow = Path().apply {
                        moveTo(cx + aw, topY - ah)
                        lineTo(cx - aw * 0.35f, topY)
                        lineTo(cx + aw, topY + ah)
                    }
                    canvas.drawPath(arrow, paint)
                } else {
                    canvas.drawArc(oval, -90f, -275f, false, paint)
                    val arrow = Path().apply {
                        moveTo(cx - aw, topY - ah)
                        lineTo(cx + aw * 0.35f, topY)
                        lineTo(cx - aw, topY + ah)
                    }
                    canvas.drawPath(arrow, paint)
                }
                paint.style = Paint.Style.FILL
                paint.textAlign = Paint.Align.CENTER
                paint.textSize = s * 0.23f
                paint.typeface = Typeface.DEFAULT_BOLD
                val fm = paint.fontMetrics
                val ty = cy - (fm.ascent + fm.descent) / 2f + s * 0.02f
                canvas.drawText("10", cx, ty, paint)
            }
            "restart" -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = s * 0.072f
                paint.strokeCap = Paint.Cap.ROUND
                paint.strokeJoin = Paint.Join.ROUND
                val r = s * 0.26f
                val oval = RectF(cx - r, cy - r, cx + r, cy + r)
                canvas.drawArc(oval, -55f, 295f, false, paint)
                val rad = Math.toRadians(-55.0)
                val tipX = cx + (r * kotlin.math.cos(rad)).toFloat()
                val tipY = cy + (r * kotlin.math.sin(rad)).toFloat()
                val aw = s * 0.115f
                val arrow = Path().apply {
                    moveTo(tipX - aw * 1.1f, tipY - aw * 0.15f)
                    lineTo(tipX, tipY)
                    lineTo(tipX + aw * 0.12f, tipY - aw * 1.1f)
                }
                canvas.drawPath(arrow, paint)
            }
            "next" -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = s * 0.068f
                val tri = Path().apply {
                    moveTo(cx - s * 0.22f, cy - s * 0.19f)
                    lineTo(cx + s * 0.09f, cy)
                    lineTo(cx - s * 0.22f, cy + s * 0.19f)
                    close()
                }
                canvas.drawPath(tri, paint)
                canvas.drawLine(cx + s * 0.20f, cy - s * 0.19f, cx + s * 0.20f, cy + s * 0.19f, paint)
            }
            "ff_icon" -> {
                paint.style = Paint.Style.FILL
                val p1 = Path().apply {
                    moveTo(cx - s * 0.34f, cy - s * 0.24f)
                    lineTo(cx - s * 0.02f, cy)
                    lineTo(cx - s * 0.34f, cy + s * 0.24f)
                    close()
                }
                val p2 = Path().apply {
                    moveTo(cx + s * 0.02f, cy - s * 0.24f)
                    lineTo(cx + s * 0.34f, cy)
                    lineTo(cx + s * 0.02f, cy + s * 0.24f)
                    close()
                }
                canvas.drawPath(p1, paint)
                canvas.drawPath(p2, paint)
            }
            "rw_icon" -> {
                paint.style = Paint.Style.FILL
                val p1 = Path().apply {
                    moveTo(cx + s * 0.34f, cy - s * 0.24f)
                    lineTo(cx + s * 0.02f, cy)
                    lineTo(cx + s * 0.34f, cy + s * 0.24f)
                    close()
                }
                val p2 = Path().apply {
                    moveTo(cx - s * 0.02f, cy - s * 0.24f)
                    lineTo(cx - s * 0.34f, cy)
                    lineTo(cx - s * 0.02f, cy + s * 0.24f)
                    close()
                }
                canvas.drawPath(p1, paint)
                canvas.drawPath(p2, paint)
            }
        }
    }

    override fun setAlpha(alpha: Int) {
        paint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        paint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}


private class VerticalGestureMeterView(
    context: Context,
    private val isBrightness: Boolean
) : View(context) {
    private var level: Float = 0.5f
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(95, 255, 255, 255)
        setShadowLayer(4f, 0f, 2f, Color.argb(160, 0, 0, 0))
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = if (isBrightness) Color.rgb(250, 204, 21) else Color.rgb(229, 9, 20)
        setShadowLayer(6f, 0f, 2f, Color.argb(160, 0, 0, 0))
    }
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        setShadowLayer(5f, 0f, 2f, Color.argb(180, 0, 0, 0))
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setShadowLayer(5f, 0f, 2f, Color.argb(190, 0, 0, 0))
    }

    fun setLevel(value: Float) {
        level = value.coerceIn(0f, 1f)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f

        val iconCy = w * 0.62f
        val iconS = w * 0.46f
        if (isBrightness) {
            iconPaint.style = Paint.Style.FILL
            val coreR = iconS * (0.20f + 0.10f * level)
            canvas.drawCircle(cx, iconCy, coreR, iconPaint)
            iconPaint.style = Paint.Style.STROKE
            iconPaint.strokeWidth = w * 0.055f
            val rayInner = coreR + iconS * 0.12f
            val rayOuter = rayInner + iconS * (0.06f + 0.18f * level)
            val rotOffset = level * 45f
            for (i in 0 until 8) {
                val angle = Math.toRadians((i * 45f + rotOffset).toDouble())
                val sx = cx + (rayInner * Math.cos(angle)).toFloat()
                val sy = iconCy + (rayInner * Math.sin(angle)).toFloat()
                val ex = cx + (rayOuter * Math.cos(angle)).toFloat()
                val ey = iconCy + (rayOuter * Math.sin(angle)).toFloat()
                canvas.drawLine(sx, sy, ex, ey, iconPaint)
            }
        } else {
            iconPaint.style = Paint.Style.FILL
            val spk = Path().apply {
                moveTo(cx - iconS * 0.28f, iconCy - iconS * 0.14f)
                lineTo(cx - iconS * 0.10f, iconCy - iconS * 0.14f)
                lineTo(cx + iconS * 0.08f, iconCy - iconS * 0.30f)
                lineTo(cx + iconS * 0.08f, iconCy + iconS * 0.30f)
                lineTo(cx - iconS * 0.10f, iconCy + iconS * 0.14f)
                lineTo(cx - iconS * 0.28f, iconCy + iconS * 0.14f)
                close()
            }
            canvas.drawPath(spk, iconPaint)
            iconPaint.style = Paint.Style.STROKE
            iconPaint.strokeWidth = w * 0.055f
            if (level <= 0.01f) {
                val xOff = iconS * 0.18f
                canvas.drawLine(cx + xOff, iconCy - iconS * 0.12f, cx + xOff + iconS * 0.18f, iconCy + iconS * 0.12f, iconPaint)
                canvas.drawLine(cx + xOff + iconS * 0.18f, iconCy - iconS * 0.12f, cx + xOff, iconCy + iconS * 0.12f, iconPaint)
            } else {
                val waves = if (level > 0.66f) 3 else if (level > 0.33f) 2 else 1
                for (i in 1..waves) {
                    val wr = iconS * (0.14f * i)
                    val oval = RectF(cx + iconS * 0.05f - wr * 0.3f, iconCy - wr, cx + iconS * 0.05f + wr, iconCy + wr)
                    canvas.drawArc(oval, -45f, 90f, false, iconPaint)
                }
            }
        }

        val barW = w * 0.18f
        val barTop = iconCy + iconS * 0.72f
        val barBottom = h - w * 0.68f
        val barLeft = cx - barW / 2f
        val barRight = cx + barW / 2f
        val barRadius = barW / 2f
        canvas.drawRoundRect(RectF(barLeft, barTop, barRight, barBottom), barRadius, barRadius, trackPaint)

        val fillH = (barBottom - barTop) * level
        if (fillH > 1f) {
            canvas.drawRoundRect(
                RectF(barLeft, barBottom - fillH, barRight, barBottom),
                barRadius,
                barRadius,
                fillPaint
            )
        }

        textPaint.textSize = w * 0.24f
        canvas.drawText("${(level * 100).toInt()}%", cx, h - w * 0.24f, textPaint)
    }
}

class NativeExoPlayerActivity : AppCompatActivity() {

    private var libVlc: LibVLC? = null
    private var vlcPlayer: MediaPlayer? = null
    private var vlcVideoLayout: VLCVideoLayout? = null
    private var vlcPlaybackReady: Boolean = false
    private var vlcPendingSeekMs: Long = 0L
    private var vlcPlaybackToken: Int = 0
    private var localProxyServer: java.net.ServerSocket? = null
    private var localProxyPort: Int = 0
    private var localProxyPool: java.util.concurrent.ExecutorService? = null
    @Volatile private var localProxyReferer: String = "https://vidly.pro/"
    @Volatile private var localProxyUserAgent: String = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
    @Volatile private var localProxyForceWebView: Boolean = false
    private var isScreenLocked: Boolean = false
    private var unlockHideRunnable: Runnable? = null
    private var vlcDidEnd: Boolean = false
    private var seekUiLockUntilMs: Long = 0L
    private var seekUiTargetMs: Long = -1L
    private var forceSoftwareDecode: Boolean = false
    private var vlcVideoOutCount: Int = 0
    private var vlcVideoConfirmed: Boolean = false
    private var desiredPaused: Boolean? = null
    private var embedMovieTemplate: String = "https://vidly.pro/movie/{TMDBID}"
    private var embedTvTemplate: String = "https://vidly.pro/tv/{TMDBID}/{SEASON}/{EPISODE}"
    private var webErrorRetryCount: Int = 0
    private var initialWebPrefsJson: String = "{}" 
    private var aspectModeIndex: Int = 0
    private var sleepAtEndOfEpisode: Boolean = false
    private var sleepTimerRunnable: Runnable? = null
    private var unlockBtn: Button? = null
    private var aspectBtn: Button? = null
    private var sleepBtn: Button? = null
    private var speedBtnRef: Button? = null
    private var syncBtnRef: Button? = null
    private var scaleDetector: android.view.ScaleGestureDetector? = null
    private var resolverWebView: WebView? = null
    private var captchaCardContainer: LinearLayout? = null
    private var captchaCursorView: View? = null
    private var isCaptchaCardVisible: Boolean = false
    private var isCaptchaDragMode: Boolean = false
    private var captchaDragDownTime: Long = 0L
    private var captchaTitleTv: TextView? = null
    private var captchaCursorX: Float = 0.5f
    private var captchaCursorY: Float = 0.5f
    private var isCaptchaCursorActive = true
    private val failedStreamUrls = HashSet<String>()
    private var lastRemoteStreamUrl: String = ""
    private var lastInlineM3u8Path: String = ""
    private var lastInlineM3u8Ref: String = ""
    private var ambientProgressBar: FrameLayout? = null
    private var ambientProgressFill: View? = null
    private var bottomContainerRef: LinearLayout? = null
    private var gestureHudContainer: LinearLayout? = null
    private var gestureHudIcon: ImageView? = null
    private var gestureHudPill: TextView? = null
    private var swipeSeekBasePosMs: Long = 0L
    private var swipeSeekTargetMs: Long = 0L
    private var hold2xSide: Int = 0
    private var hold2xStartX: Float = 0f
    private var hold2xSavedSpeed: Float = 1.0f
    private var hold2xLastAppliedSpeed: Float = 0f
    private var hold2xWasPlaying: Boolean = false
    private val hold2xStartRunnable = Runnable {
        val p = vlcPlayer ?: return@Runnable
        if (gestureActiveMode != 0 || isCaptchaCardVisible) return@Runnable
        hold2xSide = 1
        hold2xStartX = gestureStartX
        gestureActiveMode = 4
        hold2xSavedSpeed = if (p.rate > 0f) p.rate else currentSpeed
        hold2xWasPlaying = p.isPlaying
        mainHandler.removeCallbacks(singleTapToggleRunnable)
        hold2xLastAppliedSpeed = 2.0f
        if (!p.isPlaying) p.play()
        p.rate = 2.0f
        showGestureHudPill(formatSpeedText(2.0f), "ff_icon")
    }

    private var hasRealPlaybackProgress: Boolean = false
    private var seekAttemptSeq: Int = 0
    private var seekVerifyRunnable: Runnable? = null
    private var seekDebounceRunnable: Runnable? = null
    private var lastRawPayload: JSONObject? = null
    private var episodeRuntimeMin: Int = 0
    private var startTimeAppliedByOption: Boolean = false

    private fun vlcCurrentPosMs(): Long {
        val p = vlcPlayer ?: return 0L
        val t = p.time
        if (t > 0L) return t
        val dur = p.length
        val pos = p.position
        if (dur > 0L && pos > 0f && pos <= 1f) return (dur * pos).toLong()
        return 0L
    }
    private fun vlcDurationMs(): Long = (vlcPlayer?.length ?: 0L).coerceAtLeast(0L)
    private fun vlcIsPlaying(): Boolean = vlcPlayer?.isPlaying == true

    private fun effectiveSeekBaseMs(): Long {
        val now = SystemClock.elapsedRealtime()
        if (now < seekUiLockUntilMs && seekUiTargetMs >= 0L) return seekUiTargetMs
        return vlcCurrentPosMs()
    }

    private fun ensureOriginalAudioTrack(mp: MediaPlayer?) {
        val p = mp ?: return
        try {
            if (p.volume < 100) p.volume = 100
            val cur = p.audioTrack
            if (cur == -1) {
                val tracks = p.audioTracks
                if (tracks != null) {
                    val orig = tracks.firstOrNull { it.id >= 0 }
                    if (orig != null) p.audioTrack = orig.id
                }
            }
        } catch (_: Throwable) {}
    }

    private fun vlcSeekTo(ms: Long, immediate: Boolean = false) {
        val p = vlcPlayer ?: return
        val dur = vlcDurationMs()
        val target = if (dur > 0L) ms.coerceIn(0L, dur) else ms.coerceAtLeast(0L)
        seekUiTargetMs = target
        seekUiLockUntilMs = SystemClock.elapsedRealtime() + 4500L
        seekAttemptSeq++
        val mySeq = seekAttemptSeq
        seekDebounceRunnable?.let { mainHandler.removeCallbacks(it) }
        seekVerifyRunnable?.let { mainHandler.removeCallbacks(it) }
        if (dur > 0L) {
            val frac = (target.toFloat() / dur.toFloat()).coerceIn(0f, 1f)
            seekBar?.progress = (frac * 1000f).toInt().coerceIn(0, 1000)
            ambientProgressFill?.scaleX = frac
            currentPosView?.text = formatTimeMs(target)
            durationView?.text = "-${formatTimeMs((dur - target).coerceAtLeast(0L))}"
        }
        val commitSeek = Runnable {
            if (mySeq != seekAttemptSeq || isFinishing || isDestroyed) return@Runnable
            val curP = vlcPlayer ?: return@Runnable
            val dNow = vlcDurationMs()
            if (vlcDidEnd || (!curP.isPlaying && dNow > 0L && vlcCurrentPosMs() >= dNow - 1500L)) {
                vlcDidEnd = false
                vlcPendingSeekMs = target
                curP.stop()
                curP.play()
                return@Runnable
            }
            val prePos = vlcCurrentPosMs()
            seekUiLockUntilMs = SystemClock.elapsedRealtime() + 5000L
            if (dNow > 0L) {
                val frac = (target.toFloat() / dNow.toFloat()).coerceIn(0f, 0.999f)
                try {
                    curP.setPosition(frac, false)
                } catch (_: Throwable) {
                    try { curP.position = frac } catch (_: Throwable) {}
                }
            } else {
                try {
                    curP.setTime(target, false)
                } catch (_: Throwable) {
                    try { curP.time = target } catch (_: Throwable) {}
                }
            }
            val verifySeek = Runnable {
                if (mySeq != seekAttemptSeq || isFinishing || isDestroyed) return@Runnable
                val pNow = vlcPlayer ?: return@Runnable
                val curPos = vlcCurrentPosMs()
                if (kotlin.math.abs(curPos - prePos) < 2000L && kotlin.math.abs(target - prePos) > 15000L) {
                    seekUiLockUntilMs = SystemClock.elapsedRealtime() + 3500L
                    try {
                        pNow.setTime(target, false)
                    } catch (_: Throwable) {
                        try { pNow.time = target } catch (_: Throwable) {}
                    }
                }
            }
            seekVerifyRunnable = verifySeek
            mainHandler.postDelayed(verifySeek, 3200L)
        }
        if (immediate) {
            commitSeek.run()
        } else {
            seekDebounceRunnable = commitSeek
            mainHandler.postDelayed(commitSeek, 220L)
        }
    }
    private var useWebViewProxy: Boolean = false
    private var directWebPlayerMode: Boolean = false
    private var directWebBackBtn: Button? = null
    private val proxyWaiters = java.util.concurrent.ConcurrentHashMap<String, java.util.concurrent.CompletableFuture<Pair<Int, ByteArray?>>>()
    private val proxySeq = java.util.concurrent.atomic.AtomicInteger(1)
    private var topNextBtn: ImageButton? = null
    private var topNextContainer: LinearLayout? = null
    private var topRestartBtn: ImageButton? = null
    private var captchaReloadBtn: Button? = null
    private var bottomActionsRow: LinearLayout? = null
    private var rootFrameLayout: FrameLayout? = null
    private var activeResolverEmbedUrl: String = ""
    private var controllerOverlay: FrameLayout? = null
    private var subBtn: Button? = null
    private var titleView: TextView? = null
    private var serverBadgeView: TextView? = null
    private val multiEmbedSubServers = mutableListOf<Pair<String, String>>()
    private var switchServerBtn: Button? = null
    private var seriesTitleStr: String = ""
    private var totalEpisodesInSeason: Int = 0
    private val seasonEpisodesList = mutableListOf<Pair<Int, Int>>()
    private var introStartSec: Double = -1.0
    private var introEndSec: Double = -1.0
    private var recapStartSec: Double = -1.0
    private var recapEndSec: Double = -1.0
    private var outroStartSec: Double = -1.0
    private var activeSkipTargetSec: Double = -1.0
    private var nextEpDismissed: Boolean = false
    private var nextEpCountdownSec: Int = 10
    private var skipSegmentBtn: Button? = null
    private var nextEpCard: LinearLayout? = null
    private var nextEpTitleTv: TextView? = null
    private var nextEpCountdownTv: TextView? = null
    private val verifiedServers = java.util.concurrent.ConcurrentHashMap<String, Pair<String, String>>()
    private val probedFailedServers = java.util.Collections.synchronizedSet(HashSet<String>())
    private val probeQueue = java.util.ArrayDeque<String>()
    private val probeWebViews = mutableListOf<WebView>()
    private val probeSlotSources = mutableMapOf<WebView, String>()
    private val probeTimeoutRunnables = mutableMapOf<WebView, Runnable>()
    private var isProbingActive: Boolean = false
    private var subtitleOverlayView: TextView? = null
    private var playPauseBtn: ImageButton? = null
    private var seekBar: SeekBar? = null
    private var durationView: TextView? = null
    private var currentPosView: TextView? = null
    private var isScrubbing: Boolean = false
    private var isControllerVisible: Boolean = true
    private var brightnessMeter: VerticalGestureMeterView? = null
    private var volumeMeter: VerticalGestureMeterView? = null
    private var leftSeekBadge: TextView? = null
    private var rightSeekBadge: TextView? = null
    private var currentBrightness: Float = 0.65f
    private var accumSeekLeftSec: Int = 0
    private var accumSeekRightSec: Int = 0
    private var gestureActiveMode: Int = 0
    private var gestureDownTimeMs: Long = 0L
    private var gestureStartX: Float = 0f
    private var gestureStartY: Float = 0f
    private var gestureStartVal: Float = 0f
    private var lastTapTimeMs: Long = 0L
    private var lastTapSide: Int = 0
    private var activeSeekSide: Int = 0
    private var lastSeekEventTimeMs: Long = 0L
    private var audioManager: AudioManager? = null

    private var streamUrl: String = ""
    private var streamTitle: String = "SingularityTV"
    private var progressKey: String? = null
    private var startTimeSec: Long = 0L
    private var currentSpeed: Float = 1.0f
    private var retryCount: Int = 0
    private var serverFailoverAttempts: Int = 0
    private var isSwitchingServer: Boolean = false
    private var currentSource: String = "vidyst"
    private var rawPayload: JSONObject = JSONObject()

    private var imdbId: String = ""
    private var tmdbId: String = ""
    private var mediaType: String = "movie"
    private val isLiveStream: Boolean get() = mediaType.equals("live", ignoreCase = true)
    private var liveElapsedMs: Long = 0L
    private var lastLiveTickMs: Long = 0L
    private var topRestartContainerRef: View? = null
    private var rewBtnRef: View? = null
    private var fwdBtnRef: View? = null
    private var styleBtnRef: View? = null
    private var audioBtnRef: View? = null
    private var skip85BtnRef: View? = null
    private var seasonNum: Int = 1
    private var episodeNum: Int = 1
    private var preferredLang: String = "ar"
    private var activeQualityTag: String = ""

    private val availableSubs = CopyOnWriteArrayList<PlayerSubTrack>()
    private val activeParsedCues = CopyOnWriteArrayList<ParsedSubCue>()
    private var activeSubIndex: Int = -1
    private var subDelayMs: Long = 0L
    private var subTextSizeSp: Float = 22f
    private var subTextColorHex: String = "#FFFFFF"
    private var subBgStyleMode: String = "dark"

    private val mainHandler = Handler(Looper.getMainLooper())

    private val hideMetersRunnable = Runnable {
        brightnessMeter?.let { m ->
            m.animate().cancel()
            if (m.visibility == View.VISIBLE) {
                m.animate().alpha(0f).setDuration(200).withEndAction {
                    m.visibility = View.GONE
                }.start()
            }
        }
        volumeMeter?.let { m ->
            m.animate().cancel()
            if (m.visibility == View.VISIBLE) {
                m.animate().alpha(0f).setDuration(200).withEndAction {
                    m.visibility = View.GONE
                }.start()
            }
        }
    }

    private val singleTapToggleRunnable = Runnable {
        if (isControllerVisible) {
            setControllerVisible(false)
        } else {
            showControllerTemporarily()
        }
    }

    private val hideLeftSeekRunnable = Runnable {
        accumSeekLeftSec = 0
        if (activeSeekSide == -1) activeSeekSide = 0
        leftSeekBadge?.let { b ->
            b.animate().cancel()
            b.animate().alpha(0f).scaleX(0.88f).scaleY(0.88f).setDuration(180).withEndAction {
                b.visibility = View.GONE
                b.alpha = 0f
            }.start()
        }
    }

    private val hideRightSeekRunnable = Runnable {
        accumSeekRightSec = 0
        if (activeSeekSide == 1) activeSeekSide = 0
        rightSeekBadge?.let { b ->
            b.animate().cancel()
            b.animate().alpha(0f).scaleX(0.88f).scaleY(0.88f).setDuration(180).withEndAction {
                b.visibility = View.GONE
                b.alpha = 0f
            }.start()
        }
    }

    private val serverOrder = listOf("vidyst")
    private val streamIsHlsMap = HashMap<String, Boolean>()
    private val streamRefererMap = HashMap<String, String>()
    private var pendingNextSource: String = ""

    private val recentlyUpdatedSources = setOf(
        "rivestream", "vidsrcxyz", "vidsrcme", "vidsrcin",
        "vidsrcpm", "vidsrcicu", "moviesapi", "nontongo"
    )
    private val serverCatalogVersion = "v274"

    private fun serverStatusKey(sourceId: String): String {
        val pk = progressKey ?: (if (imdbId.isNotEmpty()) imdbId else streamTitle)
        return "srv_status_${pk}_$sourceId"
    }

    private fun recordServerStatus(sourceId: String, status: String) {
        if (sourceId.isBlank()) return
        try {
            val prefs = getSharedPreferences("singularity_server_status", Context.MODE_PRIVATE)
            prefs.edit()
                .putString(serverStatusKey(sourceId), status)
                .putString(serverStatusKey(sourceId) + "_ver", serverCatalogVersion)
                .apply()
        } catch (_: Throwable) {}
    }

    private fun getServerStatus(sourceId: String): String {
        return try {
            val prefs = getSharedPreferences("singularity_server_status", Context.MODE_PRIVATE)
            val st = prefs.getString(serverStatusKey(sourceId), "unknown") ?: "unknown"
            val ver = prefs.getString(serverStatusKey(sourceId) + "_ver", "") ?: ""
            when (st) {
                "working" -> "working"
                "failed" -> if (ver != serverCatalogVersion) { if (recentlyUpdatedSources.contains(sourceId)) "updated" else "unknown" } else "failed"
                else -> if (recentlyUpdatedSources.contains(sourceId)) "updated" else "unknown"
            }
        } catch (_: Throwable) {
            if (recentlyUpdatedSources.contains(sourceId)) "updated" else "unknown"
        }
    }

    private fun loadSeriesPrefsIfAny() {
        val key = imdbId.ifEmpty { tmdbId }
        val prefs = getSharedPreferences("singularity_player_prefs", Context.MODE_PRIVATE)
        applySubtitleStyle()
        if (key.isEmpty()) return
        val savedLang = prefs.getString("sp_lang_$key", "") ?: ""
        if (savedLang.isNotEmpty()) preferredLang = savedLang
        if (prefs.contains("sp_delay_$key")) {
            subDelayMs = prefs.getLong("sp_delay_$key", 0L)
            syncBtnRef?.text = String.format(Locale.US, "Sync %.1fs", subDelayMs / 1000.0)
        }
        if (prefs.contains("sp_speed_$key")) {
            val sp = prefs.getFloat("sp_speed_$key", 1.0f)
            if (sp in 0.5f..3.0f) {
                currentSpeed = sp
                speedBtnRef?.text = formatSpeedText(sp)
            }
        }
    }

    private fun saveSeriesPrefs() {
        val key = imdbId.ifEmpty { tmdbId }
        if (key.isEmpty()) return
        getSharedPreferences("singularity_player_prefs", Context.MODE_PRIVATE).edit()
            .putString("sp_lang_$key", preferredLang)
            .putLong("sp_delay_$key", subDelayMs)
            .putFloat("sp_speed_$key", currentSpeed)
            .apply()
    }

    private fun ensureNumericTmdbIdThen(onReady: () -> Unit) {
        val cur = tmdbId.trim()
        if (cur.isNotEmpty() && cur.all { it.isDigit() }) {
            onReady()
            return
        }
        if (!imdbId.startsWith("tt")) {
            onReady()
            return
        }
        val prefs = getSharedPreferences("singularity_player_prefs", Context.MODE_PRIVATE)
        val cacheKey = "tmdb_map_${mediaType.lowercase()}_$imdbId"
        val cached = prefs.getString(cacheKey, "") ?: ""
        if (cached.isNotEmpty() && cached.all { it.isDigit() }) {
            tmdbId = cached
            onReady()
            return
        }
        thread(start = true) {
            try {
                val prop = if (mediaType.equals("tv", ignoreCase = true)) "P4983" else "P4947"
                val sparql = "SELECT ?tid WHERE { ?item wdt:P345 \"$imdbId\" . ?item wdt:$prop ?tid . } LIMIT 1"
                val req = Request.Builder()
                    .url("https://query.wikidata.org/sparql?format=json&query=" + URLEncoder.encode(sparql, "UTF-8"))
                    .header("Accept", "application/sparql-results+json")
                    .header("User-Agent", "SingularityTV/3.0")
                    .build()
                StreambertApp.instance.okHttpClient.newCall(req).execute().use { res ->
                    if (res.isSuccessful) {
                        val root = JSONObject(res.body?.string() ?: "{}")
                        val bindings = root.optJSONObject("results")?.optJSONArray("bindings")
                        val valStr = bindings?.optJSONObject(0)?.optJSONObject("tid")?.optString("value", "") ?: ""
                        if (valStr.isNotEmpty() && valStr.all { it.isDigit() }) {
                            tmdbId = valStr
                            prefs.edit().putString(cacheKey, valStr).apply()
                        }
                    }
                }
            } catch (_: Throwable) {}
            mainHandler.post {
                if (!isFinishing && !isDestroyed) onReady()
            }
        }
    }

    private fun loadEmbedUrlDirect(embedUrl: String) {
        val wv = resolverWebView ?: return
        if (embedUrl.isBlank()) return
        try {
            val parsed = Uri.parse(embedUrl)
            val ref = if (!parsed.scheme.isNullOrEmpty() && !parsed.host.isNullOrEmpty()) "${parsed.scheme}://${parsed.host}/" else "https://vidly.pro/"
            wv.stopLoading()
            wv.loadUrl(embedUrl, mapOf("Referer" to ref))
        } catch (_: Throwable) {}
    }

    private fun advanceToNextAutoSource() {
        val idx = serverOrder.indexOf(currentSource).coerceAtLeast(0)
        val nextSrc = serverOrder[(idx + 1) % serverOrder.size]
        currentSource = nextSrc
        pendingNextSource = nextSrc
        isSwitchingServer = true
        val embedUrl = buildEmbedUrlForSource(nextSrc)
        if (embedUrl.isNotEmpty()) {
            activeResolverEmbedUrl = embedUrl
            loadEmbedUrlDirect(embedUrl)
        }
    }

    private fun revealFullscreenEmbedFallback() {
        if (vlcPlaybackReady || isFinishing || isDestroyed) return
        val wv = resolverWebView ?: return
        wv.translationX = -dp(5000).toFloat()
        wv.alpha = 0f
        wv.isClickable = false
        wv.isFocusable = false
        try {
            wv.evaluateJavascript("window.__sbStopped=false;window.postMessage({__sbResume:true},'*');", null)
        } catch (_: Throwable) {}
    }

    private fun enterDirectWebPlayerMode() {
        directWebPlayerMode = true
        try { vlcPlayer?.stop() } catch (_: Throwable) {}
        vlcVideoLayout?.setOnTouchListener(null)
        vlcVideoLayout?.visibility = View.GONE
        (vlcVideoLayout?.parent as? ViewGroup)?.removeView(vlcVideoLayout)
        controllerOverlay?.visibility = View.GONE
        (controllerOverlay?.parent as? ViewGroup)?.removeView(controllerOverlay)
        ambientProgressBar?.visibility = View.GONE
        (ambientProgressBar?.parent as? ViewGroup)?.removeView(ambientProgressBar)
        gestureHudContainer?.visibility = View.GONE
        (gestureHudContainer?.parent as? ViewGroup)?.removeView(gestureHudContainer)
        captchaCardContainer?.visibility = View.GONE
        (captchaCardContainer?.parent as? ViewGroup)?.removeView(captchaCardContainer)
        skipSegmentBtn?.visibility = View.GONE
        (skipSegmentBtn?.parent as? ViewGroup)?.removeView(skipSegmentBtn)
        subtitleOverlayView?.visibility = View.GONE
        (subtitleOverlayView?.parent as? ViewGroup)?.removeView(subtitleOverlayView)
        resolverWebView?.let { wv ->
            wv.layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            wv.translationX = 0f
            wv.alpha = 1f
            wv.visibility = View.VISIBLE
            wv.isClickable = true
            wv.isFocusable = true
            wv.isFocusableInTouchMode = true
            wv.bringToFront()
            wv.requestFocus()
        }
        directWebBackBtn?.visibility = View.GONE
    }

    private fun startResolvingInitialSource() {
        forceSoftwareDecode = false
        loadSeriesPrefsIfAny()
        val firstSrc = "vidyst"
        currentSource = firstSrc
        isSwitchingServer = true
        serverFailoverAttempts = 0
        pendingNextSource = firstSrc
        serverBadgeView?.text = firstSrc
        enterDirectWebPlayerMode()
        ensureNumericTmdbIdThen {
            val embedUrl = buildEmbedUrlForSource(firstSrc)
            activeResolverEmbedUrl = embedUrl
            mainHandler.removeCallbacks(failoverWatchdogRunnable)
            if (embedUrl.isNotEmpty()) {
                loadEmbedUrlDirect(embedUrl)
            }
        }
    }

    private fun showCaptchaCard(sourceId: String) {
        if (directWebPlayerMode) return
        isCaptchaCardVisible = false
        isCaptchaCursorActive = false
        captchaCardContainer?.visibility = View.GONE
        resolverWebView?.let { wv ->
            wv.translationX = -dp(5000).toFloat()
            wv.alpha = 0f
            wv.isClickable = false
            wv.isFocusable = false
        }

    }

    private fun updateCaptchaCursorPosition(wrap: FrameLayout) {
        val cursor = captchaCursorView ?: return
        val w = (wrap.width - dp(18)).coerceAtLeast(1)
        val h = (wrap.height - dp(18)).coerceAtLeast(1)
        cursor.translationX = captchaCursorX * w
        cursor.translationY = captchaCursorY * h
    }

    private fun hideCaptchaCard() {
        if (!isCaptchaCardVisible) return
        isCaptchaCardVisible = false
        isCaptchaDragMode = false
        captchaCardContainer?.visibility = View.GONE
        val root = rootFrameLayout ?: return
        val wv = resolverWebView ?: return
        (wv.parent as? ViewGroup)?.removeView(wv)
        wv.layoutParams = FrameLayout.LayoutParams(dp(360), dp(250), Gravity.BOTTOM or Gravity.START)
        wv.translationX = -dp(5000).toFloat()
        wv.alpha = 0f
        wv.isClickable = false
        wv.isFocusable = false
        root.addView(wv, 0)
    }

    private fun resolveTmdbIdIfNeeded() {
        if (tmdbId.isNotEmpty() || !imdbId.startsWith("tt")) return
        thread(start = true) {
            try {
                val prop = if (mediaType.equals("tv", ignoreCase = true)) "P4983" else "P4947"
                val sparql = "SELECT ?tid WHERE { ?item wdt:P345 \"$imdbId\" . ?item wdt:$prop ?tid . } LIMIT 1"
                val req = Request.Builder()
                    .url("https://query.wikidata.org/sparql?format=json&query=" + URLEncoder.encode(sparql, "UTF-8"))
                    .header("Accept", "application/sparql-results+json")
                    .build()
                StreambertApp.instance.okHttpClient.newCall(req).execute().use { res ->
                    if (res.isSuccessful) {
                        val root = JSONObject(res.body?.string() ?: "{}")
                        val bindings = root.optJSONObject("results")?.optJSONArray("bindings")
                        val valStr = bindings?.optJSONObject(0)?.optJSONObject("tid")?.optString("value", "") ?: ""
                        if (valStr.isNotEmpty()) {
                            tmdbId = valStr
                        }
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    private fun buildEmbedUrlForSource(sourceId: String): String {
        val im = imdbId.ifEmpty { rawPayload.optString("imdbId", "") }.trim()
        val tm = tmdbId.ifEmpty { im }.trim()
        if (im.isEmpty() && tm.isEmpty()) return ""
        val isTv = mediaType.equals("tv", ignoreCase = true)
        val s = seasonNum.coerceAtLeast(1)
        val e = episodeNum.coerceAtLeast(1)
        if (sourceId == "vidyst") {
            val isAnime = mediaType.equals("anime", ignoreCase = true)
            var out = when {
                isAnime -> "https://vidly.pro/anime/mal/{TMDBID}/{EPISODE}/sub"
                isTv -> embedTvTemplate
                else -> embedMovieTemplate
            }
            val pairs = listOf(
                "{ID}" to tm, "{TMDBID}" to tm, "{TMDB_ID}" to tm, "{ANILISTID}" to tm,
                "{IMDBID}" to im.ifEmpty { tm }, "{IMDB_ID}" to im.ifEmpty { tm },
                "{SEASON}" to "$s", "{SEASONNUMBER}" to "$s", "{SEASON_NUMBER}" to "$s", "{SEASONNO}" to "$s", "{SEASON_NO}" to "$s",
                "{EPISODE}" to "$e", "{EPISODENO}" to "$e", "{EPISODE_NO}" to "$e", "{EPISODENUMBER}" to "$e", "{EPISODE_NUMBER}" to "$e"
            )
            for ((k, v) in pairs) {
                out = out.replace(k, v, ignoreCase = true)
            }

            return out
        }
        return when (sourceId) {
            "singularity" -> if (isTv) "https://proxy.garageband.rocks/embed/tv/$im/$s/$e" else "https://proxy.garageband.rocks/embed/movie/$im"
            "vidsrcmeru" -> if (isTv) "https://vidsrcme.ru/embed/tv?imdb=$im&season=$s&episode=$e&autoplay=1" else "https://vidsrcme.ru/embed/movie?imdb=$im&autoplay=1"
            "vidsrcto" -> if (isTv) "https://vidsrc.to/embed/tv/$im/$s/$e" else "https://vidsrc.to/embed/movie/$im"
            "vidlink" -> if (isTv) "https://vidlink.pro/tv/$tm/$s/$e?autoplay=true" else "https://vidlink.pro/movie/$tm?autoplay=true"
            "videasy" -> if (isTv) "https://player.videasy.net/tv/$tm/$s/$e" else "https://player.videasy.net/movie/$tm"
            "vidsrccc" -> if (isTv) "https://vidsrc.cc/v2/embed/tv/${im.ifEmpty { tm }}/$s/$e?poster=true&autoPlay=true" else "https://vidsrc.cc/v2/embed/movie/${im.ifEmpty { tm }}?poster=true&autoPlay=true"
            "vidsrcxyz" -> if (isTv) "https://vidsrc.xyz/embed/tv/$im/$s-$e" else "https://vidsrc.xyz/embed/movie/$im"
            "vidsrcnet" -> if (isTv) "https://vidsrc.net/embed/tv/$im/$s-$e?autoplay=1" else "https://vidsrc.net/embed/movie/$im?autoplay=1"
            "vidsrcin" -> if (isTv) "https://vidsrc.in/embed/tv/$im/$s-$e" else "https://vidsrc.in/embed/movie/$im"
            "vidsrc" -> if (isTv) "https://vsembed.su/embed/tv/$im/$s/$e?autoplay=1" else "https://vsembed.su/embed/movie/$im?autoplay=1"
            "vidsrcicu" -> if (isTv) "https://vidsrc.icu/embed/tv/$im/$s/$e" else "https://vidsrc.icu/embed/movie/$im"
            "vidfast" -> if (isTv) "https://vidfast.pro/tv/$tm/$s/$e?autoPlay=true" else "https://vidfast.pro/movie/$tm?autoPlay=true"
            "vidnest" -> if (isTv) "https://vidnest.fun/tv/$tm/$s/$e" else "https://vidnest.fun/movie/$tm"
            "autoembed" -> if (isTv) "https://player.autoembed.cc/embed/tv/$tm/$s/$e?server=1" else "https://player.autoembed.cc/embed/movie/$tm?server=1"
            "embedsu" -> if (isTv) "https://embed.su/embed/tv/$tm/$s/$e" else "https://embed.su/embed/movie/$tm"
            "smashy" -> if (isTv) "https://player.smashy.stream/tv/$im?s=$s&e=$e" else "https://player.smashy.stream/movie/$im"
            "hnembed" -> if (isTv) "https://hnembed.cc/embed/tv/${im.ifEmpty { tm }}/$s/$e" else "https://hnembed.cc/embed/movie/${im.ifEmpty { tm }}"
            "superembed" -> if (isTv) "https://multiembed.mov/directstream.php?video_id=$im&s=$s&e=$e" else "https://multiembed.mov/directstream.php?video_id=$im"
            "rivestream" -> if (isTv) "https://rivestream.org/embed?type=tv&id=$tm&season=$s&episode=$e" else "https://rivestream.org/embed?type=movie&id=$tm"
            "moviesapi" -> if (isTv) "https://moviesapi.club/tv/$tm-$s-$e" else "https://moviesapi.club/movie/$tm"
            "vidsrcpro" -> if (isTv) "https://vidsrc.pro/embed/tv/$tm/$s/$e" else "https://vidsrc.pro/embed/movie/$tm"
            "vidsrcvip" -> if (isTv) "https://vidsrc.vip/embed/tv/$tm/$s/$e" else "https://vidsrc.vip/embed/movie/$tm"
            "vidsrcrip" -> if (isTv) "https://vidsrc.rip/embed/tv/$tm/$s/$e" else "https://vidsrc.rip/embed/movie/$tm"
            "111movies" -> if (isTv) "https://111movies.com/tv/$tm/$s/$e" else "https://111movies.com/movie/$tm"
            "vidjoy" -> if (isTv) "https://vidjoy.pro/embed/tv/$tm/$s/$e" else "https://vidjoy.pro/embed/movie/$tm"
            "2embed" -> if (isTv) "https://www.2embed.cc/embedtv/$im&s=$s&e=$e" else "https://www.2embed.cc/embed/$im"
            "embed2" -> if (isTv) "https://www.2embed.stream/embed/tv/$im/$s/$e" else "https://www.2embed.stream/embed/movie/$im"
            "nontongo" -> if (isTv) "https://www.NontonGo.win/embed/tv?id=$im&s=$s&e=$e" else "https://www.NontonGo.win/embed/movie?id=$im"
            else -> if (isTv) "https://vidsrcme.ru/embed/tv?imdb=$im&season=$s&episode=$e" else "https://vidsrcme.ru/embed/movie?imdb=$im"
        }
    }

    private fun getDefaultRefererForSource(sourceId: String): String {
        val u = buildEmbedUrlForSource(sourceId)
        if (u.startsWith("http")) {
            try {
                val parsed = Uri.parse(u)
                return "${parsed.scheme}://${parsed.host}/"
            } catch (_: Throwable) {}
        }
        return "https://vidlink.pro/"
    }

    private val playbackReadyWatchdogRunnable = Runnable {
        if (!isFinishing && !isDestroyed && vlcPlayer != null && !vlcPlaybackReady && !streamUrl.startsWith("/")) {
            isSwitchingServer = false
            triggerNextServerFailover()
        }
    }

    private val failoverWatchdogRunnable = Runnable {
        if (isSwitchingServer && !isFinishing && !isDestroyed) {
            isSwitchingServer = false
            if (pendingNextSource.isNotEmpty()) {
                currentSource = pendingNextSource
            }
            triggerNextServerFailover()
        }
    }

    private fun episodeStepForCurrentStream(): Int {
        val durSec = vlcDurationMs() / 1000L
        if (episodeRuntimeMin in 7..15 && durSec >= maxOf(1080L, (episodeRuntimeMin * 60L * 165L) / 100L)) {
            return 2
        }
        return 1
    }

    private fun computeNextEpisode(): Pair<Int, Int>? {
        if (!mediaType.equals("tv", ignoreCase = true)) return null
        val step = episodeStepForCurrentStream()
        val nextEpNum = episodeNum + step
        if (seasonEpisodesList.isNotEmpty()) {
            val curEntry = seasonEpisodesList.firstOrNull { it.first == seasonNum }
            val curCount = curEntry?.second ?: totalEpisodesInSeason
            if (curCount > 0 && nextEpNum <= curCount) {
                return Pair(seasonNum, nextEpNum)
            }
            val nextSeason = seasonEpisodesList.firstOrNull { it.first > seasonNum && it.second > 0 }
            if (nextSeason != null) {
                return Pair(nextSeason.first, 1)
            }
            if (curCount > 0) return null
        }
        if (totalEpisodesInSeason > 0) {
            return if (nextEpNum <= totalEpisodesInSeason) Pair(seasonNum, nextEpNum) else null
        }
        return Pair(seasonNum, nextEpNum)
    }

    private fun updateTopActionButtons() {
        val hasNext = computeNextEpisode() != null
        topNextBtn?.visibility = if (hasNext) View.VISIBLE else View.GONE
        topNextContainer?.visibility = if (hasNext) View.VISIBLE else View.GONE
        topRestartBtn?.visibility = View.VISIBLE
    }

    private fun applyResolvedStream(newUrl: String, newSource: String, refererFallback: String) {
        if (isFinishing || isDestroyed || newUrl.isBlank()) return
        if (failedStreamUrls.contains(newUrl)) return
        if (newUrl == streamUrl && vlcPlaybackReady) return
        mainHandler.removeCallbacks(failoverWatchdogRunnable)
        mainHandler.removeCallbacks(playbackReadyWatchdogRunnable)
        isSwitchingServer = false
        hideCaptchaCard()
        try {
            if (!directWebPlayerMode) resolverWebView?.evaluateJavascript("try{document.querySelectorAll('video,audio').forEach(function(v){v.pause();v.muted=true;});}catch(e){}", null) else resolverWebView?.evaluateJavascript("try{document.querySelectorAll('video').forEach(function(v){if(!v.paused){window.__sbWasP=1;v.pause();}});}catch(e){}", null)
        } catch (_: Throwable) {}
        val curPosSec = (vlcCurrentPosMs() / 1000L).coerceAtLeast(startTimeSec)
        streamUrl = newUrl
        currentSource = newSource
        startTimeSec = curPosSec
        retryCount = 0
        useWebViewProxy = false
        rawPayload.put("url", newUrl)
        rawPayload.put("currentSource", newSource)
        if (refererFallback.isNotEmpty()) {
            rawPayload.put("referer", refererFallback)
        }

        initializeExoPlayer(rawPayload)
    }

    private fun updateSwitchServerButtonText() {
        val readyCount = verifiedServers.keys.count { it != currentSource }
        switchServerBtn?.text = if (readyCount > 0) "Switch Server ($readyCount)" else "Switch Server"
    }

    private fun bestVerifiedServer(excluding: String): Triple<String, String, String>? {
        val curIdx = serverOrder.indexOf(excluding)
        data class Cand(val idx: Int, val src: String, val url: String, val ref: String, val isHls: Boolean)
        val cands = mutableListOf<Cand>()
        for ((src, pair) in verifiedServers) {
            if (src == excluding) continue
            val idx = serverOrder.indexOf(src).let { if (it >= 0) it else 999 }
            val l = pair.first.lowercase()
            val isHls = l.contains(".m3u8") || l.contains(".mpd")
            cands.add(Cand(idx, src, pair.first, pair.second, isHls))
        }
        if (cands.isEmpty()) return null
        cands.sortWith(Comparator { a, b ->
            if (a.isHls != b.isHls) return@Comparator if (a.isHls) -1 else 1
            val aAfter = if (a.idx > curIdx) 0 else 1
            val bAfter = if (b.idx > curIdx) 0 else 1
            if (aAfter != bAfter) return@Comparator aAfter - bAfter
            a.idx - b.idx
        })
        val pick = cands[0]
        return Triple(pick.src, pick.url, pick.ref)
    }

    private fun handleSwitchServer() {
        showControllerTemporarily()
        val items = mutableListOf<String>()
        for (s in multiEmbedSubServers) items.add(s.first)
        items.add("Open HnEmbed Window")
        items.add("Reload HnEmbed")
        showStyledMenuDialog("HnEmbed Servers", items.toTypedArray()) { idx ->
            if (idx < multiEmbedSubServers.size) {
                val chosen = multiEmbedSubServers[idx]
                isSwitchingServer = true
                currentSource = "hnembed"
                pendingNextSource = "hnembed"
                resolverWebView?.evaluateJavascript("(function(){var el=document.querySelector('[data-s-idx=\"${chosen.second}\"]');if(el)el.click();})();", null)
                showCaptchaCard("hnembed")
                Toast.makeText(this, "Selected ${chosen.first}", Toast.LENGTH_SHORT).show()
            } else if (idx == multiEmbedSubServers.size) {
                isSwitchingServer = true
                currentSource = "hnembed"
                pendingNextSource = "hnembed"
                val curUrl = resolverWebView?.url ?: ""
                if (curUrl.isEmpty() || curUrl == "about:blank") {
                    val embedUrl = buildEmbedUrlForSource("hnembed")
                    activeResolverEmbedUrl = embedUrl
                    if (embedUrl.isNotEmpty()) {
                        try {
                            val parsed = Uri.parse(embedUrl)
                            resolverWebView?.loadUrl(embedUrl, mapOf("Referer" to "${parsed.scheme}://${parsed.host}/"))
                        } catch (_: Throwable) {}
                    }
                }
                showCaptchaCard("hnembed")
            } else {
                isSwitchingServer = true
                currentSource = "hnembed"
                pendingNextSource = "hnembed"
                val embedUrl = buildEmbedUrlForSource("hnembed")
                activeResolverEmbedUrl = embedUrl
                if (embedUrl.isNotEmpty()) {
                    try {
                        val parsed = Uri.parse(embedUrl)
                        resolverWebView?.stopLoading()
                        resolverWebView?.loadUrl(embedUrl, mapOf("Referer" to "${parsed.scheme}://${parsed.host}/"))
                    } catch (_: Throwable) {}
                }
                showCaptchaCard("hnembed")
            }
        }
    }

    private fun startBackgroundServerProbing() {
        if (directWebPlayerMode) return
        if (isProbingActive || isFinishing || isDestroyed || streamUrl.startsWith("/")) return
        val root = rootFrameLayout ?: return
        isProbingActive = true
        probeQueue.clear()
        for (src in serverOrder) {
            if (src != currentSource && !probedFailedServers.contains(src) && !verifiedServers.containsKey(src)) {
                probeQueue.addLast(src)
            }
        }
        if (probeQueue.isEmpty()) return
        val slotCount = minOf(2, probeQueue.size)
        for (i in 0 until slotCount) {
            val pwv = WebView(this).apply {
                layoutParams = FrameLayout.LayoutParams(1, 1, Gravity.BOTTOM or Gravity.START)
                alpha = 0.01f
                isClickable = false
                isFocusable = false
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    mediaPlaybackRequiresUserGesture = false
                    loadsImagesAutomatically = true
                    mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                    javaScriptCanOpenWindowsAutomatically = false
                    setSupportMultipleWindows(false)
                    userAgentString = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
                }
                webChromeClient = object : android.webkit.WebChromeClient() {
                    override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean = false
                }
                try {
                    CookieManager.getInstance().setAcceptCookie(true)
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                } catch (_: Throwable) {}
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                        val u = request?.url?.toString() ?: return false
                        val lower = u.lowercase()
                        if (AdBlockerInterceptor.isBlockedUrl(u) || lower.contains("/vast") || lower.contains("vmap") || lower.contains("preroll") || lower.contains("popunder") || lower.contains("chatmate") || lower.contains("chaturbate") || lower.contains("stripchat")) {
                            return true
                        }
                        if (request.isForMainFrame && !lower.contains("hnembed") && !lower.contains("streamingnow") && !lower.contains("cloudflare") && !lower.contains("recaptcha") && !lower.contains("hcaptcha") && !lower.contains("google") && !lower.contains("dood") && !lower.contains("lulu") && !lower.contains("voe") && !lower.contains("filemoon") && !lower.contains("streamwish") && !lower.contains("vidhide") && !lower.contains("mixdrop")) {
                            return true
                        }
                        return false
                    }
                    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                        val u = request?.url?.toString() ?: return null
                        val lower = u.lowercase()
                        val isBadClip = listOf("promo", "teaser", "preroll", "/ad_", "_ad_", "/ads/", "banner", "trailer", "preview", "bumper", "doubleclick", "vast", "vmap").any { lower.contains(it) }
                        val hasRangeHeader = request.requestHeaders?.keys?.any { it.equals("Range", ignoreCase = true) } == true
                        val isSecFetchVideo = request.requestHeaders?.entries?.any { it.key.equals("Sec-Fetch-Dest", ignoreCase = true) && it.value.equals("video", ignoreCase = true) } == true
                        val isNonMediaAsset = listOf(".js", ".css", ".png", ".jpg", ".jpeg", ".webp", ".gif", ".svg", ".woff", ".ttf", ".vtt", ".srt", ".ts", ".m4s", ".aac", ".html", ".json").any { lower.substringBefore("?").endsWith(it) }
                        val isHlsUrl = lower.contains(".m3u8") || lower.contains(".m3u") || lower.contains("master.txt") || lower.contains("playlist.txt") || lower.contains("/hls/") || lower.contains("/hls2/") || lower.contains("/manifest") || lower.contains("type=hls")
                        val isVideo = !directWebPlayerMode && !isBadClip && !isNonMediaAsset && (isSecFetchVideo || isHlsUrl || lower.contains(".mpd") || lower.contains("mime=video") || lower.contains("videoplayback") || lower.contains("googleusercontent.com") || lower.contains("googlevideo.com") || lower.contains(".webm") || lower.contains(".mkv") || (lower.contains(".mp4") && !lower.contains("favicon") && !lower.contains("logo") && !lower.contains("blank")))
                        if (isVideo) {
                            val hdrs = HashMap<String, String>(request.requestHeaders ?: emptyMap())
                            AdBlockerInterceptor.streamHeadersMap[u] = hdrs
                            if (isHlsUrl) streamIsHlsMap[u] = true
                            val reqRef = hdrs.entries.firstOrNull { it.key.equals("referer", ignoreCase = true) }?.value ?: activeResolverEmbedUrl
                            if (reqRef.isNotEmpty()) streamRefererMap[u] = reqRef
                            mainHandler.post {
                                val src = probeSlotSources[this@apply] ?: return@post
                                if (probedFailedServers.contains(src)) return@post
                                val ref = getDefaultRefererForSource(src)
                                verifiedServers[src] = Pair(u, ref)
                                updateSwitchServerButtonText()
                                if (isSwitchingServer && streamUrl.isBlank()) {
                                    applyResolvedStream(u, src, ref)
                                }
                                advanceProbeSlot(this@apply)
                            }
                        } else if (!directWebPlayerMode && AdBlockerInterceptor.isBlockedUrl(u)) {
                            return AdBlockerInterceptor.createEmptyResponse()
                        }
                        return super.shouldInterceptRequest(view, request)
                    }

                    override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: android.webkit.WebResourceError?) {
                        super.onReceivedError(view, request, error)
                        if (directWebPlayerMode && request?.isForMainFrame == true && webErrorRetryCount < 3) {
                            webErrorRetryCount++
                            mainHandler.postDelayed({
                                if (!isFinishing && !isDestroyed) view?.reload()
                            }, 1500L)
                        }
                    }
                    override fun onReceivedHttpError(view: WebView?, request: WebResourceRequest?, errorResponse: WebResourceResponse?) {
                        super.onReceivedHttpError(view, request, errorResponse)
                        if (directWebPlayerMode && request?.isForMainFrame == true && (errorResponse?.statusCode ?: 0) >= 500 && webErrorRetryCount < 3) {
                            webErrorRetryCount++
                            mainHandler.postDelayed({
                                if (!isFinishing && !isDestroyed) view?.reload()
                            }, 1500L)
                        }
                    }
                    override fun onPageFinished(view: WebView?, url: String?) {
                        super.onPageFinished(view, url)
                        if (url != null && !url.startsWith("about:") && !url.startsWith("data:")) webErrorRetryCount = 0
                        if (directWebPlayerMode && view != null && url != null && !url.startsWith("about:") && !url.startsWith("data:")) {
                            val safePrefs = org.json.JSONObject.quote(initialWebPrefsJson)
                            view.evaluateJavascript("try{window.__sbStartSec=" + startTimeSec + ";var wp=JSON.parse(" + safePrefs + ");if(wp&&typeof wp==='object'){Object.keys(wp).forEach(function(k){try{localStorage.setItem(k,wp[k]);}catch(e){}});}}catch(e){}", null)
                        }
                        if (view == null || url == null || url.startsWith("about:")) return
                        val probeJs = "(function(){try{var t=(document.title||'')+' '+(document.body?document.body.innerText.slice(0,500):'');var l=t.toLowerCase();if(l.indexOf('no sources')!==-1||l.indexOf('try again later')!==-1||l.indexOf('404 not found')!==-1||l.indexOf('502 bad gateway')!==-1||l.indexOf('media not found')!==-1||l.indexOf('video not found')!==-1||l.indexOf('not available')!==-1){return 'DEAD';}if(l.indexOf('just a moment')!==-1||l.indexOf('verify you are human')!==-1||l.indexOf('security check')!==-1||!!document.querySelector('iframe[src*=turnstile],iframe[src*=challenge],iframe[src*=captcha],.cf-turnstile,.g-recaptcha,.h-captcha')){return 'CHALLENGE';}document.querySelectorAll('video').forEach(function(v){v.muted=true;try{v.pause();}catch(e){}});document.querySelectorAll('#pl_but,.play,.btn-play,[class*=play],button').forEach(function(b){try{b.click();}catch(e){}});}catch(e){}return '';})()"
                        view.evaluateJavascript(probeJs) { res ->
                            if (res != null && res.contains("DEAD")) {
                                val src = probeSlotSources[view]
                                if (src != null) probedFailedServers.add(src)
                                advanceProbeSlot(view)
                            } else if (res != null && res.contains("CHALLENGE")) {
                                advanceProbeSlot(view)
                            }
                        }
                    }
                }
            }
            probeWebViews.add(pwv)
            root.addView(pwv, 0)
            advanceProbeSlot(pwv)
        }
    }

    private fun advanceProbeSlot(pwv: WebView) {
        probeTimeoutRunnables.remove(pwv)?.let { mainHandler.removeCallbacks(it) }
        probeSlotSources.remove(pwv)
        try { pwv.stopLoading() } catch (_: Throwable) {}
        while (probeQueue.isNotEmpty() && !isFinishing && !isDestroyed) {
            val nextSrc = probeQueue.removeFirst()
            if (nextSrc == currentSource || probedFailedServers.contains(nextSrc) || verifiedServers.containsKey(nextSrc)) continue
            val embed = buildEmbedUrlForSource(nextSrc)
            if (embed.isEmpty()) continue
            probeSlotSources[pwv] = nextSrc
            try {
                val parsed = Uri.parse(embed)
                val originRef = "${parsed.scheme}://${parsed.host}/"
                pwv.loadUrl(embed, mapOf("Referer" to originRef))
            } catch (_: Throwable) {
                probedFailedServers.add(nextSrc)
                continue
            }
            val timeoutRun = Runnable {
                val failedSrc = probeSlotSources[pwv]
                if (failedSrc != null) probedFailedServers.add(failedSrc)
                advanceProbeSlot(pwv)
            }
            probeTimeoutRunnables[pwv] = timeoutRun
            mainHandler.postDelayed(timeoutRun, 6500L)
            return
        }
        try { pwv.loadUrl("about:blank") } catch (_: Throwable) {}
    }

    private fun stopBackgroundServerProbing() {
        isProbingActive = false
        probeQueue.clear()
        for (r in probeTimeoutRunnables.values) mainHandler.removeCallbacks(r)
        probeTimeoutRunnables.clear()
        probeSlotSources.clear()
        for (pwv in probeWebViews) {
            try {
                pwv.stopLoading()
                (pwv.parent as? ViewGroup)?.removeView(pwv)
                pwv.destroy()
            } catch (_: Throwable) {}
        }
        probeWebViews.clear()
    }

    private fun triggerNextServerFailover() {
        if (isLiveStream) return
        if (isFinishing || isDestroyed || streamUrl.startsWith("/") || isSwitchingServer) return
        val best = bestVerifiedServer(currentSource)
        if (best != null) {
            applyResolvedStream(best.second, best.first, best.third)
            updateSwitchServerButtonText()
            return
        }
        if (serverOrder.size == 1 && serverOrder.firstOrNull() == "hnembed") {
            isSwitchingServer = true
            currentSource = "hnembed"
            pendingNextSource = "hnembed"
            val curUrl = resolverWebView?.url ?: ""
            if (curUrl.isEmpty() || curUrl == "about:blank") {
                val embedUrl = buildEmbedUrlForSource("hnembed")
                activeResolverEmbedUrl = embedUrl
                if (embedUrl.isNotEmpty()) {
                    try {
                        val parsed = Uri.parse(embedUrl)
                        resolverWebView?.loadUrl(embedUrl, mapOf("Referer" to "${parsed.scheme}://${parsed.host}/"))
                    } catch (_: Throwable) {}
                }
            }
            
            showCaptchaCard("hnembed")
            return
        }
        if (serverFailoverAttempts >= serverOrder.size) {
            Toast.makeText(
                this@NativeExoPlayerActivity,
                "All servers tried — tap Switch Server to retry",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        isSwitchingServer = true
        serverFailoverAttempts++
        val resumeSec = (vlcCurrentPosMs() / 1000L).coerceAtLeast(startTimeSec)
        startTimeSec = resumeSec
        val idx = serverOrder.indexOf(currentSource)
        var nextExpected = serverOrder[(idx + 1) % serverOrder.size]
        for (step in 1..serverOrder.size) {
            val cand = serverOrder[(idx + step) % serverOrder.size]
            if (!probedFailedServers.contains(cand)) {
                nextExpected = cand
                break
            }
        }
        pendingNextSource = nextExpected
        serverBadgeView?.text = nextExpected
        val embedUrl = buildEmbedUrlForSource(nextExpected)
        activeResolverEmbedUrl = embedUrl
        Toast.makeText(
            this@NativeExoPlayerActivity,
            "Switching to $nextExpected...",
            Toast.LENGTH_SHORT
        ).show()
        mainHandler.removeCallbacks(failoverWatchdogRunnable)
        mainHandler.removeCallbacks(playbackReadyWatchdogRunnable)
        mainHandler.postDelayed(failoverWatchdogRunnable, 7500L)

        if (embedUrl.isNotEmpty()) {
            loadEmbedUrlDirect(embedUrl)
        }

        val requestedFrom = currentSource
        onNeedNextServer?.invoke(requestedFrom, resumeSec) { newUrl, newSource ->
            runOnUiThread {
                if (!newUrl.isNullOrEmpty() && isSwitchingServer) {
                    applyResolvedStream(
                        newUrl,
                        if (!newSource.isNullOrEmpty()) newSource else nextExpected,
                        getDefaultRefererForSource(nextExpected)
                    )
                }
            }
        }
    }

    private val hideControllerRunnable = Runnable {
        if (vlcIsPlaying() && !isScrubbing) {
            setControllerVisible(false)
        }
    }

    private val progressRunnable = object : Runnable {
        override fun run() {
            saveCurrentProgress()
            mainHandler.postDelayed(this, 2000L)
        }
    }

    private val uiTickRunnable = object : Runnable {
        override fun run() {
            updateTimeAndSeekBar()
            updateSkipAndNextEpisodeUi()
            mainHandler.postDelayed(this, 250L)
        }
    }

    private val subtitleTickRunnable = object : Runnable {
        override fun run() {
            updateLiveSubtitleOverlay()
            mainHandler.postDelayed(this, 120L)
        }
    }

    private fun dp(v: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            v.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    override fun attachBaseContext(newBase: Context) {
        Locale.setDefault(Locale.US)
        val cfg = android.content.res.Configuration(newBase.resources.configuration)
        cfg.setLocale(Locale.US)
        cfg.setLayoutDirection(Locale.US)
        super.attachBaseContext(newBase.createConfigurationContext(cfg))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Locale.setDefault(Locale.US)
        super.onCreate(savedInstanceState)
        isPlayerActive = true
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_LTR

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                window.decorView.defaultFocusHighlightEnabled = false
            }

            val root = FrameLayout(this).apply {
                clipChildren = false
                clipToPadding = false
                setBackgroundColor(Color.BLACK)
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    defaultFocusHighlightEnabled = false
                }
            }

            val pv = VLCVideoLayout(this).apply {
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                keepScreenOn = true
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    defaultFocusHighlightEnabled = false
                }
            }
            val resWv = WebView(this).apply {
                try {
                    if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.DOCUMENT_START_SCRIPT)) {
                        val docStartJs = """(function(){try{if(window.__sSniff)return;window.__sSniff=1;window.__sbIsStreamFrame=false;try{window.open=function(){return null;};}catch(e){}var resM3u=function(tx,base){try{var lines=tx.replace(/\uFEFF/g,'').split(/\r?\n/);var out=[];for(var k=0;k<lines.length;k++){var ln=lines[k].trim();if(!ln){continue;}if(ln.charAt(0)==='#'){out.push(lines[k].replace(/URI="([^"]+)"/g,function(m,u){try{return 'URI="'+new URL(u,base).href+'"';}catch(e){return m;}}));}else{try{out.push(new URL(ln,base).href);}catch(e){out.push(ln);}}}return out.join('\n');}catch(e){return tx;}};var extUrls=function(str){if(!str||typeof str!=='string')return [];var out=[];var parts=str.split(/["'\s,;|<>]+/);for(var i=0;i<parts.length;i++){var p=parts[i].split('\\/').join('/');if(p.indexOf(']')!==-1)p=p.slice(p.lastIndexOf(']')+1);if(p.indexOf('http')===0&&(p.indexOf('.m3u8')!==-1||p.indexOf('.mp4')!==-1||p.indexOf('.mpd')!==-1||p.indexOf('/hls/')!==-1||p.indexOf('master.txt')!==-1||p.indexOf('playlist.txt')!==-1))out.push(p);}return out;};var postS=function(u,h,fv){if(!u||typeof u!=='string'||u.indexOf('blob:')===0||u.indexOf('data:')===0)return;try{u=new URL(u,location.href).href;}catch(e){}if(u.indexOf('http')!==0)return;var l=u.toLowerCase();if((l.indexOf('.ts')!==-1||l.indexOf('.m4s')!==-1)&&l.indexOf('.m3u8')===-1)return;var isH=!!h||l.indexOf('.m3u8')!==-1||l.indexOf('.m3u')!==-1||l.indexOf('master.txt')!==-1||l.indexOf('playlist.txt')!==-1||l.indexOf('/hls/')!==-1||l.indexOf('/hls2/')!==-1||l.indexOf('/manifest')!==-1||l.indexOf('type=hls')!==-1;if(fv||isH||l.indexOf('.mpd')!==-1||l.indexOf('.mp4')!==-1||l.indexOf('.webm')!==-1||l.indexOf('.mkv')!==-1||l.indexOf('videoplayback')!==-1||l.indexOf('googleusercontent.com')!==-1||l.indexOf('mime=video')!==-1){window.__sbIsStreamFrame=true;try{AndroidSniffer.onStream(u,location.href,isH);}catch(e){}}};var scanPerf=function(){try{if(window.performance&&performance.getEntriesByType){performance.getEntriesByType('resource').forEach(function(e){if(e&&e.name)postS(e.name,false,false);});}}catch(e){}};var origFetchRef=window.fetch?window.fetch.bind(window):null;var doProxyFetch=function(id,url,rng){if(!origFetchRef){try{AndroidSniffer.onProxyBytes(id,0,'');}catch(e){}return;}var sendBlob=function(r){return r.blob().then(function(b){var fr=new FileReader();fr.onloadend=function(){try{var s=String(fr.result||'');var idx=s.indexOf(',');AndroidSniffer.onProxyBytes(id,r.status,idx>=0?s.slice(idx+1):'');}catch(e){try{AndroidSniffer.onProxyBytes(id,0,'');}catch(e2){}}};fr.onerror=function(){try{AndroidSniffer.onProxyBytes(id,0,'');}catch(e){}};fr.readAsDataURL(b);});};var hdrs=rng?{Range:rng}:{};var opt1=rng?{headers:hdrs}:{};var opt2=rng?{credentials:'include',headers:hdrs}:{credentials:'include'};origFetchRef(url,opt1).then(function(r){if(r.ok)return sendBlob(r);return origFetchRef(url,opt2).then(function(r2){if(!r2.ok){try{AndroidSniffer.onProxyBytes(id,r2.status,'');}catch(e){}return;}return sendBlob(r2);});}).catch(function(){origFetchRef(url,opt2).then(function(r2){if(!r2.ok){try{AndroidSniffer.onProxyBytes(id,r2.status,'');}catch(e){}return;}return sendBlob(r2);}).catch(function(){try{AndroidSniffer.onProxyBytes(id,0,'');}catch(e){}});});};window.addEventListener('message',function(ev){try{var d=ev&&ev.data;if(!d)return;if(d.__sbResume){window.__sbStopped=false;}if(!d.__sbFetch)return;if(d.__sbStop){window.__sbStopped=true;document.querySelectorAll('video,audio').forEach(function(v){try{v.pause();v.muted=true;}catch(e){}});var frs=document.querySelectorAll('iframe');for(var j=0;j<frs.length;j++){try{frs[j].contentWindow.postMessage(d,'*');}catch(e){}}return;}if(window.__sbIsStreamFrame){doProxyFetch(d.__sbFetch,d.url,d.range||'');return;}var frs2=document.querySelectorAll('iframe');if(frs2.length>0){for(var j2=0;j2<frs2.length;j2++){try{frs2[j2].contentWindow.postMessage(d,'*');}catch(e){}}}else{doProxyFetch(d.__sbFetch,d.url,d.range||'');}}catch(e){}});try{var _pjs;Object.defineProperty(window,'Playerjs',{configurable:true,get:function(){return _pjs;},set:function(fn){if(typeof fn==='function'){_pjs=function(cfg){try{if(cfg&&cfg.file)extUrls(String(cfg.file)).forEach(function(u){postS(u,u.indexOf('.m3u8')!==-1||u.indexOf('.txt')!==-1,true);});}catch(e){}return fn.apply(this,arguments);};}else{_pjs=fn;}}});}catch(e){}try{var sDesc=Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype,'src');if(sDesc&&sDesc.set){var oSet=sDesc.set;Object.defineProperty(HTMLMediaElement.prototype,'src',{set:function(v){try{postS(v,false,false);}catch(e){}return oSet.call(this,v);},get:sDesc.get,configurable:true});}}catch(e){}try{var oPlay=HTMLMediaElement.prototype.play;HTMLMediaElement.prototype.play=function(){try{scanPerf();if(this.src&&this.src.indexOf('http')===0)postS(this.src,false,true);if(this.currentSrc&&this.currentSrc.indexOf('http')===0)postS(this.currentSrc,false,true);}catch(e){}return oPlay.apply(this,arguments);};}catch(e){}if(window.URL&&URL.createObjectURL){var oc=URL.createObjectURL;URL.createObjectURL=function(obj){try{if(obj&&typeof obj.size==='number'&&obj.size>16&&obj.size<512000&&typeof obj.text==='function'){obj.text().then(function(tx){if(tx&&tx.replace(/\uFEFF/g,'').trim().indexOf('#EXTM3U')===0){window.__sbIsStreamFrame=true;AndroidSniffer.onInlineM3u8(resM3u(tx,location.href),location.href);}}).catch(function(){});}}catch(e){}return oc.apply(this,arguments);};}if(window.fetch){var of=window.fetch;window.fetch=function(i){var u=typeof i==='string'?i:(i&&i.url);postS(u,false,false);return of.apply(this,arguments).then(function(r){try{var ct=(r&&r.headers&&r.headers.get('content-type')||'').toLowerCase();var ru=r.url||u;var isH=ct.indexOf('mpegurl')!==-1;if(isH||ct.indexOf('video/')===0||ct.indexOf('dash+xml')!==-1){postS(ru,isH,true);}if(ru){var cl=ru.split('?')[0].toLowerCase();if(!cl.endsWith('.css')&&!cl.endsWith('.svg')&&!cl.endsWith('.ico')&&!cl.endsWith('.woff2')&&!cl.endsWith('.ts')&&!cl.endsWith('.m4s')){r.clone().text().then(function(tx){if(!tx)return;var hd=tx.slice(0,64).replace(/\uFEFF/g,'').trim();if(hd.indexOf('#EXTM3U')===0){window.__sbIsStreamFrame=true;AndroidSniffer.onInlineM3u8(resM3u(tx,ru),location.href);postS(ru,true,true);}else if(tx.length<300000&&(tx.indexOf('.m3u8')!==-1||tx.indexOf('.mp4')!==-1)){extUrls(tx).forEach(function(eu){postS(eu,eu.indexOf('.m3u8')!==-1,true);});}}).catch(function(){});}}}catch(e){}return r;});};}if(window.XMLHttpRequest){var oo=XMLHttpRequest.prototype.open;var os=XMLHttpRequest.prototype.send;XMLHttpRequest.prototype.open=function(m,u){this._su=u;postS(u,false,false);return oo.apply(this,arguments);};XMLHttpRequest.prototype.send=function(){this.addEventListener('readystatechange',function(){if(this.readyState===4&&this.status>=200&&this.status<400){try{var ct=(this.getResponseHeader('content-type')||'').toLowerCase();var ru=this.responseURL||this._su;var isH=ct.indexOf('mpegurl')!==-1;var bh=false;if((this.responseType===''||this.responseType==='text')&&typeof this.responseText==='string'){var hd=this.responseText.slice(0,64).replace(/\uFEFF/g,'').trim();if(hd.indexOf('#EXTM3U')===0){bh=true;window.__sbIsStreamFrame=true;AndroidSniffer.onInlineM3u8(resM3u(this.responseText,ru||location.href),location.href);}else if(this.responseText.length<300000&&(this.responseText.indexOf('.m3u8')!==-1||this.responseText.indexOf('.mp4')!==-1)){extUrls(this.responseText).forEach(function(eu){postS(eu,eu.indexOf('.m3u8')!==-1,true);});}}else if(!isH&&this.responseType==='arraybuffer'&&this.response&&this.response.byteLength>=7){var arr=new Uint8Array(this.response,0,Math.min(32,this.response.byteLength));var hs='';for(var k=0;k<arr.length;k++)hs+=String.fromCharCode(arr[k]);if(hs.replace(/\uFEFF/g,'').trim().indexOf('#EXTM3U')===0){bh=true;window.__sbIsStreamFrame=true;}}if(isH||bh||ct.indexOf('video/')===0||ct.indexOf('dash+xml')!==-1){postS(ru,isH||bh,true);}}catch(e){}}});return os.apply(this,arguments);};}setInterval(function(){try{document.querySelectorAll('video').forEach(function(v){var isF=(isFinite(v.duration)&&v.duration>=60)||(!v.paused&&v.currentTime>0.2);if(isF){scanPerf();}if(v.src&&v.src.indexOf('http')===0){postS(v.src,false,isF);if(isF){v.pause();v.muted=true;}}if(v.currentSrc&&v.currentSrc.indexOf('http')===0){postS(v.currentSrc,false,isF);if(isF){v.pause();v.muted=true;}}});}catch(e){}if(!window.__sbStopped){var bs=document.querySelectorAll('#pl_but,.play,.btn-play,.vjs-big-play-button,.jw-icon-display,[aria-label*=Play],button[class*=play]');for(var bi=0;bi<bs.length;bi++){try{bs[bi].click();}catch(e){}}}},1200);}catch(e){}})();"""
                        androidx.webkit.WebViewCompat.addDocumentStartJavaScript(this, docStartJs, setOf("*"))
                    }
                } catch (_: Throwable) {}
                addJavascriptInterface(object {
                    @android.webkit.JavascriptInterface
                    fun onServers(json: String) {
                        try {
                            val arr = JSONArray(json)
                            val parsed = mutableListOf<Pair<String, String>>()
                            for (i in 0 until arr.length()) {
                                val o = arr.optJSONObject(i) ?: continue
                                val n = o.optString("name").trim()
                                val ix = o.optString("idx").trim()
                                if (n.isNotEmpty() && ix.isNotEmpty()) parsed.add(Pair(n, ix))
                            }
                            if (parsed.isNotEmpty()) {
                                mainHandler.post {
                                    multiEmbedSubServers.clear()
                                    multiEmbedSubServers.addAll(parsed)
                                    switchServerBtn?.text = "Servers (${parsed.size}) ▾"
                                }
                            }
                        } catch (_: Throwable) {}
                    }
                    @android.webkit.JavascriptInterface
                    fun onInlineM3u8(m3u8: String, ref: String) {
                        if (m3u8.isBlank()) return
                        val lowerM = m3u8.lowercase()
                        val isMaster = lowerM.contains("#ext-x-stream-inf")
                        val isSubOnly = !isMaster && (lowerM.contains(".vtt") || lowerM.contains("webvtt") || lowerM.contains(".srt"))
                        if (isSubOnly) return
                        try {
                            val f = File(cacheDir, "inline_${System.currentTimeMillis()}.m3u8")
                            f.writeText(m3u8)
                            val localPath = f.absolutePath
                            if (isMaster || lastInlineM3u8Path.isEmpty()) {
                                lastInlineM3u8Path = localPath
                                lastInlineM3u8Ref = ref
                            }
                            streamIsHlsMap[localPath] = true
                            if (ref.isNotBlank()) streamRefererMap[localPath] = ref
                            val srcTag = pendingNextSource.ifEmpty { currentSource }
                            mainHandler.post {
                                val alreadyPlayingInline = streamUrl.startsWith("/") && vlcPlayer != null
                                if (!alreadyPlayingInline && (isSwitchingServer || isCaptchaCardVisible || streamUrl.isBlank())) {
                                    applyResolvedStream(localPath, srcTag, ref.ifBlank { activeResolverEmbedUrl })
                                }
                            }
                        } catch (_: Throwable) {}
                    }
                    @android.webkit.JavascriptInterface
                    fun onWakeTap() {
                        mainHandler.post {
                            resolverWebView?.let { wv ->
                                try {
                                    val t = android.os.SystemClock.uptimeMillis()
                                    val tx = wv.width.coerceAtLeast(360) * 0.5f
                                    val ty = wv.height.coerceAtLeast(250) * 0.25f
                                    wv.dispatchTouchEvent(MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, tx, ty, 0))
                                    wv.dispatchTouchEvent(MotionEvent.obtain(t, t + 30L, MotionEvent.ACTION_UP, tx, ty, 0))
                                } catch (_: Throwable) {}
                            }
                        }
                    }
                    @android.webkit.JavascriptInterface
                    fun onWebProgress(posSec: Long, durSec: Long, isPlaying: Boolean) {
                        val pk = progressKey ?: return
                        if (durSec <= 10L) return
                        val pct = ((posSec * 100L) / durSec).toInt().coerceIn(0, 100)
                        val watched = pct >= 90
                        mainHandler.post {
                            ExoProgressBus.listener?.invoke(pk, pct, posSec, durSec, watched, isPlaying)
                        }
                    }
                    @android.webkit.JavascriptInterface
                    fun onWebPrefs(prefsJson: String) {
                        if (prefsJson.length < 3) return
                        mainHandler.post {
                            ExoProgressBus.webPrefsListener?.invoke(prefsJson)
                        }
                    }
                    @android.webkit.JavascriptInterface
                    fun onWebBack() {
                        mainHandler.post {
                            if (!isFinishing && !isDestroyed) {
                                saveCurrentProgress(isPlayingOverride = false)
                                resolverWebView?.visibility = View.GONE
                                finish()
                            }
                        }
                    }
                    @android.webkit.JavascriptInterface
                    fun onStream(u: String, ref: String, isHls: Boolean) {
                        if (directWebPlayerMode || u.isBlank() || !u.startsWith("http")) return
                        val l = u.lowercase()
                        val bad = listOf("promo", "teaser", "preroll", "/ad_", "_ad_", "/ads/", "banner", "trailer", "preview", "bumper", "doubleclick", "vast", "vmap").any { l.contains(it) }
                        if (bad) return
                        lastRemoteStreamUrl = u
                        if (isHls) streamIsHlsMap[u] = true
                        if (ref.isNotBlank()) streamRefererMap[u] = ref
                        val srcTag = pendingNextSource.ifEmpty { currentSource }
                        mainHandler.post {
                            if (isSwitchingServer || isCaptchaCardVisible || streamUrl.isBlank()) {
                                applyResolvedStream(u, srcTag, ref.ifBlank { activeResolverEmbedUrl })
                            }
                        }
                    }
                    @android.webkit.JavascriptInterface
                    fun onProxyBytes(reqId: String, status: Int, b64: String) {
                        if (status in 200..299 && b64.isNotEmpty()) {
                            val fut = proxyWaiters.remove(reqId) ?: return
                            try {
                                val bytes = android.util.Base64.decode(b64, android.util.Base64.DEFAULT)
                                fut.complete(Pair(status, bytes))
                            } catch (_: Throwable) {
                                fut.complete(Pair(0, null))
                            }
                        } else if (status >= 400) {
                            proxyWaiters.remove(reqId)?.complete(Pair(status, null))
                        }
                    }
                }, "AndroidSniffer")
                setBackgroundColor(Color.BLACK)
                layoutParams = FrameLayout.LayoutParams(dp(360), dp(250), Gravity.BOTTOM or Gravity.START)
                translationX = -dp(5000).toFloat()
                alpha = 0f
                isClickable = false
                isFocusable = false
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    mediaPlaybackRequiresUserGesture = false
                    loadsImagesAutomatically = true
                    javaScriptCanOpenWindowsAutomatically = false
                    setSupportMultipleWindows(false)
                    setSupportZoom(false)
                    builtInZoomControls = false
                    displayZoomControls = false
                    userAgentString = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"
                }
                webChromeClient = object : android.webkit.WebChromeClient() {
                    override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean = false
                    override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                        callback?.onCustomViewHidden()
                    }
                }
                try {
                    CookieManager.getInstance().setAcceptCookie(true)
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                } catch (_: Throwable) {}
                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(
                        view: WebView?,
                        request: WebResourceRequest?
                    ): WebResourceResponse? {
                        if (directWebPlayerMode) return super.shouldInterceptRequest(view, request)
                        val u = request?.url?.toString() ?: return null
                        val lower = u.lowercase()
                        val isChallenge = lower.contains("challenges.cloudflare.com") || lower.contains("recaptcha/api") || lower.contains("hcaptcha.com/1/api") || lower.contains("turnstile/v0/api") || lower.contains("arkoselabs.com")
                        if (isChallenge) {
                            mainHandler.post {
                                if (isSwitchingServer) {
                                    mainHandler.removeCallbacks(failoverWatchdogRunnable)
                                    if (!isCaptchaCardVisible) {
                                        showCaptchaCard(pendingNextSource.ifEmpty { currentSource })
                                    }
                                }
                            }
                            return super.shouldInterceptRequest(view, request)
                        }
                        val isBadClip = listOf("promo", "teaser", "preroll", "/ad_", "_ad_", "/ads/", "banner", "trailer", "preview", "bumper", "doubleclick", "vast", "vmap").any { lower.contains(it) }
                        val isHlsUrl = lower.contains(".m3u8") || lower.contains(".m3u") || lower.contains("master.txt") || lower.contains("playlist.txt") || lower.contains("/hls/") || lower.contains("/hls2/") || lower.contains("/manifest") || lower.contains("type=hls")
                        val isSecFetchVideo = request.requestHeaders?.entries?.any { it.key.equals("Sec-Fetch-Dest", ignoreCase = true) && it.value.equals("video", ignoreCase = true) } == true
                        val isVideo = !isBadClip && (isSecFetchVideo || isHlsUrl || lower.contains(".mpd") || lower.contains("mime=video") || lower.contains("videoplayback") || lower.contains("googleusercontent.com") || lower.contains("googlevideo.com") || lower.contains(".webm") || lower.contains(".mkv") || (lower.contains(".mp4") && !lower.contains("favicon") && !lower.contains("preview") && !lower.contains("trailer") && !lower.contains("logo") && !lower.contains("preroll") && !lower.contains("blank") && !lower.contains("loading.mp4") && !lower.contains("intro.mp4") && !lower.contains("outro.mp4")))
                        if (isVideo) {
                            val hdrs = HashMap<String, String>(request.requestHeaders ?: emptyMap())
                            val hasRef = hdrs.keys.any { it.equals("referer", ignoreCase = true) }
                            if (!hasRef && activeResolverEmbedUrl.isNotEmpty()) {
                                hdrs["Referer"] = activeResolverEmbedUrl
                            }
                            AdBlockerInterceptor.streamHeadersMap[u] = hdrs
                            if (isHlsUrl) streamIsHlsMap[u] = true
                            val reqRef = hdrs.entries.firstOrNull { it.key.equals("referer", ignoreCase = true) }?.value ?: activeResolverEmbedUrl
                            if (reqRef.isNotEmpty()) streamRefererMap[u] = reqRef
                            val srcTag = pendingNextSource.ifEmpty { currentSource }
                            mainHandler.post {
                                if (isSwitchingServer || isCaptchaCardVisible || streamUrl.isBlank()) {
                                    applyResolvedStream(u, srcTag, reqRef)
                                }
                            }
                        } else if (AdBlockerInterceptor.isBlockedUrl(u)) {
                            return AdBlockerInterceptor.createEmptyResponse()
                        }
                        return super.shouldInterceptRequest(view, request)
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        super.onPageFinished(view, url)
                        if (view == null || url == null || url.startsWith("about:")) return
                        val clickJs = "(function(){try{if(!window.__sSniff){window.__sSniff=1;try{window.open=function(){return null;};}catch(e){}var postS=function(u,h,fv){if(!u||typeof u!=='string'||u.indexOf('blob:')===0||u.indexOf('data:')===0)return;try{u=new URL(u,location.href).href;}catch(e){}if(u.indexOf('http')!==0)return;var l=u.toLowerCase();if((l.indexOf('.ts')!==-1||l.indexOf('.m4s')!==-1)&&l.indexOf('.m3u8')===-1)return;var isH=!!h||l.indexOf('.m3u8')!==-1||l.indexOf('master.txt')!==-1||l.indexOf('playlist.txt')!==-1||l.indexOf('/hls/')!==-1||l.indexOf('/hls2/')!==-1||l.indexOf('type=hls')!==-1;if(fv||isH||l.indexOf('.mpd')!==-1||l.indexOf('.mp4')!==-1||l.indexOf('.webm')!==-1||l.indexOf('.mkv')!==-1||l.indexOf('videoplayback')!==-1||l.indexOf('googleusercontent.com')!==-1||l.indexOf('mime=video')!==-1){try{AndroidSniffer.onStream(u,location.href,isH);}catch(e){}}};if(window.URL&&URL.createObjectURL){var oc=URL.createObjectURL;URL.createObjectURL=function(obj){try{if(obj&&typeof obj.size==='number'&&obj.size>16&&obj.size<512000&&typeof obj.text==='function'){obj.text().then(function(tx){if(tx&&tx.trim().indexOf('#EXTM3U')===0)AndroidSniffer.onInlineM3u8(tx,location.href);}).catch(function(){});}}catch(e){}return oc.apply(this,arguments);};}if(window.fetch){var of=window.fetch;window.fetch=function(i){var u=typeof i==='string'?i:(i&&i.url);postS(u,false,false);return of.apply(this,arguments).then(function(r){try{var ct=(r&&r.headers&&r.headers.get('content-type')||'').toLowerCase();var ru=r.url||u;var isH=ct.indexOf('mpegurl')!==-1;if(isH||ct.indexOf('video/mp4')!==-1||ct.indexOf('video/webm')!==-1){postS(ru,isH,true);}else if(ru){var cl=ru.split('?')[0].toLowerCase();if(!cl.endsWith('.css')&&!cl.endsWith('.svg')&&!cl.endsWith('.ico')&&!cl.endsWith('.woff2')){r.clone().text().then(function(tx){if(tx&&tx.slice(0,64).trim().indexOf('#EXTM3U')===0)postS(ru,true,true);}).catch(function(){});}}}catch(e){}return r;});};}if(window.XMLHttpRequest){var oo=XMLHttpRequest.prototype.open;var os=XMLHttpRequest.prototype.send;XMLHttpRequest.prototype.open=function(m,u){this._su=u;postS(u,false,false);return oo.apply(this,arguments);};XMLHttpRequest.prototype.send=function(){this.addEventListener('readystatechange',function(){if(this.readyState===4&&this.status>=200&&this.status<400){try{var ct=(this.getResponseHeader('content-type')||'').toLowerCase();var ru=this.responseURL||this._su;var isH=ct.indexOf('mpegurl')!==-1;var bh=!isH&&(this.responseType===''||this.responseType==='text')&&typeof this.responseText==='string'&&this.responseText.slice(0,64).trim().indexOf('#EXTM3U')===0;if(isH||bh||ct.indexOf('video/mp4')!==-1||ct.indexOf('video/webm')!==-1){postS(ru,isH||bh,true);}}catch(e){}}});return os.apply(this,arguments);};}}var t=(document.title||'')+' '+(document.body?document.body.innerText.slice(0,500):'');var l=t.toLowerCase();if(l.indexOf('no sources')!==-1||l.indexOf('404 not found')!==-1||l.indexOf('502 bad gateway')!==-1||l.indexOf('media not found')!==-1||l.indexOf('video not found')!==-1){return 'DEAD';}var w=!!document.querySelector('iframe[src*=challenges\\.cloudflare\\.com],iframe[src*=turnstile],iframe[src*=challenge],iframe[src*=captcha],iframe[src*=recaptcha],iframe[src*=hcaptcha],.cf-turnstile,.g-recaptcha,.h-captcha,#cf-turnstile-response,#cf-challenge-running,[id*=turnstile],[class*=turnstile],[class*=geetest]');if(w||l.indexOf('just a moment')!==-1||l.indexOf('verify you are human')!==-1||l.indexOf('security check')!==-1||l.indexOf('are you a robot')!==-1){return 'CHALLENGE';}try{var sl=[];var sn={};var cs=document.querySelectorAll('.servers li,.servers a,.servers button,.servers div,[class*=server] li,[class*=server] a,[class*=server] button,[class*=server] div,[data-server],[data-id],[data-hash]');var sx=0;cs.forEach(function(el){var lb=(el.innerText||el.textContent||'').replace(/\\s+/g,' ').trim();if(!lb||lb.length>60||lb.toLowerCase()==='servers'||lb.toLowerCase()==='server'||lb.toLowerCase().indexOf('go to website')!==-1)return;if(sn[lb])return;sn[lb]=1;var ky='s'+(sx++);el.setAttribute('data-s-idx',ky);sl.push({name:lb,idx:ky});});if(sl.length>0)AndroidSniffer.onServers(JSON.stringify(sl));}catch(e){}document.querySelectorAll('button,div,span,a').forEach(function(el){var tx=(el.innerText||'').trim().toLowerCase();if(tx==='skip ad'||tx==='skip ads'){try{el.click();}catch(e){}}});if(typeof window.jwplayer==='function'){try{var jw=window.jwplayer();var it=jw&&jw.getPlaylistItem&&jw.getPlaylistItem();if(it){if(it.file)postS(it.file,it.file.indexOf('.m3u8')!==-1||it.type==='hls',true);if(Array.isArray(it.sources))it.sources.forEach(function(s){if(s&&s.file)postS(s.file,s.file.indexOf('.m3u8')!==-1||s.type==='hls',true);});}}catch(e){}}var clickP=function(){document.querySelectorAll('#pl_but,.play,.btn-play,.vjs-big-play-button,.jw-icon-display').forEach(function(b){try{b.click();}catch(e){}});};clickP();setTimeout(clickP,650);var scanV=function(){document.querySelectorAll('video').forEach(function(v){var isP=v.videoHeight>0&&v.videoWidth>0&&v.videoHeight>v.videoWidth*0.95;var isS=isFinite(v.duration)&&v.duration>0&&v.duration<120;if(isP||isS){v.muted=true;try{v.style.display='none';if(isFinite(v.duration)&&v.duration>1&&v.currentTime<v.duration-0.2)v.currentTime=v.duration-0.05;document.querySelectorAll('div,a,button').forEach(function(el){var tx=(el.innerText||'').trim().toLowerCase();if(tx==='skip ad'||tx==='skip ads'){try{el.click();}catch(e){}}else if(tx==='go to website'||tx.indexOf('install ')===0){try{el.style.display='none';}catch(e){}}});}catch(e){}return;}var isF=(isFinite(v.duration)&&v.duration>=60)||(!v.paused&&v.currentTime>0.2);if(v.src)postS(v.src,false,isF);if(v.currentSrc)postS(v.currentSrc,false,isF);if(isF){try{document.querySelectorAll('a[download],a[href*=\".mp4\"],a[href*=\".m3u8\"]').forEach(function(a){if(a.href)postS(a.href,a.href.indexOf('.m3u8')!==-1,true);});if(window.player&&typeof window.player.api==='function'){var pf=window.player.api('file');if(pf&&typeof pf==='string')postS(pf,pf.indexOf('.m3u8')!==-1,true);}}catch(e){}}});};scanV();setTimeout(scanV,900);setTimeout(scanV,2000);}catch(e){}return '';})()"
                        mainHandler.postDelayed({
                            if (!isFinishing && !isDestroyed && streamUrl.isBlank()) triggerResolverPlayFromUserTap()
                        }, 1200L)
                        mainHandler.postDelayed({
                            if (!isFinishing && !isDestroyed && streamUrl.isBlank()) triggerResolverPlayFromUserTap()
                        }, 2800L)
                        if (!directWebPlayerMode) view.evaluateJavascript(clickJs) { res ->
                            if (res != null && res.contains("CHALLENGE") && isSwitchingServer && !isCaptchaCardVisible) {
                                mainHandler.removeCallbacks(failoverWatchdogRunnable)
                                showCaptchaCard(pendingNextSource.ifEmpty { currentSource })
                            } else if (res != null && res.contains("DEAD") && isSwitchingServer) {
                                mainHandler.removeCallbacks(failoverWatchdogRunnable)
                                failoverWatchdogRunnable.run()
                            }
                        }
                    }
                }
            }
            rootFrameLayout = root
            val docStartSniffJs = "(function(){try{if(window.__sSniff)return;window.__sSniff=1;try{window.open=function(){return null;};}catch(e){}var postS=function(u,h,fv){if(!u||typeof u!=='string'||u.indexOf('blob:')===0||u.indexOf('data:')===0)return;try{u=new URL(u,location.href).href;}catch(e){}if(u.indexOf('http')!==0)return;var l=u.toLowerCase();if((l.indexOf('.ts')!==-1||l.indexOf('.m4s')!==-1)&&l.indexOf('.m3u8')===-1)return;var isH=!!h||l.indexOf('.m3u8')!==-1||l.indexOf('master.txt')!==-1||l.indexOf('playlist.txt')!==-1||l.indexOf('/hls/')!==-1||l.indexOf('/hls2/')!==-1||l.indexOf('type=hls')!==-1;if(fv||isH||l.indexOf('.mpd')!==-1||l.indexOf('.mp4')!==-1||l.indexOf('.webm')!==-1||l.indexOf('.mkv')!==-1||l.indexOf('videoplayback')!==-1||l.indexOf('googleusercontent.com')!==-1||l.indexOf('mime=video')!==-1){try{AndroidSniffer.onStream(u,location.href,isH);}catch(e){}}};if(window.URL&&URL.createObjectURL){var oc=URL.createObjectURL;URL.createObjectURL=function(obj){try{if(obj&&typeof obj.size==='number'&&obj.size>16&&obj.size<512000&&typeof obj.text==='function'){obj.text().then(function(tx){if(tx&&tx.trim().indexOf('#EXTM3U')===0)AndroidSniffer.onInlineM3u8(tx,location.href);}).catch(function(){});}}catch(e){}return oc.apply(this,arguments);};}if(window.fetch){var of=window.fetch;window.fetch=function(i){var u=typeof i==='string'?i:(i&&i.url);postS(u,false,false);return of.apply(this,arguments).then(function(r){try{var ct=(r&&r.headers&&r.headers.get('content-type')||'').toLowerCase();var ru=r.url||u;var isH=ct.indexOf('mpegurl')!==-1;if(isH||ct.indexOf('video/mp4')!==-1||ct.indexOf('video/webm')!==-1){postS(ru,isH,true);}else if(ru){var cl=ru.split('?')[0].toLowerCase();if(!cl.endsWith('.css')&&!cl.endsWith('.svg')&&!cl.endsWith('.ico')&&!cl.endsWith('.woff2')){r.clone().text().then(function(tx){if(tx&&tx.slice(0,64).trim().indexOf('#EXTM3U')===0)postS(ru,true,true);}).catch(function(){});}}}catch(e){}return r;});};}if(window.XMLHttpRequest){var oo=XMLHttpRequest.prototype.open;var os=XMLHttpRequest.prototype.send;XMLHttpRequest.prototype.open=function(m,u){this._su=u;postS(u,false,false);return oo.apply(this,arguments);};XMLHttpRequest.prototype.send=function(){this.addEventListener('readystatechange',function(){if(this.readyState===4&&this.status>=200&&this.status<400){try{var ct=(this.getResponseHeader('content-type')||'').toLowerCase();var ru=this.responseURL||this._su;var isH=ct.indexOf('mpegurl')!==-1;var bh=!isH&&(this.responseType===''||this.responseType==='text')&&typeof this.responseText==='string'&&this.responseText.slice(0,64).trim().indexOf('#EXTM3U')===0;if(isH||bh||ct.indexOf('video/mp4')!==-1||ct.indexOf('video/webm')!==-1){postS(ru,isH||bh,true);}}catch(e){}}});return os.apply(this,arguments);};}try{new PerformanceObserver(function(list){list.getEntries().forEach(function(e){postS(e.name,false,false);});}).observe({entryTypes:['resource']});}catch(e){}var clickP=function(){return;try{var hv=document.querySelector('video');if(hv&&!hv.paused&&hv.currentTime>0.2)return;document.querySelectorAll('#pl_but,.play,.btn-play,.vjs-big-play-button,.vjs-poster,.jw-icon-display,.jw-display-icon-container,.plyr__control--overlaid,.plyr__poster,[data-plyr=play],[aria-label*=Play i],[title*=Play i],[class*=play-btn i],[class*=play_btn i],[id*=play-btn i]').forEach(function(b){if(b.__sbClk)return;b.__sbClk=1;try{b.click();}catch(e){}});}catch(e){}};var scanV=function(){try{clickP();document.querySelectorAll('video').forEach(function(v){var isP=v.videoHeight>0&&v.videoWidth>0&&v.videoHeight>v.videoWidth*0.95;var isS=isFinite(v.duration)&&v.duration>0&&v.duration<120;if(isP||isS){v.muted=true;return;}if(!v.__sbAutoP){v.__sbAutoP=1;if(v.paused&&!window.__sbUserPaused){try{v.autoplay=true;v.play().catch(function(){});}catch(e){}}}var isF=(isFinite(v.duration)&&v.duration>=60)||(!v.paused&&v.currentTime>0.2);if(v.src)postS(v.src,false,isF);if(v.currentSrc)postS(v.currentSrc,false,isF);});}catch(e){}};var ticks=0;var iv=setInterval(function(){ticks++;scanV();if(ticks>=30)clearInterval(iv);},500);}catch(e){}})();"
            try {
                if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.DOCUMENT_START_SCRIPT)) {
                    val isDirectWebInit = intent?.getStringExtra(EXTRA_PAYLOAD_JSON)?.let { try { val o = org.json.JSONObject(it); !o.optBoolean("isLive", false) && !o.optString("url", "").startsWith("/") } catch (_: Throwable) { true } } ?: true
                    if (!isDirectWebInit) androidx.webkit.WebViewCompat.addDocumentStartJavaScript(resWv, docStartSniffJs, setOf("*"))
                    androidx.webkit.WebViewCompat.addDocumentStartJavaScript(resWv, "(function(){try{if(window.__sbUiClean)return;window.__sbUiClean=1;try{window.open=function(){return null;};}catch(e){}var m=document.querySelector('meta[name=viewport]');if(!m){m=document.createElement('meta');m.name='viewport';if(document.head)document.head.appendChild(m);}m.content='width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no';var st=document.createElement('style');st.textContent='*:focus{outline:none!important;}video{position:relative!important;z-index:0!important;}html,body{background:#000!important;touch-action:pan-x pan-y!important;-webkit-user-select:none!important;}[aria-label*=fullscreen i],[title*=fullscreen i],[data-plyr=fullscreen],.vjs-fullscreen-control,.jw-icon-fullscreen,button[class*=fullscreen i],[class*=fullscreen-btn i]{display:none!important;visibility:hidden!important;pointer-events:none!important;}#__sbWebBackBtn{display:inline-flex!important;align-items:center;justify-content:center;width:28px;height:28px;min-width:28px;margin-right:8px;background:transparent!important;border:none!important;color:rgba(255,255,255,0.92);cursor:pointer;flex-shrink:0;padding:0;outline:none;}#__sbFallbackBack{position:fixed;top:14px;left:14px;z-index:999998;display:none;align-items:center;justify-content:center;width:30px;height:30px;background:transparent;border:none;color:rgba(255,255,255,0.88);cursor:pointer;padding:0;}.__sb-tv-hover{background-color:rgba(255,255,255,0.22)!important;box-shadow:inset 0 0 0 1.5px rgba(255,255,255,0.8)!important;border-radius:8px!important;}';(document.head||document.documentElement).appendChild(st);window.__sbUserPaused=0;var checkUserToggle=function(ev){try{var v=document.querySelector('video');if(!v)return;var tg=ev.target;var isPlayCtrl=tg&&tg.closest&&(tg.closest('button,[role=button]')||tg.tagName==='VIDEO');if(!isPlayCtrl)return;var b=tg.closest?tg.closest('button,[role=button]'):null;var lb=b?((b.getAttribute('aria-label')||'')+' '+(b.getAttribute('title')||'')).toLowerCase():'';var isPp=(tg.tagName==='VIDEO')||(lb.indexOf('play')!==-1||lb.indexOf('pause')!==-1)||(b&&b.getBoundingClientRect().left<140&&b.getBoundingClientRect().bottom>window.innerHeight-95);if(isPp){if(v.paused){window.__sbUserPaused=0;}else{window.__sbUserPaused=1;v.autoplay=false;v.removeAttribute('autoplay');}}}catch(e){}};document.addEventListener('pointerdown',checkUserToggle,true);try{var op=HTMLMediaElement.prototype.play,opa=HTMLMediaElement.prototype.pause;HTMLMediaElement.prototype.pause=function(){this.autoplay=false;this.removeAttribute('autoplay');return opa.apply(this,arguments);};HTMLMediaElement.prototype.play=function(){if(window.__sbUserPaused){return Promise.reject(new DOMException('Paused','NotAllowedError'));}return op.apply(this,arguments);};}catch(e){}var mkBack=function(id){var b=document.createElement('button');b.id=id;b.type='button';b.innerHTML='<svg width=20 height=20 viewBox=\"0 0 24 24\" fill=none stroke=currentColor stroke-width=2.2 stroke-linecap=round stroke-linejoin=round><path d=\"M19 12H5\"/><path d=\"M12 19l-7-7 7-7\"/></svg>';b.onclick=function(ev){ev.stopPropagation();try{AndroidSniffer.onWebBack();}catch(e){}};return b;};var findTitleEl=function(){var t=document.querySelector('h1,h2,[class*=title i]');if(t&&t.getBoundingClientRect().width>0)return t;var cands=document.querySelectorAll('div,span,p');for(var i=0;i<cands.length;i++){var el=cands[i];if(el.id==='__sbWebBackBtn'||el.id==='__sbFallbackBack')continue;if(el.children.length>0)continue;var tx=(el.textContent||'').trim();if(tx.length<2||tx.length>70)continue;var r=el.getBoundingClientRect();if(r.top>=4&&r.top<75&&r.left>=8&&r.left<240&&r.height>=12&&r.height<52)return el;}return null;};var findPlayBtn=function(){var btns=Array.from(document.querySelectorAll('button,[role=button]'));for(var i=0;i<btns.length;i++){var b=btns[i];if(b.id==='__sbWebBackBtn'||b.id==='__sbFallbackBack')continue;var lb=((b.getAttribute('aria-label')||'')+' '+(b.getAttribute('title')||'')).toLowerCase();if(lb.indexOf('play')!==-1||lb.indexOf('pause')!==-1)return b;}return null;};var syncUi=function(){try{if(window!==window.top)return;var t=findTitleEl();var inlineBtn=document.getElementById('__sbWebBackBtn');var fb=document.getElementById('__sbFallbackBack');if(!fb&&document.body){fb=mkBack('__sbFallbackBack');document.body.appendChild(fb);}if(t&&t.parentElement){var p=t.parentElement;if(!inlineBtn||!p.contains(inlineBtn)){if(inlineBtn)inlineBtn.remove();inlineBtn=mkBack('__sbWebBackBtn');if(getComputedStyle(p).display!=='flex'){p.style.display='flex';p.style.alignItems='center';}p.insertBefore(inlineBtn,p.firstChild);}if(fb&&fb.style.display!=='none')fb.style.display='none';}else{if(fb&&fb.style.display!=='inline-flex')fb.style.display='inline-flex';}var btns=Array.from(document.querySelectorAll('button,[role=button]'));var rew=null,fwd=null,pp=null;btns.forEach(function(b){if(b.id==='__sbWebBackBtn'||b.id==='__sbFallbackBack')return;var lb=((b.getAttribute('aria-label')||'')+' '+(b.getAttribute('title')||'')+' '+(b.className||'')).toLowerCase();if(lb.indexOf('fullscreen')!==-1||lb.indexOf('full screen')!==-1||lb.indexOf('maximize')!==-1){if(b.style.display!=='none')b.style.setProperty('display','none','important');return;}var r=b.getBoundingClientRect();if(r.width>10&&r.width<=56&&r.height<=56&&r.bottom>=window.innerHeight-80&&r.right>=window.innerWidth-56&&lb.indexOf('setting')===-1&&lb.indexOf('gear')===-1){if(b.style.display!=='none')b.style.setProperty('display','none','important');return;}if(r.bottom>=window.innerHeight-95&&r.left<=window.innerWidth*0.45&&r.width>10){var tx=(b.innerText||'').trim();if(lb.indexOf('rewind')!==-1||lb.indexOf('back')!==-1||(tx==='10'&&!rew)){if(!rew)rew=b;}else if(lb.indexOf('forward')!==-1||lb.indexOf('skip')!==-1||tx==='10'){fwd=b;}else if(lb.indexOf('play')!==-1||lb.indexOf('pause')!==-1||(r.left<120&&!pp)){pp=b;}}});if(pp&&pp.parentElement){var par=pp.parentElement;var ch=Array.from(par.children).filter(function(el){return el.tagName==='BUTTON';});if(ch.length>=3&&!par.__sbOrd){par.__sbOrd=1;if(rew&&fwd){rew.style.order='1';pp.style.order='2';fwd.style.order='3';ch.forEach(function(el){if(el!==rew&&el!==pp&&el!==fwd)el.style.order='4';});}else{ch[1].style.order='1';ch[0].style.order='2';for(var k=2;k<ch.length;k++)ch[k].style.order=String(k+1);}}}document.querySelectorAll('div,section,ul').forEach(function(el){if(el.__sbMaxH)return;var cs=getComputedStyle(el);if((cs.position==='absolute'||cs.position==='fixed')&&el.getBoundingClientRect().height>140){var rr=el.getBoundingClientRect();if(rr.top>=20&&rr.bottom>window.innerHeight-14&&rr.width<window.innerWidth*0.92){el.__sbMaxH=1;el.style.setProperty('max-height',(window.innerHeight-rr.top-14)+'px','important');el.style.setProperty('overflow-y','auto','important');}}});}catch(e){}};var getTopMenu=function(){var best=null,bestZ=-1,bestArea=0;document.querySelectorAll('[role=dialog],[role=menu],div,section,ul').forEach(function(el){if(el.id==='__sbFallbackBack'||el.querySelector('video'))return;var cs=getComputedStyle(el);if(cs.display==='none'||cs.visibility==='hidden'||parseFloat(cs.opacity)<0.2)return;if(cs.position!=='absolute'&&cs.position!=='fixed')return;var r=el.getBoundingClientRect();if(r.width<150||r.height<110)return;var isFull=(r.width>=window.innerWidth*0.95&&r.height>=window.innerHeight*0.95);if(isFull){var inner=Array.from(el.children).find(function(c){var cr=c.getBoundingClientRect();return cr.width>=150&&cr.height>=110&&cr.width<window.innerWidth*0.95;});if(inner){el=inner;r=inner.getBoundingClientRect();cs=getComputedStyle(inner);}else return;}if(el.querySelector('#__sbWebBackBtn'))return;var bg=cs.backgroundColor||'';var hasBg=bg!=='rgba(0, 0, 0, 0)'&&bg!=='transparent';var hasRole=el.matches('[role=dialog],[role=menu]');var hasClose=!!Array.from(el.querySelectorAll('button,[role=button]')).find(function(b){var tx=(b.innerText||'').trim();var lb=(b.getAttribute('aria-label')||'').toLowerCase();return tx==='×'||tx==='✕'||lb.indexOf('close')!==-1;});if(!hasRole&&!hasClose&&!(hasBg&&r.height>130))return;var cnt=el.querySelectorAll('button,[role=button],[role=menuitem],[role=option],input').length;if(cnt<2)return;var z=parseInt(cs.zIndex,10)||0;var area=r.width*r.height;if(z>bestZ||(z===bestZ&&area>bestArea)){bestZ=z;bestArea=area;best=el;}});return best;};window.__sbCloseMenuIfOpen=function(){var m=getTopMenu();if(!m)return false;var cls=Array.from(m.querySelectorAll('button,[role=button]')).find(function(b){var tx=(b.innerText||'').trim();var lb=(b.getAttribute('aria-label')||'').toLowerCase();return tx==='×'||tx==='✕'||lb.indexOf('close')!==-1;});if(cls){cls.click();}else{try{document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',code:'Escape',keyCode:27,bubbles:true}));}catch(e){}}var cur=document.querySelector('.__sb-tv-hover');if(cur)cur.classList.remove('__sb-tv-hover');return true;};var isSliderEl=function(el){if(!el)return false;if(el.tagName==='INPUT'&&el.type==='range')return true;if(el.getAttribute('role')==='slider')return true;var cn=(el.className&&typeof el.className==='string'?el.className:'').toLowerCase();var r=el.getBoundingClientRect();if(r.width<60||r.height<4||r.height>38)return false;if((el.innerText||'').trim().length>0)return false;return cn.indexOf('slider')!==-1||cn.indexOf('progress')!==-1||cn.indexOf('seek')!==-1||cn.indexOf('track')!==-1||cn.indexOf('range')!==-1;};var stepSlider=function(el,dir){var delta=dir==='right'?1:-1;var rng=(el.tagName==='INPUT'&&el.type==='range')?el:el.querySelector('input[type=range]');if(rng){var mn=parseFloat(rng.min)||0,mx=parseFloat(rng.max)||100;var st=parseFloat(rng.step)||Math.max(1,(mx-mn)/20);var nv=Math.min(mx,Math.max(mn,(parseFloat(rng.value)||0)+delta*st));var setter=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,'value').set;if(setter)setter.call(rng,String(nv));else rng.value=String(nv);rng.dispatchEvent(new Event('input',{bubbles:true}));rng.dispatchEvent(new Event('change',{bubbles:true}));return true;}if(el.getAttribute('role')==='slider'){try{el.dispatchEvent(new KeyboardEvent('keydown',{key:dir==='right'?'ArrowRight':'ArrowLeft',code:dir==='right'?'ArrowRight':'ArrowLeft',keyCode:dir==='right'?39:37,bubbles:true}));}catch(e){}}var r=el.getBoundingClientRect();if(r.width>window.innerWidth*0.35&&r.bottom>window.innerHeight-130){var v=document.querySelector('video');if(v&&isFinite(v.duration)&&v.duration>0){v.currentTime=Math.min(v.duration,Math.max(0,v.currentTime+delta*10));return true;}}var curPct=el.__sbPct;if(curPct==null){var vNow=el.getAttribute('aria-valuenow'),vMin=el.getAttribute('aria-valuemin')||0,vMax=el.getAttribute('aria-valuemax')||100;if(vNow!=null&&vMax>vMin){curPct=(parseFloat(vNow)-parseFloat(vMin))/(parseFloat(vMax)-parseFloat(vMin));}else{var fill=Array.from(el.children).find(function(c){var cr=c.getBoundingClientRect();return cr.height>=2&&cr.width>0&&cr.width<=r.width&&cr.left<=r.left+4;});curPct=fill?(fill.getBoundingClientRect().width/r.width):0.5;}}var pct=Math.min(0.99,Math.max(0.01,curPct+delta*0.08));el.__sbPct=pct;var px=r.left+r.width*pct,py=r.top+r.height/2;try{el.dispatchEvent(new PointerEvent('pointerdown',{bubbles:true,cancelable:true,clientX:px,clientY:py,pointerId:1,pointerType:'mouse'}));el.dispatchEvent(new MouseEvent('mousedown',{bubbles:true,cancelable:true,clientX:px,clientY:py}));el.dispatchEvent(new PointerEvent('pointermove',{bubbles:true,cancelable:true,clientX:px,clientY:py,pointerId:1,pointerType:'mouse'}));el.dispatchEvent(new MouseEvent('mousemove',{bubbles:true,cancelable:true,clientX:px,clientY:py}));el.dispatchEvent(new PointerEvent('pointerup',{bubbles:true,cancelable:true,clientX:px,clientY:py,pointerId:1,pointerType:'mouse'}));el.dispatchEvent(new MouseEvent('mouseup',{bubbles:true,cancelable:true,clientX:px,clientY:py}));el.dispatchEvent(new MouseEvent('click',{bubbles:true,cancelable:true,clientX:px,clientY:py}));}catch(e){}return true;};var setHover=function(next){var prev=document.querySelector('.__sb-tv-hover');if(prev&&prev!==next){prev.classList.remove('__sb-tv-hover');try{prev.dispatchEvent(new MouseEvent('mouseleave',{bubbles:false}));}catch(e){}}if(next){next.classList.add('__sb-tv-hover');try{next.dispatchEvent(new MouseEvent('mouseenter',{bubbles:false}));next.dispatchEvent(new MouseEvent('mouseover',{bubbles:true}));next.scrollIntoView({block:'nearest',inline:'nearest'});}catch(e){}}};var getInteractives=function(scope){var root=scope||document;var raw=Array.from(root.querySelectorAll('button,[role=button],[role=menuitem],[role=option],[role=slider],a,input,select,[tabindex],[class*=slider i],[class*=progress i],[class*=seek i],[class*=track i],div,span,li'));var out=[];raw.forEach(function(el){if(el.disabled)return;var r=el.getBoundingClientRect();if(r.width<14||r.height<4)return;if(r.width>window.innerWidth*0.65&&r.height>window.innerHeight*0.35)return;var cs=getComputedStyle(el);if(cs.display==='none'||cs.visibility==='hidden'||parseFloat(cs.opacity)<0.15||cs.pointerEvents==='none')return;var isSl=isSliderEl(el);var isSemantic=isSl||el.matches('button,[role=button],[role=menuitem],[role=option],[role=slider],a,input,select,[tabindex]');if(!isSemantic&&cs.cursor!=='pointer')return;if(!isSl&&r.height<14)return;out.push(el);});return out.filter(function(el){return !out.some(function(other){return other!==el&&other.contains(el)&&(other.matches('button,[role=button],[role=menuitem],[role=option],a')||isSliderEl(other));});});};window.__sbWakeHud=function(){try{var cx=window.innerWidth/2+((Date.now()%9)-4),cy=window.innerHeight/2+((Date.now()%7)-3);var targets=[window,document,document.body];document.querySelectorAll('body > div, body > div > div').forEach(function(d){targets.push(d);});var v=document.querySelector('video');if(v){targets.push(v);if(v.parentElement)targets.push(v.parentElement);}targets.forEach(function(tg){if(!tg||!tg.dispatchEvent)return;try{tg.dispatchEvent(new PointerEvent('pointermove',{bubbles:true,cancelable:true,clientX:cx,clientY:cy,pointerType:'mouse'}));}catch(e){}try{tg.dispatchEvent(new MouseEvent('mousemove',{bubbles:true,cancelable:true,clientX:cx,clientY:cy}));}catch(e){}});}catch(e){}};window.__sbTvNav=function(dir,retried){try{window.__sbWakeHud();syncUi();var menu=getTopMenu();var els=getInteractives(menu||document);var cur=document.querySelector('.__sb-tv-hover');if(cur&&menu&&!menu.contains(cur)){cur.classList.remove('__sb-tv-hover');cur=null;}if(cur&&(dir==='left'||dir==='right')&&isSliderEl(cur)){stepSlider(cur,dir);return;}if(dir==='ok'){if(cur&&cur.isConnected){var v=document.querySelector('video');var lb=((cur.getAttribute('aria-label')||'')+' '+(cur.getAttribute('title')||'')).toLowerCase();if(v&&(lb.indexOf('play')!==-1||lb.indexOf('pause')!==-1||(cur.getBoundingClientRect().left<140&&cur.getBoundingClientRect().bottom>window.innerHeight-95))){window.__sbUserPaused=v.paused?0:1;}cur.click();setTimeout(syncUi,90);return;}var pb=findPlayBtn();if(pb){var v2=document.querySelector('video');if(v2)window.__sbUserPaused=v2.paused?0:1;pb.click();}return;}if(!els.length){if(!retried){setTimeout(function(){window.__sbTvNav(dir,1);},120);}return;}if(!cur||!cur.isConnected||els.indexOf(cur)===-1){var pick=menu?els[0]:(els.find(function(e){return e.id==='__sbWebBackBtn'||e.id==='__sbFallbackBack';})||els[0]);setHover(pick);return;}var cr=cur.getBoundingClientRect();var cx=cr.left+cr.width/2,cy=cr.top+cr.height/2;var best=null,bestScore=1e9;els.forEach(function(el){if(el===cur)return;var r=el.getBoundingClientRect();var x=r.left+r.width/2,y=r.top+r.height/2;var dx=x-cx,dy=y-cy;var ok=false;if(dir==='left')ok=dx<-8;else if(dir==='right')ok=dx>8;else if(dir==='up')ok=dy<-8;else if(dir==='down')ok=dy>8;if(!ok)return;var primary=(dir==='left'||dir==='right')?Math.abs(dx):Math.abs(dy);var ortho=(dir==='left'||dir==='right')?Math.abs(dy):Math.abs(dx);var sc=primary+ortho*2.2;if(sc<bestScore){bestScore=sc;best=el;}});if(best){setHover(best);}}catch(e){}};document.addEventListener('DOMContentLoaded',syncUi);window.addEventListener('load',syncUi);setTimeout(syncUi,600);setTimeout(syncUi,1800);var lastSavedPrefs='';var reportProg=function(force){try{var v=document.querySelector('video');if(v&&isFinite(v.duration)&&v.duration>30){if(!v.__sbResumed&&window.__sbStartSec>5&&v.duration>window.__sbStartSec+5){v.__sbResumed=1;try{v.currentTime=window.__sbStartSec;}catch(e){}}AndroidSniffer.onWebProgress(Math.floor(v.currentTime||0),Math.floor(v.duration||0),!v.paused);}if(force||Math.random()<0.4){var obj={};for(var i=0;i<localStorage.length;i++){var k=localStorage.key(i);if(k&&k.length<80){var val=localStorage.getItem(k);if(val&&val.length<2000)obj[k]=val;}}var s=JSON.stringify(obj);if(s!==lastSavedPrefs&&s.length>2){lastSavedPrefs=s;AndroidSniffer.onWebPrefs(s);}}}catch(e){}};document.addEventListener('pause',function(e){if(e.target&&e.target.tagName==='VIDEO')reportProg(true);},true);setInterval(function(){reportProg(false);},5000);}catch(e){}})();", setOf("*"))
                }
            } catch (_: Throwable) {}
            resolverWebView = resWv
            root.addView(resWv)

            vlcVideoLayout = pv
            applySubtitleStyle()
            root.addView(pv)

            val skBtn = Button(this).apply {
                text = "Skip Intro"
                isAllCaps = false
                setTextColor(Color.BLACK)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(16), dp(8), dp(16), dp(8))
                isFocusable = true
                isClickable = true
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    defaultFocusHighlightEnabled = false
                }
                visibility = View.GONE
                val makeSkipBg = { focused: Boolean ->
                    GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = dp(8).toFloat()
                        setColor(if (focused) Color.rgb(229, 9, 20) else Color.argb(240, 255, 255, 255))
                        if (focused) setStroke(dp(2), Color.WHITE)
                    }
                }
                background = makeSkipBg(false)
                setOnFocusChangeListener { v, hasFocus ->
                    background = makeSkipBg(hasFocus)
                    setTextColor(if (hasFocus) Color.WHITE else Color.BLACK)
                    v.animate().scaleX(if (hasFocus) 1.08f else 1f).scaleY(if (hasFocus) 1.08f else 1f).setDuration(120).start()
                }
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM or Gravity.END
                ).apply {
                    marginEnd = dp(24)
                    bottomMargin = dp(92)
                }
                setOnClickListener { handleSkipSegmentClick() }
            }
            skipSegmentBtn = skBtn
            root.addView(skBtn)

            val nCard = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                visibility = View.GONE
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(12).toFloat()
                    setColor(Color.argb(242, 14, 16, 22))
                    setStroke(dp(1), Color.argb(60, 255, 255, 255))
                }
                layoutParams = FrameLayout.LayoutParams(
                    dp(268),
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM or Gravity.END
                ).apply {
                    marginEnd = dp(24)
                    bottomMargin = dp(92)
                }
            }
            val nTag = TextView(this).apply {
                text = "NEXT EPISODE"
                setTextColor(Color.rgb(229, 9, 20))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                typeface = Typeface.DEFAULT_BOLD
            }
            val nTitle = TextView(this).apply {
                text = "Next Episode"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(0, dp(4), 0, dp(2))
            }
            nextEpTitleTv = nTitle
            val nCount = TextView(this).apply {
                text = "Starting in 10s..."
                setTextColor(Color.argb(190, 255, 255, 255))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setPadding(0, 0, 0, dp(10))
            }
            nextEpCountdownTv = nCount
            val nBtnRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
            }
            val nPlayBtn = Button(this).apply {
                text = "Play Next"
                isAllCaps = false
                setTextColor(Color.BLACK)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(12), dp(6), dp(12), dp(6))
                minHeight = 0
                minimumHeight = 0
                isFocusable = true
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    defaultFocusHighlightEnabled = false
                }
                val makeNextBg = { focused: Boolean ->
                    GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = dp(6).toFloat()
                        setColor(if (focused) Color.rgb(229, 9, 20) else Color.WHITE)
                        if (focused) setStroke(dp(2), Color.WHITE)
                    }
                }
                background = makeNextBg(false)
                setOnFocusChangeListener { v, hasFocus ->
                    background = makeNextBg(hasFocus)
                    setTextColor(if (hasFocus) Color.WHITE else Color.BLACK)
                    v.animate().scaleX(if (hasFocus) 1.08f else 1f).scaleY(if (hasFocus) 1.08f else 1f).setDuration(120).start()
                }
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = dp(8) }
                setOnClickListener { playNextEpisodeInPlayer() }
            }
            val nDismissBtn = Button(this).apply {
                text = "Watch Credits"
                isAllCaps = false
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setPadding(dp(10), dp(6), dp(10), dp(6))
                minHeight = 0
                minimumHeight = 0
                isFocusable = true
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    defaultFocusHighlightEnabled = false
                }
                background = createSecondaryBg(false)
                setOnFocusChangeListener { v, hasFocus ->
                    background = createSecondaryBg(hasFocus)
                    v.animate().scaleX(if (hasFocus) 1.08f else 1f).scaleY(if (hasFocus) 1.08f else 1f).setDuration(120).start()
                }
                setOnClickListener { dismissNextEpisodeCard() }
            }
            nBtnRow.addView(nPlayBtn)
            nBtnRow.addView(nDismissBtn)
            nCard.addView(nTag)
            nCard.addView(nTitle)
            nCard.addView(nCount)
            nCard.addView(nBtnRow)
            nextEpCard = nCard
            root.addView(nCard)

            val subOverlay = TextView(this).apply {
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, subTextSizeSp)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(28, 12, 28, 12)
                setShadowLayer(6f, 0f, 2f, Color.BLACK)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 14f
                    setColor(Color.argb(190, 0, 0, 0))
                }
                visibility = View.GONE
                val lp = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                )
                val isTvScreen = (resources.configuration.uiMode and android.content.res.Configuration.UI_MODE_TYPE_MASK) == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION || packageManager.hasSystemFeature(android.content.pm.PackageManager.FEATURE_LEANBACK)
                lp.setMargins(dp(24), 0, dp(24), if (isTvScreen) dp(32) else dp(12))
                layoutParams = lp
            }
            subtitleOverlayView = subOverlay
            root.addView(subOverlay)

            val overlay = FrameLayout(this).apply {
                clipChildren = false
                clipToPadding = false
                isClickable = false
                isFocusable = false
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            }
            controllerOverlay = overlay

            val topBar = LinearLayout(this).apply {
                clipChildren = false
                clipToPadding = false
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(28), dp(22), dp(28), dp(28))
                background = GradientDrawable(
                    GradientDrawable.Orientation.TOP_BOTTOM,
                    intArrayOf(Color.argb(150, 0, 0, 0), Color.TRANSPARENT)
                )
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP
                )
            }

            fun wrapTopLabeledButton(btn: ImageButton, labelText: String): LinearLayout {
                return LinearLayout(this).apply {
                    clipChildren = false
                    clipToPadding = false
                    layoutDirection = View.LAYOUT_DIRECTION_LTR
                    orientation = LinearLayout.VERTICAL
                    gravity = Gravity.CENTER_HORIZONTAL
                    minimumWidth = dp(56)
                    layoutParams = LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                    addView(btn)
                    addView(TextView(this@NativeExoPlayerActivity).apply {
                        text = labelText
                        isSingleLine = true
                        maxLines = 1
                        setTextColor(Color.argb(225, 255, 255, 255))
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 10.5f)
                        typeface = Typeface.DEFAULT_BOLD
                        gravity = Gravity.CENTER
                        setPadding(dp(2), dp(2), dp(2), 0)
                    })
                }
            }

            val backBtn = makeCircleVectorButton("back", 44) {
                saveCurrentProgress()
                finish()
            }
            val backContainer = wrapTopLabeledButton(backBtn, "Back")

            val tvTitle = TextView(this).apply {
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(12), 0, dp(16), 0)
                maxLines = 1
                setShadowLayer(4f, 0f, 1f, Color.argb(180, 0, 0, 0))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            titleView = tvTitle

            val srvBadge = TextView(this).apply {
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(12), dp(5), dp(12), dp(5))
                isClickable = false
                isFocusable = false
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(12).toFloat()
                    setColor(Color.argb(55, 255, 255, 255))
                }
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
            srvBadge.visibility = View.GONE
            serverBadgeView = srvBadge
            tvTitle.layoutParams = LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
            ).apply {
                marginStart = dp(12)
                marginEnd = dp(12)
            }
            val swBtn = Button(this).apply {
                visibility = View.GONE
                setOnClickListener { handleSwitchServer() }
            }
            switchServerBtn = swBtn

            val rstTopBtn = makeCircleVectorButton("restart", 44) {
                startTimeSec = 0L
                vlcPlayer?.let { p ->
                    if (vlcDidEnd || !p.isPlaying) {
                        vlcDidEnd = false
                        vlcPendingSeekMs = 0L
                        p.stop()
                        p.play()
                    } else {
                        vlcSeekTo(0L)
                        if (kotlin.math.abs(p.rate - currentSpeed) > 0.01f) p.rate = currentSpeed
                    }
                }
                updateTimeAndSeekBar()
                showControllerTemporarily()
            }.apply {
                contentDescription = "Restart"
            }
            topRestartBtn = rstTopBtn
            val rstContainer = wrapTopLabeledButton(rstTopBtn, "Restart").apply {
                (layoutParams as? LinearLayout.LayoutParams)?.marginEnd = dp(10)
            }
            topRestartContainerRef = rstContainer

            val nxtTopBtn = makeCircleVectorButton("next", 44) {
                if (computeNextEpisode() != null) {
                    playNextEpisodeInPlayer()
                }
            }.apply {
                contentDescription = "Next Episode"
            }
            topNextBtn = nxtTopBtn
            val nxtContainer = wrapTopLabeledButton(nxtTopBtn, "Next")
            topNextContainer = nxtContainer

            topBar.addView(backContainer)
            topBar.addView(tvTitle)
            topBar.addView(rstContainer)
            topBar.addView(nxtContainer)
            overlay.addView(topBar)

            val centerControls = LinearLayout(this).apply {
                clipChildren = false
                clipToPadding = false
                setPadding(dp(18), dp(18), dp(18), dp(18))
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER
                )
            }

            val rewBtn = makeCircleVectorButton("rew10", 58) {
                vlcSeekTo((effectiveSeekBaseMs() - 10_000L).coerceAtLeast(0L))
                showControllerTemporarily()
            }

            val ppBtn = makeCircleVectorButton("pause", 72) {
                toggleVlcPlayPause()
                showControllerTemporarily()
            }
            playPauseBtn = ppBtn

            val fwdBtn = makeCircleVectorButton("fwd10", 58) {
                val dur = vlcDurationMs()
                val next = effectiveSeekBaseMs() + 10_000L
                vlcSeekTo(if (dur > 0L) next.coerceAtMost(dur) else next)
                showControllerTemporarily()
            }

            (rewBtn.layoutParams as LinearLayout.LayoutParams).setMargins(0, 0, dp(30), 0)
            (fwdBtn.layoutParams as LinearLayout.LayoutParams).setMargins(dp(30), 0, 0, 0)

            rewBtnRef = rewBtn
            centerControls.addView(rewBtn)
            centerControls.addView(ppBtn)
            fwdBtnRef = fwdBtn
            centerControls.addView(fwdBtn)
            overlay.addView(centerControls)

            val bottomContainer = LinearLayout(this).apply {
                clipChildren = false
                clipToPadding = false
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(72), dp(28), dp(72), dp(22))
                background = GradientDrawable(
                    GradientDrawable.Orientation.BOTTOM_TOP,
                    intArrayOf(Color.argb(175, 0, 0, 0), Color.TRANSPARENT)
                )
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM
                )
            }

            val seekRow = LinearLayout(this).apply {
                clipChildren = false
                clipToPadding = false
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    setMargins(dp(56), 0, dp(56), dp(10))
                }
            }

            val posText = TextView(this).apply {
                text = "0:00"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(0, 0, dp(14), 0)
            }
            currentPosView = posText

            val sb = SeekBar(this).apply {
                max = 1000
                progress = 0
                splitTrack = false
                isFocusable = true
                isFocusableInTouchMode = false
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    defaultFocusHighlightEnabled = false
                }
                progressDrawable = createNetflixSeekBarDrawable(false)
                thumb = ColorDrawable(Color.TRANSPARENT)
                thumbOffset = 0
                setPadding(0, dp(10), 0, dp(10))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnFocusChangeListener { v, hasFocus ->
                    progressDrawable = createNetflixSeekBarDrawable(hasFocus)
                    v.animate()
                        .scaleY(if (hasFocus) 1.55f else 1.0f)
                        .setDuration(140)
                        .setInterpolator(DecelerateInterpolator())
                        .start()
                    showControllerTemporarily()
                }
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) {
                        if (fromUser) {
                            val dur = vlcDurationMs()
                            if (dur > 0) {
                                val target = (dur * value) / 1000L
                                currentPosView?.text = formatTimeMs(target)
                                durationView?.text = "-${formatTimeMs((dur - target).coerceAtLeast(0L))}"
                            }
                        }
                    }

                    override fun onStartTrackingTouch(bar: SeekBar?) {
                        isScrubbing = true
                        mainHandler.removeCallbacks(hideControllerRunnable)
        mainHandler.removeCallbacks(hideMetersRunnable)
        mainHandler.removeCallbacks(hideLeftSeekRunnable)
        mainHandler.removeCallbacks(hideRightSeekRunnable)
                    }

                    override fun onStopTrackingTouch(bar: SeekBar?) {
                        isScrubbing = false
                        val dur = vlcDurationMs()
                        if (dur > 0 && bar != null) {
                            vlcSeekTo((dur * bar.progress) / 1000L, immediate = true)
                        }
                        showControllerTemporarily()
                    }
                })
            }
            seekBar = sb

            val durText = TextView(this).apply {
                text = "0:00"
                setTextColor(Color.argb(215, 226, 232, 240))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(14), 0, 0, 0)
            }
            durationView = durText

            seekRow.addView(posText)
            seekRow.addView(sb)
            seekRow.addView(durText)
            bottomContainer.addView(seekRow)

            val actionsRow = LinearLayout(this).apply {
                clipChildren = false
                clipToPadding = false
                setPadding(dp(12), dp(8), dp(12), dp(8))
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }

            val sBtn = makeSecondaryButton("Subtitles") {
                showSubtitlesMenuDialog()
            }
            subBtn = sBtn

            val styleBtn = makeSecondaryButton("Style") {
                showSubtitleStyleDialog()
            }
            val syncBtn = makeSecondaryButton("Sync 0.0s") {
                showSubtitleDelayDialog()
            }
            syncBtnRef = syncBtn

            val speedBtn = makeSecondaryButton("1x") { btn ->
                showSpeedDialog(btn as Button)
            }
            speedBtnRef = speedBtn
            val aspBtn = makeSecondaryButton("Fit") {
                cycleAspectMode()
            }
            aspectBtn = aspBtn
            val skip85Btn = makeSecondaryButton("+85s") {
                val dur = vlcDurationMs()
                val next = effectiveSeekBaseMs() + 85_000L
                vlcSeekTo(if (dur > 0L) next.coerceAtMost(dur) else next)
                showGestureHudPill("+85s")
                mainHandler.postDelayed({ hideGestureHudPill() }, 800L)
                showControllerTemporarily()
            }
            val slpBtn = makeSecondaryButton("Timer") {
                showSleepTimerDialog()
            }
            sleepBtn = slpBtn
            val lockBtn = makeSecondaryButton("Lock") {
                toggleScreenLock()
            }
            val srvBtn = makeSecondaryButton("Server") {
                showServerPickerDialog()
            }
            val pipBtn = makeSecondaryButton("PiP") {
                enterPipIfSupported()
            }
            actionsRow.addView(sBtn)
            actionsRow.addView(styleBtn)
            actionsRow.addView(syncBtn)
            actionsRow.addView(speedBtn)
            actionsRow.addView(aspBtn)
            actionsRow.addView(skip85Btn)
            actionsRow.addView(slpBtn)
            actionsRow.addView(lockBtn)
            srvBtn.visibility = View.GONE
            actionsRow.addView(pipBtn)
            bottomContainerRef = bottomContainer
            styleBtnRef = styleBtn
            audioBtnRef = null
            skip85BtnRef = skip85Btn
            bottomActionsRow = actionsRow
            applyLiveModeUi()
            val actionsScroll = android.widget.HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                clipChildren = false
                clipToPadding = false
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
                addView(actionsRow)
            }
            bottomContainer.addView(actionsScroll)

            val ulBtn = makeSecondaryButton("Unlock") {
                toggleScreenLock()
            }.apply {
                visibility = View.GONE
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM or Gravity.START
                ).apply {
                    marginStart = dp(20)
                    bottomMargin = dp(20)
                }
            }
            unlockBtn = ulBtn
            root.addView(ulBtn)

            scaleDetector = android.view.ScaleGestureDetector(this, object : android.view.ScaleGestureDetector.SimpleOnScaleGestureListener() {
                override fun onScaleEnd(detector: android.view.ScaleGestureDetector) {
                    if (isScreenLocked) return
                    val f = detector.scaleFactor
                    if (f > 1.15f && aspectModeIndex != 1) applyAspectMode(1)
                    else if (f < 0.88f && aspectModeIndex != 0) applyAspectMode(0)
                }
            })

            overlay.addView(bottomContainer)
            root.addView(overlay)

            audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val lpBright = window.attributes
            if (lpBright.screenBrightness >= 0f) {
                currentBrightness = lpBright.screenBrightness
            }

            val bMeter = VerticalGestureMeterView(this, true).apply {
                visibility = View.GONE
                alpha = 0f
                val lp = FrameLayout.LayoutParams(dp(52), dp(210), Gravity.START or Gravity.CENTER_VERTICAL)
                lp.setMargins(dp(34), 0, 0, 0)
                layoutParams = lp
            }
            brightnessMeter = bMeter
            root.addView(bMeter)

            val vMeter = VerticalGestureMeterView(this, false).apply {
                visibility = View.GONE
                alpha = 0f
                val lp = FrameLayout.LayoutParams(dp(52), dp(210), Gravity.END or Gravity.CENTER_VERTICAL)
                lp.setMargins(0, 0, dp(34), 0)
                layoutParams = lp
            }
            volumeMeter = vMeter
            root.addView(vMeter)

            val lSeek = TextView(this).apply {
                visibility = View.GONE
                alpha = 0f
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(dp(24), dp(14), dp(24), dp(14))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(40).toFloat()
                    setColor(Color.argb(145, 0, 0, 0))
                }
                val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.START or Gravity.CENTER_VERTICAL)
                lp.setMargins(dp(95), 0, 0, 0)
                layoutParams = lp
            }
            leftSeekBadge = lSeek
            root.addView(lSeek)

            val rSeek = TextView(this).apply {
                visibility = View.GONE
                alpha = 0f
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(dp(24), dp(14), dp(24), dp(14))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(40).toFloat()
                    setColor(Color.argb(145, 0, 0, 0))
                }
                val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END or Gravity.CENTER_VERTICAL)
                lp.setMargins(0, 0, dp(95), 0)
                layoutParams = lp
            }
            rightSeekBadge = rSeek
            root.addView(rSeek)

            val gHudBox = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                visibility = View.GONE
                alpha = 0f
                setPadding(dp(16), dp(8), dp(16), dp(8))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(24).toFloat()
                    setColor(Color.argb(195, 0, 0, 0))
                    setStroke(dp(1), Color.argb(55, 255, 255, 255))
                }
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP or Gravity.CENTER_HORIZONTAL
                ).apply {
                    topMargin = dp(26)
                }
            }
            val gHudIv = ImageView(this).apply {
                visibility = View.GONE
                scaleType = ImageView.ScaleType.FIT_CENTER
                layoutParams = LinearLayout.LayoutParams(dp(18), dp(18)).apply {
                    marginEnd = dp(6)
                }
            }
            val gHud = TextView(this).apply {
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
            }
            gHudBox.addView(gHudIv)
            gHudBox.addView(gHud)
            gestureHudContainer = gHudBox
            gestureHudIcon = gHudIv
            gestureHudPill = gHud
            root.addView(gHudBox)

            val ambBar = FrameLayout(this).apply {
                setBackgroundColor(Color.argb(55, 255, 255, 255))
                alpha = 0f
                visibility = View.GONE
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    dp(3),
                    Gravity.BOTTOM
                )
            }
            val ambFill = View(this).apply {
                setBackgroundColor(Color.WHITE)
                pivotX = 0f
                scaleX = 0f
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            }
            ambBar.addView(ambFill)
            ambientProgressBar = ambBar
            ambientProgressFill = ambFill
            root.addView(ambBar)

            val triggerSeekStep: (Int) -> Unit = { side ->
                val player = vlcPlayer
                if (player != null) {
                    val dur = vlcDurationMs()
                    val nowMs = SystemClock.elapsedRealtime()
                    activeSeekSide = side
                    lastSeekEventTimeMs = nowMs
                    if (side < 0) {
                        val target = (effectiveSeekBaseMs() - 10_000L).coerceAtLeast(0L)
                        vlcSeekTo(target)
                        accumSeekLeftSec += 10
                        mainHandler.removeCallbacks(hideLeftSeekRunnable)
                        lSeek.animate().cancel()
                        lSeek.text = "« -${accumSeekLeftSec}s"
                        lSeek.visibility = View.VISIBLE
                        lSeek.alpha = 1f
                        lSeek.scaleX = 0.9f
                        lSeek.scaleY = 0.9f
                        lSeek.animate().scaleX(1.06f).scaleY(1.06f).setDuration(110).withEndAction {
                            lSeek.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
                        }.start()
                        mainHandler.postDelayed(hideLeftSeekRunnable, 750L)
                    } else {
                        val rawNext = effectiveSeekBaseMs() + 10_000L
                        val target = if (dur > 0L) rawNext.coerceAtMost(dur) else rawNext
                        vlcSeekTo(target)
                        accumSeekRightSec += 10
                        mainHandler.removeCallbacks(hideRightSeekRunnable)
                        rSeek.animate().cancel()
                        rSeek.text = "+${accumSeekRightSec}s »"
                        rSeek.visibility = View.VISIBLE
                        rSeek.alpha = 1f
                        rSeek.scaleX = 0.9f
                        rSeek.scaleY = 0.9f
                        rSeek.animate().scaleX(1.06f).scaleY(1.06f).setDuration(110).withEndAction {
                            rSeek.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
                        }.start()
                        mainHandler.postDelayed(hideRightSeekRunnable, 750L)
                    }
                    updateTimeAndSeekBar()
                }
            }

            pv.setOnTouchListener { _, event ->
                if (isScreenLocked) { if (event.actionMasked == MotionEvent.ACTION_UP) showUnlockButtonTemporarily(); return@setOnTouchListener true }
                scaleDetector?.onTouchEvent(event)
                val w = root.width.toFloat().coerceAtLeast(1f)
                val h = root.height.toFloat().coerceAtLeast(1f)
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        gestureActiveMode = 0
                        hold2xSide = 0
                        gestureDownTimeMs = SystemClock.elapsedRealtime()
                        gestureStartX = event.x
                        gestureStartY = event.y
                        swipeSeekBasePosMs = vlcCurrentPosMs()
                        swipeSeekTargetMs = swipeSeekBasePosMs
                        mainHandler.removeCallbacks(hold2xStartRunnable)
                        if (!isLiveStream) {
                            mainHandler.postDelayed(hold2xStartRunnable, 360L)
                        }
                        gestureStartVal = if (event.x < w * 0.5f) {
                            currentBrightness
                        } else {
                            val am = audioManager
                            if (am != null) {
                                val maxV = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                                am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxV.toFloat()
                            } else 0.5f
                        }
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.x - gestureStartX
                        val dy = gestureStartY - event.y
                        if (kotlin.math.hypot(dx.toDouble(), dy.toDouble()) > dp(16)) {
                            mainHandler.removeCallbacks(hold2xStartRunnable)
                        }
                        if (gestureActiveMode == 4) {
                            val p = vlcPlayer
                            if (p != null) {
                                val hdx = event.x - hold2xStartX
                                val rawVal = 2.0f + (hdx / (w * 0.30f))
                                val sp = (kotlin.math.round(rawVal.coerceIn(1.0f, 3.0f) * 10f) / 10f)
                                if (kotlin.math.abs(sp - hold2xLastAppliedSpeed) >= 0.05f) {
                                    hold2xLastAppliedSpeed = sp
                                    p.rate = sp
                                }
                                showGestureHudPill(formatSpeedText(sp), "ff_icon")
                            }
                            return@setOnTouchListener true
                        }
                        val inVerticalSafeZone = gestureStartY >= h * 0.14f && gestureStartY <= h * 0.84f
                        val inLeftStrip = gestureStartX >= dp(20).toFloat() && gestureStartX <= w * 0.24f
                        val inRightStrip = gestureStartX >= w * 0.76f && gestureStartX <= w - dp(20).toFloat()
                        if (gestureActiveMode == 0 && event.pointerCount == 1 && inVerticalSafeZone && (inLeftStrip || inRightStrip) && kotlin.math.abs(dy) > dp(20) && kotlin.math.abs(dy) > kotlin.math.abs(dx) * 1.3f) {
                            gestureActiveMode = if (inLeftStrip) 1 else 2
                        } else if (!isLiveStream && gestureActiveMode == 0 && event.pointerCount == 1 && kotlin.math.abs(dx) > dp(24) && kotlin.math.abs(dx) > kotlin.math.abs(dy) * 1.35f) {
                            gestureActiveMode = 3
                            swipeSeekBasePosMs = vlcCurrentPosMs()
                            swipeSeekTargetMs = swipeSeekBasePosMs
                        }
                        if (gestureActiveMode == 3) {
                            val dur = vlcDurationMs()
                            val deltaSec = ((dx / w) * 150.0).toLong()
                            val rawTarget = (swipeSeekBasePosMs + deltaSec * 1000L).coerceAtLeast(0L)
                            swipeSeekTargetMs = if (dur > 0L) rawTarget.coerceAtMost(dur) else rawTarget
                            val actualDelta = (swipeSeekTargetMs - swipeSeekBasePosMs) / 1000L
                            val sign = if (actualDelta >= 0L) "+" else ""
                            showGestureHudPill("${formatTimeMs(swipeSeekTargetMs)} (${sign}${actualDelta}s)")
                            if (dur > 0L) {
                                val frac = (swipeSeekTargetMs.toFloat() / dur.toFloat()).coerceIn(0f, 1f)
                                seekBar?.progress = (frac * 1000f).toInt()
                                ambientProgressFill?.scaleX = frac
                                currentPosView?.text = formatTimeMs(swipeSeekTargetMs)
                                durationView?.text = "-${formatTimeMs((dur - swipeSeekTargetMs).coerceAtLeast(0L))}"
                            }
                        } else if (gestureActiveMode == 1 || gestureActiveMode == 2) {
                            val delta = dy / (h * 0.6f)
                            val nextVal = (gestureStartVal + delta).coerceIn(0f, 1f)
                            mainHandler.removeCallbacks(hideMetersRunnable)
                            if (gestureActiveMode == 1) {
                                currentBrightness = nextVal.coerceAtLeast(0.04f)
                                val wlp = window.attributes
                                wlp.screenBrightness = currentBrightness
                                window.attributes = wlp
                                bMeter.setLevel(currentBrightness)
                                bMeter.animate().cancel()
                                bMeter.alpha = 1f
                                bMeter.visibility = View.VISIBLE
                            } else {
                                val am = audioManager
                                if (am != null) {
                                    val maxV = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                                    val targetV = kotlin.math.round(nextVal * maxV).toInt().coerceIn(0, maxV)
                                    am.setStreamVolume(AudioManager.STREAM_MUSIC, targetV, 0)
                                    vMeter.setLevel(targetV.toFloat() / maxV.toFloat())
                                } else {
                                    vMeter.setLevel(nextVal)
                                }
                                vMeter.animate().cancel()
                                vMeter.alpha = 1f
                                vMeter.visibility = View.VISIBLE
                            }
                            mainHandler.postDelayed(hideMetersRunnable, 900L)
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        mainHandler.removeCallbacks(hold2xStartRunnable)
                        if (gestureActiveMode == 4) {
                            endHold2xGesture()
                            return@setOnTouchListener true
                        }
                        if (gestureActiveMode == 3) {
                            gestureActiveMode = 0
                            vlcSeekTo(swipeSeekTargetMs)
                            hideGestureHudPill()
                            updateTimeAndSeekBar()
                            return@setOnTouchListener true
                        }
                        if (gestureActiveMode != 0) {
                            gestureActiveMode = 0
                            mainHandler.removeCallbacks(hideMetersRunnable)
                            mainHandler.postDelayed(hideMetersRunnable, 900L)
                            return@setOnTouchListener true
                        }
                        val moveDist = kotlin.math.hypot((event.x - gestureStartX).toDouble(), (event.y - gestureStartY).toDouble())
                        val nowMs = SystemClock.elapsedRealtime()
                        if (moveDist < dp(18) && (nowMs - gestureDownTimeMs) < 320L) {
                            val tapSide = when {
                                event.x < w * 0.35f -> -1
                                event.x > w * 0.65f -> 1
                                else -> 0
                            }
                            if (!isLiveStream && tapSide != 0 && activeSeekSide == tapSide && (nowMs - lastSeekEventTimeMs) < 850L) {
                                mainHandler.removeCallbacks(singleTapToggleRunnable)
                                triggerSeekStep(tapSide)
                            } else if (!isLiveStream && tapSide != 0 && tapSide == lastTapSide && (nowMs - lastTapTimeMs) < 320L) {
                                mainHandler.removeCallbacks(singleTapToggleRunnable)
                                lastTapTimeMs = 0L
                                triggerSeekStep(tapSide)
                            } else if (tapSide == 0 || isLiveStream) {
                                mainHandler.removeCallbacks(singleTapToggleRunnable)
                                lastTapTimeMs = 0L
                                lastTapSide = 0
                                singleTapToggleRunnable.run()
                            } else {
                                lastTapTimeMs = nowMs
                                lastTapSide = tapSide
                                mainHandler.removeCallbacks(singleTapToggleRunnable)
                                mainHandler.postDelayed(singleTapToggleRunnable, 270L)
                            }
                        }
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        mainHandler.removeCallbacks(hold2xStartRunnable)
                        if (gestureActiveMode == 4) {
                            endHold2xGesture()
                        } else if (gestureActiveMode == 3) {
                            gestureActiveMode = 0
                            hideGestureHudPill()
                        } else if (gestureActiveMode != 0) {
                            gestureActiveMode = 0
                            mainHandler.removeCallbacks(hideMetersRunnable)
                            mainHandler.postDelayed(hideMetersRunnable, 900L)
                        }
                    }
                }
                true
            }
            setContentView(root)
            enableImmersiveFullscreen()
            showControllerTemporarily()
            ppBtn.post { ppBtn.requestFocus() }

            parseIntentAndStart(intent)
        } catch (t: Throwable) {
            Toast.makeText(this, "Player initialization error: ${t.localizedMessage}", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun createNetflixSeekBarDrawable(focused: Boolean): LayerDrawable {
        val radius = dp(6).toFloat()
        val h = if (focused) dp(7) else dp(5)
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radius
            setColor(if (focused) Color.argb(120, 255, 255, 255) else Color.argb(72, 255, 255, 255))
            if (focused) {
                setStroke(dp(1), Color.argb(210, 255, 255, 255))
            }
            setSize(-1, h)
        }
        val prog = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radius
            setColor(if (focused) Color.rgb(255, 30, 42) else Color.rgb(229, 9, 20))
            setSize(-1, h)
        }
        val clip = ClipDrawable(prog, Gravity.START, ClipDrawable.HORIZONTAL)
        return LayerDrawable(arrayOf(bg, clip)).apply {
            setId(0, android.R.id.background)
            setId(1, android.R.id.progress)
        }
    }

    private fun createCircleBg(focused: Boolean): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            if (focused) {
                setColor(Color.argb(65, 255, 255, 255))
                setStroke(dp(2), Color.WHITE)
            } else {
                setColor(Color.TRANSPARENT)
            }
        }
    }

    private fun makeCircleVectorButton(iconKind: String, sizeDp: Int, onClick: (View) -> Unit): ImageButton {
        val px = dp(sizeDp)
        return ImageButton(this).apply {
            setImageDrawable(VectorIconDrawable(iconKind, Color.WHITE))
            scaleType = ImageView.ScaleType.FIT_CENTER
            background = createCircleBg(false)
            val pad = dp((sizeDp * 0.22f).toInt())
            setPadding(pad, pad, pad, pad)
            layoutParams = LinearLayout.LayoutParams(px, px)
            isFocusable = true
            isFocusableInTouchMode = false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                defaultFocusHighlightEnabled = false
            }
            setOnFocusChangeListener { v, hasFocus ->
                v.background = createCircleBg(hasFocus)
                v.animate()
                    .scaleX(if (hasFocus) 1.14f else 1.0f)
                    .scaleY(if (hasFocus) 1.14f else 1.0f)
                    .setDuration(140)
                    .setInterpolator(DecelerateInterpolator())
                    .start()
                if (hasFocus) showControllerTemporarily()
            }
            setOnClickListener(onClick)
        }
    }

    private fun createSecondaryBg(focused: Boolean): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(20).toFloat()
            if (focused) {
                setColor(Color.argb(95, 255, 255, 255))
                setStroke(dp(2), Color.WHITE)
            } else {
                setColor(Color.argb(28, 255, 255, 255))
                setStroke(dp(1), Color.argb(40, 255, 255, 255))
            }
        }
    }

    private fun makeSecondaryButton(label: String, onClick: (View) -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(Color.argb(235, 240, 240, 240))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            typeface = Typeface.DEFAULT_BOLD
            background = createSecondaryBg(false)
            setPadding(dp(16), dp(7), dp(16), dp(7))
            minWidth = 0
            minimumWidth = 0
            minHeight = 0
            minimumHeight = 0
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(dp(6), 0, dp(6), 0)
            }
            isFocusable = true
            isFocusableInTouchMode = false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                defaultFocusHighlightEnabled = false
            }
            setOnFocusChangeListener { v, hasFocus ->
                v.background = createSecondaryBg(hasFocus)
                v.animate()
                    .scaleX(if (hasFocus) 1.08f else 1.0f)
                    .scaleY(if (hasFocus) 1.08f else 1.0f)
                    .setDuration(140)
                    .setInterpolator(DecelerateInterpolator())
                    .start()
                if (hasFocus) showControllerTemporarily()
            }
            setOnClickListener(onClick)
        }
    }

    private fun showGestureHudPill(text: String, iconKind: String? = null) {
        val box = gestureHudContainer ?: return
        val iv = gestureHudIcon
        val tv = gestureHudPill ?: return
        box.animate().cancel()
        tv.text = text
        if (iconKind != null && iv != null) {
            iv.setImageDrawable(VectorIconDrawable(iconKind, Color.WHITE))
            iv.visibility = View.VISIBLE
        } else {
            iv?.visibility = View.GONE
        }
        box.visibility = View.VISIBLE
        box.alpha = 1f
    }

    private fun hideGestureHudPill() {
        val box = gestureHudContainer ?: return
        box.animate().alpha(0f).setDuration(160).withEndAction {
            if (gestureActiveMode != 3 && gestureActiveMode != 4) {
                box.visibility = View.GONE
            }
        }.start()
    }

    private fun formatSpeedText(sp: Float): String {
        val tenths = kotlin.math.round(sp * 10f).toInt()
        return if (tenths % 10 == 0) "${tenths / 10}x" else String.format(Locale.US, "%.1fx", tenths / 10f)
    }

    private fun endHold2xGesture() {
        hold2xLastAppliedSpeed = 0f
        gestureActiveMode = 0
        hold2xSide = 0
        vlcPlayer?.rate = hold2xSavedSpeed.coerceIn(0.25f, 3.0f)
        hideGestureHudPill()
    }

    private fun setControllerVisible(visible: Boolean) {
        isControllerVisible = visible
        val overlay = controllerOverlay ?: return
        val amb = ambientProgressBar
        val btm = bottomContainerRef
        if (visible) {
            if (overlay.visibility != View.VISIBLE) {
                overlay.alpha = 0f
                overlay.visibility = View.VISIBLE
                overlay.animate().alpha(1f).setDuration(220).start()
            }
            if (amb != null && amb.visibility == View.VISIBLE) {
                amb.animate().cancel()
                amb.translationY = 0f
                amb.scaleY = 1f
                amb.animate()
                    .alpha(0f)
                    .setDuration(220)
                    .withEndAction {
                        if (isControllerVisible) amb.visibility = View.GONE
                    }
                    .start()
            }
        } else {
            mainHandler.removeCallbacks(hideControllerRunnable)
            if (overlay.visibility == View.VISIBLE) {
                overlay.animate().alpha(0f).setDuration(220).withEndAction {
                    if (!isControllerVisible) {
                        overlay.visibility = View.GONE
                    }
                }.start()
            }
            if (amb != null) {
                amb.animate().cancel()
                amb.translationY = 0f
                amb.scaleY = 1f
                if (amb.visibility != View.VISIBLE) {
                    amb.alpha = 0f
                    amb.visibility = View.VISIBLE
                }
                amb.animate()
                    .alpha(1f)
                    .setDuration(240)
                    .start()
            }
        }
    }

    private fun showControllerTemporarily() {
        if (directWebPlayerMode) return
        setControllerVisible(true)
        mainHandler.removeCallbacks(hideControllerRunnable)
        mainHandler.removeCallbacks(hideLeftSeekRunnable)
        mainHandler.removeCallbacks(hideRightSeekRunnable)
        if (vlcIsPlaying()) {
            mainHandler.postDelayed(hideControllerRunnable, 4000L)
        }
    }

    private fun formatTimeMs(ms: Long): String {
        val totalSec = (ms / 1000L).coerceAtLeast(0L)
        val h = totalSec / 3600L
        val m = (totalSec % 3600L) / 60L
        val s = totalSec % 60L
        return if (h > 0) {
            String.format("%d:%02d:%02d", h, m, s)
        } else {
            String.format("%d:%02d", m, s)
        }
    }

    private fun applyLiveModeUi() {
        if (!isLiveStream) return
        topRestartContainerRef?.visibility = View.GONE
        topRestartBtn?.visibility = View.GONE
        rewBtnRef?.visibility = View.GONE
        fwdBtnRef?.visibility = View.GONE
        subBtn?.visibility = View.GONE
        styleBtnRef?.visibility = View.GONE
        syncBtnRef?.visibility = View.GONE
        audioBtnRef?.visibility = View.GONE
        speedBtnRef?.visibility = View.GONE
        aspectBtn?.visibility = View.GONE
        skip85BtnRef?.visibility = View.GONE
        sleepBtn?.visibility = View.VISIBLE
        seekBar?.isEnabled = false
        seekBar?.max = 1000
        seekBar?.progress = 1000
        seekBar?.thumb = android.graphics.drawable.ColorDrawable(Color.TRANSPARENT)
        currentPosView?.text = "0:00"
        durationView?.apply {
            text = "LIVE"
            setTextColor(Color.WHITE)
            setTypeface(null, Typeface.BOLD)
            setPadding(dp(8), dp(2), dp(8), dp(2))
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#E50914"))
                cornerRadius = dp(5).toFloat()
            }
        }
    }

    private fun killResolverMedia() {
        try {
            resolverWebView?.evaluateJavascript(
                "try{window.postMessage({__sbFetch:'stop',__sbStop:true},'*');var kill=function(d){if(!d)return;d.querySelectorAll('video,audio').forEach(function(v){try{v.pause();v.muted=true;v.volume=0;}catch(e){}});d.querySelectorAll('iframe').forEach(function(f){try{kill(f.contentDocument);}catch(e){}});};kill(document);}catch(e){}",
                null
            )
        } catch (_: Throwable) {}
    }

    private fun triggerResolverPlayFromUserTap() {
        if (directWebPlayerMode) return
        val wv = resolverWebView ?: return
        try {
            val nowT = android.os.SystemClock.uptimeMillis()
            val cx = wv.width.coerceAtLeast(360) / 2f
            val cy = wv.height.coerceAtLeast(250) / 2f
            wv.dispatchTouchEvent(MotionEvent.obtain(nowT, nowT, MotionEvent.ACTION_DOWN, cx, cy, 0))
            wv.dispatchTouchEvent(MotionEvent.obtain(nowT, nowT + 40L, MotionEvent.ACTION_UP, cx, cy, 0))
        } catch (_: Throwable) {}
        try {
            val js = "(function(){try{document.querySelectorAll('#pl_but,.play,.btn-play,.vjs-big-play-button,.vjs-poster,.jw-icon-display,.jw-display-icon-container,.plyr__control--overlaid,.plyr__poster,[data-plyr=play],[aria-label*=Play i],[title*=Play i],[class*=play-btn i],[class*=play_btn i],[id*=play-btn i],button').forEach(function(b){try{b.click();}catch(e){}});document.querySelectorAll('video').forEach(function(v){v.muted=true;v.play().catch(function(){});});var el=document.elementFromPoint(window.innerWidth/2,window.innerHeight/2);if(el){try{el.click();}catch(e){}}}catch(e){}})();"
            wv.evaluateJavascript(js, null)
        } catch (_: Throwable) {}
    }

    private fun toggleVlcPlayPause(forcePause: Boolean? = null) {
        if (vlcPlayer == null || streamUrl.isBlank() || !vlcPlaybackReady) {
            if (forcePause != true) {
                triggerResolverPlayFromUserTap()
                Toast.makeText(this, "Starting stream...", Toast.LENGTH_SHORT).show()
                showControllerTemporarily()
            }
            if (vlcPlayer == null) return
        }
        val p = vlcPlayer ?: return
        val currentlyPlaying = desiredPaused?.let { !it } ?: p.isPlaying
        val shouldPause = forcePause ?: currentlyPlaying
        if (shouldPause) {
            desiredPaused = true
            playPauseBtn?.setImageDrawable(VectorIconDrawable("play", Color.WHITE))
            try { if (p.isPlaying) p.pause() } catch (_: Throwable) {}
        } else {
            desiredPaused = false
            playPauseBtn?.setImageDrawable(VectorIconDrawable("pause", Color.WHITE))
            if (vlcDidEnd) {
                vlcDidEnd = false
                vlcPendingSeekMs = 0L
                try { p.stop() } catch (_: Throwable) {}
                try { p.play() } catch (_: Throwable) {}
            } else {
                try { if (!p.isPlaying) p.play() } catch (_: Throwable) {}
                try { if (!p.isPlaying) p.play() } catch (_: Throwable) {}
                if (kotlin.math.abs(p.rate - currentSpeed) > 0.01f) {
                    try { p.rate = currentSpeed } catch (_: Throwable) {}
                }
            }
        }
        updateTimeAndSeekBar()
    }

    private fun updateTimeAndSeekBar() {
        val player = vlcPlayer ?: return
        if (isLiveStream) {
            playPauseBtn?.setImageDrawable(VectorIconDrawable(if (desiredPaused?.let { !it } ?: player.isPlaying) "pause" else "play", Color.WHITE))
            val nowMs = SystemClock.elapsedRealtime()
            if (player.isPlaying) {
                if (lastLiveTickMs > 0L) {
                    val dt = nowMs - lastLiveTickMs
                    if (dt in 1L..5000L) liveElapsedMs += dt
                }
                lastLiveTickMs = nowMs
            } else {
                lastLiveTickMs = 0L
            }
            currentPosView?.text = formatTimeMs(liveElapsedMs)
            durationView?.text = "LIVE"
            seekBar?.progress = 1000
            ambientProgressFill?.scaleX = 1f
            return
        }
        val dur = vlcDurationMs()
        val pos = vlcCurrentPosMs()
        if (vlcPlaybackReady && dur > 0L && vlcPendingSeekMs <= 0L && (pos > 1000L || (startTimeSec <= 1L && player.isPlaying))) {
            hasRealPlaybackProgress = true
        }
        val minValidMs = if (mediaType.equals("tv", ignoreCase = true)) 60_000L else 180_000L
        if (!streamUrl.startsWith("/") && dur in 1L until minValidMs) {
            player.pause()
            recordServerStatus(currentSource, "failed")
            Toast.makeText(this, "Short/fake clip on $currentSource — switching...", Toast.LENGTH_SHORT).show()
            if (!isSwitchingServer) {
                triggerNextServerFailover()
            }
            return
        }
        if (!isSwitchingServer && !streamUrl.startsWith("/") && dur >= minValidMs && (pos > 500L || player.isPlaying)) {
            if (getServerStatus(currentSource) != "working") {
                recordServerStatus(currentSource, "working")
            }
        }
        playPauseBtn?.setImageDrawable(VectorIconDrawable(if (desiredPaused?.let { !it } ?: player.isPlaying) "pause" else "play", Color.WHITE))
        if (!isScrubbing && gestureActiveMode != 3) {
            val nowMs = SystemClock.elapsedRealtime()
            val isSeekLocked = nowMs < seekUiLockUntilMs && seekUiTargetMs >= 0L && kotlin.math.abs(pos - seekUiTargetMs) > 2000L
            if (!isSeekLocked) {
                if (nowMs < seekUiLockUntilMs && seekUiTargetMs >= 0L && kotlin.math.abs(pos - seekUiTargetMs) <= 2000L) {
                    seekUiLockUntilMs = 0L
                }
                currentPosView?.text = formatTimeMs(pos)
                val rem = (dur - pos).coerceAtLeast(0L)
                durationView?.text = if (dur > 0) "-${formatTimeMs(rem)}" else "-0:00"
                if (dur > 0) {
                    val frac = (pos.toFloat() / dur.toFloat()).coerceIn(0f, 1f)
                    seekBar?.progress = (frac * 1000f).toInt().coerceIn(0, 1000)
                    ambientProgressFill?.scaleX = frac
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        try {
            val rawJson = intent.getStringExtra(EXTRA_PAYLOAD_JSON) ?: return
            val obj = JSONObject(rawJson)
            val newUrl = obj.optString("url", "")
            if (newUrl.isBlank()) return
            if (newUrl == streamUrl && vlcPlayer != null) {
                return
            }
            val resumeSec = vlcCurrentPosMs() / 1000L
            if (resumeSec > 5L && obj.optLong("startTimeSec", 0L) <= 0L) {
                obj.put("startTimeSec", resumeSec)
                intent.putExtra(EXTRA_PAYLOAD_JSON, obj.toString())
            }
            parseIntentAndStart(intent)
        } catch (_: Throwable) {}
    }

    private fun applySubtitleStyle() {
        try {
            val fgColor = try { Color.parseColor(subTextColorHex) } catch (_: Throwable) { Color.WHITE }
            val bgColor = when (subBgStyleMode) {
                "none" -> Color.TRANSPARENT
                "semi" -> Color.argb(115, 0, 0, 0)
                else -> Color.argb(200, 0, 0, 0)
            }

            subtitleOverlayView?.apply {
                setTextColor(fgColor)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, subTextSizeSp)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 14f
                    setColor(bgColor)
                }
            }
        } catch (_: Throwable) {}
    }

    private fun parseIntentAndStart(intent: Intent?) {
        val rawJson = intent?.getStringExtra(EXTRA_PAYLOAD_JSON) ?: "{}"
        val obj = try {
            JSONObject(rawJson)
        } catch (_: Throwable) {
            JSONObject()
        }
        rawPayload = obj

        streamUrl = obj.optString("url", "")
        streamTitle = obj.optString("title", "SingularityTV")
        progressKey = obj.optString("progressKey").takeIf { it.isNotEmpty() }
        startTimeSec = obj.optLong("startTimeSec", 0L)
        imdbId = obj.optString("imdbId", "")
        mediaType = obj.optString("mediaType", "movie")
        applyLiveModeUi()
        seasonNum = obj.optInt("season", 1)
        episodeNum = obj.optInt("episode", 1)
        seriesTitleStr = obj.optString("seriesTitle", "").ifEmpty { streamTitle.substringBefore(" · S") }
        episodeRuntimeMin = obj.optInt("episodeRuntimeMin", 0)
        totalEpisodesInSeason = obj.optInt("totalEpisodes", 0)
        seasonEpisodesList.clear()
        val seasonsArr = obj.optJSONArray("seasons")
        if (seasonsArr != null) {
            val tmp = mutableListOf<Pair<Int, Int>>()
            for (i in 0 until seasonsArr.length()) {
                val so = seasonsArr.optJSONObject(i) ?: continue
                val sn = so.optInt("season_number", 0)
                val ec = so.optInt("episode_count", 0)
                if (sn > 0 && ec > 0) tmp.add(Pair(sn, ec))
            }
            tmp.sortBy { it.first }
            seasonEpisodesList.addAll(tmp)
        }
        preferredLang = obj.optString("preferredSubLang", "ar").ifBlank { "ar" }.substringBefore("-").lowercase()
        val mt = obj.optString("embedMovieTemplate", "").trim()
        if (mt.isNotEmpty()) embedMovieTemplate = mt
        val tt = obj.optString("embedTvTemplate", "").trim()
        if (tt.isNotEmpty()) embedTvTemplate = tt
        initialWebPrefsJson = obj.optString("webPlayerPrefs", "{}").ifBlank { "{}" }
        val prefs = getSharedPreferences("singularity_player_prefs", Context.MODE_PRIVATE)
        subTextColorHex = obj.optString("subTextColor", "").ifBlank { prefs.getString("sub_pref_color", "#FFFFFF") ?: "#FFFFFF" }
        subBgStyleMode = obj.optString("subBgStyle", "").ifBlank { prefs.getString("sub_pref_bg", "dark") ?: "dark" }
        val inSize = obj.optDouble("subFontSizeSp", 0.0).toFloat()
        subTextSizeSp = if (inSize in 12f..42f) inSize else prefs.getFloat("sub_pref_size", 22f).coerceIn(14f, 42f)
        prefs.edit()
            .putString("sub_pref_color", subTextColorHex)
            .putString("sub_pref_bg", subBgStyleMode)
            .putFloat("sub_pref_size", subTextSizeSp)
            .apply()
        applySubtitleStyle()
        titleView?.text = streamTitle
        updateTopActionButtons()
        serverBadgeView?.text = currentSource

        if (!isLiveStream && !streamUrl.startsWith("/")) {
            streamUrl = ""
            currentSource = "vidyst"
            serverBadgeView?.text = currentSource
            startResolvingInitialSource()
            return
        }

        availableSubs.clear()
        activeParsedCues.clear()
        activeSubIndex = -1

        val subsArray = obj.optJSONArray("subtitles") ?: obj.optJSONArray("subtitlePaths") ?: JSONArray()
        for (i in 0 until subsArray.length()) {
            val sObj = subsArray.optJSONObject(i) ?: continue
            val u = sObj.optString("url").ifEmpty { sObj.optString("path") }
            if (u.isBlank()) continue
            val lang = normalizeLangCode(sObj.optString("lang", "en"))
            val label = sObj.optString("label").ifBlank { "Stream · ${lang.uppercase()}" }
            availableSubs.add(PlayerSubTrack(label, lang, u, 120))
        }
        if (availableSubs.isNotEmpty()) {
            selectBestSubtitleForLanguage(preferredLang, silent = true)
        }

        initializeExoPlayer(obj)
        fetchOnlineSubtitlesInBackground()
    }

    private fun normalizeLangCode(raw: String): String {
        val full = raw.trim().lowercase().replace("_", "-")
        if (full == "pt-br" || full == "pob" || full == "pb" || full == "portuguese (brazil)") return "pt-br"
        val c = full.substringBefore("-")
        return when (c) {
            "ara", "arabic", "ar" -> "ar"
            "eng", "english", "en" -> "en"
            "fre", "fra", "french", "fr" -> "fr"
            "spa", "spanish", "es" -> "es"
            "ger", "deu", "german", "de" -> "de"
            "tur", "turkish", "tr" -> "tr"
            "por", "portuguese", "pt" -> "pt"
            "pob", "pb" -> "pt-br"
            "ita", "italian", "it" -> "it"
            "rus", "russian", "ru" -> "ru"
            "jpn", "japanese", "ja" -> "ja"
            "kor", "korean", "ko" -> "ko"
            "chi", "zho", "chinese", "zh", "zht", "zhs" -> "zh"
            "hin", "hindi", "hi" -> "hi"
            "ind", "indonesian", "id" -> "id"
            "dut", "nld", "dutch", "nl" -> "nl"
            "pol", "polish", "pl" -> "pl"
            "swe", "swedish", "sv" -> "sv"
            "gre", "ell", "greek", "el" -> "el"
            "per", "fas", "persian", "fa" -> "fa"
            "heb", "hebrew", "he", "iw" -> "he"
            "tha", "thai", "th" -> "th"
            "vie", "vietnamese", "vi" -> "vi"
            "bos", "bosnian", "bs" -> "bs"
            "bul", "bulgarian", "bg" -> "bg"
            "hrv", "scr", "croatian", "hr" -> "hr"
            "srp", "scc", "serbian", "sr" -> "sr"
            "ces", "cze", "czech", "cs" -> "cs"
            "slk", "slo", "slovak", "sk" -> "sk"
            "ron", "rum", "romanian", "ro" -> "ro"
            "ukr", "ukrainian", "uk" -> "uk"
            "hun", "hungarian", "hu" -> "hu"
            "fin", "finnish", "fi" -> "fi"
            "dan", "danish", "da" -> "da"
            "nor", "nob", "nno", "norwegian", "no" -> "no"
            "slv", "slovenian", "sl" -> "sl"
            "alb", "sqi", "albanian", "sq" -> "sq"
            "mac", "mkd", "macedonian", "mk" -> "mk"
            "est", "estonian", "et" -> "et"
            "lav", "latvian", "lv" -> "lv"
            "lit", "lithuanian", "lt" -> "lt"
            "may", "msa", "malay", "ms" -> "ms"
            "ben", "bengali", "bn" -> "bn"
            "urd", "urdu", "ur" -> "ur"
            "tam", "tamil", "ta" -> "ta"
            "tel", "telugu", "te" -> "te"
            "cat", "catalan", "ca" -> "ca"
            "baq", "eus", "basque", "eu" -> "eu"
            "glg", "galician", "gl" -> "gl"
            "ice", "isl", "icelandic", "is" -> "is"
            "geo", "kat", "georgian", "ka" -> "ka"
            "arm", "hye", "armenian", "hy" -> "hy"
            "aze", "azerbaijani", "az" -> "az"
            "kaz", "kazakh", "kk" -> "kk"
            "uzb", "uzbek", "uz" -> "uz"
            "tgl", "tagalog", "tl" -> "tl"
            "fil", "filipino" -> "fil"
            "swa", "swahili", "sw" -> "sw"
            "afr", "afrikaans", "af" -> "af"
            "mal", "malayalam", "ml" -> "ml"
            "mar", "marathi", "mr" -> "mr"
            "kan", "kannada", "kn" -> "kn"
            "pan", "punjabi", "pa" -> "pa"
            "sin", "sinhala", "si" -> "si"
            "bur", "mya", "burmese", "my" -> "my"
            "khm", "khmer", "km" -> "km"
            "lao", "la" -> "lo"
            "mon", "mongolian", "mn" -> "mn"
            "nep", "nepali", "ne" -> "ne"
            "amh", "amharic", "am" -> "am"
            "kur", "kurdish", "ku" -> "ku"
            "pus", "pashto", "ps" -> "ps"
            "epo", "esperanto", "eo" -> "eo"
            "gle", "irish", "ga" -> "ga"
            "wel", "cym", "welsh", "cy" -> "cy"
            "mlt", "maltese", "mt" -> "mt"
            "bel", "belarusian", "be" -> "be"
            else -> if (c.isNotEmpty()) c else "en"
        }
    }

    private fun langDisplayName(code: String): String {
        val norm = normalizeLangCode(code)
        return when (norm) {
            "ar" -> "Arabic"
            "en" -> "English"
            "ko" -> "Korean"
            "ja" -> "Japanese"
            "fr" -> "French"
            "es" -> "Spanish"
            "de" -> "German"
            "tr" -> "Turkish"
            "pt" -> "Portuguese"
            "pt-br" -> "Portuguese (Brazil)"
            "it" -> "Italian"
            "ru" -> "Russian"
            "hi" -> "Hindi"
            "id" -> "Indonesian"
            "zh" -> "Chinese"
            "nl" -> "Dutch"
            "pl" -> "Polish"
            "sv" -> "Swedish"
            "th" -> "Thai"
            "vi" -> "Vietnamese"
            "fa" -> "Persian"
            "bs" -> "Bosnian"
            "bg" -> "Bulgarian"
            "hr" -> "Croatian"
            "sr" -> "Serbian"
            "cs" -> "Czech"
            "sk" -> "Slovak"
            "ro" -> "Romanian"
            "el" -> "Greek"
            "he" -> "Hebrew"
            "uk" -> "Ukrainian"
            "hu" -> "Hungarian"
            "fi" -> "Finnish"
            "da" -> "Danish"
            "no" -> "Norwegian"
            "sl" -> "Slovenian"
            "sq" -> "Albanian"
            "mk" -> "Macedonian"
            "et" -> "Estonian"
            "lv" -> "Latvian"
            "lt" -> "Lithuanian"
            "ms" -> "Malay"
            "bn" -> "Bengali"
            "ur" -> "Urdu"
            "ta" -> "Tamil"
            "te" -> "Telugu"
            "ca" -> "Catalan"
            "eu" -> "Basque"
            "gl" -> "Galician"
            "is" -> "Icelandic"
            "ka" -> "Georgian"
            "hy" -> "Armenian"
            "az" -> "Azerbaijani"
            "kk" -> "Kazakh"
            "uz" -> "Uzbek"
            "tl" -> "Tagalog"
            "fil" -> "Filipino"
            "sw" -> "Swahili"
            "af" -> "Afrikaans"
            "ml" -> "Malayalam"
            "mr" -> "Marathi"
            "kn" -> "Kannada"
            "pa" -> "Punjabi"
            "si" -> "Sinhala"
            "my" -> "Burmese"
            "km" -> "Khmer"
            "lo" -> "Lao"
            "mn" -> "Mongolian"
            "ne" -> "Nepali"
            "am" -> "Amharic"
            "ku" -> "Kurdish"
            "ps" -> "Pashto"
            "eo" -> "Esperanto"
            "ga" -> "Irish"
            "cy" -> "Welsh"
            "mt" -> "Maltese"
            "be" -> "Belarusian"
            else -> try {
                val loc = Locale.forLanguageTag(norm)
                val name = loc.getDisplayLanguage(Locale.ENGLISH)
                if (name.isNotBlank() && !name.equals(norm, ignoreCase = true) && !name.equals("und", ignoreCase = true)) {
                    name.replaceFirstChar { it.uppercase() }
                } else {
                    norm.uppercase()
                }
            } catch (_: Throwable) {
                norm.uppercase()
            }
        }
    }

    private fun scoreTrackForCurrentStream(track: PlayerSubTrack): Int {
        var s = track.score
        val u = track.label.uppercase()
        if (activeQualityTag.isNotEmpty() && u.contains(activeQualityTag)) {
            s += 35
        }
        if (streamUrl.contains("vidsrc", ignoreCase = true) || streamUrl.contains("m3u8", ignoreCase = true)) {
            if (Regex("WEB[-_. ]?DL|WEBRIP|NF|AMZN|DSNP|ATVP|HMAX").containsMatchIn(u)) {
                s += 40
            }
        }
        return s
    }

    private fun selectBestSubtitleForLanguage(langCode: String, silent: Boolean = false): Boolean {
        val norm = normalizeLangCode(langCode)
        val matches = availableSubs.mapIndexedNotNull { idx, t ->
            if (t.lang == norm) idx to scoreTrackForCurrentStream(t) else null
        }.sortedByDescending { it.second }

        if (matches.isEmpty()) {
            if (!silent) {
                offerServerSwitchForLanguage(norm)
            }
            return false
        }

        val bestIdx = matches.first().first
        activeSubIndex = bestIdx
        preferredLang = norm
        subBtn?.text = "Subtitles (${availableSubs.size})"
        loadSubtitleCuesAsync(bestIdx)
        if (!silent) {
            Toast.makeText(
                this,
                "Auto-synced ${langDisplayName(norm)}: ${availableSubs[bestIdx].label}",
                Toast.LENGTH_SHORT
            ).show()
        }
        return true
    }

    private fun offerServerSwitchForLanguage(langCode: String) {
        AlertDialog.Builder(this)
            .setTitle("No ${langDisplayName(langCode)} Subtitle on This Server")
            .setMessage("Would you like to switch to another streaming server and load a matching ${langDisplayName(langCode)} subtitle?")
            .setPositiveButton("Switch Server") { _, _ ->
                saveCurrentProgress()
                ExoProgressBus.serverSwitchListener?.invoke(langCode)
                finish()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun mergeFetchedTracks(batch: List<PlayerSubTrack>) {
        if (batch.isEmpty()) return
        runOnUiThread {
            if (isDestroyed) return@runOnUiThread
            val existingUrls = availableSubs.map { it.urlOrPath }.toHashSet()
            val fresh = batch.filter { it.urlOrPath !in existingUrls }.sortedByDescending { it.score }
            if (fresh.isEmpty()) return@runOnUiThread
            val wasEmpty = activeSubIndex == -1
            availableSubs.addAll(fresh)
            subBtn?.text = "Subtitles (${availableSubs.size})"
            if (wasEmpty) {
                if (!selectBestSubtitleForLanguage(preferredLang, silent = true)) {
                    selectBestSubtitleForLanguage("ar", silent = true) || selectBestSubtitleForLanguage("en", silent = true)
                }
            }
        }
    }

    private fun queryWyzieLanguage(qLang: String): List<PlayerSubTrack> {
        val list = mutableListOf<PlayerSubTrack>()
        try {
            val qs = StringBuilder("id=${URLEncoder.encode(imdbId, "UTF-8")}&format=srt")
            if (qLang.isNotEmpty()) {
                qs.append("&language=").append(URLEncoder.encode(qLang, "UTF-8"))
            }
            if (mediaType == "tv") {
                qs.append("&season=").append(seasonNum).append("&episode=").append(episodeNum)
            }
            val req = Request.Builder()
                .url("https://subs.wyzie.ru/search?$qs")
                .header("User-Agent", "SingularityTV/2.7.3")
                .build()
            StreambertApp.instance.okHttpClient.newCall(req).execute().use { res ->
                if (res.isSuccessful) {
                    val body = res.body?.string()?.trim() ?: "[]"
                    if (body.startsWith("[")) {
                        val arr = JSONArray(body)
                        for (i in 0 until arr.length()) {
                            val item = arr.optJSONObject(i) ?: continue
                            val rawUrl = item.optString("url")
                            if (rawUrl.isBlank()) continue
                            val fullUrl = if (rawUrl.startsWith("http")) rawUrl else "https://subs.wyzie.ru$rawUrl"
                            val rawItemLang = item.optString("language")
                                .ifBlank { item.optString("lang") }
                                .ifBlank { item.optString("iso639") }
                                .ifBlank { qLang.ifEmpty { "en" } }
                            val lang = normalizeLangCode(rawItemLang)
                            val rel = item.optString("display_name")
                                .ifBlank { item.optString("release_name") }
                                .ifBlank { "Wyzie ${langDisplayName(lang)} #${i + 1}" }
                            if (!isSubtitleMatchingCurrentEpisode(rel)) continue
                            val sc = scoreReleaseName(rel) + if (lang == preferredLang || lang == "ar") 35 else 0
                            list.add(PlayerSubTrack("${langDisplayName(lang)} · $rel", lang, fullUrl, sc))
                        }
                    }
                }
            }
        } catch (_: Throwable) {}
        return list
    }

    private fun isSubtitleMatchingCurrentEpisode(
        relName: String,
        seasonField: String = "",
        episodeField: String = "",
        kindField: String = "",
        requireExplicitOnTv: Boolean = false
    ): Boolean {
        val isTv = mediaType.equals("tv", ignoreCase = true)
        val sInt = seasonField.trim().toIntOrNull() ?: 0
        val eInt = episodeField.trim().toIntOrNull() ?: 0
        val kTrim = kindField.trim().lowercase()
        val hasExactFields = isTv && sInt > 0 && eInt > 0
        if (isTv) {
            if (sInt > 0 && sInt != seasonNum) return false
            if (eInt > 0 && eInt != episodeNum) return false
        } else {
            if (kTrim == "episode") return false
            if (sInt > 0 || eInt > 0) return false
        }
        val l = relName.lowercase()
        if (l.isBlank()) return if (isTv) (hasExactFields || !requireExplicitOnTv) else true
        val epRegex = Regex("(?:s(\\d{1,2})[\\s._-]*e(\\d{1,2})|\\b(\\d{1,2})x(\\d{1,2})\\b)")
        val matches = epRegex.findAll(l).toList()
        if (matches.isNotEmpty()) {
            if (!isTv) return false
            var foundMatch = false
            for (m in matches) {
                val sStr = m.groupValues[1].ifEmpty { m.groupValues[3] }
                val eStr = m.groupValues[2].ifEmpty { m.groupValues[4] }
                val sVal = sStr.toIntOrNull()
                val eVal = eStr.toIntOrNull()
                if (sVal == seasonNum && eVal == episodeNum) {
                    foundMatch = true
                    break
                }
            }
            return foundMatch
        }
        if (isTv) {
            if (l.contains("complete") || l.contains("season pack") || l.contains("full season")) {
                return false
            }
            val epOnly = Regex("(?:\\bepisode[\\s._-]*(\\d{1,2})\\b|\\bep[\\s._-]*(\\d{1,2})\\b|\\be(\\d{1,2})\\b)")
            val epMatches = epOnly.findAll(l).toList()
            if (epMatches.isNotEmpty()) {
                var foundEp = false
                for (m in epMatches) {
                    val eStr = m.groupValues[1].ifEmpty { m.groupValues[2].ifEmpty { m.groupValues[3] } }
                    if (eStr.toIntOrNull() == episodeNum) {
                        foundEp = true
                        break
                    }
                }
                return foundEp
            }
            if (requireExplicitOnTv && !hasExactFields) return false
        }
        return true
    }

    private fun fetchOnlineSubtitlesInBackground() {
        val wyzieId = tmdbId.ifEmpty { imdbId }
        if (wyzieId.isNotEmpty()) {
            thread(start = true) {
                val wList = mutableListOf<PlayerSubTrack>()
                try {
                    val wUrl = if (mediaType.equals("tv", ignoreCase = true)) {
                        "https://sub.wyzie.ru/search?id=${URLEncoder.encode(wyzieId, "UTF-8")}&season=$seasonNum&episode=$episodeNum"
                    } else {
                        "https://sub.wyzie.ru/search?id=${URLEncoder.encode(wyzieId, "UTF-8")}"
                    }
                    val req = Request.Builder().url(wUrl).header("User-Agent", "SingularityTV/3.0").build()
                    StreambertApp.instance.okHttpClient.newCall(req).execute().use { res ->
                        if (res.isSuccessful) {
                            val arr = JSONArray(res.body?.string() ?: "[]")
                            val perLang = HashMap<String, Int>()
                            for (i in 0 until minOf(arr.length(), 200)) {
                                val item = arr.optJSONObject(i) ?: continue
                                val u = item.optString("url")
                                if (u.isBlank()) continue
                                val rawLang = item.optString("language").ifBlank { item.optString("display", "en") }
                                val normLang = normalizeLangCode(rawLang)
                                val cnt = (perLang[normLang] ?: 0) + 1
                                perLang[normLang] = cnt
                                val bonus = if (normLang == "ar" || normLang == preferredLang) 35 else 0
                                wList.add(PlayerSubTrack("${langDisplayName(normLang)} · Wyzie #$cnt", normLang, u, 85 + bonus))
                            }
                        }
                    }
                } catch (_: Throwable) {}
                mergeFetchedTracks(wList)
            }
        }
        if (!imdbId.startsWith("tt")) return
        val osType = if (mediaType == "tv") "series" else "movie"
        val osTarget = if (mediaType == "tv") "$imdbId:$seasonNum:$episodeNum" else imdbId
        val stremioUrls = listOf(
            "https://opensubtitles-v3.strem.io/subtitles/$osType/${URLEncoder.encode(osTarget, "UTF-8")}.json"
        )
        for (stUrl in stremioUrls) {
            thread(start = true) {
                val osList = mutableListOf<PlayerSubTrack>()
                try {
                    val req = Request.Builder()
                        .url(stUrl)
                        .header("User-Agent", "SingularityTV/2.7.3")
                        .build()
                    StreambertApp.instance.okHttpClient.newCall(req).execute().use { res ->
                        if (res.isSuccessful) {
                            val root = JSONObject(res.body?.string() ?: "{}")
                            val subs = root.optJSONArray("subtitles") ?: JSONArray()
                            val perLangCount = HashMap<String, Int>()
                            for (i in 0 until minOf(subs.length(), 300)) {
                                val s = subs.optJSONObject(i) ?: continue
                                val u = s.optString("url")
                                val rawLang = s.optString("lang").ifBlank { "en" }
                                if (u.isBlank()) continue
                                val relHint = listOf(
                                    s.optString("SubFileName"),
                                    s.optString("title"),
                                    s.optString("name"),
                                    s.optString("release"),
                                    s.optString("id"),
                                    u
                                ).filter { it.isNotBlank() }.joinToString(" ")
                                if (!isSubtitleMatchingCurrentEpisode(relHint)) continue
                                val normLang = normalizeLangCode(rawLang)
                                val cnt = (perLangCount[normLang] ?: 0) + 1
                                perLangCount[normLang] = cnt
                                val bonus = if (normLang == "ar" || normLang == preferredLang) 35 else 0
                                osList.add(PlayerSubTrack("${langDisplayName(normLang)} · OpenSubtitles #$cnt", normLang, u, 75 + bonus))
                            }
                        }
                    }
                } catch (_: Throwable) {}
                mergeFetchedTracks(osList)
            }
        }

        val numericImdb = imdbId.removePrefix("tt")
        if (numericImdb.isNotEmpty()) {
            val worldLangs = listOf("ara", "eng", "spa", "fre", "ger", "tur", "por", "ita", "rus", "jpn", "kor", "hin", "all")
            for (wLang in worldLangs) {
                thread(start = true) {
                    val restList = mutableListOf<PlayerSubTrack>()
                    try {
                        val restUrl = if (mediaType == "tv") {
                            "https://rest.opensubtitles.org/search/episode-$episodeNum/imdbid-$numericImdb/season-$seasonNum/sublanguageid-$wLang"
                        } else {
                            "https://rest.opensubtitles.org/search/imdbid-$numericImdb/sublanguageid-$wLang"
                        }
                        val req = Request.Builder()
                            .url(restUrl)
                            .header("X-User-Agent", "TemporaryUserAgent")
                            .header("User-Agent", "TemporaryUserAgent")
                            .build()
                        StreambertApp.instance.okHttpClient.newCall(req).execute().use { res ->
                            if (res.isSuccessful) {
                                val body = res.body?.string()?.trim() ?: "[]"
                                if (body.startsWith("[")) {
                                    val arr = JSONArray(body)
                                    val perLang = HashMap<String, Int>()
                                    for (i in 0 until minOf(arr.length(), 60)) {
                                        val item = arr.optJSONObject(i) ?: continue
                                        val rawDl = item.optString("SubDownloadLink")
                                        if (rawDl.isBlank()) continue
                                        val dlUrl = rawDl.replace(".gz", "")
                                        val iso = item.optString("ISO639").ifBlank { item.optString("SubLanguageID").ifBlank { "en" } }
                                        val normLang = normalizeLangCode(iso)
                                        val rel = item.optString("MovieReleaseName").ifBlank { item.optString("SubFileName").ifBlank { "" } }
                                        val cleanNum = numericImdb.trimStart('0')
                                        val itemImdb = item.optString("IDMovieImdb").removePrefix("tt").trim().trimStart('0')
                                        val parentImdb = item.optString("SeriesIMDBParent").removePrefix("tt").trim().trimStart('0')
                                        val isTv = mediaType.equals("tv", ignoreCase = true)
                                        if (!isTv && itemImdb.isNotEmpty() && itemImdb != cleanNum) continue
                                        if (isTv && parentImdb.isNotEmpty() && parentImdb != cleanNum) continue
                                        val sField = item.optString("SeriesSeason")
                                        val eField = item.optString("SeriesEpisode")
                                        val kField = item.optString("MovieKind")
                                        if (!isSubtitleMatchingCurrentEpisode(rel, sField, eField, kField, requireExplicitOnTv = true)) continue
                                        val cnt = (perLang[normLang] ?: 0) + 1
                                        perLang[normLang] = cnt
                                        val displayRel = rel.ifBlank { "OS #$cnt" }
                                        val sc = scoreReleaseName(displayRel) + if (normLang == "ar" || normLang == preferredLang) 35 else 0
                                        restList.add(PlayerSubTrack("${langDisplayName(normLang)} · $displayRel", normLang, dlUrl, sc + 20))
                                    }
                                }
                            }
                        }
                    } catch (_: Throwable) {}
                    mergeFetchedTracks(restList)
                }
            }
        }
    }

    private fun scoreReleaseName(name: String): Int {
        val u = name.uppercase()
        var score = 0
        if (Regex("WEB[-_. ]?DL|WEBRIP|AMZN|NF|DSNP|ATVP|HMAX").containsMatchIn(u)) score += 55
        if (Regex("1080P|720P|X264|H264").containsMatchIn(u)) score += 20
        if (Regex("EXTENDED|DIRECTORS|UNRATED|CAM|TS").containsMatchIn(u)) score -= 50
        return score
    }

    private fun buildPlayerMediaItem(url: String): MediaItem {
        val uri = if (url.startsWith("/")) Uri.fromFile(File(url)) else Uri.parse(url)
        val builder = MediaItem.Builder().setUri(uri)
        val lower = url.lowercase()
        if (streamIsHlsMap[url] == true || lower.contains(".m3u8") || lower.contains("master.txt") || lower.contains("playlist.txt") || lower.contains("/hls/") || lower.contains("/hls2/") || lower.contains("type=hls")) {
            builder.setMimeType(MimeTypes.APPLICATION_M3U8)
        } else if (lower.contains(".mpd")) {
            builder.setMimeType(MimeTypes.APPLICATION_MPD)
        }
        return builder.build()
    }

    private fun fetchViaWebViewProxy(url: String): ByteArray {
        val id = "p" + proxySeq.getAndIncrement()
        val fut = java.util.concurrent.CompletableFuture<Pair<Int, ByteArray?>>()
        proxyWaiters[id] = fut
        val js = "window.postMessage({__sbFetch:${JSONObject.quote(id)},url:${JSONObject.quote(url)}},'*');"
        mainHandler.post {
            try {
                resolverWebView?.evaluateJavascript(js, null)
            } catch (_: Throwable) {
                proxyWaiters.remove(id)?.complete(Pair(0, null))
            }
        }
        val res = try {
            fut.get(18, java.util.concurrent.TimeUnit.SECONDS)
        } catch (_: Throwable) {
            proxyWaiters.remove(id)
            Pair(0, null)
        }
        val bytes = res.second
        if (bytes != null && bytes.isNotEmpty()) return bytes
        throw java.io.IOException("WebView proxy HTTP ${res.first} for $url")
    }

    private fun createWebViewProxyDataSourceFactory(): androidx.media3.datasource.DataSource.Factory {
        return androidx.media3.datasource.DataSource.Factory {
            object : androidx.media3.datasource.BaseDataSource(true) {
                private var data: ByteArray? = null
                private var readPos = 0
                private var bytesRem = 0
                private var currentUri: Uri? = null
                private var fileDs: androidx.media3.datasource.FileDataSource? = null

                override fun open(dataSpec: androidx.media3.datasource.DataSpec): Long {
                    currentUri = dataSpec.uri
                    if (dataSpec.uri.scheme == "file" || dataSpec.uri.scheme == null) {
                        val fds = androidx.media3.datasource.FileDataSource()
                        fileDs = fds
                        return fds.open(dataSpec)
                    }
                    transferInitializing(dataSpec)
                    val full = fetchViaWebViewProxy(dataSpec.uri.toString())
                    val start = dataSpec.position.toInt().coerceIn(0, full.size)
                    val maxLen = if (dataSpec.length != C.LENGTH_UNSET.toLong()) {
                        minOf(dataSpec.length.toInt(), full.size - start)
                    } else {
                        full.size - start
                    }
                    data = full
                    readPos = start
                    bytesRem = maxLen.coerceAtLeast(0)
                    transferStarted(dataSpec)
                    return bytesRem.toLong()
                }

                override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
                    fileDs?.let { return it.read(buffer, offset, length) }
                    if (length == 0) return 0
                    if (bytesRem == 0) return C.RESULT_END_OF_INPUT
                    val buf = data ?: return C.RESULT_END_OF_INPUT
                    val toRead = minOf(length, bytesRem)
                    System.arraycopy(buf, readPos, buffer, offset, toRead)
                    readPos += toRead
                    bytesRem -= toRead
                    bytesTransferred(toRead)
                    return toRead
                }

                override fun getUri(): Uri? = fileDs?.uri ?: currentUri

                override fun close() {
                    fileDs?.close()
                    fileDs = null
                    if (data != null) {
                        data = null
                        transferEnded()
                    }
                    currentUri = null
                }
            }
        }
    }


    private fun ensureLocalProxyRunning(): Int {
        if (localProxyServer != null && localProxyPort > 0 && localProxyServer?.isClosed == false) {
            return localProxyPort
        }
        stopLocalProxy()
        val ss = java.net.ServerSocket(0, 50, java.net.InetAddress.getByName("127.0.0.1"))
        val port = ss.localPort
        val pool = java.util.concurrent.Executors.newCachedThreadPool()
        localProxyServer = ss
        localProxyPort = port
        localProxyPool = pool
        thread(isDaemon = true) {
            while (!ss.isClosed && !isFinishing && !isDestroyed) {
                val sock = try { ss.accept() } catch (_: Throwable) { break }
                pool.execute { handleLocalProxyClient(sock, port) }
            }
        }
        return port
    }

    private fun stopLocalProxy() {
        try { localProxyServer?.close() } catch (_: Throwable) {}
        localProxyServer = null
        localProxyPort = 0
        try { localProxyPool?.shutdownNow() } catch (_: Throwable) {}
        localProxyPool = null
    }

    private fun rewriteM3u8ForLocalProxy(text: String, baseUrl: String, port: Int): String {
        val out = StringBuilder()
        val baseUri = try { java.net.URI(baseUrl) } catch (_: Throwable) { null }
        fun resolveAbs(rel: String): String {
            val trimmed = rel.trim()
            if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) return trimmed
            return try {
                baseUri?.resolve(trimmed)?.toString() ?: trimmed
            } catch (_: Throwable) {
                trimmed
            }
        }
        fun proxyWrap(absUrl: String): String {
            return "http://127.0.0.1:$port/stream?u=" + URLEncoder.encode(absUrl, "UTF-8")
        }
        val uriRegex = Regex("URI=\"([^\"]+)\"")
        for (rawLine in text.replace("\uFEFF", "").split(Regex("\\r?\\n"))) {
            val trimmed = rawLine.trim()
            if (trimmed.isEmpty()) continue
            if (trimmed.startsWith("#")) {
                val replaced = uriRegex.replace(rawLine) { m ->
                    val abs = resolveAbs(m.groupValues[1])
                    "URI=\"${proxyWrap(abs)}\""
                }
                out.append(replaced).append('\n')
            } else {
                val abs = resolveAbs(trimmed)
                out.append(proxyWrap(abs)).append('\n')
            }
        }
        return out.toString()
    }

    private fun handleLocalProxyClient(sock: java.net.Socket, port: Int) {
        try {
            sock.soTimeout = 20000
            val reader = java.io.BufferedReader(java.io.InputStreamReader(sock.getInputStream()))
            val reqLine = reader.readLine() ?: return
            val parts = reqLine.split(" ")
            if (parts.size < 2) return
            val path = parts[1]
            var rangeHeader: String? = null
            while (true) {
                val h = reader.readLine() ?: break
                if (h.isEmpty()) break
                if (h.startsWith("Range:", ignoreCase = true)) {
                    rangeHeader = h.substringAfter(":").trim()
                }
            }
            val out = sock.getOutputStream()
            val qIdx = path.indexOf("u=")
            if (qIdx < 0) {
                out.write("HTTP/1.1 400 Bad Request\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".toByteArray())
                return
            }
            val encodedTarget = path.substring(qIdx + 2).substringBefore("&")
            val targetUrl = java.net.URLDecoder.decode(encodedTarget, "UTF-8")

            var bodyBytes: ByteArray? = null
            var contentType = "application/octet-stream"
            var statusCode = 200
            var contentRange: String? = null

            if (targetUrl.startsWith("/")) {
                val f = File(targetUrl)
                if (f.exists()) {
                    val txt = f.readText()
                    val base = lastInlineM3u8Ref.ifEmpty { localProxyReferer }
                    val rewritten = rewriteM3u8ForLocalProxy(txt, base, port)
                    bodyBytes = rewritten.toByteArray(Charsets.UTF_8)
                    contentType = "application/vnd.apple.mpegurl"
                }
            } else {
                if (!localProxyForceWebView) {
                    try {
                        val rb = Request.Builder()
                            .url(targetUrl)
                            .header("User-Agent", localProxyUserAgent)
                            .header("Accept", "*/*")
                            .header("Accept-Language", "en-US,en;q=0.9")
                        val ref = localProxyReferer
                        if (ref.isNotEmpty()) {
                            rb.header("Referer", ref)
                            try {
                                val pu = Uri.parse(ref)
                                if (!pu.scheme.isNullOrEmpty() && !pu.host.isNullOrEmpty()) {
                                    rb.header("Origin", "${pu.scheme}://${pu.host}")
                                }
                            } catch (_: Throwable) {}
                        }
                        val ck = try { CookieManager.getInstance().getCookie(targetUrl) ?: "" } catch (_: Throwable) { "" }
                        if (ck.isNotEmpty()) rb.header("Cookie", ck)
                        if (!rangeHeader.isNullOrEmpty()) rb.header("Range", rangeHeader)

                        StreambertApp.instance.okHttpClient.newCall(rb.build()).execute().use { resp ->
                            if (resp.isSuccessful) {
                                statusCode = resp.code
                                contentType = resp.header("Content-Type") ?: contentType
                                contentRange = resp.header("Content-Range")
                                bodyBytes = resp.body?.bytes()
                            } else if (resp.code == 403 || resp.code == 401 || resp.code == 503) {
                                localProxyForceWebView = true
                            }
                        }
                    } catch (_: Throwable) {}
                }

                if (bodyBytes == null) {
                    try {
                        val wvBytes = fetchViaWebViewProxy(targetUrl)
                        if (wvBytes.isNotEmpty()) {
                            bodyBytes = wvBytes
                            statusCode = 200
                        }
                    } catch (_: Throwable) {}
                }

                val raw = bodyBytes
                if (raw != null && raw.size in 10..2_000_000) {
                    val head = String(raw, 0, minOf(64, raw.size), Charsets.UTF_8).replace("\uFEFF", "").trim()
                    if (head.startsWith("#EXTM3U") || targetUrl.lowercase().contains(".m3u8")) {
                        val rewritten = rewriteM3u8ForLocalProxy(String(raw, Charsets.UTF_8), targetUrl, port)
                        bodyBytes = rewritten.toByteArray(Charsets.UTF_8)
                        contentType = "application/vnd.apple.mpegurl"
                    }
                }
            }

            val finalBytes = bodyBytes
            if (finalBytes == null) {
                out.write("HTTP/1.1 502 Bad Gateway\r\nContent-Length: 0\r\nConnection: close\r\n\r\n".toByteArray())
                return
            }
            val statusLine = if (statusCode == 206) "HTTP/1.1 206 Partial Content" else "HTTP/1.1 200 OK"
            val hdr = StringBuilder()
            hdr.append(statusLine).append("\r\n")
            hdr.append("Content-Type: ").append(contentType).append("\r\n")
            hdr.append("Content-Length: ").append(finalBytes.size).append("\r\n")
            if (!contentRange.isNullOrEmpty() && statusCode == 206) {
                hdr.append("Content-Range: ").append(contentRange).append("\r\n")
            }
            hdr.append("Accept-Ranges: bytes\r\n")
            hdr.append("Connection: close\r\n\r\n")
            out.write(hdr.toString().toByteArray(Charsets.UTF_8))
            out.write(finalBytes)
            out.flush()
        } catch (_: Throwable) {
        } finally {
            try { sock.close() } catch (_: Throwable) {}
        }
    }

    private fun releaseVlcAsync(mp: MediaPlayer?, lib: LibVLC? = null) {
        if (mp != null) {
            try { mp.setEventListener(null) } catch (_: Throwable) {}
            try { mp.detachViews() } catch (_: Throwable) {}
        }
        if (mp == null && lib == null) return
        thread(start = true) {
            try { mp?.stop() } catch (_: Throwable) {}
            try { mp?.release() } catch (_: Throwable) {}
            try { lib?.release() } catch (_: Throwable) {}
        }
    }

    private fun initializeExoPlayer(payload: JSONObject) {
        try {
            vlcPlaybackToken++
            val myToken = vlcPlaybackToken
            lastRawPayload = payload
            vlcPlaybackReady = false
            hasRealPlaybackProgress = false
            vlcVideoOutCount = 0
            vlcVideoConfirmed = false
            desiredPaused = null
            val prevMp = vlcPlayer
            vlcPlayer = null
            if (prevMp != null) {
                try { prevMp.setEventListener(null) } catch (_: Throwable) {}
                try { prevMp.detachViews() } catch (_: Throwable) {}
                try { prevMp.stop() } catch (_: Throwable) {}
                try { prevMp.release() } catch (_: Throwable) {}
            }

            currentSource = payload.optString("currentSource", currentSource).ifBlank { currentSource }
            streamTitle = payload.optString("title", streamTitle).ifBlank { "Now Playing" }
            streamUrl = payload.optString("url", streamUrl)
            mediaType = payload.optString("mediaType", mediaType)
            applyLiveModeUi()
            tmdbId = payload.optString("tmdbId", tmdbId)
            imdbId = payload.optString("imdbId", imdbId)
            seasonNum = payload.optInt("season", seasonNum)
            episodeNum = payload.optInt("episode", episodeNum)
            totalEpisodesInSeason = payload.optInt("totalEpisodes", totalEpisodesInSeason)
            seriesTitleStr = payload.optString("seriesTitle", seriesTitleStr)
            progressKey = payload.optString("progressKey", progressKey ?: "").ifBlank { null }
            startTimeSec = payload.optLong("startTimeSec", startTimeSec)
            vlcPendingSeekMs = startTimeSec * 1000L
            preferredLang = normalizeLangCode(payload.optString("preferredLang", preferredLang))

            titleView?.text = streamTitle
            updateTopActionButtons()

            if (streamUrl.isBlank()) {
                Toast.makeText(this, "No stream URL provided", Toast.LENGTH_LONG).show()
                return
            }

            if (libVlc == null) {
                val args = arrayListOf(
                    "--network-caching=1500",
                    "--live-caching=1200",
                    "--file-caching=400",
                    "--audio-desync=0",
                    "--drop-late-frames",
                    "--audio-time-stretch",
                    "--http-reconnect"
                )
                libVlc = LibVLC(this, args)
            }
            val vlc = libVlc ?: return

            val explicitRef = payload.optString("referer", "")
            val referer = when {
                retryCount >= 2 -> ""
                explicitRef.isNotBlank() -> explicitRef
                streamUrl.startsWith("/") -> lastInlineM3u8Ref.ifEmpty { "https://vidly.pro/" }
                else -> streamRefererMap[streamUrl].orEmpty().ifEmpty { "https://vidly.pro/" }
            }
            val userAgent = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36"

            val mp = MediaPlayer(vlc)
            vlcVideoLayout?.let { layout ->
                mp.attachViews(layout, null, false, true)
                layout.visibility = View.VISIBLE
                layout.alpha = 0f
            }

            localProxyReferer = referer
            localProxyUserAgent = userAgent
            localProxyForceWebView = false
            val proxyPort = ensureLocalProxyRunning()
            val proxiedUrl = "http://127.0.0.1:$proxyPort/stream?u=" + URLEncoder.encode(streamUrl, "UTF-8")
            val media = Media(vlc, Uri.parse(proxiedUrl))

            media.setHWDecoderEnabled(!forceSoftwareDecode, false)
            if (forceSoftwareDecode) {
                media.addOption(":codec=avcodec,all")
                media.addOption(":avcodec-hw=none")
                media.addOption(":no-mediacodec-dr")
            }
            media.addOption(":network-caching=1500")
            media.addOption(":live-caching=1200")
            media.addOption(":file-caching=300")
            media.addOption(":audio-desync=0")
            media.addOption(":http-user-agent=$userAgent")
            if (referer.isNotEmpty()) {
                media.addOption(":http-referrer=$referer")
            }
            media.addOption(":http-reconnect")
            media.addOption(":audio-time-stretch")
            startTimeAppliedByOption = startTimeSec > 1L
            if (startTimeAppliedByOption) {
                media.addOption(":start-time=$startTimeSec")
            }

            mp.setEventListener { ev ->
                if (myToken != vlcPlaybackToken || isFinishing || isDestroyed) return@setEventListener
                when (ev.type) {
                    MediaPlayer.Event.Vout -> {
                        val vc = ev.voutCount
                        mainHandler.post {
                            if (myToken != vlcPlaybackToken || isFinishing || isDestroyed) return@post
                            vlcVideoOutCount = vc
                            if (vc > 0) {
                                val wasConfirmed = vlcVideoConfirmed
                                vlcVideoConfirmed = true
                                try { mp.volume = 100 } catch (_: Throwable) {}
                                vlcVideoLayout?.visibility = View.VISIBLE
                                vlcVideoLayout?.alpha = 1f
                                if (!wasConfirmed && !isLiveStream && startTimeSec <= 1L) {
                                    val posNow = vlcCurrentPosMs()
                                    if (posNow in 600L..4500L) {
                                        try { mp.time = 0L } catch (_: Throwable) {}
                                    }
                                }
                                killResolverMedia()
                            }
                        }
                    }
                    MediaPlayer.Event.Playing -> {
                        mainHandler.post {
                            if (myToken != vlcPlaybackToken || isFinishing || isDestroyed) return@post
                            vlcDidEnd = false
                            desiredPaused = null
                            if (!vlcPlaybackReady) {
                                vlcPlaybackReady = true
                                mainHandler.removeCallbacks(playbackReadyWatchdogRunnable)
                                killResolverMedia()
                                resolverWebView?.let { wv ->
                                    wv.translationX = -dp(5000).toFloat()
                                    wv.alpha = 0f
                                    wv.isClickable = false
                                    wv.isFocusable = false
                                }
                                hideCaptchaCard()
                                vlcVideoLayout?.visibility = View.VISIBLE
                                subtitleOverlayView?.bringToFront()
                                ambientProgressBar?.bringToFront()
                                controllerOverlay?.bringToFront()
                                gestureHudContainer?.bringToFront()
                                if (vlcVideoConfirmed || vlcVideoOutCount > 0) {
                                    vlcVideoConfirmed = true
                                    try { mp.volume = 100 } catch (_: Throwable) {}
                                    vlcVideoLayout?.alpha = 1f
                                }
                                try { mp.setSpuTrack(-1) } catch (_: Throwable) {}
                                ensureOriginalAudioTrack(mp)
                                if (vlcPendingSeekMs > 1000L) {
                                    val seekTarget = vlcPendingSeekMs
                                    vlcPendingSeekMs = 0L
                                    if (!startTimeAppliedByOption || kotlin.math.abs(vlcCurrentPosMs() - seekTarget) > 15000L) {
                                        vlcSeekTo(seekTarget, immediate = true)
                                    }
                                }
                                mp.rate = currentSpeed
                                isSwitchingServer = false
                                serverFailoverAttempts = 0
                                recordServerStatus(currentSource, "working")
                                if (vlcDurationMs() > 0L && (vlcCurrentPosMs() > 1000L || startTimeSec <= 1L)) {
                                    hasRealPlaybackProgress = true
                                    saveCurrentProgress(isPlayingOverride = true)
                                }
                                showControllerTemporarily()
                                mainHandler.postDelayed({
                                    if (myToken != vlcPlaybackToken || isFinishing || isDestroyed) return@postDelayed
                                    val vTrack = try { mp.currentVideoTrack } catch (_: Throwable) { null }
                                    val hasVideo = vlcVideoConfirmed || vlcVideoOutCount > 0 || (vTrack != null && vTrack.width > 16 && vTrack.height > 16)
                                    if (!hasVideo) {
                                        try { mp.volume = 0 } catch (_: Throwable) {}
                                        vlcVideoLayout?.alpha = 0f
                                        if (!forceSoftwareDecode) {
                                            forceSoftwareDecode = true
                                            vlcPlaybackReady = false
                                            initializeExoPlayer(rawPayload)
                                        } else {
                                            forceSoftwareDecode = false
                                            failedStreamUrls.add(streamUrl)
                                            vlcPlaybackReady = false
                                            releaseVlcAsync(mp, null)
                                            vlcPlayer = null
                                            streamUrl = ""
                                            isSwitchingServer = true
                                            advanceToNextAutoSource()
                                        }
                                    } else {
                                        vlcVideoConfirmed = true
                                        try { mp.volume = 100 } catch (_: Throwable) {}
                                        vlcVideoLayout?.alpha = 1f
                                        killResolverMedia()
                                    }
                                }, 3500L)
                            } else if (vlcPendingSeekMs > 500L) {
                                val seekTarget = vlcPendingSeekMs
                                vlcPendingSeekMs = 0L
                                vlcSeekTo(seekTarget)
                                if (kotlin.math.abs(mp.rate - currentSpeed) > 0.01f) mp.rate = currentSpeed
                            }
                            ensureOriginalAudioTrack(mp)
                            updateTimeAndSeekBar()
                        }
                    }
                    MediaPlayer.Event.Paused -> {
                        mainHandler.post {
                            if (myToken != vlcPlaybackToken) return@post
                            desiredPaused = null
                            saveCurrentProgress(isPlayingOverride = false)
                            updateTimeAndSeekBar()
                            setControllerVisible(true)
                        }
                    }
                    MediaPlayer.Event.EndReached -> {
                        mainHandler.post {
                            if (myToken != vlcPlaybackToken) return@post
                            vlcDidEnd = true
                            saveCurrentProgress(forceCompleted = true)
                            updateTimeAndSeekBar()
                            if (sleepAtEndOfEpisode) {
                                sleepAtEndOfEpisode = false
                                sleepBtn?.text = "Timer"
                                nextEpDismissed = true
                                Toast.makeText(this@NativeExoPlayerActivity, "Sleep timer: paused at end of episode", Toast.LENGTH_SHORT).show()
                            } else if (mediaType.equals("tv", ignoreCase = true) && !nextEpDismissed && computeNextEpisode() != null) {
                                playNextEpisodeInPlayer()
                            }
                        }
                    }
                    MediaPlayer.Event.EncounteredError -> {
                        mainHandler.post {
                            if (myToken != vlcPlaybackToken || isFinishing || isDestroyed) return@post
                            mainHandler.removeCallbacks(playbackReadyWatchdogRunnable)
                            if (retryCount < 2) {
                                retryCount++
                                initializeExoPlayer(rawPayload)
                            } else if (streamUrl.startsWith("/") && lastRemoteStreamUrl.startsWith("http") && !failedStreamUrls.contains(lastRemoteStreamUrl)) {
                                val fallbackUrl = lastRemoteStreamUrl
                                failedStreamUrls.add(streamUrl)
                                streamUrl = fallbackUrl
                                retryCount = 0
                                rawPayload.put("url", fallbackUrl)
                                initializeExoPlayer(rawPayload)
                            } else if (!streamUrl.startsWith("/") && lastInlineM3u8Path.startsWith("/") && !failedStreamUrls.contains(lastInlineM3u8Path)) {
                                val fallbackInline = lastInlineM3u8Path
                                failedStreamUrls.add(streamUrl)
                                streamUrl = fallbackInline
                                retryCount = 0
                                rawPayload.put("url", fallbackInline)
                                if (lastInlineM3u8Ref.isNotEmpty()) rawPayload.put("referer", lastInlineM3u8Ref)
                                initializeExoPlayer(rawPayload)
                            } else if (!streamUrl.startsWith("/")) {
                                failedStreamUrls.add(streamUrl)
                                streamUrl = ""
                                isSwitchingServer = false
                                triggerNextServerFailover()
                            }
                        }
                    }
                }
            }

            mp.media = media
            media.release()
            try { mp.volume = 0 } catch (_: Throwable) {}
            vlcPlayer = mp
            mp.play()

            mainHandler.removeCallbacks(playbackReadyWatchdogRunnable)
            if (!streamUrl.startsWith("/")) {
                mainHandler.postDelayed(playbackReadyWatchdogRunnable, 7_500L)
            }
            mainHandler.removeCallbacks(progressRunnable)
            mainHandler.postDelayed(progressRunnable, 5_000L)
            mainHandler.removeCallbacks(uiTickRunnable)
            mainHandler.post(uiTickRunnable)
            sleepTimerRunnable?.let { mainHandler.removeCallbacks(it) }
        sleepTimerRunnable = null
        mainHandler.removeCallbacks(subtitleTickRunnable)
            mainHandler.post(subtitleTickRunnable)
        } catch (t: Throwable) {
            Toast.makeText(this, "Player init error: ${t.message}", Toast.LENGTH_LONG).show()
        }
    }



    private fun loadSubtitleCuesAsync(subIndex: Int) {
        if (subIndex < 0 || subIndex >= availableSubs.size) {
            activeParsedCues.clear()
            runOnUiThread {
                subtitleOverlayView?.visibility = View.GONE
            }
            return
        }
        val track = availableSubs[subIndex]
        thread(start = true) {
            try {
                val rawText = if (track.urlOrPath.startsWith("/")) {
                    File(track.urlOrPath).readText(Charsets.UTF_8)
                } else {
                    val req = Request.Builder()
                        .url(track.urlOrPath)
                        .header("User-Agent", "Mozilla/5.0 (Linux; Android 14)SingularityTV/2.7.3")
                        .build()
                    StreambertApp.instance.okHttpClient.newCall(req).execute().use { res ->
                        res.body?.string() ?: ""
                    }
                }
                val parsed = parseSrtOrVtt(rawText)
                activeParsedCues.clear()
                activeParsedCues.addAll(parsed)
                runOnUiThread {
                    if (!isDestroyed) {
                        autoDetectSegmentsFromStreamAndCues()
                        updateLiveSubtitleOverlay()
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    private fun parseSrtOrVtt(raw: String): List<ParsedSubCue> {
        if (raw.isBlank()) return emptyList()
        val clean = raw.replace("\uFEFF", "").replace("\r\n", "\n").replace("\r", "\n")
        val blocks = clean.split(Regex("\n\\s*\n"))
        val list = ArrayList<ParsedSubCue>(blocks.size)
        val arrowRegex = Regex("""(\d{1,2}:)?(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d{1,2}:)?(\d{2}):(\d{2})[,.](\d{1,3})""")
        val htmlTagRegex = Regex("""<[^>]*>|\{[^}]*\}""")

        for (block in blocks) {
            val lines = block.lines().map { it.trim() }.filter { it.isNotEmpty() }
            if (lines.isEmpty() || lines[0].startsWith("WEBVTT")) continue
            var matchLineIdx = -1
            var matchResult: MatchResult? = null
            for (i in lines.indices) {
                val m = arrowRegex.find(lines[i])
                if (m != null) {
                    matchLineIdx = i
                    matchResult = m
                    break
                }
            }
            if (matchLineIdx == -1 || matchResult == null) continue
            val g = matchResult.groupValues
            val startH = g[1].trimEnd(':').toLongOrNull() ?: 0L
            val startM = g[2].toLongOrNull() ?: 0L
            val startS = g[3].toLongOrNull() ?: 0L
            val startMs = g[4].padEnd(3, '0').take(3).toLongOrNull() ?: 0L
            val endH = g[5].trimEnd(':').toLongOrNull() ?: 0L
            val endM = g[6].toLongOrNull() ?: 0L
            val endS = g[7].toLongOrNull() ?: 0L
            val endMs = g[8].padEnd(3, '0').take(3).toLongOrNull() ?: 0L

            val startTotal = (startH * 3600L + startM * 60L + startS) * 1000L + startMs
            val endTotal = (endH * 3600L + endM * 60L + endS) * 1000L + endMs
            val textLines = lines.subList(matchLineIdx + 1, lines.size)
            val text = textLines.joinToString("\n").replace(htmlTagRegex, "").trim()
            if (text.isNotEmpty() && endTotal > startTotal) {
                list.add(ParsedSubCue(startTotal, endTotal, text))
            }
        }
        return list
    }

    private fun updateLiveSubtitleOverlay() {
        val overlay = subtitleOverlayView ?: return
        val player = vlcPlayer
        if (player == null || activeSubIndex < 0 || activeParsedCues.isEmpty()) {
            if (overlay.visibility != View.GONE) overlay.visibility = View.GONE
            return
        }
        val posMs = vlcCurrentPosMs() - subDelayMs
        val hit = activeParsedCues.firstOrNull { posMs >= it.startMs && posMs <= it.endMs }
        if (hit != null && hit.text.isNotEmpty()) {
            if (overlay.text.toString() != hit.text) {
                overlay.text = hit.text
            }
            if (overlay.visibility != View.VISIBLE) {
                overlay.visibility = View.VISIBLE
                overlay.bringToFront()
                controllerOverlay?.bringToFront()
                gestureHudContainer?.bringToFront()
            }
        } else {
            if (overlay.visibility != View.GONE) {
                overlay.visibility = View.GONE
            }
        }
    }

    private fun createDialogItemBg(focused: Boolean): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(10).toFloat()
            if (focused) {
                setColor(Color.argb(65, 255, 255, 255))
                setStroke(dp(2), Color.WHITE)
            } else {
                setColor(Color.argb(18, 255, 255, 255))
            }
        }
    }

    private fun showStyledMenuDialog(title: String, items: Array<String>, onSelect: (Int) -> Unit) {
        val dlg = android.app.Dialog(this)
        dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(16).toFloat()
                setColor(Color.rgb(18, 22, 32))
                setStroke(dp(1), Color.argb(45, 255, 255, 255))
            }
        }

        val titleTv = TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(6), 0, dp(6), dp(12))
        }
        card.addView(titleTv)

        val scroll = android.widget.ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            clipChildren = false
            clipToPadding = false
            layoutParams = LinearLayout.LayoutParams(
                dp(420),
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                val maxH = (resources.displayMetrics.heightPixels * 0.62f).toInt()
                if (items.size > 7) height = maxH
            }
        }

        val listBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }

        var firstRow: TextView? = null
        items.forEachIndexed { idx, label ->
            val row = TextView(this).apply {
                text = label
                setTextColor(Color.argb(235, 240, 244, 248))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(16), dp(12), dp(16), dp(12))
                background = createDialogItemBg(false)
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    setMargins(0, dp(3), 0, dp(3))
                }
                isFocusable = true
                isFocusableInTouchMode = false
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    defaultFocusHighlightEnabled = false
                }
                setOnFocusChangeListener { v, hasFocus ->
                    v.background = createDialogItemBg(hasFocus)
                    (v as TextView).setTextColor(if (hasFocus) Color.WHITE else Color.argb(220, 226, 232, 240))
                    v.animate()
                        .scaleX(if (hasFocus) 1.02f else 1.0f)
                        .scaleY(if (hasFocus) 1.02f else 1.0f)
                        .setDuration(110)
                        .start()
                }
                setOnClickListener {
                    dlg.dismiss()
                    onSelect(idx)
                }
            }
            if (idx == 0) firstRow = row
            listBox.addView(row)
        }

        scroll.addView(listBox)
        card.addView(scroll)
        dlg.setContentView(card)
        dlg.show()
        firstRow?.post { firstRow?.requestFocus() }
    }

    private fun showSubtitlesMenuDialog() {
        val langCount = availableSubs.map { it.lang }.distinct().size
        val options = arrayOf(
            "Select Language ($langCount languages)",
            "Choose Subtitle Track (${availableSubs.size} found)",
            "Turn Subtitles Off"
        )
        showStyledMenuDialog("Subtitles", options) { which ->
            when (which) {
                0 -> showLanguagePickerDialog()
                1 -> showSubtitleTrackPicker()
                2 -> {
                    activeSubIndex = -1
                    activeParsedCues.clear()
                    subtitleOverlayView?.visibility = View.GONE
                    Toast.makeText(this, "Subtitles turned off", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun showSubtitleDelayDialog() {
        val dlg = android.app.Dialog(this)
        dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
            setPadding(dp(22), dp(20), dp(22), dp(18))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(16).toFloat()
                setColor(Color.rgb(18, 22, 32))
                setStroke(dp(1), Color.argb(45, 255, 255, 255))
            }
        }

        val titleTv = TextView(this).apply {
            text = "Subtitle Sync"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, dp(16))
        }
        card.addView(titleTv)

        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            clipChildren = false
            clipToPadding = false
            setPadding(dp(4), dp(6), dp(4), dp(18))
        }
        val earlierTv = TextView(this).apply {
            text = "Earlier"
            setTextColor(Color.LTGRAY)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setPadding(0, 0, dp(10), 0)
        }
        val valTv = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            minWidth = dp(84)
            setPadding(dp(12), 0, dp(12), 0)
        }
        fun refreshText() {
            val sec = subDelayMs / 1000.0
            val sign = if (subDelayMs > 0L) "+" else ""
            valTv.text = String.format(java.util.Locale.US, "%s%.1fs", sign, sec)
            syncBtnRef?.text = String.format(java.util.Locale.US, "Sync %s%.1fs", sign, sec)
            updateLiveSubtitleOverlay()
        }
        refreshText()
        var holdRunnable: Runnable? = null
        fun makeStepBtn(label: String, deltaMs: Long): Button {
            return Button(this).apply {
                text = label
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
                typeface = Typeface.DEFAULT_BOLD
                isFocusable = true
                isFocusableInTouchMode = false
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    defaultFocusHighlightEnabled = false
                }
                background = createSecondaryBg(false)
                layoutParams = LinearLayout.LayoutParams(dp(54), dp(44))
                setOnFocusChangeListener { v, hasFocus ->
                    background = createSecondaryBg(hasFocus)
                    v.animate()
                        .scaleX(if (hasFocus) 1.12f else 1.0f)
                        .scaleY(if (hasFocus) 1.12f else 1.0f)
                        .setDuration(120)
                        .start()
                }
                setOnClickListener {
                    subDelayMs += deltaMs
                    refreshText()
                }
                setOnTouchListener { _, ev ->
                    when (ev.action) {
                        MotionEvent.ACTION_DOWN -> {
                            holdRunnable?.let { mainHandler.removeCallbacks(it) }
                            val r = object : Runnable {
                                override fun run() {
                                    subDelayMs += deltaMs
                                    refreshText()
                                    mainHandler.postDelayed(this, 70L)
                                }
                            }
                            holdRunnable = r
                            mainHandler.postDelayed(r, 260L)
                        }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                            holdRunnable?.let { mainHandler.removeCallbacks(it) }
                            holdRunnable = null
                        }
                    }
                    false
                }
            }
        }
        val minusBtn = makeStepBtn("−", -100L)
        val plusBtn = makeStepBtn("+", 100L)
        val laterTv = TextView(this).apply {
            text = "Later"
            setTextColor(Color.LTGRAY)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setPadding(dp(10), 0, 0, 0)
        }
        row.addView(earlierTv)
        row.addView(minusBtn)
        row.addView(valTv)
        row.addView(plusBtn)
        row.addView(laterTv)
        card.addView(row)

        val footerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            clipChildren = false
            clipToPadding = false
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }
        val resetBtn = makeSecondaryButton("Reset 0.0") {
            subDelayMs = 0L
            refreshText()
        }
        val doneBtn = makeSecondaryButton("Done") {
            dlg.dismiss()
        }
        footerRow.addView(resetBtn)
        footerRow.addView(doneBtn)
        card.addView(footerRow)

        dlg.setContentView(card)
        dlg.setOnDismissListener {
            holdRunnable?.let { mainHandler.removeCallbacks(it) }
        }
        dlg.show()
        plusBtn.post { plusBtn.requestFocus() }
    }

    private fun showLanguagePickerDialog() {
        val grouped = availableSubs.groupBy { it.lang }
        if (grouped.isEmpty()) {
            Toast.makeText(this, "Searching subtitles across all languages…", Toast.LENGTH_SHORT).show()
            fetchOnlineSubtitlesInBackground()
            return
        }
        val codes = grouped.keys.sortedWith(compareByDescending<String> { it == preferredLang }.thenBy { langDisplayName(it) })
        val labels = codes.map { code ->
            val mark = if (code == preferredLang && activeSubIndex >= 0) "● " else ""
            "$mark${langDisplayName(code)} (${grouped[code]?.size ?: 0})"
        }.toTypedArray()

        showStyledMenuDialog("Select Subtitle Language", labels) { which ->
            selectBestSubtitleForLanguage(codes[which], silent = false)
        }
    }

    private fun simpleLangName(code: String): String {
        return langDisplayName(code)
    }

    private fun showSubtitleTrackPicker() {
        if (availableSubs.isEmpty()) {
            Toast.makeText(this, "Searching online subtitles… try again in a moment", Toast.LENGTH_SHORT).show()
            fetchOnlineSubtitlesInBackground()
            return
        }
        val counts = mutableMapOf<String, Int>()
        val recLangs = mutableSetOf<String>()
        val labels = availableSubs.mapIndexed { idx, tr ->
            val num = (counts[tr.lang] ?: 0) + 1
            counts[tr.lang] = num
            val isRec = tr.score >= 85 && !recLangs.contains(tr.lang)
            if (isRec) recLangs.add(tr.lang)
            val mark = if (idx == activeSubIndex) "● " else ""
            val tag = ""
            "$mark${simpleLangName(tr.lang)} sub $num$tag"
        }.toTypedArray()
        showStyledMenuDialog("Select Subtitle Track", labels) { which ->
            activeSubIndex = which
            preferredLang = availableSubs[which].lang
            loadSubtitleCuesAsync(which)
            Toast.makeText(this, "Loaded: ${availableSubs[which].label}", Toast.LENGTH_SHORT).show()
        }
    }



    private fun showQualityDialog() {
        Toast.makeText(this, "Auto Quality Active (VLC)", Toast.LENGTH_SHORT).show()
    }




    private fun applyAspectMode(mode: Int) {
        aspectModeIndex = mode % 3
        val mp = vlcPlayer ?: return
        when (aspectModeIndex) {
            0 -> {
                mp.videoScale = MediaPlayer.ScaleType.SURFACE_BEST_FIT
                aspectBtn?.text = "Fit"
                showGestureHudPill("Fit")
            }
            1 -> {
                mp.videoScale = MediaPlayer.ScaleType.SURFACE_FILL
                aspectBtn?.text = "Fill"
                showGestureHudPill("Fill")
            }
            else -> {
                mp.videoScale = MediaPlayer.ScaleType.SURFACE_16_9
                aspectBtn?.text = "16:9"
                showGestureHudPill("16:9")
            }
        }
        mainHandler.postDelayed({ hideGestureHudPill() }, 900L)
    }

    private fun cycleAspectMode() {
        applyAspectMode(aspectModeIndex + 1)
        showControllerTemporarily()
    }

    private fun showUnlockButtonTemporarily() {
        val btn = unlockBtn ?: return
        unlockHideRunnable?.let { mainHandler.removeCallbacks(it) }
        btn.visibility = View.VISIBLE
        btn.bringToFront()
        btn.animate().alpha(1f).setDuration(180).start()
        val r = Runnable {
            if (isScreenLocked) {
                btn.animate().alpha(0f).setDuration(220).withEndAction {
                    if (isScreenLocked) btn.visibility = View.GONE
                }.start()
            }
        }
        unlockHideRunnable = r
        mainHandler.postDelayed(r, 2500L)
    }

    private fun toggleScreenLock() {
        isScreenLocked = !isScreenLocked
        if (isScreenLocked) {
            mainHandler.removeCallbacks(hideControllerRunnable)
            controllerOverlay?.visibility = View.GONE
            controllerOverlay?.alpha = 0f
            showUnlockButtonTemporarily()
            Toast.makeText(this, "Screen Locked", Toast.LENGTH_SHORT).show()
        } else {
            unlockHideRunnable?.let { mainHandler.removeCallbacks(it) }
            unlockBtn?.visibility = View.GONE
            unlockBtn?.alpha = 0f
            showControllerTemporarily()
            Toast.makeText(this, "Screen Unlocked", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showSleepTimerDialog() {
        val isTv = mediaType.equals("tv", ignoreCase = true)
        val endLabel = if (isTv) "End of Episode" else "End of Movie"
        val endShort = if (isTv) "End Ep" else "End Mov"
        val endToast = if (isTv) "Will pause at end of episode" else "Will pause at end of movie"
        val labels = if (isLiveStream) arrayOf("Off", "15 min", "30 min", "45 min", "60 min") else arrayOf("Off", "15 min", "30 min", "45 min", "60 min", endLabel)
        val mins = if (isLiveStream) intArrayOf(0, 15, 30, 45, 60) else intArrayOf(0, 15, 30, 45, 60, -1)
        showStyledMenuDialog("Sleep Timer", labels) { which ->
            sleepTimerRunnable?.let { mainHandler.removeCallbacks(it) }
            sleepTimerRunnable = null
            sleepAtEndOfEpisode = false
            val m = mins[which]
            if (m == 0) {
                sleepBtn?.text = "Timer"
                Toast.makeText(this, "Sleep timer off", Toast.LENGTH_SHORT).show()
            } else if (m == -1) {
                sleepAtEndOfEpisode = true
                sleepBtn?.text = endShort
                Toast.makeText(this, endToast, Toast.LENGTH_SHORT).show()
            } else {
                sleepBtn?.text = "${m}m"
                Toast.makeText(this, "Sleep timer: $m min", Toast.LENGTH_SHORT).show()
                val r = Runnable {
                    if (!isFinishing && !isDestroyed) {
                        vlcPlayer?.pause()
                        updateTimeAndSeekBar()
                        sleepBtn?.text = "Timer"
                        Toast.makeText(this, "Sleep timer finished", Toast.LENGTH_SHORT).show()
                    }
                }
                sleepTimerRunnable = r
                mainHandler.postDelayed(r, m * 60_000L)
            }
        }
    }

    private fun showSubtitleStyleDialog() {
        val labels = arrayOf(
            "Size: Small", "Size: Normal", "Size: Large", "Size: TV XL",
            "Color: White", "Color: Yellow", "Color: Cyan", "Color: Green",
            "BG: None", "BG: Semi", "BG: Dark"
        )
        showStyledMenuDialog("Subtitle Style", labels) { which ->
            val prefs = getSharedPreferences("singularity_player_prefs", Context.MODE_PRIVATE).edit()
            when (which) {
                0 -> { subTextSizeSp = 16f; prefs.putFloat("sub_pref_size", 16f) }
                1 -> { subTextSizeSp = 22f; prefs.putFloat("sub_pref_size", 22f) }
                2 -> { subTextSizeSp = 28f; prefs.putFloat("sub_pref_size", 28f) }
                3 -> { subTextSizeSp = 34f; prefs.putFloat("sub_pref_size", 34f) }
                4 -> { subTextColorHex = "#FFFFFF"; prefs.putString("sub_pref_color", "#FFFFFF") }
                5 -> { subTextColorHex = "#FACC15"; prefs.putString("sub_pref_color", "#FACC15") }
                6 -> { subTextColorHex = "#38BDF8"; prefs.putString("sub_pref_color", "#38BDF8") }
                7 -> { subTextColorHex = "#4ADE80"; prefs.putString("sub_pref_color", "#4ADE80") }
                8 -> { subBgStyleMode = "none"; prefs.putString("sub_pref_bg", "none") }
                9 -> { subBgStyleMode = "semi"; prefs.putString("sub_pref_bg", "semi") }
                10 -> { subBgStyleMode = "dark"; prefs.putString("sub_pref_bg", "dark") }
            }
            prefs.apply()
            applySubtitleStyle()
            ExoProgressBus.subtitleStyleListener?.invoke(subTextColorHex, subBgStyleMode, subTextSizeSp)
        }
    }

    private fun showServerPickerDialog() {
        val labels = arrayOf("VidLink (TMDB Fast)", "VidSrc.cc (IMDb & TMDB)", "HnEmbed (IMDb & TMDB)")
        val ids = arrayOf("vidlink", "vidsrccc", "hnembed")
        showStyledMenuDialog("Switch Server", labels) { which ->
            val sid = ids[which]
            val curSec = vlcCurrentPosMs() / 1000L
            if (curSec > 5L) startTimeSec = curSec
            vlcPlaybackReady = false
            vlcDidEnd = false
            retryCount = 0
            try { vlcPlayer?.stop() } catch (_: Throwable) {}
            failedStreamUrls.clear()
            streamUrl = ""
            currentSource = sid
            pendingNextSource = sid
            isSwitchingServer = true
            val embedUrl = buildEmbedUrlForSource(sid)
            if (embedUrl.isNotEmpty() && resolverWebView != null) {
                activeResolverEmbedUrl = embedUrl
                loadEmbedUrlDirect(embedUrl)
                Toast.makeText(this, "Switching to ${labels[which]}...", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showSpeedDialog(speedBtn: Button) {
        val speeds = floatArrayOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f, 2.5f, 3.0f)
        val labels = speeds.map { formatSpeedText(it) }.toTypedArray()
        showStyledMenuDialog("Playback Speed", labels) { which ->
            currentSpeed = speeds[which]
            vlcPlayer?.rate = currentSpeed
            speedBtn.text = formatSpeedText(currentSpeed)
            saveSeriesPrefs()
        }
    }

    private fun enterPipIfSupported() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val params = PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
                enterPictureInPictureMode(params)
            } catch (_: Throwable) {}
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (isInPictureInPictureMode) {
            setControllerVisible(false)
        } else {
            showControllerTemporarily()
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (directWebPlayerMode) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                when (event.keyCode) {
                    KeyEvent.KEYCODE_BACK -> {
                        resolverWebView?.evaluateJavascript("try{if(window.__sbCloseMenuIfOpen&&window.__sbCloseMenuIfOpen()){'CLOSED';}else{'EXIT';}}catch(e){'EXIT';}") { res ->
                            if (res == null || !res.contains("CLOSED")) {
                                saveCurrentProgress(isPlayingOverride = false)
                                resolverWebView?.visibility = View.GONE
                                finish()
                            }
                        }
                        return true
                    }
                    KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        resolverWebView?.let { wv ->
                            try {
                                val t = android.os.SystemClock.uptimeMillis()
                                val hx = (wv.width.coerceAtLeast(360) / 2f) + ((t % 11L) - 5L)
                                val hy = (wv.height.coerceAtLeast(250) / 2f) + ((t % 7L) - 3L)
                                val hv = MotionEvent.obtain(t, t, MotionEvent.ACTION_HOVER_MOVE, hx, hy, 0)
                                hv.source = android.view.InputDevice.SOURCE_MOUSE
                                wv.dispatchGenericMotionEvent(hv)
                                hv.recycle()
                            } catch (_: Throwable) {}
                        }
                        val dir = when (event.keyCode) {
                            KeyEvent.KEYCODE_DPAD_UP -> "up"
                            KeyEvent.KEYCODE_DPAD_DOWN -> "down"
                            KeyEvent.KEYCODE_DPAD_LEFT -> "left"
                            else -> "right"
                        }
                        resolverWebView?.evaluateJavascript("try{window.__sbTvNav&&window.__sbTvNav('$dir');}catch(e){}", null)
                        return true
                    }
                    KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                        resolverWebView?.evaluateJavascript("try{window.__sbTvNav&&window.__sbTvNav('ok');}catch(e){}", null)
                        return true
                    }
                    KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY, KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                        resolverWebView?.evaluateJavascript("try{var v=document.querySelector('video');if(v){if(v.paused)v.play().catch(function(){});else v.pause();}}catch(e){}", null)
                        return true
                    }
                }
            }
            if (event.action == KeyEvent.ACTION_UP) {
                when (event.keyCode) {
                    KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN,
                    KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_DPAD_RIGHT,
                    KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER,
                    KeyEvent.KEYCODE_NUMPAD_ENTER, KeyEvent.KEYCODE_BACK -> return true
                }
            }
            return super.dispatchKeyEvent(event)
        }
        if (event.action == KeyEvent.ACTION_DOWN) {
            if (isCaptchaCardVisible) {
                val wv = resolverWebView
                val wrap = (captchaCardContainer?.getChildAt(1) as? FrameLayout)
                if (wv != null && wrap != null) {
                    if (isCaptchaCursorActive) {
                        val step = if (isCaptchaDragMode) 0.03f else 0.06f
                        val emitMoveIfDragging = {
                            if (isCaptchaDragMode) {
                                val tx = captchaCursorX * wv.width
                                val ty = captchaCursorY * wv.height
                                val nowT = android.os.SystemClock.uptimeMillis()
                                wv.dispatchTouchEvent(MotionEvent.obtain(captchaDragDownTime, nowT, MotionEvent.ACTION_MOVE, tx, ty, 0))
                            }
                        }
                        when (event.keyCode) {
                            KeyEvent.KEYCODE_DPAD_LEFT -> {
                                captchaCursorX = (captchaCursorX - step).coerceIn(0f, 1f)
                                updateCaptchaCursorPosition(wrap)
                                emitMoveIfDragging()
                                return true
                            }
                            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                                captchaCursorX = (captchaCursorX + step).coerceIn(0f, 1f)
                                updateCaptchaCursorPosition(wrap)
                                emitMoveIfDragging()
                                return true
                            }
                            KeyEvent.KEYCODE_DPAD_UP -> {
                                if (!isCaptchaDragMode && captchaCursorY <= 0.06f) {
                                    isCaptchaCursorActive = false
                                    captchaCursorView?.alpha = 0.25f
                                    showControllerTemporarily()
                                    if (captchaCursorX >= 0.55f) {
                                        captchaReloadBtn?.requestFocus()
                                    } else {
                                        switchServerBtn?.requestFocus()
                                    }
                                    return true
                                }
                                captchaCursorY = (captchaCursorY - step).coerceIn(0f, 1f)
                                updateCaptchaCursorPosition(wrap)
                                emitMoveIfDragging()
                                return true
                            }
                            KeyEvent.KEYCODE_DPAD_DOWN -> {
                                if (!isCaptchaDragMode && captchaCursorY >= 0.94f) {
                                    isCaptchaCursorActive = false
                                    captchaCursorView?.alpha = 0.25f
                                    showControllerTemporarily()
                                    subBtn?.requestFocus()
                                    return true
                                }
                                captchaCursorY = (captchaCursorY + step).coerceIn(0f, 1f)
                                updateCaptchaCursorPosition(wrap)
                                emitMoveIfDragging()
                                return true
                            }
                            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                                val tx = captchaCursorX * wv.width
                                val ty = captchaCursorY * wv.height
                                val nowT = android.os.SystemClock.uptimeMillis()
                                if (event.repeatCount == 2) {
                                    isCaptchaDragMode = true
                                    captchaDragDownTime = nowT
                                    (captchaCursorView?.background as? GradientDrawable)?.setColor(Color.rgb(250, 204, 21))
                                    captchaTitleTv?.text = "SLIDE MODE (Left/Right then OK)"
                                    wv.dispatchTouchEvent(MotionEvent.obtain(captchaDragDownTime, nowT, MotionEvent.ACTION_DOWN, tx, ty, 0))
                                    return true
                                }
                                if (event.repeatCount == 0) {
                                    if (isCaptchaDragMode) {
                                        isCaptchaDragMode = false
                                        (captchaCursorView?.background as? GradientDrawable)?.setColor(Color.argb(210, 229, 9, 20))
                                        captchaTitleTv?.text = "Verify · Hold OK to Slide"
                                        wv.dispatchTouchEvent(MotionEvent.obtain(captchaDragDownTime, nowT, MotionEvent.ACTION_UP, tx, ty, 0))
                                    } else {
                                        wv.dispatchTouchEvent(MotionEvent.obtain(nowT, nowT, MotionEvent.ACTION_DOWN, tx, ty, 0))
                                        wv.dispatchTouchEvent(MotionEvent.obtain(nowT, nowT + 40, MotionEvent.ACTION_UP, tx, ty, 0))
                                    }
                                }
                                return true
                            }
                            KeyEvent.KEYCODE_BACK -> {
                                hideCaptchaCard()
                                return true
                            }
                        }
                    } else {
                        when (event.keyCode) {
                            KeyEvent.KEYCODE_DPAD_UP -> {
                                val focused = currentFocus
                                val inBottomRow = focused != null && (focused == seekBar || focused.parent == bottomActionsRow)
                                if (inBottomRow) {
                                    isCaptchaCursorActive = true
                                    captchaCursorView?.alpha = 1.0f
                                    captchaCursorY = 0.88f
                                    updateCaptchaCursorPosition(wrap)
                                    return true
                                }
                            }
                            KeyEvent.KEYCODE_DPAD_DOWN -> {
                                val focused = currentFocus
                                if (focused == captchaReloadBtn || focused == switchServerBtn) {
                                    isCaptchaCursorActive = true
                                    captchaCursorView?.alpha = 1.0f
                                    captchaCursorY = 0.12f
                                    updateCaptchaCursorPosition(wrap)
                                    return true
                                }
                            }
                            KeyEvent.KEYCODE_BACK -> {
                                hideCaptchaCard()
                                return true
                            }
                        }
                    }
                }
            }
            if (isScreenLocked) {
                if (event.keyCode == KeyEvent.KEYCODE_DPAD_CENTER || event.keyCode == KeyEvent.KEYCODE_ENTER || event.keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER) {
                    if (unlockBtn?.visibility == View.VISIBLE) {
                        toggleScreenLock()
                    } else {
                        showUnlockButtonTemporarily()
                        unlockBtn?.requestFocus()
                    }
                    return true
                }
                showUnlockButtonTemporarily()
                unlockBtn?.requestFocus()
                return true
            }
            val player = vlcPlayer
            when (event.keyCode) {
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
                KeyEvent.KEYCODE_SPACE -> {
                    if (player != null) {
                        toggleVlcPlayPause()
                        showControllerTemporarily()
                        return true
                    }
                }
                KeyEvent.KEYCODE_MEDIA_PAUSE -> {
                    if (player != null) {
                        toggleVlcPlayPause(forcePause = true)
                        showControllerTemporarily()
                        return true
                    }
                }
                KeyEvent.KEYCODE_MEDIA_PLAY -> {
                    if (player != null) {
                        toggleVlcPlayPause(forcePause = false)
                        showControllerTemporarily()
                        return true
                    }
                }
                KeyEvent.KEYCODE_DPAD_CENTER,
                KeyEvent.KEYCODE_ENTER,
                KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                    if (!isControllerVisible && player != null) {
                        toggleVlcPlayPause()
                        showControllerTemporarily()
                        playPauseBtn?.requestFocus()
                        return true
                    }
                    if (isControllerVisible && currentFocus == null) {
                        playPauseBtn?.requestFocus()
                        showControllerTemporarily()
                        return true
                    }
                    showControllerTemporarily()
                }
                KeyEvent.KEYCODE_DPAD_LEFT,
                KeyEvent.KEYCODE_MEDIA_REWIND -> {
                    if (isLiveStream) {
                        if (!isControllerVisible) {
                            showControllerTemporarily()
                            playPauseBtn?.requestFocus()
                            return true
                        }
                        if (currentFocus == null) {
                            playPauseBtn?.requestFocus()
                            return true
                        }
                        showControllerTemporarily()
                    } else {
                        val isMediaRew = event.keyCode == KeyEvent.KEYCODE_MEDIA_REWIND
                        if ((isMediaRew || !isControllerVisible || seekBar?.hasFocus() == true) && player != null) {
                            val step = if (event.repeatCount > 2) 30_000L else 10_000L
                            val target = (effectiveSeekBaseMs() - step).coerceAtLeast(0L)
                            vlcSeekTo(target)
                            showControllerTemporarily()
                            seekBar?.requestFocus()
                            return true
                        }
                        if (currentFocus == null) {
                            playPauseBtn?.requestFocus()
                            return true
                        }
                        showControllerTemporarily()
                    }
                }
                KeyEvent.KEYCODE_DPAD_RIGHT,
                KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                    if (isLiveStream) {
                        if (!isControllerVisible) {
                            showControllerTemporarily()
                            playPauseBtn?.requestFocus()
                            return true
                        }
                        if (currentFocus == null) {
                            playPauseBtn?.requestFocus()
                            return true
                        }
                        showControllerTemporarily()
                    } else {
                        val isMediaFwd = event.keyCode == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD
                        if ((isMediaFwd || !isControllerVisible || seekBar?.hasFocus() == true) && player != null) {
                            val d = vlcDurationMs()
                            val step = if (event.repeatCount > 2) 30_000L else 10_000L
                            val nxt = effectiveSeekBaseMs() + step
                            val target = if (d > 0L) nxt.coerceAtMost(d) else nxt
                            vlcSeekTo(target)
                            showControllerTemporarily()
                            seekBar?.requestFocus()
                            return true
                        }
                        if (currentFocus == null) {
                            playPauseBtn?.requestFocus()
                            return true
                        }
                        showControllerTemporarily()
                    }
                }
                KeyEvent.KEYCODE_DPAD_UP,
                KeyEvent.KEYCODE_DPAD_DOWN -> {
                    if (!isControllerVisible) {
                        showControllerTemporarily()
                        if (!isLiveStream && seekBar != null) {
                            seekBar?.requestFocus()
                        } else {
                            playPauseBtn?.requestFocus()
                        }
                        return true
                    }
                    if (currentFocus == null) {
                        playPauseBtn?.requestFocus()
                        showControllerTemporarily()
                        return true
                    }
                    showControllerTemporarily()
                }
                KeyEvent.KEYCODE_BACK -> {
                    if (isControllerVisible && !isCaptchaCardVisible) {
                        setControllerVisible(false)
                        return true
                    }
                    saveCurrentProgress()
                    finish()
                    return true
                }
            }
        } else if (event.action == KeyEvent.ACTION_UP) {
            if (isScreenLocked) return true
            if (!isLiveStream && (event.keyCode == KeyEvent.KEYCODE_MEDIA_REWIND || event.keyCode == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD || ((event.keyCode == KeyEvent.KEYCODE_DPAD_LEFT || event.keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) && (!isControllerVisible || seekBar?.hasFocus() == true)))) {
                return true
            }
            if (event.keyCode == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE ||
                event.keyCode == KeyEvent.KEYCODE_MEDIA_PLAY ||
                event.keyCode == KeyEvent.KEYCODE_MEDIA_PAUSE ||
                event.keyCode == KeyEvent.KEYCODE_SPACE) {
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun saveCurrentProgress(forceCompleted: Boolean = false, isPlayingOverride: Boolean? = null) {
        try {
            val mp = vlcPlayer
            val key = progressKey ?: return
            val playingNow = isPlayingOverride ?: (mp?.isPlaying == true && !forceCompleted && !isFinishing)
            val durMs = if (mp != null) vlcDurationMs() else 0L
            val posMs = if (mp != null) vlcCurrentPosMs() else 0L
            if (!forceCompleted && (durMs <= 0L || !hasRealPlaybackProgress || vlcPendingSeekMs > 0L)) {
                return
            }
            if (durMs <= 0L) {
                ExoProgressBus.listener?.invoke(key, 100, (posMs / 1000L).coerceAtLeast(0L), 0L, true, false)
                return
            }

            val posSec = posMs / 1000L
            val durSec = durMs / 1000L
            val rawPct = ((posMs * 100L) / durMs).toInt().coerceIn(0, 100)
            val pct = if (forceCompleted) 100 else rawPct.coerceAtLeast(1)
            val isWatched = forceCompleted || pct >= 92 || (durSec - posSec <= 45L)

            StreambertApp.instance.database.playbackProgressDao().upsertSync(
                PlaybackProgressEntity(
                    progressKey = key,
                    percent = pct,
                    positionSec = posSec,
                    durationSec = durSec,
                    watched = isWatched
                )
            )
            ExoProgressBus.listener?.invoke(key, pct, posSec, durSec, isWatched, playingNow)
        } catch (_: Throwable) {}
    }

    private fun enableImmersiveFullscreen() {
        try {
            WindowCompat.setDecorFitsSystemWindows(window, false)
            WindowInsetsControllerCompat(window, window.decorView).let { controller ->
                controller.hide(WindowInsetsCompat.Type.systemBars())
                controller.systemBarsBehavior =
                    WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } catch (_: Throwable) {}
    }

    override fun onResume() {
        super.onResume()
        try {
            resolverWebView?.onResume()
            resolverWebView?.resumeTimers()
            if (directWebPlayerMode) {
                resolverWebView?.evaluateJavascript("try{document.querySelectorAll('video,audio').forEach(function(v){v.muted=false;if(window.__sbWasP){window.__sbWasP=0;v.play().catch(function(){});}});}catch(e){}", null)
            }
        } catch (_: Throwable) {}
    }

    override fun onPause() {
        super.onPause()
        saveCurrentProgress(isPlayingOverride = false)
        if (isFinishing || Build.VERSION.SDK_INT < Build.VERSION_CODES.N || !isInPictureInPictureMode) {
            vlcPlayer?.pause()
            try {
                if (!directWebPlayerMode) resolverWebView?.evaluateJavascript("try{document.querySelectorAll('video,audio').forEach(function(v){v.pause();v.muted=true;});}catch(e){}", null) else resolverWebView?.evaluateJavascript("try{document.querySelectorAll('video').forEach(function(v){if(!v.paused){window.__sbWasP=1;v.pause();}});}catch(e){}", null)
            } catch (_: Throwable) {}
        }
    }

    override fun onStop() {
        super.onStop()
        saveCurrentProgress(isPlayingOverride = false)
        if (isFinishing) {
            forceShutdownPlayer()
        } else if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N || !isInPictureInPictureMode) {
            vlcPlayer?.pause()
            try {
                if (!directWebPlayerMode) resolverWebView?.evaluateJavascript("try{document.querySelectorAll('video,audio').forEach(function(v){v.pause();v.muted=true;});}catch(e){}", null) else resolverWebView?.evaluateJavascript("try{document.querySelectorAll('video').forEach(function(v){if(!v.paused){window.__sbWasP=1;v.pause();}});}catch(e){}", null)
            } catch (_: Throwable) {}
        }
    }

    override fun finish() {
        saveCurrentProgress(isPlayingOverride = false)
        forceShutdownPlayer()
        super.finish()
    }

    fun forceShutdownPlayer() {
        isPlayerActive = false
        if (activeInstance === this) activeInstance = null
        stopBackgroundServerProbing()
        mainHandler.removeCallbacks(nextEpCountdownRunnable)
        mainHandler.removeCallbacks(failoverWatchdogRunnable)
        mainHandler.removeCallbacks(playbackReadyWatchdogRunnable)
        mainHandler.removeCallbacks(hideControllerRunnable)
        mainHandler.removeCallbacks(hideMetersRunnable)
        mainHandler.removeCallbacks(hideLeftSeekRunnable)
        mainHandler.removeCallbacks(hideRightSeekRunnable)
        mainHandler.removeCallbacks(progressRunnable)
        mainHandler.removeCallbacks(uiTickRunnable)
        mainHandler.removeCallbacks(subtitleTickRunnable)
        try {
            resolverWebView?.evaluateJavascript("try{document.querySelectorAll('video,audio').forEach(function(v){v.pause();v.muted=true;v.removeAttribute('src');v.load();});}catch(e){}", null)
            resolverWebView?.stopLoading()
            resolverWebView?.visibility = View.GONE
            resolverWebView?.alpha = 0f
            resolverWebView?.loadData("<html><body style=background:#000></body></html>", "text/html", "utf-8")
            resolverWebView?.onPause()
            resolverWebView?.destroy()
        } catch (_: Throwable) {}
        resolverWebView = null
        val oldMp = vlcPlayer
        val oldLib = libVlc
        vlcPlayer = null
        libVlc = null
        releaseVlcAsync(oldMp, oldLib)
        stopLocalProxy()
    }

    override fun onDestroy() {
        forceShutdownPlayer()
        super.onDestroy()
    }


    private val nextEpCountdownRunnable = object : Runnable {
        override fun run() {
            if (isFinishing || isDestroyed || nextEpDismissed || nextEpCard?.visibility != View.VISIBLE) return
            nextEpCountdownSec--
            if (nextEpCountdownSec <= 0) {
                playNextEpisodeInPlayer()
            } else {
                nextEpCountdownTv?.text = "Starting in ${nextEpCountdownSec}s..."
                mainHandler.postDelayed(this, 1000L)
            }
        }
    }

    private fun handleSkipSegmentClick() {
        if (vlcPlayer == null) return
        if (activeSkipTargetSec > 0) {
            vlcSeekTo((activeSkipTargetSec * 1000.0).toLong())
            skipSegmentBtn?.visibility = View.GONE
            activeSkipTargetSec = -1.0
        }
    }

    private fun dismissNextEpisodeCard() {
        nextEpDismissed = true
        mainHandler.removeCallbacks(nextEpCountdownRunnable)
        nextEpCard?.visibility = View.GONE
    }

    private fun playNextEpisodeInPlayer() {
        mainHandler.removeCallbacks(nextEpCountdownRunnable)
        nextEpCard?.visibility = View.GONE
        saveCurrentProgress(forceCompleted = true)
        stopBackgroundServerProbing()
        verifiedServers.clear()
        probedFailedServers.clear()
        availableSubs.clear()
        activeParsedCues.clear()
        activeSubIndex = -1
        subtitleOverlayView?.visibility = View.GONE
        val stepUsed = episodeStepForCurrentStream()
        if (stepUsed == 2) {
            val idKeyMid = imdbId.ifEmpty { tmdbId }
            val midKey = "tv_${idKeyMid}_s${seasonNum}e${episodeNum + 1}"
            try {
                val durMid = (vlcDurationMs() / 1000L).coerceAtLeast(1L)
                StreambertApp.instance.database.playbackProgressDao().upsertSync(
                    PlaybackProgressEntity(progressKey = midKey, percent = 100, positionSec = durMid, durationSec = durMid, watched = true)
                )
                ExoProgressBus.listener?.invoke(midKey, 100, durMid, durMid, true, false)
            } catch (_: Throwable) {}
        }
        val nxtEp = computeNextEpisode() ?: return
        seasonNum = nxtEp.first
        episodeNum = nxtEp.second
        seasonEpisodesList.firstOrNull { it.first == seasonNum }?.let { totalEpisodesInSeason = it.second }
        val idKey = imdbId.ifEmpty { tmdbId }
        progressKey = "tv_${idKey}_s${seasonNum}e${episodeNum}"
        streamTitle = "$seriesTitleStr · S${seasonNum}E${episodeNum}"
        titleView?.text = streamTitle
        updateTopActionButtons()
        startTimeSec = 0L
        streamUrl = ""
        introStartSec = -1.0
        introEndSec = -1.0
        recapStartSec = -1.0
        recapEndSec = -1.0
        outroStartSec = -1.0
        nextEpDismissed = false
        updateSwitchServerButtonText()
        try {
            vlcPlaybackReady = false
            vlcPlayer?.stop()
        } catch (_: Throwable) {}
        startResolvingInitialSource()
        fetchOnlineSubtitlesInBackground()
        fetchSkipSegmentsInBackground()
        mainHandler.postDelayed({ startBackgroundServerProbing() }, 400L)
    }

    private fun autoDetectSegmentsFromStreamAndCues() {
        val cues = activeParsedCues.toList()
        if (cues.isEmpty()) return
        val durMs = vlcDurationMs()
        val validDur = if (durMs > 60000L) durMs / 1000.0 else 0.0

        fun isMetaOrMusicCue(text: String): Boolean {
            val l = text.lowercase()
            if (l.contains("♪") || l.contains("♫") || l.contains("[music") || l.contains("(music") || l.contains("theme song")) return true
            if (l.contains("directed by") || l.contains("produced by") || l.contains("starring") || l.contains("written by") || l.contains("executive producer") || l.contains("created by") || l.contains("based on")) return true
            if (l.contains("synced by") || l.contains("translated by") || l.contains("subtitles by") || l.contains("opensubtitles") || l.contains("osdb.link")) return true
            return false
        }

        val spoken = cues.filter { !isMetaOrMusicCue(it.text) && it.text.trim().isNotEmpty() }
        val firstSpoken = spoken.firstOrNull() ?: return
        val firstStartSec = firstSpoken.startMs / 1000.0
        val openingLimit = if (validDur > 0.0) minOf(validDur * 0.45, 720.0) else 720.0

        data class GapCand(val st: Double, val en: Double, val score: Int)
        val gapCands = mutableListOf<GapCand>()

        val isTv = mediaType.equals("tv", ignoreCase = true)
        if (firstStartSec in 25.0..210.0) {
            val musicBefore = cues.filter { (it.endMs / 1000.0) <= firstStartSec + 1.0 && isMetaOrMusicCue(it.text) }
            if (isTv && firstStartSec >= 32.0 || musicBefore.isNotEmpty()) {
                val bonus = if (musicBefore.isEmpty()) 0 else 45
                val startAt = (musicBefore.firstOrNull()?.startMs ?: 2000L) / 1000.0
                gapCands.add(GapCand(maxOf(1.5, startAt), maxOf(startAt + 8.0, firstStartSec - 0.8), 55 + bonus))
            }
        }

        if (isTv) {
            for (i in 0 until (spoken.size - 1)) {
                val cur = spoken[i]
                val nxt = spoken[i + 1]
                val curEndSec = cur.endMs / 1000.0
                val nxtStartSec = nxt.startMs / 1000.0
                if (curEndSec > openingLimit) break
                val gap = nxtStartSec - curEndSec
                if (gap in 28.0..135.0) {
                    val musicInGap = cues.filter { (it.startMs / 1000.0) >= curEndSec - 1.0 && (it.endMs / 1000.0) <= nxtStartSec + 1.0 && isMetaOrMusicCue(it.text) }
                    var sc = 45
                    if (gap in 32.0..98.0) sc += 25
                    if (musicInGap.isNotEmpty()) sc += 50
                    gapCands.add(GapCand(curEndSec + 0.5, nxtStartSec - 0.8, sc))
                }
            }
        }

        if (introEndSec > introStartSec && introStartSec >= 0.0) {
            val extDur = introEndSec - introStartSec
            val conflictingSpoken = spoken.count { (it.startMs / 1000.0) >= introStartSec + 5.0 && (it.endMs / 1000.0) <= introEndSec - 5.0 }
            val bestSync = gapCands.minByOrNull { kotlin.math.abs(it.st - introStartSec) + kotlin.math.abs((it.en - it.st) - extDur) }
            if (bestSync != null && kotlin.math.abs(bestSync.st - introStartSec) <= 45.0 && kotlin.math.abs((bestSync.en - bestSync.st) - extDur) <= 25.0) {
                introStartSec = bestSync.st
                introEndSec = bestSync.en
            } else if (conflictingSpoken >= 2) {
                val bestAuto = gapCands.maxByOrNull { it.score }
                if (bestAuto != null) {
                    introStartSec = bestAuto.st
                    introEndSec = bestAuto.en
                } else {
                    introStartSec = -1.0
                    introEndSec = -1.0
                }
            }
        } else {
            val bestAuto = gapCands.maxByOrNull { it.score }
            if (bestAuto != null) {
                introStartSec = bestAuto.st
                introEndSec = bestAuto.en
            }
        }

        if (validDur > 180.0) {
            val lastSpoken = spoken.lastOrNull()
            if (lastSpoken != null) {
                val lastEndSec = lastSpoken.endMs / 1000.0
                val rem = validDur - lastEndSec
                if (outroStartSec > 0.0) {
                    val spokenAfterOutro = spoken.count { (it.startMs / 1000.0) >= outroStartSec + 6.0 }
                    if (spokenAfterOutro >= 3) {
                        outroStartSec = if (rem in 25.0..300.0 && lastEndSec >= validDur * 0.78) lastEndSec + 1.5 else -1.0
                    }
                } else if (rem in 25.0..300.0 && lastEndSec >= validDur * 0.78) {
                    outroStartSec = lastEndSec + 1.5
                }
            }
        }
    }

    private fun fetchSkipSegmentsInBackground(durationMs: Long = 0L) {
        if (durationMs == 0L) {
            introStartSec = -1.0
            introEndSec = -1.0
            recapStartSec = -1.0
            recapEndSec = -1.0
            outroStartSec = -1.0
        }
        val rawIm = imdbId.trim()
        val tm = tmdbId.trim()
        val isTv = mediaType.equals("tv", ignoreCase = true)
        val sNum = seasonNum
        val eNum = episodeNum
        val durSec = if (durationMs > 0L) durationMs / 1000.0 else (vlcDurationMs() / 1000.0)

        thread(start = true) {
            var im = rawIm
            if (!im.startsWith("tt") && tm.isNotEmpty() && tm.all { it.isDigit() }) {
                try {
                    val prop = if (isTv) "P4983" else "P4947"
                    val sparql = "SELECT ?imdb WHERE { ?item wdt:$prop \"$tm\" . ?item wdt:P345 ?imdb . } LIMIT 1"
                    val wu = "https://query.wikidata.org/sparql?format=json&query=" + java.net.URLEncoder.encode(sparql, "UTF-8")
                    val wReq = Request.Builder().url(wu).header("Accept", "application/sparql-results+json").build()
                    StreambertApp.instance.okHttpClient.newCall(wReq).execute().use { res ->
                        if (res.isSuccessful) {
                            val bindings = JSONObject(res.body?.string() ?: "{}").optJSONObject("results")?.optJSONArray("bindings")
                            val valStr = bindings?.optJSONObject(0)?.optJSONObject("imdb")?.optString("value", "") ?: ""
                            if (valStr.startsWith("tt")) im = valStr
                        }
                    }
                } catch (_: Throwable) {}
            }

            val lock = Any()
            val introCands = mutableListOf<Triple<Double, Double, Int>>()
            val recapCands = mutableListOf<Triple<Double, Double, Int>>()
            val outroCands = mutableListOf<Pair<Double, Int>>()

            fun addIntro(st: Double, en: Double, w: Int) {
                if (st >= 0.0 && en > st + 5.0 && (en - st) <= 240.0 && (durSec <= 0.0 || st < maxOf(durSec * 0.45, 720.0))) {
                    synchronized(lock) { introCands.add(Triple(st, en, w)) }
                }
            }
            fun addRecap(st: Double, en: Double, w: Int) {
                if (st >= 0.0 && en > st + 5.0 && st < 150.0 && (durSec <= 0.0 || en < durSec * 0.25)) {
                    synchronized(lock) { recapCands.add(Triple(st, en, w)) }
                }
            }
            fun addOutro(st: Double, w: Int) {
                if (st <= 30.0 || durSec <= 180.0) return
                val rem = durSec - st
                if (rem < 12.0 || rem > 240.0 || st < durSec * 0.80) return
                synchronized(lock) { outroCands.add(Pair(st, w)) }
            }

            val latch = java.util.concurrent.CountDownLatch(7)

            thread(start = true) {
                try {
                    val qp = mutableListOf<String>()
                    if (im.startsWith("tt")) qp.add("imdb_id=$im")
                    else if (tm.isNotEmpty() && tm.all { it.isDigit() }) qp.add("tmdb_id=$tm")
                    if (isTv) { qp.add("season=$sNum"); qp.add("episode=$eNum") }
                    if (durationMs > 30_000L) qp.add("duration_ms=$durationMs")
                    if (qp.isNotEmpty()) {
                        val req = Request.Builder().url("https://api.theintrodb.org/v3/media?" + qp.joinToString("&")).header("User-Agent", "SingularityTV/1.0.0").build()
                        StreambertApp.instance.okHttpClient.newCall(req).execute().use { res ->
                            if (res.isSuccessful) {
                                val obj = JSONObject(res.body?.string() ?: "{}")
                                obj.optJSONArray("intro")?.optJSONObject(0)?.let { addIntro(it.optDouble("start_ms", 0.0) / 1000.0, it.optDouble("end_ms", -1.0) / 1000.0, 6) }
                                obj.optJSONArray("recap")?.optJSONObject(0)?.let { addRecap(it.optDouble("start_ms", 0.0) / 1000.0, it.optDouble("end_ms", -1.0) / 1000.0, 6) }
                                obj.optJSONArray("credits")?.optJSONObject(0)?.let { addOutro(it.optDouble("start_ms", -1.0) / 1000.0, 6) }
                            }
                        }
                    }
                } catch (_: Throwable) {} finally { latch.countDown() }
            }

            thread(start = true) {
                try {
                    if (im.startsWith("tt")) {
                        val epStr = if (isTv) "season=$sNum&episode=$eNum" else "is_movie=true"
                        val req2 = Request.Builder().url("https://api.introdb.app/segments?imdb_id=$im&$epStr").header("User-Agent", "SingularityTV/1.0.0").build()
                        StreambertApp.instance.okHttpClient.newCall(req2).execute().use { res ->
                            if (res.isSuccessful) {
                                val obj = JSONObject(res.body?.string() ?: "{}")
                                obj.optJSONObject("intro")?.let { seg ->
                                    addIntro(seg.optDouble("start_ms", seg.optDouble("start_sec", 0.0) * 1000.0) / 1000.0, seg.optDouble("end_ms", seg.optDouble("end_sec", 0.0) * 1000.0) / 1000.0, 5)
                                }
                                obj.optJSONObject("recap")?.let { seg ->
                                    addRecap(seg.optDouble("start_ms", seg.optDouble("start_sec", 0.0) * 1000.0) / 1000.0, seg.optDouble("end_ms", seg.optDouble("end_sec", 0.0) * 1000.0) / 1000.0, 5)
                                }
                                (obj.optJSONObject("outro") ?: obj.optJSONObject("credits"))?.let { seg ->
                                    addOutro(seg.optDouble("start_ms", seg.optDouble("start_sec", 0.0) * 1000.0) / 1000.0, 5)
                                }
                            }
                        }
                    }
                } catch (_: Throwable) {} finally { latch.countDown() }
            }

            thread(start = true) {
                try {
                    if (im.startsWith("tt") && isTv) {
                        val req2b = Request.Builder().url("https://api.introdb.app/intro?imdb_id=$im&season=$sNum&episode=$eNum").header("User-Agent", "SingularityTV/1.0.0").build()
                        StreambertApp.instance.okHttpClient.newCall(req2b).execute().use { res ->
                            if (res.isSuccessful) {
                                val obj = JSONObject(res.body?.string() ?: "{}")
                                addIntro(obj.optDouble("start_ms", obj.optDouble("start_sec", 0.0) * 1000.0) / 1000.0, obj.optDouble("end_ms", obj.optDouble("end_sec", 0.0) * 1000.0) / 1000.0, 4)
                            }
                        }
                    }
                } catch (_: Throwable) {} finally { latch.countDown() }
            }

            for (skipBase in listOf("https://api.skipdb.tv/v1/segments", "https://api.skipdb.tv/api/segments")) {
                thread(start = true) {
                    try {
                        if (im.startsWith("tt") || (tm.isNotEmpty() && tm.all { it.isDigit() })) {
                            val sp = mutableListOf<String>()
                            if (im.startsWith("tt")) sp.add("imdb_id=$im") else sp.add("tmdb_id=$tm")
                            if (isTv) { sp.add("season=$sNum"); sp.add("episode=$eNum") }
                            if (durationMs > 30_000L) sp.add("duration_ms=$durationMs")
                            val req3 = Request.Builder().url("$skipBase?" + sp.joinToString("&")).header("User-Agent", "SingularityTV/1.0.0").build()
                            StreambertApp.instance.okHttpClient.newCall(req3).execute().use { res ->
                                if (res.isSuccessful) {
                                    val obj = JSONObject(res.body?.string() ?: "{}")
                                    val arr = obj.optJSONArray("segments") ?: obj.optJSONArray("results") ?: obj.optJSONArray("data") ?: JSONArray()
                                    for (i in 0 until arr.length()) {
                                        val seg = arr.optJSONObject(i) ?: continue
                                        val tp = seg.optString("type", seg.optString("segment", "")).lowercase()
                                        val st = seg.optDouble("start_ms", seg.optDouble("start", 0.0) * 1000.0) / 1000.0
                                        val en = seg.optDouble("end_ms", seg.optDouble("end", 0.0) * 1000.0) / 1000.0
                                        if (tp.contains("intro") || tp == "op") addIntro(st, en, 4)
                                        else if (tp.contains("recap")) addRecap(st, en, 4)
                                        else if (tp.contains("credit") || tp.contains("outro") || tp == "ed") addOutro(st, 4)
                                    }
                                }
                            }
                        }
                    } catch (_: Throwable) {} finally { latch.countDown() }
                }
            }

            thread(start = true) {
                try {
                    if (im.startsWith("tt")) {
                        val ihUrl = if (isTv) "https://api.introhater.com/skip-times?imdb_id=$im&season=$sNum&episode=$eNum" else "https://api.introhater.com/skip-times?imdb_id=$im"
                        val req4 = Request.Builder().url(ihUrl).header("User-Agent", "SingularityTV/1.0.0").build()
                        StreambertApp.instance.okHttpClient.newCall(req4).execute().use { res ->
                            if (res.isSuccessful) {
                                val obj = JSONObject(res.body?.string() ?: "{}")
                                val arr = obj.optJSONArray("results") ?: obj.optJSONArray("segments") ?: JSONArray()
                                for (i in 0 until arr.length()) {
                                    val seg = arr.optJSONObject(i) ?: continue
                                    val tp = seg.optString("skipType", seg.optString("type", "")).lowercase()
                                    val iv = seg.optJSONObject("interval") ?: continue
                                    val st = iv.optDouble("startTime", -1.0)
                                    val en = iv.optDouble("endTime", -1.0)
                                    if (tp == "op" || tp.contains("intro")) addIntro(st, en, 3)
                                    else if (tp == "recap") addRecap(st, en, 3)
                                    else if (tp == "ed" || tp.contains("outro") || tp.contains("credit")) addOutro(st, 3)
                                }
                            }
                        }
                    }
                } catch (_: Throwable) {} finally { latch.countDown() }
            }

            thread(start = true) {
                try {
                    if (im.startsWith("tt")) {
                        val armReq = Request.Builder().url("https://arm.haglund.dev/api/v2/ids?source=imdb&id=$im").build()
                        StreambertApp.instance.okHttpClient.newCall(armReq).execute().use { res ->
                            if (res.isSuccessful) {
                                val malId = JSONObject(res.body?.string() ?: "{}").optInt("myanimelist", 0)
                                if (malId > 0) {
                                    val epLen = if (durSec > 60.0) durSec.toInt() else 0
                                    val aniReq = Request.Builder().url("https://api.aniskip.com/v2/skip-times/$malId/${if (isTv) eNum else 1}?types[]=op&types[]=ed&types[]=recap&episodeLength=$epLen").build()
                                    StreambertApp.instance.okHttpClient.newCall(aniReq).execute().use { r2 ->
                                        if (r2.isSuccessful) {
                                            val arr = JSONObject(r2.body?.string() ?: "{}").optJSONArray("results") ?: JSONArray()
                                            for (i in 0 until arr.length()) {
                                                val seg = arr.optJSONObject(i) ?: continue
                                                val tp = seg.optString("skipType", "").lowercase()
                                                val iv = seg.optJSONObject("interval") ?: continue
                                                val st = iv.optDouble("startTime", -1.0)
                                                val en = iv.optDouble("endTime", -1.0)
                                                if (tp == "op") addIntro(st, en, 4)
                                                else if (tp == "recap") addRecap(st, en, 4)
                                                else if (tp == "ed") addOutro(st, 4)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                } catch (_: Throwable) {} finally { latch.countDown() }
            }

            try { latch.await(7000L, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (_: Throwable) {}

            fun pickBestSpan(cands: List<Triple<Double, Double, Int>>): Pair<Double, Double>? {
                if (cands.isEmpty()) return null
                var bestScore = -1
                var bestCenter = cands[0]
                for (c in cands) {
                    var score = 0
                    for (o in cands) {
                        if (kotlin.math.abs(c.first - o.first) <= 3.5 && kotlin.math.abs(c.second - o.second) <= 3.5) {
                            score += o.third
                        }
                    }
                    if (score > bestScore) {
                        bestScore = score
                        bestCenter = c
                    }
                }
                var sumSt = 0.0
                var sumEn = 0.0
                var totalW = 0.0
                var count = 0
                var maxW = 0
                for (o in cands) {
                    if (kotlin.math.abs(bestCenter.first - o.first) <= 3.5 && kotlin.math.abs(bestCenter.second - o.second) <= 3.5) {
                        val w = o.third.toDouble()
                        sumSt += o.first * w
                        sumEn += o.second * w
                        totalW += w
                        count++
                        if (o.third > maxW) maxW = o.third
                    }
                }
                if (count < 2 && maxW < 6) return null
                return if (totalW > 0.0) Pair(sumSt / totalW, sumEn / totalW) else Pair(bestCenter.first, bestCenter.second)
            }

            fun pickBestOutro(cands: List<Pair<Double, Int>>): Double? {
                if (cands.isEmpty()) return null
                var bestScore = -1
                var bestCenter = cands[0]
                for (c in cands) {
                    var score = 0
                    for (o in cands) {
                        if (kotlin.math.abs(c.first - o.first) <= 4.0) score += o.second
                    }
                    if (score > bestScore) {
                        bestScore = score
                        bestCenter = c
                    }
                }
                var sumSt = 0.0
                var totalW = 0.0
                for (o in cands) {
                    if (kotlin.math.abs(bestCenter.first - o.first) <= 4.0) {
                        val w = o.second.toDouble()
                        sumSt += o.first * w
                        totalW += w
                    }
                }
                return if (totalW > 0.0) sumSt / totalW else bestCenter.first
            }

            val bestIntro = synchronized(lock) { pickBestSpan(introCands) }
            val bestRecap = synchronized(lock) { pickBestSpan(recapCands) }
            val bestOutro = synchronized(lock) { pickBestOutro(outroCands) }

            mainHandler.post {
                if (isFinishing || isDestroyed) return@post
                bestIntro?.let { introStartSec = it.first; introEndSec = it.second }
                bestRecap?.let { recapStartSec = it.first; recapEndSec = it.second }
                bestOutro?.let { outroStartSec = it }
                autoDetectSegmentsFromStreamAndCues()
            }
        }
    }

    private fun updateSkipAndNextEpisodeUi() {
        if (vlcPlayer == null) return
        val cur = vlcCurrentPosMs() / 1000.0
        val dur = vlcDurationMs() / 1000.0
        if (cur < 0) return

        skipSegmentBtn?.visibility = View.GONE
        activeSkipTargetSec = -1.0

        val card = nextEpCard ?: return
        if (mediaType.equals("tv", ignoreCase = true) && !nextEpDismissed && dur > 120.0) {
            val nextPair = computeNextEpisode()
            if (nextPair != null) {
                val validOutro = outroStartSec > 60.0 && (dur - outroStartSec) in 12.0..240.0 && outroStartSec >= dur * 0.80
                val triggerSec = if (validOutro) outroStartSec else maxOf(dur * 0.94, dur - 45.0)
                if (cur >= triggerSec && cur < dur) {
                    if (card.visibility != View.VISIBLE) {
                        nextEpTitleTv?.text = "$seriesTitleStr · S${nextPair.first}E${nextPair.second}"
                        nextEpCountdownSec = 10
                        nextEpCountdownTv?.text = "Starting in 10s..."
                        card.visibility = View.VISIBLE
                        card.bringToFront()
                        mainHandler.removeCallbacks(nextEpCountdownRunnable)
                        mainHandler.postDelayed(nextEpCountdownRunnable, 1000L)
                    }
                } else if (card.visibility == View.VISIBLE) {
                    mainHandler.removeCallbacks(nextEpCountdownRunnable)
                    card.visibility = View.GONE
                }
            }
        }
    }

    companion object {
        const val EXTRA_PAYLOAD_JSON = "extra_payload_json"
        @Volatile var isPlayerActive: Boolean = false
        @Volatile var activeInstance: NativeExoPlayerActivity? = null
        var onNeedNextServer: ((String, Long, (String?, String?) -> Unit) -> Unit)? = null

        fun forceCloseIfOpen() {
            val inst = activeInstance
            if (inst != null) {
                try {
                    inst.runOnUiThread {
                        inst.forceShutdownPlayer()
                        if (!inst.isFinishing && !inst.isDestroyed) {
                            inst.finish()
                        }
                    }
                } catch (_: Throwable) {}
            }
            isPlayerActive = false
            activeInstance = null
        }
    }
}

object ExoProgressBus {
    var listener: ((String, Int, Long, Long, Boolean, Boolean) -> Unit)? = null
    var serverSwitchListener: ((String) -> Unit)? = null
    var preferredSourceListener: ((String) -> Unit)? = null
    var subtitleStyleListener: ((String, String, Float) -> Unit)? = null
    var webPrefsListener: ((String) -> Unit)? = null
}
