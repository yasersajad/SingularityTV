export const ACCENT_PRESETS = [
  { id: "red", label: "Electric Crimson", color: "#E50914", color2: "#FF2A4B", dim: "rgba(229, 9, 20, 0.16)", glow: "0 0 28px rgba(229, 9, 20, 0.38)" },
  { id: "violet", label: "Singularity Violet", color: "#8B5CF6", color2: "#A78BFA", dim: "rgba(139, 92, 246, 0.16)", glow: "0 0 28px rgba(139, 92, 246, 0.38)" },
  { id: "blue", label: "Cosmic Blue", color: "#3B82F6", color2: "#60A5FA", dim: "rgba(59, 130, 246, 0.16)", glow: "0 0 28px rgba(59, 130, 246, 0.38)" },
  { id: "green", label: "Emerald Pulse", color: "#10B981", color2: "#34D399", dim: "rgba(16, 185, 129, 0.16)", glow: "0 0 28px rgba(16, 185, 129, 0.35)" },
  { id: "orange", label: "Solar Amber", color: "#F59E0B", color2: "#FBBF24", dim: "rgba(245, 158, 11, 0.16)", glow: "0 0 28px rgba(245, 158, 11, 0.35)" },
  { id: "pink", label: "Nebula Rose", color: "#EC4899", color2: "#F472B6", dim: "rgba(236, 72, 153, 0.16)", glow: "0 0 28px rgba(236, 72, 153, 0.35)" }
];

export function applyAccentColor(presetId) {
  const preset = ACCENT_PRESETS.find(p => p.id === presetId) ?? ACCENT_PRESETS[0];
  const root = document.documentElement;
  root.style.setProperty("--red", preset.color);
  root.style.setProperty("--red2", preset.color2);
  root.style.setProperty("--accent", preset.color);
  root.style.setProperty("--accent2", preset.color2);
  root.style.setProperty("--red-dim", preset.dim);
  root.style.setProperty("--red-glow", preset.glow);
}

export const DEFAULT_CUSTOM_VARS = {
  "--bg": "#07080D",
  "--bg-secondary": "#0C0E15",
  "--surface": "#0C0E15",
  "--surface2": "#141722",
  "--surface3": "#1B1F2E",
  "--glass": "rgba(255, 255, 255, 0.055)",
  "--border": "rgba(255, 255, 255, 0.09)",
  "--text": "#F7F8FC",
  "--text2": "#A3A8B8",
  "--text3": "#6F768A"
};

export const THEME_PRESETS = [
  { id: "dark", label: "Singularity Obsidian", description: "Deep cosmic black with elevated glass surfaces", vars: { ...DEFAULT_CUSTOM_VARS } },
  { id: "oled", label: "Pure Zero OLED", description: "True #000000 black for OLED panels", vars: { "--bg": "#000000", "--bg-secondary": "#06070B", "--surface": "#090A10", "--surface2": "#121520", "--surface3": "#1A1E2C", "--glass": "rgba(255, 255, 255, 0.05)", "--border": "rgba(255, 255, 255, 0.08)", "--text": "#F7F8FC", "--text2": "#A3A8B8", "--text3": "#6F768A" } },
  { id: "midnight", label: "Nebula Slate", description: "Deep midnight slate with cool silver undertones", vars: { "--bg": "#090B14", "--bg-secondary": "#0E1220", "--surface": "#121728", "--surface2": "#182036", "--surface3": "#202A46", "--glass": "rgba(255, 255, 255, 0.06)", "--border": "rgba(163, 184, 248, 0.14)", "--text": "#F7F8FC", "--text2": "#A9B2C8", "--text3": "#747E99" } }
];

export function applyTheme(themeId, customVars = null) {
  const root = document.documentElement;
  const preset = THEME_PRESETS.find(p => p.id === themeId) ?? THEME_PRESETS[0];
  const vars = themeId === "custom" && customVars ? { ...DEFAULT_CUSTOM_VARS, ...customVars } : preset.vars;
  for (const [k, v] of Object.entries(vars)) root.style.setProperty(k, v);
}
