import React, { useState, useEffect, useMemo, useCallback, useRef } from "react";
import MediaCard from "../components/MediaCard";
import HeroBanner from "../components/HeroBanner";
import { tmdbFetch, isAnimeContent } from "../utils/api";
import { WifiOffIcon } from "../components/Icons";
import { useRatings, getRatingForItem } from "../utils/useRatings";
import { isRestricted } from "../utils/ageRating";
import { loadHomeLayout, loadHomeViewMode } from "../utils/homeLayout";

function getRecentHistoryItems(history, count = 5) {
  if (!history || history.length === 0) return [];
  const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;
  const recent = history.filter(h => h.watchedAt && h.watchedAt > thirtyDaysAgo).sort((a, b) => b.watchedAt - a.watchedAt);
  const seen = new Set();
  const unique = [];
  for (const item of recent) {
    const key = `${item.media_type || "movie"}_${item.id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    unique.push(item);
    if (unique.length >= count) break;
  }
  return unique;
}

export default function HomePage({
  trending, trendingTV, loading, onSelect, progress, inProgress, offline, onRetry,
  watched, onMarkWatched, onMarkUnwatched, history, savedList = [], onToggleSave,
  isSavedFn, activeFilter = "all", isTvMode = false, apiKey
}) {
  const [recommendedItems, setRecommendedItems] = useState([]);
  const [topRatedItems, setTopRatedItems] = useState([]);
  const [popularMovies, setPopularMovies] = useState([]);
  const [popularTV, setPopularTV] = useState([]);
  const [animeItems, setAnimeItems] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [categoryItems, setCategoryItems] = useState([]);
  const [loadingCategory, setLoadingCategory] = useState(false);
  const [categoryPage, setCategoryPage] = useState(1);
  const [categoryHasMore, setCategoryHasMore] = useState(false);
  const [loadingMoreCategory, setLoadingMoreCategory] = useState(false);
  const categoryItemsRef = useRef([]);
  useEffect(() => { categoryItemsRef.current = categoryItems; }, [categoryItems]);

  const CATEGORIES = useMemo(() => ["All", "Action", "Sci-Fi", "Fantasy", "Horror", "Comedy", "Drama", "Thriller", "Animation", "Mystery", "Crime", "Adventure", "Romance", "Family", "Documentary"], []);
  const [layout, setLayout] = useState(() => loadHomeLayout());
  const [viewMode, setViewMode] = useState(() => loadHomeViewMode());
  useEffect(() => {
    const onLayout = () => setLayout(loadHomeLayout());
    const onView = () => setViewMode(loadHomeViewMode());
    window.addEventListener("streambert:home-layout-changed", onLayout);
    window.addEventListener("streambert:home-view-changed", onView);
    return () => {
      window.removeEventListener("streambert:home-layout-changed", onLayout);
      window.removeEventListener("streambert:home-view-changed", onView);
    };
  }, []);
  const { order: rowOrder, visible: rowVisible } = layout;

  const allItems = useMemo(() => [
    ...inProgress, ...trending.map(i => ({ ...i, media_type: "movie" })), ...trendingTV.map(i => ({ ...i, media_type: "tv" })),
    ...recommendedItems, ...topRatedItems, ...popularMovies, ...popularTV, ...animeItems
  ], [inProgress, trending, trendingTV, recommendedItems, topRatedItems, popularMovies, popularTV, animeItems]);

  const { ratingsMap, ageLimitSetting } = useRatings(allItems);
  const itemRestricted = useCallback(item => isRestricted(getRatingForItem(item, ratingsMap).minAge, ageLimitSetting), [ratingsMap, ageLimitSetting]);
  const enrichedRatingsMap = useMemo(() => {
    const out = {};
    for (const [k, v] of Object.entries(ratingsMap)) out[k] = { ...v, restricted: isRestricted(v.minAge, ageLimitSetting) };
    return out;
  }, [ratingsMap, ageLimitSetting]);
  const filteredRecommendedItems = useMemo(() => recommendedItems.filter(item => !itemRestricted(item)), [recommendedItems, itemRestricted]);

  useEffect(() => {
    if (!apiKey || offline || !history || history.length === 0) return;
    const sources = getRecentHistoryItems(history, 5);
    if (sources.length === 0) return;
    const controller = new AbortController();
    const watchedIds = new Set((history || []).map(h => `${h.media_type || "movie"}_${h.id}`));
    Promise.all(sources.map(source => {
      const type = source.media_type === "tv" ? "tv" : "movie";
      return tmdbFetch(`/${type}/${source.id}/recommendations`, apiKey, { signal: controller.signal })
        .then(data => {
          const results = (data.results || []).map(i => ({ ...i, media_type: type }));
          return results.length > 0 ? results : tmdbFetch(`/${type}/${source.id}/similar`, apiKey, { signal: controller.signal }).then(d => (d.results || []).map(i => ({ ...i, media_type: type })));
        }).catch(() => []);
    })).then(arrays => {
      const merged = [];
      const maxLen = Math.max(...arrays.map(a => a.length));
      for (let i = 0; i < maxLen; i++) for (const arr of arrays) if (arr[i]) merged.push(arr[i]);
      const seen = new Set();
      setRecommendedItems(merged.filter(item => {
        const key = `${item.media_type}_${item.id}`;
        if (seen.has(key) || watchedIds.has(key)) return false;
        seen.add(key);
        return true;
      }).slice(0, 20));
    }).catch(() => {});
    return () => controller.abort();
  }, [apiKey, offline, history?.length]);

  useEffect(() => {
    if (selectedCategory === "All" || offline) { setCategoryItems([]); setLoadingCategory(false); setCategoryPage(1); setCategoryHasMore(false); return; }
    let mounted = true;
    setLoadingCategory(true); setCategoryPage(1); setCategoryHasMore(false);
    tmdbFetch(`/discover/genre?genre=${encodeURIComponent(selectedCategory)}&page=1`, apiKey)
      .then(data => { if (mounted) { setCategoryItems(data?.results || []); setCategoryHasMore(!!data?.hasMore); } })
      .catch(() => { if (mounted) setCategoryItems([]); })
      .finally(() => { if (mounted) setLoadingCategory(false); });
    return () => { mounted = false; };
  }, [selectedCategory, apiKey, offline]);

  const loadMoreCategory = useCallback(() => {
    if (loadingMoreCategory || !categoryHasMore || selectedCategory === "All" || offline) return;
    const nextPage = categoryPage + 1;
    setLoadingMoreCategory(true);
    tmdbFetch(`/discover/genre?genre=${encodeURIComponent(selectedCategory)}&page=${nextPage}`, apiKey)
      .then(data => {
        const nextItems = data?.results || [];
        const seen = new Set(categoryItemsRef.current.map(x => `${x.media_type}_${x.id}`));
        const newUnique = nextItems.filter(item => !seen.has(`${item.media_type}_${item.id}`));
        if (newUnique.length > 0) { setCategoryItems(prev => [...prev, ...newUnique]); setCategoryPage(nextPage); setCategoryHasMore(!!data?.hasMore); }
        else setCategoryHasMore(false);
      }).catch(() => setCategoryHasMore(false)).finally(() => setLoadingMoreCategory(false));
  }, [loadingMoreCategory, categoryHasMore, selectedCategory, offline, categoryPage, apiKey]);

  useEffect(() => {
    if (!apiKey || offline) return;
    const controller = new AbortController();
    Promise.all([
      tmdbFetch("/movie/top_rated?page=1", apiKey, { signal: controller.signal }),
      tmdbFetch("/tv/top_rated?page=1", apiKey, { signal: controller.signal }),
      tmdbFetch("/movie/popular?page=1", apiKey, { signal: controller.signal }),
      tmdbFetch("/tv/popular?page=1", apiKey, { signal: controller.signal }),
      tmdbFetch("/discover/tv?with_genres=16&with_original_language=ja&sort_by=popularity.desc&page=1", apiKey, { signal: controller.signal })
    ]).then(([moviesData, tvData, popM, popT, anim]) => {
      const movies = (moviesData.results || []).slice(0, 12).map(i => ({ ...i, media_type: "movie" }));
      const tv = (tvData.results || []).slice(0, 12).map(i => ({ ...i, media_type: "tv" }));
      const merged = [];
      const max = Math.max(movies.length, tv.length);
      for (let i = 0; i < max; i++) { if (movies[i]) merged.push(movies[i]); if (tv[i]) merged.push(tv[i]); }
      setTopRatedItems(merged);
      setPopularMovies((popM.results || []).slice(0, 16).map(i => ({ ...i, media_type: "movie" })));
      setPopularTV((popT.results || []).slice(0, 16).map(i => ({ ...i, media_type: "tv" })));
      setAnimeItems((anim.results || []).slice(0, 16).map(i => ({ ...i, media_type: "tv" })));
    }).catch(() => {});
    return () => controller.abort();
  }, [apiKey, offline]);

  const trendingMovieItems = useMemo(() => trending.slice(0, 16).map(i => ({ ...i, media_type: "movie" })), [trending]);
  const trendingTVItems = useMemo(() => trendingTV.slice(0, 16).map(i => ({ ...i, media_type: "tv" })), [trendingTV]);

  const heroItems = useMemo(() => {
    if (activeFilter === "movies") return trendingMovieItems.slice(0, 5);
    if (activeFilter === "tv") return trendingTVItems.slice(0, 5);
    if (activeFilter === "anime") return (animeItems.length ? animeItems : trendingTVItems.filter(isAnimeContent)).slice(0, 5);
    return trendingMovieItems.slice(0, 5);
  }, [activeFilter, trendingMovieItems, trendingTVItems, animeItems]);

  const renderRow = (key, title, items, variant = "landscape") => {
    if (!items || items.length === 0) return null;
    return React.createElement("section", { key, className: "tv-row-section" },
      React.createElement("div", { className: "tv-row-header" }, React.createElement("h2", { className: "tv-row-title" }, title)),
      React.createElement("div", { className: viewMode === "list" ? "cards-grid tv-cards-grid" : "scroll-row tv-scroll-row" },
        items.map(item => {
          const type = item.media_type === "tv" ? "tv" : "movie";
          const rd = enrichedRatingsMap[`${type}_${item.id}`] || {};
          const pk = item.media_type === "movie" ? `movie_${item.id}` : (item.season != null && item.episode != null ? `tv_${item.id}_s${item.season}e${item.episode}` : null);
          return React.createElement(MediaCard, {
            key: `${key}_${type}_${item.id}_${item.season || ""}_${item.episode || ""}`,
            item, variant, onClick: () => onSelect(item), progress: pk ? progress[pk] || 0 : 0,
            watched, onMarkWatched, onMarkUnwatched, ageRating: rd.cert, restricted: rd.restricted
          });
        })
      )
    );
  };

  const topPicksItems = filteredRecommendedItems.length > 0 ? filteredRecommendedItems : trendingMovieItems;

  return React.createElement("div", { className: "tv-home fade-in" },
    offline && React.createElement("div", { className: "tv-offline-state" },
      React.createElement(WifiOffIcon, { size: 48 }),
      React.createElement("div", { style: { fontSize: 20, fontWeight: 600, color: "var(--text)" } }, "No internet connection"),
      React.createElement("div", { style: { fontSize: 14, color: "var(--text3)" } }, "Trending and search require an internet connection. Your downloads and library still work offline."),
      React.createElement("button", { className: "btn btn-primary", onClick: onRetry }, "Retry")
    ),
    !offline && loading && React.createElement("div", { className: "sg-skeleton-hero" }, React.createElement("div", { className: "sg-skeleton-shimmer" })),
    !offline && !loading && heroItems.length > 0 && React.createElement(HeroBanner, { items: heroItems, onSelect, ratingsMap: enrichedRatingsMap, onToggleSave, isSavedFn, isTvMode }),
    activeFilter === "all" && React.createElement("div", { className: "tv-category-bar" },
      CATEGORIES.map(cat => React.createElement("button", { key: cat, className: `tv-category-pill${selectedCategory === cat ? " active" : ""}`, onClick: () => setSelectedCategory(cat) }, cat))
    ),
    React.createElement("div", { className: "tv-rows-container" },
      activeFilter === "movies" && React.createElement(React.Fragment, null,
        renderRow("m_trending", "Trending Movies", trendingMovieItems, "landscape"),
        renderRow("m_popular", "Popular Movies", popularMovies, "poster"),
        renderRow("m_top", "Top Rated Movies", topRatedItems.filter(i => i.media_type === "movie"), "poster")
      ),
      activeFilter === "tv" && React.createElement(React.Fragment, null,
        renderRow("tv_trending", "Trending TV Shows", trendingTVItems, "landscape"),
        renderRow("tv_popular", "Popular Series", popularTV, "poster"),
        renderRow("tv_top", "Top Rated Series", topRatedItems.filter(i => i.media_type === "tv"), "poster")
      ),
      activeFilter === "anime" && React.createElement(React.Fragment, null,
        renderRow("an_popular", "Trending Anime", animeItems, "landscape"),
        renderRow("an_top", "Popular Anime Series", animeItems.slice().reverse(), "poster")
      ),
      activeFilter === "all" && selectedCategory !== "All" && React.createElement("section", { className: "tv-row-section" },
        React.createElement("div", { className: "tv-row-header" }, React.createElement("h2", { className: "tv-row-title" }, `${selectedCategory} Movies & Shows`)),
        loadingCategory ? React.createElement("div", { className: "loader", style: { padding: 28 } }, React.createElement("div", { className: "spinner" })) :
          categoryItems.length === 0 ? React.createElement("div", { style: { color: "var(--text3)", padding: "12px 4px", fontSize: 14 } }, `No titles found in ${selectedCategory}.`) :
          React.createElement("div", { className: "cards-grid tv-cards-grid" },
            categoryItems.map(item => {
              const type = item.media_type === "tv" ? "tv" : "movie";
              const rd = enrichedRatingsMap[`${type}_${item.id}`] || {};
              return React.createElement(MediaCard, { key: `cat_${type}_${item.id}`, item, variant: "poster", onClick: () => onSelect(item), progress: 0, watched, onMarkWatched, onMarkUnwatched, ageRating: rd.cert, restricted: rd.restricted });
            })
          ),
        !loadingCategory && categoryItems.length > 0 && categoryHasMore && React.createElement("div", { style: { display: "flex", justifyContent: "center", padding: "24px 0 8px" } },
          React.createElement("button", { className: "btn btn-ghost", onClick: loadMoreCategory, disabled: loadingMoreCategory, style: { padding: "10px 28px", borderRadius: 999, fontWeight: 600, fontSize: 14 } }, loadingMoreCategory ? "Loading..." : "Load More")
        )
      ),
      activeFilter === "all" && selectedCategory === "All" && React.createElement(React.Fragment, null,
        rowOrder.map(id => {
          if (!rowVisible[id]) return null;
          if (id === "continue") return renderRow("continue", "Continue Watching", inProgress, "landscape");
          if (id === "recommended") return renderRow("recommended", "Recommended For You", topPicksItems, "landscape");
          if (id === "trendingTV") return renderRow("trendingTV", "Trending TV Shows", trendingTVItems, "landscape");
          if (id === "trendingMovies") return renderRow("trendingMovies", "Trending Movies", trendingMovieItems, "poster");
          if (id === "topRated") return renderRow("topRated", "Top Rated", topRatedItems, "poster");
          return null;
        }),
        renderRow("popMovies", "Popular Movies", popularMovies, "poster"),
        renderRow("popSeries", "Popular Series", popularTV, "poster"),
        renderRow("animeRow", "Anime", animeItems, "landscape"),
        savedList.length > 0 && renderRow("favorites", "Your Favorites", savedList, "poster")
      )
    )
  );
}
