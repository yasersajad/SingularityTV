import React, { useState, useEffect } from "react";
import { imgUrl } from "../utils/api";
import { PlayIcon, StarIcon, BookmarkIcon, BookmarkFillIcon } from "./Icons";

export default function HeroBanner({ items = [], onSelect, ratingsMap = {}, onToggleSave, isSavedFn, isTvMode = false }) {
  const [activeIndex, setActiveIndex] = useState(0);
  useEffect(() => {
    if (items.length <= 1) return;
    const interval = setInterval(() => setActiveIndex(prev => (prev + 1) % items.length), 7500);
    return () => clearInterval(interval);
  }, [items.length]);

  const item = items[activeIndex] || items[0];
  if (!item) return null;
  const title = item.title || item.name;
  const year = (item.release_date || item.first_air_date || "").slice(0, 4);
  const mediaType = item.media_type === "tv" ? "tv" : "movie";
  const ratingInfo = ratingsMap[`${mediaType}_${item.id}`] || {};
  const backdrop = imgUrl(item.backdrop_path || item.poster_path, isTvMode ? "w1280" : "w780");
  const saved = isSavedFn ? isSavedFn(item) : false;

  return React.createElement("section", { className: "hero-banner sg-hero" },
    React.createElement("div", { key: `bg_${item.id}_${activeIndex}`, className: "hero-banner-bg sg-hero-bg-anim", style: { backgroundImage: backdrop ? `url(${backdrop})` : "none" } }),
    React.createElement("div", { className: "hero-banner-scrim" }),
    React.createElement("div", { className: "hero-banner-ambient-glow" }),
    React.createElement("div", { className: "hero-banner-inner" },
      React.createElement("div", { key: `meta_${item.id}_${activeIndex}`, className: "hero-banner-content sg-hero-meta-anim" },
        React.createElement("div", { className: "hero-banner-pills" },
          React.createElement("span", { className: "hero-pill hero-pill--accent" }, "FEATURED"),
          React.createElement("span", { className: "hero-pill" }, mediaType === "tv" ? "SERIES" : "MOVIE"),
          year && React.createElement("span", { className: "hero-pill" }, year),
          ratingInfo.cert && React.createElement("span", { className: "hero-pill" }, ratingInfo.cert),
          item.vote_average > 0 && React.createElement("span", { className: "hero-pill hero-pill--score" }, React.createElement(StarIcon, { size: 11 }), item.vote_average.toFixed(1))
        ),
        React.createElement("h1", { className: "hero-banner-title" }, title),
        item.overview && React.createElement("p", { className: "hero-banner-overview" }, item.overview),
        React.createElement("div", { className: "hero-actions" },
          React.createElement("button", { className: "btn btn-primary hero-action-btn", onClick: () => onSelect(item) }, React.createElement(PlayIcon), React.createElement("span", null, "Watch Now")),
          React.createElement("button", { className: "btn btn-secondary hero-action-btn", onClick: () => onSelect(item) }, React.createElement("span", null, "More Info")),
          onToggleSave && React.createElement("button", {
            className: `btn btn-glass hero-action-btn hero-fav-btn${saved ? " saved" : ""}`,
            onClick: () => onToggleSave(item),
            "aria-label": saved ? "Remove from Favorites" : "Add to Favorites"
          }, saved ? React.createElement(BookmarkFillIcon) : React.createElement(BookmarkIcon))
        )
      ),
      React.createElement("div", { className: "hero-banner-right" },
        items.length > 1 && React.createElement("div", { className: "hero-dots-pill" },
          items.map((slide, idx) => React.createElement("button", { key: slide.id || idx, className: `hero-dot${idx === activeIndex ? " active" : ""}`, onClick: () => setActiveIndex(idx), "aria-label": `Featured item ${idx + 1}` }))
        ),
        React.createElement("div", { className: "hero-platform-badge" },
          React.createElement("span", { className: "hero-platform-logo" }, "SINGULARITY WEBOS"),
          React.createElement("span", { className: "hero-platform-sub" }, "4K ULTRA HD · DOLBY VISION")
        )
      )
    )
  );
}
