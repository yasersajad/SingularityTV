import React, { useState, useEffect } from "react";
import { getAuthUser, getActiveProfile } from "../utils/supabaseSync";
import { SingularityLogo, SearchIcon, HomeIcon, HistoryIcon, SettingsIcon, DownloadsQueueIcon, FilmIcon, TVIcon, SparklesIcon } from "./Icons";

function LiveTvIcon() {
  return React.createElement("svg", { width: "18", height: "18", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" },
    React.createElement("rect", { x: "2", y: "7", width: "20", height: "15", rx: "2.5" }),
    React.createElement("polyline", { points: "17 2 12 7 7 2" })
  );
}

export function MobileBottomNavigation({ page, activeFilter, onNavigate, onSearch, onOpenProfiles, activeDownloads }) {
  const [activeProfile, setActiveProfile] = useState(() => getActiveProfile());
  const [authUser, setAuthUser] = useState(() => getAuthUser());
  useEffect(() => {
    const sync = () => { setActiveProfile(getActiveProfile()); setAuthUser(getAuthUser()); };
    window.addEventListener("singularity:profile-changed", sync);
    window.addEventListener("singularity:auth-changed", sync);
    window.addEventListener("singularity:live-sync-updated", sync);
    return () => {
      window.removeEventListener("singularity:profile-changed", sync);
      window.removeEventListener("singularity:auth-changed", sync);
      window.removeEventListener("singularity:live-sync-updated", sync);
    };
  }, []);

  const mobileTabs = [
    { id: "home", label: "Home", icon: React.createElement(HomeIcon) },
    { id: "search", label: "Search", icon: React.createElement(SearchIcon), isSearch: true },
    { id: "live", label: "Live TV", icon: React.createElement(LiveTvIcon) },
    { id: "history", label: "My Library", icon: React.createElement(HistoryIcon) },
    { id: "downloads", label: "Downloads", icon: React.createElement(DownloadsQueueIcon), badge: activeDownloads > 0 ? activeDownloads : null }
  ];

  return React.createElement(React.Fragment, null,
    React.createElement("header", { className: "sg-mobile-topbar" },
      React.createElement("button", { className: "sg-mobile-brand", onClick: () => onNavigate("home", { filter: "all" }), "aria-label": "SINGULARITY WebOS Home" },
        React.createElement(SingularityLogo, { variant: "horizontal", size: 30 })
      ),
      React.createElement("div", { className: "sg-mobile-top-actions" },
        React.createElement("button", {
          className: "sg-mobile-profile-chip",
          onClick: () => onOpenProfiles ? onOpenProfiles() : onNavigate("settings", { section: "account" }),
          "aria-label": "Switch Profile"
        },
          React.createElement("span", { className: "sg-profile-dot", style: { background: activeProfile?.avatarColor || "var(--red)" } }, (activeProfile?.name || authUser?.name || "S").charAt(0).toUpperCase()),
          React.createElement("span", { className: "sg-profile-chip-name" }, activeProfile?.name || "Profile")
        ),
        React.createElement("button", {
          className: `sg-mobile-settings-btn${page === "settings" ? " active" : ""}`,
          onClick: () => onNavigate("settings"),
          "aria-label": "Settings"
        }, React.createElement(SettingsIcon))
      )
    ),
    React.createElement("nav", { className: "sg-mobile-bottom-nav", "aria-label": "Mobile Primary Navigation" },
      mobileTabs.map(tab => {
        const isActive = !tab.isSearch && page === tab.id && (!activeFilter || activeFilter === "all");
        return React.createElement("button", {
          key: tab.id,
          className: `sg-mobile-tab${isActive ? " active" : ""}`,
          onClick: () => tab.isSearch ? onSearch() : onNavigate(tab.id, { filter: "all" }),
          "aria-label": tab.label
        },
          React.createElement("span", { className: "sg-mobile-tab-pill" }),
          React.createElement("span", { className: "sg-mobile-tab-icon" }, tab.icon),
          React.createElement("span", { className: "sg-mobile-tab-label" }, tab.label),
          tab.badge && React.createElement("span", { className: "sg-mobile-tab-badge" }, tab.badge)
        );
      })
    )
  );
}

export function TVNavigationRail({ page, activeFilter, onNavigate, onSearch, onOpenProfiles, activeDownloads }) {
  const [expanded, setExpanded] = useState(false);
  const [timeStr, setTimeStr] = useState(() => new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }));
  const [activeProfile, setActiveProfile] = useState(() => getActiveProfile());

  useEffect(() => {
    const sync = () => setActiveProfile(getActiveProfile());
    window.addEventListener("singularity:profile-changed", sync);
    window.addEventListener("singularity:live-sync-updated", sync);
    return () => {
      window.removeEventListener("singularity:profile-changed", sync);
      window.removeEventListener("singularity:live-sync-updated", sync);
    };
  }, []);

  useEffect(() => {
    const timer = setInterval(() => setTimeStr(new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })), 30000);
    return () => clearInterval(timer);
  }, []);

  const railItems = [
    { id: "home", filter: "all", label: "Home", icon: React.createElement(HomeIcon) },
    { id: "search", filter: null, label: "Search", icon: React.createElement(SearchIcon), isSearch: true },
    { id: "movies", filter: "movies", label: "Movies", icon: React.createElement(FilmIcon), targetPage: "home" },
    { id: "tvshows", filter: "tv", label: "TV Shows", icon: React.createElement(TVIcon), targetPage: "home" },
    { id: "anime", filter: "anime", label: "Anime", icon: React.createElement(SparklesIcon), targetPage: "home" },
    { id: "live", filter: "all", label: "Live TV", icon: React.createElement(LiveTvIcon) },
    { id: "history", filter: "all", label: "Library", icon: React.createElement(HistoryIcon) },
    { id: "downloads", filter: "all", label: "Downloads", icon: React.createElement(DownloadsQueueIcon), badge: activeDownloads > 0 ? activeDownloads : null },
    { id: "settings", filter: "all", label: "Settings", icon: React.createElement(SettingsIcon) }
  ];

  return React.createElement("aside", {
    className: `sg-tv-rail${expanded ? " expanded" : ""}`,
    onMouseEnter: () => setExpanded(true),
    onMouseLeave: () => setExpanded(false),
    onFocusCapture: () => setExpanded(true),
    onBlurCapture: e => { if (!e.currentTarget.contains(e.relatedTarget)) setExpanded(false); },
    "aria-label": "TV Navigation Rail"
  },
    React.createElement("div", { className: "sg-tv-rail-top" },
      React.createElement("button", { className: "sg-tv-rail-brand topnav-btn", onClick: () => onNavigate("home", { filter: "all" }), "aria-label": "SINGULARITY WebOS" },
        React.createElement(SingularityLogo, { variant: "compact", size: 36 }),
        React.createElement("div", { className: "sg-tv-rail-brand-text" },
          React.createElement("span", { className: "sg-brand-title" }, "SINGULARITY"),
          React.createElement("span", { className: "sg-brand-sub" }, "WEBOS")
        )
      ),
      React.createElement("button", {
        className: "sg-tv-rail-profile topnav-btn",
        onClick: () => onOpenProfiles ? onOpenProfiles() : onNavigate("settings", { section: "account" }),
        "aria-label": "Switch Profile"
      },
        React.createElement("span", { className: "sg-tv-avatar", style: { background: activeProfile?.avatarColor || "var(--red)" } }, (activeProfile?.name || "S").charAt(0).toUpperCase()),
        React.createElement("span", { className: "sg-tv-rail-label" }, activeProfile?.name || "Profile")
      )
    ),
    React.createElement("nav", { className: "sg-tv-rail-links" },
      railItems.map(item => {
        const target = item.targetPage || item.id;
        const isActive = !item.isSearch && page === target && (item.filter === (activeFilter || "all"));
        return React.createElement("button", {
          key: item.id,
          className: `sg-tv-rail-item topnav-btn${isActive ? " active" : ""}`,
          onClick: () => item.isSearch ? onSearch() : onNavigate(target, { filter: item.filter || "all" })
        },
          React.createElement("span", { className: "sg-tv-rail-icon" }, item.icon),
          React.createElement("span", { className: "sg-tv-rail-label" }, item.label),
          item.badge && React.createElement("span", { className: "sg-tv-rail-badge" }, item.badge)
        );
      })
    ),
    React.createElement("div", { className: "sg-tv-rail-footer" },
      React.createElement("span", { className: "sg-tv-clock" }, timeStr)
    )
  );
}

export default function AppNavigation(props) {
  return props.isTvMode ? React.createElement(TVNavigationRail, props) : React.createElement(MobileBottomNavigation, props);
}
