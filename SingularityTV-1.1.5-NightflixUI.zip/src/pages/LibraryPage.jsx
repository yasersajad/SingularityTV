import React, { useMemo, useState, useEffect, useCallback } from "react";
import { imgUrl } from "../utils/api";
import { getActiveProfile } from "../utils/supabaseSync";
import { PlayIcon, SearchIcon, SettingsIcon, CloseIcon, DownloadIcon } from "../components/Icons";

export default function LibraryPage({
  history = [],
  inProgress = [],
  saved = [],
  progress = {},
  onSelect,
  onRemoveHistory,
  downloads = [],
  onOpenExoPlayer,
  onSearch,
  onOpenProfiles,
  onSettings,
  isTvMode = false,
  onPlayDirect
}) {
  const [showAllSaved, setShowAllSaved] = useState(false);
  const [activeProfile, setActiveProfile] = useState(() => getActiveProfile());

  useEffect(() => {
    const sync = () => setActiveProfile(getActiveProfile());
    window.addEventListener("singularity:profile-changed", sync);
    window.addEventListener("singularity:live-sync-updated", sync);
    return () => {
      window.removeEventListener("singularity:profile-changed", sync);
      window.removeEventListener("singularity:live-sync-updated", sync);
    };
  }, []);

  const offlineDownloads = useMemo(() => {
    return (downloads || []).filter(
      d => d && (d.status === "completed" || d.status === "local") && (d.outputPath || d.filePath || d.path)
    );
  }, [downloads]);

  const playOfflineDownload = useCallback(dl => {
    const fileUrl = dl.outputPath || dl.filePath || dl.path;
    if (!fileUrl) return;
    const isTv = dl.mediaType === "tv" || dl.media_type === "tv" || dl.season != null;
    const pk = isTv ? `tv_${dl.tmdbId || dl.id}_s${dl.season || 1}e${dl.episode || 1}` : `movie_${dl.tmdbId || dl.id}`;
    const payload = {
      url: fileUrl,
      title: dl.title || "Offline Video",
      subtitle: isTv && dl.season != null ? `S${dl.season} · E${dl.episode}` : "Offline Download",
      isLocal: true,
      progressKey: pk,
      tmdbId: String(dl.tmdbId || dl.id || ""),
      mediaType: isTv ? "tv" : "movie",
      season: dl.season || 1,
      episode: dl.episode || 1
    };
    if (window.AndroidBridge?.openExoPlayer) {
      window.AndroidBridge.openExoPlayer(JSON.stringify(payload));
    } else {
      onOpenExoPlayer?.(payload);
    }
  }, [onOpenExoPlayer]);

  if (showAllSaved) {
    return React.createElement("div", { className: "nf-my-page" },
      React.createElement("div", { className: "nf-header-bar" },
        React.createElement("button", { className: "nf-icon-btn", onClick: () => setShowAllSaved(false) }, "‹"),
        React.createElement("h1", { style: { margin: 0, fontSize: 20, fontWeight: 700, flex: 1 } }, "My List")
      ),
      React.createElement("div", {
        style: { display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: 8, padding: "12px 16px" }
      },
        saved.map(item => React.createElement("button", {
          key: `all_${item.media_type}_${item.id}`,
          className: "nf-poster-btn card",
          style: { width: "100%" },
          onClick: () => onSelect(item)
        },
          React.createElement("img", { src: imgUrl(item.poster_path || item.backdrop_path, "w342"), alt: item.title || item.name, loading: "lazy" })
        ))
      )
    );
  }

  const profileName = activeProfile?.name || "Your SingularityTV";
  const initial = profileName.charAt(0).toUpperCase();

  return React.createElement("div", { className: "nf-my-page nf-pinned-page" },
    !isTvMode && React.createElement("div", { className: "nf-pinned-top" },
      React.createElement("div", { className: "nf-header-bar" },
        React.createElement("h1", { style: { margin: 0, fontSize: 26, fontWeight: 700, color: "#fff" } }, "My SingularityTV"),
        React.createElement("div", { className: "nf-header-actions" },
          React.createElement("button", { className: "nf-icon-btn", onClick: onSearch, "aria-label": "Search" }, React.createElement(SearchIcon)),
          React.createElement("button", { className: "nf-icon-btn", onClick: () => onSettings?.(), "aria-label": "Settings" },
            React.createElement("svg", { width: "22", height: "22", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round" },
              React.createElement("line", { x1: "3", y1: "6", x2: "21", y2: "6" }),
              React.createElement("line", { x1: "3", y1: "12", x2: "21", y2: "12" }),
              React.createElement("line", { x1: "3", y1: "18", x2: "21", y2: "18" })
            )
          )
        )
      )
    ),
    React.createElement("div", { className: "nf-pinned-scroll" },
    React.createElement("div", { style: { textAlign: "center", padding: "8px 16px 24px" } },
      React.createElement("button", {
        onClick: onOpenProfiles,
        style: { border: "none", background: "transparent", cursor: "pointer", padding: 0 }
      },
        React.createElement("div", {
          className: "nf-profile-square",
          style: { background: activeProfile?.avatarColor || "#e50914" }
        }, initial)
      ),
      React.createElement("div", { style: { fontSize: 19, fontWeight: 700, color: "#fff", marginTop: 10 } }, profileName),
      React.createElement("div", { style: { fontSize: 13, fontWeight: 500, color: "rgba(255,255,255,0.5)", marginTop: 4 } },
        `${saved.length} in My List · ${inProgress.length} in progress`
      )
    ),
    React.createElement("div", { className: "nf-rails-stack", style: { paddingTop: 0 } },
      inProgress.length > 0 && React.createElement("section", { className: "nf-row" },
        React.createElement("h2", { className: "nf-row-title" }, "Continue Watching"),
        React.createElement("div", { className: "nf-rail-scroller tv-scroll-row" },
          inProgress.map(item => {
            const pk = item.media_type === "movie" ? `movie_${item.id}` : `tv_${item.id}_s${item.season}e${item.episode}`;
            const pct = Math.min(100, Math.max(3, Number(progress[pk] || 6)));
            const epLabel = item.media_type === "tv" && item.season != null ? `S${item.season}:E${item.episode}` : "Resume";
            return React.createElement("div", { key: `mycw_${pk}`, className: "nf-continue-card card" },
              React.createElement("div", { className: "nf-continue-art", onClick: () => (onPlayDirect || onSelect)(item) },
                React.createElement("img", { src: imgUrl(item.poster_path || item.backdrop_path, "w342"), alt: item.title || item.name, loading: "lazy" }),
                React.createElement("div", { className: "nf-continue-play-ring" }, React.createElement(PlayIcon, { size: 17 })),
                React.createElement("div", { className: "nf-progress-track" },
                  React.createElement("div", { className: "nf-progress-fill", style: { width: `${pct}%` } })
                )
              ),
              React.createElement("div", { className: "nf-continue-footer" },
                React.createElement("span", { style: { width: 28 } }),
                React.createElement("span", { className: "nf-continue-ep" }, epLabel),
                React.createElement("button", { onClick: () => onRemoveHistory?.(item), "aria-label": "Remove" }, React.createElement(CloseIcon, { size: 14 }))
              )
            );
          })
        )
      ),
      React.createElement("section", { className: "nf-row" },
        React.createElement("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", padding: "0 16px" } },
          React.createElement("h2", { className: "nf-row-title", style: { padding: 0 } }, "My List"),
          saved.length > 4 && React.createElement("button", {
            onClick: () => setShowAllSaved(true),
            style: { border: "none", background: "transparent", color: "rgba(255,255,255,0.72)", fontSize: 14, fontWeight: 600, cursor: "pointer" }
          }, "See All ›")
        ),
        saved.length === 0
          ? React.createElement("div", { style: { padding: "0 16px", fontSize: 14, color: "rgba(255,255,255,0.5)" } }, "Tap + on any title to save it here.")
          : React.createElement("div", { className: "nf-rail-scroller tv-scroll-row" },
              saved.map(item => React.createElement("button", {
                key: `mysv_${item.media_type}_${item.id}`,
                className: "nf-poster-btn card",
                onClick: () => onSelect(item)
              },
                React.createElement("img", { src: imgUrl(item.poster_path || item.backdrop_path, "w342"), alt: item.title || item.name, loading: "lazy" })
              ))
            )
      ),
      offlineDownloads.length > 0 && React.createElement("section", { className: "nf-row" },
        React.createElement("h2", { className: "nf-row-title" }, "Downloads"),
        React.createElement("div", { className: "nf-rail-scroller tv-scroll-row" },
          offlineDownloads.map(dl => React.createElement("button", {
            key: `dl_${dl.id}`,
            className: "nf-poster-btn card",
            onClick: () => playOfflineDownload(dl)
          },
            dl.posterPath
              ? React.createElement("img", { src: imgUrl(dl.posterPath, "w342"), alt: dl.title, loading: "lazy" })
              : React.createElement("div", { style: { width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", color: "#fff" } }, React.createElement(DownloadIcon))
          ))
        )
      ),
      history.length > 0 && React.createElement("section", { className: "nf-row" },
        React.createElement("h2", { className: "nf-row-title" }, "Recently Watched"),
        history.slice(0, 15).map((entry, idx) => React.createElement("div", {
          key: `hist_${entry.media_type}_${entry.id}_${idx}`,
          className: "nf-my-history-row"
        },
          React.createElement("img", {
            src: imgUrl(entry.poster_path || entry.backdrop_path, "w185"),
            alt: entry.title || entry.name,
            className: "nf-my-history-thumb",
            onClick: () => onSelect(entry)
          }),
          React.createElement("div", { style: { flex: 1, minWidth: 0 }, onClick: () => onSelect(entry) },
            React.createElement("div", { style: { fontSize: 15, fontWeight: 600, color: "#fff", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" } }, entry.title || entry.name),
            React.createElement("div", { style: { fontSize: 12.5, color: "rgba(255,255,255,0.65)", marginTop: 2 } },
              entry.media_type === "tv" && entry.season != null ? `S${entry.season}:E${entry.episode}` : "Film"
            )
          ),
          React.createElement("button", {
            className: "nf-my-play-circle",
            onClick: () => (onPlayDirect || onSelect)(entry),
            "aria-label": "Play"
          }, React.createElement(PlayIcon, { size: 13 }))
        ))
      ),
      React.createElement("div", { style: { padding: "4px 16px 12px" } },
        React.createElement("button", {
          onClick: () => onSettings?.(),
          style: {
            width: "100%",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            padding: 14,
            borderRadius: 10,
            border: "none",
            background: "#1c1c1e",
            color: "#ffffff",
            cursor: "pointer"
          }
        },
          React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 12 } },
            React.createElement("span", { style: { width: 36, height: 36, borderRadius: "50%", background: "#2b2b2e", display: "inline-flex", alignItems: "center", justifyContent: "center" } }, React.createElement(SettingsIcon)),
            React.createElement("div", { style: { textAlign: "left" } },
              React.createElement("div", { style: { fontSize: 15, fontWeight: 600 } }, "App Settings"),
              React.createElement("div", { style: { fontSize: 12.5, color: "rgba(255,255,255,0.5)" } }, "Profiles, accent colour, playback, sync")
            )
          ),
          React.createElement("span", { style: { color: "rgba(255,255,255,0.5)", fontSize: 18 } }, "›")
        )
      )
    )
    )
  );
}
