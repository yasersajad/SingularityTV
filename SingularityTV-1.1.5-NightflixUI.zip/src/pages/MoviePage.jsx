import React, { useState, useEffect, useCallback, useMemo } from "react";
import { tmdbFetch, imgUrl } from "../utils/api";
import { storage } from "../utils/storage";
import { PlayIcon, CloseIcon, BackIcon } from "../components/Icons";
import TrailerModal from "../components/TrailerModal";

function formatRuntime(mins) {
  const m = Number(mins || 0);
  if (m <= 0) return "";
  const h = Math.floor(m / 60);
  const rem = m % 60;
  return h > 0 ? `${h}h ${rem > 0 ? rem + "m" : ""}`.trim() : `${rem}m`;
}

function PlusSvg() {
  return React.createElement("svg", { width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.2", strokeLinecap: "round" },
    React.createElement("line", { x1: "12", y1: "5", x2: "12", y2: "19" }),
    React.createElement("line", { x1: "5", y1: "12", x2: "19", y2: "12" })
  );
}

function CheckSvg() {
  return React.createElement("svg", { width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.4", strokeLinecap: "round", strokeLinejoin: "round" },
    React.createElement("polyline", { points: "20 6 9 17 4 12" })
  );
}

function ThumbSvg({ filled }) {
  return React.createElement("svg", { width: "20", height: "20", viewBox: "0 0 24 24", fill: filled ? "currentColor" : "none", stroke: "currentColor", strokeWidth: "1.9", strokeLinecap: "round", strokeLinejoin: "round" },
    React.createElement("path", { d: "M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3" })
  );
}

function ShareSvg() {
  return React.createElement("svg", { width: "20", height: "20", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "1.9", strokeLinecap: "round", strokeLinejoin: "round" },
    React.createElement("line", { x1: "22", y1: "2", x2: "11", y2: "13" }),
    React.createElement("polygon", { points: "22 2 15 22 11 13 2 9 22 2" })
  );
}

export default function MoviePage({
  item,
  apiKey,
  onSave,
  isSaved,
  onHistory,
  progress = {},
  saveProgress,
  onBack,
  watched = {},
  onMarkUnwatched,
  onSelect,
  onOpenExoPlayer
}) {
  const [details, setDetails] = useState(null);
  const [logoPath, setLogoPath] = useState(null);
  const [videos, setVideos] = useState([]);
  const [similar, setSimilar] = useState([]);
  const [credits, setCredits] = useState(null);
  const [cert, setCert] = useState("");
  const [activeTab, setActiveTab] = useState("more");
  const [expanded, setExpanded] = useState(false);
  const [liked, setLiked] = useState(false);
  const [showTrailer, setShowTrailer] = useState(false);
  const [activeTrailerKey, setActiveTrailerKey] = useState(null);
  const [barOpacity, setBarOpacity] = useState(0);

  const progressKey = `movie_${item.id}`;
  const pct = Number(progress[progressKey] || 0);
  const isWatched = !!watched[progressKey];

  useEffect(() => {
    let mounted = true;
    setDetails(null);
    setLogoPath(null);
    setVideos([]);
    setSimilar([]);
    setCredits(null);
    setCert("");
    setActiveTab("more");
    setExpanded(false);

    Promise.all([
      tmdbFetch(`/movie/${item.id}?append_to_response=credits,recommendations,similar,videos,release_dates,images&include_image_language=en,null`, apiKey).catch(() => null),
      tmdbFetch(`/movie/${item.id}/videos?language=en-US`, apiKey).catch(() => ({ results: [] }))
    ]).then(([data, enVids]) => {
      if (!mounted || !data) return;
      setDetails(data);
      setCredits(data.credits || null);

      const logos = data.images?.logos || [];
      const pickLogo = logos.find(l => l.iso_639_1 === "en" && !String(l.file_path || "").endsWith(".svg")) || logos[0];
      setLogoPath(pickLogo?.file_path || null);

      const rels = data.release_dates?.results || [];
      const prefRel = rels.find(r => r.iso_3166_1 === "US") || rels.find(r => r.iso_3166_1 === "GB") || rels[0];
      const certVal = prefRel?.release_dates?.map(x => x.certification).find(Boolean) || "";
      setCert(certVal);

      const allVids = [...(enVids?.results || []), ...(data.videos?.results || [])];
      const seenV = new Set();
      const ytVids = allVids
        .filter(v => v && v.key && v.site === "YouTube" && !seenV.has(v.key) && seenV.add(v.key))
        .sort((a, b) => ((b.type === "Trailer" ? 4 : 0) + (b.official ? 2 : 0)) - ((a.type === "Trailer" ? 4 : 0) + (a.official ? 2 : 0)));
      setVideos(ytVids);

      const rec = data.recommendations?.results || [];
      const sim = data.similar?.results || [];
      const seenS = new Set([String(item.id)]);
      const mergedSim = [...rec, ...sim]
        .filter(x => x && x.id && x.poster_path && !seenS.has(String(x.id)) && seenS.add(String(x.id)))
        .slice(0, 18)
        .map(x => ({ ...x, media_type: "movie" }));
      setSimilar(mergedSim);
    });

    return () => { mounted = false; };
  }, [item.id, apiKey]);

  useEffect(() => {
    const onScroll = () => {
      const scroller = document.querySelector(".main--full");
      const y = Math.max(window.scrollY || 0, scroller ? scroller.scrollTop : 0);
      setBarOpacity(Math.min(1, Math.max(0, (y - 160) / 50)));
    };
    window.addEventListener("scroll", onScroll, { passive: true, capture: true });
    return () => window.removeEventListener("scroll", onScroll, true);
  }, []);

  const d = details || item;
  const title = d.title || d.name || "Untitled";
  const year = (d.release_date || "").slice(0, 4);
  const runtime = formatRuntime(d.runtime);
  const score = Number(d.vote_average || 0) > 0 ? Math.round(Number(d.vote_average) * 10) : null;
  const backdrop = imgUrl(d.backdrop_path || d.poster_path, "w1280");
  const primaryTrailer = videos.find(v => v.type === "Trailer") || videos[0] || null;

  const castLine = useMemo(() => {
    const c = (credits?.cast || []).slice(0, 3).map(p => p.name).filter(Boolean);
    return c.length ? c.join(", ") + ((credits?.cast?.length || 0) > 3 ? ", more" : "") : "";
  }, [credits]);

  const directorLine = useMemo(() => {
    const dirs = (credits?.crew || []).filter(p => p.job === "Director").map(p => p.name).filter(Boolean);
    return dirs.slice(0, 2).join(", ");
  }, [credits]);

  const handlePlay = useCallback(() => {
    if (isWatched || pct >= 92) {
      onMarkUnwatched?.(progressKey);
      saveProgress?.(progressKey, 0);
      storage.set("dlTime_" + progressKey, 0);
    }
    const startSec = isWatched || pct >= 92 ? 0 : Number(storage.get("dlTime_" + progressKey) || 0);
    const tmdbVal = String(d.numeric_id || d.id || item.id || "");
    const payload = {
      url: "",
      title: title,
      startTimeSec: startSec,
      startPositionSec: startSec,
      progressKey: progressKey,
      tmdbId: tmdbVal,
      mediaType: "movie"
    };
    onHistory?.({ ...d, media_type: "movie" });
    if (window.AndroidBridge?.openExoPlayer) {
      window.AndroidBridge.openExoPlayer(JSON.stringify(payload));
    } else {
      onOpenExoPlayer?.(payload);
    }
  }, [d, item.id, title, isWatched, pct, progressKey, onHistory, onMarkUnwatched, saveProgress, onOpenExoPlayer]);

  const openTrailer = key => {
    setActiveTrailerKey(key || primaryTrailer?.key || null);
    setShowTrailer(true);
  };

  return React.createElement("div", { className: "nf-detail-page" },
    React.createElement("div", {
      className: "nf-detail-top-controls",
      style: {
        background: `rgba(0,0,0,${barOpacity})`,
        borderBottom: barOpacity > 0.5 ? "0.5px solid rgba(255,255,255,0.1)" : "none"
      }
    },
      React.createElement("button", { className: "nf-round-btn", onClick: onBack, "aria-label": "Back" }, React.createElement(BackIcon, { size: 18 })),
      React.createElement("div", {
        style: {
          flex: 1, textAlign: "center", fontSize: 16, fontWeight: 600, color: "#fff",
          opacity: barOpacity, padding: "0 16px", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis"
        }
      }, title),
      React.createElement("button", { className: "nf-round-btn", onClick: onBack, "aria-label": "Close" }, React.createElement(CloseIcon, { size: 15 }))
    ),

    React.createElement("div", {
      className: "nf-detail-hero",
      onClick: () => primaryTrailer && openTrailer(primaryTrailer.key)
    },
      backdrop && React.createElement("img", { src: backdrop, alt: title }),
      React.createElement("div", { className: "nf-detail-hero-overlay" }),
      primaryTrailer && React.createElement("button", {
        onClick: e => { e.stopPropagation(); openTrailer(primaryTrailer.key); },
        style: {
          position: "absolute", left: 12, bottom: 12, border: "none",
          background: "rgba(0,0,0,0.62)", color: "#fff", borderRadius: 999,
          padding: "6px 12px", fontSize: 12, fontWeight: 600,
          display: "inline-flex", alignItems: "center", gap: 6, cursor: "pointer"
        }
      }, React.createElement(PlayIcon, { size: 10 }), "Preview")
    ),

    React.createElement("div", { className: "nf-detail-body" },
      logoPath
        ? React.createElement("img", { src: imgUrl(logoPath, "w500"), alt: title, style: { maxWidth: "66%", maxHeight: 74, objectFit: "contain", display: "block" } })
        : React.createElement("h1", { style: { margin: 0, fontSize: 28, fontWeight: 900, letterSpacing: "-0.02em", color: "#fff" } }, title),

      React.createElement("div", { className: "nf-meta-line", style: { marginTop: 12, fontSize: 13.5 } },
        score && React.createElement("span", { className: "nf-score-green" }, `${score}% rating`),
        year && React.createElement("span", null, year),
        cert && React.createElement("span", { className: "nf-cert-box" }, cert),
        runtime && React.createElement("span", null, runtime)
      ),

      React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: 8, marginTop: 14 } },
        React.createElement("button", { className: "nf-btn-primary", style: { height: 42 }, onClick: handlePlay },
          React.createElement(PlayIcon, { size: 16 }),
          React.createElement("span", null, pct > 2 && pct < 92 ? "Resume" : "Play")
        ),
        primaryTrailer && React.createElement("button", { className: "nf-btn-secondary", style: { height: 42 }, onClick: () => openTrailer(primaryTrailer.key) },
          React.createElement("span", null, "Trailer")
        )
      ),

      pct > 2 && pct < 95 && React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 10, marginTop: 12 } },
        React.createElement("div", { style: { width: 150, height: 3, background: "rgba(255,255,255,0.25)", borderRadius: 2, overflow: "hidden" } },
          React.createElement("div", { style: { width: `${pct}%`, height: "100%", background: "#e50914" } })
        ),
        React.createElement("span", { style: { fontSize: 12, color: "rgba(255,255,255,0.72)" } }, `${pct}% watched`)
      ),

      d.overview && React.createElement("p", {
        onClick: () => setExpanded(e => !e),
        style: {
          margin: "14px 0 0", fontSize: 14.5, lineHeight: 1.5, color: "#fff", cursor: "pointer",
          display: expanded ? "block" : "-webkit-box", WebkitLineClamp: expanded ? "unset" : 4, WebkitBoxOrient: "vertical", overflow: "hidden"
        }
      }, d.overview),

      React.createElement("div", { style: { marginTop: 10, display: "flex", flexDirection: "column", gap: 4, fontSize: 12.5 } },
        castLine && React.createElement("div", null,
          React.createElement("span", { style: { color: "rgba(255,255,255,0.5)" } }, "Starring: "),
          React.createElement("span", { style: { color: "rgba(255,255,255,0.75)" } }, castLine)
        ),
        directorLine && React.createElement("div", null,
          React.createElement("span", { style: { color: "rgba(255,255,255,0.5)" } }, "Director: "),
          React.createElement("span", { style: { color: "rgba(255,255,255,0.75)" } }, directorLine)
        )
      ),

      React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 28, marginTop: 20 } },
        React.createElement("button", { className: "nf-icon-action", onClick: onSave },
          isSaved ? React.createElement(CheckSvg) : React.createElement(PlusSvg),
          React.createElement("span", null, "My List")
        ),
        React.createElement("button", { className: "nf-icon-action", onClick: () => setLiked(l => !l) },
          React.createElement(ThumbSvg, { filled: liked }),
          React.createElement("span", null, liked ? "Rated" : "Rate")
        ),
        React.createElement("button", {
          className: "nf-icon-action",
          onClick: () => { try { navigator.share?.({ title, url: `https://www.themoviedb.org/movie/${item.id}` }); } catch {} }
        },
          React.createElement(ShareSvg),
          React.createElement("span", null, "Share")
        )
      ),

      React.createElement("div", { className: "nf-detail-tabs" },
        React.createElement("button", {
          className: `nf-detail-tab${activeTab === "more" ? " active" : ""}`,
          onClick: () => setActiveTab("more")
        },
          React.createElement("div", { className: "nf-detail-tab-bar" }),
          React.createElement("span", { className: "nf-detail-tab-label" }, "More Like This")
        ),
        videos.length > 0 && React.createElement("button", {
          className: `nf-detail-tab${activeTab === "trailers" ? " active" : ""}`,
          onClick: () => setActiveTab("trailers")
        },
          React.createElement("div", { className: "nf-detail-tab-bar" }),
          React.createElement("span", { className: "nf-detail-tab-label" }, "Trailers & More")
        )
      ),

      activeTab === "more" && React.createElement("div", {
        style: { display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: 8, marginTop: 16 }
      },
        similar.map(s => React.createElement("button", {
          key: `sim_${s.id}`,
          className: "nf-poster-btn card",
          style: { width: "100%" },
          onClick: () => onSelect?.(s)
        },
          React.createElement("img", { src: imgUrl(s.poster_path, "w342"), alt: s.title || s.name, loading: "lazy" })
        ))
      ),

      activeTab === "trailers" && React.createElement("div", { style: { display: "flex", flexDirection: "column", gap: 18, marginTop: 16 } },
        videos.slice(0, 10).map(v => React.createElement("div", {
          key: v.key,
          style: { cursor: "pointer" },
          onClick: () => openTrailer(v.key)
        },
          React.createElement("div", { style: { position: "relative", width: "100%", aspectRatio: "16 / 9", borderRadius: 4, overflow: "hidden", background: "#1c1c1e" } },
            React.createElement("img", { src: `https://img.youtube.com/vi/${v.key}/hqdefault.jpg`, alt: v.name, style: { width: "100%", height: "100%", objectFit: "cover" }, loading: "lazy" }),
            React.createElement("div", { className: "nf-continue-play-ring" }, React.createElement(PlayIcon, { size: 16 }))
          ),
          React.createElement("div", { style: { fontSize: 14, fontWeight: 600, color: "#fff", marginTop: 8 } }, v.name),
          React.createElement("div", { style: { fontSize: 12, color: "rgba(255,255,255,0.5)", marginTop: 2 } }, v.type)
        ))
      )
    ),

    showTrailer && React.createElement(TrailerModal, {
      trailerKey: activeTrailerKey,
      title: title,
      mediaId: item.id,
      mediaType: "movie",
      apiKey: apiKey,
      onClose: () => setShowTrailer(false)
    })
  );
}
