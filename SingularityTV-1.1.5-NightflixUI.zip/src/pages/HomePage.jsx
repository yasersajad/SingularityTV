import React, { useState, useEffect, useMemo, useCallback } from "react";
import { tmdbFetch, imgUrl } from "../utils/api";
import { getActiveProfile } from "../utils/supabaseSync";
import { PlayIcon, SearchIcon, CloseIcon, WifiOffIcon } from "../components/Icons";

const NF_GENRE_NAMES = {
  28: "Action", 12: "Adventure", 16: "Animation", 35: "Comedy", 80: "Crime",
  99: "Documentary", 18: "Drama", 10751: "Family", 14: "Fantasy", 36: "History",
  27: "Horror", 10402: "Music", 9648: "Mystery", 10749: "Romance", 878: "Sci-Fi",
  10770: "TV Movie", 53: "Thriller", 10752: "War", 37: "Western",
  10759: "Action & Adventure", 10762: "Kids", 10764: "Reality", 10765: "Sci-Fi & Fantasy",
  10768: "War & Politics"
};

const NF_CATEGORIES = [
  { id: "action", name: "Action", movie: "28", tv: "10759" },
  { id: "adventure", name: "Adventure", movie: "12", tv: "10759" },
  { id: "animation", name: "Animation", movie: "16", tv: "16" },
  { id: "comedy", name: "Comedy", movie: "35", tv: "35" },
  { id: "crime", name: "Crime", movie: "80", tv: "80" },
  { id: "documentary", name: "Documentaries", movie: "99", tv: "99" },
  { id: "drama", name: "Drama", movie: "18", tv: "18" },
  { id: "family", name: "Family", movie: "10751", tv: "10751" },
  { id: "fantasy", name: "Fantasy", movie: "14", tv: "10765" },
  { id: "history", name: "History", movie: "36", tv: null },
  { id: "horror", name: "Horror", movie: "27", tv: null },
  { id: "kids", name: "Kids", movie: "10751|16", tv: "10762" },
  { id: "music", name: "Music", movie: "10402", tv: null },
  { id: "mystery", name: "Mystery", movie: "9648", tv: "9648" },
  { id: "reality", name: "Reality", movie: null, tv: "10764" },
  { id: "romance", name: "Romance", movie: "10749", tv: null },
  { id: "scifi", name: "Sci-Fi", movie: "878", tv: "10765" },
  { id: "thriller", name: "Thrillers", movie: "53", tv: "80|9648" },
  { id: "war", name: "War", movie: "10752", tv: "10768" },
  { id: "western", name: "Westerns", movie: "37", tv: "37" }
];

function getGenreTags(item) {
  if (Array.isArray(item?.genres) && item.genres.length > 0) {
    return item.genres.slice(0, 3).map(g => g.name).filter(Boolean);
  }
  const ids = Array.isArray(item?.genre_ids) ? item.genre_ids : [];
  return ids.map(id => NF_GENRE_NAMES[id]).filter(Boolean).slice(0, 3);
}

function getItemYear(item) {
  const d = item?.release_date || item?.first_air_date || "";
  return d.length >= 4 ? d.slice(0, 4) : "";
}

function isRecentRelease(item) {
  const raw = item?.release_date || item?.first_air_date;
  if (!raw) return false;
  const ts = Date.parse(raw);
  if (isNaN(ts)) return false;
  const now = Date.now();
  return ts <= now && ts > now - 35 * 24 * 60 * 60 * 1000;
}

function PlusSvg() {
  return React.createElement("svg", { width: "17", height: "17", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.4", strokeLinecap: "round" },
    React.createElement("line", { x1: "12", y1: "5", x2: "12", y2: "19" }),
    React.createElement("line", { x1: "5", y1: "12", x2: "19", y2: "12" })
  );
}

function CheckSvg() {
  return React.createElement("svg", { width: "17", height: "17", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.6", strokeLinecap: "round", strokeLinejoin: "round" },
    React.createElement("polyline", { points: "20 6 9 17 4 12" })
  );
}

function InfoSvg() {
  return React.createElement("svg", { width: "17", height: "17", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2", strokeLinecap: "round", strokeLinejoin: "round" },
    React.createElement("circle", { cx: "12", cy: "12", r: "10" }),
    React.createElement("line", { x1: "12", y1: "16", x2: "12", y2: "12" }),
    React.createElement("line", { x1: "12", y1: "8", x2: "12.01", y2: "8" })
  );
}

function ChevronRightSvg() {
  return React.createElement("svg", { width: "14", height: "14", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", strokeWidth: "2.4", strokeLinecap: "round", strokeLinejoin: "round" },
    React.createElement("polyline", { points: "9 18 15 12 9 6" })
  );
}

function NFPreviewSheet({ item, isSaved, onToggleSave, onPlay, onDetails, onClose }) {
  if (!item) return null;
  const title = item.title || item.name || "Untitled";
  const year = getItemYear(item);
  const score = Number(item.vote_average || 0) > 0 ? Math.round(Number(item.vote_average) * 10) : null;
  const poster = imgUrl(item.poster_path || item.backdrop_path, "w342");
  const isTv = item.media_type === "tv" || (!item.title && !!item.name);

  return React.createElement("div", {
    className: "nf-sheet-backdrop",
    onClick: onClose
  },
    React.createElement("div", {
      className: "nf-preview-sheet",
      onClick: e => e.stopPropagation()
    },
      React.createElement("div", { className: "nf-preview-top" },
        poster && React.createElement("img", {
          src: poster,
          alt: title,
          className: "nf-preview-poster",
          onClick: () => { onClose(); onDetails(item); }
        }),
        React.createElement("div", { className: "nf-preview-meta-col" },
          React.createElement("h3", { className: "nf-preview-title" }, title),
          React.createElement("div", { className: "nf-meta-line" },
            year && React.createElement("span", null, year),
            React.createElement("span", null, isTv ? "Series" : "Film"),
            score && React.createElement("span", { className: "nf-score-green" }, `${score}%`)
          ),
          React.createElement("p", { className: "nf-preview-overview" }, item.overview || "Tap Details & More to view full synopsis and cast.")
        ),
        React.createElement("button", {
          className: "nf-sheet-close",
          onClick: onClose,
          "aria-label": "Close"
        }, React.createElement(CloseIcon, { size: 13 }))
      ),
      React.createElement("div", { className: "nf-preview-actions" },
        React.createElement("button", {
          className: "nf-btn-primary",
          onClick: () => { onClose(); onPlay(item); }
        },
          React.createElement(PlayIcon, { size: 15 }),
          React.createElement("span", null, "Play")
        ),
        React.createElement("button", {
          className: "nf-icon-action",
          onClick: () => onToggleSave?.(item)
        },
          isSaved ? React.createElement(CheckSvg) : React.createElement(PlusSvg),
          React.createElement("span", null, "My List")
        )
      ),
      React.createElement("div", { className: "nf-sheet-divider" }),
      React.createElement("button", {
        className: "nf-sheet-details-btn",
        onClick: () => { onClose(); onDetails(item); }
      },
        React.createElement("span", { style: { display: "inline-flex", alignItems: "center", gap: 10 } },
          React.createElement(InfoSvg),
          React.createElement("span", null, isTv ? "Episodes & Info" : "Details & More")
        ),
        React.createElement(ChevronRightSvg)
      )
    )
  );
}

function NFCategoryPicker({ scope, selectedId, onSelect, onClose }) {
  const supported = NF_CATEGORIES.filter(c => scope === "all" ? true : scope === "series" ? !!c.tv : !!c.movie);
  const homeTitle = scope === "all" ? "Home" : scope === "series" ? "All Series" : "All Films";

  return React.createElement("div", {
    className: "nf-picker-overlay",
    onClick: onClose
  },
    React.createElement("div", {
      className: "nf-picker-list",
      onClick: e => e.stopPropagation()
    },
      React.createElement("button", {
        className: `nf-picker-opt${!selectedId ? " selected" : ""}`,
        onClick: () => { onSelect(null); onClose(); }
      }, homeTitle),
      supported.map(cat => React.createElement("button", {
        key: cat.id,
        className: `nf-picker-opt${selectedId === cat.id ? " selected" : ""}`,
        onClick: () => { onSelect(cat); onClose(); }
      }, cat.name))
    ),
    React.createElement("button", {
      className: "nf-picker-close",
      onClick: onClose,
      "aria-label": "Close"
    }, React.createElement(CloseIcon, { size: 22 }))
  );
}

function NFNewHotFeed({ apiKey, onSelect, onOpenPreview, onToggleSave, isSavedFn, onSearch, isTvMode }) {
  const [section, setSection] = useState("comingSoon");
  const [comingSoon, setComingSoon] = useState([]);
  const [everyone, setEveryone] = useState([]);
  const [topSeries, setTopSeries] = useState([]);
  const [topFilms, setTopFilms] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let mounted = true;
    setLoading(true);
    Promise.all([
      tmdbFetch("/movie/upcoming?page=1", apiKey).catch(() => ({ results: [] })),
      tmdbFetch("/trending/all/day?page=1", apiKey).catch(() => ({ results: [] })),
      tmdbFetch("/trending/tv/day?page=1", apiKey).catch(() => ({ results: [] })),
      tmdbFetch("/trending/movie/day?page=1", apiKey).catch(() => ({ results: [] }))
    ]).then(([up, tr, tv, mv]) => {
      if (!mounted) return;
      setComingSoon((up?.results || []).filter(x => x.backdrop_path).slice(0, 14).map(x => ({ ...x, media_type: "movie" })));
      setEveryone((tr?.results || []).filter(x => x.backdrop_path && (x.media_type === "movie" || x.media_type === "tv")).slice(0, 12));
      setTopSeries((tv?.results || []).filter(x => x.backdrop_path).slice(0, 10).map(x => ({ ...x, media_type: "tv" })));
      setTopFilms((mv?.results || []).filter(x => x.backdrop_path).slice(0, 10).map(x => ({ ...x, media_type: "movie" })));
    }).finally(() => { if (mounted) setLoading(false); });
    return () => { mounted = false; };
  }, [apiKey]);

  const tabs = [
    { id: "comingSoon", label: "Coming Soon" },
    { id: "everyone", label: "Everyone's Watching" },
    { id: "topSeries", label: "Top 10 Series" },
    { id: "topFilms", label: "Top 10 Films" }
  ];

  const list = section === "comingSoon" ? comingSoon : section === "everyone" ? everyone : section === "topSeries" ? topSeries : topFilms;

  return React.createElement("div", { className: "nf-newhot-page" },
    !isTvMode && React.createElement("div", { className: "nf-header-bar" },
      React.createElement("h1", { style: { margin: 0, fontSize: 26, fontWeight: 700, color: "#fff" } }, "New & Hot"),
      React.createElement("button", { className: "nf-icon-btn", onClick: onSearch, "aria-label": "Search" }, React.createElement(SearchIcon))
    ),
    React.createElement("div", { className: "nf-newhot-chips" },
      tabs.map(t => React.createElement("button", {
        key: t.id,
        className: `nf-newhot-chip${section === t.id ? " active" : ""}`,
        onClick: () => setSection(t.id)
      }, t.label))
    ),
    loading ? React.createElement("div", { className: "loader", style: { padding: 48 } }, React.createElement("div", { className: "spinner" })) :
      list.map((item, idx) => {
        const title = item.title || item.name;
        const art = imgUrl(item.backdrop_path || item.poster_path, "w780");
        const tags = getGenreTags(item);
        const saved = isSavedFn?.(item);
        const isRanked = section === "topSeries" || section === "topFilms";
        const rd = item.release_date ? new Date(item.release_date) : null;
        const mon = rd && !isNaN(rd) ? rd.toLocaleString("en-US", { month: "short" }).toUpperCase() : "SOON";
        const day = rd && !isNaN(rd) ? rd.getDate() : "•";

        return React.createElement("div", { key: `${section}_${item.media_type}_${item.id}`, className: "nf-newhot-card" },
          (section === "comingSoon" || isRanked) && React.createElement("div", { className: "nf-newhot-rail-col" },
            isRanked
              ? React.createElement("div", { style: { fontSize: 32, fontWeight: 900, lineHeight: 1, color: "#fff" } }, idx + 1)
              : React.createElement(React.Fragment, null,
                  React.createElement("div", { style: { fontSize: 12, fontWeight: 600, color: "rgba(255,255,255,0.68)" } }, mon),
                  React.createElement("div", { style: { fontSize: 28, fontWeight: 800, lineHeight: 1.05, color: "#fff" } }, day)
                )
          ),
          React.createElement("div", { className: "nf-newhot-main" },
            art && React.createElement("img", {
              src: art,
              alt: title,
              className: "nf-newhot-art",
              onClick: () => isTvMode ? onSelect(item) : onOpenPreview(item)
            }),
            React.createElement("div", { style: { display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8 } },
              React.createElement("div", { style: { fontSize: 18, fontWeight: 800, color: "#fff", lineHeight: 1.2 } }, title),
              React.createElement("div", { style: { display: "flex", alignItems: "center", gap: 4 } },
                React.createElement("button", { className: "nf-icon-action", onClick: () => onToggleSave?.(item) },
                  saved ? React.createElement(CheckSvg) : React.createElement(PlusSvg),
                  React.createElement("span", null, "My List")
                ),
                React.createElement("button", { className: "nf-icon-action", onClick: () => onSelect(item) },
                  React.createElement(PlayIcon, { size: 16 }),
                  React.createElement("span", null, "Play")
                )
              )
            ),
            item.overview && React.createElement("p", {
              style: { margin: 0, fontSize: 13.5, lineHeight: 1.45, color: "rgba(255,255,255,0.72)", display: "-webkit-box", WebkitLineClamp: 3, WebkitBoxOrient: "vertical", overflow: "hidden" }
            }, item.overview),
            tags.length > 0 && React.createElement("div", { style: { fontSize: 12.5, fontWeight: 500, color: "#fff" } }, tags.join("  •  "))
          )
        );
      })
  );
}

export default function HomePage({
  trending = [],
  trendingTV = [],
  loading,
  onSelect,
  progress = {},
  inProgress = [],
  offline,
  onRetry,
  history = [],
  savedList = [],
  onToggleSave,
  isSavedFn,
  activeFilter = "all",
  isTvMode = false,
  apiKey,
  onSearch,
  onOpenProfiles,
  onRemoveHistory
}) {
  const [scope, setScope] = useState("all");
  const [category, setCategory] = useState(null);
  const [showPicker, setShowPicker] = useState(false);
  const [previewItem, setPreviewItem] = useState(null);
  const [headerOpacity, setHeaderOpacity] = useState(0);
  const [heroLogoPath, setHeroLogoPath] = useState(null);
  const [rowsData, setRowsData] = useState({});
  const [becauseItems, setBecauseItems] = useState([]);
  const [becauseTitle, setBecauseTitle] = useState("");
  const [activeProfile, setActiveProfile] = useState(() => getActiveProfile());

  useEffect(() => {
    const sync = () => setActiveProfile(getActiveProfile());
    window.addEventListener("singularity:profile-changed", sync);
    return () => window.removeEventListener("singularity:profile-changed", sync);
  }, []);

  useEffect(() => {
    if (activeFilter === "tv") { setScope("series"); setCategory(null); }
    else if (activeFilter === "movies") { setScope("films"); setCategory(null); }
    else if (activeFilter === "all") { setScope("all"); }
  }, [activeFilter]);

  useEffect(() => {
    const onScroll = () => {
      const scroller = document.querySelector(".main--full");
      const y = Math.max(window.scrollY || 0, scroller ? scroller.scrollTop : 0);
      setHeaderOpacity(Math.min(1, Math.max(0, (y - 8) / 70)));
    };
    window.addEventListener("scroll", onScroll, { passive: true, capture: true });
    return () => window.removeEventListener("scroll", onScroll, true);
  }, []);

  useEffect(() => {
    if (offline) return;
    let mounted = true;
    const reqs = [];
    if (category) {
      const mG = scope === "series" ? null : category.movie;
      const tG = scope === "films" ? null : category.tv;
      if (mG) {
        reqs.push(tmdbFetch(`/discover/movie?with_genres=${mG}&sort_by=popularity.desc&vote_count.gte=150`, apiKey).then(d => ["cat_pop_m", (d?.results || []).map(x => ({ ...x, media_type: "movie" }))]).catch(() => ["cat_pop_m", []]));
        reqs.push(tmdbFetch(`/discover/movie?with_genres=${mG}&sort_by=vote_average.desc&vote_count.gte=500`, apiKey).then(d => ["cat_top_m", (d?.results || []).map(x => ({ ...x, media_type: "movie" }))]).catch(() => ["cat_top_m", []]));
      }
      if (tG) {
        reqs.push(tmdbFetch(`/discover/tv?with_genres=${tG}&sort_by=popularity.desc&vote_count.gte=60`, apiKey).then(d => ["cat_pop_t", (d?.results || []).map(x => ({ ...x, media_type: "tv" }))]).catch(() => ["cat_pop_t", []]));
        reqs.push(tmdbFetch(`/discover/tv?with_genres=${tG}&sort_by=vote_average.desc&vote_count.gte=250`, apiKey).then(d => ["cat_top_t", (d?.results || []).map(x => ({ ...x, media_type: "tv" }))]).catch(() => ["cat_top_t", []]));
      }
    } else {
      reqs.push(
        tmdbFetch("/movie/now_playing?page=1", apiKey).then(d => ["nowPlaying", (d?.results || []).map(x => ({ ...x, media_type: "movie" }))]).catch(() => ["nowPlaying", []]),
        tmdbFetch("/tv/on_the_air?page=1", apiKey).then(d => ["onTheAir", (d?.results || []).map(x => ({ ...x, media_type: "tv" }))]).catch(() => ["onTheAir", []]),
        tmdbFetch("/movie/popular?page=1", apiKey).then(d => ["popMovies", (d?.results || []).map(x => ({ ...x, media_type: "movie" }))]).catch(() => ["popMovies", []]),
        tmdbFetch("/discover/tv?sort_by=popularity.desc&vote_count.gte=200", apiKey).then(d => ["popSeries", (d?.results || []).map(x => ({ ...x, media_type: "tv" }))]).catch(() => ["popSeries", []]),
        tmdbFetch("/discover/movie?with_genres=28|12&sort_by=popularity.desc&vote_count.gte=300", apiKey).then(d => ["action", (d?.results || []).map(x => ({ ...x, media_type: "movie" }))]).catch(() => ["action", []]),
        tmdbFetch("/discover/movie?with_genres=35&sort_by=popularity.desc&vote_count.gte=300", apiKey).then(d => ["comedy", (d?.results || []).map(x => ({ ...x, media_type: "movie" }))]).catch(() => ["comedy", []]),
        tmdbFetch("/discover/movie?with_genres=878|14&sort_by=popularity.desc&vote_count.gte=300", apiKey).then(d => ["scifi", (d?.results || []).map(x => ({ ...x, media_type: "movie" }))]).catch(() => ["scifi", []]),
        tmdbFetch("/discover/movie?with_genres=80|53&sort_by=popularity.desc&vote_count.gte=300", apiKey).then(d => ["crime", (d?.results || []).map(x => ({ ...x, media_type: "movie" }))]).catch(() => ["crime", []]),
        tmdbFetch("/discover/tv?with_genres=16&sort_by=popularity.desc&vote_count.gte=150", apiKey).then(d => ["animation", (d?.results || []).map(x => ({ ...x, media_type: "tv" }))]).catch(() => ["animation", []]),
        tmdbFetch("/discover/movie?with_genres=27&sort_by=popularity.desc&vote_count.gte=250", apiKey).then(d => ["horror", (d?.results || []).map(x => ({ ...x, media_type: "movie" }))]).catch(() => ["horror", []]),
        tmdbFetch("/movie/top_rated?page=1", apiKey).then(d => ["topRatedM", (d?.results || []).map(x => ({ ...x, media_type: "movie" }))]).catch(() => ["topRatedM", []]),
        tmdbFetch("/tv/top_rated?page=1", apiKey).then(d => ["topRatedT", (d?.results || []).map(x => ({ ...x, media_type: "tv" }))]).catch(() => ["topRatedT", []])
      );
    }
    Promise.all(reqs).then(entries => {
      if (!mounted) return;
      const next = {};
      for (const [k, v] of entries) next[k] = v;
      setRowsData(prev => ({ ...prev, ...next }));
    });
    return () => { mounted = false; };
  }, [scope, category, offline, apiKey]);

  useEffect(() => {
    if (offline || !history || history.length === 0) { setBecauseItems([]); setBecauseTitle(""); return; }
    const seed = history[0];
    if (!seed?.id) return;
    let mounted = true;
    const mt = seed.media_type === "tv" ? "tv" : "movie";
    tmdbFetch(`/${mt}/${seed.id}/recommendations?page=1`, apiKey)
      .then(d => {
        if (!mounted) return;
        const list = (d?.results || []).filter(x => x.poster_path).slice(0, 18).map(x => ({ ...x, media_type: mt }));
        if (list.length > 0) {
          setBecauseItems(list);
          setBecauseTitle(`Because You Watched ${seed.title || seed.name}`);
        }
      })
      .catch(() => {});
    return () => { mounted = false; };
  }, [history?.[0]?.id, offline, apiKey]);

  const trendingMovies = useMemo(() => trending.map(i => ({ ...i, media_type: "movie" })), [trending]);
  const trendingSeries = useMemo(() => trendingTV.map(i => ({ ...i, media_type: "tv" })), [trendingTV]);

  const heroItem = useMemo(() => {
    if (category) {
      const pool = [...(rowsData.cat_pop_m || []), ...(rowsData.cat_pop_t || [])];
      return pool[0] || trendingMovies[0] || trendingSeries[0] || null;
    }
    if (scope === "series") return trendingSeries[0] || trendingMovies[0] || null;
    if (scope === "films") return trendingMovies[0] || trendingSeries[0] || null;
    return trendingMovies[0] || trendingSeries[0] || null;
  }, [scope, category, rowsData, trendingMovies, trendingSeries]);

  useEffect(() => {
    if (!heroItem?.id || offline) { setHeroLogoPath(null); return; }
    let mounted = true;
    const mt = heroItem.media_type === "tv" ? "tv" : "movie";
    tmdbFetch(`/${mt}/${heroItem.id}/images?include_image_language=en,null`, apiKey)
      .then(imgData => {
        if (!mounted) return;
        const logos = imgData?.logos || [];
        const pick = logos.find(l => l.iso_639_1 === "en" && !String(l.file_path || "").endsWith(".svg")) || logos[0];
        setHeroLogoPath(pick?.file_path || null);
      })
      .catch(() => { if (mounted) setHeroLogoPath(null); });
    return () => { mounted = false; };
  }, [heroItem?.id, heroItem?.media_type, offline, apiKey]);

  const top10Keys = useMemo(() => {
    const s = new Set();
    trendingSeries.slice(0, 10).forEach(i => s.add(`tv_${i.id}`));
    trendingMovies.slice(0, 10).forEach(i => s.add(`movie_${i.id}`));
    return s;
  }, [trendingSeries, trendingMovies]);

  const openCard = useCallback(item => {
    if (isTvMode) onSelect(item);
    else setPreviewItem(item);
  }, [isTvMode, onSelect]);

  if (activeFilter === "explore") {
    return React.createElement(React.Fragment, null,
      React.createElement(NFNewHotFeed, {
        apiKey,
        onSelect,
        onOpenPreview: setPreviewItem,
        onToggleSave,
        isSavedFn,
        onSearch,
        isTvMode
      }),
      previewItem && React.createElement(NFPreviewSheet, {
        item: previewItem,
        isSaved: isSavedFn?.(previewItem),
        onToggleSave,
        onPlay: onSelect,
        onDetails: onSelect,
        onClose: () => setPreviewItem(null)
      })
    );
  }

  const interleave = (a = [], b = []) => {
    const out = [];
    const len = Math.max(a.length, b.length);
    for (let i = 0; i < len; i++) {
      if (a[i]) out.push(a[i]);
      if (b[i]) out.push(b[i]);
    }
    return out;
  };

  const filteredContinue = inProgress.filter(it => {
    if (category) return false;
    if (scope === "series") return it.media_type === "tv";
    if (scope === "films") return it.media_type === "movie";
    return true;
  });

  const filteredSaved = savedList.filter(it => {
    if (category) return false;
    if (scope === "series") return it.media_type === "tv";
    if (scope === "films") return it.media_type === "movie";
    return true;
  });

  const renderPosterRow = (key, title, items, opts = {}) => {
    const clean = (items || []).filter(i => i && (i.poster_path || i.backdrop_path));
    if (clean.length === 0) return null;
    return React.createElement("section", { key, className: "nf-row" },
      React.createElement("h2", { className: "nf-row-title" }, title),
      React.createElement("div", { className: "nf-rail-scroller tv-scroll-row" },
        clean.slice(0, opts.top10 ? 10 : 22).map((item, idx) => {
          const poster = imgUrl(item.poster_path || item.backdrop_path, "w342");
          const itemKey = `${item.media_type || "movie"}_${item.id}`;
          const isT10 = !opts.top10 && top10Keys.has(itemKey);
          const pill = !opts.top10 && isRecentRelease(item) ? "Recently Added" : null;
          const btn = React.createElement("button", {
            key: `${key}_${itemKey}`,
            className: "nf-poster-btn card",
            onClick: () => openCard(item),
            "aria-label": item.title || item.name
          },
            React.createElement("img", { src: poster, alt: item.title || item.name, loading: "lazy" }),
            isT10 && React.createElement("div", { className: "nf-top10-corner" },
              React.createElement("span", null, "TOP"),
              React.createElement("span", null, "10")
            ),
            pill && React.createElement("span", { className: "nf-poster-pill" }, pill)
          );
          if (opts.top10) {
            return React.createElement("div", {
              key: `${key}_rank_${itemKey}`,
              className: "nf-top10-card",
              onClick: () => openCard(item)
            },
              React.createElement("span", { className: "nf-top10-rank" }, idx + 1),
              btn
            );
          }
          return btn;
        })
      )
    );
  };

  const renderContinueRow = () => {
    if (filteredContinue.length === 0) return null;
    return React.createElement("section", { key: "continue", className: "nf-row" },
      React.createElement("h2", { className: "nf-row-title" }, "Continue Watching"),
      React.createElement("div", { className: "nf-rail-scroller tv-scroll-row" },
        filteredContinue.map(item => {
          const poster = imgUrl(item.poster_path || item.backdrop_path, "w342");
          const pk = item.media_type === "movie" ? `movie_${item.id}` : `tv_${item.id}_s${item.season}e${item.episode}`;
          const pct = Math.min(100, Math.max(3, Number(progress[pk] || 6)));
          const epLabel = item.media_type === "tv" && item.season != null ? `S${item.season}:E${item.episode}` : "Resume";
          return React.createElement("div", { key: `cw_${pk}`, className: "nf-continue-card card" },
            React.createElement("div", {
              className: "nf-continue-art",
              onClick: () => onSelect(item)
            },
              poster && React.createElement("img", { src: poster, alt: item.title || item.name, loading: "lazy" }),
              React.createElement("div", { className: "nf-continue-play-ring" }, React.createElement(PlayIcon, { size: 17 })),
              React.createElement("div", { className: "nf-progress-track" },
                React.createElement("div", { className: "nf-progress-fill", style: { width: `${pct}%` } })
              )
            ),
            React.createElement("div", { className: "nf-continue-footer" },
              React.createElement("button", { onClick: () => openCard(item), "aria-label": "Info" }, React.createElement(InfoSvg)),
              React.createElement("span", { className: "nf-continue-ep" }, epLabel),
              React.createElement("button", { onClick: () => onRemoveHistory?.(item), "aria-label": "Remove" }, React.createElement(CloseIcon, { size: 14 }))
            )
          );
        })
      )
    );
  };

  const heroArt = heroItem ? imgUrl(heroItem.poster_path || heroItem.backdrop_path, "w780") : null;
  const heroTags = heroItem ? getGenreTags(heroItem) : [];
  const heroSaved = heroItem ? isSavedFn?.(heroItem) : false;

  return React.createElement("div", { className: "nf-home-scroll" },
    React.createElement("div", {
      className: "nf-ambient-bg",
      style: {
        background: "linear-gradient(to bottom, rgba(229, 9, 20, 0.24) 0%, rgba(30, 34, 48, 0.35) 38%, rgba(0, 0, 0, 0) 100%)"
      }
    }),
    !isTvMode && React.createElement("header", { className: "nf-header" },
      React.createElement("div", { className: "nf-header-backdrop", style: { opacity: headerOpacity } }),
      React.createElement("div", { className: "nf-header-bar" },
        React.createElement("button", {
          className: "nf-wordmark-btn",
          onClick: () => { setScope("all"); setCategory(null); window.scrollTo({ top: 0, behavior: "smooth" }); }
        },
          React.createElement("span", { className: "nf-wordmark-text" },
            "Singularity",
            React.createElement("span", null, "TV")
          )
        ),
        React.createElement("div", { className: "nf-header-actions" },
          React.createElement("button", {
            className: "nf-icon-btn",
            onClick: onSearch,
            "aria-label": "Search"
          }, React.createElement(SearchIcon)),
          React.createElement("button", {
            className: "nf-icon-btn",
            onClick: onOpenProfiles,
            "aria-label": "Switch Profile"
          },
            React.createElement("span", {
              style: {
                width: 26,
                height: 26,
                borderRadius: 6,
                background: activeProfile?.avatarColor || "#e50914",
                color: "#fff",
                fontSize: 12,
                fontWeight: 800,
                display: "inline-flex",
                alignItems: "center",
                justifyContent: "center"
              }
            }, (activeProfile?.name || "S").charAt(0).toUpperCase())
          )
        )
      ),
      React.createElement("div", { className: "nf-chips-bar" },
        (scope !== "all" || category) && React.createElement("button", {
          className: "nf-clear-chip",
          onClick: () => { setScope("all"); setCategory(null); },
          "aria-label": "Clear filters"
        }, React.createElement(CloseIcon, { size: 12 })),
        scope === "all"
          ? React.createElement(React.Fragment, null,
              React.createElement("button", { className: "nf-chip", onClick: () => setScope("series") }, "Series"),
              React.createElement("button", { className: "nf-chip", onClick: () => setScope("films") }, "Films")
            )
          : React.createElement("button", { className: "nf-chip selected", onClick: () => setScope("all") }, scope === "series" ? "Series" : "Films"),
        React.createElement("button", {
          className: `nf-chip${category ? " selected" : ""}`,
          onClick: () => setShowPicker(true)
        },
          React.createElement("span", null, category ? category.name : "Categories"),
          React.createElement("span", { style: { fontSize: 10, opacity: 0.8 } }, "▾")
        )
      )
    ),

    offline && React.createElement("div", { className: "tv-offline-state" },
      React.createElement(WifiOffIcon, { size: 48 }),
      React.createElement("div", { style: { fontSize: 20, fontWeight: 700, color: "#fff" } }, "Offline Mode"),
      React.createElement("div", { style: { fontSize: 14, color: "rgba(255,255,255,0.65)" } }, "Your downloads remain available in My SingularityTV."),
      React.createElement("button", { className: "nf-btn-primary", style: { maxWidth: 180 }, onClick: onRetry }, "Try Again")
    ),

    !offline && heroItem && React.createElement("div", { className: "nf-hero-wrap" },
      React.createElement("div", {
        className: "nf-hero-card",
        onClick: () => openCard(heroItem)
      },
        heroArt && React.createElement("img", { src: heroArt, alt: heroItem.title || heroItem.name, className: "nf-hero-art" }),
        React.createElement("div", { className: "nf-hero-gradient" }),
        React.createElement("div", { className: "nf-hero-info", onClick: e => e.stopPropagation() },
          heroLogoPath
            ? React.createElement("img", { src: imgUrl(heroLogoPath, "w500"), alt: heroItem.title || heroItem.name, className: "nf-hero-logo-img" })
            : React.createElement("h1", { className: "nf-hero-fallback-title" }, heroItem.title || heroItem.name),
          heroTags.length > 0 && React.createElement("div", { className: "nf-hero-tags" }, heroTags.join("  •  ")),
          React.createElement("div", { className: "nf-hero-buttons" },
            React.createElement("button", {
              className: "nf-btn-primary hero-action-btn",
              onClick: () => onSelect(heroItem)
            },
              React.createElement(PlayIcon, { size: 16 }),
              React.createElement("span", null, "Play")
            ),
            React.createElement("button", {
              className: "nf-btn-secondary hero-action-btn",
              onClick: () => onToggleSave?.(heroItem)
            },
              heroSaved ? React.createElement(CheckSvg) : React.createElement(PlusSvg),
              React.createElement("span", null, "My List")
            )
          )
        )
      )
    ),

    !offline && React.createElement("div", { className: "nf-rails-stack" },
      category
        ? React.createElement(React.Fragment, null,
            renderPosterRow("cat_pop", `Popular ${category.name}`, interleave(rowsData.cat_pop_m, rowsData.cat_pop_t)),
            renderPosterRow("cat_top", `Critically Acclaimed ${category.name}`, interleave(rowsData.cat_top_m, rowsData.cat_top_t)),
            rowsData.cat_pop_t?.length > 0 && renderPosterRow("cat_tv", `${category.name} Series`, rowsData.cat_pop_t),
            rowsData.cat_pop_m?.length > 0 && renderPosterRow("cat_mv", `${category.name} Films`, rowsData.cat_pop_m)
          )
        : scope === "series"
          ? React.createElement(React.Fragment, null,
              renderContinueRow(),
              renderPosterRow("tr_tv", "Trending Series", trendingSeries),
              renderPosterRow("t10_tv", "Top 10 Series Today", trendingSeries, { top10: true }),
              renderPosterRow("ota", "New Episodes", rowsData.onTheAir),
              filteredSaved.length > 0 && renderPosterRow("mylist", "My List", filteredSaved),
              renderPosterRow("pop_tv", "Popular Series", rowsData.popSeries),
              renderPosterRow("anim_tv", "Animated Series", rowsData.animation),
              renderPosterRow("top_tv", "Binge-Worthy Series", rowsData.topRatedT)
            )
          : scope === "films"
            ? React.createElement(React.Fragment, null,
                renderContinueRow(),
                renderPosterRow("tr_mv", "Trending Films", trendingMovies),
                renderPosterRow("t10_mv", "Top 10 Films Today", trendingMovies, { top10: true }),
                renderPosterRow("now_mv", "New Releases", rowsData.nowPlaying),
                filteredSaved.length > 0 && renderPosterRow("mylist", "My List", filteredSaved),
                renderPosterRow("pop_mv", "Popular Films", rowsData.popMovies),
                renderPosterRow("act_mv", "Action Films", rowsData.action),
                renderPosterRow("com_mv", "Comedies", rowsData.comedy),
                renderPosterRow("sci_mv", "Sci-Fi & Fantasy", rowsData.scifi),
                renderPosterRow("hor_mv", "Horror Films", rowsData.horror),
                renderPosterRow("top_mv", "Critically Acclaimed Films", rowsData.topRatedM)
              )
            : React.createElement(React.Fragment, null,
                renderContinueRow(),
                renderPosterRow("tr_all", "Trending Now", interleave(trendingMovies, trendingSeries)),
                renderPosterRow("t10_tv", "Top 10 Series Today", trendingSeries, { top10: true }),
                renderPosterRow("now_mv", "New Releases", rowsData.nowPlaying),
                filteredSaved.length > 0 && renderPosterRow("mylist", "My List", filteredSaved),
                becauseItems.length > 0 && renderPosterRow("because", becauseTitle, becauseItems),
                renderPosterRow("pop_mix", "Popular on SingularityTV", interleave(rowsData.popMovies, rowsData.popSeries)),
                renderPosterRow("t10_mv", "Top 10 Films Today", trendingMovies, { top10: true }),
                renderPosterRow("ota", "New Episodes", rowsData.onTheAir),
                renderPosterRow("act", "Action & Adventure", rowsData.action),
                renderPosterRow("com", "Comedies", rowsData.comedy),
                renderPosterRow("sci", "Sci-Fi & Fantasy", rowsData.scifi),
                renderPosterRow("crm", "Crime & Thrillers", rowsData.crime),
                renderPosterRow("anim", "Animation", rowsData.animation),
                renderPosterRow("hor", "Horror Films", rowsData.horror),
                renderPosterRow("acc", "Critically Acclaimed", interleave(rowsData.topRatedM, rowsData.topRatedT))
              )
    ),

    showPicker && React.createElement(NFCategoryPicker, {
      scope,
      selectedId: category?.id || null,
      onSelect: setCategory,
      onClose: () => setShowPicker(false)
    }),

    previewItem && React.createElement(NFPreviewSheet, {
      item: previewItem,
      isSaved: isSavedFn?.(previewItem),
      onToggleSave,
      onPlay: onSelect,
      onDetails: onSelect,
      onClose: () => setPreviewItem(null)
    })
  );
}
