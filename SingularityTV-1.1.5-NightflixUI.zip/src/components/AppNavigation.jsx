import React, { useState, useEffect } from "react";
import { getActiveProfile } from "../utils/supabaseSync";
import {
  SearchIcon,
  HomeIcon,
  SettingsIcon
} from "./Icons";

function FlameIcon() {
  return React.createElement("svg", {
    width: "22", height: "22", viewBox: "0 0 24 24", fill: "none",
    stroke: "currentColor", strokeWidth: "1.8", strokeLinecap: "round", strokeLinejoin: "round"
  },
    React.createElement("rect", { x: "3", y: "6", width: "14", height: "12", rx: "2" }),
    React.createElement("path", { d: "M7 6V4a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2h-2" }),
    React.createElement("polygon", { points: "9,9.5 13,12 9,14.5", fill: "currentColor", stroke: "none" })
  );
}

function ProfileSquareIcon({ letter, color, active }) {
  return React.createElement("span", {
    style: {
      width: 22,
      height: 22,
      borderRadius: 5,
      background: color || "#e50914",
      color: "#fff",
      fontSize: 11,
      fontWeight: 800,
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      border: active ? "1.5px solid #ffffff" : "1.5px solid transparent"
    }
  }, letter || "S");
}

export function MobileBottomNavigation({
  page,
  activeFilter,
  onNavigate
}) {
  const [activeProfile, setActiveProfile] = useState(() => getActiveProfile());

  useEffect(() => {
    const sync = () => setActiveProfile(getActiveProfile());
    window.addEventListener("singularity:profile-changed", sync);
    window.addEventListener("singularity:live-sync-updated", sync);
    return () => {
      window.removeEventListener("singularity:profile-changed", sync);
      window.removeEventListener("singularity:live-sync-updated", sync);
    };
  }, []);

  const isHome = page === "home" && activeFilter !== "explore";
  const isNewHot = page === "home" && activeFilter === "explore";
  const isMy = page === "history" || page === "downloads" || page === "live";

  return React.createElement("nav", {
    className: "nf-tab-bar",
    "aria-label": "Main Navigation"
  },
    React.createElement("button", {
      className: `nf-tab-item${isHome ? " active" : ""}`,
      onClick: () => onNavigate("home", { filter: "all" })
    },
      React.createElement(HomeIcon),
      React.createElement("span", null, "Home")
    ),
    React.createElement("button", {
      className: `nf-tab-item${isNewHot ? " active" : ""}`,
      onClick: () => onNavigate("home", { filter: "explore" })
    },
      React.createElement(FlameIcon),
      React.createElement("span", null, "New & Hot")
    ),
    React.createElement("button", {
      className: `nf-tab-item${isMy ? " active" : ""}`,
      onClick: () => onNavigate("history", { filter: "all" })
    },
      React.createElement(ProfileSquareIcon, {
        letter: (activeProfile?.name || "S").charAt(0).toUpperCase(),
        color: activeProfile?.avatarColor,
        active: isMy
      }),
      React.createElement("span", null, "My SingularityTV")
    )
  );
}

export function TVCommandStrip({
  page,
  activeFilter,
  onNavigate,
  onSearch,
  onOpenProfiles,
  activeDownloads
}) {
  const [timeStr, setTimeStr] = useState(() =>
    new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })
  );
  const [activeProfile, setActiveProfile] = useState(() => getActiveProfile());

  useEffect(() => {
    const sync = () => setActiveProfile(getActiveProfile());
    window.addEventListener("singularity:profile-changed", sync);
    window.addEventListener("singularity:live-sync-updated", sync);
    return () => {
      window.removeEventListener("singularity:profile-changed", sync);
      window.removeEventListener("singularity:live-sync-updated", sync);
    };
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeStr(new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }));
    }, 30000);
    return () => clearInterval(timer);
  }, []);

  const navItems = [
    { id: "home", filter: "all", label: "Home" },
    { id: "newhot", filter: "explore", targetPage: "home", label: "New & Hot" },
    { id: "tvshows", filter: "tv", targetPage: "home", label: "Series" },
    { id: "movies", filter: "movies", targetPage: "home", label: "Films" },
    { id: "live", filter: "all", label: "Live TV" },
    { id: "history", filter: "all", label: "My List" },
    { id: "downloads", filter: "all", label: "Downloads", badge: activeDownloads > 0 ? activeDownloads : null }
  ];

  return React.createElement("header", {
    className: "sg-tv-strip",
    "aria-label": "TV Navigation Strip"
  },
    React.createElement("button", {
      className: "sg-tv-strip-brand topnav-btn",
      onClick: () => onNavigate("home", { filter: "all" }),
      "aria-label": "SingularityTV"
    },
      React.createElement("span", { className: "nf-wordmark-text", style: { fontSize: 17 } },
        "Singularity",
        React.createElement("span", null, "TV")
      )
    ),
    React.createElement("nav", { className: "sg-tv-strip-nav" },
      navItems.map(item => {
        const target = item.targetPage || item.id;
        const isActive = page === target && (item.filter === (activeFilter || "all"));
        return React.createElement("button", {
          key: item.id,
          className: `sg-tv-strip-link topnav-btn${isActive ? " active" : ""}`,
          onClick: () => onNavigate(target, { filter: item.filter || "all" })
        },
          React.createElement("span", null, item.label),
          item.badge && React.createElement("span", { className: "sg-tv-strip-badge" }, item.badge)
        );
      })
    ),
    React.createElement("div", { className: "sg-tv-strip-actions" },
      React.createElement("button", {
        className: "sg-tv-strip-icon topnav-btn",
        onClick: onSearch,
        "aria-label": "Search"
      }, React.createElement(SearchIcon)),
      React.createElement("button", {
        className: "sg-tv-strip-profile topnav-btn",
        onClick: () => onOpenProfiles ? onOpenProfiles() : onNavigate("settings", { section: "account" }),
        "aria-label": "Switch Profile"
      },
        React.createElement("span", {
          className: "sg-tv-avatar",
          style: { background: activeProfile?.avatarColor || "#e50914" }
        }, (activeProfile?.name || "S").charAt(0).toUpperCase()),
        React.createElement("span", { className: "sg-tv-profile-name" }, activeProfile?.name || "Profile")
      ),
      React.createElement("button", {
        className: `sg-tv-strip-icon topnav-btn${page === "settings" ? " active" : ""}`,
        onClick: () => onNavigate("settings"),
        "aria-label": "Settings"
      }, React.createElement(SettingsIcon)),
      React.createElement("span", { className: "sg-tv-strip-clock" }, timeStr)
    )
  );
}

export default function AppNavigation(props) {
  return props.isTvMode
    ? React.createElement(TVCommandStrip, props)
    : React.createElement(MobileBottomNavigation, props);
}
