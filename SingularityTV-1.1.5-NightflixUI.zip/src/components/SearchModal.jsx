import React, { useState, useEffect, useRef, useCallback, useMemo, memo } from "react";
import { tmdbFetch, imgUrl, resolveGenreFromQuery } from "../utils/api";
import { SearchIcon, CloseIcon, WatchedIcon } from "./Icons";
import { setGamepadFocus } from "../utils/gamepadSpatialNav";
import { isStrictAndroidTvHardware, isAndroidTvDevice } from "../utils/androidBridge";

const STUDIO_MAP = {
  marvel: { company: "420", name: "Marvel Studios" },
  "marvel studios": { company: "420", name: "Marvel Studios" },
  mcu: { company: "420", name: "Marvel Studios" },
  dc: { company: "9993|128064|429", name: "DC Studios" },
  "dc studios": { company: "9993|128064|429", name: "DC Studios" },
  "dc comics": { company: "9993|128064|429", name: "DC Studios" },
  pixar: { company: "3", name: "Pixar" },
  disney: { company: "2|6125", name: "Walt Disney Pictures" },
  "walt disney": { company: "2|6125", name: "Walt Disney Pictures" },
  warner: { company: "174", name: "Warner Bros." },
  "warner bros": { company: "174", name: "Warner Bros." },
  wb: { company: "174", name: "Warner Bros." },
  universal: { company: "33", name: "Universal Pictures" },
  "universal pictures": { company: "33", name: "Universal Pictures" },
  sony: { company: "34|5|2251", name: "Sony Pictures" },
  "sony pictures": { company: "34|5|2251", name: "Sony Pictures" },
  columbia: { company: "5", name: "Columbia Pictures" },
  paramount: { company: "4", name: "Paramount Pictures" },
  a24: { company: "41077", name: "A24" },
  dreamworks: { company: "521|7", name: "DreamWorks" },
  ghibli: { company: "10342", name: "Studio Ghibli" },
  "studio ghibli": { company: "10342", name: "Studio Ghibli" },
  lionsgate: { company: "1632", name: "Lionsgate" },
  "20th century": { company: "25|127928", name: "20th Century Studios" },
  fox: { company: "25|127928", name: "20th Century Studios" },
  blumhouse: { company: "3172", name: "Blumhouse" },
  legendary: { company: "923", name: "Legendary Pictures" },
  lucasfilm: { company: "1", name: "Lucasfilm" },
  illumination: { company: "6704", name: "Illumination" },
  "new line": { company: "12", name: "New Line Cinema" },
  mgm: { company: "21", name: "MGM" },
  miramax: { company: "14", name: "Miramax" },
  netflix: { network: "213", name: "Netflix" },
  hbo: { network: "49", name: "HBO" },
  "apple tv": { network: "2552", name: "Apple TV+" },
  mappa: { company: "21444", name: "MAPPA" },
  ufotable: { company: "5887", name: "ufotable" },
  toei: { company: "5542", name: "Toei Animation" },
  madhouse: { company: "3464", name: "Madhouse" }
};

const EN_ROWS = [
  ["a", "b", "c", "d", "e", "f"],
  ["g", "h", "i", "j", "k", "l"],
  ["m", "n", "o", "p", "q", "r"],
  ["s", "t", "u", "v", "w", "x"],
  ["y", "z", "1", "2", "3", "4"],
  ["5", "6", "7", "8", "9", "0"]
];

const AR_ROWS = [
  ["ا", "ب", "ت", "ث", "ج", "ح"],
  ["خ", "د", "ذ", "ر", "ز", "س"],
  ["ش", "ص", "ض", "ط", "ظ", "ع"],
  ["غ", "ف", "ق", "ك", "ل", "م"],
  ["ن", "ه", "و", "ي", "ة", "ى"],
  ["أ", "إ", "آ", "ؤ", "ئ", "ء"]
];

const SearchResultCard = memo(function SearchResultCard({ item, onSelect, watched }) {
  const [imgBroken, setImgBroken] = useState(false);
  const thumb = item.poster_path
    ? imgUrl(item.poster_path, "w342")
    : item.backdrop_path
      ? imgUrl(item.backdrop_path, "w300")
      : null;
  const title = item.title || item.name;
  if (!thumb || imgBroken || !title) return null;
  const wKey = item.media_type === "tv" ? `tv_${item.id}` : `movie_${item.id}`;
  const isWatched = !!watched?.[wKey];
  return (
    <button className={`nf-result-card${isWatched ? " ep-watched" : ""}`} style={{ width: "100%", minWidth: 0, margin: 0 }} onClick={() => onSelect(item)}>
      <div className="nf-result-thumb" style={{ width: "100%", aspectRatio: "2 / 3", overflow: "hidden" }}>
        <img src={thumb} alt={title} loading="lazy" decoding="async" fetchPriority="low" draggable={false} style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: "center top", display: "block" }} onError={() => setImgBroken(true)} />
        <span className="nf-result-type">
          {item.media_type === "tv" ? "SERIES" : "MOVIE"}
        </span>
        {Number(item.vote_average || 0) > 0 && (
          <span className="sg4-search-score">★ {Number(item.vote_average).toFixed(1)}</span>
        )}
        {isWatched && (
          <div className="card-watched-badge">
            <WatchedIcon size={20} />
          </div>
        )}
      </div>
      <div className="nf-result-title">{title}</div>
    </button>
  );
});

const KeyboardPanel = memo(function KeyboardPanel({
  firstKeyRef,
  langMode,
  onToggleLang,
  onAppend,
  onBackspace,
  onClear
}) {
  const rows = langMode === "ar" ? AR_ROWS : EN_ROWS;
  return (
    <div className="nf-keyboard-panel">
      <div className="nf-keyboard-actions">
        <button
          ref={firstKeyRef}
          className="nf-key nf-key--action"
          onClick={onToggleLang}
        >
          {langMode === "ar" ? "EN" : "عربي"}
        </button>
        <button className="nf-key nf-key--action nf-key--space" onClick={() => onAppend(" ")}>
          ␣
        </button>
        <button className="nf-key nf-key--action" onClick={onBackspace}>
          ⌫
        </button>
        <button className="nf-key nf-key--action" onClick={onClear}>
          Clear
        </button>
      </div>

      <div className="nf-keyboard-grid" dir={langMode === "ar" ? "rtl" : "ltr"}>
        {rows.flat().map(ch => (
          <button key={ch} className="nf-key" onClick={() => onAppend(ch)}>
            {ch}
          </button>
        ))}
      </div>
    </div>
  );
});

export default function SearchModal({
  apiKey,
  onSelect,
  onClose,
  offline,
  trending = [],
  trendingTV = [],
  watched = {},
  initialQuery = "",
  onQueryChange,
  initialLangMode = "en",
  onLangModeChange,
  onPlayDirect
}) {
  const [query, setQueryState] = useState(initialQuery || "");
  const [langMode, setLangModeState] = useState(initialLangMode || "en");
  const setQuery = useCallback(val => {
    setQueryState(prev => {
      const next = typeof val === "function" ? val(prev) : val;
      onQueryChange?.(next);
      return next;
    });
  }, [onQueryChange]);
  const setLangMode = useCallback(val => {
    setLangModeState(prev => {
      const next = typeof val === "function" ? val(prev) : val;
      onLangModeChange?.(next);
      return next;
    });
  }, [onLangModeChange]);
  const isTvMode = useMemo(() => isStrictAndroidTvHardware(), []);
  const [results, setResults] = useState([]);
  const [visibleCount, setVisibleCount] = useState(18);
  const searchSentinelRef = useRef(null);
  const isTvSearch = isAndroidTvDevice();
  useEffect(() => {
    if (isTvSearch) return;
    const node = searchSentinelRef.current;
    if (!node || typeof IntersectionObserver === "undefined") return;
    const obs = new IntersectionObserver(entries => {
      if (entries[0]?.isIntersecting) {
        setVisibleCount(prev => prev + 18);
      }
    }, { rootMargin: "260px" });
    obs.observe(node);
    return () => obs.disconnect();
  }, [isTvSearch, visibleCount, results.length]);
  const [fallbackTrending, setFallbackTrending] = useState([]);
  const [loading, setLoading] = useState(false);
  const firstKeyRef = useRef(null);
  const mobileInputRef = useRef(null);

  useEffect(() => {
    const tid = setTimeout(() => {
      if (isTvMode) {
        if (firstKeyRef.current) setGamepadFocus(firstKeyRef.current, { scroll: false });
      } else {
        mobileInputRef.current?.focus();
      }
    }, 80);
    return () => clearTimeout(tid);
  }, [isTvMode]);

  const combinedTrending = useMemo(() => {
    const out = [];
    const seen = new Set();
    const maxLen = Math.max(trending.length, trendingTV.length);
    for (let i = 0; i < maxLen; i++) {
      const m = trending[i];
      if (m && m.id && !seen.has(`movie_${m.id}`)) {
        seen.add(`movie_${m.id}`);
        out.push({ ...m, media_type: m.media_type || "movie" });
      }
      const t = trendingTV[i];
      if (t && t.id && !seen.has(`tv_${t.id}`)) {
        seen.add(`tv_${t.id}`);
        out.push({ ...t, media_type: t.media_type || "tv" });
      }
    }
    if (out.length > 0) return out;
    return fallbackTrending;
  }, [trending, trendingTV, fallbackTrending]);

  useEffect(() => {
    if (offline || trending.length > 0 || trendingTV.length > 0) return;
    let mounted = true;
    const controller = new AbortController();
    tmdbFetch("/trending/all/day", apiKey, { signal: controller.signal })
      .then(data => {
        if (!mounted) return;
        const items = (data.results || []).filter(
          x => x && x.id && (x.media_type === "movie" || x.media_type === "tv")
        );
        setFallbackTrending(items);
      })
      .catch(() => {});
    return () => {
      mounted = false;
      controller.abort();
    };
  }, [offline, trending.length, trendingTV.length, apiKey]);

  useEffect(() => {
    const trimmed = query.trim();
    if (trimmed.length < 2) {
      setResults([]);
      setLoading(false);
      return;
    }
    let mounted = true;
    const controller = new AbortController();
    const hasArabic = /[\u0600-\u06FF]/.test(trimmed);

    const timer = setTimeout(async () => {
      setLoading(true);
      try {
        const langParam = hasArabic ? "&language=ar-SA" : "";
        const normQ = trimmed.toLowerCase();
        let studioHit = STUDIO_MAP[normQ] || null;
        if (!studioHit) {
          for (const [k, v] of Object.entries(STUDIO_MAP)) {
            if (normQ === k + " movies" || normQ === k + " films" || normQ === k + " studio" || normQ === k + " studios") {
              studioHit = v;
              break;
            }
          }
        }
        const [data, compData] = await Promise.all([
          tmdbFetch(`/search/multi?query=${encodeURIComponent(trimmed)}&page=1${langParam}`, apiKey, { signal: controller.signal }),
          !studioHit && trimmed.length >= 3
            ? tmdbFetch(`/search/company?query=${encodeURIComponent(trimmed)}&page=1`, apiKey, { signal: controller.signal }).catch(() => null)
            : Promise.resolve(null)
        ]);
        if (!studioHit && compData?.results?.length > 0) {
          const exactComp = compData.results.find(c => {
            const cn = (c.name || "").toLowerCase();
            return cn === normQ || cn.startsWith(normQ + " ") || normQ.includes(cn);
          });
          if (exactComp && exactComp.id) {
            studioHit = { company: String(exactComp.id), name: exactComp.name };
          }
        }
        const raw = data.results || [];
        const collected = [];
        const seen = new Set();
        const pushUnique = item => {
          if (!item || !item.id) return;
          const mt = item.media_type || (item.first_air_date ? "tv" : "movie");
          if (mt !== "movie" && mt !== "tv") return;
          const key = `${mt}_${item.id}`;
          if (seen.has(key)) return;
          seen.add(key);
          collected.push({ ...item, media_type: mt });
        };
        if (studioHit) {
          try {
            const studioReqs = studioHit.network
              ? [
                  tmdbFetch(`/discover/tv?with_networks=${studioHit.network}&sort_by=popularity.desc&page=1${langParam}`, apiKey, { signal: controller.signal }).catch(() => ({ results: [] })),
                  tmdbFetch(`/discover/tv?with_networks=${studioHit.network}&sort_by=popularity.desc&page=2${langParam}`, apiKey, { signal: controller.signal }).catch(() => ({ results: [] }))
                ]
              : [
                  tmdbFetch(`/discover/movie?with_companies=${encodeURIComponent(studioHit.company)}&sort_by=popularity.desc&page=1${langParam}`, apiKey, { signal: controller.signal }).catch(() => ({ results: [] })),
                  tmdbFetch(`/discover/movie?with_companies=${encodeURIComponent(studioHit.company)}&sort_by=popularity.desc&page=2${langParam}`, apiKey, { signal: controller.signal }).catch(() => ({ results: [] })),
                  tmdbFetch(`/discover/tv?with_companies=${encodeURIComponent(studioHit.company)}&sort_by=popularity.desc&page=1${langParam}`, apiKey, { signal: controller.signal }).catch(() => ({ results: [] }))
                ];
            const studioPages = await Promise.all(studioReqs);
            for (let pi = 0; pi < studioPages.length; pi++) {
              const mt = studioHit.network || pi === 2 ? "tv" : "movie";
              for (const it of studioPages[pi]?.results || []) {
                pushUnique({ ...it, media_type: mt });
              }
            }
          } catch {}
        }

        const people = raw.filter(r => r.media_type === "person");
        for (const r of raw) {
          if (r.media_type === "person") {
            for (const kf of r.known_for || []) {
              pushUnique(kf);
            }
          } else {
            pushUnique(r);
          }
        }

        if (people.length > 0 && collected.length < 12) {
          try {
            const credits = await tmdbFetch(
              `/person/${people[0].id}/combined_credits?${hasArabic ? "language=ar-SA" : ""}`,
              apiKey,
              { signal: controller.signal }
            );
            const cast = (credits.cast || [])
              .sort((a, b) => (b.popularity || 0) - (a.popularity || 0))
              .slice(0, 12);
            for (const c of cast) {
              pushUnique(c);
            }
          } catch {}
        }

        if (mounted) {
          setVisibleCount(18);
          setResults(collected.slice(0, 90));
        }
      } catch {}
      if (mounted) setLoading(false);
    }, 450);

    return () => {
      mounted = false;
      clearTimeout(timer);
      controller.abort();
    };
  }, [query, apiKey]);

  const appendChar = useCallback(ch => {
    setQuery(prev => prev + ch);
  }, []);

  const handleBackspace = useCallback(() => {
    setQuery(prev => prev.slice(0, -1));
  }, []);

  const handleClear = useCallback(() => {
    setQuery("");
  }, []);

  const toggleLang = useCallback(() => {
    setLangMode(prev => (prev === "en" ? "ar" : "en"));
  }, []);

  const handleSelect = useCallback(
    item => {
      try {
        const qTrim = query.trim();
        if (qTrim.length >= 2) {
          const raw = localStorage.getItem("streambert_searchHistory");
          const prev = raw ? JSON.parse(raw) : [];
          const next = [qTrim, ...prev.filter(x => x !== qTrim)].slice(0, 25);
          localStorage.setItem("streambert_searchHistory", JSON.stringify(next));
          window.dispatchEvent(new CustomEvent("streambert:cloud-sync-needed"));
        }
      } catch {}
      onSelect(item);
    },
    [onSelect, query]
  );

  const isSearching = query.trim().length >= 2;
  const allDisplayItems = isSearching ? results : combinedTrending.slice(0, 12);
  const displayItems = isSearching ? allDisplayItems.slice(0, visibleCount) : allDisplayItems;

  return (
    <div
      className="modal-overlay nf-search-overlay"
      onClick={e => e.target === e.currentTarget && onClose()}
    >
      <div className="nf-search-shell" style={isTvMode ? undefined : { gridTemplateColumns: "1fr" }}>
        {isTvMode && (
          <div className="nf-search-left">
            <KeyboardPanel
              firstKeyRef={firstKeyRef}
              langMode={langMode}
              onToggleLang={toggleLang}
              onAppend={appendChar}
              onBackspace={handleBackspace}
              onClear={handleClear}
            />

            <div className="nf-trending-panel">
              <div className="nf-trending-heading">Trending Now</div>
              <div className="nf-trending-list">
                {combinedTrending.slice(0, 8).map(item => (
                  <button
                    key={`trend_${item.media_type}_${item.id}`}
                    className="nf-trending-chip"
                    onClick={() => handleSelect(item)}
                  >
                    <span className="nf-trending-name">{item.title || item.name}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        <div className="nf-search-right">
          <div className="nf-search-bar">
            <SearchIcon />
            {isTvMode ? (
              <div
                className="nf-search-query-display"
                dir={/[\u0600-\u06FF]/.test(query) ? "rtl" : "ltr"}
              >
                {query ? (
                  <span className="nf-search-query-text">{query}</span>
                ) : (
                  <span className="nf-search-placeholder">Search movies, actors, shows...</span>
                )}
              </div>
            ) : (
              <input
                ref={mobileInputRef}
                type="search"
                value={query}
                onChange={e => setQuery(e.target.value)}
                placeholder="Search movies, actors, shows..."
                dir={/[\u0600-\u06FF]/.test(query) ? "rtl" : "ltr"}
                autoComplete="off"
                autoCorrect="off"
                spellCheck={false}
                style={{
                  flex: 1,
                  minWidth: 0,
                  background: "transparent",
                  border: "none",
                  outline: "none",
                  color: "#fff",
                  fontSize: 16,
                  fontWeight: 600
                }}
              />
            )}
            {!isTvMode && query.length > 0 && (
              <button
                type="button"
                className="nf-player-btn"
                onClick={handleClear}
                aria-label="Clear"
                style={{ fontSize: 12, padding: "4px 10px", width: "auto" }}
              >
                Clear
              </button>
            )}
            <button
              className="nf-player-btn nf-search-close-btn"
              data-gamepad-close="1"
              onClick={onClose}
              aria-label="Close"
            >
              <CloseIcon />
            </button>
          </div>

          <div className="nf-search-section-label">
            {isSearching ? (resolveGenreFromQuery(query) ? `Results for "${query}" · ${resolveGenreFromQuery(query)}` : `Results for "${query}"`) : "Top Searches"}
          </div>

          {offline && (
            <div className="nf-search-empty">No internet connection. Search is unavailable offline.</div>
          )}

          {!offline && loading && (
            <div className="loader">
              <div className="spinner" />
            </div>
          )}

          {!offline && !loading && isSearching && results.length === 0 && (
            <div className="nf-search-empty">No results found for "{query}"</div>
          )}

          {!offline && !loading && (
            <>
              {!isSearching && !isTvMode ? (
                <div className="nf-topsearches-list">
                  {displayItems.map(r => {
                    const thumb = imgUrl(r.backdrop_path || r.poster_path, "w300");
                    const title = r.title || r.name;
                    const yr = (r.release_date || r.first_air_date || "").slice(0, 4);
                    const sub = [yr, r.media_type === "tv" ? "Series" : "Film"].filter(Boolean).join(" · ");
                    return (
                      <div key={`top_${r.media_type}_${r.id}`} className="nf-topsearch-row">
                        <div style={{ display: "flex", alignItems: "center", gap: 12, flex: 1, minWidth: 0, cursor: "pointer" }} onClick={() => handleSelect(r)}>
                          {thumb && <img src={thumb} alt={title} className="nf-topsearch-thumb" loading="lazy" />}
                          <div style={{ minWidth: 0, flex: 1 }}>
                            <div style={{ fontSize: 15, fontWeight: 500, color: "#fff", overflow: "hidden", textOverflow: "ellipsis", display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical" }}>{title}</div>
                            {sub && <div style={{ fontSize: 12, color: "rgba(255,255,255,0.5)", marginTop: 2 }}>{sub}</div>}
                          </div>
                        </div>
                        <button className="nf-my-play-circle" onClick={() => (onPlayDirect || handleSelect)(r)} aria-label={`Play ${title}`}>
                          <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><polygon points="6,4 20,12 6,20" /></svg>
                        </button>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="nf-results-grid">
                  {displayItems.map(r => (
                    <SearchResultCard
                      key={`${r.media_type}_${r.id}`}
                      item={r}
                      onSelect={handleSelect}
                      watched={watched}
                    />
                  ))}
                </div>
              )}
              {isSearching && visibleCount < allDisplayItems.length && !isTvSearch && (
                <div ref={searchSentinelRef} className="sg4-infinite-sentinel">
                  <div className="spinner" />
                </div>
              )}
              {isSearching && visibleCount < allDisplayItems.length && isTvSearch && (
                <div style={{ display: "flex", justifyContent: "center", padding: "20px 0 10px" }}>
                  <button
                    type="button"
                    className="sg3-btn-info"
                    onClick={() => setVisibleCount(prev => prev + 18)}
                  >
                    Load More ({Math.min(visibleCount, allDisplayItems.length)} / {allDisplayItems.length})
                  </button>
                </div>
              )}
            </>
          )}
        </div>
      </div>
    </div>
  );
}
