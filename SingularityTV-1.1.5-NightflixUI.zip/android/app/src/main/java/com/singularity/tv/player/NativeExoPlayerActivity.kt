package com.singularity.tv.player

import android.annotation.SuppressLint
import android.content.pm.ActivityInfo
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONObject
import kotlin.math.abs

class NativeExoPlayerActivity : AppCompatActivity() {
    private var webView: WebView? = null
    private lateinit var topBar: FrameLayout
    private lateinit var titleText: TextView
    private lateinit var loadingBox: LinearLayout
    private lateinit var failureBox: LinearLayout
    private lateinit var failureTitle: TextView
    private lateinit var failureMsg: TextView

    private val handler = Handler(Looper.getMainLooper())
    private val hideChromeRunnable = Runnable {
        topBar.animate().alpha(0f).setDuration(250L).withEndAction {
            topBar.visibility = View.GONE
        }.start()
    }

    private var currentTitle: String = "SingularityTV"
    private var currentSubtitle: String = ""
    private var progressKey: String = ""
    private var tmdbId: String = ""
    private var mediaType: String = "movie"
    private var seasonNum: Int = 1
    private var episodeNum: Int = 1
    private var startPositionSec: Int = 0
    private var targetUrl: String = ""
    private var allowedBrandLabel: String? = null
    private var lastPersistedSec: Double = -1000.0

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        activeInstance = this
        isPlayerActive = true

        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        hideSystemBars()

        val rawPayload = intent.getStringExtra(EXTRA_PAYLOAD_JSON) ?: "{}"
        parsePayload(rawPayload)

        val density = resources.displayMetrics.density
        val root = FrameLayout(this).apply {
            setBackgroundColor(Color.BLACK)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        val wv = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.BLACK)
            settings.apply {
                javaScriptEnabled = true
                domStorageEnabled = true
                databaseEnabled = true
                mediaPlaybackRequiresUserGesture = false
                allowFileAccess = true
                allowContentAccess = true
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
                setSupportMultipleWindows(false)
                javaScriptCanOpenWindowsAutomatically = false
                userAgentString = userAgentString.replace(Regex(";\\s*wv\\)"), ")")
            }
            CookieManager.getInstance().apply {
                setAcceptCookie(true)
                setAcceptThirdPartyCookies(this@apply, true)
            }
            addJavascriptInterface(NightflixJsBridge(), "NightflixAndroidBridge")
            webChromeClient = object : WebChromeClient() {}
            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                    showLoading(true)
                    failureBox.visibility = View.GONE
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    showLoading(false)
                    view?.evaluateJavascript(PLAYER_BRIDGE_JS, null)
                    view?.evaluateJavascript(RESUME_LOOP_GUARD_JS, null)
                    view?.evaluateJavascript(HIDE_FULLSCREEN_JS, null)
                }

                override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                    val req = request ?: return false
                    if (req.isForMainFrame) {
                        val host = req.url?.host
                        val allowed = allowedBrandLabel
                        if (allowed != null && brandLabel(host) != allowed) {
                            return true
                        }
                    }
                    return false
                }

                override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                    if (request?.isForMainFrame == true) {
                        showFailure("The player didn't load", error?.description?.toString() ?: "Connection error")
                    }
                }
            }
        }
        webView = wv
        root.addView(wv)

        loadingBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            val spinner = ProgressBar(this@NativeExoPlayerActivity).apply {
                indeterminateDrawable?.setTint(Color.parseColor("#E50914"))
            }
            val lbl = TextView(this@NativeExoPlayerActivity).apply {
                text = currentTitle
                setTextColor(Color.argb(205, 255, 255, 255))
                textSize = 15f
                gravity = Gravity.CENTER
                setPadding((32 * density).toInt(), (16 * density).toInt(), (32 * density).toInt(), 0)
            }
            addView(spinner)
            addView(lbl)
        }
        root.addView(loadingBox)

        topBar = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (82 * density).toInt(),
                Gravity.TOP
            )
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.argb(190, 0, 0, 0), Color.argb(90, 0, 0, 0), Color.TRANSPARENT)
            )
            setPadding((14 * density).toInt(), (10 * density).toInt(), (14 * density).toInt(), 0)
        }

        titleText = TextView(this).apply {
            text = formattedTitleLine()
            setTextColor(Color.WHITE)
            textSize = 15f
            maxLines = 1
            gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                (44 * density).toInt(),
                Gravity.TOP or Gravity.CENTER_HORIZONTAL
            ).apply {
                marginStart = (56 * density).toInt()
                marginEnd = (56 * density).toInt()
            }
        }
        topBar.addView(titleText)

        val closeBtn = TextView(this).apply {
            text = "✕"
            setTextColor(Color.WHITE)
            textSize = 19f
            gravity = Gravity.CENTER
            layoutParams = FrameLayout.LayoutParams(
                (44 * density).toInt(),
                (44 * density).toInt(),
                Gravity.TOP or Gravity.END
            )
            setOnClickListener {
                forceShutdownPlayer()
                finish()
            }
        }
        topBar.addView(closeBtn)
        root.addView(topBar)

        failureBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.argb(220, 0, 0, 0))
            visibility = View.GONE
            setPadding((28 * density).toInt(), (24 * density).toInt(), (28 * density).toInt(), (24 * density).toInt())
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )

            failureTitle = TextView(this@NativeExoPlayerActivity).apply {
                text = "The player didn't load"
                setTextColor(Color.WHITE)
                textSize = 19f
                gravity = Gravity.CENTER
            }
            failureMsg = TextView(this@NativeExoPlayerActivity).apply {
                setTextColor(Color.argb(185, 255, 255, 255))
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(0, (10 * density).toInt(), 0, (18 * density).toInt())
            }
            val row = LinearLayout(this@NativeExoPlayerActivity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }
            val btnClose = TextView(this@NativeExoPlayerActivity).apply {
                text = "Close"
                setTextColor(Color.WHITE)
                textSize = 15f
                gravity = Gravity.CENTER
                background = GradientDrawable().apply {
                    setColor(Color.argb(42, 255, 255, 255))
                    cornerRadius = 6 * density
                }
                layoutParams = LinearLayout.LayoutParams((124 * density).toInt(), (42 * density).toInt()).apply {
                    marginEnd = (10 * density).toInt()
                }
                setOnClickListener {
                    forceShutdownPlayer()
                    finish()
                }
            }
            val btnRetry = TextView(this@NativeExoPlayerActivity).apply {
                text = "Try Again"
                setTextColor(Color.BLACK)
                textSize = 15f
                gravity = Gravity.CENTER
                background = GradientDrawable().apply {
                    setColor(Color.WHITE)
                    cornerRadius = 6 * density
                }
                layoutParams = LinearLayout.LayoutParams((124 * density).toInt(), (42 * density).toInt())
                setOnClickListener { loadTarget() }
            }
            row.addView(btnClose)
            row.addView(btnRetry)
            addView(failureTitle)
            addView(failureMsg)
            addView(row)
        }
        root.addView(failureBox)

        setContentView(root)
        showChrome()
        loadTarget()
    }

    private fun parsePayload(raw: String) {
        try {
            val obj = JSONObject(raw)
            val rawTitle = obj.optString("title", currentTitle)
            currentTitle = rawTitle.replace(Regex("\\s*[·•\\-]\\s*S\\d+E\\d+.*$"), "").trim().ifEmpty { rawTitle }
            currentSubtitle = obj.optString("episodeName", "")
            progressKey = obj.optString("progressKey", "")
            tmdbId = obj.optString("tmdbId", "")
            mediaType = obj.optString("mediaType", "movie").lowercase()
            seasonNum = obj.optInt("season", 1)
            episodeNum = obj.optInt("episode", 1)
            startPositionSec = if (obj.has("startPositionSec")) obj.optInt("startPositionSec", 0) else obj.optInt("startTimeSec", 0)

            val directUrl = obj.optString("url", "")
            val isLocal = obj.optBoolean("isLocal", false)

            if (isLocal && directUrl.isNotEmpty()) {
                targetUrl = directUrl
                return
            }

            if (tmdbId.isNotEmpty()) {
                var built = if (mediaType == "tv") {
                    "https://vidfast.vc/tv/$tmdbId/$seasonNum/$episodeNum?autoPlay=true&theme=E50914&title=false&poster=true&chromecast=false&nextButton=true&autoNext=true"
                } else {
                    "https://vidfast.vc/movie/$tmdbId?autoPlay=true&theme=E50914&title=false&poster=true&chromecast=false"
                }
                if (startPositionSec > 5) {
                    built += "&startAt=$startPositionSec"
                }
                targetUrl = built
            } else if ((directUrl.startsWith("http://") || directUrl.startsWith("https://")) && !directUrl.lowercase().contains("vidly.pro")) {
                targetUrl = directUrl
            }
        } catch (_: Throwable) {}
    }

    private fun formattedTitleLine(): String {
        if (mediaType == "tv") {
            return if (currentSubtitle.isNotEmpty()) "$currentTitle  S${seasonNum}:E${episodeNum} \"$currentSubtitle\""
            else "$currentTitle  S${seasonNum}:E${episodeNum}"
        }
        return currentTitle
    }

    private fun loadTarget() {
        if (targetUrl.isEmpty()) {
            showFailure("Not available right now", "No playable stream URL was provided.")
            return
        }
        allowedBrandLabel = brandLabel(Uri.parse(targetUrl).host)
        failureBox.visibility = View.GONE
        showLoading(true)
        webView?.loadUrl(targetUrl)
    }

    private fun showChrome() {
        handler.removeCallbacks(hideChromeRunnable)
        topBar.visibility = View.VISIBLE
        topBar.animate().alpha(1f).setDuration(200L).start()
        handler.postDelayed(hideChromeRunnable, 3500L)
    }

    private fun showLoading(show: Boolean) {
        runOnUiThread {
            loadingBox.visibility = if (show) View.VISIBLE else View.GONE
        }
    }

    private fun showFailure(title: String, msg: String) {
        runOnUiThread {
            loadingBox.visibility = View.GONE
            failureTitle.text = title
            failureMsg.text = msg
            failureBox.visibility = View.VISIBLE
        }
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller.hide(WindowInsetsCompat.Type.systemBars())
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            showChrome()
            when (event.keyCode) {
                KeyEvent.KEYCODE_BACK -> {
                    forceShutdownPlayer()
                    finish()
                    return true
                }
                KeyEvent.KEYCODE_DPAD_LEFT -> {
                    webView?.evaluateJavascript("try{var v=document.querySelector('video');if(v&&isFinite(v.duration)){v.currentTime=Math.max(0,v.currentTime-10);}}catch(e){}", null)
                    return true
                }
                KeyEvent.KEYCODE_DPAD_RIGHT -> {
                    webView?.evaluateJavascript("try{var v=document.querySelector('video');if(v&&isFinite(v.duration)){v.currentTime=Math.min(v.duration-0.5,v.currentTime+10);}}catch(e){}", null)
                    return true
                }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                    webView?.evaluateJavascript("try{var v=document.querySelector('video');if(v){if(v.paused)v.play().catch(function(){});else v.pause();}}catch(e){}", null)
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    fun forceShutdownPlayer() {
        handler.removeCallbacks(hideChromeRunnable)
        try {
            webView?.evaluateJavascript("try{document.querySelectorAll('video,audio').forEach(function(m){m.pause();m.muted=true;m.removeAttribute('src');m.load();});}catch(e){}", null)
            webView?.stopLoading()
            webView?.loadUrl("about:blank")
            webView?.destroy()
        } catch (_: Throwable) {}
        webView = null
        isPlayerActive = false
        if (activeInstance === this) activeInstance = null
    }

    override fun onDestroy() {
        forceShutdownPlayer()
        super.onDestroy()
    }

    private fun brandLabel(host: String?): String? {
        val h = host?.lowercase() ?: return null
        val parts = h.split(".")
        if (parts.size < 2) return parts.firstOrNull()
        return parts[parts.size - 2]
    }

    inner class NightflixJsBridge {
        @JavascriptInterface
        fun onInteraction() {
            runOnUiThread { showChrome() }
        }

        @JavascriptInterface
        fun onSourceUnavailable() {
        }

        @JavascriptInterface
        fun onProgress(ct: Double, dur: Double, eventName: String) {
            if (ct <= 0.0) return
            val ev = eventName.lowercase()
            val discrete = ev == "pause" || ev == "seeked" || ev == "ended"
            if (!discrete && abs(ct - lastPersistedSec) < 5.0) return
            lastPersistedSec = ct

            val pct = if (dur > 0.0) ((ct / dur) * 100.0).toInt().coerceIn(1, 100) else 1
            val watched = ev == "ended" || (dur > 0.0 && (ct / dur) >= 0.95)
            val playing = ev != "pause" && !watched
            val key = if (progressKey.isNotEmpty()) progressKey else (if (mediaType == "tv") "tv_${tmdbId}_s${seasonNum}e${episodeNum}" else "movie_${tmdbId}")
            ExoProgressBus.listener?.invoke(key, pct, ct.toLong(), dur.toLong(), watched, playing)
        }
    }

    companion object {
        const val EXTRA_PAYLOAD_JSON = "extra_payload_json"
        @Volatile var isPlayerActive: Boolean = false
        @Volatile var activeInstance: NativeExoPlayerActivity? = null
        var onNeedNextServer: ((String, Long, (String?, String?) -> Unit) -> Unit)? = null

        fun forceCloseIfOpen() {
            val inst = activeInstance
            if (inst != null) {
                try {
                    inst.runOnUiThread {
                        inst.forceShutdownPlayer()
                        if (!inst.isFinishing && !inst.isDestroyed) {
                            inst.finish()
                        }
                    }
                } catch (_: Throwable) {}
            }
            isPlayerActive = false
            activeInstance = null
        }

        private const val PLAYER_BRIDGE_JS = """
            (function(){
              if(window.__nfBridgeInstalled) return;
              window.__nfBridgeInstalled = 1;
              function normalize(raw){
                var p = raw;
                if(typeof raw === 'string'){ try{ p = JSON.parse(raw); }catch(e){ return null; } }
                return (p && typeof p === 'object') ? p : null;
              }
              window.addEventListener('message', function(ev){
                var p = normalize(ev.data);
                if(!p) return;
                if(p.event === 'status' && Number(p.data) >= 400){
                  try{ NightflixAndroidBridge.onSourceUnavailable(); }catch(e){}
                  return;
                }
                var d = (p.type === 'PLAYER_EVENT' && p.data) ? p.data : p;
                var ct = Number(d.currentTime || d.timestamp || 0);
                var dur = Number(d.duration || 0);
                if(ct > 0){
                  try{ NightflixAndroidBridge.onProgress(ct, dur, String(d.event || 'timeupdate')); }catch(e){}
                }
              }, false);
              var lastT = 0;
              function ping(){
                var n = Date.now();
                if(n - lastT < 350) return;
                lastT = n;
                try{ NightflixAndroidBridge.onInteraction(); }catch(e){}
              }
              document.addEventListener('touchstart', ping, {capture:true, passive:true});
              document.addEventListener('mousedown', ping, {capture:true, passive:true});
              setInterval(function(){
                try{
                  var v = document.querySelector('video');
                  if(v && isFinite(v.duration) && v.duration > 30 && v.currentTime > 0){
                    NightflixAndroidBridge.onProgress(v.currentTime, v.duration, v.ended ? 'ended' : (v.paused ? 'pause' : 'timeupdate'));
                  }
                }catch(e){}
              }, 5000);
            })();
        """


        private const val HIDE_FULLSCREEN_JS = """
            (function(){
              if(window.__sgHideFsInstalled) return;
              window.__sgHideFsInstalled = 1;
              try {
                var s = document.createElement('style');
                s.textContent = 'button[aria-label*="fullscreen" i],button[title*="fullscreen" i],[data-tooltip*="fullscreen" i],button[class*="fullscreen" i],.vjs-fullscreen-control,.plyr__control[data-plyr="fullscreen"],.jw-icon-fullscreen{display:none!important;visibility:hidden!important;opacity:0!important;pointer-events:none!important;width:0!important;height:0!important;}';
                (document.head || document.documentElement).appendChild(s);
              } catch(e){}
              function hideFs(){
                try {
                  var btns = document.querySelectorAll('button,[role="button"]');
                  var vw = window.innerWidth || 800, vh = window.innerHeight || 400;
                  for(var i=0;i<btns.length;i++){
                    var b = btns[i];
                    var lbl = ((b.getAttribute('aria-label')||'')+' '+(b.getAttribute('title')||'')+' '+(b.getAttribute('data-tooltip')||'')+' '+(b.className||'')).toLowerCase();
                    if(lbl.indexOf('fullscreen')!==-1 || lbl.indexOf('full screen')!==-1 || lbl.indexOf('maximize')!==-1){
                      b.style.setProperty('display','none','important');
                      continue;
                    }
                    var r = b.getBoundingClientRect();
                    if(r.width>12 && r.width<68 && r.height>12 && r.height<68 && r.right>=vw-58 && r.bottom>=vh-76){
                      if(b.querySelector('svg') && b.nextElementSibling === null && r.right >= vw - 44){
                        b.style.setProperty('display','none','important');
                      }
                    }
                  }
                } catch(e){}
              }
              hideFs();
              setInterval(hideFs, 900);
              if(window.MutationObserver){
                try { new MutationObserver(hideFs).observe(document.documentElement, {childList:true, subtree:true}); } catch(e){}
              }
            })();
        """

        private const val RESUME_LOOP_GUARD_JS = """
            (function(){
              var params = new URLSearchParams(window.location.search);
              var raw = params.get('startAt') || params.get('progress');
              var resumeTime = raw ? parseFloat(raw) : NaN;
              if(!(resumeTime > 0)) return;
              var proto = window.HTMLMediaElement && HTMLMediaElement.prototype;
              var desc = proto && Object.getOwnPropertyDescriptor(proto, 'currentTime');
              if(!desc || !desc.get || !desc.set) return;
              function guard(v){
                if(!v || v.__nfGuarded) return;
                v.__nfGuarded = true;
                var furthest = 0, everResumed = false;
                v.addEventListener('timeupdate', function(){
                  var t = desc.get.call(v);
                  if(t > furthest) furthest = t;
                });
                Object.defineProperty(v, 'currentTime', {
                  configurable: true,
                  get: function(){ return desc.get.call(this); },
                  set: function(val){
                    if(val === resumeTime){
                      var cur = desc.get.call(this);
                      if(!everResumed){ everResumed = true; desc.set.call(this, Math.max(resumeTime, furthest)); return; }
                      if(cur < furthest - 5){ desc.set.call(this, Math.max(resumeTime, furthest)); }
                      return;
                    }
                    desc.set.call(this, val);
                  }
                });
              }
              function guardAll(){
                var vs = document.getElementsByTagName('video');
                for(var i=0;i<vs.length;i++) guard(vs[i]);
              }
              guardAll();
              if(window.MutationObserver){
                new MutationObserver(guardAll).observe(document.documentElement, {childList:true, subtree:true});
              }
            })();
        """
    }
}

object ExoProgressBus {
    var listener: ((String, Int, Long, Long, Boolean, Boolean) -> Unit)? = null
    var serverSwitchListener: ((String) -> Unit)? = null
    var preferredSourceListener: ((String) -> Unit)? = null
    var subtitleStyleListener: ((String, String, Float) -> Unit)? = null
    var webPrefsListener: ((String) -> Unit)? = null
}
