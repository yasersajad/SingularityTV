import UIKit
import AVFoundation
import WebKit

class NativePlayerViewController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate {
    private let payloadJson: String
    private var reusedMiniWebView: WKWebView?

    var onProgressUpdate: ((String, Int, Int, Int, Bool, Bool) -> Void)?
    var onSubtitleStyleChanged: ((String, String, Double) -> Void)?
    var onWebPrefsUpdate: ((String) -> Void)?
    var onPreferredSource: ((String) -> Void)?
    var onBlockedAd: ((String) -> Void)?
    var onMinimizeToMiniPiP: ((WKWebView, String) -> Void)?

    private var webView: WKWebView?
    private var topBarContainer: UIView!
    private var titleLabel: UILabel!
    private var loadingContainer: UIView!
    private var loadingSpinner: UIActivityIndicatorView!
    private var failureContainer: UIView!
    private var failureTitleLabel: UILabel!
    private var failureMessageLabel: UILabel!

    private var currentTitle: String = "SingularityTV"
    private var episodeName: String = ""
    private var progressKey: String = ""
    private var tmdbId: String = ""
    private var mediaType: String = "movie"
    private var seasonNum: Int = 1
    private var episodeNum: Int = 1
    private var startPositionSec: Int = 0
    private var targetUrlString: String = ""
    private var allowedBrandLabel: String?
    private var lastPersistedSeconds: Double = -1000
    private var chromeHideWorkItem: DispatchWorkItem?
    private var isHandingOffToMini: Bool = false
    private var hasFinishedInitialLoad: Bool = false

    private static let messageHandlerName = "nightflixPlayerEvents"

    init(payloadJson: String, reusedWebView: WKWebView? = nil) {
        self.payloadJson = payloadJson
        self.reusedMiniWebView = reusedWebView
        super.init(nibName: nil, bundle: nil)
        parsePayload(payloadJson)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .landscape }
    override var preferredInterfaceOrientationForPresentation: UIInterfaceOrientation { .landscapeRight }
    override var shouldAutorotate: Bool { true }

    func applyExternalResolvedStream(url: String, sourceId: String) {
        guard !url.isEmpty, !url.lowercased().contains("vidly.pro"), let target = URL(string: url) else { return }
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            self.allowedBrandLabel = Self.brandLabel(of: target.host)
            self.hideFailure()
            self.showLoading(true)
            self.webView?.load(URLRequest(url: target))
        }
    }

    private func parsePayload(_ raw: String) {
        guard let data = raw.data(using: .utf8),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return }

        let rawTitle = (obj["title"] as? String) ?? currentTitle
        currentTitle = rawTitle.replacingOccurrences(of: #"\s*[·•\-]\s*S\d+E\d+.*$"#, with: "", options: .regularExpression).trimmingCharacters(in: .whitespacesAndNewlines)
        if currentTitle.isEmpty { currentTitle = rawTitle }

        episodeName = (obj["episodeName"] as? String) ?? ""
        progressKey = (obj["progressKey"] as? String) ?? ""
        tmdbId = String(describing: obj["tmdbId"] ?? "")
        if tmdbId == "<null>" || tmdbId == "nil" { tmdbId = "" }
        mediaType = ((obj["mediaType"] as? String) ?? "movie").lowercased()
        seasonNum = (obj["season"] as? Int) ?? (Int(String(describing: obj["season"] ?? "")) ?? 1)
        episodeNum = (obj["episode"] as? Int) ?? (Int(String(describing: obj["episode"] ?? "")) ?? 1)
        startPositionSec = (obj["startPositionSec"] as? Int) ?? (obj["startTimeSec"] as? Int) ?? 0

        let directUrl = (obj["url"] as? String) ?? ""
        let isLocal = (obj["isLocal"] as? Bool) ?? false

        if isLocal && !directUrl.isEmpty {
            targetUrlString = directUrl
            return
        }

        if !tmdbId.isEmpty {
            var base = mediaType == "tv"
                ? "https://vidfast.vc/tv/\(tmdbId)/\(seasonNum)/\(episodeNum)?autoPlay=true&theme=E50914&title=false&poster=true&chromecast=false&nextButton=true&autoNext=true"
                : "https://vidfast.vc/movie/\(tmdbId)?autoPlay=true&theme=E50914&title=false&poster=true&chromecast=false"
            if startPositionSec > 5 {
                base += "&startAt=\(startPositionSec)"
            }
            targetUrlString = base
        } else if !directUrl.isEmpty && !directUrl.lowercased().contains("vidly.pro") {
            targetUrlString = directUrl
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        activateAudioSession()
        setupWebView()
        setupTopBar()
        setupLoadingView()
        setupFailureView()
        showChrome()
        loadInitialUrl()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        forceLandscapeOrientation(true)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        chromeHideWorkItem?.cancel()
        if !isHandingOffToMini {
            cleanupWebView()
            deactivateAudioSession()
        }
        forceLandscapeOrientation(false)
    }

    private func setupWebView() {
        if let existing = reusedMiniWebView {
            reusedMiniWebView = nil
            existing.removeFromSuperview()
            existing.navigationDelegate = self
            existing.uiDelegate = self
            existing.frame = view.bounds
            existing.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            existing.isHidden = false
            existing.alpha = 1
            existing.isUserInteractionEnabled = true
            view.insertSubview(existing, at: 0)
            webView = existing
            return
        }

        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.allowsPictureInPictureMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.preferences.javaScriptCanOpenWindowsAutomatically = false
        config.applicationNameForUserAgent = "Version/18.0 Mobile/15E148 Safari/604.1"

        let ucc = config.userContentController
        ucc.add(WeakMessageHandler(self), name: Self.messageHandlerName)
        ucc.addUserScript(WKUserScript(source: Self.playerBridgeScript, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        ucc.addUserScript(WKUserScript(source: Self.resumeLoopGuardScript, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        ucc.addUserScript(WKUserScript(source: Self.hideFullscreenButtonScript, injectionTime: .atDocumentEnd, forMainFrameOnly: false))

        let wv = WKWebView(frame: view.bounds, configuration: config)
        wv.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        wv.navigationDelegate = self
        wv.uiDelegate = self
        wv.isOpaque = false
        wv.backgroundColor = .black
        wv.allowsBackForwardNavigationGestures = false
        wv.scrollView.backgroundColor = .black
        wv.scrollView.bounces = false
        wv.scrollView.isScrollEnabled = false
        wv.scrollView.contentInsetAdjustmentBehavior = .never
        view.addSubview(wv)
        webView = wv
    }

    private func setupTopBar() {
        let bar = UIView()
        bar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bar)

        let gradient = CAGradientLayer()
        gradient.colors = [
            UIColor.black.withAlphaComponent(0.72).cgColor,
            UIColor.black.withAlphaComponent(0.35).cgColor,
            UIColor.clear.cgColor
        ]
        gradient.frame = CGRect(x: 0, y: 0, width: 2000, height: 110)
        bar.layer.insertSublayer(gradient, at: 0)

        let lbl = UILabel()
        lbl.translatesAutoresizingMaskIntoConstraints = false
        lbl.textColor = .white
        lbl.font = .systemFont(ofSize: 15, weight: .semibold)
        lbl.textAlignment = .center
        lbl.lineBreakMode = .byTruncatingTail
        lbl.text = formattedTitleLine()
        lbl.layer.shadowColor = UIColor.black.cgColor
        lbl.layer.shadowOpacity = 0.6
        lbl.layer.shadowRadius = 6
        lbl.layer.shadowOffset = .zero
        bar.addSubview(lbl)
        titleLabel = lbl

        let closeBtn = UIButton(type: .system)
        closeBtn.translatesAutoresizingMaskIntoConstraints = false
        let xCfg = UIImage.SymbolConfiguration(pointSize: 19, weight: .semibold)
        closeBtn.setImage(UIImage(systemName: "xmark", withConfiguration: xCfg), for: .normal)
        closeBtn.tintColor = .white
        closeBtn.addTarget(self, action: #selector(handleClose), for: .touchUpInside)
        bar.addSubview(closeBtn)

        NSLayoutConstraint.activate([
            bar.topAnchor.constraint(equalTo: view.topAnchor),
            bar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            bar.heightAnchor.constraint(equalToConstant: 88),

            closeBtn.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 4),
            closeBtn.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -8),
            closeBtn.widthAnchor.constraint(equalToConstant: 44),
            closeBtn.heightAnchor.constraint(equalToConstant: 44),

            lbl.centerYAnchor.constraint(equalTo: closeBtn.centerYAnchor),
            lbl.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 72),
            lbl.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -72)
        ])

        topBarContainer = bar
    }

    private func setupLoadingView() {
        let box = UIView()
        box.translatesAutoresizingMaskIntoConstraints = false
        box.backgroundColor = .black
        box.isUserInteractionEnabled = false
        view.addSubview(box)

        let sp = UIActivityIndicatorView(style: .large)
        sp.translatesAutoresizingMaskIntoConstraints = false
        sp.color = UIColor(red: 229/255, green: 9/255, blue: 20/255, alpha: 1)
        sp.startAnimating()
        box.addSubview(sp)
        loadingSpinner = sp

        let lbl = UILabel()
        lbl.translatesAutoresizingMaskIntoConstraints = false
        lbl.text = currentTitle
        lbl.textColor = UIColor.white.withAlphaComponent(0.8)
        lbl.font = .systemFont(ofSize: 15, weight: .semibold)
        lbl.textAlignment = .center
        box.addSubview(lbl)

        NSLayoutConstraint.activate([
            box.topAnchor.constraint(equalTo: view.topAnchor),
            box.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            box.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            box.trailingAnchor.constraint(equalTo: view.trailingAnchor),

            sp.centerXAnchor.constraint(equalTo: box.centerXAnchor),
            sp.centerYAnchor.constraint(equalTo: box.centerYAnchor, constant: -14),

            lbl.topAnchor.constraint(equalTo: sp.bottomAnchor, constant: 18),
            lbl.leadingAnchor.constraint(equalTo: box.leadingAnchor, constant: 40),
            lbl.trailingAnchor.constraint(equalTo: box.trailingAnchor, constant: -40)
        ])

        loadingContainer = box
    }

    private func setupFailureView() {
        let overlay = UIView()
        overlay.translatesAutoresizingMaskIntoConstraints = false
        overlay.backgroundColor = UIColor.black.withAlphaComponent(0.82)
        overlay.isHidden = true
        view.addSubview(overlay)

        let stack = UIStackView()
        stack.translatesAutoresizingMaskIntoConstraints = false
        stack.axis = .vertical
        stack.alignment = .center
        stack.spacing = 12
        overlay.addSubview(stack)

        let icon = UIImageView(image: UIImage(systemName: "exclamationmark.triangle.fill"))
        icon.tintColor = UIColor(red: 229/255, green: 9/255, blue: 20/255, alpha: 1)
        icon.preferredSymbolConfiguration = UIImage.SymbolConfiguration(pointSize: 26, weight: .semibold)
        stack.addArrangedSubview(icon)

        let tLbl = UILabel()
        tLbl.text = "The player didn't load"
        tLbl.textColor = .white
        tLbl.font = .systemFont(ofSize: 19, weight: .bold)
        stack.addArrangedSubview(tLbl)
        failureTitleLabel = tLbl

        let mLbl = UILabel()
        mLbl.textColor = UIColor.white.withAlphaComponent(0.7)
        mLbl.font = .systemFont(ofSize: 14)
        mLbl.numberOfLines = 0
        mLbl.textAlignment = .center
        stack.addArrangedSubview(mLbl)
        failureMessageLabel = mLbl

        let btns = UIStackView()
        btns.axis = .horizontal
        btns.distribution = .fillEqually
        btns.spacing = 10
        btns.translatesAutoresizingMaskIntoConstraints = false

        let closeB = UIButton(type: .system)
        closeB.setTitle("Close", for: .normal)
        closeB.setTitleColor(.white, for: .normal)
        closeB.titleLabel?.font = .systemFont(ofSize: 15, weight: .semibold)
        closeB.backgroundColor = UIColor.white.withAlphaComponent(0.16)
        closeB.layer.cornerRadius = 6
        closeB.addTarget(self, action: #selector(handleClose), for: .touchUpInside)

        let retryB = UIButton(type: .system)
        retryB.setTitle("Try Again", for: .normal)
        retryB.setTitleColor(.black, for: .normal)
        retryB.titleLabel?.font = .systemFont(ofSize: 15, weight: .semibold)
        retryB.backgroundColor = .white
        retryB.layer.cornerRadius = 6
        retryB.addTarget(self, action: #selector(handleRetry), for: .touchUpInside)

        btns.addArrangedSubview(closeB)
        btns.addArrangedSubview(retryB)
        stack.addArrangedSubview(btns)

        NSLayoutConstraint.activate([
            overlay.topAnchor.constraint(equalTo: view.topAnchor),
            overlay.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            overlay.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            overlay.trailingAnchor.constraint(equalTo: view.trailingAnchor),

            stack.centerXAnchor.constraint(equalTo: overlay.centerXAnchor),
            stack.centerYAnchor.constraint(equalTo: overlay.centerYAnchor),
            stack.widthAnchor.constraint(lessThanOrEqualToConstant: 380),
            stack.leadingAnchor.constraint(greaterThanOrEqualTo: overlay.leadingAnchor, constant: 24),
            stack.trailingAnchor.constraint(lessThanOrEqualTo: overlay.trailingAnchor, constant: -24),

            btns.widthAnchor.constraint(equalToConstant: 280),
            btns.heightAnchor.constraint(equalToConstant: 42)
        ])

        failureContainer = overlay
    }

    private func loadInitialUrl() {
        guard !targetUrlString.isEmpty, let url = URL(string: targetUrlString) else {
            showFailure(title: "Not available right now", message: "No playable stream URL was provided for this title.")
            return
        }
        hasFinishedInitialLoad = false
        allowedBrandLabel = Self.brandLabel(of: url.host)
        showLoading(true)
        hideFailure()
        var req = URLRequest(url: url, cachePolicy: .reloadIgnoringLocalCacheData, timeoutInterval: 45)
        req.setValue("https://vidfast.vc/", forHTTPHeaderField: "Referer")
        webView?.load(req)
    }

    private func formattedTitleLine() -> String {
        if mediaType == "tv" {
            if !episodeName.isEmpty {
                return "\(currentTitle)  S\(seasonNum):E\(episodeNum) “\(episodeName)”"
            }
            return "\(currentTitle)  S\(seasonNum):E\(episodeNum)"
        }
        return currentTitle
    }

    private func showChrome() {
        chromeHideWorkItem?.cancel()
        UIView.animate(withDuration: 0.25) {
            self.topBarContainer.alpha = 1
        }
        let work = DispatchWorkItem { [weak self] in
            guard let self else { return }
            UIView.animate(withDuration: 0.25) {
                self.topBarContainer.alpha = 0
            }
        }
        chromeHideWorkItem = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.5, execute: work)
    }

    private func showLoading(_ show: Bool) {
        UIView.animate(withDuration: 0.25) {
            self.loadingContainer.alpha = show ? 1 : 0
        }
        if show { loadingSpinner.startAnimating() } else { loadingSpinner.stopAnimating() }
    }

    private func showFailure(title: String, message: String) {
        showLoading(false)
        failureTitleLabel.text = title
        failureMessageLabel.text = message
        failureContainer.isHidden = false
    }

    private func hideFailure() {
        failureContainer.isHidden = true
    }

    @objc private func handleClose() {
        dismiss(animated: true)
    }

    @objc private func handleRetry() {
        loadInitialUrl()
    }

    private func cleanupWebView() {
        guard let wv = webView else { return }
        wv.stopLoading()
        if #available(iOS 15.0, *) {
            wv.pauseAllMediaPlayback(completionHandler: nil)
        }
        wv.configuration.userContentController.removeScriptMessageHandler(forName: Self.messageHandlerName)
        wv.navigationDelegate = nil
        wv.uiDelegate = nil
        webView = nil
    }

    private func activateAudioSession() {
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback, mode: .moviePlayback)
        try? session.setActive(true)
    }

    private func deactivateAudioSession() {
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }

    private func forceLandscapeOrientation(_ landscape: Bool) {
        if #available(iOS 16.0, *) {
            setNeedsUpdateOfSupportedInterfaceOrientations()
            if let scene = view.window?.windowScene {
                let prefs = UIWindowScene.GeometryPreferences.iOS(interfaceOrientations: landscape ? .landscapeRight : .portrait)
                scene.requestGeometryUpdate(prefs, errorHandler: nil)
            }
        }
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let root = message.body as? [String: Any] else { return }
        if (root["type"] as? String) == "NIGHTFLIX_INTERACTION" {
            DispatchQueue.main.async { [weak self] in self?.showChrome() }
            return
        }
        if (root["event"] as? String) == "status" {
            return
        }

        let payload = (root["type"] as? String) == "PLAYER_EVENT" ? (root["data"] as? [String: Any] ?? root) : root
        let ct = Self.doubleVal(payload["currentTime"] ?? payload["timestamp"]) ?? 0
        let dur = Self.doubleVal(payload["duration"]) ?? 0
        let eventName = ((payload["event"] as? String) ?? "").lowercased()

        if mediaType == "tv" {
            if let s = payload["season"] as? Int { seasonNum = s }
            if let e = payload["episode"] as? Int { episodeNum = e }
            DispatchQueue.main.async { [weak self] in
                guard let self else { return }
                self.titleLabel.text = self.formattedTitleLine()
            }
        }

        guard ct > 0 else { return }
        let isDiscrete = (eventName == "pause" || eventName == "seeked" || eventName == "ended")
        if !isDiscrete && abs(ct - lastPersistedSeconds) < 5 { return }
        lastPersistedSeconds = ct

        let pct: Int = dur > 0 ? min(100, max(1, Int((ct / dur) * 100))) : 1
        let watched = eventName == "ended" || (dur > 0 && (ct / dur) >= 0.95)
        let playing = eventName != "pause" && !watched
        let key = mediaType == "tv" ? "tv_\(tmdbId)_s\(seasonNum)e\(episodeNum)" : (progressKey.isEmpty ? "movie_\(tmdbId)" : progressKey)

        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            self.hideFailure()
            self.showLoading(false)
            self.onProgressUpdate?(key, pct, Int(ct), Int(dur), watched, playing)
        }
    }

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        if !hasFinishedInitialLoad {
            showLoading(true)
        }
        hideFailure()
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        hasFinishedInitialLoad = true
        showLoading(false)
        hideFailure()
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let targetFrame = navigationAction.targetFrame else {
            decisionHandler(.cancel)
            return
        }
        if targetFrame.isMainFrame,
           let host = navigationAction.request.url?.host,
           let allowedBrandLabel,
           Self.brandLabel(of: host) != allowedBrandLabel {
            onBlockedAd?(navigationAction.request.url?.absoluteString ?? host)
            decisionHandler(.cancel)
            return
        }
        decisionHandler(.allow)
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        return nil
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        handleNavError(error)
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        handleNavError(error)
    }

    private func handleNavError(_ error: Error) {
        let nsErr = error as NSError
        if (nsErr.domain == NSURLErrorDomain && (nsErr.code == NSURLErrorCancelled || nsErr.code == NSURLErrorTimedOut)) || (nsErr.domain == "WebKitErrorDomain" && (nsErr.code == 102 || nsErr.code == 101)) {
            showLoading(false)
            return
        }
        if hasFinishedInitialLoad {
            showLoading(false)
            return
        }
        showFailure(title: "The player didn't load", message: error.localizedDescription)
    }

    private static func brandLabel(of host: String?) -> String? {
        guard let host else { return nil }
        let labels = host.lowercased().split(separator: ".")
        guard labels.count >= 2 else { return labels.first.map(String.init) }
        return String(labels[labels.count - 2])
    }

    private static func doubleVal(_ raw: Any?) -> Double? {
        if let d = raw as? Double { return d }
        if let i = raw as? Int { return Double(i) }
        if let s = raw as? String { return Double(s) }
        return nil
    }

    private final class WeakMessageHandler: NSObject, WKScriptMessageHandler {
        weak var delegate: WKScriptMessageHandler?
        init(_ delegate: WKScriptMessageHandler) { self.delegate = delegate }
        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            delegate?.userContentController(userContentController, didReceive: message)
        }
    }

    private static let playerBridgeScript = """
    (function () {
        var handlers = window.webkit && window.webkit.messageHandlers;
        var channel = handlers && handlers.nightflixPlayerEvents;
        if (!channel) { return; }

        function post(payload) {
            try { channel.postMessage(payload); } catch (e) {}
        }

        function normalize(raw) {
            var payload = raw;
            if (typeof raw === "string") {
                try { payload = JSON.parse(raw); } catch (e) { return null; }
            }
            if (!payload || typeof payload !== "object") { return null; }
            return payload;
        }

        function shouldForward(payload) {
            if (payload.type === "PLAYER_EVENT") {
                return !!payload.data && typeof payload.data === "object";
            }
            if (payload.event === "status") { return true; }
            var hasPosition = payload.timestamp !== undefined || payload.progress !== undefined;
            var hasIdentity = payload.id !== undefined || payload.type !== undefined;
            return hasPosition && hasIdentity;
        }

        window.addEventListener("message", function (event) {
            var payload = normalize(event.data);
            if (!payload || !shouldForward(payload)) { return; }
            try { post(JSON.parse(JSON.stringify(payload))); } catch (e) {}
        }, false);

        var lastTouch = 0;
        function reportInteraction() {
            var now = Date.now();
            if (now - lastTouch < 350) { return; }
            lastTouch = now;
            post({ type: "NIGHTFLIX_INTERACTION" });
        }
        document.addEventListener("touchstart", reportInteraction, { capture: true, passive: true });
        document.addEventListener("mousedown", reportInteraction, { capture: true, passive: true });
    })();
    """

    private static let resumeLoopGuardScript = """
    (function () {
        var params = new URLSearchParams(window.location.search);
        var raw = params.get("startAt") || params.get("progress");
        var resumeTime = raw ? parseFloat(raw) : NaN;
        if (!(resumeTime > 0)) { return; }

        var proto = window.HTMLMediaElement && HTMLMediaElement.prototype;
        var descriptor = proto && Object.getOwnPropertyDescriptor(proto, "currentTime");
        if (!descriptor || !descriptor.get || !descriptor.set) { return; }

        function guard(video) {
            if (!video || video.__nightflixResumeGuarded) { return; }
            video.__nightflixResumeGuarded = true;

            var furthest = 0;
            var everResumed = false;

            video.addEventListener("timeupdate", function () {
                var t = descriptor.get.call(video);
                if (t > furthest) { furthest = t; }
            });

            Object.defineProperty(video, "currentTime", {
                configurable: true,
                get: function () { return descriptor.get.call(this); },
                set: function (value) {
                    if (value === resumeTime) {
                        var current = descriptor.get.call(this);
                        if (!everResumed) {
                            everResumed = true;
                            descriptor.set.call(this, Math.max(resumeTime, furthest));
                            return;
                        }
                        if (current < furthest - 5) {
                            descriptor.set.call(this, Math.max(resumeTime, furthest));
                        }
                        return;
                    }
                    descriptor.set.call(this, value);
                }
            });
        }

        function guardAll() {
            var videos = document.getElementsByTagName("video");
            for (var i = 0; i < videos.length; i++) { guard(videos[i]); }
        }

        guardAll();
        if (window.MutationObserver) {
            new MutationObserver(guardAll).observe(document.documentElement, {
                childList: true,
                subtree: true
            });
        }
    })();
    """

    private static let hideFullscreenButtonScript = """
    (function () {
        if (window.__sgHideFsInstalled) { return; }
        window.__sgHideFsInstalled = 1;
        try {
            var style = document.createElement("style");
            style.id = "__sgHideFsStyle";
            style.textContent = [
                'button[aria-label*="fullscreen" i]',
                'button[title*="fullscreen" i]',
                '[data-tooltip*="fullscreen" i]',
                'button[class*="fullscreen" i]',
                '[data-testid*="fullscreen" i]',
                '.vjs-fullscreen-control',
                '.plyr__control[data-plyr="fullscreen"]',
                '.jw-icon-fullscreen'
            ].join(",") + "{display:none!important;visibility:hidden!important;opacity:0!important;pointer-events:none!important;width:0!important;height:0!important;margin:0!important;padding:0!important;}";
            (document.head || document.documentElement).appendChild(style);
        } catch (e) {}

        function hideFsButtons() {
            try {
                var btns = document.querySelectorAll("button, [role='button']");
                var vw = window.innerWidth || 800;
                var vh = window.innerHeight || 400;
                for (var i = 0; i < btns.length; i++) {
                    var b = btns[i];
                    if (b.dataset && b.dataset.sgFsHidden) continue;
                    var lbl = ((b.getAttribute("aria-label") || "") + " " + (b.getAttribute("title") || "") + " " + (b.getAttribute("data-tooltip") || "") + " " + (b.className || "")).toLowerCase();
                    if (lbl.indexOf("fullscreen") !== -1 || lbl.indexOf("full screen") !== -1 || lbl.indexOf("maximize") !== -1) {
                        b.style.setProperty("display", "none", "important");
                        if (b.dataset) b.dataset.sgFsHidden = "1";
                        continue;
                    }
                    var r = b.getBoundingClientRect();
                    if (r.width > 12 && r.width < 68 && r.height > 12 && r.height < 68 && r.right >= vw - 58 && r.bottom >= vh - 76) {
                        var svg = b.querySelector("svg");
                        if (svg) {
                            var h = (svg.innerHTML || "").toLowerCase();
                            var looksFs = h.indexOf("m8 3h5") !== -1 || h.indexOf("m15 3h6") !== -1 || h.indexOf("m21 15v4") !== -1 || h.indexOf("m3 8v-3") !== -1 || h.indexOf("m4 8v") !== -1 || h.indexOf("m7 14h5") !== -1 || (b.nextElementSibling === null && r.right >= vw - 44);
                            if (looksFs) {
                                b.style.setProperty("display", "none", "important");
                                if (b.dataset) b.dataset.sgFsHidden = "1";
                            }
                        }
                    }
                }
            } catch (e) {}
        }

        hideFsButtons();
        setInterval(hideFsButtons, 900);
        if (window.MutationObserver) {
            try {
                new MutationObserver(hideFsButtons).observe(document.documentElement, { childList: true, subtree: true });
            } catch (e) {}
        }
    })();
    """
}
