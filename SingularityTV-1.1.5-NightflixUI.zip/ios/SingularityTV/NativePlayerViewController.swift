import UIKit
import AVFoundation
import WebKit

class NativePlayerViewController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate {
    private let payloadJson: String
    private var reusedMiniWebView: WKWebView?

    var onProgressUpdate: ((String, Int, Int, Int, Bool, Bool) -> Void)?
    var onSubtitleStyleChanged: ((String, String, Double) -> Void)?
    var onWebPrefsUpdate: ((String) -> Void)?
    var onPreferredSource: ((String) -> Void)?
    var onBlockedAd: ((String) -> Void)?
    var onMinimizeToMiniPiP: ((WKWebView, String) -> Void)?

    private var webView: WKWebView?
    private var topBarContainer: UIView!
    private var titleLabel: UILabel!
    private var loadingContainer: UIView!
    private var loadingSpinner: UIActivityIndicatorView!
    private var failureContainer: UIView!
    private var failureTitleLabel: UILabel!
    private var failureMessageLabel: UILabel!

    private var currentTitle: String = "SingularityTV"
    private var currentSubtitle: String = ""
    private var progressKey: String = ""
    private var tmdbId: String = ""
    private var mediaType: String = "movie"
    private var seasonNum: Int = 1
    private var episodeNum: Int = 1
    private var startPositionSec: Int = 0
    private var targetUrlString: String = ""
    private var allowedBrandLabel: String?
    private var lastPersistedSeconds: Double = -1000
    private var chromeHideWorkItem: DispatchWorkItem?
    private var isChromeVisible: Bool = true
    private var isHandingOffToMini: Bool = false

    private static let messageHandlerName = "nightflixPlayerEvents"

    init(payloadJson: String, reusedWebView: WKWebView? = nil) {
        self.payloadJson = payloadJson
        self.reusedMiniWebView = reusedWebView
        super.init(nibName: nil, bundle: nil)
        parsePayload(payloadJson)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .landscape }
    override var preferredInterfaceOrientationForPresentation: UIInterfaceOrientation { .landscapeRight }
    override var shouldAutorotate: Bool { true }

    func applyExternalResolvedStream(url: String, sourceId: String) {
        guard !url.isEmpty, let target = URL(string: url) else { return }
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            self.allowedBrandLabel = Self.brandLabel(of: target.host)
            self.hideFailure()
            self.showLoading(true)
            self.webView?.load(URLRequest(url: target))
        }
    }

    private func parsePayload(_ raw: String) {
        guard let data = raw.data(using: .utf8),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return }
        currentTitle = (obj["title"] as? String) ?? currentTitle
        currentSubtitle = (obj["subtitle"] as? String) ?? ""
        progressKey = (obj["progressKey"] as? String) ?? ""
        tmdbId = String(describing: obj["tmdbId"] ?? "")
        if tmdbId == "<null>" { tmdbId = "" }
        mediaType = (obj["mediaType"] as? String) ?? "movie"
        seasonNum = (obj["season"] as? Int) ?? (Int(String(describing: obj["season"] ?? "")) ?? 1)
        episodeNum = (obj["episode"] as? Int) ?? (Int(String(describing: obj["episode"] ?? "")) ?? 1)
        startPositionSec = (obj["startPositionSec"] as? Int) ?? (obj["startTimeSec"] as? Int) ?? 0

        let directUrl = (obj["url"] as? String) ?? ""
        let movieTpl = (obj["embedMovieTemplate"] as? String) ?? "https://vidfast.vc/movie/{TMDBID}?autoPlay=true&theme=E50914&title=false&poster=true&chromecast=false"
        let tvTpl = (obj["embedTvTemplate"] as? String) ?? "https://vidfast.vc/tv/{TMDBID}/{SEASON}/{EPISODE}?autoPlay=true&theme=E50914&title=false&poster=true&chromecast=false&nextButton=true&autoNext=true"

        if !directUrl.isEmpty && (directUrl.hasPrefix("http://") || directUrl.hasPrefix("https://")) {
            targetUrlString = directUrl
        } else if !tmdbId.isEmpty {
            let tpl = mediaType == "tv" ? tvTpl : movieTpl
            var built = tpl
                .replacingOccurrences(of: "{TMDBID}", with: tmdbId)
                .replacingOccurrences(of: "{SEASON}", with: String(seasonNum))
                .replacingOccurrences(of: "{EPISODE}", with: String(episodeNum))
            if startPositionSec > 5 && !built.contains("startAt=") && !built.contains("progress=") {
                built += (built.contains("?") ? "&" : "?") + "startAt=\(startPositionSec)"
            }
            targetUrlString = built
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        activateAudioSession()
        setupWebView()
        setupTopBar()
        setupLoadingView()
        setupFailureView()
        showChrome()
        loadInitialUrl()
    }

    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        forceLandscapeOrientation(true)
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        chromeHideWorkItem?.cancel()
        if !isHandingOffToMini {
            cleanupWebView()
            deactivateAudioSession()
        }
        forceLandscapeOrientation(false)
    }

    private func setupWebView() {
        if let existing = reusedMiniWebView {
            reusedMiniWebView = nil
            existing.removeFromSuperview()
            existing.navigationDelegate = self
            existing.uiDelegate = self
            existing.frame = view.bounds
            existing.autoresizingMask = [.flexibleWidth, .flexibleHeight]
            existing.isHidden = false
            existing.alpha = 1
            existing.isUserInteractionEnabled = true
            view.insertSubview(existing, at: 0)
            webView = existing
            return
        }

        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.allowsPictureInPictureMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.preferences.javaScriptCanOpenWindowsAutomatically = false
        config.applicationNameForUserAgent = "Version/18.0 Mobile/15E148 Safari/604.1"

        let ucc = config.userContentController
        ucc.add(WeakMessageHandler(self), name: Self.messageHandlerName)
        ucc.addUserScript(WKUserScript(source: Self.playerBridgeScript, injectionTime: .atDocumentStart, forMainFrameOnly: true))
        ucc.addUserScript(WKUserScript(source: Self.resumeLoopGuardScript, injectionTime: .atDocumentStart, forMainFrameOnly: true))

        let wv = WKWebView(frame: view.bounds, configuration: config)
        wv.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        wv.navigationDelegate = self
        wv.uiDelegate = self
        wv.isOpaque = false
        wv.backgroundColor = .black
        wv.allowsBackForwardNavigationGestures = false
        wv.scrollView.backgroundColor = .black
        wv.scrollView.bounces = false
        wv.scrollView.isScrollEnabled = false
        wv.scrollView.contentInsetAdjustmentBehavior = .never
        view.addSubview(wv)
        webView = wv
    }

    private func setupTopBar() {
        let bar = UIView()
        bar.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(bar)

        let gradient = CAGradientLayer()
        gradient.colors = [
            UIColor.black.withAlphaComponent(0.75).cgColor,
            UIColor.black.withAlphaComponent(0.35).cgColor,
            UIColor.clear.cgColor
        ]
        gradient.frame = CGRect(x: 0, y: 0, width: 2000, height: 100)
        bar.layer.insertSublayer(gradient, at: 0)

        let lbl = UILabel()
        lbl.translatesAutoresizingMaskIntoConstraints = false
        lbl.textColor = .white
        lbl.font = .systemFont(ofSize: 15, weight: .semibold)
        lbl.textAlignment = .center
        lbl.lineBreakMode = .byTruncatingTail
        lbl.text = formattedTitleLine()
        lbl.layer.shadowColor = UIColor.black.cgColor
        lbl.layer.shadowOpacity = 0.65
        lbl.layer.shadowRadius = 6
        lbl.layer.shadowOffset = .zero
        bar.addSubview(lbl)
        titleLabel = lbl

        let closeBtn = UIButton(type: .system)
        closeBtn.translatesAutoresizingMaskIntoConstraints = false
        let xCfg = UIImage.SymbolConfiguration(pointSize: 18, weight: .semibold)
        closeBtn.setImage(UIImage(systemName: "xmark", withConfiguration: xCfg), for: .normal)
        closeBtn.tintColor = .white
        closeBtn.addTarget(self, action: #selector(handleClose), for: .touchUpInside)
        bar.addSubview(closeBtn)

        let pipBtn = UIButton(type: .system)
        pipBtn.translatesAutoresizingMaskIntoConstraints = false
        let pCfg = UIImage.SymbolConfiguration(pointSize: 16, weight: .semibold)
        pipBtn.setImage(UIImage(systemName: "pip.enter", withConfiguration: pCfg), for: .normal)
        pipBtn.tintColor = .white
        pipBtn.addTarget(self, action: #selector(handleMinimizePiP), for: .touchUpInside)
        bar.addSubview(pipBtn)

        NSLayoutConstraint.activate([
            bar.topAnchor.constraint(equalTo: view.topAnchor),
            bar.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            bar.trailingAnchor.constraint(equalTo: view.trailingAnchor),
            bar.heightAnchor.constraint(equalToConstant: 86),

            closeBtn.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 6),
            closeBtn.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -10),
            closeBtn.widthAnchor.constraint(equalToConstant: 44),
            closeBtn.heightAnchor.constraint(equalToConstant: 44),

            pipBtn.centerYAnchor.constraint(equalTo: closeBtn.centerYAnchor),
            pipBtn.trailingAnchor.constraint(equalTo: closeBtn.leadingAnchor, constant: -4),
            pipBtn.widthAnchor.constraint(equalToConstant: 40),
            pipBtn.heightAnchor.constraint(equalToConstant: 40),

            lbl.centerYAnchor.constraint(equalTo: closeBtn.centerYAnchor),
            lbl.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 72),
            lbl.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -98)
        ])

        topBarContainer = bar
    }

    private func setupLoadingView() {
        let box = UIView()
        box.translatesAutoresizingMaskIntoConstraints = false
        box.backgroundColor = .black
        box.isUserInteractionEnabled = false
        view.addSubview(box)

        let sp = UIActivityIndicatorView(style: .large)
        sp.translatesAutoresizingMaskIntoConstraints = false
        sp.color = UIColor(red: 229/255, green: 9/255, blue: 20/255, alpha: 1)
        sp.startAnimating()
        box.addSubview(sp)
        loadingSpinner = sp

        let lbl = UILabel()
        lbl.translatesAutoresizingMaskIntoConstraints = false
        lbl.text = currentTitle
        lbl.textColor = UIColor.white.withAlphaComponent(0.8)
        lbl.font = .systemFont(ofSize: 15, weight: .semibold)
        lbl.textAlignment = .center
        box.addSubview(lbl)

        NSLayoutConstraint.activate([
            box.topAnchor.constraint(equalTo: view.topAnchor),
            box.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            box.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            box.trailingAnchor.constraint(equalTo: view.trailingAnchor),

            sp.centerXAnchor.constraint(equalTo: box.centerXAnchor),
            sp.centerYAnchor.constraint(equalTo: box.centerYAnchor, constant: -12),

            lbl.topAnchor.constraint(equalTo: sp.bottomAnchor, constant: 16),
            lbl.leadingAnchor.constraint(equalTo: box.leadingAnchor, constant: 40),
            lbl.trailingAnchor.constraint(equalTo: box.trailingAnchor, constant: -40)
        ])

        loadingContainer = box
    }

    private func setupFailureView() {
        let overlay = UIView()
        overlay.translatesAutoresizingMaskIntoConstraints = false
        overlay.backgroundColor = UIColor.black.withAlphaComponent(0.85)
        overlay.isHidden = true
        view.addSubview(overlay)

        let stack = UIStackView()
        stack.translatesAutoresizingMaskIntoConstraints = false
        stack.axis = .vertical
        stack.alignment = .center
        stack.spacing = 12
        overlay.addSubview(stack)

        let icon = UIImageView(image: UIImage(systemName: "exclamationmark.triangle.fill"))
        icon.tintColor = UIColor(red: 229/255, green: 9/255, blue: 20/255, alpha: 1)
        icon.preferredSymbolConfiguration = UIImage.SymbolConfiguration(pointSize: 28, weight: .semibold)
        stack.addArrangedSubview(icon)

        let tLbl = UILabel()
        tLbl.text = "The player didn't load"
        tLbl.textColor = .white
        tLbl.font = .systemFont(ofSize: 19, weight: .bold)
        stack.addArrangedSubview(tLbl)
        failureTitleLabel = tLbl

        let mLbl = UILabel()
        mLbl.textColor = UIColor.white.withAlphaComponent(0.72)
        mLbl.font = .systemFont(ofSize: 14)
        mLbl.numberOfLines = 0
        mLbl.textAlignment = .center
        stack.addArrangedSubview(mLbl)
        failureMessageLabel = mLbl

        let btns = UIStackView()
        btns.axis = .horizontal
        btns.distribution = .fillEqually
        btns.spacing = 10
        btns.translatesAutoresizingMaskIntoConstraints = false

        let closeB = UIButton(type: .system)
        closeB.setTitle("Close", for: .normal)
        closeB.setTitleColor(.white, for: .normal)
        closeB.titleLabel?.font = .systemFont(ofSize: 15, weight: .semibold)
        closeB.backgroundColor = UIColor.white.withAlphaComponent(0.16)
        closeB.layer.cornerRadius = 6
        closeB.addTarget(self, action: #selector(handleClose), for: .touchUpInside)

        let retryB = UIButton(type: .system)
        retryB.setTitle("Try Again", for: .normal)
        retryB.setTitleColor(.black, for: .normal)
        retryB.titleLabel?.font = .systemFont(ofSize: 15, weight: .semibold)
        retryB.backgroundColor = .white
        retryB.layer.cornerRadius = 6
        retryB.addTarget(self, action: #selector(handleRetry), for: .touchUpInside)

        btns.addArrangedSubview(closeB)
        btns.addArrangedSubview(retryB)
        stack.addArrangedSubview(btns)

        NSLayoutConstraint.activate([
            overlay.topAnchor.constraint(equalTo: view.topAnchor),
            overlay.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            overlay.leadingAnchor.constraint(equalTo: view.leadingAnchor),
            overlay.trailingAnchor.constraint(equalTo: view.trailingAnchor),

            stack.centerXAnchor.constraint(equalTo: overlay.centerXAnchor),
            stack.centerYAnchor.constraint(equalTo: overlay.centerYAnchor),
            stack.widthAnchor.constraint(lessThanOrEqualToConstant: 360),
            stack.leadingAnchor.constraint(greaterThanOrEqualTo: overlay.leadingAnchor, constant: 24),
            stack.trailingAnchor.constraint(lessThanOrEqualTo: overlay.trailingAnchor, constant: -24),

            btns.widthAnchor.constraint(equalToConstant: 280),
            btns.heightAnchor.constraint(equalToConstant: 42)
        ])

        failureContainer = overlay
    }

    private func loadInitialUrl() {
        guard !targetUrlString.isEmpty, let url = URL(string: targetUrlString) else {
            showFailure(title: "Not available right now", message: "No playable stream URL was provided for this title.")
            return
        }
        allowedBrandLabel = Self.brandLabel(of: url.host)
        showLoading(true)
        hideFailure()
        webView?.load(URLRequest(url: url))
    }

    private func formattedTitleLine() -> String {
        if mediaType == "tv" {
            if !currentSubtitle.isEmpty {
                return "\(currentTitle)  \(currentSubtitle)"
            }
            return "\(currentTitle)  S\(seasonNum):E\(episodeNum)"
        }
        return currentTitle
    }

    private func showChrome() {
        chromeHideWorkItem?.cancel()
        isChromeVisible = true
        UIView.animate(withDuration: 0.22) {
            self.topBarContainer.alpha = 1
        }
        let work = DispatchWorkItem { [weak self] in
            guard let self else { return }
            self.isChromeVisible = false
            UIView.animate(withDuration: 0.25) {
                self.topBarContainer.alpha = 0
            }
        }
        chromeHideWorkItem = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 3.5, execute: work)
    }

    private func showLoading(_ show: Bool) {
        UIView.animate(withDuration: 0.25) {
            self.loadingContainer.alpha = show ? 1 : 0
        }
        if show { loadingSpinner.startAnimating() } else { loadingSpinner.stopAnimating() }
    }

    private func showFailure(title: String, message: String) {
        showLoading(false)
        failureTitleLabel.text = title
        failureMessageLabel.text = message
        failureContainer.isHidden = false
    }

    private func hideFailure() {
        failureContainer.isHidden = true
    }

    @objc private func handleClose() {
        dismiss(animated: true)
    }

    @objc private func handleRetry() {
        loadInitialUrl()
    }

    @objc private func handleMinimizePiP() {
        guard let wv = webView, let cb = onMinimizeToMiniPiP else {
            dismiss(animated: true)
            return
        }
        isHandingOffToMini = true
        dismiss(animated: true) {
            cb(wv, self.payloadJson)
        }
    }

    private func cleanupWebView() {
        guard let wv = webView else { return }
        wv.stopLoading()
        if #available(iOS 15.0, *) {
            wv.pauseAllMediaPlayback(completionHandler: nil)
        }
        wv.configuration.userContentController.removeScriptMessageHandler(forName: Self.messageHandlerName)
        wv.navigationDelegate = nil
        wv.uiDelegate = nil
        webView = nil
    }

    private func activateAudioSession() {
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback, mode: .moviePlayback)
        try? session.setActive(true)
    }

    private func deactivateAudioSession() {
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }

    private func forceLandscapeOrientation(_ landscape: Bool) {
        if #available(iOS 16.0, *) {
            setNeedsUpdateOfSupportedInterfaceOrientations()
            if let scene = view.window?.windowScene {
                let prefs = UIWindowScene.GeometryPreferences.iOS(interfaceOrientations: landscape ? .landscapeRight : .portrait)
                scene.requestGeometryUpdate(prefs, errorHandler: nil)
            }
        }
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let root = message.body as? [String: Any] else { return }
        if (root["type"] as? String) == "NIGHTFLIX_INTERACTION" {
            DispatchQueue.main.async { [weak self] in self?.showChrome() }
            return
        }
        if (root["event"] as? String) == "status", let code = root["data"] as? Int, code >= 400 {
            DispatchQueue.main.async { [weak self] in
                self?.showFailure(
                    title: "Not available right now",
                    message: "None of the player's servers could stream this title. Try again in a little while."
                )
            }
            return
        }

        let payload = (root["type"] as? String) == "PLAYER_EVENT" ? (root["data"] as? [String: Any] ?? root) : root
        let ct = Self.doubleVal(payload["currentTime"] ?? payload["timestamp"]) ?? 0
        let dur = Self.doubleVal(payload["duration"]) ?? 0
        let eventName = ((payload["event"] as? String) ?? "").lowercased()

        guard ct > 0 else { return }
        let isDiscrete = (eventName == "pause" || eventName == "seeked" || eventName == "ended")
        if !isDiscrete && abs(ct - lastPersistedSeconds) < 5 { return }
        lastPersistedSeconds = ct

        let pct: Int = dur > 0 ? min(100, max(1, Int((ct / dur) * 100))) : 1
        let watched = eventName == "ended" || (dur > 0 && (ct / dur) >= 0.95)
        let playing = eventName != "pause" && !watched
        let key = progressKey.isEmpty ? (mediaType == "tv" ? "tv_\(tmdbId)_s\(seasonNum)e\(episodeNum)" : "movie_\(tmdbId)") : progressKey

        DispatchQueue.main.async { [weak self] in
            self?.onProgressUpdate?(key, pct, Int(ct), Int(dur), watched, playing)
        }
    }

    func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
        showLoading(true)
        hideFailure()
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        showLoading(false)
    }

    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        guard let targetFrame = navigationAction.targetFrame else {
            decisionHandler(.cancel)
            return
        }
        if targetFrame.isMainFrame,
           let host = navigationAction.request.url?.host,
           let allowedBrandLabel,
           Self.brandLabel(of: host) != allowedBrandLabel {
            onBlockedAd?(navigationAction.request.url?.absoluteString ?? host)
            decisionHandler(.cancel)
            return
        }
        decisionHandler(.allow)
    }

    func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
        return nil
    }

    func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
        handleNavError(error)
    }

    func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
        handleNavError(error)
    }

    private func handleNavError(_ error: Error) {
        let nsErr = error as NSError
        if (nsErr.domain == NSURLErrorDomain && nsErr.code == NSURLErrorCancelled) || (nsErr.domain == "WebKitErrorDomain" && nsErr.code == 102) {
            return
        }
        showFailure(title: "The player didn't load", message: error.localizedDescription)
    }

    private static func brandLabel(of host: String?) -> String? {
        guard let host else { return nil }
        let labels = host.lowercased().split(separator: ".")
        guard labels.count >= 2 else { return labels.first.map(String.init) }
        return String(labels[labels.count - 2])
    }

    private static func doubleVal(_ raw: Any?) -> Double? {
        if let d = raw as? Double { return d }
        if let i = raw as? Int { return Double(i) }
        if let s = raw as? String { return Double(s) }
        return nil
    }

    private final class WeakMessageHandler: NSObject, WKScriptMessageHandler {
        weak var delegate: WKScriptMessageHandler?
        init(_ delegate: WKScriptMessageHandler) { self.delegate = delegate }
        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            delegate?.userContentController(userContentController, didReceive: message)
        }
    }

    private static let playerBridgeScript = """
    (function () {
        var handlers = window.webkit && window.webkit.messageHandlers;
        var channel = handlers && handlers.nightflixPlayerEvents;
        if (!channel) { return; }

        function post(payload) {
            try { channel.postMessage(payload); } catch (e) {}
        }

        function normalize(raw) {
            var payload = raw;
            if (typeof raw === "string") {
                try { payload = JSON.parse(raw); } catch (e) { return null; }
            }
            if (!payload || typeof payload !== "object") { return null; }
            return payload;
        }

        function shouldForward(payload) {
            if (payload.type === "PLAYER_EVENT") {
                return !!payload.data && typeof payload.data === "object";
            }
            if (payload.event === "status") { return true; }
            var hasPosition = payload.timestamp !== undefined || payload.progress !== undefined;
            var hasIdentity = payload.id !== undefined || payload.type !== undefined;
            return hasPosition && hasIdentity;
        }

        window.addEventListener("message", function (event) {
            var payload = normalize(event.data);
            if (!payload || !shouldForward(payload)) { return; }
            try { post(JSON.parse(JSON.stringify(payload))); } catch (e) {}
        }, false);

        var lastTouch = 0;
        function reportInteraction() {
            var now = Date.now();
            if (now - lastTouch < 350) { return; }
            lastTouch = now;
            post({ type: "NIGHTFLIX_INTERACTION" });
        }
        document.addEventListener("touchstart", reportInteraction, { capture: true, passive: true });
        document.addEventListener("mousedown", reportInteraction, { capture: true, passive: true });

        setInterval(function () {
            try {
                var v = document.querySelector("video");
                if (v && isFinite(v.duration) && v.duration > 30 && v.currentTime > 0) {
                    post({
                        type: "PLAYER_EVENT",
                        data: {
                            event: v.ended ? "ended" : (v.paused ? "pause" : "timeupdate"),
                            currentTime: v.currentTime,
                            duration: v.duration
                        }
                    });
                }
            } catch (e) {}
        }, 5000);
    })();
    """

    private static let resumeLoopGuardScript = """
    (function () {
        var params = new URLSearchParams(window.location.search);
        var raw = params.get("startAt") || params.get("progress");
        var resumeTime = raw ? parseFloat(raw) : NaN;
        if (!(resumeTime > 0)) { return; }

        var proto = window.HTMLMediaElement && HTMLMediaElement.prototype;
        var descriptor = proto && Object.getOwnPropertyDescriptor(proto, "currentTime");
        if (!descriptor || !descriptor.get || !descriptor.set) { return; }

        function guard(video) {
            if (!video || video.__nightflixResumeGuarded) { return; }
            video.__nightflixResumeGuarded = true;

            var furthest = 0;
            var everResumed = false;

            video.addEventListener("timeupdate", function () {
                var t = descriptor.get.call(video);
                if (t > furthest) { furthest = t; }
            });

            Object.defineProperty(video, "currentTime", {
                configurable: true,
                get: function () { return descriptor.get.call(this); },
                set: function (value) {
                    if (value === resumeTime) {
                        var current = descriptor.get.call(this);
                        if (!everResumed) {
                            everResumed = true;
                            descriptor.set.call(this, Math.max(resumeTime, furthest));
                            return;
                        }
                        if (current < furthest - 5) {
                            descriptor.set.call(this, Math.max(resumeTime, furthest));
                        }
                        return;
                    }
                    descriptor.set.call(this, value);
                }
            });
        }

        function guardAll() {
            var videos = document.getElementsByTagName("video");
            for (var i = 0; i < videos.length; i++) { guard(videos[i]); }
        }

        guardAll();
        if (window.MutationObserver) {
            new MutationObserver(guardAll).observe(document.documentElement, {
                childList: true,
                subtree: true
            });
        }
    })();
    """
}
