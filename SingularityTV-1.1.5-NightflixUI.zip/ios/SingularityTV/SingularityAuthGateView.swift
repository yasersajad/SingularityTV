import SwiftUI

struct SingularityAuthGateView: View {
    enum Mode {
        case signIn
        case signUp
        case verifyOtp
    }

    @EnvironmentObject private var account: SingularityAccountManager
    @Environment(\.nightflixAccent) private var accent

    @State private var mode: Mode = .signIn
    @State private var name: String = ""
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var otpCode: String = ""
    @State private var isLoading: Bool = false
    @State private var errorMessage: String?

    var body: some View {
        ZStack {
            NF.canvas.ignoresSafeArea()

            RadialGradient(
                colors: [accent.opacity(0.22), .clear],
                center: .top,
                startRadius: 10,
                endRadius: 380
            )
            .ignoresSafeArea()
            .allowsHitTesting(false)

            ScrollView {
                VStack(spacing: 24) {
                    Spacer(minLength: 46)

                    VStack(spacing: 8) {
                        NFWordmark(size: 34)
                        Text(subtitleText)
                            .font(.system(size: 14, weight: .medium))
                            .foregroundStyle(NF.textSecondary)
                            .multilineTextAlignment(.center)
                    }

                    VStack(spacing: 14) {
                        if mode == .signUp {
                            fieldBox(title: "Name") {
                                TextField("Your name", text: $name)
                                    .textContentType(.name)
                                    .autocorrectionDisabled()
                            }
                        }

                        if mode != .verifyOtp {
                            fieldBox(title: "Email") {
                                TextField("name@example.com", text: $email)
                                    .textContentType(.emailAddress)
                                    .keyboardType(.emailAddress)
                                    .textInputAutocapitalization(.never)
                                    .autocorrectionDisabled()
                            }

                            fieldBox(title: "Password") {
                                SecureField("••••••••", text: $password)
                                    .textContentType(mode == .signUp ? .newPassword : .password)
                            }
                        } else {
                            fieldBox(title: "Verification Code") {
                                TextField("6-digit code", text: $otpCode)
                                    .keyboardType(.numberPad)
                            }
                        }

                        if let errorMessage {
                            Text(errorMessage)
                                .font(.system(size: 13, weight: .medium))
                                .foregroundStyle(Color(hex: "ff5a5f"))
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }

                        Button {
                            submit()
                        } label: {
                            ZStack {
                                if isLoading {
                                    ProgressView()
                                        .tint(.black)
                                } else {
                                    Text(primaryButtonTitle)
                                        .font(.system(size: 16, weight: .semibold))
                                        .foregroundStyle(.black)
                                }
                            }
                            .frame(maxWidth: .infinity)
                            .frame(height: 46)
                            .background(Color.white, in: RoundedRectangle(cornerRadius: NF.buttonCorner, style: .continuous))
                        }
                        .buttonStyle(NFPressableStyle())
                        .disabled(isLoading)
                        .padding(.top, 4)

                        Button {
                            HapticManager.shared.selection()
                            errorMessage = nil
                            withAnimation(.easeOut(duration: 0.2)) {
                                if mode == .signIn {
                                    mode = .signUp
                                } else {
                                    mode = .signIn
                                }
                            }
                        } label: {
                            Text(mode == .signIn ? "New to SingularityTV? Create an account" : "Already have an account? Sign In")
                                .font(.system(size: 14, weight: .medium))
                                .foregroundStyle(NF.textSecondary)
                                .padding(.top, 4)
                        }
                        .buttonStyle(.plain)
                    }
                    .padding(20)
                    .background(NF.surface, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    .overlay {
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .strokeBorder(NF.hairline, lineWidth: 1)
                    }
                    .padding(.horizontal, 20)
                }
                .padding(.bottom, 40)
            }
            .scrollIndicators(.hidden)
        }
        .preferredColorScheme(.dark)
    }

    private var subtitleText: String {
        switch mode {
        case .signIn: return "Sign in to sync your profiles, My List & progress."
        case .signUp: return "Create your SingularityTV account."
        case .verifyOtp: return "Enter the code sent to \(email)."
        }
    }

    private var primaryButtonTitle: String {
        switch mode {
        case .signIn: return "Sign In"
        case .signUp: return "Create Account"
        case .verifyOtp: return "Verify Email"
        }
    }

    private func fieldBox<Content: View>(title: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(.system(size: 12, weight: .semibold))
                .foregroundStyle(NF.textSecondary)

            content()
                .font(.system(size: 15))
                .foregroundStyle(.white)
                .tint(.white)
                .padding(.horizontal, 12)
                .frame(height: 44)
                .background(NF.surfaceRaised, in: RoundedRectangle(cornerRadius: 6, style: .continuous))
        }
    }

    private func submit() {
        errorMessage = nil
        isLoading = true
        HapticManager.shared.lightImpact()

        Task {
            do {
                switch mode {
                case .signIn:
                    try await account.signIn(email: email, password: password)
                    HapticManager.shared.success()
                case .signUp:
                    let needsOtp = try await account.signUp(email: email, password: password, name: name)
                    if needsOtp {
                        withAnimation(.easeOut(duration: 0.2)) {
                            mode = .verifyOtp
                        }
                    } else {
                        HapticManager.shared.success()
                    }
                case .verifyOtp:
                    try await account.verifySignupOtp(email: email, code: otpCode, name: name)
                    HapticManager.shared.success()
                }
            } catch {
                HapticManager.shared.error()
                errorMessage = error.localizedDescription
            }
            isLoading = false
        }
    }
}
