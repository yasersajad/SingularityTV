import SwiftUI

struct SingularityProfilesView: View {
    var onDismiss: (() -> Void)?

    @EnvironmentObject private var account: SingularityAccountManager
    @State private var isEditing: Bool = false
    @State private var editingProfile: SingularityProfile?
    @State private var isAddingNew: Bool = false

    private let columns = [
        GridItem(.adaptive(minimum: 108, maximum: 136), spacing: 20)
    ]

    var body: some View {
        ZStack {
            NF.canvas.ignoresSafeArea()

            VStack(spacing: 0) {
                header

                ScrollView {
                    VStack(spacing: 28) {
                        Text(isEditing ? "Manage Profiles" : "Who's Watching?")
                            .font(.system(size: 26, weight: .bold))
                            .foregroundStyle(.white)
                            .padding(.top, 28)

                        LazyVGrid(columns: columns, spacing: 24) {
                            ForEach(account.profiles) { profile in
                                profileTile(profile)
                            }

                            if account.profiles.count < 5 {
                                addTile
                            }
                        }
                        .padding(.horizontal, 28)

                        Button(role: .destructive) {
                            HapticManager.shared.warning()
                            account.signOut()
                        } label: {
                            Text("Sign Out")
                                .font(.system(size: 14, weight: .semibold))
                                .foregroundStyle(NF.textSecondary)
                                .padding(.horizontal, 18)
                                .frame(height: 36)
                                .background(NF.surface, in: Capsule())
                        }
                        .buttonStyle(.plain)
                        .padding(.top, 16)
                    }
                    .padding(.bottom, 40)
                }
                .scrollIndicators(.hidden)
            }
        }
        .preferredColorScheme(.dark)
        .sheet(item: $editingProfile) { prof in
            SingularityProfileEditorSheet(profile: prof, canDelete: account.profiles.count > 1) { updated in
                account.updateProfile(updated)
            } onDelete: {
                account.deleteProfile(id: prof.id)
            }
            .presentationDetents([.medium])
            .presentationBackground(NF.surface)
        }
        .sheet(isPresented: $isAddingNew) {
            SingularityProfileEditorSheet(
                profile: SingularityProfile(
                    id: "new",
                    name: "",
                    avatarColor: SingularityProfile.defaultColors[account.profiles.count % SingularityProfile.defaultColors.count],
                    isKids: false
                ),
                canDelete: false
            ) { created in
                account.createProfile(name: created.name, avatarColor: created.avatarColor, isKids: created.isKids)
            } onDelete: {}
            .presentationDetents([.medium])
            .presentationBackground(NF.surface)
        }
    }

    private var header: some View {
        HStack {
            if let onDismiss {
                Button {
                    HapticManager.shared.lightImpact()
                    onDismiss()
                } label: {
                    Image(systemName: "xmark")
                        .font(.system(size: 17, weight: .semibold))
                        .foregroundStyle(.white)
                        .frame(width: 40, height: 40)
                }
                .buttonStyle(.plain)
            } else {
                Spacer().frame(width: 40)
            }

            Spacer()

            NFWordmark(size: 22)

            Spacer()

            Button {
                HapticManager.shared.selection()
                withAnimation(.easeOut(duration: 0.18)) {
                    isEditing.toggle()
                }
            } label: {
                Text(isEditing ? "Done" : "Edit")
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(width: 48, height: 40)
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 12)
        .frame(height: 52)
    }

    private func profileTile(_ profile: SingularityProfile) -> some View {
        Button {
            HapticManager.shared.selection()
            if isEditing {
                editingProfile = profile
            } else {
                account.selectProfile(profile)
                onDismiss?()
            }
        } label: {
            VStack(spacing: 10) {
                ZStack {
                    SingularityProfileBadge(profile: profile, size: 92, isSelected: profile.id == account.activeProfileId && !isEditing)

                    if isEditing {
                        RoundedRectangle(cornerRadius: 14, style: .continuous)
                            .fill(Color.black.opacity(0.48))
                            .frame(width: 92, height: 92)
                        Image(systemName: "pencil")
                            .font(.system(size: 24, weight: .bold))
                            .foregroundStyle(.white)
                    }
                }

                Text(profile.name)
                    .font(.system(size: 14, weight: .semibold))
                    .foregroundStyle(.white)
                    .lineLimit(1)
            }
        }
        .buttonStyle(NFPressableStyle())
    }

    private var addTile: some View {
        Button {
            HapticManager.shared.selection()
            isAddingNew = true
        } label: {
            VStack(spacing: 10) {
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .strokeBorder(Color.white.opacity(0.28), lineWidth: 1.5)
                    .frame(width: 92, height: 92)
                    .overlay {
                        Image(systemName: "plus")
                            .font(.system(size: 28, weight: .medium))
                            .foregroundStyle(.white)
                    }

                Text("Add Profile")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundStyle(NF.textSecondary)
            }
        }
        .buttonStyle(NFPressableStyle())
    }
}

struct SingularityProfileBadge: View {
    let profile: SingularityProfile
    var size: CGFloat
    var isSelected: Bool = false

    private var tint: Color {
        Color(hex: profile.avatarColor)
    }

    var body: some View {
        RoundedRectangle(cornerRadius: size * 0.16, style: .continuous)
            .fill(
                LinearGradient(
                    colors: [tint, tint.opacity(0.72)],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
            )
            .frame(width: size, height: size)
            .overlay {
                Image(systemName: "face.smiling.inverse")
                    .font(.system(size: size * 0.56, weight: .regular))
                    .foregroundStyle(.white)
            }
            .overlay {
                RoundedRectangle(cornerRadius: size * 0.16, style: .continuous)
                    .strokeBorder(Color.white, lineWidth: isSelected ? max(size * 0.06, 1.5) : 0)
            }
    }
}

private struct SingularityProfileEditorSheet: View {
    @Environment(\.dismiss) private var dismiss
    @State private var name: String
    @State private var selectedColor: String
    @State private var isKids: Bool

    let profileId: String
    let canDelete: Bool
    let onSave: (SingularityProfile) -> Void
    let onDelete: () -> Void

    init(
        profile: SingularityProfile,
        canDelete: Bool,
        onSave: @escaping (SingularityProfile) -> Void,
        onDelete: @escaping () -> Void
    ) {
        _name = State(initialValue: profile.name)
        _selectedColor = State(initialValue: profile.avatarColor)
        _isKids = State(initialValue: profile.isKids)
        self.profileId = profile.id
        self.canDelete = canDelete
        self.onSave = onSave
        self.onDelete = onDelete
    }

    var body: some View {
        VStack(spacing: 18) {
            Text(profileId == "new" ? "New Profile" : "Edit Profile")
                .font(.system(size: 19, weight: .bold))
                .foregroundStyle(.white)
                .padding(.top, 16)

            TextField("Profile name", text: $name)
                .font(.system(size: 16, weight: .medium))
                .foregroundStyle(.white)
                .tint(.white)
                .padding(.horizontal, 14)
                .frame(height: 44)
                .background(NF.surfaceRaised, in: RoundedRectangle(cornerRadius: 8, style: .continuous))

            HStack(spacing: 10) {
                ForEach(SingularityProfile.defaultColors, id: \.self) { hex in
                    Button {
                        HapticManager.shared.selection()
                        selectedColor = hex
                    } label: {
                        Circle()
                            .fill(Color(hex: hex))
                            .frame(width: 30, height: 30)
                            .overlay {
                                Circle().strokeBorder(Color.white, lineWidth: selectedColor.lowercased() == hex.lowercased() ? 2.5 : 0)
                            }
                    }
                    .buttonStyle(.plain)
                }
            }

            Toggle("Kids Profile", isOn: $isKids)
                .tint(Color(hex: selectedColor))
                .foregroundStyle(.white)
                .padding(.horizontal, 4)

            HStack(spacing: 10) {
                if canDelete {
                    Button(role: .destructive) {
                        onDelete()
                        dismiss()
                    } label: {
                        Text("Delete")
                            .font(.system(size: 15, weight: .semibold))
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .frame(height: 44)
                            .background(Color.red.opacity(0.28), in: RoundedRectangle(cornerRadius: NF.buttonCorner, style: .continuous))
                    }
                    .buttonStyle(.plain)
                }

                Button {
                    let clean = name.trimmingCharacters(in: .whitespacesAndNewlines)
                    guard !clean.isEmpty else { return }
                    onSave(SingularityProfile(id: profileId, name: clean, avatarColor: selectedColor, isKids: isKids))
                    dismiss()
                } label: {
                    Text("Save")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(.black)
                        .frame(maxWidth: .infinity)
                        .frame(height: 44)
                        .background(Color.white, in: RoundedRectangle(cornerRadius: NF.buttonCorner, style: .continuous))
                }
                .buttonStyle(.plain)
            }

            Spacer(minLength: 0)
        }
        .padding(.horizontal, 20)
        .preferredColorScheme(.dark)
    }
}
