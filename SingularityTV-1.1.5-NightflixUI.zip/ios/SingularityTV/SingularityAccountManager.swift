import Foundation
import SwiftUI

struct SingularityAuthUser: Codable, Equatable {
    let id: String
    let email: String
    let name: String
}

struct SingularityAuthSession: Codable, Equatable {
    let accessToken: String
    let refreshToken: String
    let expiresAtMs: Double
    let user: SingularityAuthUser
}

struct SingularityProfile: Identifiable, Codable, Equatable, Hashable {
    let id: String
    var name: String
    var avatarColor: String
    var isKids: Bool

    static let defaultColors: [String] = [
        "#e50914",
        "#2f80ff",
        "#1db954",
        "#f5c518",
        "#9146ff",
        "#ff6a00",
        "#00b8d4",
        "#ff2d92"
    ]
}

@MainActor
final class SingularityAccountManager: ObservableObject {
    static let supabaseURL = "https://soufctreejgcpvqftxeb.supabase.co"
    static let supabaseKey = "sb_publishable_CRHhsCu1wvqdK7lUok8VfQ_IOBUqwJI"

    @Published private(set) var session: SingularityAuthSession?
    @Published private(set) var profiles: [SingularityProfile] = []
    @Published var activeProfileId: String = "prof_main"
    @Published var needsProfileSelection: Bool = false
    @Published var isSyncing: Bool = false

    private let defaults: UserDefaults
    private let sessionKey = "singularity_native_sb_session"
    private let profilesKey = "singularity_native_profiles"
    private let activeProfileKey = "singularity_native_active_profile_id"
    private var syncTask: Task<Void, Never>?

    var onProfileSwitched: ((String) -> Void)?

    var isAuthenticated: Bool {
        session != nil
    }

    var currentUser: SingularityAuthUser? {
        session?.user
    }

    var activeProfile: SingularityProfile {
        profiles.first(where: { $0.id == activeProfileId })
            ?? profiles.first
            ?? SingularityProfile(id: "prof_main", name: currentUser?.name ?? "Main", avatarColor: "#e50914", isKids: false)
    }

    init(defaults: UserDefaults = .standard) {
        self.defaults = defaults
        loadLocalSession()
        loadLocalProfiles()
        if isAuthenticated {
            needsProfileSelection = profiles.count > 1
        }
    }

    private func loadLocalSession() {
        guard let data = defaults.data(forKey: sessionKey),
              let decoded = try? JSONDecoder().decode(SingularityAuthSession.self, from: data) else {
            session = nil
            return
        }
        session = decoded
    }

    private func saveLocalSession(_ newSession: SingularityAuthSession?) {
        session = newSession
        if let newSession, let data = try? JSONEncoder().encode(newSession) {
            defaults.set(data, forKey: sessionKey)
        } else {
            defaults.removeObject(forKey: sessionKey)
        }
    }

    private func loadLocalProfiles() {
        if let data = defaults.data(forKey: profilesKey),
           let decoded = try? JSONDecoder().decode([SingularityProfile].self, from: data),
           !decoded.isEmpty {
            profiles = Array(decoded.prefix(5))
        } else {
            let fallbackName = currentUser?.name ?? "Main"
            profiles = [SingularityProfile(id: "prof_main", name: fallbackName, avatarColor: "#e50914", isKids: false)]
        }

        let storedActive = defaults.string(forKey: activeProfileKey) ?? ""
        if profiles.contains(where: { $0.id == storedActive }) {
            activeProfileId = storedActive
        } else {
            activeProfileId = profiles.first?.id ?? "prof_main"
            defaults.set(activeProfileId, forKey: activeProfileKey)
        }
    }

    private func saveLocalProfiles() {
        if let data = try? JSONEncoder().encode(profiles) {
            defaults.set(data, forKey: profilesKey)
        }
        defaults.set(activeProfileId, forKey: activeProfileKey)
    }

    func signIn(email: String, password: String) async throws {
        let cleanEmail = email.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard cleanEmail.contains("@"), !password.isEmpty else {
            throw NSError(domain: "SingularityAuth", code: 400, userInfo: [NSLocalizedDescriptionKey: "Please enter a valid email and password."])
        }

        let body: [String: Any] = [
            "email": cleanEmail,
            "password": password
        ]
        let json = try await authRequest(path: "/auth/v1/token?grant_type=password", body: body)
        guard let parsed = parseSession(from: json, fallbackEmail: cleanEmail, fallbackName: "") else {
            throw NSError(domain: "SingularityAuth", code: 401, userInfo: [NSLocalizedDescriptionKey: extractError(json, fallback: "Invalid email or password.")])
        }

        saveLocalSession(parsed)
        await pullFromCloud()
        needsProfileSelection = true
        onProfileSwitched?(activeProfileId)
    }

    func signUp(email: String, password: String, name: String) async throws -> Bool {
        let cleanEmail = email.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        let cleanName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let displayName = cleanName.isEmpty ? (cleanEmail.split(separator: "@").first.map(String.init) ?? "User") : cleanName

        guard cleanEmail.contains("@") else {
            throw NSError(domain: "SingularityAuth", code: 400, userInfo: [NSLocalizedDescriptionKey: "Please enter a valid email address."])
        }
        guard password.count >= 6 else {
            throw NSError(domain: "SingularityAuth", code: 400, userInfo: [NSLocalizedDescriptionKey: "Password must be at least 6 characters."])
        }

        let body: [String: Any] = [
            "email": cleanEmail,
            "password": password,
            "data": ["name": displayName, "full_name": displayName]
        ]
        let json = try await authRequest(path: "/auth/v1/signup", body: body)

        if let parsed = parseSession(from: json, fallbackEmail: cleanEmail, fallbackName: displayName) {
            saveLocalSession(parsed)
            profiles = [SingularityProfile(id: "prof_main", name: displayName, avatarColor: "#e50914", isKids: false)]
            activeProfileId = "prof_main"
            saveLocalProfiles()
            await pushToCloud()
            needsProfileSelection = false
            onProfileSwitched?(activeProfileId)
            return false
        }

        return true
    }

    func verifySignupOtp(email: String, code: String, name: String) async throws {
        let cleanEmail = email.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        let cleanCode = code.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanCode.isEmpty else {
            throw NSError(domain: "SingularityAuth", code: 400, userInfo: [NSLocalizedDescriptionKey: "Please enter the verification code."])
        }

        let body: [String: Any] = [
            "email": cleanEmail,
            "token": cleanCode,
            "type": "signup"
        ]
        let json = try await authRequest(path: "/auth/v1/verify", body: body)
        guard let parsed = parseSession(from: json, fallbackEmail: cleanEmail, fallbackName: name) else {
            throw NSError(domain: "SingularityAuth", code: 401, userInfo: [NSLocalizedDescriptionKey: extractError(json, fallback: "Invalid or expired verification code.")])
        }

        saveLocalSession(parsed)
        await pullFromCloud()
        needsProfileSelection = false
        onProfileSwitched?(activeProfileId)
    }

    func signOut() {
        syncTask?.cancel()
        saveLocalSession(nil)
        needsProfileSelection = false
    }

    func selectProfile(_ profile: SingularityProfile) {
        activeProfileId = profile.id
        saveLocalProfiles()
        needsProfileSelection = false
        onProfileSwitched?(profile.id)
        scheduleCloudPush()
    }

    func createProfile(name: String, avatarColor: String, isKids: Bool) {
        let trimmed = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty, profiles.count < 5 else { return }
        let newId = "prof_\(Int(Date().timeIntervalSince1970))_\(Int.random(in: 100...999))"
        let profile = SingularityProfile(id: newId, name: trimmed, avatarColor: avatarColor, isKids: isKids)
        profiles.append(profile)
        saveLocalProfiles()
        scheduleCloudPush()
    }

    func updateProfile(_ updated: SingularityProfile) {
        guard let idx = profiles.firstIndex(where: { $0.id == updated.id }) else { return }
        profiles[idx] = updated
        saveLocalProfiles()
        scheduleCloudPush()
    }

    func deleteProfile(id: String) {
        guard profiles.count > 1 else { return }
        profiles.removeAll { $0.id == id }
        if activeProfileId == id {
            activeProfileId = profiles.first?.id ?? "prof_main"
            onProfileSwitched?(activeProfileId)
        }
        saveLocalProfiles()
        scheduleCloudPush()
    }

    func scheduleCloudPush() {
        guard isAuthenticated else { return }
        syncTask?.cancel()
        syncTask = Task {
            try? await Task.sleep(for: .milliseconds(900))
            guard !Task.isCancelled else { return }
            await pushToCloud()
        }
    }

    func pullFromCloud() async {
        guard let activeSession = await validSession() else { return }
        isSyncing = true
        defer { isSyncing = false }

        guard let url = URL(string: "\(Self.supabaseURL)/rest/v1/user_sync?user_id=eq.\(activeSession.user.id)&select=data,updated_at") else { return }
        var req = URLRequest(url: url)
        req.httpMethod = "GET"
        req.setValue(Self.supabaseKey, forHTTPHeaderField: "apikey")
        req.setValue("Bearer \(activeSession.accessToken)", forHTTPHeaderField: "Authorization")
        req.setValue("application/json", forHTTPHeaderField: "Accept")

        guard let (data, resp) = try? await URLSession.shared.data(for: req),
              let http = resp as? HTTPURLResponse, (200...299).contains(http.statusCode),
              let rows = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]],
              let first = rows.first,
              let cloudData = first["data"] as? [String: Any] else {
            return
        }

        if let rawProfiles = cloudData["profiles"] as? [[String: Any]] {
            let parsedProfiles: [SingularityProfile] = rawProfiles.compactMap { item in
                guard let id = item["id"] as? String, !id.isEmpty,
                      let name = item["name"] as? String, !name.isEmpty else { return nil }
                let color = (item["avatarColor"] as? String) ?? "#e50914"
                let isKids = (item["isKids"] as? Bool) ?? false
                return SingularityProfile(id: id, name: name, avatarColor: color, isKids: isKids)
            }
            if !parsedProfiles.isEmpty {
                profiles = Array(parsedProfiles.prefix(5))
                if !profiles.contains(where: { $0.id == activeProfileId }) {
                    activeProfileId = profiles[0].id
                }
                saveLocalProfiles()
            }
        }

        if let nativeBuckets = cloudData["iosNativeProfileData"] as? [String: [String: String]] {
            for (pid, bucket) in nativeBuckets {
                if let myListB64 = bucket["myList"], let d = Data(base64Encoded: myListB64) {
                    defaults.set(d, forKey: "prof_\(pid)_myListItems")
                }
                if let cwB64 = bucket["continueWatching"], let d = Data(base64Encoded: cwB64) {
                    defaults.set(d, forKey: "prof_\(pid)_continueWatchingItems")
                }
                if let histB64 = bucket["history"], let d = Data(base64Encoded: histB64) {
                    defaults.set(d, forKey: "prof_\(pid)_recentlyWatchedItems")
                }
            }
            onProfileSwitched?(activeProfileId)
        }
    }

    func pushToCloud() async {
        guard let activeSession = await validSession() else { return }
        isSyncing = true
        defer { isSyncing = false }

        var existingData: [String: Any] = [:]
        if let getUrl = URL(string: "\(Self.supabaseURL)/rest/v1/user_sync?user_id=eq.\(activeSession.user.id)&select=data") {
            var getReq = URLRequest(url: getUrl)
            getReq.httpMethod = "GET"
            getReq.setValue(Self.supabaseKey, forHTTPHeaderField: "apikey")
            getReq.setValue("Bearer \(activeSession.accessToken)", forHTTPHeaderField: "Authorization")
            if let (d, r) = try? await URLSession.shared.data(for: getReq),
               let http = r as? HTTPURLResponse, (200...299).contains(http.statusCode),
               let arr = try? JSONSerialization.jsonObject(with: d) as? [[String: Any]],
               let first = arr.first,
               let dict = first["data"] as? [String: Any] {
                existingData = dict
            }
        }

        let profilesJson: [[String: Any]] = profiles.map { p in
            [
                "id": p.id,
                "name": p.name,
                "avatarColor": p.avatarColor,
                "isKids": p.isKids
            ]
        }
        existingData["profiles"] = profilesJson
        existingData["_profilesTs"] = Int(Date().timeIntervalSince1970 * 1000)

        var nativeBuckets: [String: [String: String]] = [:]
        for p in profiles {
            var b: [String: String] = [:]
            if let d = defaults.data(forKey: "prof_\(p.id)_myListItems") {
                b["myList"] = d.base64EncodedString()
            }
            if let d = defaults.data(forKey: "prof_\(p.id)_continueWatchingItems") {
                b["continueWatching"] = d.base64EncodedString()
            }
            if let d = defaults.data(forKey: "prof_\(p.id)_recentlyWatchedItems") {
                b["history"] = d.base64EncodedString()
            }
            nativeBuckets[p.id] = b
        }
        existingData["iosNativeProfileData"] = nativeBuckets

        guard let postUrl = URL(string: "\(Self.supabaseURL)/rest/v1/user_sync?on_conflict=user_id") else { return }
        var postReq = URLRequest(url: postUrl)
        postReq.httpMethod = "POST"
        postReq.setValue(Self.supabaseKey, forHTTPHeaderField: "apikey")
        postReq.setValue("Bearer \(activeSession.accessToken)", forHTTPHeaderField: "Authorization")
        postReq.setValue("application/json", forHTTPHeaderField: "Content-Type")
        postReq.setValue("resolution=merge-duplicates,return=minimal", forHTTPHeaderField: "Prefer")

        let payload: [String: Any] = [
            "user_id": activeSession.user.id,
            "email": activeSession.user.email,
            "data": existingData,
            "updated_at": ISO8601DateFormatter().string(from: Date())
        ]
        postReq.httpBody = try? JSONSerialization.data(withJSONObject: payload)
        _ = try? await URLSession.shared.data(for: postReq)
    }

    private func validSession() async -> SingularityAuthSession? {
        guard let cur = session else { return nil }
        let nowMs = Date().timeIntervalSince1970 * 1000
        if nowMs < cur.expiresAtMs - 60_000 {
            return cur
        }
        guard !cur.refreshToken.isEmpty else { return cur }
        if let json = try? await authRequest(path: "/auth/v1/token?grant_type=refresh_token", body: ["refresh_token": cur.refreshToken]),
           let refreshed = parseSession(from: json, fallbackEmail: cur.user.email, fallbackName: cur.user.name) {
            saveLocalSession(refreshed)
            return refreshed
        }
        return cur
    }

    private func authRequest(path: String, body: [String: Any]) async throws -> [String: Any] {
        guard let url = URL(string: Self.supabaseURL + path) else {
            throw NSError(domain: "SingularityAuth", code: 400, userInfo: [NSLocalizedDescriptionKey: "Invalid server URL."])
        }
        var req = URLRequest(url: url)
        req.httpMethod = "POST"
        req.setValue(Self.supabaseKey, forHTTPHeaderField: "apikey")
        req.setValue("application/json", forHTTPHeaderField: "Content-Type")
        req.httpBody = try JSONSerialization.data(withJSONObject: body)

        let (data, resp) = try await URLSession.shared.data(for: req)
        let json = (try? JSONSerialization.jsonObject(with: data) as? [String: Any]) ?? [:]
        if let http = resp as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
            throw NSError(domain: "SingularityAuth", code: http.statusCode, userInfo: [NSLocalizedDescriptionKey: extractError(json, fallback: "Authentication failed.")])
        }
        return json
    }

    private func parseSession(from json: [String: Any], fallbackEmail: String, fallbackName: String) -> SingularityAuthSession? {
        guard let accessToken = json["access_token"] as? String, !accessToken.isEmpty,
              let rawUser = json["user"] as? [String: Any],
              let uid = rawUser["id"] as? String, !uid.isEmpty else {
            return nil
        }
        let email = ((rawUser["email"] as? String) ?? fallbackEmail).trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        let meta = rawUser["user_metadata"] as? [String: Any]
        let metaName = (meta?["name"] as? String) ?? (meta?["full_name"] as? String) ?? ""
        let resolvedName = metaName.isEmpty ? (fallbackName.isEmpty ? (email.split(separator: "@").first.map(String.init) ?? "User") : fallbackName) : metaName

        let expiresIn = (json["expires_in"] as? Double) ?? 3600
        let expiresAtMs: Double
        if let exp = json["expires_at"] as? Double {
            expiresAtMs = exp * 1000
        } else {
            expiresAtMs = Date().timeIntervalSince1970 * 1000 + expiresIn * 1000
        }

        let user = SingularityAuthUser(id: uid, email: email, name: resolvedName)
        return SingularityAuthSession(
            accessToken: accessToken,
            refreshToken: (json["refresh_token"] as? String) ?? "",
            expiresAtMs: expiresAtMs,
            user: user
        )
    }

    private func extractError(_ json: [String: Any], fallback: String) -> String {
        if let msg = json["msg"] as? String, !msg.isEmpty { return msg }
        if let desc = json["error_description"] as? String, !desc.isEmpty { return desc }
        if let msg = json["message"] as? String, !msg.isEmpty { return msg }
        if let err = json["error"] as? String, !err.isEmpty { return err }
        return fallback
    }
}
