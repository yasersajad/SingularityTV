//
//  NightFlixApp.swift
//  NightFlix
//
//  Created by Tommaso d’Addio on 24/05/2026.
//

import SwiftUI

@main
struct NightFlixApp: App {
    @UIApplicationDelegateAdaptor(NightflixAppDelegate.self) private var appDelegate
    @StateObject private var settings = AppSettingsManager()
    @StateObject private var account = SingularityAccountManager()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(settings)
                .environmentObject(account)
                .environment(\.nightflixAccent, settings.accentColor)
                .tint(settings.accentColor)
                .preferredColorScheme(.dark)
        }
    }
}
