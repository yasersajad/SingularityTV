import Foundation
import Observation

/// Handles simple local persistence for recently watched items.
@Observable
final class WatchHistoryManager {
    private(set) var items: [WatchItem] = []

    private var storageKey = "prof_prof_main_recentlyWatchedItems"
    @ObservationIgnored var onChanged: (() -> Void)?
    private let maxItems = 12
    private let userDefaults: UserDefaults
    private let decoder = JSONDecoder()
    private let encoder = JSONEncoder()

    init(userDefaults: UserDefaults = .standard) {
        self.userDefaults = userDefaults
        let activeId = userDefaults.string(forKey: "singularity_native_active_profile_id") ?? "prof_main"
        self.storageKey = "prof_\(activeId)_recentlyWatchedItems"
        load()
    }

    func reload(forProfileId profileId: String) {
        storageKey = "prof_\(profileId)_recentlyWatchedItems"
        load()
    }

    func add(_ item: WatchItem) {
        items.removeAll { existingItem in
            existingItem.type == item.type
                && existingItem.tmdbId == item.tmdbId
                && existingItem.season == item.season
                && existingItem.episode == item.episode
        }

        items.insert(item, at: 0)
        items = Array(items.prefix(maxItems))
        save()
    }

    func clear() {
        items = []
        userDefaults.removeObject(forKey: storageKey)
    }

    private func load() {
        guard let data = userDefaults.data(forKey: storageKey) else {
            items = []
            return
        }

        do {
            items = try decoder.decode([WatchItem].self, from: data)
        } catch {
            items = []
            userDefaults.removeObject(forKey: storageKey)
        }
    }

    private func save() {
        do {
            let data = try encoder.encode(items)
            userDefaults.set(data, forKey: storageKey)
            onChanged?()
        } catch {
            userDefaults.removeObject(forKey: storageKey)
        }
    }
}
