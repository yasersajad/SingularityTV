import React, { useState, useEffect, useMemo } from "react";
import { imgUrl } from "../utils/api";
import { PlayIcon, StarIcon, BookmarkIcon, BookmarkFillIcon } from "./Icons";

const AURA_PALETTES = [
  { primary: "rgba(230, 184, 106, 0.24)", secondary: "rgba(94, 139, 255, 0.16)" },
  { primary: "rgba(94, 139, 255, 0.24)", secondary: "rgba(155, 123, 255, 0.16)" },
  { primary: "rgba(229, 95, 114, 0.22)", secondary: "rgba(230, 184, 106, 0.15)" },
  { primary: "rgba(34, 197, 139, 0.20)", secondary: "rgba(94, 139, 255, 0.15)" },
  { primary: "rgba(155, 123, 255, 0.24)", secondary: "rgba(244, 114, 182, 0.15)" }
];

export default function HeroBanner({
  items = [],
  onSelect,
  ratingsMap = {},
  onToggleSave,
  isSavedFn,
  progress = {},
  isTvMode = false
}) {
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    if (items.length <= 1) return;
    const interval = setInterval(() => {
      setActiveIndex(prev => (prev + 1) % items.length);
    }, 8000);
    return () => clearInterval(interval);
  }, [items.length]);

  const item = items[activeIndex] || items[0];
  const aura = useMemo(() => {
    if (!item) return AURA_PALETTES[0];
    const seed = (Number(item.id) || activeIndex) % AURA_PALETTES.length;
    return AURA_PALETTES[Math.abs(seed)];
  }, [item?.id, activeIndex]);

  if (!item) return null;

  const title = item.title || item.name;
  const year = (item.release_date || item.first_air_date || "").slice(0, 4);
  const mediaType = item.media_type === "tv" ? "tv" : "movie";
  const ratingInfo = ratingsMap[`${mediaType}_${item.id}`] || {};
  const backdrop = imgUrl(
    item.backdrop_path || item.poster_path,
    isTvMode ? "w1280" : "w780"
  );
  const saved = isSavedFn ? isSavedFn(item) : false;
  const pk = mediaType === "movie" ? `movie_${item.id}` : null;
  const pct = pk ? Number(progress[pk] || 0) : 0;

  return React.createElement("section", {
    className: "sg3-hero",
    style: {
      "--aura-1": aura.primary,
      "--aura-2": aura.secondary
    }
  },
    React.createElement("div", {
      key: `bg_${item.id}_${activeIndex}`,
      className: "sg3-hero-backdrop",
      style: { backgroundImage: backdrop ? `url(${backdrop})` : "none" }
    }),
    React.createElement("div", { className: "sg3-hero-atmosphere" }),
    React.createElement("div", { className: "sg3-hero-scrim" }),

    React.createElement("div", { className: "sg3-hero-inner" },
      React.createElement("div", {
        key: `copy_${item.id}_${activeIndex}`,
        className: "sg3-hero-copy"
      },
        React.createElement("div", { className: "sg3-hero-eyebrow" },
          React.createElement("span", { className: "sg3-eyebrow-tag" }, mediaType === "tv" ? "FEATURED SERIES" : "FEATURED FILM"),
          year && React.createElement("span", { className: "sg3-eyebrow-sep" }, "·"),
          year && React.createElement("span", null, year),
          ratingInfo.cert && React.createElement("span", { className: "sg3-eyebrow-sep" }, "·"),
          ratingInfo.cert && React.createElement("span", { className: "sg3-eyebrow-cert" }, ratingInfo.cert),
          item.vote_average > 0 && React.createElement("span", { className: "sg3-eyebrow-score" },
            React.createElement(StarIcon, { size: 11 }),
            item.vote_average.toFixed(1)
          )
        ),

        React.createElement("h1", { className: "sg3-hero-title" }, title),
        item.overview && React.createElement("p", { className: "sg3-hero-synopsis" }, item.overview),

        React.createElement("div", { className: "sg3-hero-actions" },
          React.createElement("button", {
            className: "sg3-btn-watch hero-action-btn",
            onClick: () => onSelect(item)
          },
            React.createElement(PlayIcon),
            React.createElement("span", null, pct > 2 && pct < 92 ? `Continue · ${pct}%` : "Watch Now")
          ),
          React.createElement("button", {
            className: "sg3-btn-info hero-action-btn",
            onClick: () => onSelect(item)
          },
            React.createElement("span", null, "More Info")
          ),
          onToggleSave && React.createElement("button", {
            className: `sg3-btn-save hero-action-btn${saved ? " saved" : ""}`,
            onClick: () => onToggleSave(item),
            "aria-label": saved ? "Remove from My Space" : "Save to My Space"
          }, saved ? React.createElement(BookmarkFillIcon) : React.createElement(BookmarkIcon))
        )
      ),

      items.length > 1 && React.createElement("div", { className: "sg3-hero-rail-dots" },
        items.map((slide, idx) => React.createElement("button", {
          key: slide.id || idx,
          className: `sg3-hero-bar${idx === activeIndex ? " active" : ""}`,
          onClick: () => setActiveIndex(idx),
          "aria-label": `Spotlight ${idx + 1}`
        }))
      )
    )
  );
}
