import { useEffect, useState, useMemo, useCallback } from "react";
import { CloseIcon, ExternalLinkIcon } from "./Icons";
import { tmdbFetch } from "../utils/api";

export default function TrailerModal({
  trailerKey,
  title,
  mediaId,
  mediaType = "movie",
  apiKey,
  onClose
}) {
  const [resolvedVideos, setResolvedVideos] = useState([]);
  const [activeIdx, setActiveIdx] = useState(0);
  const [loading, setLoading] = useState(true);
  const [iframeReady, setIframeReady] = useState(false);

  useEffect(() => {
    let mounted = true;
    setLoading(true);
    setIframeReady(false);
    setActiveIdx(0);

    const initialList = trailerKey
      ? [{ key: trailerKey, site: "YouTube", type: "Trailer", name: `${title || "Official"} Trailer` }]
      : [];

    if (initialList.length > 0) {
      setResolvedVideos(initialList);
      setLoading(false);
    }

    if (mediaId) {
      const mType = mediaType === "tv" ? "tv" : "movie";
      Promise.all([
        tmdbFetch(`/${mType}/${mediaId}/videos?language=en-US`, apiKey).catch(() => ({ results: [] })),
        tmdbFetch(`/${mType}/${mediaId}/videos`, apiKey).catch(() => ({ results: [] }))
      ]).then(([enRes, locRes]) => {
        if (!mounted) return;
        const combined = [...(enRes?.results || []), ...(locRes?.results || [])];
        const seen = new Set();
        const filtered = combined
          .filter(v => {
            if (!v || !v.key) return false;
            const k = `${v.site || "YouTube"}_${v.key}`;
            if (seen.has(k)) return false;
            seen.add(k);
            return v.site === "YouTube" || v.site === "Vimeo";
          })
          .sort((a, b) => {
            const score = x => (x.type === "Trailer" ? 10 : x.type === "Teaser" ? 6 : 2) + (x.official ? 3 : 0);
            return score(b) - score(a);
          });

        if (filtered.length > 0) {
          setResolvedVideos(filtered);
          setActiveIdx(0);
        } else if (initialList.length === 0 && title) {
          tmdbFetch(`/search/${mType}?query=${encodeURIComponent(title)}&page=1`, apiKey)
            .then(sr => {
              if (!mounted) return;
              const hit = sr?.results?.[0];
              if (hit?.id && String(hit.id) !== String(mediaId)) {
                return tmdbFetch(`/${mType}/${hit.id}/videos?language=en-US`, apiKey).catch(() => ({ results: [] }));
              }
              return null;
            })
            .then(vRes => {
              if (!mounted) return;
              const vList = (vRes?.results || []).filter(v => v && v.key && (v.site === "YouTube" || v.site === "Vimeo"));
              if (vList.length > 0) setResolvedVideos(vList);
            })
            .catch(() => {});
        }
      }).finally(() => {
        if (mounted) setLoading(false);
      });
    } else {
      setLoading(false);
    }

    return () => { mounted = false; };
  }, [trailerKey, mediaId, mediaType, title, apiKey]);

  const sources = useMemo(() => {
    const list = [];
    for (const v of resolvedVideos) {
      if (v.site === "Vimeo") {
        list.push({
          label: `Vimeo - ${v.name || "Trailer"}`,
          embedUrl: `https://player.vimeo.com/video/${encodeURIComponent(v.key)}?autoplay=1&title=0&byline=0&portrait=0`,
          watchUrl: `https://vimeo.com/${encodeURIComponent(v.key)}`
        });
      } else {
        const yk = encodeURIComponent(v.key);
        list.push({
          label: `YouTube - ${v.name || v.type || "Trailer"}`,
          embedUrl: `https://www.youtube-nocookie.com/embed/${yk}?autoplay=1&rel=0&modestbranding=1&playsinline=1`,
          watchUrl: `https://www.youtube.com/watch?v=${yk}`
        });
        list.push({
          label: `YouTube - ${v.name || "Trailer"}`,
          embedUrl: `https://www.youtube.com/embed/${yk}?autoplay=1&rel=0&playsinline=1`,
          watchUrl: `https://www.youtube.com/watch?v=${yk}`
        });
      }
    }
    if (list.length === 0 && trailerKey) {
      const yk = encodeURIComponent(trailerKey);
      list.push({
        label: "YouTube Trailer",
        embedUrl: `https://www.youtube-nocookie.com/embed/${yk}?autoplay=1&rel=0&modestbranding=1&playsinline=1`,
        watchUrl: `https://www.youtube.com/watch?v=${yk}`
      });
    }
    return list;
  }, [resolvedVideos, trailerKey]);

  const currentSource = sources[activeIdx] || sources[0] || null;

  useEffect(() => {
    setIframeReady(false);
    if (!currentSource) return;
    const t = setTimeout(() => setIframeReady(true), 550);
    return () => clearTimeout(t);
  }, [currentSource]);

  const handleTryAnother = useCallback(() => {
    if (sources.length <= 1) return;
    setIframeReady(false);
    setActiveIdx(prev => (prev + 1) % sources.length);
  }, [sources.length]);

  useEffect(() => {
    const handler = e => {
      if (e.key === "Escape" || e.keyCode === 4) onClose();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onClose]);

  const openInBrowser = () => {
    const targetUrl = currentSource?.watchUrl || (trailerKey ? `https://www.youtube.com/watch?v=${encodeURIComponent(trailerKey)}` : "");
    if (!targetUrl) return;
    try {
      if (window.electron?.openExternal) {
        window.electron.openExternal(targetUrl);
        return;
      }
    } catch {}
    window.open(targetUrl, "_blank", "noopener,noreferrer");
  };

  const noTrailerFound = !loading && !currentSource;

  return React.createElement("div", {
    className: "trailer-overlay",
    onClick: onClose
  }, React.createElement("div", {
    className: "trailer-modal",
    onClick: e => e.stopPropagation()
  }, React.createElement("div", {
    className: "trailer-modal-header"
  }, React.createElement("span", {
    className: "trailer-modal-title"
  }, title || "Trailer", " - Official Trailer"), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, sources.length > 1 && React.createElement("button", {
    onClick: handleTryAnother,
    title: "Switch trailer source",
    className: "trailer-openbrowser-btn"
  }, "Next Trailer (", activeIdx + 1, "/", sources.length, ")"), currentSource && React.createElement("button", {
    onClick: openInBrowser,
    title: "Open in browser",
    className: "trailer-openbrowser-btn"
  }, React.createElement(ExternalLinkIcon, {
    size: 13
  }), "Open in Browser"), React.createElement("button", {
    className: "trailer-close-btn",
    onClick: onClose,
    title: "Close",
    "data-gamepad-close": "true"
  }, React.createElement(CloseIcon, null)))), React.createElement("div", {
    className: "trailer-embed-wrap",
    style: {
      background: "#000",
      position: "relative"
    }
  }, (loading || noTrailerFound || !iframeReady) && React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 2,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      background: "#000",
      color: noTrailerFound ? "#ff6b81" : "rgba(255,255,255,0.7)",
      fontSize: 14,
      textAlign: "center",
      padding: "0 28px",
      gap: 12
    }
  }, noTrailerFound ? React.createElement(React.Fragment, null,
    React.createElement("span", { style: { fontSize: 28 } }, "!"),
    React.createElement("span", null, "No TMDB trailer found for this title.")
  ) : React.createElement(React.Fragment, null,
    React.createElement("div", { className: "spinner" }),
    React.createElement("span", null, "Loading TMDB trailer...")
  )), currentSource && React.createElement("iframe", {
    key: `${currentSource.embedUrl}_${activeIdx}`,
    src: currentSource.embedUrl,
    title: `${title || "Trailer"} Trailer`,
    allow: "autoplay; fullscreen; encrypted-media; picture-in-picture; accelerometer; gyroscope",
    allowFullScreen: true,
    referrerPolicy: "strict-origin-when-cross-origin",
    onLoad: () => setIframeReady(true),
    style: {
      position: "absolute",
      inset: 0,
      width: "100%",
      height: "100%",
      border: "none",
      background: "#000",
      opacity: iframeReady ? 1 : 0.01,
      transition: "opacity 0.2s ease"
    }
  }))));
}
