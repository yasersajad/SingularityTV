import React from "react";
import AppNavigation from "./AppNavigation";
export default function TopNav(props) { return React.createElement(AppNavigation, props); }
