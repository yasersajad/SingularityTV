function _extends() { _extends = Object.assign ? Object.assign.bind() : function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; }; return _extends.apply(this, arguments); }
export const SingularityLogo = ({ variant = "compact", size = 36, monochrome = false, light = false, style }) => {
  const bgFill = monochrome ? "transparent" : light ? "#F5F5F7" : "#06070B";
  const goldStroke = monochrome ? "currentColor" : light ? "#B88635" : "#E6B86A";
  const arcStroke = monochrome ? "currentColor" : light ? "#1E293B" : "#E8ECF5";
  const coreFill = monochrome ? "currentColor" : light ? "#06070B" : "#FFFFFF";

  const emblem = React.createElement("svg", {
    viewBox: "0 0 120 120", width: size, height: size, fill: "none",
    style: { width: size, height: size, display: "block", flexShrink: 0, ...(variant === "compact" ? style : {}) }
  },
    !monochrome && React.createElement("rect", { width: "120", height: "120", rx: "28", fill: bgFill, stroke: "rgba(255,255,255,0.1)", strokeWidth: "2" }),
    React.createElement("circle", { cx: "60", cy: "60", r: "44", stroke: arcStroke, strokeWidth: "2.2", strokeDasharray: "188 88", strokeLinecap: "round", strokeOpacity: "0.85" }),
    React.createElement("circle", { cx: "60", cy: "60", r: "31", stroke: goldStroke, strokeWidth: "2.8", strokeDasharray: "130 68", strokeLinecap: "round", transform: "rotate(140 60 60)" }),
    React.createElement("ellipse", { cx: "60", cy: "60", rx: "45", ry: "14.5", transform: "rotate(-28 60 60)", stroke: goldStroke, strokeWidth: "3.8", strokeLinecap: "round" }),
    React.createElement("circle", { cx: "60", cy: "60", r: "6", fill: coreFill })
  );

  if (variant !== "horizontal") return emblem;
  return React.createElement("div", { className: "sg-brand-lockup", style: { display: "inline-flex", alignItems: "center", gap: 10, ...style } },
    emblem,
    React.createElement("div", { style: { display: "flex", flexDirection: "column", lineHeight: 1 } },
      React.createElement("span", { style: { fontFamily: "var(--font-display)", fontSize: Math.round(size * 0.64), fontWeight: 700, letterSpacing: "0.18em", color: light ? "#06070B" : "#F5F5F7" } }, "SINGULARITY"),
      React.createElement("span", { style: { fontSize: Math.max(8, Math.round(size * 0.22)), fontWeight: 700, letterSpacing: "0.32em", color: "var(--accent)", marginTop: 2 } }, "WEBOS")
    )
  );
};
export const SingularityTVLogo = ({ style }) => React.createElement(SingularityLogo, { variant: "compact", size: 38, style });

export const SearchIcon = () => React.createElement("svg", {
  width: "20",
  height: "20",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("circle", {
  cx: "11",
  cy: "11",
  r: "8"
}), React.createElement("path", {
  d: "m21 21-4.35-4.35"
}));
export const HistoryIcon = () => React.createElement("svg", {
  width: "20",
  height: "20",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("path", {
  d: "M12 8v4l3 3"
}), React.createElement("path", {
  d: "M3.05 11a9 9 0 1 1 .5 4"
}), React.createElement("path", {
  d: "M3 3v5h5"
}));
export const BookmarkIcon = () => React.createElement("svg", {
  width: "20",
  height: "20",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("path", {
  d: "M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"
}));
export const BookmarkFillIcon = () => React.createElement("svg", {
  width: "20",
  height: "20",
  viewBox: "0 0 24 24",
  fill: "currentColor"
}, React.createElement("path", {
  d: "M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"
}));
export const PlayIcon = () => React.createElement("svg", {
  width: "20",
  height: "20",
  viewBox: "0 0 24 24",
  fill: "currentColor"
}, React.createElement("polygon", {
  points: "5 3 19 12 5 21 5 3"
}));
export const CloseIcon = () => React.createElement("svg", {
  width: "20",
  height: "20",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("line", {
  x1: "18",
  y1: "6",
  x2: "6",
  y2: "18"
}), React.createElement("line", {
  x1: "6",
  y1: "6",
  x2: "18",
  y2: "18"
}));
export const FilmIcon = () => React.createElement("svg", {
  width: "20",
  height: "20",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("rect", {
  x: "2",
  y: "2",
  width: "20",
  height: "20",
  rx: "2.18",
  ry: "2.18"
}), React.createElement("line", {
  x1: "7",
  y1: "2",
  x2: "7",
  y2: "22"
}), React.createElement("line", {
  x1: "17",
  y1: "2",
  x2: "17",
  y2: "22"
}), React.createElement("line", {
  x1: "2",
  y1: "12",
  x2: "22",
  y2: "12"
}), React.createElement("line", {
  x1: "2",
  y1: "7",
  x2: "7",
  y2: "7"
}), React.createElement("line", {
  x1: "17",
  y1: "7",
  x2: "22",
  y2: "7"
}), React.createElement("line", {
  x1: "17",
  y1: "17",
  x2: "22",
  y2: "17"
}), React.createElement("line", {
  x1: "2",
  y1: "17",
  x2: "7",
  y2: "17"
}));
export const TVIcon = () => React.createElement("svg", {
  width: "20",
  height: "20",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("rect", {
  x: "2",
  y: "7",
  width: "20",
  height: "15",
  rx: "2",
  ry: "2"
}), React.createElement("polyline", {
  points: "17 2 12 7 7 2"
}));
export const HomeIcon = () => React.createElement("svg", {
  width: "20",
  height: "20",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("path", {
  d: "m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"
}), React.createElement("polyline", {
  points: "9 22 9 12 15 12 15 22"
}));
export const StarIcon = ({
  size = 16
}) => React.createElement("svg", {
  width: "20",
  height: "20",
  viewBox: "0 0 24 24",
  fill: "currentColor",
  width: size,
  height: size
}, React.createElement("polygon", {
  points: "12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"
}));
export const SettingsIcon = () => React.createElement("svg", {
  width: "20",
  height: "20",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("circle", {
  cx: "12",
  cy: "12",
  r: "3"
}), React.createElement("path", {
  d: "M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"
}));
export const HelpIcon = () => React.createElement("svg", {
  width: "20",
  height: "20",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2",
  style: {
    width: 24,
    height: 24
  }
}, React.createElement("circle", {
  cx: "12",
  cy: "12",
  r: "10"
}), React.createElement("path", {
  d: "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"
}), React.createElement("line", {
  x1: "12",
  y1: "17",
  x2: "12.01",
  y2: "17",
  strokeWidth: "2.5",
  strokeLinecap: "round"
}));
export const EyeIcon = () => React.createElement("svg", {
  width: "20",
  height: "20",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("path", {
  d: "M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"
}), React.createElement("circle", {
  cx: "12",
  cy: "12",
  r: "3"
}));
export const DownloadIcon = () => React.createElement("svg", {
  width: "20",
  height: "20",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("path", {
  d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"
}), React.createElement("polyline", {
  points: "7 10 12 15 17 10"
}), React.createElement("line", {
  x1: "12",
  y1: "15",
  x2: "12",
  y2: "3"
}));
export const TrashIcon = () => React.createElement("svg", {
  width: "20",
  height: "20",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("polyline", {
  points: "3 6 5 6 21 6"
}), React.createElement("path", {
  d: "M19 6l-1 14H6L5 6"
}), React.createElement("path", {
  d: "M10 11v6M14 11v6"
}), React.createElement("path", {
  d: "M9 6V4h6v2"
}));
export const FolderIcon = () => React.createElement("svg", {
  width: "20",
  height: "20",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("path", {
  d: "M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"
}));
export const WatchedIcon = ({
  size = 22
}) => React.createElement("svg", {
  width: "20",
  height: "20",
  viewBox: "0 0 24 24",
  width: size,
  height: size,
  fill: "none",
  style: {
    filter: "drop-shadow(0 0 4px rgba(72,199,116,0.7))"
  }
}, React.createElement("circle", {
  cx: "12",
  cy: "12",
  r: "11",
  fill: "#1a2e1a",
  stroke: "#48c774",
  strokeWidth: "1.5"
}), React.createElement("path", {
  d: "M6.5 12.5l3.5 3.5 7-7",
  stroke: "#48c774",
  strokeWidth: "2.2",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}));
export const TrailerIcon = () => React.createElement("svg", {
  width: "20",
  height: "20",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("rect", {
  x: "2",
  y: "2",
  width: "20",
  height: "20",
  rx: "2",
  ry: "2"
}), React.createElement("polygon", {
  points: "10 8 16 12 10 16 10 8",
  fill: "currentColor",
  stroke: "none"
}));
export const DownloadsQueueIcon = () => React.createElement("svg", {
  width: "20",
  height: "20",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("path", {
  d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"
}), React.createElement("polyline", {
  points: "7 10 12 15 17 10"
}), React.createElement("line", {
  x1: "12",
  y1: "15",
  x2: "12",
  y2: "3"
}), React.createElement("line", {
  x1: "3",
  y1: "21",
  x2: "21",
  y2: "21"
}));
export const QuitIcon = () => React.createElement("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  width: "22",
  height: "22",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2.2",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, React.createElement("path", {
  d: "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"
}), React.createElement("polyline", {
  points: "16 17 21 12 16 7"
}), React.createElement("line", {
  x1: "21",
  y1: "12",
  x2: "9",
  y2: "12"
}));
export const BackIcon = () => React.createElement("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  width: "22",
  height: "22",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2.2",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, React.createElement("polyline", {
  points: "15 18 9 12 15 6"
}));
export const RatingShieldIcon = ({
  size = 10
}) => React.createElement("svg", {
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "currentColor",
  style: {
    flexShrink: 0
  }
}, React.createElement("path", {
  d: "M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"
}));
export const RatingLockIcon = ({
  size = 10
}) => React.createElement("svg", {
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2.5",
  strokeLinecap: "round",
  strokeLinejoin: "round",
  style: {
    flexShrink: 0
  }
}, React.createElement("rect", {
  x: "3",
  y: "11",
  width: "18",
  height: "11",
  rx: "2",
  ry: "2"
}), React.createElement("path", {
  d: "M7 11V7a5 5 0 0 1 10 0v4"
}));
export const SourceIcon = () => React.createElement("svg", {
  width: "20",
  height: "20",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, React.createElement("ellipse", {
  cx: "12",
  cy: "12",
  rx: "10",
  ry: "10"
}), React.createElement("ellipse", {
  cx: "12",
  cy: "12",
  rx: "4",
  ry: "10"
}), React.createElement("line", {
  x1: "2",
  y1: "12",
  x2: "22",
  y2: "12"
}));
export const WarningIcon = ({
  size = 24,
  color = "var(--red)"
}) => React.createElement("svg", {
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: color,
  strokeWidth: "2",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, React.createElement("path", {
  d: "M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"
}), React.createElement("line", {
  x1: "12",
  y1: "9",
  x2: "12",
  y2: "13"
}), React.createElement("line", {
  x1: "12",
  y1: "17",
  x2: "12.01",
  y2: "17"
}));
export const ExternalLinkIcon = ({
  size = 13
}) => React.createElement("svg", {
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, React.createElement("path", {
  d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"
}), React.createElement("polyline", {
  points: "15 3 21 3 21 9"
}), React.createElement("line", {
  x1: "10",
  y1: "14",
  x2: "21",
  y2: "3"
}));
export const ChevronLeftIcon = ({
  size = 26
}) => React.createElement("svg", {
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2.5",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, React.createElement("polyline", {
  points: "15 18 9 12 15 6"
}));
export const ChevronRightIcon = ({
  size = 26
}) => React.createElement("svg", {
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2.5",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, React.createElement("polyline", {
  points: "9 18 15 12 9 6"
}));
export const ShieldBlockIcon = ({
  size = 16
}) => React.createElement("svg", {
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, React.createElement("path", {
  d: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"
}), React.createElement("polyline", {
  points: "9 12 11 14 15 10"
}));
export const SubtitlesIcon = ({
  size = 16,
  ...props
}) => React.createElement("svg", _extends({
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, props), React.createElement("rect", {
  x: "2",
  y: "4",
  width: "20",
  height: "16",
  rx: "2"
}), React.createElement("path", {
  d: "M7 15h4M15 15h2M7 11h2M13 11h4"
}));
export const PopOutIcon = ({
  size = 16
}) => React.createElement("svg", {
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, React.createElement("rect", {
  x: "2",
  y: "7",
  width: "13",
  height: "10",
  rx: "2"
}), React.createElement("path", {
  d: "M15 3h6v6"
}), React.createElement("path", {
  d: "M10 14L21 3"
}));
export const CastIcon = ({
  size = 20
}) => React.createElement("svg", {
  width: size,
  height: size,
  fill: "currentColor",
  stroke: "none",
  viewBox: "0 0 32 32",
  xmlns: "http://www.w3.org/2000/svg"
}, React.createElement("path", {
  d: "M16 15.503A5.041 5.041 0 1 0 16 5.42a5.041 5.041 0 0 0 0 10.083zm0 2.215c-6.703 0-11 3.699-11 5.5v3.363h22v-3.363c0-2.178-4.068-5.5-11-5.5z"
}));

export const WifiOffIcon = ({ size = 44 }) => React.createElement("svg", {
  width: "20",
  height: "20",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2",
  strokeLinecap: "round",
  strokeLinejoin: "round",
  width: size,
  height: size
}, React.createElement("line", { x1: "1", y1: "1", x2: "23", y2: "23" }),
   React.createElement("path", { d: "M16.72 11.06A10.94 10.94 0 0 1 19 12.55" }),
   React.createElement("path", { d: "M5 12.55a10.94 10.94 0 0 1 5.17-2.39" }),
   React.createElement("path", { d: "M10.71 5.05A16 16 0 0 1 22.58 9" }),
   React.createElement("path", { d: "M1.42 9a15.91 15.91 0 0 1 4.7-2.88" }),
   React.createElement("path", { d: "M8.53 16.11a6 6 0 0 1 6.95 0" }),
   React.createElement("line", { x1: "12", y1: "20", x2: "12.01", y2: "20" }));

export const AlertIcon = ({ size = 24 }) => React.createElement("svg", {
  width: "20",
  height: "20",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2",
  strokeLinecap: "round",
  strokeLinejoin: "round",
  width: size,
  height: size
}, React.createElement("path", { d: "M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z" }),
   React.createElement("line", { x1: "12", y1: "9", x2: "12", y2: "13" }),
   React.createElement("line", { x1: "12", y1: "17", x2: "12.01", y2: "17" }));
