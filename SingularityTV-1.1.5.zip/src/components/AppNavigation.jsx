import React, { useState, useEffect } from "react";
import { getAuthUser, getActiveProfile } from "../utils/supabaseSync";
import {
  SingularityLogo,
  SearchIcon,
  HomeIcon,
  HistoryIcon,
  SettingsIcon,
  DownloadsQueueIcon,
  SparklesIcon
} from "./Icons";

function ExploreIcon() {
  return React.createElement("svg", {
    width: "20", height: "20", viewBox: "0 0 24 24", fill: "none",
    stroke: "currentColor", strokeWidth: "1.9", strokeLinecap: "round", strokeLinejoin: "round"
  },
    React.createElement("circle", { cx: "12", cy: "12", r: "9" }),
    React.createElement("polygon", { points: "16.24 7.76 14.12 14.12 7.76 16.24 9.88 9.88 16.24 7.76" })
  );
}

export function MobileBottomNavigation({
  page,
  activeFilter,
  onNavigate,
  onSearch,
  onOpenProfiles,
  activeDownloads
}) {
  const [activeProfile, setActiveProfile] = useState(() => getActiveProfile());
  const [authUser, setAuthUser] = useState(() => getAuthUser());

  useEffect(() => {
    const sync = () => {
      setActiveProfile(getActiveProfile());
      setAuthUser(getAuthUser());
    };
    window.addEventListener("singularity:profile-changed", sync);
    window.addEventListener("singularity:auth-changed", sync);
    window.addEventListener("singularity:live-sync-updated", sync);
    return () => {
      window.removeEventListener("singularity:profile-changed", sync);
      window.removeEventListener("singularity:auth-changed", sync);
      window.removeEventListener("singularity:live-sync-updated", sync);
    };
  }, []);

  const mobileTabs = [
    { id: "home", filter: "all", label: "Home", icon: React.createElement(HomeIcon) },
    { id: "explore", filter: "explore", targetPage: "home", label: "Explore", icon: React.createElement(ExploreIcon) },
    { id: "search", label: "Search", icon: React.createElement(SearchIcon), isSearch: true },
    { id: "history", filter: "all", label: "My Space", icon: React.createElement(HistoryIcon) },
    {
      id: "downloads",
      filter: "all",
      label: "Downloads",
      icon: React.createElement(DownloadsQueueIcon),
      badge: activeDownloads > 0 ? activeDownloads : null
    }
  ];

  return React.createElement(React.Fragment, null,
    React.createElement("header", { className: "sg-mobile-topbar" },
      React.createElement("button", {
        className: "sg-mobile-brand",
        onClick: () => onNavigate("home", { filter: "all" }),
        "aria-label": "SINGULARITY WebOS Home"
      },
        React.createElement(SingularityLogo, { variant: "horizontal", size: 28 })
      ),
      React.createElement("div", { className: "sg-mobile-top-actions" },
        React.createElement("button", {
          className: `sg-mobile-live-chip${page === "live" ? " active" : ""}`,
          onClick: () => onNavigate("live", { filter: "all" })
        },
          React.createElement("span", { className: "sg-live-pulse-dot" }),
          React.createElement("span", null, "LIVE")
        ),
        React.createElement("button", {
          className: "sg-mobile-profile-chip",
          onClick: () => onOpenProfiles ? onOpenProfiles() : onNavigate("settings", { section: "account" }),
          "aria-label": "Switch Profile"
        },
          React.createElement("span", {
            className: "sg-profile-dot",
            style: { background: activeProfile?.avatarColor || "var(--accent)" }
          }, (activeProfile?.name || authUser?.name || "S").charAt(0).toUpperCase())
        ),
        React.createElement("button", {
          className: `sg-mobile-settings-btn${page === "settings" ? " active" : ""}`,
          onClick: () => onNavigate("settings"),
          "aria-label": "Settings"
        }, React.createElement(SettingsIcon))
      )
    ),
    React.createElement("nav", {
      className: "sg-mobile-dock",
      "aria-label": "Mobile Navigation"
    },
      mobileTabs.map(tab => {
        const target = tab.targetPage || tab.id;
        const isActive = !tab.isSearch && page === target && (tab.filter === (activeFilter || "all"));
        return React.createElement("button", {
          key: tab.id,
          className: `sg-dock-item${isActive ? " active" : ""}`,
          onClick: () => tab.isSearch ? onSearch() : onNavigate(target, { filter: tab.filter || "all" }),
          "aria-label": tab.label
        },
          React.createElement("span", { className: "sg-dock-icon" }, tab.icon),
          React.createElement("span", { className: "sg-dock-label" }, tab.label),
          React.createElement("span", { className: "sg-dock-indicator" }),
          tab.badge && React.createElement("span", { className: "sg-dock-badge" }, tab.badge)
        );
      })
    )
  );
}

export function TVCommandStrip({
  page,
  activeFilter,
  onNavigate,
  onSearch,
  onOpenProfiles,
  activeDownloads
}) {
  const [timeStr, setTimeStr] = useState(() =>
    new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })
  );
  const [activeProfile, setActiveProfile] = useState(() => getActiveProfile());

  useEffect(() => {
    const sync = () => setActiveProfile(getActiveProfile());
    window.addEventListener("singularity:profile-changed", sync);
    window.addEventListener("singularity:live-sync-updated", sync);
    return () => {
      window.removeEventListener("singularity:profile-changed", sync);
      window.removeEventListener("singularity:live-sync-updated", sync);
    };
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeStr(new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }));
    }, 30000);
    return () => clearInterval(timer);
  }, []);

  const navItems = [
    { id: "home", filter: "all", label: "Home" },
    { id: "movies", filter: "movies", targetPage: "home", label: "Movies" },
    { id: "tvshows", filter: "tv", targetPage: "home", label: "Series" },
    { id: "anime", filter: "anime", targetPage: "home", label: "Anime" },
    { id: "live", filter: "all", label: "Live TV" },
    { id: "history", filter: "all", label: "My Space" },
    { id: "downloads", filter: "all", label: "Downloads", badge: activeDownloads > 0 ? activeDownloads : null }
  ];

  return React.createElement("header", {
    className: "sg-tv-strip",
    "aria-label": "TV Navigation Strip"
  },
    React.createElement("button", {
      className: "sg-tv-strip-brand topnav-btn",
      onClick: () => onNavigate("home", { filter: "all" }),
      "aria-label": "SINGULARITY WebOS"
    },
      React.createElement(SingularityLogo, { variant: "horizontal", size: 30 })
    ),
    React.createElement("nav", { className: "sg-tv-strip-nav" },
      navItems.map(item => {
        const target = item.targetPage || item.id;
        const isActive = page === target && (item.filter === (activeFilter || "all"));
        return React.createElement("button", {
          key: item.id,
          className: `sg-tv-strip-link topnav-btn${isActive ? " active" : ""}`,
          onClick: () => onNavigate(target, { filter: item.filter || "all" })
        },
          React.createElement("span", null, item.label),
          item.badge && React.createElement("span", { className: "sg-tv-strip-badge" }, item.badge)
        );
      })
    ),
    React.createElement("div", { className: "sg-tv-strip-actions" },
      React.createElement("button", {
        className: "sg-tv-strip-icon topnav-btn",
        onClick: onSearch,
        "aria-label": "Search"
      }, React.createElement(SearchIcon)),
      React.createElement("button", {
        className: "sg-tv-strip-profile topnav-btn",
        onClick: () => onOpenProfiles ? onOpenProfiles() : onNavigate("settings", { section: "account" }),
        "aria-label": "Switch Profile"
      },
        React.createElement("span", {
          className: "sg-tv-avatar",
          style: { background: activeProfile?.avatarColor || "var(--accent)" }
        }, (activeProfile?.name || "S").charAt(0).toUpperCase()),
        React.createElement("span", { className: "sg-tv-profile-name" }, activeProfile?.name || "Profile")
      ),
      React.createElement("button", {
        className: `sg-tv-strip-icon topnav-btn${page === "settings" ? " active" : ""}`,
        onClick: () => onNavigate("settings"),
        "aria-label": "Settings"
      }, React.createElement(SettingsIcon)),
      React.createElement("span", { className: "sg-tv-strip-clock" }, timeStr)
    )
  );
}

export default function AppNavigation(props) {
  return props.isTvMode
    ? React.createElement(TVCommandStrip, props)
    : React.createElement(MobileBottomNavigation, props);
}
