import React, { useState, useEffect, useRef, useCallback, memo } from "react";
import { imgUrl, isAnimeContent } from "../utils/api";
import { PlayIcon, FilmIcon, TVIcon, WatchedIcon, RatingShieldIcon, RatingLockIcon, StarIcon } from "./Icons";

const MediaCard = memo(function MediaCard({
  item,
  variant = "landscape",
  onClick,
  progress,
  watched,
  onMarkWatched,
  onMarkUnwatched,
  ageRating,
  restricted
}) {
  const title = item.title || item.name;
  const year = (item.release_date || item.first_air_date || "").slice(0, 4);
  const isTV = item.media_type === "tv";
  const isAnime = isAnimeContent(item);
  const isLandscape = variant === "landscape";
  const score = Number(item.vote_average || 0);

  const rawDate = item.release_date || item.first_air_date;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const isUnreleased = rawDate ? new Date(rawDate) > today : false;

  const watchedKey = isTV
    ? item.season != null && item.episode != null
      ? `tv_${item.id}_s${item.season}e${item.episode}`
      : `tv_${item.id}`
    : `movie_${item.id}`;
  const isWatched = !!watched?.[watchedKey];

  const [menu, setMenu] = useState(null);
  const menuRef = useRef(null);
  const canMarkWatched = !isTV || (item.season != null && item.episode != null);

  const openMenu = useCallback(
    e => {
      if (!canMarkWatched) return;
      e.preventDefault();
      e.stopPropagation();
      setMenu({ x: e.clientX, y: e.clientY });
    },
    [canMarkWatched]
  );

  useEffect(() => {
    if (!menu) return;
    const close = () => setMenu(null);
    window.addEventListener("click", close);
    window.addEventListener("contextmenu", close);
    return () => {
      window.removeEventListener("click", close);
      window.removeEventListener("contextmenu", close);
    };
  }, [menu]);

  const [imgFailed, setImgFailed] = useState(false);
  const imagePath = isLandscape
    ? item.backdrop_path || item.poster_path
    : item.poster_path || item.backdrop_path;
  const fallbackPath = isLandscape ? item.poster_path : item.backdrop_path;
  const [useAlt, setUseAlt] = useState(false);
  const activePath = useAlt && fallbackPath ? fallbackPath : imagePath;
  const imageSrc = activePath ? imgUrl(activePath, isLandscape ? "w500" : "w342") : null;

  if (isUnreleased || !imageSrc || imgFailed || !title) return null;

  return React.createElement(React.Fragment, null,
    React.createElement("div", {
      role: "button",
      tabIndex: 0,
      className: `card sg4-card ${isLandscape ? "card--landscape" : "card--poster"}${isWatched ? " ep-watched" : ""}`,
      onClick,
      onContextMenu: openMenu
    },
      React.createElement("div", { className: "card-media" },
        React.createElement("img", {
          src: imageSrc,
          alt: title,
          loading: "lazy",
          decoding: "async",
          draggable: false,
          onError: () => {
            if (!useAlt && fallbackPath && fallbackPath !== imagePath) setUseAlt(true);
            else setImgFailed(true);
          }
        }),
        React.createElement("div", { className: "card-gradient-overlay sg4-card-scrim" }),
        React.createElement("div", { className: "sg4-card-top-badges" },
          score > 0 && React.createElement("span", { className: "sg4-score-pill" },
            React.createElement(StarIcon, { size: 10 }),
            score.toFixed(1)
          ),
          ageRating && React.createElement("span", { className: `sg4-age-pill${restricted ? " restricted" : ""}` },
            restricted ? React.createElement(RatingLockIcon, { size: 9 }) : React.createElement(RatingShieldIcon, { size: 9 }),
            ageRating
          ),
          React.createElement("span", {
            className: `sg4-type-pill${isAnime ? " anime" : ""}`
          }, isAnime ? "ANIME" : isTV ? "SERIES" : "HD")
        ),
        React.createElement("div", { className: "card-overlay" },
          React.createElement("div", { className: "card-play sg4-play-orb" }, React.createElement(PlayIcon))
        ),
        React.createElement("div", { className: "card-overlay-meta sg4-card-meta" },
          React.createElement("div", { className: "card-title", title }, title),
          React.createElement("div", { className: "card-year" },
            isTV && item.season != null && item.episode != null
              ? `S${item.season} · E${item.episode}${item.episodeName ? ` · ${item.episodeName}` : ""}`
              : `${year ? `${year} · ` : ""}${isTV ? "Series" : "Film"}`
          )
        ),
        progress > 0 && !isWatched && React.createElement("div", { className: "card-progress sg4-progress-track" },
          React.createElement("div", { className: "card-progress-fill sg4-progress-bar", style: { width: `${Math.min(progress, 100)}%` } })
        ),
        isWatched && React.createElement("div", { className: "card-watched-badge" }, React.createElement(WatchedIcon, { size: 22 }))
      )
    ),
    menu && React.createElement("div", {
      ref: menuRef,
      className: "context-menu",
      style: { top: menu.y, left: menu.x },
      onClick: e => e.stopPropagation()
    },
      isWatched
        ? React.createElement("button", { className: "context-menu-item", onClick: e => { e.stopPropagation(); onMarkUnwatched?.(watchedKey); setMenu(null); } }, "Mark as Unwatched")
        : React.createElement("button", { className: "context-menu-item", onClick: e => { e.stopPropagation(); onMarkWatched?.(watchedKey); setMenu(null); } }, "Mark as Watched")
    )
  );
});

export default MediaCard;
