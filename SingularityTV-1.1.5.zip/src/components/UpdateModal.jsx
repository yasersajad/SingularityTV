import { useState, useEffect, useRef } from "react";
function ReleaseImage({
  src,
  alt,
  style
}) {
  const [resolvedSrc, setResolvedSrc] = useState(null);
  useEffect(() => {
    if (!src) return;
    if (window.electron?.fetchReleaseImage) {
      window.electron.fetchReleaseImage(src).then(dataUri => {
        setResolvedSrc(dataUri || src);
      });
    } else {
      setResolvedSrc(src);
    }
  }, [src]);
  if (!resolvedSrc) return null;
  return React.createElement("img", {
    src: resolvedSrc,
    alt: alt,
    style: style,
    onError: e => {
      e.currentTarget.style.display = "none";
    }
  });
}
function inlineFormat(text) {
  const parts = [];
  const re = /(~~[^~]+~~|\*\*[^*]+\*\*|\*[^*\n]+\*|_[^_\n]+_|`[^`]+`|!\[[^\]]*\]\([^)]+\)|\[[^\]]+\]\([^)]+\)|https?:\/\/[^\s<>"')]+|@[\w-]+)/g;
  let last = 0,
    m,
    k = 0;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) parts.push(React.createElement("span", {
      key: k++
    }, text.slice(last, m.index)));
    const raw = m[0];
    if (raw.startsWith("~~")) {
      parts.push(React.createElement("s", {
        key: k++,
        style: {
          color: "var(--text3)"
        }
      }, raw.slice(2, -2)));
    } else if (raw.startsWith("**")) {
      parts.push(React.createElement("strong", {
        key: k++,
        style: {
          color: "var(--text)",
          fontWeight: 600
        }
      }, raw.slice(2, -2)));
    } else if (raw.startsWith("*") || raw.startsWith("_")) {
      parts.push(React.createElement("em", {
        key: k++,
        style: {
          color: "var(--text2)",
          fontStyle: "italic"
        }
      }, raw.slice(1, -1)));
    } else if (raw.startsWith("`")) {
      parts.push(React.createElement("code", {
        key: k++,
        style: {
          fontSize: 11,
          background: "var(--surface)",
          border: "1px solid var(--border)",
          borderRadius: 3,
          padding: "1px 5px",
          fontFamily: "monospace",
          color: "var(--text)"
        }
      }, raw.slice(1, -1)));
    } else if (raw.startsWith("![")) {
      const mm = raw.match(/^!\[([^\]]*)\]\(([^)]+)\)$/);
      if (mm) {
        parts.push(React.createElement(ReleaseImage, {
          key: k++,
          src: mm[2],
          alt: mm[1],
          style: {
            maxWidth: "100%",
            verticalAlign: "middle",
            borderRadius: 6,
            border: "1px solid var(--border)"
          }
        }));
      }
    } else if (raw.startsWith("[")) {
      const mm = raw.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
      if (mm) {
        parts.push(React.createElement("a", {
          key: k++,
          href: mm[2],
          onClick: e => {
            e.preventDefault();
            window.electron?.openExternal(mm[2]);
          },
          style: {
            color: "var(--red)",
            textDecoration: "underline",
            cursor: "pointer"
          }
        }, mm[1]));
      }
    } else if (raw.startsWith("@")) {
      const username = raw.slice(1);
      parts.push(React.createElement("a", {
        key: k++,
        href: `https://t.me/${username}`,
        onClick: e => {
          e.preventDefault();
          window.electron?.openExternal(`https://t.me/${username}`);
        },
        style: {
          color: "var(--red)",
          textDecoration: "none",
          fontWeight: 500,
          cursor: "pointer"
        }
      }, raw));
    } else if (raw.startsWith("http")) {
      let label = raw;
      try {
        const u = new URL(raw);
        const prMatch = u.pathname.match(/\/(pull|issues?)\/(\d+)$/);
        if (prMatch) label = `#${prMatch[2]}`;else label = u.hostname.replace(/^www\./, "") + u.pathname;
      } catch {}
      parts.push(React.createElement("a", {
        key: k++,
        href: raw,
        onClick: e => {
          e.preventDefault();
          window.electron?.openExternal(raw);
        },
        style: {
          color: "var(--red)",
          textDecoration: "underline",
          cursor: "pointer",
          fontSize: "0.95em"
        }
      }, label));
    }
    last = m.index + raw.length;
  }
  if (last < text.length) parts.push(React.createElement("span", {
    key: k++
  }, text.slice(last)));
  return parts.length ? parts : text;
}
function renderChangelog(text) {
  if (!text) return null;
  const lines = text.split("\n");
  const elements = [];
  let key = 0;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line.startsWith("### ")) {
      elements.push(React.createElement("div", {
        key: key++,
        style: {
          fontSize: 13,
          fontWeight: 700,
          color: "var(--text)",
          marginTop: 14,
          marginBottom: 4,
          letterSpacing: 0.3
        }
      }, inlineFormat(line.slice(4))));
      continue;
    }
    if (line.startsWith("## ")) {
      elements.push(React.createElement("div", {
        key: key++,
        style: {
          fontSize: 14,
          fontWeight: 700,
          color: "var(--text)",
          marginTop: 16,
          marginBottom: 6,
          borderBottom: "1px solid var(--border)",
          paddingBottom: 4
        }
      }, inlineFormat(line.slice(3))));
      continue;
    }
    if (line.startsWith("# ")) {
      elements.push(React.createElement("div", {
        key: key++,
        style: {
          fontSize: 15,
          fontWeight: 700,
          color: "var(--text)",
          marginTop: 16,
          marginBottom: 8
        }
      }, inlineFormat(line.slice(2))));
      continue;
    }
    if (/^([-*_])\1{2,}\s*$/.test(line.trim())) {
      elements.push(React.createElement("div", {
        key: key++,
        style: {
          borderBottom: "1px solid var(--border)",
          margin: "12px 0"
        }
      }));
      continue;
    }
    if (line.startsWith("> ")) {
      elements.push(React.createElement("div", {
        key: key++,
        style: {
          borderLeft: "3px solid var(--red)",
          paddingLeft: 10,
          margin: "4px 0",
          color: "var(--text3)",
          fontSize: 13,
          fontStyle: "italic",
          lineHeight: 1.6
        }
      }, inlineFormat(line.slice(2))));
      continue;
    }
    const htmlImgMatch = line.match(/<img\b[^>]*\bsrc="([^"]+)"[^>]*>/i);
    if (htmlImgMatch) {
      const src = htmlImgMatch[1];
      const altMatch = line.match(/\balt="([^"]*)"/i);
      const alt = altMatch ? altMatch[1] : "";
      elements.push(React.createElement("div", {
        key: key++,
        style: {
          margin: "10px 0"
        }
      }, React.createElement(ReleaseImage, {
        src: src,
        alt: alt,
        style: {
          maxWidth: "100%",
          borderRadius: 8,
          border: "1px solid var(--border)",
          display: "block"
        }
      }), alt && React.createElement("div", {
        style: {
          fontSize: 11,
          color: "var(--text3)",
          textAlign: "center",
          marginTop: 4,
          fontStyle: "italic"
        }
      }, alt)));
      continue;
    }
    const imgMatch = line.match(/^!\[([^\]]*)\]\(([^)]+)\)$/);
    if (imgMatch) {
      const [, alt, src] = imgMatch;
      elements.push(React.createElement("div", {
        key: key++,
        style: {
          margin: "10px 0"
        }
      }, React.createElement("img", {
        src: src,
        alt: alt,
        style: {
          maxWidth: "100%",
          borderRadius: 8,
          border: "1px solid var(--border)",
          display: "block"
        },
        onError: e => {
          e.currentTarget.style.display = "none";
        }
      }), alt && React.createElement("div", {
        style: {
          fontSize: 11,
          color: "var(--text3)",
          textAlign: "center",
          marginTop: 4,
          fontStyle: "italic"
        }
      }, alt)));
      continue;
    }
    const numMatch = line.match(/^(\d+)\. (.*)$/);
    if (numMatch) {
      elements.push(React.createElement("div", {
        key: key++,
        style: {
          display: "flex",
          gap: 8,
          fontSize: 13,
          color: "var(--text2)",
          lineHeight: 1.6,
          marginBottom: 2
        }
      }, React.createElement("span", {
        style: {
          color: "var(--red)",
          flexShrink: 0,
          fontWeight: 600,
          minWidth: 18,
          textAlign: "right"
        }
      }, numMatch[1], "."), React.createElement("span", null, inlineFormat(numMatch[2]))));
      continue;
    }
    if (/^[-*] /.test(line)) {
      elements.push(React.createElement("div", {
        key: key++,
        style: {
          display: "flex",
          gap: 8,
          fontSize: 13,
          color: "var(--text2)",
          lineHeight: 1.6,
          marginBottom: 2
        }
      }, React.createElement("span", {
        style: {
          color: "var(--red)",
          flexShrink: 0,
          marginTop: 1
        }
      }, "\u2022"), React.createElement("span", null, inlineFormat(line.slice(2)))));
      continue;
    }
    if (line.trim() === "") {
      elements.push(React.createElement("div", {
        key: key++,
        style: {
          height: 6
        }
      }));
      continue;
    }
    elements.push(React.createElement("div", {
      key: key++,
      style: {
        fontSize: 13,
        color: "var(--text2)",
        lineHeight: 1.6,
        marginBottom: 2
      }
    }, inlineFormat(line)));
  }
  return elements;
}
export default function UpdateModal({
  updateInfo,
  activeDownloads = 0,
  onClose
}) {
  const {
    latest,
    current,
    url,
    changelog,
    assets,
    sourceLabel
  } = updateInfo;
  const [phase, setPhase] = useState("idle");
  const [format, setFormat] = useState(null);
  const [progress, setProgress] = useState(0);
  const [progressLabel, setProgressLabel] = useState("");
  const [errorMsg, setErrorMsg] = useState("");
  const cancelRef = useRef(false);
  useEffect(() => {
    if (!window.electron?.detectUpdateFormat) return;
    let mounted = true;
    window.electron.detectUpdateFormat().then(fmt => {
      if (mounted) setFormat(fmt);
    });
    return () => {
      mounted = false;
    };
  }, []);
  useEffect(() => {
    if (!window.electron?.onUpdateProgress) return;
    const handler = window.electron.onUpdateProgress(data => {
      if (!data) return;
      if (data.error) {
        setPhase("error");
        setErrorMsg(data.error);
        return;
      }
      setProgress(data.percent ?? 0);
      setProgressLabel(data.label ?? "");
      if (data.done) {
        setPhase(data.isIpa ? "done_ipa" : "done");
      }
    });
    return () => window.electron.offUpdateProgress(handler);
  }, []);
  const assetUrl = format && assets?.[format];
  const canInstall = format && assetUrl && activeDownloads === 0 && phase === "idle";
  const handleInstall = async () => {
    if (!canInstall) return;
    cancelRef.current = false;
    setPhase("downloading");
    setProgress(0);
    setProgressLabel("Preparing…");
    try {
      const result = await window.electron.downloadAndInstallUpdate({
        url: assetUrl,
        format
      });
      if (cancelRef.current) return;
      if (!result.ok) throw new Error(result.error || "Update failed");
      setPhase("installing");
      setProgressLabel("Launching installer…");
    } catch (e) {
      if (cancelRef.current) return;
      setPhase("error");
      setErrorMsg(e.message || "Update failed");
    }
  };
  const handleCancel = () => {
    if (phase === "downloading") {
      cancelRef.current = true;
      window.electron?.cancelUpdate?.();
    }
    onClose();
  };
  const formatLabel = {
    apk: "Android APK (.apk)",
    ipa: "iOS IPA (.ipa)",
    appimage: "AppImage",
    deb: ".deb package",
    pacman: ".pacman (Arch)",
    exe: "Windows installer",
    dmg: "macOS installer (Universal)"
  }[format] || "installer";
  const busy = phase === "downloading" || phase === "installing";
  return React.createElement("div", {
    onClick: (busy || mandatory) ? undefined : handleCancel,
    style: {
      position: "fixed",
      inset: 0,
      zIndex: 6000,
      background: "rgba(0,0,0,0.78)",
      backdropFilter: "blur(10px)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: 24,
      cursor: busy ? "default" : "auto"
    }
  }, React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border)",
      borderRadius: 14,
      width: "100%",
      maxWidth: 560,
      maxHeight: "85vh",
      display: "flex",
      flexDirection: "column",
      boxShadow: "0 32px 80px rgba(0,0,0,0.7)",
      overflow: "hidden"
    }
  }, React.createElement("div", {
    style: {
      padding: "24px 28px 16px",
      borderBottom: "1px solid var(--border)",
      flexShrink: 0
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      justifyContent: "space-between",
      gap: 12
    }
  }, React.createElement("div", null, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      marginBottom: 4
    }
  }, React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 22,
      letterSpacing: 1
    }
  }, "UPDATE AVAILABLE")), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      display: "flex",
      alignItems: "center",
      gap: 8,
      flexWrap: "wrap"
    }
  }, current && React.createElement(React.Fragment, null, React.createElement("span", {
    style: {
      color: "var(--text3)"
    }
  }, "v", current), React.createElement("span", {
    style: {
      color: "var(--text3)",
      fontSize: 11
    }
  }, "\u2192")), React.createElement("a", {
    href: url,
    onClick: e => {
      e.preventDefault();
      window.electron?.openExternal(url);
    },
    style: {
      color: "var(--red)",
      fontWeight: 600,
      textDecoration: "none",
      cursor: "pointer"
    },
    title: `View on ${sourceLabel || "Telegram @ec1lz"}`
  }, "v", latest, " \u2197"), mandatory ? "is required to continue" : "is ready to install", format && React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      background: "var(--surface2)",
      border: "1px solid var(--border)",
      borderRadius: 4,
      padding: "1px 7px"
    }
  }, formatLabel))), !mandatory && React.createElement("button", {
    onClick: handleCancel,
    disabled: busy,
    style: {
      background: "transparent",
      border: "1px solid var(--border)",
      borderRadius: 6,
      color: "var(--text3)",
      cursor: busy ? "not-allowed" : "pointer",
      fontSize: 18,
      width: 28,
      height: 28,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      flexShrink: 0,
      opacity: busy ? 0.35 : 1
    }
  }, "\xD7"))), React.createElement("div", {
    style: {
      flex: 1,
      overflowY: "auto",
      padding: "20px 28px"
    }
  }, changelog ? React.createElement(React.Fragment, null, React.createElement("div", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      letterSpacing: 1.5,
      color: "var(--text3)",
      textTransform: "uppercase",
      marginBottom: 12
    }
  }, "What's New"), React.createElement("div", null, renderChangelog(changelog))) : React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      fontStyle: "italic"
    }
  }, "No changelog available.")), React.createElement("div", {
    style: {
      padding: "16px 28px",
      borderTop: "1px solid var(--border)",
      flexShrink: 0
    }
  }, activeDownloads > 0 && phase === "idle" && React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--red)",
      marginBottom: 12,
      display: "flex",
      alignItems: "center",
      gap: 6
    }
  }, "\u26A0 ", activeDownloads, " download", activeDownloads > 1 ? "s" : "", " ", "running, finish or cancel them before updating."), !format && phase === "idle" && React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginBottom: 12
    }
  }, "Could not detect install format. Use the", " ", React.createElement("a", {
    href: url,
    onClick: e => {
      e.preventDefault();
      window.electron?.openExternal(url);
    },
    style: {
      color: "var(--red)",
      cursor: "pointer"
    }
  }, sourceLabel || "Telegram @ec1lz", " releases page"), " ", "to download manually."), (phase === "downloading" || phase === "installing") && React.createElement("div", {
    style: {
      marginBottom: 14
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      fontSize: 12,
      color: "var(--text3)",
      marginBottom: 6
    }
  }, React.createElement("span", null, progressLabel || (phase === "downloading" ? "Downloading update…" : "Installing…")), phase === "downloading" && React.createElement("span", null, Math.round(progress), "%")), React.createElement("div", {
    style: {
      height: 4,
      background: "var(--surface2)",
      borderRadius: 2,
      overflow: "hidden"
    }
  }, React.createElement("div", {
    style: {
      height: "100%",
      width: phase === "installing" ? "100%" : `${progress}%`,
      background: "var(--red)",
      borderRadius: 2,
      transition: "width 0.3s ease",
      animation: phase === "installing" ? "progress-indeterminate 1.2s ease-in-out infinite" : "none"
    }
  }))), phase === "error" && React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--red)",
      marginBottom: 12
    }
  }, "\u2715 ", errorMsg, React.createElement("span", {
    style: {
      marginLeft: 10
    }
  }, React.createElement("a", {
    href: url,
    onClick: e => {
      e.preventDefault();
      window.electron?.openExternal(url);
    },
    style: {
      color: "var(--red)",
      textDecoration: "underline",
      cursor: "pointer"
    }
  }, "Download manually \u2197"))), phase === "done" && React.createElement("div", {
    style: {
      fontSize: 13,
      color: "#48c774",
      marginBottom: 12
    }
  }, "\u2713 Update downloaded, installer is running"), phase === "done_ipa" && React.createElement("div", {
    style: {
      fontSize: 13,
      color: "#48c774",
      marginBottom: 12,
      lineHeight: 1.5
    }
  }, "IPA downloaded! Save it to Files and install it with your sideloading app (SideStore, AltStore, KSign, or ESign)."), React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      justifyContent: "flex-end",
      flexWrap: "wrap"
    }
  }, (!mandatory || phase === "downloading") && React.createElement("button", {
    className: "btn btn-ghost",
    onClick: handleCancel
  }, phase === "downloading" ? "Cancel" : "Close"), phase === "done_ipa" && React.createElement("button", {
    className: "btn btn-primary",
    onClick: () => window.electron?.openDownloadedIpa?.()
  }, "Save / Share IPA"), phase === "error" && React.createElement("button", {
    className: "btn btn-primary",
    onClick: () => { setPhase("idle"); setErrorMsg(""); }
  }, "Retry"), phase === "idle" && React.createElement(React.Fragment, null, React.createElement("a", {
    href: url,
    onClick: e => {
      e.preventDefault();
      window.electron?.openExternal(url);
    },
    style: {
      display: "inline-flex",
      alignItems: "center",
      padding: "9px 18px",
      background: "var(--surface2)",
      border: "1px solid var(--border)",
      borderRadius: 8,
      fontSize: 14,
      fontWeight: 600,
      color: "var(--text)",
      textDecoration: "none",
      cursor: "pointer"
    }
  }, sourceLabel || "Telegram @ec1lz", " \u2197"), React.createElement("button", {
    className: "btn",
    disabled: !canInstall,
    onClick: handleInstall,
    style: {
      background: canInstall ? "var(--red)" : "rgba(229,9,20,0.3)",
      color: "#fff",
      border: "none",
      fontWeight: 600,
      opacity: canInstall ? 1 : 0.6,
      cursor: canInstall ? "pointer" : "not-allowed"
    }
  }, format === "ipa" ? "Download IPA" : "Install Update"))))), React.createElement("style", null, `
        @keyframes progress-indeterminate {
          0%   { transform: translateX(-100%); width: 60%; }
          100% { transform: translateX(200%);  width: 60%; }
        }
      `));
}
