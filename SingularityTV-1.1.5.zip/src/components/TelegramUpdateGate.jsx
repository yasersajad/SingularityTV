import React, { useState } from "react";
import { SingularityLogo } from "./Icons";
import { APP_VERSION, TELEGRAM_BOT_USERNAME, TELEGRAM_CHANNEL_URL, signOutAccount } from "../utils/supabaseSync";
import { isStrictAndroidTvHardware } from "../utils/androidBridge";

function openExternalUrl(url) {
  if (window.AndroidBridge?.openExternal) {
    window.AndroidBridge.openExternal(url);
    return;
  }
  if (window.electron?.openExternal) {
    window.electron.openExternal(url);
    return;
  }
  window.open(url, "_blank", "noopener,noreferrer");
}

export function TelegramUpdateGate({ user, gateState, onRecheck }) {
  const [checking, setChecking] = useState(false);

  const tvExempt = isStrictAndroidTvHardware();
  if (!gateState || (!gateState.needsUpdate && (gateState.member || tvExempt))) {
    return null;
  }

  const channelUrl = gateState.channelUrl || TELEGRAM_CHANNEL_URL;
  const updateUrl = gateState.release?.update_post_url || channelUrl;
  const botVerifyUrl = `https://t.me/${TELEGRAM_BOT_USERNAME}?start=verify_${encodeURIComponent(user?.id || "")}`;

  const handleRecheck = async () => {
    setChecking(true);
    try {
      await onRecheck?.();
    } finally {
      setChecking(false);
    }
  };

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 99990,
        background: "radial-gradient(circle at 50% 18%, #24070b 0%, #0b0b11 55%, #050508 100%)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "max(24px, env(safe-area-inset-top)) 18px max(24px, env(safe-area-inset-bottom))",
        direction: "ltr"
      }}
    >
      <div
        style={{
          width: "100%",
          maxWidth: 420,
          background: "rgba(20, 20, 28, 0.94)",
          backdropFilter: "blur(20px)",
          WebkitBackdropFilter: "blur(20px)",
          border: "1px solid rgba(255,255,255,0.12)",
          borderRadius: 20,
          padding: "28px 24px",
          boxShadow: "0 24px 72px rgba(0,0,0,0.72)",
          textAlign: "center"
        }}
      >
        <div
          style={{
            width: 60,
            height: 60,
            borderRadius: 16,
            margin: "0 auto 14px",
            background: "rgba(229,9,20,0.16)",
            border: "1px solid rgba(229,9,20,0.42)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center"
          }}
        >
          <SingularityLogo style={{ width: 34, height: 34 }} />
        </div>

        {gateState.needsUpdate ? (
          <>
            <div style={{ fontSize: 21, fontWeight: 800, color: "#fff" }}>
              Update Required
            </div>
            <div style={{ fontSize: 13, color: "rgba(255,255,255,0.68)", marginTop: 8, lineHeight: 1.55 }}>
              Your version (v{APP_VERSION}) has expired. Join our official Telegram channel and install{" "}
              <strong style={{ color: "#fff" }}>v{gateState.release?.latest_version}</strong> to continue using SINGULARITY WebOS.
            </div>
            {gateState.release?.changelog && (
              <div
                style={{
                  marginTop: 14,
                  padding: "12px 14px",
                  borderRadius: 12,
                  background: "rgba(255,255,255,0.05)",
                  border: "1px solid rgba(255,255,255,0.08)",
                  color: "rgba(255,255,255,0.85)",
                  fontSize: 13,
                  textAlign: "left",
                  whiteSpace: "pre-wrap",
                  lineHeight: 1.5
                }}
              >
                {gateState.release.changelog}
              </div>
            )}
            <button
              type="button"
              onClick={() => openExternalUrl(updateUrl)}
              style={{
                width: "100%",
                marginTop: 18,
                padding: "13px 18px",
                borderRadius: 12,
                border: "none",
                background: "linear-gradient(135deg, #e50914, #b80710)",
                color: "#fff",
                fontSize: 15,
                fontWeight: 700,
                cursor: "pointer"
              }}
            >
              Join Channel & Download Update
            </button>
          </>
        ) : (
          <>
            <div style={{ fontSize: 21, fontWeight: 800, color: "#fff" }}>
              {gateState.leftChannel ? "Channel Membership Lost" : "Join Official Channel"}
            </div>
            <div style={{ fontSize: 13, color: "rgba(255,255,255,0.7)", marginTop: 8, lineHeight: 1.55 }}>
              {gateState.leftChannel
                ? "You left the official SINGULARITY WebOS Telegram channel. Rejoin the channel to unlock the app again."
                : "Joining the official SINGULARITY WebOS Telegram channel is required to use the app and receive updates."}
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: 10, marginTop: 20 }}>
              <button
                type="button"
                onClick={() => openExternalUrl(channelUrl)}
                style={{
                  width: "100%",
                  padding: "13px 16px",
                  borderRadius: 12,
                  border: "none",
                  background: "#229ED9",
                  color: "#fff",
                  fontSize: 14,
                  fontWeight: 700,
                  cursor: "pointer"
                }}
              >
                1. Join Telegram Channel
              </button>

              <button
                type="button"
                onClick={() => openExternalUrl(botVerifyUrl)}
                style={{
                  width: "100%",
                  padding: "13px 16px",
                  borderRadius: 12,
                  border: "1px solid rgba(255,255,255,0.16)",
                  background: "rgba(255,255,255,0.08)",
                  color: "#fff",
                  fontSize: 14,
                  fontWeight: 700,
                  cursor: "pointer"
                }}
              >
                2. Verify with @{TELEGRAM_BOT_USERNAME}
              </button>

              <button
                type="button"
                disabled={checking}
                onClick={handleRecheck}
                style={{
                  width: "100%",
                  padding: "13px 16px",
                  borderRadius: 12,
                  border: "none",
                  background: "linear-gradient(135deg, #e50914, #b80710)",
                  color: "#fff",
                  fontSize: 14,
                  fontWeight: 700,
                  cursor: checking ? "not-allowed" : "pointer",
                  opacity: checking ? 0.7 : 1
                }}
              >
                {checking ? "Checking Membership..." : "3. I've Joined — Check Now"}
              </button>
            </div>

            <button
              type="button"
              onClick={() => signOutAccount()}
              style={{
                marginTop: 16,
                background: "none",
                border: "none",
                color: "rgba(255,255,255,0.55)",
                fontSize: 13,
                cursor: "pointer"
              }}
            >
              Sign Out
            </button>
          </>
        )}
      </div>
    </div>
  );
}
