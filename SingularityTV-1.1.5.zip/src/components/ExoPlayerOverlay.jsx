import React, { useState, useEffect, useRef, useCallback } from "react";
import { CloseIcon, PlayIcon, SubtitlesIcon, BackIcon } from "./Icons";
import { storage, STORAGE_KEYS } from "../utils/storage";
import { setGamepadFocus } from "../utils/gamepadSpatialNav";

export function parseSubtitleCues(rawText) {
  if (!rawText || typeof rawText !== "string") return [];
  const normalized = rawText.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  const blocks = normalized.split(/\n\n+/);
  const cues = [];
  const parseTime = t => {
    const clean = t.trim().replace(",", ".");
    const parts = clean.split(":");
    if (parts.length === 3) {
      return parseInt(parts[0], 10) * 3600 + parseInt(parts[1], 10) * 60 + parseFloat(parts[2]);
    }
    if (parts.length === 2) {
      return parseInt(parts[0], 10) * 60 + parseFloat(parts[1]);
    }
    return 0;
  };
  for (const block of blocks) {
    const lines = block.split("\n").map(l => l.trim()).filter(Boolean);
    if (!lines.length || lines[0].startsWith("WEBVTT")) continue;
    const arrowIdx = lines.findIndex(l => l.includes("-->"));
    if (arrowIdx === -1) continue;
    const [startStr, endPart] = lines[arrowIdx].split("-->");
    const endStr = (endPart || "").trim().split(/\s+/)[0];
    const start = parseTime(startStr);
    const end = parseTime(endStr);
    const text = lines.slice(arrowIdx + 1).join("\n").replace(/<[^>]+>/g, "");
    if (Number.isFinite(start) && Number.isFinite(end) && text) {
      cues.push({ start, end, text });
    }
  }
  return cues;
}

const SPEEDS = [0.75, 1.0, 1.25, 1.5, 2.0];
const SUB_SIZES = [
  { id: "sm", label: "Small", px: 16 },
  { id: "normal", label: "Normal", px: 22 },
  { id: "lg", label: "Large", px: 28 },
  { id: "xl", label: "TV XL", px: 34 }
];

export default function ExoPlayerOverlay({ session, onClose, onProgressUpdate }) {
  const videoRef = useRef(null);
  const playBtnRef = useRef(null);
  const hideTimerRef = useRef(null);
  const [playing, setPlaying] = useState(true);
  const [controlsVisible, setControlsVisible] = useState(true);
  const [currentTime, setCurrentTime] = useState(session?.startTimeSec || 0);
  const [duration, setDuration] = useState(0);
  const [speed, setSpeed] = useState(1.0);
  const [subDelaySec, setSubDelaySec] = useState(() => (Number(storage.get(STORAGE_KEYS.SUBTITLE_DELAY_MS)) || 0) / 1000);
  const [subSize, setSubSize] = useState(() => storage.get(STORAGE_KEYS.SUBTITLE_FONT_SCALE) || "normal");
  const [subBottomPct, setSubBottomPct] = useState(() => Number(storage.get(STORAGE_KEYS.SUBTITLE_POSITION)) || 10);
  const [activeSubIdx, setActiveSubIdx] = useState(0);
  const [cues, setCues] = useState([]);
  const [activeCueText, setActiveCueText] = useState("");
  const [showSubPanel, setShowSubPanel] = useState(false);
  const [errorMsg, setErrorMsg] = useState(null);

  const subtitles = session?.subtitles || [];

  const revealControls = useCallback(() => {
    setControlsVisible(true);
    if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    hideTimerRef.current = setTimeout(() => {
      if (videoRef.current && !videoRef.current.paused && !showSubPanel) {
        setControlsVisible(false);
      }
    }, 4500);
  }, [showSubPanel]);

  useEffect(() => {
    revealControls();
    const tid = setTimeout(() => {
      if (playBtnRef.current) setGamepadFocus(playBtnRef.current, { scroll: false });
    }, 80);
    return () => {
      clearTimeout(tid);
      if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    };
  }, [revealControls]);

  useEffect(() => {
    if (activeSubIdx < 0 || !subtitles[activeSubIdx]?.url) {
      setCues([]);
      return;
    }
    let cancelled = false;
    fetch(subtitles[activeSubIdx].url)
      .then(r => r.text())
      .then(txt => {
        if (!cancelled) setCues(parseSubtitleCues(txt));
      })
      .catch(() => {
        if (!cancelled) setCues([]);
      });
    return () => {
      cancelled = true;
    };
  }, [activeSubIdx, subtitles]);

  useEffect(() => {
    if (!cues.length) {
      setActiveCueText("");
      return;
    }
    const adjusted = currentTime - subDelaySec;
    const hit = cues.find(c => adjusted >= c.start && adjusted <= c.end);
    setActiveCueText(hit ? hit.text : "");
  }, [currentTime, subDelaySec, cues]);

  const changeSpeed = next => {
    setSpeed(next);
    if (videoRef.current) videoRef.current.playbackRate = next;
    revealControls();
  };

  const seekBy = useCallback(
    delta => {
      const v = videoRef.current;
      if (!v) return;
      v.currentTime = Math.max(0, Math.min(v.duration || 1e9, v.currentTime + delta));
      revealControls();
    },
    [revealControls]
  );

  const togglePlay = useCallback(() => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) v.play();
    else v.pause();
    revealControls();
  }, [revealControls]);

  useEffect(() => {
    const onActivity = () => revealControls();
    window.addEventListener("keydown", onActivity);
    window.addEventListener("streambert:dpad", onActivity);
    return () => {
      window.removeEventListener("keydown", onActivity);
      window.removeEventListener("streambert:dpad", onActivity);
    };
  }, [revealControls]);

  if (!session) return null;

  const fmtTime = s => {
    if (!s || !Number.isFinite(s)) return "0:00";
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = Math.floor(s % 60);
    return h > 0
      ? `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`
      : `${m}:${String(sec).padStart(2, "0")}`;
  };

  const fontPx = SUB_SIZES.find(s => s.id === subSize)?.px ?? 22;
  const pct = duration > 0 ? Math.min(100, (currentTime / duration) * 100) : 0;

  return (
    <div
      className="nf-player-overlay"
      onMouseMove={revealControls}
      onTouchStart={revealControls}
    >
      <video
        ref={videoRef}
        src={session.url}
        autoPlay
        playsInline
        controls={false}
        onClick={togglePlay}
        onLoadedMetadata={e => {
          setDuration(e.currentTarget.duration || 0);
          if (session.startTimeSec > 0) {
            e.currentTarget.currentTime = session.startTimeSec;
          }
        }}
        onTimeUpdate={e => {
          const ct = e.currentTarget.currentTime;
          const dur = e.currentTarget.duration || 0;
          setCurrentTime(ct);
          if (dur > 0 && onProgressUpdate) {
            onProgressUpdate(ct, dur);
          }
        }}
        onPlay={() => setPlaying(true)}
        onPause={() => {
          setPlaying(false);
          setControlsVisible(true);
        }}
        onError={() => setErrorMsg("Stream requires Native Android ExoPlayer headers or a different source.")}
        className="nf-player-video"
      />

      {activeCueText && (
        <div className="nf-subtitle-wrap" style={{ bottom: `${subBottomPct}%` }}>
          <span className="nf-subtitle-text" style={{ fontSize: fontPx }}>
            {activeCueText}
          </span>
        </div>
      )}

      <div className={`nf-player-chrome${controlsVisible || !playing || showSubPanel ? " visible" : ""}`}>
        <div className="nf-player-topbar">
          <div className="nf-player-title-group">
            <button
              className="nf-player-btn nf-player-back"
              data-gamepad-close="1"
              onClick={onClose}
              aria-label="Back"
            >
              <BackIcon />
            </button>
            <div className="nf-player-title-text">
              <span className="nf-player-badge">NETFLIX PLAYER</span>
              <h2 className="nf-player-title">{session.title || "SingularityTV"}</h2>
            </div>
          </div>

          <button
            className={`nf-player-btn nf-player-pill-btn${showSubPanel ? " active" : ""}`}
            onClick={() => setShowSubPanel(v => !v)}
          >
            <SubtitlesIcon size={16} />
            <span>Audio & Subtitles</span>
          </button>
        </div>

        {showSubPanel && (
          <div className="nf-sub-panel" onClick={e => e.stopPropagation()}>
            <div className="nf-sub-panel-header">
              <span>Subtitles & Sync</span>
              <button className="nf-player-btn nf-sub-close" onClick={() => setShowSubPanel(false)}>
                <CloseIcon />
              </button>
            </div>
            <div className="nf-sub-section">
              <div className="nf-sub-label">Track</div>
              <div className="nf-sub-row">
                <button
                  className={`nf-player-btn nf-sub-chip${activeSubIdx === -1 ? " active" : ""}`}
                  onClick={() => setActiveSubIdx(-1)}
                >
                  Off
                </button>
                {subtitles.map((s, idx) => (
                  <button
                    key={idx}
                    className={`nf-player-btn nf-sub-chip${activeSubIdx === idx ? " active" : ""}`}
                    onClick={() => setActiveSubIdx(idx)}
                  >
                    {(s.lang || `Track ${idx + 1}`).toUpperCase()}
                  </button>
                ))}
              </div>
            </div>
            <div className="nf-sub-section">
              <div className="nf-sub-label">
                Sync Delay ({subDelaySec >= 0 ? `+${subDelaySec.toFixed(1)}s` : `${subDelaySec.toFixed(1)}s`})
              </div>
              <div className="nf-sub-row">
                <button
                  className="nf-player-btn nf-sub-chip"
                  onClick={() => {
                    const next = Math.round((subDelaySec - 0.2) * 10) / 10;
                    setSubDelaySec(next);
                    storage.set(STORAGE_KEYS.SUBTITLE_DELAY_MS, next * 1000);
                  }}
                >
                  -0.2s
                </button>
                <button
                  className="nf-player-btn nf-sub-chip"
                  onClick={() => {
                    setSubDelaySec(0);
                    storage.set(STORAGE_KEYS.SUBTITLE_DELAY_MS, 0);
                  }}
                >
                  0.0s
                </button>
                <button
                  className="nf-player-btn nf-sub-chip"
                  onClick={() => {
                    const next = Math.round((subDelaySec + 0.2) * 10) / 10;
                    setSubDelaySec(next);
                    storage.set(STORAGE_KEYS.SUBTITLE_DELAY_MS, next * 1000);
                  }}
                >
                  +0.2s
                </button>
              </div>
            </div>
            <div className="nf-sub-section">
              <div className="nf-sub-label">Font Size</div>
              <div className="nf-sub-row">
                {SUB_SIZES.map(s => (
                  <button
                    key={s.id}
                    className={`nf-player-btn nf-sub-chip${subSize === s.id ? " active" : ""}`}
                    onClick={() => {
                      setSubSize(s.id);
                      storage.set(STORAGE_KEYS.SUBTITLE_FONT_SCALE, s.id);
                    }}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        <div className="nf-player-bottom">
          <div className="nf-progress-row">
            <div className="nf-progress-track-wrap">
              <input
                type="range"
                className="nf-progress"
                min={0}
                max={Math.max(1, Math.floor(duration))}
                value={Math.floor(currentTime)}
                style={{
                  background: `linear-gradient(to right, #e50914 ${pct}%, rgba(255,255,255,0.25) ${pct}%)`
                }}
                onChange={e => {
                  const val = Number(e.target.value);
                  setCurrentTime(val);
                  if (videoRef.current) videoRef.current.currentTime = val;
                  revealControls();
                }}
              />
            </div>
            <span className="nf-time-display">
              {fmtTime(currentTime)} / {fmtTime(duration)}
            </span>
          </div>

          <div className="nf-player-main-controls">
            <div className="nf-controls-left">
              <button
                ref={playBtnRef}
                className="nf-player-btn nf-play-toggle"
                onClick={togglePlay}
              >
                <PlayIcon />
                <span>{playing ? "Pause" : "Play"}</span>
              </button>
              <button className="nf-player-btn nf-seek-btn" onClick={() => seekBy(-10)}>
                ↺ 10s
              </button>
              <button className="nf-player-btn nf-seek-btn" onClick={() => seekBy(10)}>
                10s ↻
              </button>
            </div>

            <div className="nf-controls-right">
              {SPEEDS.map(s => (
                <button
                  key={s}
                  className={`nf-player-btn nf-speed-btn${speed === s ? " active" : ""}`}
                  onClick={() => changeSpeed(s)}
                >
                  {s}x
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {errorMsg && (
        <div className="nf-player-error">
          <div style={{ fontSize: 16, fontWeight: 600, color: "#e50914" }}>{errorMsg}</div>
          <button className="nf-player-btn nf-play-toggle" onClick={onClose}>
            Return
          </button>
        </div>
      )}
    </div>
  );
}
