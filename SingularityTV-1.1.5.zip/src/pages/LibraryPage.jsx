import React, { useCallback, useMemo, useState, useEffect } from "react";
import MediaCard from "../components/MediaCard";
import { imgUrl } from "../utils/api";
import { EyeIcon, WatchedIcon, PlayIcon, DownloadIcon, FilmIcon, TrashIcon } from "../components/Icons";
import { useRatings, getRatingForItem } from "../utils/useRatings";
import { isRestricted } from "../utils/ageRating";
import { storage, STORAGE_KEYS } from "../utils/storage";

export default function LibraryPage({
  history = [],
  inProgress = [],
  saved = [],
  progress = {},
  onSelect,
  watched,
  onMarkWatched,
  onMarkUnwatched,
  onRemoveHistory,
  downloads = [],
  onOpenExoPlayer
}) {
  const [activeTab, setActiveTab] = useState("all");
  const allItems = useMemo(() => [...inProgress, ...saved], [inProgress, saved]);
  const { ratingsMap, ageLimitSetting } = useRatings(allItems);

  const offlineDownloads = useMemo(() => {
    return (downloads || []).filter(
      d => d && (d.status === "completed" || d.status === "local") && (d.outputPath || d.filePath || d.path)
    );
  }, [downloads]);

  const playOfflineDownload = useCallback(
    dl => {
      const fileUrl = dl.outputPath || dl.filePath || dl.path;
      if (!fileUrl) return;
      const pk =
        dl.mediaType === "tv"
          ? `tv_${dl.tmdbId || dl.mediaId}_s${dl.season || 1}e${dl.episode || 1}`
          : `movie_${dl.tmdbId || dl.mediaId}`;
      const startSec = storage.get("dlTime_" + pk) || 0;
      const payload = {
        url: fileUrl,
        title: dl.name || dl.title || "Offline Video",
        startTimeSec: startSec,
        subtitles: dl.subtitles || [],
        progressKey: pk,
        mediaType: dl.mediaType || "movie",
        subTextColor: storage.get("subtitleTextColor") || "#FFFFFF",
        subBgStyle: storage.get("subtitleBgStyle") || "dark",
        subFontSizeSp: Number(storage.get("subtitleFontSizeSp") || 22),
        preferredSubLang: storage.get(STORAGE_KEYS.SUBTITLE_LANG) || "ar"
      };
      if (window.AndroidBridge?.openExoPlayer) {
        window.AndroidBridge.openExoPlayer(JSON.stringify(payload));
      } else {
        onOpenExoPlayer?.(payload);
      }
    },
    [onOpenExoPlayer]
  );

  const getRating = useCallback(item => getRatingForItem(item, ratingsMap), [ratingsMap]);
  const itemRestricted = useCallback(
    item => isRestricted(getRating(item).minAge, ageLimitSetting),
    [getRating, ageLimitSetting]
  );

  const tabs = [
    { id: "all", label: "All", count: null },
    { id: "continue", label: "Continue", count: inProgress.length },
    { id: "saved", label: "Watchlist", count: saved.length },
    { id: "history", label: "History", count: history.length },
    { id: "offline", label: "Offline", count: offlineDownloads.length }
  ];

  const showContinue = (activeTab === "all" || activeTab === "continue") && inProgress.length > 0;
  const showSaved = (activeTab === "all" || activeTab === "saved") && saved.length > 0;
  const showHistory = (activeTab === "all" || activeTab === "history") && history.length > 0;
  const showOffline = (activeTab === "all" || activeTab === "offline") && offlineDownloads.length > 0;
  const isEmpty = !showContinue && !showSaved && !showHistory && !showOffline;

  return React.createElement("div", { className: "sg4-space-page fade-in" },
    React.createElement("div", { className: "sg4-space-header" },
      React.createElement("div", null,
        React.createElement("span", { className: "sg4-space-kicker" }, "PERSONAL UNIVERSE"),
        React.createElement("h1", { className: "sg4-space-title" }, "My Space")
      ),
      React.createElement("div", { className: "sg4-space-tabs" },
        tabs.map(t => React.createElement("button", {
          key: t.id,
          className: `sg4-space-tab${activeTab === t.id ? " active" : ""}`,
          onClick: () => setActiveTab(t.id)
        },
          React.createElement("span", null, t.label),
          t.count != null && t.count > 0 && React.createElement("span", { className: "sg4-space-tab-count" }, t.count)
        ))
      )
    ),

    showOffline && React.createElement("section", { className: "sg4-space-section" },
      React.createElement("div", { className: "sg3-section-head" },
        React.createElement("h2", { className: "sg3-section-title" }, "Offline Ready"),
        React.createElement("span", { className: "sg3-section-kicker" }, `${offlineDownloads.length} DOWNLOADED`)
      ),
      React.createElement("div", { className: "sg4-offline-grid" },
        offlineDownloads.map(dl => React.createElement("button", {
          key: dl.id,
          className: "sg4-offline-card card",
          onClick: () => playOfflineDownload(dl)
        },
          React.createElement("div", { className: "sg4-offline-thumb" },
            dl.posterPath
              ? React.createElement("img", { src: imgUrl(dl.posterPath, "w185"), alt: dl.name || dl.title, loading: "lazy" })
              : React.createElement("div", { className: "sg4-offline-fallback" }, React.createElement(FilmIcon)),
            React.createElement("span", { className: "sg4-offline-play" }, React.createElement(PlayIcon))
          ),
          React.createElement("div", { className: "sg4-offline-info" },
            React.createElement("div", { className: "sg4-offline-title" }, dl.name || dl.title),
            React.createElement("div", { className: "sg4-offline-meta" }, `${dl.size || "Ready"} · ${dl.mediaType === "tv" ? "Series" : "Film"}`)
          )
        ))
      )
    ),

    showContinue && React.createElement("section", { className: "sg4-space-section" },
      React.createElement("div", { className: "sg3-section-head" },
        React.createElement("h2", { className: "sg3-section-title" }, "Continue Watching"),
        React.createElement("span", { className: "sg3-section-kicker" }, `${inProgress.length} IN PROGRESS`)
      ),
      React.createElement("div", { className: activeTab === "continue" ? "sg4-landscape-grid" : "scroll-row tv-scroll-row" },
        inProgress.map(item => {
          const pk = item.media_type === "movie" ? `movie_${item.id}` : `tv_${item.id}_s${item.season}e${item.episode}`;
          const r = getRating(item);
          return React.createElement(MediaCard, {
            key: pk,
            item,
            variant: "landscape",
            onClick: () => onSelect(item),
            progress: progress[pk] || 0,
            watched,
            onMarkWatched,
            onMarkUnwatched,
            ageRating: r.cert,
            restricted: itemRestricted(item)
          });
        })
      )
    ),

    showSaved && React.createElement("section", { className: "sg4-space-section" },
      React.createElement("div", { className: "sg3-section-head" },
        React.createElement("h2", { className: "sg3-section-title" }, "Watchlist"),
        React.createElement("span", { className: "sg3-section-kicker" }, `${saved.length} SAVED`)
      ),
      React.createElement("div", { className: "sg4-poster-grid" },
        saved.map(item => {
          const r = getRating(item);
          return React.createElement(MediaCard, {
            key: `${item.media_type}_${item.id}`,
            item,
            variant: "poster",
            onClick: () => onSelect(item),
            watched,
            onMarkWatched,
            onMarkUnwatched,
            ageRating: r.cert,
            restricted: itemRestricted(item)
          });
        })
      )
    ),

    showHistory && React.createElement("section", { className: "sg4-space-section" },
      React.createElement("div", { className: "sg3-section-head" },
        React.createElement("h2", { className: "sg3-section-title" }, "Watch History"),
        React.createElement("span", { className: "sg3-section-kicker" }, `${history.length} TITLES`)
      ),
      React.createElement("div", { className: "sg4-history-list" },
        history.map(item => {
          const pk = item.media_type === "movie" ? `movie_${item.id}` : `tv_${item.id}_s${item.season}e${item.episode}`;
          const isWatched = !!watched?.[pk];
          return React.createElement("div", {
            key: `${pk}_${item.watchedAt}`,
            className: "sg4-history-item card",
            onClick: () => onSelect(item)
          },
            React.createElement("div", { className: "sg4-history-poster" },
              item.poster_path && React.createElement("img", { src: imgUrl(item.poster_path, "w154"), alt: item.title || "", loading: "lazy" })
            ),
            React.createElement("div", { className: "sg4-history-body" },
              React.createElement("div", { className: "sg4-history-title" },
                React.createElement("span", null, item.title || item.name),
                isWatched && React.createElement(WatchedIcon, { size: 15 })
              ),
              React.createElement("div", { className: "sg4-history-meta" },
                item.media_type === "tv" && item.season != null && item.episode != null
                  ? `S${item.season} E${item.episode}${item.episodeName ? ` · ${item.episodeName}` : ""} · `
                  : `${item.media_type === "tv" ? "Series" : "Film"} · `,
                new Date(item.watchedAt).toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" })
              )
            ),
            onRemoveHistory && React.createElement("button", {
              className: "sg4-history-del",
              "aria-label": "Remove from history",
              onClick: e => { e.stopPropagation(); onRemoveHistory(item); }
            }, React.createElement(TrashIcon))
          );
        })
      )
    ),

    isEmpty && React.createElement("div", { className: "empty-state sg4-empty" },
      React.createElement(EyeIcon),
      React.createElement("h3", null, "Your space is empty"),
      React.createElement("p", null, "Start watching or save titles to build your personal universe.")
    )
  );
}
