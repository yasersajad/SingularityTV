import React, { useState, useEffect, useMemo, useCallback, useRef } from "react";
import MediaCard from "../components/MediaCard";
import HeroBanner from "../components/HeroBanner";
import { tmdbFetch, imgUrl, isAnimeContent } from "../utils/api";
import { WifiOffIcon, PlayIcon, StarIcon } from "../components/Icons";
import { useRatings, getRatingForItem } from "../utils/useRatings";
import { isRestricted } from "../utils/ageRating";

function getRecentHistoryItems(history, count = 5) {
  if (!history || history.length === 0) return [];
  const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;
  const recent = history.filter(h => h.watchedAt && h.watchedAt > thirtyDaysAgo).sort((a, b) => b.watchedAt - a.watchedAt);
  const seen = new Set();
  const unique = [];
  for (const item of recent) {
    const key = `${item.media_type || "movie"}_${item.id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    unique.push(item);
    if (unique.length >= count) break;
  }
  return unique;
}

function EditorialSpotlight({ title, items, onSelect }) {
  if (!items || items.length < 3) return null;
  const lead = items[0];
  const side = items.slice(1, 4);
  const leadImg = imgUrl(lead.backdrop_path || lead.poster_path, "w780");
  const leadTitle = lead.title || lead.name;
  const leadYear = (lead.release_date || lead.first_air_date || "").slice(0, 4);

  return React.createElement("section", { className: "sg3-section sg3-editorial-section" },
    React.createElement("div", { className: "sg3-section-head" },
      React.createElement("h2", { className: "sg3-section-title" }, title),
      React.createElement("span", { className: "sg3-section-kicker" }, "CURATED SPOTLIGHT")
    ),
    React.createElement("div", { className: "sg3-editorial-grid" },
      React.createElement("button", {
        className: "sg3-editorial-lead card",
        onClick: () => onSelect(lead)
      },
        leadImg && React.createElement("img", { src: leadImg, alt: leadTitle, loading: "lazy", decoding: "async" }),
        React.createElement("div", { className: "sg3-editorial-scrim" }),
        React.createElement("div", { className: "sg3-editorial-lead-copy" },
          React.createElement("span", { className: "sg3-editorial-tag" },
            lead.media_type === "tv" ? "SERIES" : "FILM",
            leadYear ? ` · ${leadYear}` : "",
            lead.vote_average > 0 ? ` · ★ ${lead.vote_average.toFixed(1)}` : ""
          ),
          React.createElement("h3", { className: "sg3-editorial-lead-title" }, leadTitle),
          lead.overview && React.createElement("p", { className: "sg3-editorial-lead-desc" }, lead.overview)
        )
      ),
      React.createElement("div", { className: "sg3-editorial-stack" },
        side.map((item, idx) => {
          const thumb = imgUrl(item.backdrop_path || item.poster_path, "w300");
          const t = item.title || item.name;
          const yr = (item.release_date || item.first_air_date || "").slice(0, 4);
          return React.createElement("button", {
            key: `ed_${item.id}_${idx}`,
            className: "sg3-editorial-mini card",
            onClick: () => onSelect(item)
          },
            thumb && React.createElement("img", { className: "sg3-editorial-mini-img", src: thumb, alt: t, loading: "lazy", decoding: "async" }),
            React.createElement("div", { className: "sg3-editorial-mini-meta" },
              React.createElement("span", { className: "sg3-editorial-mini-num" }, `0${idx + 2}`),
              React.createElement("div", { className: "sg3-editorial-mini-title" }, t),
              React.createElement("div", { className: "sg3-editorial-mini-sub" },
                `${yr ? yr + " · " : ""}${item.media_type === "tv" ? "Series" : "Movie"}${item.vote_average > 0 ? " · ★ " + item.vote_average.toFixed(1) : ""}`
              )
            )
          );
        })
      )
    )
  );
}

function MinimalDiscoveryRow({ title, items, onSelect }) {
  if (!items || items.length === 0) return null;
  return React.createElement("section", { className: "sg3-section" },
    React.createElement("div", { className: "sg3-section-head" },
      React.createElement("h2", { className: "sg3-section-title" }, title)
    ),
    React.createElement("div", { className: "sg3-minimal-strip" },
      items.slice(0, 10).map((item, idx) => {
        const t = item.title || item.name;
        const yr = (item.release_date || item.first_air_date || "").slice(0, 4);
        const thumb = imgUrl(item.poster_path || item.backdrop_path, "w185");
        return React.createElement("button", {
          key: `min_${item.id}_${idx}`,
          className: "sg3-minimal-pill card",
          onClick: () => onSelect(item)
        },
          thumb && React.createElement("img", { src: thumb, alt: t, loading: "lazy", decoding: "async" }),
          React.createElement("div", { className: "sg3-minimal-info" },
            React.createElement("div", { className: "sg3-minimal-title" }, t),
            React.createElement("div", { className: "sg3-minimal-sub" },
              `${yr || "New"} · ${item.vote_average > 0 ? "★ " + item.vote_average.toFixed(1) : "Curated"}`
            )
          )
        );
      })
    )
  );
}

export default function HomePage({
  trending, trendingTV, loading, onSelect, progress, inProgress, offline, onRetry,
  watched, onMarkWatched, onMarkUnwatched, history, savedList = [], onToggleSave,
  isSavedFn, activeFilter = "all", isTvMode = false, apiKey
}) {
  const [recommendedItems, setRecommendedItems] = useState([]);
  const [topRatedItems, setTopRatedItems] = useState([]);
  const [popularMovies, setPopularMovies] = useState([]);
  const [popularTV, setPopularTV] = useState([]);
  const [animeItems, setAnimeItems] = useState([]);
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [categoryItems, setCategoryItems] = useState([]);
  const [loadingCategory, setLoadingCategory] = useState(false);
  const [categoryPage, setCategoryPage] = useState(1);
  const [categoryHasMore, setCategoryHasMore] = useState(false);
  const [loadingMoreCategory, setLoadingMoreCategory] = useState(false);
  const [exploreItems, setExploreItems] = useState([]);
  const [explorePage, setExplorePage] = useState(1);
  const [exploreHasMore, setExploreHasMore] = useState(true);
  const [loadingMoreExplore, setLoadingMoreExplore] = useState(false);
  const sentinelRef = useRef(null);
  const categoryItemsRef = useRef([]);
  const exploreItemsRef = useRef([]);
  useEffect(() => { exploreItemsRef.current = exploreItems; }, [exploreItems]);
  useEffect(() => { categoryItemsRef.current = categoryItems; }, [categoryItems]);

  const CATEGORIES = useMemo(() => ["All", "Action", "Sci-Fi", "Thriller", "Drama", "Fantasy", "Horror", "Comedy", "Animation", "Mystery", "Crime", "Adventure", "Documentary"], []);

  const allItems = useMemo(() => [
    ...inProgress, ...trending.map(i => ({ ...i, media_type: "movie" })), ...trendingTV.map(i => ({ ...i, media_type: "tv" })),
    ...recommendedItems, ...topRatedItems, ...popularMovies, ...popularTV, ...animeItems
  ], [inProgress, trending, trendingTV, recommendedItems, topRatedItems, popularMovies, popularTV, animeItems]);

  const { ratingsMap, ageLimitSetting } = useRatings(allItems);
  const itemRestricted = useCallback(item => isRestricted(getRatingForItem(item, ratingsMap).minAge, ageLimitSetting), [ratingsMap, ageLimitSetting]);
  const enrichedRatingsMap = useMemo(() => {
    const out = {};
    for (const [k, v] of Object.entries(ratingsMap)) out[k] = { ...v, restricted: isRestricted(v.minAge, ageLimitSetting) };
    return out;
  }, [ratingsMap, ageLimitSetting]);
  const filteredRecommendedItems = useMemo(() => recommendedItems.filter(item => !itemRestricted(item)), [recommendedItems, itemRestricted]);

  const lastWatchedTitle = useMemo(() => {
    const recent = getRecentHistoryItems(history, 1);
    return recent[0]?.title || recent[0]?.name || null;
  }, [history]);

  useEffect(() => {
    if (!apiKey || offline || !history || history.length === 0) return;
    const sources = getRecentHistoryItems(history, 4);
    if (sources.length === 0) return;
    const controller = new AbortController();
    const watchedIds = new Set((history || []).map(h => `${h.media_type || "movie"}_${h.id}`));
    Promise.all(sources.map(source => {
      const type = source.media_type === "tv" ? "tv" : "movie";
      return tmdbFetch(`/${type}/${source.id}/recommendations`, apiKey, { signal: controller.signal })
        .then(data => {
          const results = (data.results || []).map(i => ({ ...i, media_type: type }));
          return results.length > 0 ? results : tmdbFetch(`/${type}/${source.id}/similar`, apiKey, { signal: controller.signal }).then(d => (d.results || []).map(i => ({ ...i, media_type: type })));
        }).catch(() => []);
    })).then(arrays => {
      const merged = [];
      const maxLen = Math.max(...arrays.map(a => a.length));
      for (let i = 0; i < maxLen; i++) for (const arr of arrays) if (arr[i]) merged.push(arr[i]);
      const seen = new Set();
      setRecommendedItems(merged.filter(item => {
        const key = `${item.media_type}_${item.id}`;
        if (seen.has(key) || watchedIds.has(key)) return false;
        seen.add(key);
        return true;
      }).slice(0, 18));
    }).catch(() => {});
    return () => controller.abort();
  }, [apiKey, offline, history?.length]);

  useEffect(() => {
    if (selectedCategory === "All" || offline) { setCategoryItems([]); setLoadingCategory(false); setCategoryPage(1); setCategoryHasMore(false); return; }
    let mounted = true;
    setLoadingCategory(true); setCategoryPage(1); setCategoryHasMore(false);
    tmdbFetch(`/discover/genre?genre=${encodeURIComponent(selectedCategory)}&page=1`, apiKey)
      .then(data => { if (mounted) { const list = data?.results || []; setCategoryItems(list); setCategoryHasMore(list.length > 0 && (data?.hasMore !== false)); } })
      .catch(() => { if (mounted) setCategoryItems([]); })
      .finally(() => { if (mounted) setLoadingCategory(false); });
    return () => { mounted = false; };
  }, [selectedCategory, apiKey, offline]);

  const loadMoreCategory = useCallback(() => {
    if (loadingMoreCategory || !categoryHasMore || selectedCategory === "All" || offline) return;
    const nextPage = categoryPage + 1;
    setLoadingMoreCategory(true);
    tmdbFetch(`/discover/genre?genre=${encodeURIComponent(selectedCategory)}&page=${nextPage}`, apiKey)
      .then(data => {
        const nextItems = data?.results || [];
        const seen = new Set(categoryItemsRef.current.map(x => `${x.media_type}_${x.id}`));
        const newUnique = nextItems.filter(item => !seen.has(`${item.media_type}_${item.id}`));
        if (newUnique.length > 0) { setCategoryItems(prev => [...prev, ...newUnique]); setCategoryPage(nextPage); setCategoryHasMore(nextItems.length >= 6 && nextPage < 15 && data?.hasMore !== false); }
        else setCategoryHasMore(false);
      }).catch(() => setCategoryHasMore(false)).finally(() => setLoadingMoreCategory(false));
  }, [loadingMoreCategory, categoryHasMore, selectedCategory, offline, categoryPage, apiKey]);

  useEffect(() => {
    if (activeFilter !== "explore" || selectedCategory !== "All" || offline) return;
    if (exploreItemsRef.current.length > 0) return;
    setLoadingMoreExplore(true);
    Promise.all([
      tmdbFetch("/trending/movie/week?page=1", apiKey),
      tmdbFetch("/trending/tv/week?page=1", apiKey)
    ]).then(([m, t]) => {
      const mList = (m?.results || []).map(i => ({ ...i, media_type: "movie" }));
      const tList = (t?.results || []).map(i => ({ ...i, media_type: "tv" }));
      const merged = [];
      const max = Math.max(mList.length, tList.length);
      for (let i = 0; i < max; i++) { if (mList[i]) merged.push(mList[i]); if (tList[i]) merged.push(tList[i]); }
      setExploreItems(merged);
      setExplorePage(1);
      setExploreHasMore(true);
    }).catch(() => {}).finally(() => setLoadingMoreExplore(false));
  }, [activeFilter, selectedCategory, offline, apiKey]);

  const loadMoreExplore = useCallback(() => {
    if (loadingMoreExplore || !exploreHasMore || offline) return;
    const nextPage = explorePage + 1;
    setLoadingMoreExplore(true);
    Promise.all([
      tmdbFetch(`/discover/movie?sort_by=popularity.desc&page=${nextPage}`, apiKey),
      tmdbFetch(`/discover/tv?sort_by=popularity.desc&page=${nextPage}`, apiKey)
    ]).then(([m, t]) => {
      const mList = (m?.results || []).map(i => ({ ...i, media_type: "movie" }));
      const tList = (t?.results || []).map(i => ({ ...i, media_type: "tv" }));
      const seen = new Set(exploreItemsRef.current.map(x => `${x.media_type}_${x.id}`));
      const fresh = [];
      const max = Math.max(mList.length, tList.length);
      for (let i = 0; i < max; i++) {
        if (mList[i] && !seen.has(`movie_${mList[i].id}`)) { seen.add(`movie_${mList[i].id}`); fresh.push(mList[i]); }
        if (tList[i] && !seen.has(`tv_${tList[i].id}`)) { seen.add(`tv_${tList[i].id}`); fresh.push(tList[i]); }
      }
      if (fresh.length > 0) {
        setExploreItems(prev => [...prev, ...fresh]);
        setExplorePage(nextPage);
        setExploreHasMore(nextPage < 15);
      } else {
        setExploreHasMore(false);
      }
    }).catch(() => setExploreHasMore(false)).finally(() => setLoadingMoreExplore(false));
  }, [loadingMoreExplore, exploreHasMore, offline, explorePage, apiKey]);

  useEffect(() => {
    const node = sentinelRef.current;
    if (!node || typeof IntersectionObserver === "undefined") return;
    const obs = new IntersectionObserver(entries => {
      if (entries[0]?.isIntersecting) {
        if (selectedCategory !== "All") loadMoreCategory();
        else if (activeFilter === "explore") loadMoreExplore();
      }
    }, { rootMargin: "420px" });
    obs.observe(node);
    return () => obs.disconnect();
  }, [selectedCategory, activeFilter, loadMoreCategory, loadMoreExplore]);

  useEffect(() => {
    if (!apiKey || offline) return;
    const controller = new AbortController();
    Promise.all([
      tmdbFetch("/movie/top_rated?page=1", apiKey, { signal: controller.signal }),
      tmdbFetch("/tv/top_rated?page=1", apiKey, { signal: controller.signal }),
      tmdbFetch("/movie/popular?page=1", apiKey, { signal: controller.signal }),
      tmdbFetch("/tv/popular?page=1", apiKey, { signal: controller.signal }),
      tmdbFetch("/discover/tv?with_genres=16&with_original_language=ja&sort_by=popularity.desc&page=1", apiKey, { signal: controller.signal })
    ]).then(([moviesData, tvData, popM, popT, anim]) => {
      const movies = (moviesData.results || []).slice(0, 12).map(i => ({ ...i, media_type: "movie" }));
      const tv = (tvData.results || []).slice(0, 12).map(i => ({ ...i, media_type: "tv" }));
      const merged = [];
      const max = Math.max(movies.length, tv.length);
      for (let i = 0; i < max; i++) { if (movies[i]) merged.push(movies[i]); if (tv[i]) merged.push(tv[i]); }
      setTopRatedItems(merged);
      setPopularMovies((popM.results || []).slice(0, 16).map(i => ({ ...i, media_type: "movie" })));
      setPopularTV((popT.results || []).slice(0, 16).map(i => ({ ...i, media_type: "tv" })));
      setAnimeItems((anim.results || []).slice(0, 16).map(i => ({ ...i, media_type: "tv" })));
    }).catch(() => {});
    return () => controller.abort();
  }, [apiKey, offline]);

  const trendingMovieItems = useMemo(() => trending.slice(0, 16).map(i => ({ ...i, media_type: "movie" })), [trending]);
  const trendingTVItems = useMemo(() => trendingTV.slice(0, 16).map(i => ({ ...i, media_type: "tv" })), [trendingTV]);

  const heroItems = useMemo(() => {
    if (activeFilter === "movies") return trendingMovieItems.slice(0, 5);
    if (activeFilter === "tv") return trendingTVItems.slice(0, 5);
    if (activeFilter === "anime") return (animeItems.length ? animeItems : trendingTVItems.filter(isAnimeContent)).slice(0, 5);
    return trendingMovieItems.slice(0, 5);
  }, [activeFilter, trendingMovieItems, trendingTVItems, animeItems]);

  const renderRow = (key, title, items, variant = "landscape", kicker = null) => {
    if (!items || items.length === 0) return null;
    return React.createElement("section", { key, className: "sg3-section" },
      React.createElement("div", { className: "sg3-section-head" },
        React.createElement("h2", { className: "sg3-section-title" }, title),
        kicker && React.createElement("span", { className: "sg3-section-kicker" }, kicker)
      ),
      React.createElement("div", { className: "scroll-row tv-scroll-row" },
        items.map(item => {
          const type = item.media_type === "tv" ? "tv" : "movie";
          const rd = enrichedRatingsMap[`${type}_${item.id}`] || {};
          const pk = item.media_type === "movie" ? `movie_${item.id}` : (item.season != null && item.episode != null ? `tv_${item.id}_s${item.season}e${item.episode}` : null);
          return React.createElement(MediaCard, {
            key: `${key}_${type}_${item.id}_${item.season || ""}_${item.episode || ""}`,
            item, variant, onClick: () => onSelect(item), progress: pk ? progress[pk] || 0 : 0,
            watched, onMarkWatched, onMarkUnwatched, ageRating: rd.cert, restricted: rd.restricted
          });
        })
      )
    );
  };

  const becauseTitle = lastWatchedTitle ? `Because You Watched ${lastWatchedTitle}` : "Recommended Tonight";
  const becauseItems = filteredRecommendedItems.length > 0 ? filteredRecommendedItems : popularMovies;

  return React.createElement("div", { className: "sg3-home fade-in" },
    offline && React.createElement("div", { className: "tv-offline-state" },
      React.createElement(WifiOffIcon, { size: 48 }),
      React.createElement("div", { style: { fontSize: 20, fontWeight: 600, color: "var(--text)" } }, "Offline Mode"),
      React.createElement("div", { style: { fontSize: 14, color: "var(--text3)" } }, "Your downloads and saved space remain available offline."),
      React.createElement("button", { className: "sg3-btn-watch", onClick: onRetry }, "Reconnect")
    ),

    !offline && activeFilter !== "explore" && loading && React.createElement("div", { className: "sg-skeleton-hero" },
      React.createElement("div", { className: "sg-skeleton-shimmer" })
    ),

    !offline && activeFilter !== "explore" && !loading && heroItems.length > 0 && React.createElement(HeroBanner, {
      items: heroItems, onSelect, ratingsMap: enrichedRatingsMap, onToggleSave, isSavedFn, progress, isTvMode
    }),

    (activeFilter === "explore" || activeFilter === "all") && React.createElement("div", { className: `sg3-genre-strip${activeFilter === "explore" ? " sg3-genre-strip--explore" : ""}` },
      CATEGORIES.map(cat => React.createElement("button", {
        key: cat,
        className: `sg3-genre-chip${selectedCategory === cat ? " active" : ""}`,
        onClick: () => setSelectedCategory(cat)
      }, cat))
    ),

    React.createElement("div", { className: "sg3-sections-wrap" },
      activeFilter === "movies" && React.createElement(React.Fragment, null,
        React.createElement(EditorialSpotlight, { title: "Cinema Spotlight", items: trendingMovieItems, onSelect }),
        renderRow("m_pop", "Popular Films", popularMovies, "poster", "WORLDWIDE"),
        renderRow("m_top", "Critically Acclaimed", topRatedItems.filter(i => i.media_type === "movie"), "landscape")
      ),

      activeFilter === "tv" && React.createElement(React.Fragment, null,
        React.createElement(EditorialSpotlight, { title: "Series Spotlight", items: trendingTVItems, onSelect }),
        renderRow("tv_pop", "Popular Series", popularTV, "poster", "BINGE-WORTHY"),
        renderRow("tv_top", "Highest Rated Series", topRatedItems.filter(i => i.media_type === "tv"), "landscape")
      ),

      activeFilter === "anime" && React.createElement(React.Fragment, null,
        React.createElement(EditorialSpotlight, { title: "Anime Universe", items: animeItems, onSelect }),
        renderRow("an_all", "Popular Anime", animeItems, "poster")
      ),

      (activeFilter === "explore" || selectedCategory !== "All") && React.createElement("section", { className: "sg3-section" },
        React.createElement("div", { className: "sg3-section-head" },
          React.createElement("h2", { className: "sg3-section-title" }, selectedCategory === "All" ? "Discover Something New" : `${selectedCategory} Universe`)
        ),
        loadingCategory ? React.createElement("div", { className: "loader", style: { padding: 32 } }, React.createElement("div", { className: "spinner" })) :
          React.createElement("div", { className: "cards-grid tv-cards-grid" },
            (selectedCategory === "All" ? (exploreItems.length ? exploreItems : [...trendingMovieItems, ...trendingTVItems]) : categoryItems).map(item => {
              const type = item.media_type === "tv" ? "tv" : "movie";
              const rd = enrichedRatingsMap[`${type}_${item.id}`] || {};
              return React.createElement(MediaCard, { key: `exp_${type}_${item.id}`, item, variant: "poster", onClick: () => onSelect(item), progress: 0, watched, onMarkWatched, onMarkUnwatched, ageRating: rd.cert, restricted: rd.restricted });
            })
          ),
        ((selectedCategory !== "All" && categoryHasMore) || (selectedCategory === "All" && exploreHasMore)) && React.createElement("div", { ref: sentinelRef, className: "sg4-infinite-sentinel" },
          (loadingMoreCategory || loadingMoreExplore) && React.createElement("div", { className: "spinner" })
        ),
        isTvMode && ((selectedCategory !== "All" && categoryHasMore) || (selectedCategory === "All" && exploreHasMore)) && React.createElement("div", { style: { display: "flex", justifyContent: "center", padding: "24px 0 8px" } },
          React.createElement("button", {
            className: "sg3-btn-info",
            onClick: selectedCategory !== "All" ? loadMoreCategory : loadMoreExplore,
            disabled: loadingMoreCategory || loadingMoreExplore
          }, (loadingMoreCategory || loadingMoreExplore) ? "Loading..." : "Load More")
        )
      ),

      activeFilter === "all" && selectedCategory === "All" && React.createElement(React.Fragment, null,
        inProgress.length > 0 && renderRow("continue", "Continue Your Journey", inProgress, "landscape", "PICK UP WHERE YOU LEFT OFF"),
        React.createElement(EditorialSpotlight, { title: "Trending in Your Universe", items: trendingTVItems.length >= 4 ? trendingTVItems : trendingMovieItems, onSelect }),
        renderRow("because", becauseTitle, becauseItems, "poster", "PERSONALIZED"),
        renderRow("next_obsession", "Your Next Obsession", trendingMovieItems, "landscape", "CINEMATIC"),
        React.createElement(MinimalDiscoveryRow, { title: "Hidden Gems & Acclaimed", items: topRatedItems, onSelect }),
        renderRow("anime_u", "Anime Universe", animeItems, "poster"),
        savedList.length > 0 && renderRow("fav_worlds", "Your Favorite Worlds", savedList, "poster", "SAVED")
      )
    )
  );
}
