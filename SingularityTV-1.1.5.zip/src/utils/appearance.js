export const ACCENT_PRESETS = [
  { id: "gold", label: "Champagne Gold", color: "#E6B86A", color2: "#F5D99F", dim: "rgba(230, 184, 106, 0.16)", glow: "0 0 28px rgba(230, 184, 106, 0.34)" },
  { id: "red", label: "Electric Crimson", color: "#E50914", color2: "#FF3352", dim: "rgba(229, 9, 20, 0.16)", glow: "0 0 28px rgba(229, 9, 20, 0.36)" },
  { id: "blue", label: "Aurora Cobalt", color: "#5E8BFF", color2: "#8FAFFF", dim: "rgba(94, 139, 255, 0.16)", glow: "0 0 28px rgba(94, 139, 255, 0.36)" },
  { id: "violet", label: "Singularity Violet", color: "#9B7BFF", color2: "#BDA6FF", dim: "rgba(155, 123, 255, 0.16)", glow: "0 0 28px rgba(155, 123, 255, 0.36)" },
  { id: "green", label: "Emerald Pulse", color: "#22C58B", color2: "#5AE0B0", dim: "rgba(34, 197, 139, 0.16)", glow: "0 0 28px rgba(34, 197, 139, 0.34)" },
  { id: "pink", label: "Nebula Rose", color: "#F472B6", color2: "#F9A8D4", dim: "rgba(244, 114, 182, 0.16)", glow: "0 0 28px rgba(244, 114, 182, 0.34)" }
];

export function applyAccentColor(presetId) {
  const preset = ACCENT_PRESETS.find(p => p.id === presetId) ?? ACCENT_PRESETS[0];
  const root = document.documentElement;
  root.style.setProperty("--red", preset.color);
  root.style.setProperty("--red2", preset.color2);
  root.style.setProperty("--accent", preset.color);
  root.style.setProperty("--accent2", preset.color2);
  root.style.setProperty("--red-dim", preset.dim);
  root.style.setProperty("--red-glow", preset.glow);
}

export const DEFAULT_CUSTOM_VARS = {
  "--bg": "#050608",
  "--bg-secondary": "#0B0D12",
  "--surface": "#0B0D12",
  "--surface2": "#12151E",
  "--surface3": "#1A1E2B",
  "--glass": "rgba(255, 255, 255, 0.045)",
  "--border": "rgba(255, 255, 255, 0.08)",
  "--text": "#F5F5F7",
  "--text2": "#9CA3B5",
  "--text3": "#687082"
};

export const THEME_PRESETS = [
  { id: "dark", label: "Singularity Obsidian", description: "Architectural deep obsidian with luminous accents", vars: { ...DEFAULT_CUSTOM_VARS } },
  { id: "oled", label: "Pure Zero OLED", description: "True #000000 black for OLED panels", vars: { "--bg": "#000000", "--bg-secondary": "#050608", "--surface": "#08090E", "--surface2": "#10131C", "--surface3": "#171B27", "--glass": "rgba(255, 255, 255, 0.04)", "--border": "rgba(255, 255, 255, 0.075)", "--text": "#F5F5F7", "--text2": "#9CA3B5", "--text3": "#687082" } },
  { id: "midnight", label: "Cobalt Dusk", description: "Deep midnight slate with atmospheric blue undertones", vars: { "--bg": "#070912", "--bg-secondary": "#0D1120", "--surface": "#11172B", "--surface2": "#17203A", "--surface3": "#1F2A4A", "--glass": "rgba(255, 255, 255, 0.055)", "--border": "rgba(155, 180, 245, 0.13)", "--text": "#F5F5F7", "--text2": "#A8B3CC", "--text3": "#717D9A" } }
];

export function applyTheme(themeId, customVars = null) {
  const root = document.documentElement;
  const preset = THEME_PRESETS.find(p => p.id === themeId) ?? THEME_PRESETS[0];
  const vars = themeId === "custom" && customVars ? { ...DEFAULT_CUSTOM_VARS, ...customVars } : preset.vars;
  for (const [k, v] of Object.entries(vars)) root.style.setProperty(k, v);
}
