export const TELEGRAM_HANDLE = "ec1lz";
export const TELEGRAM_URL = "https://t.me/ec1lz";
export const GITHUB_OWNER = "yasersajad";
export const GITHUB_REPO = "SingularityTV";
export const CURRENT_APP_VERSION = "1.0.0";

export const UPDATE_SOURCES = {
  github: {
    id: "github",
    label: "GitHub Releases",
    apiUrl: `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/releases/latest`,
    headers: { Accept: "application/vnd.github+json" },
    fallbackUrl: `https://github.com/${GITHUB_OWNER}/${GITHUB_REPO}/releases/latest`
  },
  telegram: {
    id: "telegram",
    label: "GitHub + Mirrors",
    apiUrl: `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/releases/latest`,
    headers: { Accept: "application/vnd.github+json" },
    fallbackUrl: `https://github.com/${GITHUB_OWNER}/${GITHUB_REPO}/releases/latest`
  }
};

export const DEFAULT_UPDATE_SOURCE = "github";

const DEFAULT_APK_URL = `https://github.com/${GITHUB_OWNER}/${GITHUB_REPO}/releases/latest/download/SingularityTV.apk`;
const DEFAULT_IPA_URL = `https://github.com/${GITHUB_OWNER}/${GITHUB_REPO}/releases/latest/download/SingularityTV.ipa`;

function extractSemver(raw) {
  const m = String(raw || "").match(/(\d+\.\d+\.\d+(?:\.\d+)?)/);
  return m ? m[1] : null;
}

export function compareVersions(a, b) {
  const pa = String(a || "0").replace(/^v/i, "").split(".").map(n => parseInt(n, 10) || 0);
  const pb = String(b || "0").replace(/^v/i, "").split(".").map(n => parseInt(n, 10) || 0);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const va = pa[i] || 0;
    const vb = pb[i] || 0;
    if (va > vb) return 1;
    if (va < vb) return -1;
  }
  return 0;
}

async function fetchJsonFast(url, headers = {}) {
  const sep = url.includes("?") ? "&" : "?";
  const bust = `${url}${sep}_t=${Date.now()}`;
  const res = await fetch(bust, {
    headers: { "Cache-Control": "no-cache", ...headers },
    signal: AbortSignal.timeout(7000)
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

function parseGithubRelease(rel) {
  if (!rel || typeof rel !== "object") return null;
  const ver = extractSemver(rel.tag_name) || extractSemver(rel.name) || extractSemver(rel.body);
  if (!ver) return null;
  const assets = Array.isArray(rel.assets) ? rel.assets : [];
  const apkAsset = assets.find(a => String(a.name || "").toLowerCase().endsWith(".apk"));
  const ipaAsset = assets.find(a => String(a.name || "").toLowerCase().endsWith(".ipa"));
  return {
    version: ver,
    notes: rel.body || "",
    url: rel.html_url || `https://github.com/${GITHUB_OWNER}/${GITHUB_REPO}/releases/latest`,
    assets: {
      apk: apkAsset?.browser_download_url || DEFAULT_APK_URL,
      ipa: ipaAsset?.browser_download_url || DEFAULT_IPA_URL
    }
  };
}

async function checkGithubLatestRelease() {
  const rel = await fetchJsonFast(`https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/releases/latest`, {
    Accept: "application/vnd.github+json"
  });
  return parseGithubRelease(rel);
}

async function checkGithubReleasesList() {
  const list = await fetchJsonFast(`https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/releases?per_page=5`, {
    Accept: "application/vnd.github+json"
  });
  if (!Array.isArray(list)) return null;
  let best = null;
  for (const rel of list) {
    if (rel?.draft) continue;
    const parsed = parseGithubRelease(rel);
    if (parsed && (!best || compareVersions(parsed.version, best.version) > 0)) {
      best = parsed;
    }
  }
  return best;
}

async function checkRawPackageJson(branch = "main") {
  const pkg = await fetchJsonFast(`https://raw.githubusercontent.com/${GITHUB_OWNER}/${GITHUB_REPO}/${branch}/package.json`);
  const ver = extractSemver(pkg?.version);
  if (!ver) return null;
  return {
    version: ver,
    notes: `SingularityTV v${ver} is now available on GitHub.`,
    url: `https://github.com/${GITHUB_OWNER}/${GITHUB_REPO}/releases/latest`,
    assets: {
      apk: DEFAULT_APK_URL,
      ipa: DEFAULT_IPA_URL
    }
  };
}

async function checkJsDelivrPackageJson() {
  const pkg = await fetchJsonFast(`https://cdn.jsdelivr.net/gh/${GITHUB_OWNER}/${GITHUB_REPO}@main/package.json`);
  const ver = extractSemver(pkg?.version);
  if (!ver) return null;
  return {
    version: ver,
    notes: `SingularityTV v${ver} is now available.`,
    url: `https://github.com/${GITHUB_OWNER}/${GITHUB_REPO}/releases/latest`,
    assets: {
      apk: DEFAULT_APK_URL,
      ipa: DEFAULT_IPA_URL
    }
  };
}

export async function checkForUpdates() {
  let current = CURRENT_APP_VERSION;
  try {
    if (typeof window !== "undefined" && window.electron?.getAppVersion) {
      const v = await window.electron.getAppVersion();
      if (v) current = String(v).replace(/^v/i, "");
    }
  } catch {}

  const settled = await Promise.allSettled([
    checkGithubLatestRelease(),
    checkGithubReleasesList(),
    checkRawPackageJson("main"),
    checkJsDelivrPackageJson()
  ]);

  let best = null;
  for (const r of settled) {
    if (r.status === "fulfilled" && r.value?.version) {
      const cand = r.value;
      if (!best || compareVersions(cand.version, best.version) > 0) {
        best = cand;
      } else if (compareVersions(cand.version, best.version) === 0 && cand.notes && !best.notes) {
        best = cand;
      }
    }
  }

  if (!best) {
    return {
      hasUpdate: false,
      current,
      latest: current,
      mandatory: false,
      url: `https://github.com/${GITHUB_OWNER}/${GITHUB_REPO}/releases/latest`,
      assets: { apk: DEFAULT_APK_URL, ipa: DEFAULT_IPA_URL },
      sourceLabel: "GitHub Releases"
    };
  }

  const hasUpdate = compareVersions(best.version, current) > 0;
  return {
    hasUpdate,
    current,
    latest: best.version,
    mandatory: hasUpdate,
    notes: best.notes || "",
    url: best.url,
    assets: best.assets,
    sourceLabel: "GitHub Releases"
  };
}

export async function checkForUpdatesWithFallback() {
  return checkForUpdates();
}
