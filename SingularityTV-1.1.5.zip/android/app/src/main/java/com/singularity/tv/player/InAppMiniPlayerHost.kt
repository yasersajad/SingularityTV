package com.singularity.tv.player

import android.app.UiModeManager
import android.content.Context
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import com.singularity.tv.BuildConfig

object InAppMiniPlayerHost {
    @Volatile var miniWebView: WebView? = null
    @Volatile var payloadJson: String? = null
    @Volatile var streamTitle: String = ""
    @Volatile var progressKey: String? = null
    @Volatile var isHandingOffToMini: Boolean = false
    @Volatile var isReexpandingToFull: Boolean = false
    @Volatile var onMiniClosed: (() -> Unit)? = null

    fun isMobilePhone(context: Context, forceTvMode: Boolean = false): Boolean {
        if (BuildConfig.FORCE_TV_MODE || forceTvMode) return false
        val uiMode = context.resources.configuration.uiMode
        if ((uiMode and Configuration.UI_MODE_TYPE_MASK) == Configuration.UI_MODE_TYPE_TELEVISION) return false
        val umm = context.getSystemService(Context.UI_MODE_SERVICE) as? UiModeManager
        if (umm?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION) return false
        val pm = context.packageManager
        if (pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK) || pm.hasSystemFeature(PackageManager.FEATURE_TELEVISION)) return false
        if (!pm.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN)) return false
        return true
    }

    fun destroyMiniPlayer() {
        val wv = miniWebView
        miniWebView = null
        payloadJson = null
        streamTitle = ""
        progressKey = null
        isHandingOffToMini = false
        isReexpandingToFull = false
        if (wv != null) {
            try {
                (wv.parent as? ViewGroup)?.removeView(wv)
                wv.evaluateJavascript(
                    "try{window.__sgForcePause=true;document.querySelectorAll('video,audio').forEach(function(v){v.pause();v.muted=true;v.removeAttribute('src');v.load();});}catch(e){}",
                    null
                )
                wv.stopLoading()
                wv.visibility = View.GONE
                wv.loadData("<html><body style=background:#000></body></html>", "text/html", "utf-8")
                wv.onPause()
                wv.destroy()
            } catch (_: Throwable) {}
        }
        try { onMiniClosed?.invoke() } catch (_: Throwable) {}
    }
}
