package com.singularity.tv

import android.annotation.SuppressLint
import android.app.PictureInPictureParams
import android.graphics.Color
import android.content.Context
import android.content.res.Configuration
import android.os.Build
import java.util.Locale
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.util.Rational
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import com.singularity.tv.bridge.StreambertJsBridge
import com.singularity.tv.download.DownloadEventBus
import com.singularity.tv.player.ExoProgressBus
import com.singularity.tv.webview.StreambertWebViewClient
import org.json.JSONObject

open class MainActivity : AppCompatActivity() {

    lateinit var webView: WebView
    private var customFullscreenView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var isPlayingMedia: Boolean = false
    open val forceTvMode: Boolean = false
    private lateinit var mainRootContainer: FrameLayout
    private var miniPlayerCard: FrameLayout? = null
    private var miniControlsLayer: FrameLayout? = null
    private var miniPlayPauseBtn: android.widget.ImageView? = null
    private var miniProgressFill: View? = null
    private var miniIsPaused: Boolean = false
    private val miniHideHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private val miniHideRunnable = Runnable {
        miniControlsLayer?.animate()?.alpha(0f)?.setDuration(180)?.withEndAction {
            miniControlsLayer?.visibility = View.GONE
        }?.start()
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun attachBaseContext(newBase: Context) {
        Locale.setDefault(Locale.US)
        val cfg = Configuration(newBase.resources.configuration)
        cfg.setLocale(Locale.US)
        cfg.setLayoutDirection(Locale.US)
        super.attachBaseContext(newBase.createConfigurationContext(cfg))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Locale.setDefault(Locale.US)
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_LTR
        applySystemBarsVisibility(immersivePlayback = false)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            window.decorView.defaultFocusHighlightEnabled = false
        }

        val rootContainer = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#0A0A0A"))
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                defaultFocusHighlightEnabled = false
            }
        }

        webView = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#0A0A0A"))
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            isLongClickable = false
            isHapticFeedbackEnabled = false
            setOnLongClickListener { true }
            isFocusable = true
            isFocusableInTouchMode = true
            try { WebView.setWebContentsDebuggingEnabled(true) } catch (_: Throwable) {}
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                defaultFocusHighlightEnabled = false
            }
        }
        rootContainer.addView(webView)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowContentAccess = true
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = false
            userAgentString = userAgentString.replace(Regex(";\\s*wv\\)"), ")")
        }

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }

        val jsBridge = StreambertJsBridge(this) { channel, payloadJson ->
            dispatchToReact(channel, payloadJson)
        }
        webView.addJavascriptInterface(jsBridge, "AndroidBridge")

        val otaDir = java.io.File(filesDir, "ota")
        try {
            val otaPrefs = getSharedPreferences("singularity_ota", Context.MODE_PRIVATE)
            val curStamp = packageManager.getPackageInfo(packageName, 0).lastUpdateTime.toString()
            val prevStamp = otaPrefs.getString("ota_install_stamp_v115_r2", "") ?: ""
            if (prevStamp != curStamp) {
                if (otaDir.exists()) otaDir.deleteRecursively()
                otaPrefs.edit().putString("ota_install_stamp_v115_r2", curStamp).remove("ota_version").apply()
            }
        } catch (_: Throwable) {}
        webView.webViewClient = StreambertWebViewClient(assetLoader, otaDir) { channel, payloadJson ->
            dispatchToReact(channel, payloadJson)
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (customFullscreenView != null) {
                    callback?.onCustomViewHidden()
                    return
                }
                customFullscreenView = view
                customViewCallback = callback
                applySystemBarsVisibility(immersivePlayback = true)
                if (view != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        view.defaultFocusHighlightEnabled = false
                    }
                    rootContainer.addView(
                        view,
                        FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                    )
                    webView.visibility = View.GONE
                }
            }

            override fun onHideCustomView() {
                val v = customFullscreenView ?: return
                rootContainer.removeView(v)
                customFullscreenView = null
                customViewCallback?.onCustomViewHidden()
                customViewCallback = null
                webView.visibility = View.VISIBLE
                applySystemBarsVisibility(immersivePlayback = isPlayingMedia)
            }
        }

        mainRootContainer = rootContainer
        setContentView(rootContainer)

        DownloadEventBus.listener = { entity ->
            dispatchToReact(
                "download-progress",
                StreambertJsBridge.downloadToJson(entity).toString()
            )
        }
        ExoProgressBus.listener = { key, pct, posSec, durSec, watched, playingNow ->
            val payload = JSONObject().apply {
                put("progressKey", key)
                put("percent", pct)
                put("positionSec", posSec)
                put("durationSec", durSec)
                put("watched", watched)
                put("isPlaying", playingNow)
            }
            dispatchToReact("exo-progress", payload.toString())
        }
        ExoProgressBus.webPrefsListener = { prefsJson ->
            runOnUiThread {
                dispatchToReact("web-player-prefs-changed", JSONObject.quote(prefsJson))
            }
        }
        ExoProgressBus.subtitleStyleListener = { colorHex, bgMode, fontSizeSp ->
            val payload = JSONObject().apply {
                put("subTextColor", colorHex)
                put("subBgStyle", bgMode)
                put("subFontSizeSp", fontSizeSp.toDouble())
            }
            dispatchToReact("subtitle-style-changed", payload.toString())
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (customFullscreenView != null) {
                    webView.webChromeClient?.onHideCustomView()
                    return
                }
                webView.evaluateJavascript(
                    "(window.__streambertHandleBack && window.__streambertHandleBack()) || false"
                ) { result ->
                    if (result != "true") {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                        isEnabled = true
                    }
                }
            }
        })

        try {
            webView.clearCache(false)
        } catch (_: Exception) {}
        try {
            val standaloneHtml = assets.open("public/standalone.html").bufferedReader(Charsets.UTF_8).use { it.readText() }
            if (standaloneHtml.length > 5000) {
                webView.loadDataWithBaseURL(
                    "https://appassets.androidplatform.net/assets/public/index.html",
                    standaloneHtml,
                    "text/html",
                    "UTF-8",
                    null
                )
            } else {
                webView.loadUrl("https://appassets.androidplatform.net/assets/public/index.html?v=115")
            }
        } catch (_: Throwable) {
            webView.loadUrl("https://appassets.androidplatform.net/assets/public/index.html?v=115")
        }
        checkAndFetchOtaUpdate()
        try {
            val savedSrc = getSharedPreferences("singularity_prefs", Context.MODE_PRIVATE)
                .getString("last_working_source", "") ?: ""
            if (savedSrc.isNotBlank()) {
                webView.postDelayed({
                    dispatchToReact("preferred-source-updated", JSONObject.quote(savedSrc))
                }, 800L)
            }
        } catch (_: Exception) {}
    }


    private fun checkAndFetchOtaUpdate() {
        kotlin.concurrent.thread(start = true) {
            try {
                val base = "https://soufctreejgcpvqftxeb.supabase.co/functions/v1/telegram-gate"
                val conn = java.net.URL("$base?action=ota_manifest").openConnection() as java.net.HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                if (conn.responseCode != 200) return@thread
                val manifestStr = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val manifest = JSONObject(manifestStr)
                val prefs = getSharedPreferences("singularity_ota", Context.MODE_PRIVATE)
                val remoteOtaVer = manifest.optString("ota_version", "").trim()
                val localOtaVer = prefs.getString("ota_version", "") ?: ""
                if (remoteOtaVer.isEmpty() || remoteOtaVer == localOtaVer) return@thread
                val installedVer = try { packageManager.getPackageInfo(packageName, 0).versionName?.split("-")?.firstOrNull() ?: "1.1.3" } catch (_: Throwable) { "1.1.3" }
                val remoteBase = remoteOtaVer.split("-").firstOrNull()?.trim() ?: ""
                if (remoteBase.isNotEmpty()) {
                    val rParts = remoteBase.split(".").map { it.toIntOrNull() ?: 0 }
                    val iParts = installedVer.split(".").map { it.toIntOrNull() ?: 0 }
                    var cmp = 0
                    for (idx in 0 until maxOf(rParts.size, iParts.size)) {
                        val rv = rParts.getOrElse(idx) { 0 }
                        val iv = iParts.getOrElse(idx) { 0 }
                        if (rv != iv) { cmp = rv.compareTo(iv); break }
                    }
                    if (cmp < 0) return@thread
                }
                var builtAtMs = 0L
                var builtBundleSha = ""
                var builtCssSha = ""
                try {
                    val fpStr = assets.open("public/ota-fingerprint.json").bufferedReader().use { it.readText() }
                    val fpObj = JSONObject(fpStr)
                    builtAtMs = fpObj.optLong("builtAtMs", 0L)
                    builtBundleSha = fpObj.optString("bundleSha256", "")
                    builtCssSha = fpObj.optString("cssSha256", "")
                } catch (_: Throwable) {}
                val binMs = try { packageManager.getPackageInfo(packageName, 0).lastUpdateTime } catch (_: Throwable) { 0L }
                val baselineMs = maxOf(builtAtMs, binMs)
                val updatedAtStr = manifest.optString("updated_at", "").trim()
                if (updatedAtStr.isNotEmpty() && baselineMs > 0L) {
                    try {
                        val otaMs = java.time.Instant.parse(updatedAtStr).toEpochMilli()
                        if (otaMs <= baselineMs) return@thread
                    } catch (_: Throwable) {}
                }
                val rBundleSha = manifest.optString("bundle_sha256", "")
                val rCssSha = manifest.optString("css_sha256", "")
                if (rBundleSha.isNotEmpty() && rBundleSha == builtBundleSha && (rCssSha.isEmpty() || rCssSha == builtCssSha)) {
                    return@thread
                }
                val otaDir = java.io.File(filesDir, "ota")
                if (!otaDir.exists()) otaDir.mkdirs()
                var updatedAny = false
                if (manifest.optBoolean("has_bundle", false)) {
                    val bConn = java.net.URL("$base?action=ota_file&file=bundle.js").openConnection() as java.net.HttpURLConnection
                    bConn.connectTimeout = 15000
                    bConn.readTimeout = 20000
                    if (bConn.responseCode == 200) {
                        val bytes = bConn.inputStream.readBytes()
                        if (bytes.size > 5000) {
                            val tmp = java.io.File(otaDir, "bundle.js.tmp")
                            tmp.writeBytes(bytes)
                            tmp.renameTo(java.io.File(otaDir, "bundle.js"))
                            updatedAny = true
                        }
                    }
                    bConn.disconnect()
                }
                if (manifest.optBoolean("has_css", false)) {
                    val cConn = java.net.URL("$base?action=ota_file&file=global.css").openConnection() as java.net.HttpURLConnection
                    cConn.connectTimeout = 12000
                    cConn.readTimeout = 15000
                    if (cConn.responseCode == 200) {
                        val bytes = cConn.inputStream.readBytes()
                        if (bytes.size > 100) {
                            val tmp = java.io.File(otaDir, "global.css.tmp")
                            tmp.writeBytes(bytes)
                            tmp.renameTo(java.io.File(otaDir, "global.css"))
                            updatedAny = true
                        }
                    }
                    cConn.disconnect()
                }
                if (updatedAny) {
                    prefs.edit().putString("ota_version", remoteOtaVer).apply()
                    runOnUiThread {
                        if (!isDestroyed && !isPlayingMedia && ::webView.isInitialized) {
                            try { webView.reload() } catch (_: Throwable) {}
                        }
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    fun setPlaybackImmersive(active: Boolean) {
        isPlayingMedia = active
        runOnUiThread {
            if (active) {
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            } else {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
            applySystemBarsVisibility(immersivePlayback = active || customFullscreenView != null)
        }
    }

    private fun applySystemBarsVisibility(immersivePlayback: Boolean) {
        try {
            WindowCompat.setDecorFitsSystemWindows(window, false)
            val controller = WindowInsetsControllerCompat(window, window.decorView)
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            if (immersivePlayback) {
                controller.hide(WindowInsetsCompat.Type.systemBars())
            } else {
                controller.hide(WindowInsetsCompat.Type.statusBars())
            }
        } catch (_: Exception) {}
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            applySystemBarsVisibility(immersivePlayback = isPlayingMedia || customFullscreenView != null)
        }
    }

    override fun onPause() {
        super.onPause()
        try {
            webView.evaluateJavascript(
                "(function(){try{document.querySelectorAll('video,audio').forEach(function(m){m.pause();});}catch(e){}})();",
                null
            )
            if (!com.singularity.tv.player.NativeExoPlayerActivity.isPlayerActive) {
                webView.onPause()
            }
        } catch (_: Exception) {}
    }


    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val dataUri = intent.data
        if (dataUri != null && dataUri.scheme == "singularitytv") {
            dispatchToReact("google-oauth-callback", JSONObject.quote(dataUri.toString()))
        }
    }

    override fun onResume() {
        super.onResume()
        if (!com.singularity.tv.player.InAppMiniPlayerHost.isHandingOffToMini) {
            try {
                com.singularity.tv.player.NativeExoPlayerActivity.forceCloseIfOpen()
            } catch (_: Throwable) {}
        }
        try {
            webView.onResume()
        } catch (_: Exception) {}
        try {
            attachInAppMiniPlayerIfNeeded()
        } catch (_: Throwable) {}
        checkAndFetchOtaUpdate()
    }

    fun dispatchToReact(channel: String, payloadJson: String) {
        runOnUiThread {
            if (!isDestroyed && ::webView.isInitialized) {
                val safeChannel = JSONObject.quote(channel)
                webView.evaluateJavascript(
                    "window.__streambertDispatch && window.__streambertDispatch($safeChannel, $payloadJson);",
                    null
                )
            }
        }
    }

    fun enterAppPipMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val params = PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
                enterPictureInPictureMode(params)
            } catch (_: Exception) {}
        }
    }

    fun simulateTap(xRatio: Float, yRatio: Float) {
        runOnUiThread {
            if (isDestroyed || !::webView.isInitialized || webView.width <= 0 || webView.height <= 0) return@runOnUiThread
            val x = (xRatio.coerceIn(0.05f, 0.95f)) * webView.width
            val y = (yRatio.coerceIn(0.05f, 0.95f)) * webView.height
            val downTime = SystemClock.uptimeMillis()
            val downEvent = MotionEvent.obtain(downTime, downTime, MotionEvent.ACTION_DOWN, x, y, 0)
            val upEvent = MotionEvent.obtain(downTime, downTime + 45L, MotionEvent.ACTION_UP, x, y, 0)
            webView.dispatchTouchEvent(downEvent)
            webView.dispatchTouchEvent(upEvent)
            downEvent.recycle()
            upEvent.recycle()
        }
    }

    fun clearWebViewCache() {
        try {
            webView.clearCache(true)
        } catch (_: Exception) {}
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val actionName = when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> "up"
            KeyEvent.KEYCODE_DPAD_DOWN -> "down"
            KeyEvent.KEYCODE_DPAD_LEFT -> "left"
            KeyEvent.KEYCODE_DPAD_RIGHT -> "right"
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER, KeyEvent.KEYCODE_BUTTON_A -> "select"
            KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_SEARCH -> "menu"
            KeyEvent.KEYCODE_PAGE_UP, KeyEvent.KEYCODE_CHANNEL_UP -> "page_up"
            KeyEvent.KEYCODE_PAGE_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> "page_down"
            else -> null
        }
        if (actionName != null) {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager
            if (imm?.isAcceptingText == true) {
                return super.dispatchKeyEvent(event)
            }
            if (event.action == KeyEvent.ACTION_DOWN) {
                webView.evaluateJavascript(
                    "window.dispatchEvent(new CustomEvent('streambert:dpad', { detail: { action: '$actionName' } }));",
                    null
                )
                return true
            }
            if (event.action == KeyEvent.ACTION_UP) {
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun attachInAppMiniPlayerIfNeeded() {
        val wv = com.singularity.tv.player.InAppMiniPlayerHost.miniWebView ?: return
        com.singularity.tv.player.InAppMiniPlayerHost.isHandingOffToMini = false
        if (!com.singularity.tv.player.InAppMiniPlayerHost.isMobilePhone(this, forceTvMode)) {
            com.singularity.tv.player.InAppMiniPlayerHost.destroyMiniPlayer()
            return
        }
        if (!::mainRootContainer.isInitialized) return
        removeMiniPlayerCardOnly()

        val density = resources.displayMetrics.density
        val cardW = (204f * density).toInt()
        val cardH = (115f * density).toInt()
        val margin = (14f * density).toInt()
        val bottomDockClear = (88f * density).toInt()

        val card = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(cardW, cardH)
            elevation = 24f * density
            clipToOutline = true
            outlineProvider = object : android.view.ViewOutlineProvider() {
                override fun getOutline(view: View, outline: android.graphics.Outline) {
                    outline.setRoundRect(0, 0, view.width, view.height, 14f * density)
                }
            }
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(Color.parseColor("#0B0D12"))
                cornerRadius = 14f * density
                setStroke((1.2f * density).toInt().coerceAtLeast(1), Color.argb(65, 255, 255, 255))
            }
        }

        try { (wv.parent as? ViewGroup)?.removeView(wv) } catch (_: Throwable) {}
        wv.layoutParams = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        wv.translationX = 0f
        wv.alpha = 1f
        wv.visibility = View.VISIBLE
        wv.isClickable = false
        wv.isFocusable = false
        wv.onResume()
        wv.evaluateJavascript("try{if(window.__sgSetMiniMode)window.__sgSetMiniMode(true);}catch(e){}", null)
        card.addView(wv)

        // Transparent touch capture overlay for drag / tap / corner snap
        val touchLayer = View(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.TRANSPARENT)
        }
        card.addView(touchLayer)

        // YouTube-style controls overlay (Expand, Play/Pause, Close)
        val controls = FrameLayout(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.argb(115, 5, 6, 8))
            visibility = View.GONE
            alpha = 0f
        }

        fun makeVectorMiniDrawable(kind: String): android.graphics.drawable.Drawable {
            return object : android.graphics.drawable.Drawable() {
                private val bgPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.argb(150, 10, 12, 18)
                    style = android.graphics.Paint.Style.FILL
                }
                private val strokePaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.WHITE
                    style = android.graphics.Paint.Style.STROKE
                    strokeWidth = 2.1f * density
                    strokeCap = android.graphics.Paint.Cap.ROUND
                    strokeJoin = android.graphics.Paint.Join.ROUND
                }
                private val fillPaint = android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG).apply {
                    color = Color.WHITE
                    style = android.graphics.Paint.Style.FILL
                }
                override fun draw(canvas: android.graphics.Canvas) {
                    val b = bounds
                    val cx = b.exactCenterX()
                    val cy = b.exactCenterY()
                    val r = (minOf(b.width(), b.height()) / 2f)
                    canvas.drawCircle(cx, cy, r, bgPaint)
                    val u = r * 0.42f
                    when (kind) {
                        "expand" -> {
                            canvas.drawLine(cx - u, cy + u, cx - u * 0.25f, cy + u * 0.25f, strokePaint)
                            canvas.drawLine(cx - u, cy + u, cx - u, cy + u * 0.35f, strokePaint)
                            canvas.drawLine(cx - u, cy + u, cx - u * 0.35f, cy + u, strokePaint)
                            canvas.drawLine(cx + u, cy - u, cx + u * 0.25f, cy - u * 0.25f, strokePaint)
                            canvas.drawLine(cx + u, cy - u, cx + u, cy - u * 0.35f, strokePaint)
                            canvas.drawLine(cx + u, cy - u, cx + u * 0.35f, cy - u, strokePaint)
                        }
                        "close" -> {
                            val d = u * 0.85f
                            canvas.drawLine(cx - d, cy - d, cx + d, cy + d, strokePaint)
                            canvas.drawLine(cx + d, cy - d, cx - d, cy + d, strokePaint)
                        }
                        "pause" -> {
                            val bw = u * 0.34f
                            val bh = u * 0.95f
                            val gap = u * 0.28f
                            canvas.drawRoundRect(cx - gap - bw, cy - bh, cx - gap, cy + bh, 2f * density, 2f * density, fillPaint)
                            canvas.drawRoundRect(cx + gap, cy - bh, cx + gap + bw, cy + bh, 2f * density, 2f * density, fillPaint)
                        }
                        "play" -> {
                            val path = android.graphics.Path().apply {
                                moveTo(cx - u * 0.55f, cy - u * 0.95f)
                                lineTo(cx + u * 0.95f, cy)
                                lineTo(cx - u * 0.55f, cy + u * 0.95f)
                                close()
                            }
                            canvas.drawPath(path, fillPaint)
                        }
                    }
                }
                override fun setAlpha(alpha: Int) { bgPaint.alpha = alpha; strokePaint.alpha = alpha; fillPaint.alpha = alpha }
                override fun setColorFilter(cf: android.graphics.ColorFilter?) { strokePaint.colorFilter = cf; fillPaint.colorFilter = cf }
                @Deprecated("Deprecated in Java")
                override fun getOpacity(): Int = android.graphics.PixelFormat.TRANSLUCENT
            }
        }

        fun makeMiniBtn(kind: String, sizeDp: Int, gravity: Int, onClick: () -> Unit): android.widget.ImageView {
            return android.widget.ImageView(this).apply {
                setImageDrawable(makeVectorMiniDrawable(kind))
                layoutParams = FrameLayout.LayoutParams((sizeDp * density).toInt(), (sizeDp * density).toInt(), gravity).apply {
                    val m = (7f * density).toInt()
                    setMargins(m, m, m, m)
                }
                setOnClickListener {
                    miniHideHandler.removeCallbacks(miniHideRunnable)
                    onClick()
                }
            }
        }

        val expandBtn = makeMiniBtn("expand", 32, android.view.Gravity.TOP or android.view.Gravity.START) {
            expandInAppMiniPlayer()
        }
        val closeBtn = makeMiniBtn("close", 32, android.view.Gravity.TOP or android.view.Gravity.END) {
            closeInAppMiniPlayer()
        }
        miniIsPaused = false
        val ppBtn = makeMiniBtn("pause", 44, android.view.Gravity.CENTER) {
            val curWv = com.singularity.tv.player.InAppMiniPlayerHost.miniWebView ?: return@makeMiniBtn
            if (miniIsPaused) {
                miniIsPaused = false
                miniPlayPauseBtn?.setImageDrawable(makeVectorMiniDrawable("pause"))
                curWv.evaluateJavascript("try{var v=document.querySelector('video');if(v){window.__sbUserPaused=0;v.play().catch(function(){});}}catch(e){}", null)
            } else {
                miniIsPaused = true
                miniPlayPauseBtn?.setImageDrawable(makeVectorMiniDrawable("play"))
                curWv.evaluateJavascript("try{var v=document.querySelector('video');if(v){window.__sbUserPaused=1;window.__sgAllowPauseUntil=Date.now()+900;v.pause();}}catch(e){}", null)
            }
            miniHideHandler.postDelayed(miniHideRunnable, 2600L)
        }
        miniPlayPauseBtn = ppBtn
        controls.addView(expandBtn)
        controls.addView(closeBtn)
        controls.addView(ppBtn)
        controls.setOnClickListener { expandInAppMiniPlayer() }
        card.addView(controls)
        miniControlsLayer = controls

        var downRawX = 0f
        var downRawY = 0f
        var startX = 0f
        var startY = 0f
        var moved = false
        var lastTapAt = 0L

        touchLayer.setOnTouchListener { _, ev ->
            val parentW = mainRootContainer.width.coerceAtLeast(cardW + margin * 2)
            val parentH = mainRootContainer.height.coerceAtLeast(cardH + bottomDockClear + margin)
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downRawX = ev.rawX
                    downRawY = ev.rawY
                    startX = card.x
                    startY = card.y
                    moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = ev.rawX - downRawX
                    val dy = ev.rawY - downRawY
                    if (!moved && (kotlin.math.abs(dx) > 8f * density || kotlin.math.abs(dy) > 8f * density)) {
                        moved = true
                    }
                    if (moved) {
                        card.x = (startX + dx).coerceIn(margin.toFloat(), (parentW - cardW - margin).toFloat())
                        card.y = (startY + dy).coerceIn((36f * density), (parentH - cardH - margin).toFloat())
                    }
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (!moved) {
                        val now = System.currentTimeMillis()
                        if (now - lastTapAt < 300L) {
                            expandInAppMiniPlayer()
                        } else {
                            lastTapAt = now
                            if (controls.visibility == View.VISIBLE) {
                                miniHideHandler.removeCallbacks(miniHideRunnable)
                                controls.animate().alpha(0f).setDuration(150).withEndAction {
                                    controls.visibility = View.GONE
                                }.start()
                            } else {
                                controls.visibility = View.VISIBLE
                                controls.animate().alpha(1f).setDuration(150).start()
                                miniHideHandler.removeCallbacks(miniHideRunnable)
                                miniHideHandler.postDelayed(miniHideRunnable, 3000L)
                            }
                        }
                    } else {
                        // Snap smoothly to nearest corner (YouTube PiP physics)
                        val snapX = if (card.x + cardW / 2f < parentW / 2f) margin.toFloat() else (parentW - cardW - margin).toFloat()
                        val minY = (44f * density)
                        val maxY = (parentH - cardH - bottomDockClear).toFloat().coerceAtLeast(minY)
                        val snapY = if (card.y + cardH / 2f < parentH * 0.42f) minY else maxY
                        card.animate().x(snapX).y(snapY).setDuration(220)
                            .setInterpolator(android.view.animation.DecelerateInterpolator(1.6f)).start()
                    }
                    true
                }
                else -> false
            }
        }

        val trackH = (3f * density).toInt().coerceAtLeast(3)
        val pTrack = View(this).apply { layoutParams = FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, trackH, android.view.Gravity.BOTTOM); setBackgroundColor(Color.argb(70, 255, 255, 255)) }
        val pFill = View(this).apply { layoutParams = FrameLayout.LayoutParams(0, trackH, android.view.Gravity.BOTTOM or android.view.Gravity.START); setBackgroundColor(Color.WHITE) }
        card.addView(pTrack); card.addView(pFill); miniProgressFill = pFill
        val prevProgListener = ExoProgressBus.listener
        ExoProgressBus.listener = { key, pct, posSec, durSec, watched, playingNow -> prevProgListener?.invoke(key, pct, posSec, durSec, watched, playingNow); runOnUiThread { val curCard = miniPlayerCard ?: return@runOnUiThread; val curFill = miniProgressFill ?: return@runOnUiThread; val targetW = (curCard.width * (pct.coerceIn(0, 100) / 100f)).toInt(); (curFill.layoutParams as? FrameLayout.LayoutParams)?.let { lp -> if (lp.width != targetW) { lp.width = targetW; curFill.layoutParams = lp } } } }
        mainRootContainer.addView(card)
        miniPlayerCard = card
        mainRootContainer.post {
            val pw = mainRootContainer.width
            val ph = mainRootContainer.height
            if (pw > 0 && ph > 0) {
                card.x = (pw - cardW - margin).toFloat()
                card.y = (ph - cardH - bottomDockClear).toFloat().coerceAtLeast(44f * density)
            }
        }
        com.singularity.tv.player.InAppMiniPlayerHost.onMiniClosed = {
            runOnUiThread { removeMiniPlayerCardOnly() }
        }
    }

    private fun removeMiniPlayerCardOnly() {
        miniHideHandler.removeCallbacks(miniHideRunnable)
        miniPlayerCard?.let { card ->
            try { (card.parent as? ViewGroup)?.removeView(card) } catch (_: Throwable) {}
        }
        miniPlayerCard = null
        miniControlsLayer = null
        miniPlayPauseBtn = null
    }

    private fun closeInAppMiniPlayer() {
        removeMiniPlayerCardOnly()
        com.singularity.tv.player.InAppMiniPlayerHost.destroyMiniPlayer()
    }

    private fun expandInAppMiniPlayer() {
        val payload = com.singularity.tv.player.InAppMiniPlayerHost.payloadJson ?: return
        val wv = com.singularity.tv.player.InAppMiniPlayerHost.miniWebView ?: return
        try { (wv.parent as? ViewGroup)?.removeView(wv) } catch (_: Throwable) {}
        removeMiniPlayerCardOnly()
        com.singularity.tv.player.InAppMiniPlayerHost.isReexpandingToFull = true
        com.singularity.tv.player.NativeExoPlayerActivity.isPlayerActive = true
        val intent = Intent(this, com.singularity.tv.player.NativeExoPlayerActivity::class.java).apply {
            putExtra(com.singularity.tv.player.NativeExoPlayerActivity.EXTRA_PAYLOAD_JSON, payload)
        }
        startActivity(intent)
        overridePendingTransition(0, 0)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        mainRootContainer.post {
            val card = miniPlayerCard ?: return@post
            val density = resources.displayMetrics.density
            val cardW = (204f * density).toInt(); val cardH = (115f * density).toInt()
            val margin = (14f * density).toInt(); val bottomDockClear = (88f * density).toInt()
            val pw = mainRootContainer.width; val ph = mainRootContainer.height
            if (pw > 0 && ph > 0) {
                val snapX = if (card.x + cardW / 2f < pw / 2f) margin.toFloat() else (pw - cardW - margin).toFloat().coerceAtLeast(margin.toFloat())
                val minY = 44f * density; val maxY = (ph - cardH - bottomDockClear).toFloat().coerceAtLeast(minY)
                card.x = snapX; card.y = if (card.y + cardH / 2f < ph * 0.42f) minY else maxY
                val ratio = ((miniProgressFill?.width?.toFloat() ?: 0f) / cardW.coerceAtLeast(1)).coerceIn(0f, 1f)
                (miniProgressFill?.layoutParams as? FrameLayout.LayoutParams)?.let { lp -> lp.width = (cardW * ratio).toInt(); miniProgressFill?.layoutParams = lp }
            }
        }
    }

    override fun onDestroy() {
        closeInAppMiniPlayer()
        DownloadEventBus.listener = null
        ExoProgressBus.listener = null
        try {
            webView.destroy()
        } catch (_: Exception) {}
        super.onDestroy()
    }
}
