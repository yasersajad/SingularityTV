import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const BOT_TOKEN = Deno.env.get("TELEGRAM_BOT_TOKEN") || "";
const SUPABASE_URL = Deno.env.get("SUPABASE_URL") || "https://soufctreejgcpvqftxeb.supabase.co";
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
const ADMIN_ID = Deno.env.get("ADMIN_TELEGRAM_ID") || "6798616395";
const CHANNEL_ID = Deno.env.get("CHANNEL_TELEGRAM_ID") || "-1004347079304";
const CHANNEL_URL = Deno.env.get("CHANNEL_INVITE_URL") || "https://t.me/+IUpscNRqcqc4Y2Zk";

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS"
};

const VALID_MEMBER_STATUSES = new Set(["creator", "administrator", "member", "restricted"]);

async function tgCall(method: string, payload: Record<string, unknown>) {
  const res = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/${method}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  return res.json().catch(() => ({ ok: false }));
}

async function isChannelMember(telegramUserId: number | string): Promise<boolean> {
  if (!BOT_TOKEN || !telegramUserId) return false;
  const res = await tgCall("getChatMember", {
    chat_id: CHANNEL_ID,
    user_id: Number(telegramUserId)
  });
  if (!res?.ok || !res?.result?.status) return false;
  return VALID_MEMBER_STATUSES.has(String(res.result.status));
}

function jsonResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS_HEADERS, "Content-Type": "application/json" }
  });
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: CORS_HEADERS });
  }

  const supabase = createClient(SUPABASE_URL, SERVICE_ROLE_KEY);
  const body = await req.json().catch(() => ({}));

  if (body && body.action === "check") {
    const authHeader = req.headers.get("Authorization") || "";
    const token = authHeader.replace(/^Bearer\s+/i, "").trim();
    if (!token) {
      return jsonResponse({ error: "Unauthorized" }, 401);
    }
    const { data: userRes, error: userErr } = await supabase.auth.getUser(token);
    if (userErr || !userRes?.user) {
      return jsonResponse({ error: "Invalid session" }, 401);
    }
    const userId = userRes.user.id;
    const { data: releaseRow } = await supabase
      .from("app_releases")
      .select("*")
      .eq("id", 1)
      .maybeSingle();

    const { data: syncRow } = await supabase
      .from("user_sync")
      .select("telegram_user_id, telegram_verified")
      .eq("user_id", userId)
      .maybeSingle();

    const tgId = syncRow?.telegram_user_id || null;
    if (!tgId) {
      return jsonResponse({
        member: false,
        linked: false,
        leftChannel: false,
        channelUrl: releaseRow?.channel_url || CHANNEL_URL,
        release: releaseRow || null
      });
    }

    const stillMember = await isChannelMember(tgId);
    if (stillMember !== Boolean(syncRow?.telegram_verified)) {
      await supabase
        .from("user_sync")
        .update({ telegram_verified: stillMember })
        .eq("user_id", userId);
    }

    return jsonResponse({
      member: stillMember,
      linked: true,
      leftChannel: !stillMember,
      channelUrl: releaseRow?.channel_url || CHANNEL_URL,
      release: releaseRow || null
    });
  }

  const msg = body?.message;
  if (!msg) {
    return jsonResponse({ ok: true });
  }

  const chatId = msg.chat?.id;
  const fromId = String(msg.from?.id || "");
  const text = String(msg.text || msg.caption || "").trim();

  if (text.startsWith("/start")) {
    const parts = text.split(/\s+/);
    const param = parts[1] || "";
    if (param.startsWith("verify_")) {
      const userId = param.slice(7).trim();
      if (!userId) {
        await tgCall("sendMessage", {
          chat_id: chatId,
          text: "Invalid verification link. Please open SingularityTV and tap Verify again."
        });
        return jsonResponse({ ok: true });
      }
      const joined = await isChannelMember(fromId);
      if (!joined) {
        await tgCall("sendMessage", {
          chat_id: chatId,
          text: `You must join the official SingularityTV channel first:\n${CHANNEL_URL}\n\nAfter joining, tap /start verify_${userId} or return to the app and tap Verify with Bot again.`
        });
        return jsonResponse({ ok: true });
      }
      const { data: authUser } = await supabase.auth.admin.getUserById(userId);
      const userEmail = authUser?.user?.email || "";
      if (!userEmail) {
        await tgCall("sendMessage", {
          chat_id: chatId,
          text: "Account not found. Please sign in to SingularityTV first."
        });
        return jsonResponse({ ok: true });
      }
      await supabase.from("user_sync").upsert(
        {
          user_id: userId,
          email: userEmail,
          telegram_user_id: Number(fromId),
          telegram_verified: true,
          updated_at: new Date().toISOString()
        },
        { onConflict: "user_id" }
      );
      await tgCall("sendMessage", {
        chat_id: chatId,
        text: "Verified! Your SingularityTV account is unlocked. Return to the app and tap Check Now.\n\nNote: Stay subscribed to the channel to keep access active."
      });
      return jsonResponse({ ok: true });
    }
    await tgCall("sendMessage", {
      chat_id: chatId,
      text: `Welcome to SingularityTV Official Bot!\n\nJoin our channel: ${CHANNEL_URL}\nThen tap Verify inside the SingularityTV app.`
    });
    return jsonResponse({ ok: true });
  }

  if (fromId !== ADMIN_ID) {
    return jsonResponse({ ok: true });
  }

  if (text.startsWith("/status")) {
    const { data: rel } = await supabase.from("app_releases").select("*").eq("id", 1).maybeSingle();
    await tgCall("sendMessage", {
      chat_id: chatId,
      text: rel
        ? `Current Release:\nLatest: v${rel.latest_version}\nMin Required: v${rel.min_required_version}\nForce Update: ${rel.force_update ? "ON" : "OFF"}\nChangelog: ${rel.changelog || "None"}`
        : "No release record found."
    });
    return jsonResponse({ ok: true });
  }

  if (text.startsWith("/force")) {
    const arg = text.split(/\s+/)[1]?.toLowerCase();
    const enabled = arg !== "off";
    await supabase
      .from("app_releases")
      .update({ force_update: enabled, updated_at: new Date().toISOString() })
      .eq("id", 1);
    await tgCall("sendMessage", {
      chat_id: chatId,
      text: `Force update is now ${enabled ? "ON" : "OFF"}.`
    });
    return jsonResponse({ ok: true });
  }

  if (text.startsWith("/release")) {
    const rawArgs = text.replace(/^\/release\s*/i, "").trim();
    const [verPart, ...rest] = rawArgs.split("|");
    const version = (verPart || "").replace(/^v/i, "").trim();
    const changelog = rest.join("|").trim() || "New SingularityTV update available!";
    if (!version) {
      await tgCall("sendMessage", {
        chat_id: chatId,
        text: "Usage:\nSend APK/IPA file(s) or text with:\n/release 1.1.0 | What's new in this update"
      });
      return jsonResponse({ ok: true });
    }
    const postCaption = `SingularityTV v${version}\n\n${changelog}\n\nDownload and install the latest version to continue using SingularityTV.`;
    if (msg.document?.file_id) {
      await tgCall("sendDocument", {
        chat_id: CHANNEL_ID,
        document: msg.document.file_id,
        caption: postCaption
      });
    } else {
      await tgCall("sendMessage", {
        chat_id: CHANNEL_ID,
        text: postCaption
      });
    }
    await supabase.from("app_releases").upsert(
      {
        id: 1,
        latest_version: version,
        min_required_version: version,
        force_update: true,
        changelog,
        channel_url: CHANNEL_URL,
        update_post_url: CHANNEL_URL,
        updated_at: new Date().toISOString()
      },
      { onConflict: "id" }
    );
    await tgCall("sendMessage", {
      chat_id: chatId,
      text: `Published SingularityTV v${version} to the channel!\nAll older app versions are now locked and redirected to the channel.`
    });
    return jsonResponse({ ok: true });
  }

  if (msg.document?.file_id) {
    const fileName = String(msg.document.file_name || "");
    if (/\.(apk|ipa|zip)$/i.test(fileName)) {
      const { data: rel } = await supabase.from("app_releases").select("latest_version").eq("id", 1).maybeSingle();
      const ver = rel?.latest_version ? `v${rel.latest_version}` : "";
      const platformTag = /\.ipa$/i.test(fileName) ? "iOS (IPA)" : /\.apk$/i.test(fileName) ? "Android / Android TV (APK)" : "Package";
      const cap = text || `SingularityTV ${ver} · ${platformTag}`.trim();
      await tgCall("sendDocument", {
        chat_id: CHANNEL_ID,
        document: msg.document.file_id,
        caption: cap
      });
      await tgCall("sendMessage", {
        chat_id: chatId,
        text: `Published ${fileName} to the channel!`
      });
    }
  }

  return jsonResponse({ ok: true });
});
