import React, { useState, useEffect, useMemo, useCallback } from "react";
import { storage } from "../utils/storage";
import { touchBackupTimestamp } from "../utils/backup";

const LIVE_UI_STYLES = `
@keyframes stvLivePulse {
  0%, 100% { opacity: 1; transform: scale(1); }
  50% { opacity: 0.45; transform: scale(0.82); }
}
.live-card {
  position: relative;
  background: linear-gradient(160deg, rgba(28, 28, 38, 0.92), rgba(16, 16, 22, 0.96));
  border: 1px solid rgba(255, 255, 255, 0.08);
  border-radius: 16px;
  padding: 16px 14px 14px;
  cursor: pointer;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  transition: transform 0.18s ease, border-color 0.18s ease, box-shadow 0.18s ease;
  overflow: hidden;
}
.live-card:hover {
  transform: translateY(-3px);
  border-color: rgba(229, 9, 20, 0.55);
  box-shadow: 0 12px 28px rgba(0, 0, 0, 0.45), 0 0 18px rgba(229, 9, 20, 0.16);
}
.live-dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: #ff2e3a;
  display: inline-block;
  animation: stvLivePulse 1.5s ease-in-out infinite;
}
`;

const SATELLITES = [
  {
    id: "nilesat",
    name: "Nilesat 7°W",
    urls: [
      "https://iptv-org.github.io/iptv/languages/ara.m3u",
      "https://iptv-org.github.io/iptv/countries/eg.m3u",
      "https://iptv-org.github.io/iptv/countries/jo.m3u",
      "https://iptv-org.github.io/iptv/countries/lb.m3u",
      "https://iptv-org.github.io/iptv/countries/iq.m3u",
      "https://iptv-org.github.io/iptv/countries/sy.m3u",
      "https://iptv-org.github.io/iptv/countries/ps.m3u"
    ]
  },
  {
    id: "arabsat",
    name: "Arabsat / Badr 26°E",
    urls: [
      "https://iptv-org.github.io/iptv/countries/sa.m3u",
      "https://iptv-org.github.io/iptv/countries/ae.m3u",
      "https://iptv-org.github.io/iptv/countries/qa.m3u",
      "https://iptv-org.github.io/iptv/countries/kw.m3u",
      "https://iptv-org.github.io/iptv/countries/bh.m3u",
      "https://iptv-org.github.io/iptv/countries/om.m3u",
      "https://iptv-org.github.io/iptv/languages/ara.m3u"
    ]
  },
  {
    id: "eutelsat",
    name: "Eutelsat 7°W / Maghreb",
    urls: [
      "https://iptv-org.github.io/iptv/countries/ma.m3u",
      "https://iptv-org.github.io/iptv/countries/dz.m3u",
      "https://iptv-org.github.io/iptv/countries/tn.m3u",
      "https://iptv-org.github.io/iptv/countries/ly.m3u",
      "https://iptv-org.github.io/iptv/languages/ara.m3u"
    ]
  },
  {
    id: "hotbird",
    name: "Hotbird 13°E",
    urls: [
      "https://iptv-org.github.io/iptv/countries/it.m3u",
      "https://iptv-org.github.io/iptv/countries/fr.m3u",
      "https://iptv-org.github.io/iptv/countries/gb.m3u",
      "https://iptv-org.github.io/iptv/countries/pl.m3u",
      "https://raw.githubusercontent.com/Free-TV/IPTV/master/playlists/playlist_uk.m3u8",
      "https://raw.githubusercontent.com/Free-TV/IPTV/master/playlists/playlist_france.m3u8",
      "https://raw.githubusercontent.com/Free-TV/IPTV/master/playlists/playlist_italy.m3u8"
    ]
  },
  {
    id: "astra",
    name: "Astra 19.2°E",
    urls: [
      "https://iptv-org.github.io/iptv/countries/de.m3u",
      "https://iptv-org.github.io/iptv/countries/es.m3u",
      "https://iptv-org.github.io/iptv/countries/at.m3u",
      "https://raw.githubusercontent.com/Free-TV/IPTV/master/playlists/playlist_germany.m3u8",
      "https://raw.githubusercontent.com/Free-TV/IPTV/master/playlists/playlist_spain.m3u8"
    ]
  },
  {
    id: "turksat",
    name: "Turksat 42°E",
    urls: [
      "https://iptv-org.github.io/iptv/countries/tr.m3u",
      "https://iptv-org.github.io/iptv/countries/az.m3u",
      "https://raw.githubusercontent.com/Free-TV/IPTV/master/playlists/playlist_turkey.m3u8"
    ]
  },
  {
    id: "north_america",
    name: "North America (US / CA)",
    urls: [
      "https://iptv-org.github.io/iptv/countries/us.m3u",
      "https://iptv-org.github.io/iptv/countries/ca.m3u",
      "https://raw.githubusercontent.com/Free-TV/IPTV/master/playlists/playlist_usa.m3u8",
      "https://raw.githubusercontent.com/Free-TV/IPTV/master/playlists/playlist_canada.m3u8"
    ]
  },
  {
    id: "asiasat",
    name: "AsiaSat / East Asia",
    urls: [
      "https://iptv-org.github.io/iptv/countries/in.m3u",
      "https://iptv-org.github.io/iptv/countries/pk.m3u",
      "https://iptv-org.github.io/iptv/countries/jp.m3u",
      "https://iptv-org.github.io/iptv/countries/kr.m3u",
      "https://raw.githubusercontent.com/Free-TV/IPTV/master/playlists/playlist_japan.m3u8"
    ]
  },
  {
    id: "all",
    name: "All Satellites (Global)",
    urls: [
      "https://raw.githubusercontent.com/Free-TV/IPTV/master/playlist.m3u8",
      "https://shovo127.github.io/IPTV-By-Shovo/index.m3u",
      "https://iptv-org.github.io/iptv/categories/sports.m3u",
      "https://iptv-org.github.io/iptv/categories/news.m3u"
    ]
  }
];

const CATEGORIES = [
  { id: "all", label: "All" },
  { id: "sports", label: "Sports" },
  { id: "favorites", label: "Favorites" },
  { id: "news", label: "News" },
  { id: "movies", label: "Movies" },
  { id: "entertainment", label: "Entertainment" },
  { id: "kids", label: "Kids" },
  { id: "documentary", label: "Documentary" },
  { id: "music", label: "Music" },
  { id: "custom", label: "Custom M3U" }
];

const SPORTS_SUBCATEGORIES = [
  { id: "all_sports", label: "All Sports", accent: "#e50914" },
  { id: "football", label: "Football / Soccer", accent: "#22c55e" },
  { id: "ufc", label: "UFC", accent: "#ef4444" },
  { id: "pfl", label: "PFL", accent: "#3b82f6" },
  { id: "combat", label: "Fights & MMA", accent: "#f97316" },
  { id: "martial", label: "Martial Arts & Boxing", accent: "#eab308" },
  { id: "motorsport", label: "Motorsport & F1", accent: "#a855f7" },
  { id: "basketball", label: "Basketball & NBA", accent: "#ec4899" }
];

function isInvalidLabel(str) {
  const s = String(str || "").trim().toLowerCase();
  return !s || s === "undefined" || s === "null" || s === "n/a" || s === "none" || s === "unknown" || s === "live channel" || s === "live stream";
}

function classifyChannelGroup(rawGroup, rawName) {
  const g = String(rawGroup || "").trim();
  const gl = g.toLowerCase();
  const nl = String(rawName || "").toLowerCase();
  if (!isInvalidLabel(g)) {
    const clean = g.split(";")[0].trim();
    if (!isInvalidLabel(clean)) return clean;
  }
  if (/sport|bein|ssc|alkass|espn|ufc|pfl|mma|fight|boxing|combat|martial|wwe|aew|football|soccer|arryadia|ontime|kora|ad sport|dubai sport|f1|motor|nba|golf|tennis/.test(nl)) return "Sports";
  if (/news|jazeera|arabiya|hadath|sky|bbc|cnn|france 24|rt |cnbc|bloomberg|asharq|ekhbariya/.test(nl)) return "News";
  if (/movie|film|cinema|aflam|mbc 2|mbc max|rotana cinema|hbo|star movies|fox movies|action/.test(nl)) return "Movies";
  if (/kids|cartoon|mbc 3|spacetoon|nickelodeon|disney|cn |baraem|majid/.test(nl)) return "Kids";
  if (/doc|nat geo|national geographic|discovery|history|animal planet/.test(nl)) return "Documentary";
  if (/music|mtv|rotana music|mazzika|ghinwa|melody/.test(nl)) return "Music";
  return "Entertainment";
}

function detectSportSub(ch) {
  const txt = `${ch.name || ""} ${ch.group || ""}`.toLowerCase();
  const tags = [];
  if (/football|soccer|bein|ssc|alkass|kora|liga|premier|uefa|fifa|ontime|ad sport|dubai sport|arryadia|goal|mutv|real madrid|barca|chelsea|serie a|bundesliga|sport 1|sport 2|sport 3|sport 4|sport 5|riyadiya|sports/.test(txt)) {
    tags.push("football");
  }
  if (/\bufc\b|ultimate fighting|octagon|fight pass/.test(txt)) {
    tags.push("ufc");
  }
  if (/\bpfl\b|professional fighters|bellator/.test(txt)) {
    tags.push("pfl");
  }
  if (/mma|fight|ufc|pfl|bellator|cage|combat|glory|one championship|bare knuckle|bkfc|wwe|aew|impact|tna|wrestling/.test(txt)) {
    tags.push("combat");
  }
  if (/martial|boxing|kickbox|karate|muay|judo|taekwondo|bjj|jiu|k-1|dazn|top rank|matchroom|combat|fight/.test(txt)) {
    tags.push("martial");
  }
  if (/f1|formula|motogp|motor|racing|nascar|speed|red bull|rally|mavtv/.test(txt)) {
    tags.push("motorsport");
  }
  if (/nba|basketball|euroleague|hoops|ncaa|espn/.test(txt)) {
    tags.push("basketball");
  }
  return tags;
}

function isSportsChannel(ch) {
  const txt = `${ch.name || ""} ${ch.group || ""}`.toLowerCase();
  return /sport|bein|ssc|alkass|espn|ufc|pfl|mma|fight|boxing|combat|martial|wwe|aew|football|soccer|arryadia|ontime|kora|f1|motor|nba|golf|tennis|dazn|euro|fox sports|cbs sports|nbc sports|sky sports|tnt sports|tsn|red bull|riyadiya/.test(txt);
}

function parseM3u(text) {
  const lines = String(text || "").split(/\r?\n/);
  const items = [];
  let current = null;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    if (line.startsWith("#EXTINF")) {
      const logoMatch = line.match(/tvg-logo="([^"]*)"/i);
      const groupMatch = line.match(/group-title="([^"]*)"/i);
      const commaIdx = line.lastIndexOf(",");
      const rawName = commaIdx !== -1 ? line.slice(commaIdx + 1).trim() : "";
      if (/\[offline\]/i.test(rawName)) {
        current = null;
        continue;
      }
      const qualMatch = rawName.match(/\((4K|2160p|1080p|720p|576p|480p|HD|FHD|UHD)\)/i);
      const quality = qualMatch ? qualMatch[1].toUpperCase() : "";
      const cleanName = rawName
        .replace(/\((4K|2160p|1080p|720p|576p|480p|360p|HD|FHD|UHD)\)/gi, "")
        .replace(/\[[^\]]*\]/g, "")
        .replace(/\s+/g, " ")
        .trim();
      if (isInvalidLabel(cleanName)) {
        current = null;
        continue;
      }
      const rawGroup = groupMatch ? groupMatch[1].trim() : "";
      const cleanGroup = classifyChannelGroup(rawGroup, cleanName);
      const logo = logoMatch && !isInvalidLabel(logoMatch[1]) && /^https?:\/\//i.test(logoMatch[1]) ? logoMatch[1] : "";
      current = {
        name: cleanName,
        logo,
        group: cleanGroup,
        quality
      };
    } else if (!line.startsWith("#")) {
      const validUrl = /^https?:\/\/[^\s"'<>]+$/i.test(line) && !/undefined|null|example\.com/i.test(line);
      if (current && validUrl) {
        items.push({ ...current, url: line });
      }
      current = null;
    }
  }
  return items;
}

async function fetchPlaylistText(url) {
  const controller = new AbortController();
  const tid = setTimeout(() => controller.abort(), 9000);
  try {
    const res = await fetch(url, { signal: controller.signal });
    if (!res.ok) return "";
    return await res.text();
  } catch {
    return "";
  } finally {
    clearTimeout(tid);
  }
}

const DEAD_CACHE_KEY = "singularity_dead_live_urls_v1";

function loadDeadUrlSet() {
  try {
    const raw = sessionStorage.getItem(DEAD_CACHE_KEY);
    return new Set(raw ? JSON.parse(raw) : []);
  } catch {
    return new Set();
  }
}

function saveDeadUrlSet(set) {
  try {
    sessionStorage.setItem(DEAD_CACHE_KEY, JSON.stringify(Array.from(set).slice(-1500)));
  } catch {}
}

async function probeStreamAlive(url) {
  const controller = new AbortController();
  const tid = setTimeout(() => controller.abort(), 3200);
  try {
    const res = await fetch(url, { method: "GET", signal: controller.signal });
    clearTimeout(tid);
    if (res.status >= 400) return false;
    const ct = (res.headers.get("content-type") || "").toLowerCase();
    if (ct.includes("text/html")) return false;
    return true;
  } catch (err) {
    clearTimeout(tid);
    if (err && err.name === "AbortError") return false;
    const c2 = new AbortController();
    const tid2 = setTimeout(() => c2.abort(), 3200);
    try {
      await fetch(url, { method: "GET", mode: "no-cors", signal: c2.signal });
      clearTimeout(tid2);
      return true;
    } catch {
      clearTimeout(tid2);
      return false;
    }
  }
}

export default function LiveTVPage({ onOpenExoPlayer }) {
  const [satellite, setSatellite] = useState(() => {
    const saved = storage.get("liveSatellite");
    return SATELLITES.some(s => s.id === saved) ? saved : "nilesat";
  });
  const [category, setCategory] = useState("all");
  const [sportSub, setSportSub] = useState("all_sports");
  const [query, setQuery] = useState("");
  const [channels, setChannels] = useState([]);
  const [deadUrls, setDeadUrls] = useState(() => loadDeadUrlSet());
  const [checkingHealth, setCheckingHealth] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [favorites, setFavorites] = useState(() => storage.get("liveFavorites") || []);
  const [customUrl, setCustomUrl] = useState(() => storage.get("customLiveM3u") || "");
  const [customInput, setCustomInput] = useState(() => storage.get("customLiveM3u") || "");

  useEffect(() => {
    const onSync = () => {
      setFavorites(storage.get("liveFavorites") || []);
      const savedCustom = storage.get("customLiveM3u") || "";
      setCustomUrl(savedCustom);
      setCustomInput(savedCustom);
    };
    window.addEventListener("singularity:live-sync-updated", onSync);
    return () => window.removeEventListener("singularity:live-sync-updated", onSync);
  }, []);

  const loadChannels = useCallback(async () => {
    if (category === "favorites") {
      setError("");
      setLoading(false);
      return;
    }
    const urls = [];
    if (category === "custom") {
      if (!customUrl.trim()) {
        setChannels([]);
        setError("");
        setLoading(false);
        return;
      }
      urls.push(customUrl.trim());
    } else {
      const sat = SATELLITES.find(s => s.id === satellite) || SATELLITES[0];
      urls.push(...sat.urls);
      if (category === "sports") {
        urls.push("https://iptv-org.github.io/iptv/categories/sports.m3u");
        urls.push("https://shovo127.github.io/IPTV-By-Shovo/index.m3u");
        urls.push("https://raw.githubusercontent.com/Free-TV/IPTV/master/playlist.m3u8");
      } else if (category === "news") {
        urls.push("https://iptv-org.github.io/iptv/categories/news.m3u");
      } else if (category === "movies") {
        urls.push("https://iptv-org.github.io/iptv/categories/movies.m3u");
        urls.push("https://raw.githubusercontent.com/Free-TV/IPTV/master/playlists/playlist_zz_movies.m3u8");
      }
    }

    setLoading(true);
    setError("");
    try {
      const texts = await Promise.all(urls.map(fetchPlaylistText));
      const seenUrl = new Set();
      const merged = [];
      for (const txt of texts) {
        if (!txt) continue;
        const parsed = parseM3u(txt);
        for (const ch of parsed) {
          if (!ch.url || seenUrl.has(ch.url)) continue;
          seenUrl.add(ch.url);
          merged.push(ch);
        }
      }
      if (merged.length === 0) {
        setError("No working channels found for this satellite right now. Try switching satellite or Custom M3U.");
      }
      setChannels(merged);
    } catch (e) {
      setChannels([]);
      setError(e.message || "Failed to fetch channels.");
    } finally {
      setLoading(false);
    }
  }, [satellite, category, customUrl]);

  useEffect(() => {
    loadChannels();
  }, [loadChannels]);

  useEffect(() => {
    if (!channels.length) {
      setCheckingHealth(false);
      return;
    }
    let cancelled = false;
    const toCheck = channels.filter(c => c.url && !deadUrls.has(c.url)).slice(0, 240);
    if (!toCheck.length) {
      setCheckingHealth(false);
      return;
    }
    setCheckingHealth(true);
    let idx = 0;
    const newlyDead = [];
    const flushDead = () => {
      if (!newlyDead.length || cancelled) return;
      const batch = newlyDead.splice(0, newlyDead.length);
      setDeadUrls(prev => {
        const next = new Set(prev);
        for (const u of batch) next.add(u);
        saveDeadUrlSet(next);
        return next;
      });
    };
    const worker = async () => {
      while (!cancelled && idx < toCheck.length) {
        const item = toCheck[idx++];
        const ok = await probeStreamAlive(item.url);
        if (!ok && !cancelled) {
          newlyDead.push(item.url);
          if (newlyDead.length >= 6) flushDead();
        }
      }
    };
    const workers = Array.from({ length: 14 }, () => worker());
    Promise.all(workers).then(() => {
      flushDead();
      if (!cancelled) setCheckingHealth(false);
    });
    return () => {
      cancelled = true;
    };
  }, [channels]);

  const handleSatelliteChange = id => {
    setSatellite(id);
    storage.set("liveSatellite", id);
  };

  const toggleFavorite = useCallback((ch, e) => {
    e.stopPropagation();
    touchBackupTimestamp("_liveFavTs", ch.url);
    setFavorites(prev => {
      const exists = prev.some(f => f.url === ch.url);
      const next = exists ? prev.filter(f => f.url !== ch.url) : [ch, ...prev];
      storage.set("liveFavorites", next);
      window.dispatchEvent(new CustomEvent("streambert:cloud-sync-needed"));
      return next;
    });
  }, []);

  const handleSaveCustomM3u = e => {
    e.preventDefault();
    const clean = customInput.trim();
    setCustomUrl(clean);
    storage.set("customLiveM3u", clean);
    window.dispatchEvent(new CustomEvent("streambert:cloud-sync-needed"));
  };

  const playChannel = ch => {
    const payload = {
      url: ch.url,
      title: ch.name,
      mediaType: "live",
      isLive: true,
      startTimeSec: 0,
      subtitles: [],
      progressKey: ""
    };
    if (window.AndroidBridge?.openExoPlayer) {
      window.AndroidBridge.openExoPlayer(JSON.stringify(payload));
      return;
    }
    onOpenExoPlayer?.(payload);
  };

  const favUrls = useMemo(() => new Set(favorites.map(f => f.url)), [favorites]);

  const sportCounts = useMemo(() => {
    const counts = { all_sports: 0, football: 0, ufc: 0, pfl: 0, combat: 0, martial: 0, motorsport: 0, basketball: 0 };
    for (const ch of channels) {
      if (deadUrls.has(ch.url)) continue;
      if (!isSportsChannel(ch)) continue;
      counts.all_sports += 1;
      const tags = detectSportSub(ch);
      for (const t of tags) {
        if (counts[t] !== undefined) counts[t] += 1;
      }
    }
    return counts;
  }, [channels, deadUrls]);

  const displayedChannels = useMemo(() => {
    const base = category === "favorites" ? favorites.filter(f => f && !isInvalidLabel(f.name) && f.url) : channels;
    const q = query.trim().toLowerCase();
    return base.filter(ch => {
      if (category !== "favorites" && deadUrls.has(ch.url)) return false;
      if (category === "sports") {
        if (!isSportsChannel(ch)) return false;
        if (sportSub !== "all_sports") {
          const tags = detectSportSub(ch);
          if (!tags.includes(sportSub)) return false;
        }
      } else if (category !== "all" && category !== "favorites" && category !== "custom") {
        const g = (ch.group || "").toLowerCase();
        const n = (ch.name || "").toLowerCase();
        if (category === "news") {
          if (!g.includes("news") && !n.includes("news") && !n.includes("jazeera") && !n.includes("arabiya") && !n.includes("hadath") && !n.includes("sky") && !n.includes("bbc") && !n.includes("cnn")) return false;
        } else if (category === "movies") {
          if (!g.includes("movie") && !g.includes("film") && !g.includes("cinema") && !n.includes("aflam") && !n.includes("cinema") && !n.includes("mbc 2") && !n.includes("mbc max") && !n.includes("rotana") && !n.includes("movie")) return false;
        } else if (!g.includes(category) && !n.includes(category)) {
          return false;
        }
      }
      if (q) {
        return (ch.name || "").toLowerCase().includes(q) || (ch.group || "").toLowerCase().includes(q);
      }
      return true;
    });
  }, [category, sportSub, favorites, channels, query, deadUrls]);

  const activeSat = SATELLITES.find(s => s.id === satellite) || SATELLITES[0];

  return (
    <div style={{ padding: "18px 22px 84px", maxWidth: 1420, margin: "0 auto", direction: "ltr" }}>
      <style>{LIVE_UI_STYLES}</style>

      <div
        style={{
          background: "linear-gradient(135deg, rgba(229, 9, 20, 0.2), rgba(20, 20, 30, 0.92) 55%, rgba(12, 12, 18, 0.96))",
          border: "1px solid rgba(255, 255, 255, 0.1)",
          borderRadius: 20,
          padding: "20px 22px",
          marginBottom: 18,
          display: "flex",
          flexWrap: "wrap",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 16
        }}
      >
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
            <span
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: 6,
                background: "rgba(229, 9, 20, 0.92)",
                color: "#fff",
                fontSize: 11,
                fontWeight: 800,
                letterSpacing: "0.08em",
                padding: "4px 10px",
                borderRadius: 999
              }}
            >
              <span className="live-dot" style={{ background: "#fff" }} />
              ON AIR
            </span>
            <h1 style={{ margin: 0, fontSize: 25, fontWeight: 800, color: "#fff" }}>Live TV</h1>
            {!loading && displayedChannels.length > 0 && (
              <span style={{ fontSize: 12, fontWeight: 700, color: "rgba(255,255,255,0.85)", background: "rgba(255,255,255,0.1)", padding: "3px 10px", borderRadius: 999 }}>
                {displayedChannels.length} channels
              </span>
            )}
            {checkingHealth && !loading && (
              <span style={{ fontSize: 11, fontWeight: 600, color: "#7be3a2", background: "rgba(72,199,116,0.14)", border: "1px solid rgba(72,199,116,0.35)", padding: "3px 9px", borderRadius: 999 }}>
                Checking live streams...
              </span>
            )}
          </div>
          <div style={{ fontSize: 13, color: "rgba(255,255,255,0.68)", marginTop: 6 }}>
            Signal: <strong style={{ color: "#fff" }}>{activeSat.name}</strong> · Football, UFC, PFL, Combat, News & Movies
          </div>
        </div>

        <div style={{ display: "flex", flexWrap: "wrap", gap: 10, alignItems: "center" }}>
          <div style={{ position: "relative", display: "inline-flex", alignItems: "center" }}>
            <select
              value={satellite}
              onChange={e => handleSatelliteChange(e.target.value)}
              aria-label="Select Satellite Signal"
              style={{
                padding: "10px 14px",
                borderRadius: 12,
                background: "rgba(255,255,255,0.08)",
                color: "#fff",
                border: "1px solid rgba(255,255,255,0.16)",
                fontSize: 13,
                fontWeight: 700,
                outline: "none",
                cursor: "pointer"
              }}
            >
              {SATELLITES.map(s => (
                <option key={s.id} value={s.id} style={{ background: "#14141c", color: "#fff" }}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>

          <input
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search channels, UFC, PFL, beIN..."
            style={{
              padding: "10px 14px",
              borderRadius: 12,
              background: "rgba(255,255,255,0.07)",
              color: "#fff",
              border: "1px solid rgba(255,255,255,0.14)",
              fontSize: 13,
              outline: "none",
              minWidth: 215
            }}
          />
        </div>
      </div>

      <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 10, marginBottom: 12 }}>
        {CATEGORIES.map(cat => (
          <button
            key={cat.id}
            type="button"
            onClick={() => setCategory(cat.id)}
            style={{
              padding: "9px 16px",
              borderRadius: 999,
              border: category === cat.id ? "1px solid #e50914" : "1px solid rgba(255,255,255,0.1)",
              background: category === cat.id ? "linear-gradient(135deg, #e50914, #b80710)" : "rgba(255,255,255,0.05)",
              color: category === cat.id ? "#fff" : "rgba(255,255,255,0.72)",
              fontSize: 13,
              fontWeight: 700,
              whiteSpace: "nowrap",
              cursor: "pointer",
              boxShadow: category === cat.id ? "0 4px 14px rgba(229,9,20,0.35)" : "none"
            }}
          >
            {cat.label}
            {cat.id === "favorites" && favorites.length > 0 ? ` (${favorites.length})` : ""}
          </button>
        ))}
      </div>

      {category === "sports" && (
        <div
          style={{
            background: "rgba(255, 255, 255, 0.03)",
            border: "1px solid rgba(255, 255, 255, 0.08)",
            borderRadius: 16,
            padding: "14px 14px 10px",
            marginBottom: 18
          }}
        >
          <div style={{ fontSize: 12, fontWeight: 700, color: "rgba(255,255,255,0.6)", textTransform: "uppercase", letterSpacing: "0.08em", marginBottom: 10 }}>
            Sports Arena Channels
          </div>
          <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 4 }}>
            {SPORTS_SUBCATEGORIES.map(sub => {
              const active = sportSub === sub.id;
              const cnt = sportCounts[sub.id] || 0;
              return (
                <button
                  key={sub.id}
                  type="button"
                  onClick={() => setSportSub(sub.id)}
                  style={{
                    padding: "8px 14px",
                    borderRadius: 12,
                    border: active ? `1px solid ${sub.accent}` : "1px solid rgba(255,255,255,0.1)",
                    background: active ? `${sub.accent}2e` : "rgba(255,255,255,0.04)",
                    color: active ? "#fff" : "rgba(255,255,255,0.75)",
                    fontSize: 13,
                    fontWeight: 700,
                    whiteSpace: "nowrap",
                    cursor: "pointer",
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 7
                  }}
                >
                  <span style={{ width: 8, height: 8, borderRadius: "50%", background: sub.accent }} />
                  <span>{sub.label}</span>
                  {cnt > 0 && (
                    <span style={{ fontSize: 11, opacity: 0.85, background: "rgba(0,0,0,0.35)", padding: "1px 6px", borderRadius: 999 }}>
                      {cnt}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {category === "custom" && (
        <form onSubmit={handleSaveCustomM3u} style={{ display: "flex", gap: 10, marginBottom: 20, flexWrap: "wrap" }}>
          <input
            type="url"
            value={customInput}
            onChange={e => setCustomInput(e.target.value)}
            placeholder="Paste your M3U / M3U8 playlist URL..."
            style={{
              flex: "1 1 260px",
              padding: "10px 14px",
              borderRadius: 12,
              background: "var(--surface2)",
              color: "var(--text)",
              border: "1px solid var(--border)",
              fontSize: 13,
              outline: "none"
            }}
          />
          <button type="submit" className="btn btn-primary" style={{ padding: "10px 18px" }}>
            Load Playlist
          </button>
        </form>
      )}

      {loading ? (
        <div style={{ padding: 54, textAlign: "center", color: "var(--text2)", fontSize: 15 }}>
          Tuning satellite channels...
        </div>
      ) : error ? (
        <div style={{ padding: 36, textAlign: "center", color: "var(--red)", fontSize: 14 }}>
          {error}
        </div>
      ) : displayedChannels.length === 0 ? (
        <div style={{ padding: 48, textAlign: "center", color: "var(--text3)", fontSize: 14 }}>
          {category === "favorites"
            ? "No favorite live channels yet. Tap the heart icon on any channel to save it."
            : "No channels matched this filter on the selected satellite. Try switching satellite or All Sports."}
        </div>
      ) : (
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(176px, 1fr))",
            gap: 14
          }}
        >
          {displayedChannels.slice(0, 600).map((ch, idx) => {
            const isFav = favUrls.has(ch.url);
            return (
              <div
                key={`${ch.url}_${idx}`}
                className="live-card"
                onClick={() => playChannel(ch)}
                role="button"
                tabIndex={0}
                onKeyDown={e => { if (e.key === "Enter") playChannel(ch); }}
              >
                <div style={{ width: "100%", display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 2 }}>
                  <span
                    style={{
                      display: "inline-flex",
                      alignItems: "center",
                      gap: 5,
                      background: "rgba(229, 9, 20, 0.2)",
                      border: "1px solid rgba(229, 9, 20, 0.45)",
                      color: "#ff5c66",
                      fontSize: 10,
                      fontWeight: 800,
                      padding: "2px 7px",
                      borderRadius: 999
                    }}
                  >
                    <span className="live-dot" />
                    LIVE
                  </span>

                  <div style={{ display: "inline-flex", alignItems: "center", gap: 6 }}>
                    {ch.quality && (
                      <span
                        style={{
                          fontSize: 10,
                          fontWeight: 700,
                          color: "rgba(255,255,255,0.8)",
                          background: "rgba(255,255,255,0.1)",
                          padding: "2px 6px",
                          borderRadius: 6
                        }}
                      >
                        {ch.quality}
                      </span>
                    )}
                    <button
                      type="button"
                      onClick={e => toggleFavorite(ch, e)}
                      aria-label="Toggle favorite channel"
                      style={{
                        background: "rgba(255,255,255,0.08)",
                        border: "none",
                        borderRadius: "50%",
                        width: 26,
                        height: 26,
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        color: isFav ? "#e50914" : "rgba(255,255,255,0.6)",
                        cursor: "pointer"
                      }}
                    >
                      <svg width="13" height="13" viewBox="0 0 24 24" fill={isFav ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2.2">
                        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
                      </svg>
                    </button>
                  </div>
                </div>

                <div
                  style={{
                    width: 78,
                    height: 54,
                    borderRadius: 12,
                    background: "rgba(255,255,255,0.06)",
                    border: "1px solid rgba(255,255,255,0.06)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    overflow: "hidden",
                    padding: 7
                  }}
                >
                  {ch.logo ? (
                    <img
                      src={ch.logo}
                      alt={ch.name}
                      loading="lazy"
                      onError={e => { e.currentTarget.style.display = "none"; }}
                      style={{ maxWidth: "100%", maxHeight: "100%", objectFit: "contain" }}
                    />
                  ) : (
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.45)" strokeWidth="2">
                      <rect x="2" y="7" width="20" height="15" rx="2" ry="2" />
                      <polyline points="17 2 12 7 7 2" />
                    </svg>
                  )}
                </div>

                <div
                  style={{
                    fontSize: 13,
                    fontWeight: 700,
                    color: "#fff",
                    textAlign: "center",
                    display: "-webkit-box",
                    WebkitLineClamp: 2,
                    WebkitBoxOrient: "vertical",
                    overflow: "hidden",
                    minHeight: 34,
                    lineHeight: 1.3
                  }}
                >
                  {ch.name}
                </div>

                <div
                  style={{
                    fontSize: 11,
                    fontWeight: 600,
                    color: "rgba(255,255,255,0.62)",
                    background: "rgba(255,255,255,0.06)",
                    padding: "3px 9px",
                    borderRadius: 999,
                    maxWidth: "100%",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap"
                  }}
                >
                  {ch.group}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
