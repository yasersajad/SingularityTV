import React, { useState, useEffect, useMemo, useCallback } from "react";
import { storage } from "../utils/storage";

const COUNTRIES = [
  { code: "ara_all", name: "All Arabic Channels", freeTv: null, lang: "ara" },
  { code: "sa", name: "Saudi Arabia", freeTv: "saudi_arabia" },
  { code: "ae", name: "United Arab Emirates", freeTv: "united_arab_emirates" },
  { code: "eg", name: "Egypt", freeTv: "egypt" },
  { code: "kw", name: "Kuwait", freeTv: "kuwait" },
  { code: "qa", name: "Qatar", freeTv: "qatar" },
  { code: "bh", name: "Bahrain", freeTv: "bahrain" },
  { code: "om", name: "Oman", freeTv: "oman" },
  { code: "jo", name: "Jordan", freeTv: "jordan" },
  { code: "lb", name: "Lebanon", freeTv: "lebanon" },
  { code: "iq", name: "Iraq", freeTv: "iraq" },
  { code: "ma", name: "Morocco", freeTv: "morocco" },
  { code: "dz", name: "Algeria", freeTv: "algeria" },
  { code: "tn", name: "Tunisia", freeTv: "tunisia" },
  { code: "us", name: "United States", freeTv: "usa" },
  { code: "gb", name: "United Kingdom", freeTv: "uk" },
  { code: "ca", name: "Canada", freeTv: "canada" },
  { code: "fr", name: "France", freeTv: "france" },
  { code: "de", name: "Germany", freeTv: "germany" },
  { code: "es", name: "Spain", freeTv: "spain" },
  { code: "it", name: "Italy", freeTv: "italy" },
  { code: "tr", name: "Turkey", freeTv: "turkey" },
  { code: "in", name: "India", freeTv: "india" },
  { code: "pk", name: "Pakistan", freeTv: "pakistan" },
  { code: "jp", name: "Japan", freeTv: "japan" },
  { code: "kr", name: "South Korea", freeTv: "korea" },
  { code: "br", name: "Brazil", freeTv: "brazil" },
  { code: "au", name: "Australia", freeTv: "australia" },
  { code: "all", name: "All Countries (Global)", freeTv: null }
];

const CATEGORIES = [
  { id: "all", label: "All" },
  { id: "favorites", label: "Favorites" },
  { id: "sports", label: "Sports" },
  { id: "news", label: "News" },
  { id: "movies", label: "Movies" },
  { id: "entertainment", label: "Entertainment" },
  { id: "kids", label: "Kids" },
  { id: "documentary", label: "Documentary" },
  { id: "music", label: "Music" },
  { id: "general", label: "General" },
  { id: "custom", label: "Custom M3U" }
];

function parseM3u(text) {
  const lines = String(text || "").split(/\r?\n/);
  const items = [];
  let current = null;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    if (line.startsWith("#EXTINF")) {
      const logoMatch = line.match(/tvg-logo="([^"]*)"/i);
      const groupMatch = line.match(/group-title="([^"]*)"/i);
      const commaIdx = line.lastIndexOf(",");
      const name = commaIdx !== -1 ? line.slice(commaIdx + 1).trim() : "Live Channel";
      current = {
        name: name || "Live Channel",
        logo: logoMatch ? logoMatch[1] : "",
        group: groupMatch ? groupMatch[1] : "General"
      };
    } else if (!line.startsWith("#") && /^https?:\/\//i.test(line)) {
      if (current) {
        items.push({ ...current, url: line });
        current = null;
      } else {
        items.push({ name: "Live Stream", logo: "", group: "General", url: line });
      }
    }
  }
  return items;
}

async function fetchPlaylistText(url) {
  const controller = new AbortController();
  const tid = setTimeout(() => controller.abort(), 9000);
  try {
    const res = await fetch(url, { signal: controller.signal });
    if (!res.ok) return "";
    return await res.text();
  } catch {
    return "";
  } finally {
    clearTimeout(tid);
  }
}

export default function LiveTVPage({ onOpenExoPlayer }) {
  const [country, setCountry] = useState(() => storage.get("liveCountry") || "ara_all");
  const [category, setCategory] = useState("all");
  const [query, setQuery] = useState("");
  const [channels, setChannels] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [favorites, setFavorites] = useState(() => storage.get("liveFavorites") || []);
  const [customUrl, setCustomUrl] = useState(() => storage.get("customLiveM3u") || "");
  const [customInput, setCustomInput] = useState(() => storage.get("customLiveM3u") || "");

  useEffect(() => {
    const onSync = () => {
      setFavorites(storage.get("liveFavorites") || []);
      const savedCustom = storage.get("customLiveM3u") || "";
      setCustomUrl(savedCustom);
      setCustomInput(savedCustom);
    };
    window.addEventListener("singularity:live-sync-updated", onSync);
    return () => window.removeEventListener("singularity:live-sync-updated", onSync);
  }, []);

  const loadChannels = useCallback(async () => {
    if (category === "favorites") {
      setError("");
      setLoading(false);
      return;
    }
    const urls = [];
    if (category === "custom") {
      if (!customUrl.trim()) {
        setChannels([]);
        setError("");
        setLoading(false);
        return;
      }
      urls.push(customUrl.trim());
    } else if (country === "ara_all") {
      urls.push("https://iptv-org.github.io/iptv/languages/ara.m3u");
      urls.push("https://iptv-org.github.io/iptv/countries/sa.m3u");
      urls.push("https://iptv-org.github.io/iptv/countries/ae.m3u");
      urls.push("https://iptv-org.github.io/iptv/countries/eg.m3u");
      urls.push("https://iptv-org.github.io/iptv/countries/qa.m3u");
      urls.push("https://iptv-org.github.io/iptv/countries/kw.m3u");
      if (category === "sports") {
        urls.push("https://iptv-org.github.io/iptv/categories/sports.m3u");
      }
    } else if (country === "all") {
      const catSlug = category === "all" ? "general" : category;
      urls.push(`https://iptv-org.github.io/iptv/categories/${catSlug}.m3u`);
      urls.push("https://raw.githubusercontent.com/Free-TV/IPTV/master/playlist.m3u8");
      urls.push("https://shovo127.github.io/IPTV-By-Shovo/index.m3u");
    } else {
      const cObj = COUNTRIES.find(c => c.code === country);
      urls.push(`https://iptv-org.github.io/iptv/countries/${country}.m3u`);
      if (cObj?.freeTv) {
        urls.push(`https://raw.githubusercontent.com/Free-TV/IPTV/master/playlists/playlist_${cObj.freeTv}.m3u8`);
      }
      if (category === "sports") {
        urls.push("https://iptv-org.github.io/iptv/categories/sports.m3u");
      } else if (category === "news") {
        urls.push("https://iptv-org.github.io/iptv/categories/news.m3u");
      } else if (category === "movies") {
        urls.push("https://iptv-org.github.io/iptv/categories/movies.m3u");
        urls.push("https://raw.githubusercontent.com/Free-TV/IPTV/master/playlists/playlist_zz_movies.m3u8");
      }
    }

    setLoading(true);
    setError("");
    try {
      const texts = await Promise.all(urls.map(fetchPlaylistText));
      const seenUrl = new Set();
      const merged = [];
      for (const txt of texts) {
        if (!txt) continue;
        const parsed = parseM3u(txt);
        for (const ch of parsed) {
          if (!ch.url || seenUrl.has(ch.url)) continue;
          seenUrl.add(ch.url);
          merged.push(ch);
        }
      }
      if (merged.length === 0) {
        setError("Could not load channels right now. Try another country or Custom M3U.");
      }
      setChannels(merged);
    } catch (e) {
      setChannels([]);
      setError(e.message || "Failed to fetch channels.");
    } finally {
      setLoading(false);
    }
  }, [country, category, customUrl]);

  useEffect(() => {
    loadChannels();
  }, [loadChannels]);

  const handleCountryChange = code => {
    setCountry(code);
    storage.set("liveCountry", code);
  };

  const toggleFavorite = useCallback((ch, e) => {
    e.stopPropagation();
    setFavorites(prev => {
      const exists = prev.some(f => f.url === ch.url);
      const next = exists ? prev.filter(f => f.url !== ch.url) : [ch, ...prev];
      storage.set("liveFavorites", next);
      window.dispatchEvent(new CustomEvent("streambert:cloud-sync-needed"));
      return next;
    });
  }, []);

  const handleSaveCustomM3u = e => {
    e.preventDefault();
    const clean = customInput.trim();
    setCustomUrl(clean);
    storage.set("customLiveM3u", clean);
    window.dispatchEvent(new CustomEvent("streambert:cloud-sync-needed"));
  };

  const playChannel = ch => {
    const payload = {
      url: ch.url,
      title: ch.name,
      mediaType: "live",
      isLive: true,
      startTimeSec: 0,
      subtitles: [],
      progressKey: ""
    };
    if (window.AndroidBridge?.openExoPlayer) {
      window.AndroidBridge.openExoPlayer(JSON.stringify(payload));
      return;
    }
    onOpenExoPlayer?.(payload);
  };

  const favUrls = useMemo(() => new Set(favorites.map(f => f.url)), [favorites]);

  const displayedChannels = useMemo(() => {
    const base = category === "favorites" ? favorites : channels;
    const q = query.trim().toLowerCase();
    return base.filter(ch => {
      if (category !== "all" && category !== "favorites" && category !== "custom" && country !== "all") {
        const g = (ch.group || "").toLowerCase();
        const n = (ch.name || "").toLowerCase();
        if (category === "sports") {
          if (!g.includes("sport") && !n.includes("sport") && !n.includes("bein") && !n.includes("ssc") && !n.includes("alkass") && !n.includes("espn")) return false;
        } else if (category === "news") {
          if (!g.includes("news") && !n.includes("news") && !n.includes("jazeera") && !n.includes("arabiya") && !n.includes("hadath") && !n.includes("sky") && !n.includes("bbc") && !n.includes("cnn")) return false;
        } else if (category === "movies") {
          if (!g.includes("movie") && !g.includes("film") && !g.includes("cinema") && !n.includes("aflam") && !n.includes("cinema") && !n.includes("mbc 2") && !n.includes("mbc max") && !n.includes("rotana") && !n.includes("movie")) return false;
        } else if (!g.includes(category) && !n.includes(category)) {
          return false;
        }
      }
      if (q) {
        return (ch.name || "").toLowerCase().includes(q) || (ch.group || "").toLowerCase().includes(q);
      }
      return true;
    });
  }, [category, favorites, channels, country, query]);

  return (
    <div style={{ padding: "20px 24px 80px", maxWidth: 1380, margin: "0 auto", direction: "ltr" }}>
      <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", justifyContent: "space-between", gap: 14, marginBottom: 18 }}>
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <h1 style={{ margin: 0, fontSize: 24, fontWeight: 800, color: "var(--text)" }}>Live TV</h1>
            {!loading && displayedChannels.length > 0 && (
              <span style={{ fontSize: 12, fontWeight: 700, color: "#fff", background: "var(--red)", padding: "2px 9px", borderRadius: 999 }}>
                {displayedChannels.length}
              </span>
            )}
          </div>
          <div style={{ fontSize: 13, color: "var(--text3)", marginTop: 3 }}>
            Multi-source live sports, news, movies & international channels by country
          </div>
        </div>

        <div style={{ display: "flex", flexWrap: "wrap", gap: 10, alignItems: "center" }}>
          <select
            value={country}
            onChange={e => handleCountryChange(e.target.value)}
            aria-label="Select Country"
            style={{
              padding: "9px 14px",
              borderRadius: 10,
              background: "var(--surface2)",
              color: "var(--text)",
              border: "1px solid var(--border)",
              fontSize: 13,
              fontWeight: 600,
              outline: "none",
              cursor: "pointer"
            }}
          >
            {COUNTRIES.map(c => (
              <option key={c.code} value={c.code} style={{ background: "#14141c", color: "#fff" }}>
                {c.name}
              </option>
            ))}
          </select>

          <input
            type="text"
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search channels..."
            style={{
              padding: "9px 14px",
              borderRadius: 10,
              background: "var(--surface2)",
              color: "var(--text)",
              border: "1px solid var(--border)",
              fontSize: 13,
              outline: "none",
              minWidth: 190
            }}
          />
        </div>
      </div>

      <div style={{ display: "flex", gap: 8, overflowX: "auto", paddingBottom: 10, marginBottom: 18 }}>
        {CATEGORIES.map(cat => (
          <button
            key={cat.id}
            type="button"
            onClick={() => setCategory(cat.id)}
            style={{
              padding: "8px 15px",
              borderRadius: 999,
              border: category === cat.id ? "1px solid var(--red)" : "1px solid var(--border)",
              background: category === cat.id ? "var(--red)" : "var(--surface2)",
              color: category === cat.id ? "#fff" : "var(--text2)",
              fontSize: 13,
              fontWeight: 700,
              whiteSpace: "nowrap",
              cursor: "pointer"
            }}
          >
            {cat.label}
            {cat.id === "favorites" && favorites.length > 0 ? ` (${favorites.length})` : ""}
          </button>
        ))}
      </div>

      {category === "custom" && (
        <form onSubmit={handleSaveCustomM3u} style={{ display: "flex", gap: 10, marginBottom: 20, flexWrap: "wrap" }}>
          <input
            type="url"
            value={customInput}
            onChange={e => setCustomInput(e.target.value)}
            placeholder="Paste your M3U / M3U8 playlist URL..."
            style={{
              flex: "1 1 260px",
              padding: "10px 14px",
              borderRadius: 10,
              background: "var(--surface2)",
              color: "var(--text)",
              border: "1px solid var(--border)",
              fontSize: 13,
              outline: "none"
            }}
          />
          <button type="submit" className="btn btn-primary" style={{ padding: "10px 18px" }}>
            Load Playlist
          </button>
        </form>
      )}

      {loading ? (
        <div style={{ padding: 48, textAlign: "center", color: "var(--text2)", fontSize: 15 }}>
          Loading live channels...
        </div>
      ) : error ? (
        <div style={{ padding: 36, textAlign: "center", color: "var(--red)", fontSize: 14 }}>
          {error}
        </div>
      ) : displayedChannels.length === 0 ? (
        <div style={{ padding: 48, textAlign: "center", color: "var(--text3)", fontSize: 14 }}>
          {category === "favorites"
            ? "No favorite live channels yet. Tap the heart icon on any channel to save it."
            : "No matching live channels found for this country or category."}
        </div>
      ) : (
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(175px, 1fr))",
            gap: 14
          }}
        >
          {displayedChannels.slice(0, 600).map((ch, idx) => {
            const isFav = favUrls.has(ch.url);
            return (
              <div
                key={`${ch.url}_${idx}`}
                onClick={() => playChannel(ch)}
                role="button"
                tabIndex={0}
                onKeyDown={e => { if (e.key === "Enter") playChannel(ch); }}
                style={{
                  position: "relative",
                  background: "var(--surface2)",
                  border: "1px solid var(--border)",
                  borderRadius: 14,
                  padding: "16px 14px 14px",
                  cursor: "pointer",
                  display: "flex",
                  flexDirection: "column",
                  alignItems: "center",
                  gap: 10,
                  transition: "transform 0.16s ease, border-color 0.16s ease"
                }}
              >
                <button
                  type="button"
                  onClick={e => toggleFavorite(ch, e)}
                  aria-label="Toggle favorite channel"
                  style={{
                    position: "absolute",
                    top: 8,
                    right: 8,
                    background: "rgba(0,0,0,0.4)",
                    border: "none",
                    borderRadius: "50%",
                    width: 28,
                    height: 28,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: isFav ? "#e50914" : "rgba(255,255,255,0.6)",
                    cursor: "pointer"
                  }}
                >
                  <svg width="14" height="14" viewBox="0 0 24 24" fill={isFav ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2.2">
                    <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
                  </svg>
                </button>

                <div
                  style={{
                    width: 68,
                    height: 52,
                    borderRadius: 10,
                    background: "rgba(255,255,255,0.06)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    overflow: "hidden",
                    padding: 6
                  }}
                >
                  {ch.logo ? (
                    <img
                      src={ch.logo}
                      alt={ch.name}
                      loading="lazy"
                      onError={e => { e.currentTarget.style.display = "none"; }}
                      style={{ maxWidth: "100%", maxHeight: "100%", objectFit: "contain" }}
                    />
                  ) : (
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="rgba(255,255,255,0.45)" strokeWidth="2">
                      <rect x="2" y="7" width="20" height="15" rx="2" ry="2" />
                      <polyline points="17 2 12 7 7 2" />
                    </svg>
                  )}
                </div>

                <div
                  style={{
                    fontSize: 13,
                    fontWeight: 700,
                    color: "var(--text)",
                    textAlign: "center",
                    display: "-webkit-box",
                    WebkitLineClamp: 2,
                    WebkitBoxOrient: "vertical",
                    overflow: "hidden",
                    minHeight: 34
                  }}
                >
                  {ch.name}
                </div>

                <div
                  style={{
                    fontSize: 11,
                    color: "var(--text3)",
                    background: "rgba(229,9,20,0.14)",
                    border: "1px solid rgba(229,9,20,0.3)",
                    padding: "2px 8px",
                    borderRadius: 999,
                    maxWidth: "100%",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap"
                  }}
                >
                  LIVE · {ch.group || "General"}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
