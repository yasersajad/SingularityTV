const EPG_SOURCES = [
  { url: "https://dearbulut.github.io/iptv/epg/sa.xml.gz", gzip: true },
  { url: "https://dearbulut.github.io/iptv/epg/ae.xml.gz", gzip: true },
  { url: "https://dearbulut.github.io/iptv/epg/us.xml.gz", gzip: true },
  { url: "https://dearbulut.github.io/iptv/epg/gb.xml.gz", gzip: true },
  { url: "https://raw.githubusercontent.com/dhasap/dhanytv/main/epg.xml", gzip: false },
  { url: "https://epgshare01.online/epgshare01/epg_ripper_AE1.xml.gz", gzip: true },
  { url: "https://epgshare01.online/epgshare01/epg_ripper_US1.xml.gz", gzip: true }
];

const SPORTS_EVENT_FEEDS = [
  { sport: "ufc", label: "UFC", accent: "#ef4444", url: "https://site.api.espn.com/apis/site/v2/sports/mma/ufc/scoreboard" },
  { sport: "pfl", label: "PFL", accent: "#3b82f6", url: "https://site.api.espn.com/apis/site/v2/sports/mma/pfl/scoreboard" },
  { sport: "football", label: "Football", accent: "#22c55e", url: "https://site.api.espn.com/apis/site/v2/sports/soccer/all/scoreboard" },
  { sport: "basketball", label: "NBA", accent: "#ec4899", url: "https://site.api.espn.com/apis/site/v2/sports/basketball/nba/scoreboard" },
  { sport: "motorsport", label: "F1", accent: "#a855f7", url: "https://site.api.espn.com/apis/site/v2/sports/racing/f1/scoreboard" }
];

let epgCache = null;
let epgCacheTs = 0;
let epgPromise = null;

let eventsCache = null;
let eventsCacheTs = 0;

export function normalizeChannelKey(str) {
  return String(str || "")
    .toLowerCase()
    .replace(/\.(us|uk|ae|sa|eg|fr|de|es|it|tr|qa|kw|ma|ca|au|in|jp)\b/g, "")
    .replace(/\b(hd|fhd|uhd|sd|4k|1080p|720p|480p|tv|channel|live|east|west|plus)\b/g, "")
    .replace(/[^a-z0-9\u0600-\u06ff]+/g, "")
    .trim();
}

function parseXmltvTime(raw) {
  const m = String(raw || "").trim().match(/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})\s*([+-]\d{4})?/);
  if (!m) return 0;
  const iso = `${m[1]}-${m[2]}-${m[3]}T${m[4]}:${m[5]}:${m[6]}`;
  if (m[7]) {
    const tz = `${m[7].slice(0, 3)}:${m[7].slice(3)}`;
    return Date.parse(iso + tz) || 0;
  }
  return Date.parse(iso + "Z") || 0;
}

function decodeXmlEntities(str) {
  return String(str || "")
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;|&apos;/g, "'")
    .trim();
}

async function fetchXmlText(url, isGzip) {
  const controller = new AbortController();
  const tid = setTimeout(() => controller.abort(), 11000);
  try {
    const res = await fetch(url, { signal: controller.signal });
    if (!res.ok) return "";
    if (isGzip && typeof DecompressionStream !== "undefined" && res.body) {
      const ds = new DecompressionStream("gzip");
      const decompressed = res.body.pipeThrough(ds);
      return await new Response(decompressed).text();
    }
    return await res.text();
  } catch {
    return "";
  } finally {
    clearTimeout(tid);
  }
}

function parseXmltvIntoMap(xmlText, nowMs, map) {
  if (!xmlText || xmlText.length < 100) return;
  const chNames = new Map();
  const chRegex = /<channel\s+[^>]*id="([^"]+)"[^>]*>([\s\S]*?)<\/channel>/gi;
  let cm;
  while ((cm = chRegex.exec(xmlText)) !== null) {
    const cid = cm[1].trim();
    const block = cm[2];
    const dnMatch = block.match(/<display-name[^>]*>([^<]+)<\/display-name>/i);
    if (dnMatch) {
      chNames.set(cid, decodeXmlEntities(dnMatch[1]));
    }
  }

  const progRegex = /<programme\s+([^>]+)>([\s\S]*?)<\/programme>/gi;
  let pm;
  while ((pm = progRegex.exec(xmlText)) !== null) {
    const attrs = pm[1];
    const startM = attrs.match(/start="([^"]+)"/i);
    const stopM = attrs.match(/stop="([^"]+)"/i);
    const chM = attrs.match(/channel="([^"]+)"/i);
    if (!startM || !stopM || !chM) continue;
    const startMs = parseXmltvTime(startM[1]);
    const stopMs = parseXmltvTime(stopM[1]);
    if (!startMs || !stopMs) continue;
    if (stopMs < nowMs || startMs > nowMs + 6 * 3600 * 1000) continue;

    const body = pm[2];
    const titleM = body.match(/<title[^>]*>([^<]+)<\/title>/i);
    if (!titleM) continue;
    const title = decodeXmlEntities(titleM[1]);
    if (!title || /jadwal belum tersedia/i.test(title)) continue;
    const descM = body.match(/<desc[^>]*>([^<]+)<\/desc>/i);
    const desc = descM ? decodeXmlEntities(descM[1]) : "";
    const catM = body.match(/<category[^>]*>([^<]+)<\/category>/i);
    const cat = catM ? decodeXmlEntities(catM[1]) : "";

    const rawId = chM[1].trim();
    const keys = [rawId.toLowerCase(), normalizeChannelKey(rawId)];
    const dn = chNames.get(rawId);
    if (dn) keys.push(normalizeChannelKey(dn));

    const isNow = startMs <= nowMs && stopMs > nowMs;
    const entry = { title, desc, category: cat, startMs, stopMs };

    for (const k of keys) {
      if (!k) continue;
      const cur = map.get(k) || { now: null, next: null };
      if (isNow) {
        if (!cur.now) cur.now = entry;
      } else if (startMs > nowMs) {
        if (!cur.next || startMs < cur.next.startMs) cur.next = entry;
      }
      map.set(k, cur);
    }
  }
}

export async function loadLiveEpgMap() {
  if (epgCache && Date.now() - epgCacheTs < 10 * 60 * 1000) {
    return epgCache;
  }
  if (epgPromise) return epgPromise;
  epgPromise = (async () => {
    const nowMs = Date.now();
    const map = new Map();
    const texts = await Promise.all(EPG_SOURCES.map(s => fetchXmlText(s.url, s.gzip)));
    for (const xml of texts) {
      parseXmltvIntoMap(xml, nowMs, map);
    }
    epgCache = map;
    epgCacheTs = Date.now();
    epgPromise = null;
    return map;
  })();
  return epgPromise;
}

export function lookupChannelEpg(epgMap, ch) {
  if (!epgMap || !ch) return null;
  if (ch.tvgId) {
    const byId = epgMap.get(String(ch.tvgId).toLowerCase()) || epgMap.get(normalizeChannelKey(ch.tvgId));
    if (byId && (byId.now || byId.next)) return byId;
  }
  const nk = normalizeChannelKey(ch.name);
  if (nk) {
    const byName = epgMap.get(nk);
    if (byName && (byName.now || byName.next)) return byName;
  }
  return null;
}

export function classifyProgramContent(program) {
  if (!program || !program.title) return null;
  const full = `${program.title} ${program.desc || ""} ${program.category || ""}`.toLowerCase();
  const title = program.title;

  const isPress = /press conference|weigh-in|weigh in|face off|face-off|embedded|countdown|media day|ceremonial|pre-show|post-fight|post fight|talk show|podcast|studio|highlights|recap|magazine/.test(full);
  const ufcNum = title.match(/\bufc\s*(\d{2,4})\b/i);
  const isUfc = /\bufc\b|ultimate fighting/.test(full);
  const isPfl = /\bpfl\b|professional fighters league|bellator/.test(full);
  const isFootball = /football|soccer|premier league|champions league|europa league|la liga|serie a|bundesliga|ligue 1|saudi pro|roshn|world cup|copa|fifa|uefa|afc|caf|mls|eredivisie|fa cup|carabao|\bvs\.?\b.*(fc|sc|united|city|real|barcelona|hilal|nassr|ittihad|ahli|arsenal|liverpool|chelsea|bayern|psg|inter|milan|juventus)|كورة|كرة القدم|الدوري/.test(full);
  const isBoxingMartial = /boxing|kickboxing|muay thai|karate|judo|taekwondo|jiu-jitsu|bjj|glory|one championship|bkfc|bare knuckle|wwe|aew|wrestling|martial arts|combat|mma|fight night|cage/.test(full);
  const isMotor = /formula 1|\bf1\b|motogp|nascar|grand prix|indycar|rally|motorsport|racing/.test(full);
  const isBasket = /\bnba\b|basketball|euroleague|wnba|ncaa basketball/.test(full);

  const sportTags = [];
  if (isUfc) {
    sportTags.push("ufc", "combat");
  }
  if (isPfl) {
    sportTags.push("pfl", "combat");
  }
  if (isFootball) {
    sportTags.push("football");
  }
  if (isBoxingMartial) {
    sportTags.push("combat", "martial");
  }
  if (isMotor) {
    sportTags.push("motorsport");
  }
  if (isBasket) {
    sportTags.push("basketball");
  }

  if (isUfc && isPress) {
    return {
      badge: ufcNum ? `UFC ${ufcNum[1]} · PRESS CONF` : "UFC · PRESS CONF",
      color: "#f59e0b",
      sportTags: ["ufc", "combat"],
      isPress: true
    };
  }
  if (isUfc) {
    return {
      badge: ufcNum ? `UFC ${ufcNum[1]}` : "UFC LIVE",
      color: "#ef4444",
      sportTags: ["ufc", "combat"],
      isPress: false
    };
  }
  if (isPfl && isPress) {
    return {
      badge: "PFL · PRESS CONF",
      color: "#f59e0b",
      sportTags: ["pfl", "combat"],
      isPress: true
    };
  }
  if (isPfl) {
    return {
      badge: "PFL EVENT",
      color: "#3b82f6",
      sportTags: ["pfl", "combat"],
      isPress: false
    };
  }
  if (isFootball && isPress) {
    return {
      badge: "FOOTBALL · STUDIO",
      color: "#f59e0b",
      sportTags: ["football"],
      isPress: true
    };
  }
  if (isFootball) {
    return {
      badge: "LIVE FOOTBALL",
      color: "#22c55e",
      sportTags: ["football"],
      isPress: false
    };
  }
  if (isBoxingMartial && isPress) {
    return {
      badge: "COMBAT · PRESS CONF",
      color: "#f59e0b",
      sportTags: ["combat", "martial"],
      isPress: true
    };
  }
  if (isBoxingMartial) {
    return {
      badge: "FIGHT / MARTIAL ARTS",
      color: "#f97316",
      sportTags: ["combat", "martial"],
      isPress: false
    };
  }
  if (isMotor) {
    return {
      badge: "MOTORSPORT",
      color: "#a855f7",
      sportTags: ["motorsport"],
      isPress: isPress
    };
  }
  if (isBasket) {
    return {
      badge: "BASKETBALL / NBA",
      color: "#ec4899",
      sportTags: ["basketball"],
      isPress: isPress
    };
  }
  if (isPress) {
    return {
      badge: "STUDIO / TALK",
      color: "#64748b",
      sportTags: [],
      isPress: true
    };
  }
  return {
    badge: "ON AIR",
    color: "#64748b",
    sportTags: [],
    isPress: false
  };
}

export async function loadLiveSportsEvents() {
  if (eventsCache && Date.now() - eventsCacheTs < 5 * 60 * 1000) {
    return eventsCache;
  }
  const results = await Promise.all(
    SPORTS_EVENT_FEEDS.map(async feed => {
      const controller = new AbortController();
      const tid = setTimeout(() => controller.abort(), 7000);
      try {
        const res = await fetch(feed.url, { signal: controller.signal });
        if (!res.ok) return [];
        const json = await res.json();
        const evs = Array.isArray(json?.events) ? json.events : [];
        return evs.slice(0, 6).map(ev => {
          const st = ev?.status?.type || {};
          const state = st.state || "pre";
          const detail = st.shortDetail || st.description || "";
          return {
            id: `${feed.sport}_${ev.id}`,
            sport: feed.sport,
            label: feed.label,
            accent: feed.accent,
            name: ev.shortName || ev.name || feed.label,
            fullName: ev.name || ev.shortName || feed.label,
            isLive: state === "in",
            isUpcoming: state === "pre",
            detail,
            date: ev.date || ""
          };
        });
      } catch {
        return [];
      } finally {
        clearTimeout(tid);
      }
    })
  );
  const flat = results.flat().filter(e => e.isLive || e.isUpcoming);
  flat.sort((a, b) => (b.isLive ? 1 : 0) - (a.isLive ? 1 : 0));
  eventsCache = flat;
  eventsCacheTs = Date.now();
  return flat;
}
