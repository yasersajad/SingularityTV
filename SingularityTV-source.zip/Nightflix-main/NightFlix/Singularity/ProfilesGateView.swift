import SwiftUI

struct ProfilesGateView: View {
    let allowDismiss: Bool

    @EnvironmentObject private var sessionManager: SingularitySessionManager
    @Environment(\.dismiss) private var dismiss
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    @State private var manageMode = false
    @State private var cardsVisible = false
    @State private var selectedGlowId: String?

    @State private var isShowingEditor = false
    @State private var editingProfile: UserProfile?
    @State private var nameInput = ""
    @State private var colorInput = UserProfile.avatarPalette[0]
    @State private var isKidsInput = false
    @State private var isSaving = false
    @State private var showDeleteConfirmation = false

    private let columns = [
        GridItem(.adaptive(minimum: 118, maximum: 150), spacing: 20)
    ]

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color(hex: "1B0609"), Color(hex: "08080C"), Color(hex: "040406")],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            VStack(spacing: 0) {
                topBar

                ScrollView {
                    VStack(spacing: 26) {
                        VStack(spacing: 6) {
                            Text(manageMode ? "Manage Profiles" : "Who's Watching?")
                                .font(.system(size: 28, weight: .heavy, design: .rounded))
                                .foregroundStyle(.white)
                                .opacity(cardsVisible || reduceMotion ? 1 : 0)

                            if let email = sessionManager.session?.user.email {
                                Text(email)
                                    .font(.caption)
                                    .foregroundStyle(.white.opacity(0.55))
                            }
                        }
                        .padding(.top, 12)

                        if let err = sessionManager.profileError {
                            Text(err)
                                .font(.footnote)
                                .foregroundStyle(Color(hex: "FF8C92"))
                                .padding(12)
                                .frame(maxWidth: 460)
                                .background(NightFlixStyle.accentColor.opacity(0.15), in: RoundedRectangle(cornerRadius: 10))
                        }

                        LazyVGrid(columns: columns, spacing: 24) {
                            ForEach(Array(sessionManager.profiles.enumerated()), id: \.element.id) { index, profile in
                                profileCard(profile, index: index)
                            }

                            if sessionManager.profiles.count < 5 {
                                addProfileCard(index: sessionManager.profiles.count)
                            }
                        }
                        .frame(maxWidth: 560)
                        .padding(.horizontal, 20)

                        Button {
                            HapticManager.shared.selection()
                            withAnimation(reduceMotion ? nil : .easeOut(duration: 0.2)) {
                                manageMode.toggle()
                            }
                        } label: {
                            Text(manageMode ? "Done" : "Manage Profiles")
                                .font(.subheadline.weight(.bold))
                                .foregroundStyle(.white)
                                .padding(.horizontal, 24)
                                .padding(.vertical, 11)
                                .background(Color.white.opacity(0.08), in: Capsule())
                                .overlay {
                                    Capsule().stroke(Color.white.opacity(0.18), lineWidth: 1)
                                }
                        }
                        .buttonStyle(NFScaleButtonStyle())
                        .padding(.top, 8)
                    }
                    .padding(.vertical, 24)
                    .frame(maxWidth: .infinity)
                }
            }
        }
        .preferredColorScheme(.dark)
        .onAppear {
            sessionManager.profileError = nil
            if reduceMotion {
                cardsVisible = true
            } else {
                cardsVisible = false
                withAnimation(.spring(response: 0.48, dampingFraction: 0.82)) {
                    cardsVisible = true
                }
            }
        }
        .sheet(isPresented: $isShowingEditor) {
            profileEditorSheet
                .presentationBackground(Color(hex: "0D0D12"))
                .presentationDragIndicator(.visible)
        }
    }

    private var topBar: some View {
        HStack {
            HStack(spacing: 8) {
                Text("S")
                    .font(.system(size: 22, weight: .black, design: .rounded))
                    .foregroundStyle(NightFlixStyle.accentColor)
                Text("SingularityTV")
                    .font(.headline.weight(.bold))
                    .foregroundStyle(.white)
            }

            Spacer()

            if allowDismiss {
                Button {
                    dismiss()
                } label: {
                    Image(systemName: "xmark")
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.white.opacity(0.8))
                        .frame(width: 34, height: 34)
                        .background(Color.white.opacity(0.09), in: Circle())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Close Profiles")
            }
        }
        .padding(.horizontal, 20)
        .padding(.top, 14)
        .padding(.bottom, 6)
    }

    private func profileCard(_ profile: UserProfile, index: Int) -> some View {
        let isActive = profile.id == sessionManager.activeProfileId
        let isLaunching = selectedGlowId == profile.id
        let delay = reduceMotion ? 0.0 : Double(index) * 0.075

        return Button {
            if manageMode {
                openEditor(for: profile)
            } else {
                Task { await handleSelect(profile) }
            }
        } label: {
            VStack(spacing: 10) {
                ZStack {
                    ProfileAvatarBadge(profile: profile, size: 96)
                        .overlay {
                            if isLaunching || (isActive && !manageMode) {
                                RoundedRectangle(cornerRadius: 26, style: .continuous)
                                    .stroke(isLaunching ? profile.color : Color.white.opacity(0.85), lineWidth: isLaunching ? 3.5 : 2)
                            }
                        }
                        .shadow(color: isLaunching ? profile.color.opacity(0.65) : .clear, radius: 18)

                    if manageMode {
                        RoundedRectangle(cornerRadius: 26, style: .continuous)
                            .fill(Color.black.opacity(0.45))
                            .frame(width: 96, height: 96)
                        Image(systemName: "pencil")
                            .font(.title3.weight(.bold))
                            .foregroundStyle(.white)
                    }
                }
                .scaleEffect(isLaunching ? 1.07 : 1.0)

                Text(profile.name)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white)
                    .lineLimit(1)

                if isActive && !manageMode {
                    Text("ACTIVE")
                        .font(.system(size: 10, weight: .bold))
                        .tracking(1)
                        .foregroundStyle(NightFlixStyle.accentColor)
                }
            }
            .padding(8)
            .opacity(cardsVisible || reduceMotion ? 1 : 0)
            .scaleEffect(cardsVisible || reduceMotion ? 1 : 0.88)
            .animation(
                reduceMotion ? nil : .spring(response: 0.45, dampingFraction: 0.78).delay(delay),
                value: cardsVisible
            )
        }
        .buttonStyle(NFScaleButtonStyle())
        .disabled(sessionManager.isSwitchingProfile)
    }

    private func addProfileCard(index: Int) -> some View {
        let delay = reduceMotion ? 0.0 : Double(index) * 0.075

        return Button {
            openEditor(for: nil)
        } label: {
            VStack(spacing: 10) {
                ZStack {
                    RoundedRectangle(cornerRadius: 26, style: .continuous)
                        .fill(Color.white.opacity(0.06))
                        .frame(width: 96, height: 96)
                        .overlay {
                            RoundedRectangle(cornerRadius: 26, style: .continuous)
                                .stroke(Color.white.opacity(0.18), style: StrokeStyle(lineWidth: 1.5, dash: [6]))
                        }
                    Image(systemName: "plus")
                        .font(.system(size: 30, weight: .semibold))
                        .foregroundStyle(.white.opacity(0.85))
                }

                Text("Add Profile")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.85))
            }
            .padding(8)
            .opacity(cardsVisible || reduceMotion ? 1 : 0)
            .scaleEffect(cardsVisible || reduceMotion ? 1 : 0.88)
            .animation(
                reduceMotion ? nil : .spring(response: 0.45, dampingFraction: 0.78).delay(delay),
                value: cardsVisible
            )
        }
        .buttonStyle(NFScaleButtonStyle())
        .disabled(sessionManager.isSwitchingProfile)
    }

    private func handleSelect(_ profile: UserProfile) async {
        guard !sessionManager.isSwitchingProfile else { return }
        HapticManager.shared.selection()
        if !reduceMotion {
            withAnimation(.spring(response: 0.3, dampingFraction: 0.72)) {
                selectedGlowId = profile.id
            }
            try? await Task.sleep(for: .milliseconds(220))
        }
        selectedGlowId = nil
        await sessionManager.selectProfile(profile)
        if allowDismiss {
            dismiss()
        }
    }

    private func openEditor(for profile: UserProfile?) {
        sessionManager.profileError = nil
        editingProfile = profile
        if let profile {
            nameInput = profile.name
            colorInput = profile.avatarColor
            isKidsInput = profile.isKids
        } else {
            nameInput = ""
            let idx = sessionManager.profiles.count % UserProfile.avatarPalette.count
            colorInput = UserProfile.avatarPalette[idx]
            isKidsInput = false
        }
        isShowingEditor = true
    }

    private var profileEditorSheet: some View {
        let previewProfile = UserProfile(
            id: editingProfile?.id ?? "preview",
            name: nameInput.isEmpty ? "S" : nameInput,
            avatarColor: colorInput,
            isKids: isKidsInput,
            createdAt: 0
        )

        return NavigationStack {
            ScrollView {
                VStack(spacing: 22) {
                    ProfileAvatarBadge(profile: previewProfile, size: 100)
                        .padding(.top, 10)

                    TextField("Profile Name", text: Binding(
                        get: { nameInput },
                        set: { nameInput = String($0.prefix(24)) }
                    ))
                    .padding(14)
                    .foregroundStyle(.white)
                    .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 12))
                    .overlay {
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(Color.white.opacity(0.16), lineWidth: 1)
                    }

                    VStack(alignment: .leading, spacing: 10) {
                        Text("Avatar Color")
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(.white.opacity(0.65))

                        HStack(spacing: 12) {
                            ForEach(UserProfile.avatarPalette, id: \.self) { hex in
                                let selected = colorInput.caseInsensitiveCompare(hex) == .orderedSame
                                Button {
                                    HapticManager.shared.selection()
                                    colorInput = hex
                                } label: {
                                    Circle()
                                        .fill(Color(hex: hex.replacingOccurrences(of: "#", with: "")))
                                        .frame(width: 34, height: 34)
                                        .overlay {
                                            if selected {
                                                Circle().stroke(.white, lineWidth: 2.5)
                                            }
                                        }
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)

                    Toggle(isOn: $isKidsInput) {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Kids Profile")
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(.white)
                            Text("Filters adult & mature titles from catalog and search")
                                .font(.caption)
                                .foregroundStyle(.white.opacity(0.58))
                        }
                    }
                    .tint(NightFlixStyle.accentColor)
                    .padding(14)
                    .background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 12))

                    if let err = sessionManager.profileError {
                        Text(err)
                            .font(.footnote)
                            .foregroundStyle(Color(hex: "FF8C92"))
                    }

                    VStack(spacing: 10) {
                        Button {
                            Task {
                                isSaving = true
                                let ok: Bool
                                if let existing = editingProfile {
                                    ok = await sessionManager.updateProfile(
                                        id: existing.id,
                                        name: nameInput,
                                        avatarColor: colorInput,
                                        isKids: isKidsInput
                                    )
                                } else {
                                    ok = await sessionManager.createProfile(
                                        name: nameInput,
                                        avatarColor: colorInput,
                                        isKids: isKidsInput
                                    )
                                }
                                isSaving = false
                                if ok {
                                    isShowingEditor = false
                                }
                            }
                        } label: {
                            Text(isSaving ? "Saving..." : "Save Profile")
                                .font(.subheadline.weight(.bold))
                                .foregroundStyle(.white)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 14)
                                .background(NightFlixStyle.accentColor, in: RoundedRectangle(cornerRadius: 12))
                        }
                        .buttonStyle(NFScaleButtonStyle())
                        .disabled(isSaving)

                        if let existing = editingProfile, sessionManager.profiles.count > 1 {
                            Button(role: .destructive) {
                                showDeleteConfirmation = true
                            } label: {
                                Text("Delete Profile")
                                    .font(.subheadline.weight(.semibold))
                                    .frame(maxWidth: .infinity)
                                    .padding(.vertical, 12)
                            }
                            .disabled(isSaving)
                        }
                    }
                }
                .padding(20)
            }
            .navigationTitle(editingProfile == nil ? "Create Profile" : "Edit Profile")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        isShowingEditor = false
                    }
                }
            }
            .alert("Delete profile?", isPresented: $showDeleteConfirmation) {
                Button("Cancel", role: .cancel) {}
                Button("Delete", role: .destructive) {
                    guard let existing = editingProfile else { return }
                    Task {
                        isSaving = true
                        let ok = await sessionManager.deleteProfile(id: existing.id)
                        isSaving = false
                        if ok {
                            isShowingEditor = false
                        }
                    }
                }
            } message: {
                Text("This permanently removes this profile and its watch history and My List.")
            }
        }
    }
}

struct ProfileAvatarBadge: View {
    let profile: UserProfile
    let size: CGFloat

    var body: some View {
        ZStack(alignment: .bottomTrailing) {
            RoundedRectangle(cornerRadius: size * 0.27, style: .continuous)
                .fill(
                    LinearGradient(
                        colors: [profile.color, Color(hex: "090B12")],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing
                    )
                )
                .frame(width: size, height: size)
                .overlay {
                    RoundedRectangle(cornerRadius: size * 0.27, style: .continuous)
                        .stroke(Color.white.opacity(0.24), lineWidth: 1)
                }
                .overlay {
                    Text(profile.initial)
                        .font(.system(size: size * 0.42, weight: .heavy, design: .rounded))
                        .foregroundStyle(.white)
                }

            if profile.isKids {
                Text("KIDS")
                    .font(.system(size: max(8, size * 0.12), weight: .black))
                    .foregroundStyle(.black)
                    .padding(.horizontal, 5)
                    .padding(.vertical, 2)
                    .background(Color(hex: "E6B86A"), in: Capsule())
                    .offset(x: -4, y: -4)
            }
        }
    }
}
