import UIKit
import WebKit
import AuthenticationServices

class MainViewController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate, ASWebAuthenticationPresentationContextProviding, URLSessionDownloadDelegate {
    private var authSession: ASWebAuthenticationSession?
    private var updateDownloadTask: URLSessionDownloadTask?
    private var updateSession: URLSession?
    private var downloadedIpaUrl: URL?
    private var preprobeWebView: WKWebView?
    private var preprobeQueue: [String] = []
    private var preprobeCurrentSource: String = ""
    private var preprobeProgressKey: String = ""
    private var preprobeMeta: [String: Any] = [:]
    private var preprobeTimer: Timer?
    private var webView: WKWebView!
    private var lastM3u8Url: String = ""
    private var lastM3u8Time: TimeInterval = 0
    private weak var activePlayerVC: NativePlayerViewController?

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 8/255, green: 10/255, blue: 15/255, alpha: 1)

        let config = WKWebViewConfiguration()
        config.websiteDataStore = WKWebsiteDataStore.default()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = .all
        config.preferences.javaScriptCanOpenWindowsAutomatically = false
        config.preferences.setValue(true, forKey: "allowFileAccessFromFileURLs")
        config.setValue(true, forKey: "allowUniversalAccessFromFileURLs")

        let ucc = WKUserContentController()
        ucc.add(self, name: "SingularityBridge")
        ucc.add(self, name: "StreamSniffer")

        let snifferJs = """
        (function(){
          var hn = (location.hostname || '').toLowerCase();
          if (/cloudflare\\.com|recaptcha\\.net|hcaptcha\\.com|arkoselabs\\.com|geetest\\.com/.test(hn) || (hn.indexOf('google.com') !== -1 && location.pathname.indexOf('/recaptcha') !== -1)) return;
          if (window.__sbSnifferInstalled) return;
          window.__sbSnifferInstalled = true;
          function post(kind, url) {
            try {
              if (!url || typeof url !== 'string') return;
              window.webkit.messageHandlers.StreamSniffer.postMessage({ kind: kind, url: url, ref: location.href });
            } catch(e) {}
          }
          function checkUrl(u) {
            if (!u || typeof u !== 'string') return;
            var l = u.toLowerCase();
            if (l.indexOf('.m3u8') !== -1 || l.indexOf('.mpd') !== -1 || l.indexOf('master.txt') !== -1 || l.indexOf('playlist.txt') !== -1 || l.indexOf('/hls/') !== -1) {
              post('m3u8', u);
            } else if (l.indexOf('.mp4') !== -1 && l.indexOf('favicon') === -1 && l.indexOf('preview') === -1 && l.indexOf('trailer') === -1 && l.indexOf('logo') === -1) {
              post('m3u8', u);
            } else if (l.indexOf('.vtt') !== -1 || l.indexOf('.srt') !== -1) {
              post('sub', u);
            }
          }
          if (window.fetch) {
            var origFetch = window.fetch;
            window.fetch = function(input) {
              try { checkUrl(typeof input === 'string' ? input : (input && input.url)); } catch(e) {}
              return origFetch.apply(this, arguments);
            };
          }
          if (window.XMLHttpRequest) {
            var origOpen = XMLHttpRequest.prototype.open;
            XMLHttpRequest.prototype.open = function(m, u) {
              try { checkUrl(u); } catch(e) {}
              return origOpen.apply(this, arguments);
            };
          }
          try {
            var po = new PerformanceObserver(function(list) {
              list.getEntries().forEach(function(e) { checkUrl(e.name); });
            });
            po.observe({ entryTypes: ['resource'] });
          } catch(e) {}
        })();
        """
        ucc.addUserScript(WKUserScript(source: snifferJs, injectionTime: .atDocumentStart, forMainFrameOnly: false))
        config.userContentController = ucc

        webView = WKWebView(frame: .zero, configuration: config)
        webView.translatesAutoresizingMaskIntoConstraints = false
        webView.isOpaque = false
        webView.backgroundColor = UIColor(red: 8/255, green: 10/255, blue: 15/255, alpha: 1)
        webView.scrollView.backgroundColor = UIColor(red: 8/255, green: 10/255, blue: 15/255, alpha: 1)
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.navigationDelegate = self
        webView.uiDelegate = self
        let adRulesJson = "[{\"trigger\": {\"url-filter\": \".*\", \"if-domain\": [\"*google-analytics.com\", \"*googletagmanager.com\", \"*googletagservices.com\", \"*doubleclick.net\", \"*adservice.google.com\", \"*pagead2.googlesyndication.com\", \"*cdn.adx1.com\", \"*intelligenceadx.com\", \"*adsco.re\", \"*mc.yandex.com\", \"*mc.yandex.ru\", \"*bvtpk.com\", \"*my.rtmark.net\", \"*b7510.com\", \"*gt.unbrownunflat.com\", \"*im.malocacomals.com\", \"*nf.sixmossin.com\", \"*realizationnewestfangs.com\", \"*acscdn.com\", \"*lt.taloseempest.com\", \"*pl26708123.profitableratecpm.com\", \"*preferencenail.com\", \"*protrafficinspector.com\", \"*s10.histats.com\", \"*weirdopt.com\", \"*cloudflareinsights.com\", \"*kettledroopingcontinuation.com\", \"*wayfarerorthodox.com\", \"*woxaglasuy.net\", \"*adeptspiritual.com\", \"*calculating-laugh.com\", \"*amavhxdlofklxjg.xyz\", \"*usrpubtrk.com\", \"*adexchangeclear.com\", \"*rzjzjnavztycv.online\", \"*hameltnoummos.com\", \"*ancillammmm.com\", \"*hubeamily.com\", \"*llvpn.com\", \"*gillyspencie.com\", \"*soakysecrets.com\", \"*mdstats.info\", \"*ads-twitter.com\", \"*connatix.com\", \"*imasdk.googleapis.com\", \"*jwpltx.com\", \"*openfpcdn.io\", \"*phruk.org\", \"*welcomingexpulsion.com\", \"*pgo99.com\", \"*todditehexarch.com\", \"*uniolaicecaps.com\", \"*alloha.tv\", \"*pc.alloviewroll.com\", \"*yadro.ru\", \"*getaim.org\", \"*myangular.life\", \"*rstprgapipt.com\", \"*veselchaga.link\", \"*webvisor.org\", \"*datariaarpent.com\", \"*gamesrevenue.com\", \"*mgid.com\", \"*pushaffiliate.net\", \"*imp-mintads.site\", \"*xadsmart.com\", \"*tsyndicate.com\", \"*rapidadexchange.com\", \"*pxltag.com\", \"*runative-syndicate.com\", \"*cdn4ads.com\"]}, \"action\": {\"type\": \"block\"}}]"
        WKContentRuleListStore.default().compileContentRuleList(forIdentifier: "SingularityAdBlock", encodedContentRuleList: adRulesJson) { list, _ in
            if let list = list {
                DispatchQueue.main.async {
                    self.webView.configuration.userContentController.add(list)
                }
            }
        }
        webView.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"

        view.addSubview(webView)
        NSLayoutConstraint.activate([
            webView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            webView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor)
        ])

        clearStaleOtaIfBinaryUpdated()
        loadAppBundle()
        checkAndFetchOtaUpdate()
        NotificationCenter.default.addObserver(self, selector: #selector(onWillEnterForegroundOta), name: UIApplication.willEnterForegroundNotification, object: nil)
    }

    private func clearStaleOtaIfBinaryUpdated() {
        guard let exeUrl = Bundle.main.executableURL,
              let attrs = try? FileManager.default.attributesOfItem(atPath: exeUrl.path),
              let mdate = attrs[.modificationDate] as? Date else { return }
        let curStamp = String(Int(mdate.timeIntervalSince1970))
        let ud = UserDefaults.standard
        let prevStamp = ud.string(forKey: "ota_install_stamp") ?? ""
        if prevStamp != curStamp {
            let otaDir = otaDirectoryUrl()
            try? FileManager.default.removeItem(at: otaDir)
            ud.set(curStamp, forKey: "ota_install_stamp")
            ud.removeObject(forKey: "ota_version")
        }
    }

    @objc private func onWillEnterForegroundOta() {
        checkAndFetchOtaUpdate()
    }

    private func otaDirectoryUrl() -> URL {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        return docs.appendingPathComponent("ota", isDirectory: true)
    }

    private func loadAppBundle() {
        let baseOrigin = URL(string: "https://ios.singularitytv.local/app/index.html")!
        let bundlePath = Bundle.main.bundlePath
        let otaDir = otaDirectoryUrl()
        let otaJsUrl = otaDir.appendingPathComponent("bundle.js")
        let otaCssUrl = otaDir.appendingPathComponent("global.css")
        if let otaJs = try? String(contentsOf: otaJsUrl, encoding: .utf8), otaJs.count > 5000 {
            var cssText = (try? String(contentsOf: otaCssUrl, encoding: .utf8)) ?? ""
            if cssText.isEmpty {
                for p in [bundlePath + "/WebAssets/global.css", bundlePath + "/global.css"] {
                    if let s = try? String(contentsOfFile: p, encoding: .utf8), !s.isEmpty { cssText = s; break }
                }
            }
            let combinedHtml = """
            <!doctype html>
            <html lang="en">
            <head>
              <meta charset="UTF-8" />
              <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" />
              <title>SingularityTV</title>
              <style>\(cssText)</style>
            </head>
            <body>
              <div id="root"></div>
              <script>\(otaJs)</script>
            </body>
            </html>
            """
            webView.loadHTMLString(combinedHtml, baseURL: baseOrigin)
            return
        }
        let standalonePaths = [
            bundlePath + "/WebAssets/standalone.html",
            bundlePath + "/standalone.html"
        ]
        for path in standalonePaths {
            if let html = try? String(contentsOfFile: path, encoding: .utf8), !html.isEmpty {
                webView.loadHTMLString(html, baseURL: baseOrigin)
                return
            }
        }
        let cssPaths = [bundlePath + "/WebAssets/global.css", bundlePath + "/global.css"]
        let jsPaths = [bundlePath + "/WebAssets/bundle.js", bundlePath + "/bundle.js"]
        var cssContent = ""
        var jsContent = ""
        for p in cssPaths {
            if let s = try? String(contentsOfFile: p, encoding: .utf8), !s.isEmpty { cssContent = s; break }
        }
        for p in jsPaths {
            if let s = try? String(contentsOfFile: p, encoding: .utf8), !s.isEmpty { jsContent = s; break }
        }
        if !jsContent.isEmpty {
            let combinedHtml = """
            <!doctype html>
            <html lang="en">
            <head>
              <meta charset="UTF-8" />
              <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" />
              <title>SingularityTV</title>
              <style>\(cssContent)</style>
            </head>
            <body>
              <div id="root"></div>
              <script>\(jsContent)</script>
            </body>
            </html>
            """
            webView.loadHTMLString(combinedHtml, baseURL: baseOrigin)
            return
        }
        if let htmlUrl = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "WebAssets") ?? Bundle.main.url(forResource: "index", withExtension: "html") {
            let folderUrl = htmlUrl.deletingLastPathComponent()
            webView.loadFileURL(htmlUrl, allowingReadAccessTo: folderUrl)
        }
    }


    private func checkAndFetchOtaUpdate() {
        let base = "https://soufctreejgcpvqftxeb.supabase.co/functions/v1/telegram-gate"
        guard let url = URL(string: "\(base)?action=ota_manifest") else { return }
        URLSession.shared.dataTask(with: url) { [weak self] data, resp, _ in
            guard let self = self, let data = data,
                  let http = resp as? HTTPURLResponse, http.statusCode == 200,
                  let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else { return }
            let ud = UserDefaults.standard
            let remoteVer = (json["ota_version"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
            let localVer = ud.string(forKey: "ota_version") ?? ""
            guard !remoteVer.isEmpty, remoteVer != localVer else { return }
            var builtAtMs: Double = 0
            var builtBundleSha = ""
            var builtCssSha = ""
            if let fpUrl = Bundle.main.url(forResource: "ota-fingerprint", withExtension: "json", subdirectory: "WebAssets") ?? Bundle.main.url(forResource: "ota-fingerprint", withExtension: "json"),
               let fpData = try? Data(contentsOf: fpUrl),
               let fpObj = try? JSONSerialization.jsonObject(with: fpData) as? [String: Any] {
                builtAtMs = (fpObj["builtAtMs"] as? NSNumber)?.doubleValue ?? 0
                builtBundleSha = fpObj["bundleSha256"] as? String ?? ""
                builtCssSha = fpObj["cssSha256"] as? String ?? ""
            }
            var binMs: Double = 0
            if let exeUrl = Bundle.main.executableURL,
               let attrs = try? FileManager.default.attributesOfItem(atPath: exeUrl.path),
               let binDate = attrs[.modificationDate] as? Date {
                binMs = binDate.timeIntervalSince1970 * 1000.0
            }
            let baselineMs = max(builtAtMs, binMs)
            if let updatedStr = json["updated_at"] as? String, !updatedStr.isEmpty, baselineMs > 0 {
                let iso = ISO8601DateFormatter()
                iso.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
                let otaDate = iso.date(from: updatedStr) ?? ISO8601DateFormatter().date(from: updatedStr)
                if let otaDate = otaDate, (otaDate.timeIntervalSince1970 * 1000.0) <= baselineMs {
                    return
                }
            }
            let rBundleSha = json["bundle_sha256"] as? String ?? ""
            let rCssSha = json["css_sha256"] as? String ?? ""
            if !rBundleSha.isEmpty && rBundleSha == builtBundleSha && (rCssSha.isEmpty || rCssSha == builtCssSha) {
                return
            }
            let hasBundle = (json["has_bundle"] as? Bool) ?? false
            let hasCss = (json["has_css"] as? Bool) ?? false
            let dir = self.otaDirectoryUrl()
            try? FileManager.default.createDirectory(at: dir, withIntermediateDirectories: true)
            let group = DispatchGroup()
            var updatedAny = false
            if hasBundle, let bUrl = URL(string: "\(base)?action=ota_file&file=bundle.js") {
                group.enter()
                URLSession.shared.dataTask(with: bUrl) { bData, bResp, _ in
                    defer { group.leave() }
                    if let bd = bData, let bh = bResp as? HTTPURLResponse, bh.statusCode == 200, bd.count > 5000 {
                        let dst = dir.appendingPathComponent("bundle.js")
                        if (try? bd.write(to: dst, options: .atomic)) != nil { updatedAny = true }
                    }
                }.resume()
            }
            if hasCss, let cUrl = URL(string: "\(base)?action=ota_file&file=global.css") {
                group.enter()
                URLSession.shared.dataTask(with: cUrl) { cData, cResp, _ in
                    defer { group.leave() }
                    if let cd = cData, let ch = cResp as? HTTPURLResponse, ch.statusCode == 200, cd.count > 100 {
                        let dst = dir.appendingPathComponent("global.css")
                        if (try? cd.write(to: dst, options: .atomic)) != nil { updatedAny = true }
                    }
                }.resume()
            }
            group.notify(queue: .main) {
                if updatedAny {
                    ud.set(remoteVer, forKey: "ota_version")
                    if self.activePlayerVC == nil {
                        self.loadAppBundle()
                    }
                }
            }
        }.resume()
    }

    func dispatchToReact(channel: String, payloadJson: String) {
        let safeChannel = String(data: try! JSONSerialization.data(withJSONObject: [channel]), encoding: .utf8) ?? "[\"\"]"
        let js = "window.__streambertDispatch && window.__streambertDispatch((\(safeChannel))[0], \(payloadJson));"
        DispatchQueue.main.async {
            self.webView.evaluateJavaScript(js, completionHandler: nil)
        }
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        if message.name == "StreamSniffer" {
            guard let dict = message.body as? [String: Any],
                  let kind = dict["kind"] as? String,
                  let url = dict["url"] as? String else { return }
            if kind == "m3u8" {
                let now = Date().timeIntervalSince1970
                if url != lastM3u8Url || now - lastM3u8Time > 2.5 {
                    lastM3u8Url = url
                    lastM3u8Time = now
                    if let data = try? JSONSerialization.data(withJSONObject: [url]),
                       let arr = String(data: data, encoding: .utf8) {
                        let quoted = String(arr.dropFirst().dropLast())
                        dispatchToReact(channel: "m3u8-found", payloadJson: quoted)
                    }
                }
            } else if kind == "sub" {
                let payload: [String: Any] = ["url": url, "lang": "en"]
                if let data = try? JSONSerialization.data(withJSONObject: payload),
                   let str = String(data: data, encoding: .utf8) {
                    dispatchToReact(channel: "subtitle-found", payloadJson: str)
                }
            }
            return
        }

        if message.name == "SingularityBridge" {
            guard let body = message.body as? [String: Any],
                  let method = body["method"] as? String else { return }
            let args = body["args"] as? [Any] ?? []

            if method == "openExoPlayer", let payloadStr = args.first as? String {
                let playerVC = NativePlayerViewController(payloadJson: payloadStr)
                playerVC.modalPresentationStyle = .fullScreen
                playerVC.onProgressUpdate = { [weak self] key, pct, posSec, durSec, watched, playingNow in
                    let payload: [String: Any] = [
                        "progressKey": key,
                        "percent": pct,
                        "positionSec": posSec,
                        "durationSec": durSec,
                        "watched": watched,
                        "isPlaying": playingNow
                    ]
                    if let data = try? JSONSerialization.data(withJSONObject: payload),
                       let str = String(data: data, encoding: .utf8) {
                        self?.dispatchToReact(channel: "exo-progress", payloadJson: str)
                    }
                }
                playerVC.onBlockedAd = { [weak self] blockedUrl in
                    let host = URL(string: blockedUrl)?.host ?? "ad"
                    let payload: [String: Any] = ["total": 1, "domains": [host: 1]]
                    if let data = try? JSONSerialization.data(withJSONObject: payload),
                       let str = String(data: data, encoding: .utf8) {
                        self?.dispatchToReact(channel: "blocked-stats-update", payloadJson: str)
                    }
                }
                playerVC.onPreferredSource = { [weak self] sourceId in
                    if let data = try? JSONSerialization.data(withJSONObject: [sourceId]),
                       let arr = String(data: data, encoding: .utf8) {
                        let quoted = String(arr.dropFirst().dropLast())
                        self?.dispatchToReact(channel: "preferred-source-updated", payloadJson: quoted)
                    }
                }
                playerVC.onSubtitleStyleChanged = { [weak self] colorHex, bgMode, fontSizePt in
                    let payload: [String: Any] = [
                        "subTextColor": colorHex,
                        "subBgStyle": bgMode,
                        "subFontSizeSp": fontSizePt
                    ]
                    if let data = try? JSONSerialization.data(withJSONObject: payload),
                       let str = String(data: data, encoding: .utf8) {
                        self?.dispatchToReact(channel: "subtitle-style-changed", payloadJson: str)
                    }
                }
                activePlayerVC = playerVC
                present(playerVC, animated: true)
            } else if method == "startGoogleOAuth", let urlStr = args.first as? String, let authUrl = URL(string: urlStr) {
                let scheme = args.count > 1 ? (args[1] as? String ?? "singularitytv") : "singularitytv"
                DispatchQueue.main.async {
                    let session = ASWebAuthenticationSession(url: authUrl, callbackURLScheme: scheme) { [weak self] callbackURL, error in
                        if let cb = callbackURL {
                            if let data = try? JSONSerialization.data(withJSONObject: [cb.absoluteString]),
                               let arr = String(data: data, encoding: .utf8) {
                                let quoted = String(arr.dropFirst().dropLast())
                                self?.dispatchToReact(channel: "google-oauth-callback", payloadJson: quoted)
                            }
                        } else if let err = error {
                            if let data = try? JSONSerialization.data(withJSONObject: ["error:" + err.localizedDescription]),
                               let arr = String(data: data, encoding: .utf8) {
                                let quoted = String(arr.dropFirst().dropLast())
                                self?.dispatchToReact(channel: "google-oauth-callback", payloadJson: quoted)
                            }
                        }
                    }
                    session.presentationContextProvider = self
                    session.prefersEphemeralWebBrowserSession = false
                    self.authSession = session
                    session.start()
                }
            } else if method == "openExternal", let urlStr = args.first as? String, let targetUrl = URL(string: urlStr) {
                DispatchQueue.main.async {
                    UIApplication.shared.open(targetUrl, options: [:], completionHandler: nil)
                }
            } else if method == "deliverNextServerStream" {
                let url = args.first as? String ?? ""
                let sourceId = args.count > 1 ? (args[1] as? String ?? "") : ""
                activePlayerVC?.applyExternalResolvedStream(url: url, sourceId: sourceId)
            } else if method == "downloadAndInstallUpdate", let jsonStr = args.first as? String,
                      let data = jsonStr.data(using: .utf8),
                      let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                      let urlStr = obj["url"] as? String,
                      let dlUrl = URL(string: urlStr) {
                startIpaDownload(url: dlUrl)
            } else if method == "cancelUpdate" {
                updateDownloadTask?.cancel()
                updateDownloadTask = nil
            } else if method == "preprobeStream", let jsonStr = args.first as? String,
                      let data = jsonStr.data(using: .utf8),
                      let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
                startBackgroundPreprobe(obj)
            } else if method == "openDownloadedIpa" {
                if let fileUrl = downloadedIpaUrl {
                    DispatchQueue.main.async {
                        self.presentIpaShareSheet(fileUrl)
                    }
                }
            }
        }
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        if let saved = UserDefaults.standard.string(forKey: "streambert_lastWorkingSource"), !saved.isEmpty {
            if let data = try? JSONSerialization.data(withJSONObject: [saved]),
               let arr = String(data: data, encoding: .utf8) {
                let quoted = String(arr.dropFirst().dropLast())
                dispatchToReact(channel: "preferred-source-updated", payloadJson: quoted)
            }
        }
    }

    func webView(
        _ webView: WKWebView,
        createWebViewWith configuration: WKWebViewConfiguration,
        for navigationAction: WKNavigationAction,
        windowFeatures: WKWindowFeatures
    ) -> WKWebView? {
        return nil
    }

    func presentationAnchor(for session: ASWebAuthenticationSession) -> ASPresentationAnchor {
        return view.window ?? ASPresentationAnchor()
    }

    private func startIpaDownload(url: URL) {
        updateDownloadTask?.cancel()
        let cfg = URLSessionConfiguration.default
        let sess = URLSession(configuration: cfg, delegate: self, delegateQueue: nil)
        updateSession = sess
        var req = URLRequest(url: url, timeoutInterval: 120)
        req.setValue("SingularityTV/1.0.0", forHTTPHeaderField: "User-Agent")
        let task = sess.downloadTask(with: req)
        updateDownloadTask = task
        task.resume()
    }

    private func presentIpaShareSheet(_ fileUrl: URL) {
        let vc = UIActivityViewController(activityItems: [fileUrl], applicationActivities: nil)
        if let pop = vc.popoverPresentationController {
            pop.sourceView = self.view
            pop.sourceRect = CGRect(x: self.view.bounds.midX, y: self.view.bounds.midY, width: 1, height: 1)
        }
        present(vc, animated: true)
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
        guard totalBytesExpectedToWrite > 0 else { return }
        let pct = min(99, max(0, Int((Double(totalBytesWritten) / Double(totalBytesExpectedToWrite)) * 100.0)))
        let mbDone = String(format: "%.1f", Double(totalBytesWritten) / 1048576.0)
        let mbTot = String(format: "%.1f", Double(totalBytesExpectedToWrite) / 1048576.0)
        let payload: [String: Any] = ["percent": pct, "label": "Downloading \(mbDone) / \(mbTot) MB"]
        if let d = try? JSONSerialization.data(withJSONObject: payload), let js = String(data: d, encoding: .utf8) {
            dispatchToReact(channel: "update-progress", payloadJson: js)
        }
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
        let dest = docs.appendingPathComponent("SingularityTV-latest.ipa")
        try? FileManager.default.removeItem(at: dest)
        do {
            try FileManager.default.moveItem(at: location, to: dest)
            downloadedIpaUrl = dest
            let payload: [String: Any] = ["percent": 100, "label": "IPA ready! Save to Files or Sideload app.", "done": true, "isIpa": true]
            if let d = try? JSONSerialization.data(withJSONObject: payload), let js = String(data: d, encoding: .utf8) {
                dispatchToReact(channel: "update-progress", payloadJson: js)
            }
            DispatchQueue.main.async {
                self.presentIpaShareSheet(dest)
            }
        } catch {
            let payload: [String: Any] = ["percent": 0, "label": "Save failed", "error": error.localizedDescription]
            if let d = try? JSONSerialization.data(withJSONObject: payload), let js = String(data: d, encoding: .utf8) {
                dispatchToReact(channel: "update-progress", payloadJson: js)
            }
        }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if let err = error as NSError?, err.code != NSURLErrorCancelled {
            let payload: [String: Any] = ["percent": 0, "label": "Download failed", "error": err.localizedDescription]
            if let d = try? JSONSerialization.data(withJSONObject: payload), let js = String(data: d, encoding: .utf8) {
                dispatchToReact(channel: "update-progress", payloadJson: js)
            }
        }
    }


    private func stopPreprobe() {
        preprobeTimer?.invalidate()
        preprobeTimer = nil
        preprobeQueue.removeAll()
        preprobeWebView?.stopLoading()
        preprobeWebView?.removeFromSuperview()
        preprobeWebView = nil
    }

    private func startBackgroundPreprobe(_ obj: [String: Any]) {
        let pk = obj["progressKey"] as? String ?? ""
        if pk.isEmpty { return }
        if let cached = UserDefaults.standard.dictionary(forKey: "preprobe_\(pk)"),
           let ts = cached["ts"] as? TimeInterval,
           Date().timeIntervalSince1970 - ts < 900 {
            return
        }
        stopPreprobe()
        preprobeProgressKey = pk
        preprobeMeta = obj
        preprobeQueue = []
        let config = WKWebViewConfiguration()
        config.websiteDataStore = WKWebsiteDataStore.default()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        let ucc = WKUserContentController()
        ucc.add(self, name: "PreprobeSniffer")
        let js = """
        (function(){
          function post(k, u) {
            try { window.webkit.messageHandlers.PreprobeSniffer.postMessage({ kind: k, url: u || location.href, ref: location.href }); } catch(e) {}
          }
          function check(u) {
            if (!u || typeof u !== 'string') return;
            if (u.indexOf('blob:') === 0 || u.indexOf('data:') === 0) return;
            try { u = new URL(u, location.href).href; } catch(e) {}
            if (u.indexOf('http') !== 0) return;
            var l = u.toLowerCase();
            if (l.indexOf('.ts') !== -1 && l.indexOf('.m3u8') === -1) return;
            if (l.indexOf('.m3u8') !== -1 || l.indexOf('.mpd') !== -1 || l.indexOf('/hls/') !== -1 || (l.indexOf('.mp4') !== -1 && l.indexOf('preview') === -1 && l.indexOf('trailer') === -1)) {
              post('stream', u);
            }
          }
          if (window.fetch) {
            var of = window.fetch;
            window.fetch = function(i) { try { check(typeof i === 'string' ? i : (i && i.url)); } catch(e) {} return of.apply(this, arguments); };
          }
          if (window.XMLHttpRequest) {
            var oo = XMLHttpRequest.prototype.open;
            XMLHttpRequest.prototype.open = function(m, u) { try { check(u); } catch(e) {} return oo.apply(this, arguments); };
          }
          setInterval(function(){
            try {
              var vids = document.querySelectorAll('video, audio');
              for (var i = 0; i < vids.length; i++) { vids[i].muted = true; vids[i].volume = 0; }
              var txt = ((document.title || '') + ' ' + (document.body ? document.body.innerText.slice(0, 400) : '')).toLowerCase();
              if (txt.indexOf('no sources') !== -1 || txt.indexOf('not found') !== -1 || txt.indexOf('try again later') !== -1) { post('dead', location.href); }
              if (txt.indexOf('just a moment') !== -1 || txt.indexOf('verify you are human') !== -1) { post('challenge', location.href); }
            } catch(e) {}
          }, 1200);
        })();
        """
        ucc.addUserScript(WKUserScript(source: js, injectionTime: .atDocumentStart, forMainFrameOnly: false))
        config.userContentController = ucc
        let wv = WKWebView(frame: CGRect(x: 0, y: 0, width: 80, height: 60), configuration: config)
        wv.alpha = 0.01
        wv.isUserInteractionEnabled = false
        view.insertSubview(wv, at: 0)
        preprobeWebView = wv
        advancePreprobe()
    }

    private func advancePreprobe() {
        preprobeTimer?.invalidate()
        guard let wv = preprobeWebView, !preprobeQueue.isEmpty else {
            stopPreprobe()
            return
        }
        let src = preprobeQueue.removeFirst()
        preprobeCurrentSource = src
        let im = preprobeMeta["imdbId"] as? String ?? ""
        let tm = (preprobeMeta["tmdbId"] as? String ?? "").isEmpty ? im : (preprobeMeta["tmdbId"] as? String ?? "")
        let isTv = (preprobeMeta["mediaType"] as? String ?? "movie").lowercased() == "tv"
        let s = max(1, preprobeMeta["season"] as? Int ?? 1)
        let e = max(1, preprobeMeta["episode"] as? Int ?? 1)
        var embed = ""
        switch src {
        case "hnembed": embed = isTv ? "https://hnembed.cc/embed/tv/\(im.isEmpty ? tm : im)/\(s)/\(e)" : "https://hnembed.cc/embed/movie/\(im.isEmpty ? tm : im)"
        case "vidsrcmeru": embed = isTv ? "https://vidsrcme.ru/embed/tv?imdb=\(im)&season=\(s)&episode=\(e)&autoplay=1" : "https://vidsrcme.ru/embed/movie?imdb=\(im)&autoplay=1"
        case "vidsrcxyz": embed = isTv ? "https://vidsrc.xyz/embed/tv/\(im)/\(s)-\(e)" : "https://vidsrc.xyz/embed/movie/\(im)"
        case "vidsrcnet": embed = isTv ? "https://vidsrc.net/embed/tv/\(im)/\(s)-\(e)?autoplay=1" : "https://vidsrc.net/embed/movie/\(im)?autoplay=1"
        case "vidsrcto": embed = isTv ? "https://vidsrc.to/embed/tv/\(im)/\(s)/\(e)" : "https://vidsrc.to/embed/movie/\(im)"
        case "vidsrc": embed = isTv ? "https://vsembed.su/embed/tv/\(im)/\(s)/\(e)?autoplay=1" : "https://vsembed.su/embed/movie/\(im)?autoplay=1"
        case "vidlink": embed = isTv ? "https://vidlink.pro/tv/\(tm)/\(s)/\(e)?autoplay=true" : "https://vidlink.pro/movie/\(tm)?autoplay=true"
        case "videasy": embed = isTv ? "https://player.videasy.net/tv/\(tm)/\(s)/\(e)" : "https://player.videasy.net/movie/\(tm)"
        case "vidsrccc": embed = isTv ? "https://vidsrc.cc/v2/embed/tv/\(tm)/\(s)/\(e)?autoPlay=true" : "https://vidsrc.cc/v2/embed/movie/\(tm)?autoPlay=true"
        case "vidfast": embed = isTv ? "https://vidfast.pro/tv/\(tm)/\(s)/\(e)?autoPlay=true" : "https://vidfast.pro/movie/\(tm)?autoPlay=true"
        default: embed = isTv ? "https://embed.su/embed/tv/\(tm)/\(s)/\(e)" : "https://embed.su/embed/movie/\(tm)"
        }
        if let u = URL(string: embed) {
            wv.load(URLRequest(url: u))
        }
        preprobeTimer = Timer.scheduledTimer(withTimeInterval: 6.0, repeats: false) { [weak self] _ in
            self?.advancePreprobe()
        }
    }

}
