package com.singularity.tv.webview

import android.graphics.Bitmap
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import com.singularity.tv.subtitle.SubtitleManager
import org.json.JSONObject

class StreambertWebViewClient(
    private val assetLoader: WebViewAssetLoader,
    private val otaDir: java.io.File? = null,
    private val dispatchEventToJs: (String, String) -> Unit
) : WebViewClient() {

    private var lastBlockedEmitMs = 0L
    private var lastM3u8EmitTimeMs = 0L
    private var lastM3u8Url = ""
    private var lastChallengeEmitTimeMs = 0L

    companion object {
        private const val ANTI_BLUE_TAP_CSS =
            "*,*::before,*::after,html,body,a,button,input,select,textarea,div,span,img,svg,video,iframe,[role='button'],[tabindex]{" +
            "-webkit-tap-highlight-color:rgba(0,0,0,0)!important;" +
            "-webkit-tap-highlight-color:transparent!important;" +
            "-webkit-focus-ring-color:rgba(0,0,0,0)!important;" +
            "-webkit-touch-callout:none!important;" +
            "outline:none!important;" +
            "outline-color:transparent!important;" +
            "}" +
            "*:focus,*:focus-visible,*:active{" +
            "-webkit-tap-highlight-color:rgba(0,0,0,0)!important;" +
            "outline:none!important;" +
            "}" +
            "::selection,::-moz-selection{" +
            "background:rgba(229,9,20,0.25)!important;" +
            "color:#ffffff!important;" +
            "}"
    }

    override fun shouldOverrideUrlLoading(
        view: WebView?,
        request: WebResourceRequest?
    ): Boolean {
        val req = request ?: return false
        val host = req.url?.host?.lowercase() ?: return false

        if (req.isForMainFrame && host != "appassets.androidplatform.net") {
            return true
        }
        return false
    }

    override fun shouldInterceptRequest(
        view: WebView?,
        request: WebResourceRequest?
    ): WebResourceResponse? {
        val url = request?.url?.toString() ?: return null

        if (otaDir != null && request.url?.host == "appassets.androidplatform.net") {
            val reqPath = request.url.path ?: ""
            if (reqPath.endsWith("/bundle.js")) {
                val f = java.io.File(otaDir, "bundle.js")
                if (f.exists() && f.length() > 1000L) {
                    try {
                        return WebResourceResponse("application/javascript", "UTF-8", java.io.FileInputStream(f))
                    } catch (_: Throwable) {}
                }
            } else if (reqPath.endsWith("/global.css")) {
                val f = java.io.File(otaDir, "global.css")
                if (f.exists() && f.length() > 100L) {
                    try {
                        return WebResourceResponse("text/css", "UTF-8", java.io.FileInputStream(f))
                    } catch (_: Throwable) {}
                }
            }
        }
        val assetResponse = assetLoader.shouldInterceptRequest(request.url)
        if (assetResponse != null) {
            return assetResponse
        }

        val lower = url.lowercase()
        val isChallenge = lower.contains("challenges.cloudflare.com") || lower.contains("recaptcha/api") || lower.contains("hcaptcha.com/1/api") || lower.contains("turnstile/v0/api") || lower.contains("arkoselabs.com")
        if (isChallenge) {
            val now = System.currentTimeMillis()
            if (now - lastChallengeEmitTimeMs > 1500L) {
                lastChallengeEmitTimeMs = now
                dispatchEventToJs("server-challenge-detected", JSONObject.quote(url))
            }
        }
        val isVideoStream = lower.contains(".m3u8") || lower.contains(".mpd") || lower.contains("master.txt") || lower.contains("playlist.txt") || (lower.contains(".mp4") && !lower.contains("favicon") && !lower.contains("preview") && !lower.contains("trailer") && !lower.contains("logo"))
        if (isVideoStream) {
            val headers = request.requestHeaders ?: emptyMap()
            AdBlockerInterceptor.streamHeadersMap[url] = headers
            val now = System.currentTimeMillis()
            if (url != lastM3u8Url || now - lastM3u8EmitTimeMs > 2500L) {
                lastM3u8Url = url
                lastM3u8EmitTimeMs = now
                dispatchEventToJs("m3u8-found", JSONObject.quote(url))
            }
        } else if (lower.contains(".vtt") || lower.contains(".srt")) {
            val lang = SubtitleManager.extractSubtitleLang(url)
            val payload = JSONObject().apply {
                put("url", url)
                put("lang", lang)
            }
            dispatchEventToJs("subtitle-found", payload.toString())
        } else if (AdBlockerInterceptor.isBlockedUrl(url)) {
            AdBlockerInterceptor.recordBlocked(url) { domain, delta ->
                val now = System.currentTimeMillis()
                if (now - lastBlockedEmitMs >= 2000L) {
                    lastBlockedEmitMs = now
                    val payload = JSONObject().apply {
                        put("total", delta)
                        put("domains", JSONObject().apply { put(domain, delta) })
                    }
                    dispatchEventToJs("blocked-stats-update", payload.toString())
                }
            }
            return AdBlockerInterceptor.createEmptyResponse()
        }

        return super.shouldInterceptRequest(view, request)
    }

    private fun injectAntiBlueHighlight(view: WebView?, url: String?) {
        if (view == null) return
        val extraCss = if (url != null) AdBlockerInterceptor.getSiteTweakCss(url) ?: "" else ""
        val combined = JSONObject.quote(ANTI_BLUE_TAP_CSS + extraCss)
        view.evaluateJavascript(
            "(function(){try{var id='__singularity_no_tap_blue';var s=document.getElementById(id);if(!s){s=document.createElement('style');s.id=id;(document.head||document.documentElement).appendChild(s);}s.textContent=$combined;}catch(e){}})();",
            null
        )
    }

    override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
        super.onPageStarted(view, url, favicon)
        injectAntiBlueHighlight(view, url)
    }

    override fun onPageFinished(view: WebView?, url: String?) {
        super.onPageFinished(view, url)
        injectAntiBlueHighlight(view, url)
        if (view != null && url != null && !url.startsWith("about:") && !url.contains("appassets.androidplatform.net")) {
            view.evaluateJavascript(
                "(function(){try{var t=(document.title||'')+' '+(document.body?document.body.innerText.slice(0,400):'');var l=t.toLowerCase();if(l.indexOf('just a moment')!==-1||l.indexOf('verify you are human')!==-1||l.indexOf('attention required')!==-1||l.indexOf('404 not found')!==-1||l.indexOf('502 bad gateway')!==-1||l.indexOf('503 service')!==-1){return 'CHALLENGE';}}catch(e){}return '';})()"
            ) { res ->
                if (res != null && res.contains("CHALLENGE")) {
                    val now = System.currentTimeMillis()
                    if (now - lastChallengeEmitTimeMs > 1500L) {
                        lastChallengeEmitTimeMs = now
                        dispatchEventToJs("server-challenge-detected", JSONObject.quote(url))
                    }
                }
            }
        }
    }
}
