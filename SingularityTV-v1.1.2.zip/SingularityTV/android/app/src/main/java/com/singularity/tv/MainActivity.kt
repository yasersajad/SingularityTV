package com.singularity.tv

import android.annotation.SuppressLint
import android.app.PictureInPictureParams
import android.graphics.Color
import android.content.Context
import android.content.res.Configuration
import android.os.Build
import java.util.Locale
import android.content.Intent
import android.os.Bundle
import android.os.SystemClock
import android.util.Rational
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.widget.FrameLayout
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.webkit.WebViewAssetLoader
import com.singularity.tv.bridge.StreambertJsBridge
import com.singularity.tv.download.DownloadEventBus
import com.singularity.tv.player.ExoProgressBus
import com.singularity.tv.webview.StreambertWebViewClient
import org.json.JSONObject

open class MainActivity : AppCompatActivity() {

    lateinit var webView: WebView
    private var customFullscreenView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var isPlayingMedia: Boolean = false
    open val forceTvMode: Boolean = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun attachBaseContext(newBase: Context) {
        Locale.setDefault(Locale.US)
        val cfg = Configuration(newBase.resources.configuration)
        cfg.setLocale(Locale.US)
        cfg.setLayoutDirection(Locale.US)
        super.attachBaseContext(newBase.createConfigurationContext(cfg))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        Locale.setDefault(Locale.US)
        super.onCreate(savedInstanceState)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_LTR
        applySystemBarsVisibility(immersivePlayback = false)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            window.decorView.defaultFocusHighlightEnabled = false
        }

        val rootContainer = FrameLayout(this).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#0A0A0A"))
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                defaultFocusHighlightEnabled = false
            }
        }

        webView = WebView(this).apply {
            layoutParams = FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
            setBackgroundColor(Color.parseColor("#0A0A0A"))
            overScrollMode = View.OVER_SCROLL_NEVER
            isVerticalScrollBarEnabled = false
            isHorizontalScrollBarEnabled = false
            isLongClickable = false
            isHapticFeedbackEnabled = false
            setOnLongClickListener { true }
            isFocusable = true
            isFocusableInTouchMode = true
            setLayerType(View.LAYER_TYPE_HARDWARE, null)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                defaultFocusHighlightEnabled = false
            }
        }
        rootContainer.addView(webView)

        val assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = true
            allowContentAccess = true
            mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
            setSupportMultipleWindows(false)
            javaScriptCanOpenWindowsAutomatically = false
            userAgentString = userAgentString.replace(Regex(";\\s*wv\\)"), ")")
        }

        CookieManager.getInstance().apply {
            setAcceptCookie(true)
            setAcceptThirdPartyCookies(webView, true)
        }

        val jsBridge = StreambertJsBridge(this) { channel, payloadJson ->
            dispatchToReact(channel, payloadJson)
        }
        webView.addJavascriptInterface(jsBridge, "AndroidBridge")

        val otaDir = java.io.File(filesDir, "ota")
        try {
            val otaPrefs = getSharedPreferences("singularity_ota", Context.MODE_PRIVATE)
            val curStamp = packageManager.getPackageInfo(packageName, 0).lastUpdateTime.toString()
            val prevStamp = otaPrefs.getString("ota_install_stamp", "") ?: ""
            if (prevStamp != curStamp) {
                if (otaDir.exists()) otaDir.deleteRecursively()
                otaPrefs.edit().putString("ota_install_stamp", curStamp).remove("ota_version").apply()
            }
        } catch (_: Throwable) {}
        webView.webViewClient = StreambertWebViewClient(assetLoader, otaDir) { channel, payloadJson ->
            dispatchToReact(channel, payloadJson)
        }
        webView.webChromeClient = object : WebChromeClient() {
            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (customFullscreenView != null) {
                    callback?.onCustomViewHidden()
                    return
                }
                customFullscreenView = view
                customViewCallback = callback
                applySystemBarsVisibility(immersivePlayback = true)
                if (view != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        view.defaultFocusHighlightEnabled = false
                    }
                    rootContainer.addView(
                        view,
                        FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                    )
                    webView.visibility = View.GONE
                }
            }

            override fun onHideCustomView() {
                val v = customFullscreenView ?: return
                rootContainer.removeView(v)
                customFullscreenView = null
                customViewCallback?.onCustomViewHidden()
                customViewCallback = null
                webView.visibility = View.VISIBLE
                applySystemBarsVisibility(immersivePlayback = isPlayingMedia)
            }
        }

        setContentView(rootContainer)

        DownloadEventBus.listener = { entity ->
            dispatchToReact(
                "download-progress",
                StreambertJsBridge.downloadToJson(entity).toString()
            )
        }
        ExoProgressBus.listener = { key, pct, posSec, durSec, watched, playingNow ->
            val payload = JSONObject().apply {
                put("progressKey", key)
                put("percent", pct)
                put("positionSec", posSec)
                put("durationSec", durSec)
                put("watched", watched)
                put("isPlaying", playingNow)
            }
            dispatchToReact("exo-progress", payload.toString())
        }
        ExoProgressBus.subtitleStyleListener = { colorHex, bgMode, fontSizeSp ->
            val payload = JSONObject().apply {
                put("subTextColor", colorHex)
                put("subBgStyle", bgMode)
                put("subFontSizeSp", fontSizeSp.toDouble())
            }
            dispatchToReact("subtitle-style-changed", payload.toString())
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (customFullscreenView != null) {
                    webView.webChromeClient?.onHideCustomView()
                    return
                }
                webView.evaluateJavascript(
                    "(window.__streambertHandleBack && window.__streambertHandleBack()) || false"
                ) { result ->
                    if (result != "true") {
                        isEnabled = false
                        onBackPressedDispatcher.onBackPressed()
                        isEnabled = true
                    }
                }
            }
        })

        try {
            webView.clearCache(false)
        } catch (_: Exception) {}
        webView.loadUrl("https://appassets.androidplatform.net/assets/public/index.html?v=2703")
        checkAndFetchOtaUpdate()
        try {
            val savedSrc = getSharedPreferences("singularity_prefs", Context.MODE_PRIVATE)
                .getString("last_working_source", "") ?: ""
            if (savedSrc.isNotBlank()) {
                webView.postDelayed({
                    dispatchToReact("preferred-source-updated", JSONObject.quote(savedSrc))
                }, 800L)
            }
        } catch (_: Exception) {}
    }


    private fun checkAndFetchOtaUpdate() {
        kotlin.concurrent.thread(start = true) {
            try {
                val base = "https://soufctreejgcpvqftxeb.supabase.co/functions/v1/telegram-gate"
                val conn = java.net.URL("$base?action=ota_manifest").openConnection() as java.net.HttpURLConnection
                conn.connectTimeout = 8000
                conn.readTimeout = 8000
                if (conn.responseCode != 200) return@thread
                val manifestStr = conn.inputStream.bufferedReader().use { it.readText() }
                conn.disconnect()
                val manifest = JSONObject(manifestStr)
                val prefs = getSharedPreferences("singularity_ota", Context.MODE_PRIVATE)
                val remoteOtaVer = manifest.optString("ota_version", "").trim()
                val localOtaVer = prefs.getString("ota_version", "") ?: ""
                if (remoteOtaVer.isEmpty() || remoteOtaVer == localOtaVer) return@thread
                val otaDir = java.io.File(filesDir, "ota")
                if (!otaDir.exists()) otaDir.mkdirs()
                var updatedAny = false
                if (manifest.optBoolean("has_bundle", false)) {
                    val bConn = java.net.URL("$base?action=ota_file&file=bundle.js").openConnection() as java.net.HttpURLConnection
                    bConn.connectTimeout = 15000
                    bConn.readTimeout = 20000
                    if (bConn.responseCode == 200) {
                        val bytes = bConn.inputStream.readBytes()
                        if (bytes.size > 5000) {
                            val tmp = java.io.File(otaDir, "bundle.js.tmp")
                            tmp.writeBytes(bytes)
                            tmp.renameTo(java.io.File(otaDir, "bundle.js"))
                            updatedAny = true
                        }
                    }
                    bConn.disconnect()
                }
                if (manifest.optBoolean("has_css", false)) {
                    val cConn = java.net.URL("$base?action=ota_file&file=global.css").openConnection() as java.net.HttpURLConnection
                    cConn.connectTimeout = 12000
                    cConn.readTimeout = 15000
                    if (cConn.responseCode == 200) {
                        val bytes = cConn.inputStream.readBytes()
                        if (bytes.size > 100) {
                            val tmp = java.io.File(otaDir, "global.css.tmp")
                            tmp.writeBytes(bytes)
                            tmp.renameTo(java.io.File(otaDir, "global.css"))
                            updatedAny = true
                        }
                    }
                    cConn.disconnect()
                }
                if (updatedAny) {
                    prefs.edit().putString("ota_version", remoteOtaVer).apply()
                    runOnUiThread {
                        if (!isDestroyed && !isPlayingMedia && ::webView.isInitialized) {
                            try { webView.reload() } catch (_: Throwable) {}
                        }
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    fun setPlaybackImmersive(active: Boolean) {
        isPlayingMedia = active
        runOnUiThread {
            if (active) {
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            } else {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
            applySystemBarsVisibility(immersivePlayback = active || customFullscreenView != null)
        }
    }

    private fun applySystemBarsVisibility(immersivePlayback: Boolean) {
        try {
            WindowCompat.setDecorFitsSystemWindows(window, false)
            val controller = WindowInsetsControllerCompat(window, window.decorView)
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            if (immersivePlayback) {
                controller.hide(WindowInsetsCompat.Type.systemBars())
            } else {
                controller.hide(WindowInsetsCompat.Type.statusBars())
            }
        } catch (_: Exception) {}
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            applySystemBarsVisibility(immersivePlayback = isPlayingMedia || customFullscreenView != null)
        }
    }

    override fun onPause() {
        super.onPause()
        try {
            webView.evaluateJavascript(
                "(function(){try{document.querySelectorAll('video,audio').forEach(function(m){m.pause();});}catch(e){}})();",
                null
            )
            if (!com.singularity.tv.player.NativeExoPlayerActivity.isPlayerActive) {
                webView.onPause()
            }
        } catch (_: Exception) {}
    }


    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val dataUri = intent.data
        if (dataUri != null && dataUri.scheme == "singularitytv") {
            dispatchToReact("google-oauth-callback", JSONObject.quote(dataUri.toString()))
        }
    }

    override fun onResume() {
        super.onResume()
        try {
            com.singularity.tv.player.NativeExoPlayerActivity.forceCloseIfOpen()
        } catch (_: Throwable) {}
        try {
            webView.onResume()
        } catch (_: Exception) {}
    }

    fun dispatchToReact(channel: String, payloadJson: String) {
        runOnUiThread {
            if (!isDestroyed && ::webView.isInitialized) {
                val safeChannel = JSONObject.quote(channel)
                webView.evaluateJavascript(
                    "window.__streambertDispatch && window.__streambertDispatch($safeChannel, $payloadJson);",
                    null
                )
            }
        }
    }

    fun enterAppPipMode() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val params = PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
                enterPictureInPictureMode(params)
            } catch (_: Exception) {}
        }
    }

    fun simulateTap(xRatio: Float, yRatio: Float) {
        runOnUiThread {
            if (isDestroyed || !::webView.isInitialized || webView.width <= 0 || webView.height <= 0) return@runOnUiThread
            val x = (xRatio.coerceIn(0.05f, 0.95f)) * webView.width
            val y = (yRatio.coerceIn(0.05f, 0.95f)) * webView.height
            val downTime = SystemClock.uptimeMillis()
            val downEvent = MotionEvent.obtain(downTime, downTime, MotionEvent.ACTION_DOWN, x, y, 0)
            val upEvent = MotionEvent.obtain(downTime, downTime + 45L, MotionEvent.ACTION_UP, x, y, 0)
            webView.dispatchTouchEvent(downEvent)
            webView.dispatchTouchEvent(upEvent)
            downEvent.recycle()
            upEvent.recycle()
        }
    }

    fun clearWebViewCache() {
        try {
            webView.clearCache(true)
        } catch (_: Exception) {}
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val actionName = when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> "up"
            KeyEvent.KEYCODE_DPAD_DOWN -> "down"
            KeyEvent.KEYCODE_DPAD_LEFT -> "left"
            KeyEvent.KEYCODE_DPAD_RIGHT -> "right"
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER, KeyEvent.KEYCODE_BUTTON_A -> "select"
            KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_SEARCH -> "menu"
            KeyEvent.KEYCODE_PAGE_UP, KeyEvent.KEYCODE_CHANNEL_UP -> "page_up"
            KeyEvent.KEYCODE_PAGE_DOWN, KeyEvent.KEYCODE_CHANNEL_DOWN -> "page_down"
            else -> null
        }
        if (actionName != null) {
            val imm = getSystemService(INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager
            if (imm?.isAcceptingText == true) {
                return super.dispatchKeyEvent(event)
            }
            if (event.action == KeyEvent.ACTION_DOWN) {
                webView.evaluateJavascript(
                    "window.dispatchEvent(new CustomEvent('streambert:dpad', { detail: { action: '$actionName' } }));",
                    null
                )
                return true
            }
            if (event.action == KeyEvent.ACTION_UP) {
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onDestroy() {
        DownloadEventBus.listener = null
        ExoProgressBus.listener = null
        try {
            webView.destroy()
        } catch (_: Exception) {}
        super.onDestroy()
    }
}
