package com.singularity.tv.webview

import android.net.Uri
import android.webkit.WebResourceResponse
import com.singularity.tv.StreambertApp
import com.singularity.tv.data.BlockedDomainEntity
import java.io.ByteArrayInputStream
import java.util.concurrent.ConcurrentHashMap

object AdBlockerInterceptor {

    private val BLOCKED_HOST_SUFFIXES = listOf(
        "google-analytics.com",
        "googletagmanager.com",
        "googletagservices.com",
        "doubleclick.net",
        "adservice.google.com",
        "adservice.google.de",
        "pagead2.googlesyndication.com",
        "cdn.adx1.com",
        "intelligenceadx.com",
        "adsco.re",
        "mc.yandex.com",
        "mc.yandex.ru",
        "bvtpk.com",
        "my.rtmark.net",
        "b7510.com",
        "gt.unbrownunflat.com",
        "im.malocacomals.com",
        "nf.sixmossin.com",
        "realizationnewestfangs.com",
        "acscdn.com",
        "lt.taloseempest.com",
        "pl26708123.profitableratecpm.com",
        "preferencenail.com",
        "protrafficinspector.com",
        "s10.histats.com",
        "weirdopt.com",
        "cloudflareinsights.com",
        "kettledroopingcontinuation.com",
        "wayfarerorthodox.com",
        "woxaglasuy.net",
        "adeptspiritual.com",
        "calculating-laugh.com",
        "amavhxdlofklxjg.xyz",
        "usrpubtrk.com",
        "adexchangeclear.com",
        "rzjzjnavztycv.online",
        "hameltnoummos.com",
        "ancillammmm.com",
        "hubeamily.com",
        "llvpn.com",
        "gillyspencie.com",
        "soakysecrets.com",
        "mdstats.info",
        "ads-twitter.com",
        "connatix.com",
        "imasdk.googleapis.com",
        "jwpltx.com",
        "openfpcdn.io",
        "phruk.org",
        "welcomingexpulsion.com",
        "pgo99.com",
        "todditehexarch.com",
        "uniolaicecaps.com",
        "alloha.tv",
        "pc.alloviewroll.com",
        "yadro.ru",
        "getaim.org",
        "myangular.life",
        "rstprgapipt.com",
        "veselchaga.link",
        "webvisor.org",
        "datariaarpent.com",
        "gamesrevenue.com",
        "shankedunwindy.cyou",
        "asemquips.cfd",
        "epicgameshubham.com",
        "tantrajoni.cfd",
        "thatdisform.cyou",
        "vdrk.site",
        "aarems.org",
        "aerionvel.com",
        "cdn4ads.com",
        "directyp.org",
        "fakerstoterframing.qpon",
        "karthliunstagy.com",
        "nresystems.com",
        "sainwertapr.com",
        "pxltag.com",
        "runative-syndicate.com",
        "saidairakas.com",
        "coiffesreal.qpon",
        "solarcyclonesky.com",
        "bawrelcuttail.com",
        "tabaxirethnize.cyou",
        "thyriswh.cyou",
        "ukankingwithea.com",
        "uuidksinc.net",
        "blockadsnot.com",
        "canseealltheugline.org",
        "eifitcannotke.org",
        "embercascademaple.com",
        "bancadeltempoidea.org",
        "tryedesign.com",
        "aelwynvel.com",
        "cometslourdy.cfd",
        "pusleybrand.cyou",
        "luugy.com",
        "nimbusgrovelodge.com",
        "brushetenglandagacant.qpon",
        "hyaloidsatury.com",
        "stummelbeelbow.com",
        "mgid.com",
        "deedwaifpleas.org",
        "pushaffiliate.net",
        "imp-mintads.site",
        "oceanicdreamcove.com",
        "xadsmart.com",
        "srvqk3.com",
        "popads.net",
        "popcash.net",
        "exoclick.com",
        "exosrv.com",
        "magsrv.com",
        "juicyads.com",
        "juicyads.net",
        "trafficjunky.com",
        "trafficjunky.net",
        "propellerads.com",
        "monetag.com",
        "adsterra.com",
        "highperformanceformat.com",
        "effectivegatecpm.com",
        "onclickalgo.com",
        "realsrv.com",
        "hilltopads.net",
        "admaven.com",
        "ad-maven.com",
        "clickadu.com",
        "galaksion.com",
        "onclkds.com",
        "betteradsystem.com",
        "a-ads.com",
        "bidvertiser.com",
        "richpush.co",
        "ero-advertising.com",
        "chaturbate.com",
        "stripchat.com",
        "bongacams.com",
        "livejasmin.com",
        "cam4.com",
        "profitablecpmrate.com",
        "highrevenuegate.com",
        "adskeeper.com",
        "outbrain.com",
        "taboola.com",
        "2mdn.net",
        "cysyjucymudity.com",
        "pncloudfl.com",
        "cruzswim.org",
        "darnobedienceupscale.com",
        "derricknationtop.com",
        "tsyndicate.com",
        "rapidadexchange.com",
        "cepesbritons.qpon",
        "sarplerlacunes.qpon",
        "usrpubtrck.com",
        "ixiondartman.com",
        "varnishtala.cyou"
    )

    val streamHeadersMap = ConcurrentHashMap<String, Map<String, String>>()

    fun isBlockedUrl(url: String): Boolean {
        val host = try {
            Uri.parse(url).host?.lowercase()?.removePrefix("www.") ?: return false
        } catch (_: Exception) {
            return false
        }
        return BLOCKED_HOST_SUFFIXES.any { suffix ->
            host == suffix || host.endsWith(".$suffix")
        }
    }

    fun recordBlocked(url: String, onBatchEmit: ((String, Long) -> Unit)? = null) {
        val domain = try {
            Uri.parse(url).host?.lowercase()?.removePrefix("www.") ?: return
        } catch (_: Exception) {
            return
        }
        try {
            val dao = StreambertApp.instance.database.blockedDomainDao()
            val existing = dao.getAllSync().find { it.domain == domain }
            val nextCount = (existing?.count ?: 0L) + 1L
            dao.upsertSync(BlockedDomainEntity(domain, nextCount))
            onBatchEmit?.invoke(domain, 1L)
        } catch (_: Exception) {}
    }

    fun createEmptyResponse(): WebResourceResponse {
        return WebResourceResponse(
            "text/plain",
            "utf-8",
            204,
            "No Content",
            mapOf("Access-Control-Allow-Origin" to "*"),
            ByteArrayInputStream(ByteArray(0))
        )
    }

    fun getSiteTweakCss(url: String): String? {
        val host = try {
            Uri.parse(url).host?.lowercase() ?: return null
        } catch (_: Exception) {
            return null
        }
        return when {
            host == "on.kinohub.vip" || host.endsWith(".on.kinohub.vip") ->
                "html, body { overflow: hidden !important; background: #000 !important; } body * { visibility: hidden !important; } section.player_section, section.player_section * { visibility: visible !important; } section.player_section { position: fixed !important; inset: 0 !important; width: 100vw !important; height: 100vh !important; max-width: none !important; margin: 0 !important; z-index: 2147483647 !important; background: #000 !important; }"
            host == "aether.ist" || host.endsWith(".aether.ist") ->
                "div:has(> .top-content), .top-content, .tabbable { display: none !important; }"
            host == "vidnest.fun" || host.endsWith(".vidnest.fun") ->
                ".popup-selector, #overlay-id { display: none !important; }"
            host == "frembed.uno" || host.endsWith(".frembed.uno") ->
                ".popup-selector { display: none !important; }"
            else -> null
        }
    }
}
