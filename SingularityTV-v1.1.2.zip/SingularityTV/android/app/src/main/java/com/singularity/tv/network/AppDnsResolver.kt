package com.singularity.tv.network

import android.net.VpnService
import okhttp3.Dns
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import javax.net.SocketFactory

object AppDnsResolver : Dns {

    private val dohEndpoints = listOf(
        "https://khoindvn.io.vn/dns-query",
        "https://1.1.1.1/dns-query",
        "https://8.8.8.8/dns-query"
    )

    private val bootstrapIps = mapOf(
        "khoindvn.io.vn" to listOf("104.21.48.1", "172.67.162.1"),
        "1.1.1.1" to listOf("1.1.1.1"),
        "1.0.0.1" to listOf("1.0.0.1"),
        "8.8.8.8" to listOf("8.8.8.8"),
        "8.8.4.4" to listOf("8.8.4.4")
    )

    private val cache = ConcurrentHashMap<String, Pair<Long, List<InetAddress>>>()
    private val dnsMsgMediaType = "application/dns-message".toMediaType()

    private fun createDohClient(vpnService: VpnService?): OkHttpClient {
        val builder = OkHttpClient.Builder()
            .connectTimeout(4, TimeUnit.SECONDS)
            .readTimeout(5, TimeUnit.SECONDS)
            .dns(object : Dns {
                override fun lookup(hostname: String): List<InetAddress> {
                    return bootstrapIps[hostname]?.mapNotNull {
                        try { InetAddress.getByName(it) } catch (_: Exception) { null }
                    }?.takeIf { it.isNotEmpty() } ?: Dns.SYSTEM.lookup(hostname)
                }
            })
        if (vpnService != null) {
            builder.socketFactory(object : SocketFactory() {
                private val def = getDefault()
                override fun createSocket(): Socket = def.createSocket().also { vpnService.protect(it) }
                override fun createSocket(host: String?, port: Int): Socket = def.createSocket(host, port).also { vpnService.protect(it) }
                override fun createSocket(host: String?, port: Int, localHost: InetAddress?, localPort: Int): Socket = def.createSocket(host, port, localHost, localPort).also { vpnService.protect(it) }
                override fun createSocket(host: InetAddress?, port: Int): Socket = def.createSocket(host, port).also { vpnService.protect(it) }
                override fun createSocket(address: InetAddress?, port: Int, localAddress: InetAddress?, localPort: Int): Socket = def.createSocket(address, port, localAddress, localPort).also { vpnService.protect(it) }
            })
        }
        return builder.build()
    }

    private val appDohClient: OkHttpClient by lazy { createDohClient(null) }

    fun resolveWireQuery(queryBytes: ByteArray, vpnService: VpnService? = null): ByteArray? {
        val client = if (vpnService != null) createDohClient(vpnService) else appDohClient
        for (endpoint in dohEndpoints) {
            try {
                val req = Request.Builder()
                    .url(endpoint)
                    .post(queryBytes.toRequestBody(dnsMsgMediaType))
                    .header("Accept", "application/dns-message")
                    .header("Content-Type", "application/dns-message")
                    .build()
                client.newCall(req).execute().use { res ->
                    if (res.isSuccessful) {
                        val bytes = res.body?.bytes()
                        if (bytes != null && bytes.size >= 12) return bytes
                    }
                }
            } catch (_: Exception) {}
        }
        val udpFallbacks = listOf("1.1.1.1", "8.8.8.8")
        for (ip in udpFallbacks) {
            var socket: DatagramSocket? = null
            try {
                socket = DatagramSocket()
                vpnService?.protect(socket)
                socket.soTimeout = 3500
                val addr = InetAddress.getByName(ip)
                socket.send(DatagramPacket(queryBytes, queryBytes.size, addr, 53))
                val buf = ByteArray(4096)
                val resp = DatagramPacket(buf, buf.size)
                socket.receive(resp)
                if (resp.length >= 12) {
                    return buf.copyOf(resp.length)
                }
            } catch (_: Exception) {
            } finally {
                try { socket?.close() } catch (_: Exception) {}
            }
        }
        return null
    }

    private fun buildDnsQuery(hostname: String, qtype: Int): ByteArray {
        val baos = ByteArrayOutputStream()
        val dos = DataOutputStream(baos)
        dos.writeShort(0x1337)
        dos.writeShort(0x0100)
        dos.writeShort(1)
        dos.writeShort(0)
        dos.writeShort(0)
        dos.writeShort(0)
        for (label in hostname.split(".")) {
            val bytes = label.toByteArray(Charsets.UTF_8)
            dos.writeByte(bytes.size)
            dos.write(bytes)
        }
        dos.writeByte(0)
        dos.writeShort(qtype)
        dos.writeShort(1)
        dos.flush()
        return baos.toByteArray()
    }

    private fun skipDnsName(buf: ByteArray, offset: Int): Int {
        var pos = offset
        while (pos < buf.size) {
            val len = buf[pos].toInt() and 0xFF
            if (len == 0) return pos + 1
            if ((len and 0xC0) == 0xC0) return pos + 2
            pos += 1 + len
        }
        return buf.size
    }

    private fun parseARecords(resp: ByteArray): List<InetAddress> {
        if (resp.size < 12) return emptyList()
        val qdCount = ((resp[4].toInt() and 0xFF) shl 8) or (resp[5].toInt() and 0xFF)
        val anCount = ((resp[6].toInt() and 0xFF) shl 8) or (resp[7].toInt() and 0xFF)
        var pos = 12
        for (i in 0 until qdCount) {
            pos = skipDnsName(resp, pos) + 4
        }
        val out = mutableListOf<InetAddress>()
        for (i in 0 until anCount) {
            if (pos >= resp.size) break
            pos = skipDnsName(resp, pos)
            if (pos + 10 > resp.size) break
            val rtype = ((resp[pos].toInt() and 0xFF) shl 8) or (resp[pos + 1].toInt() and 0xFF)
            val rdLen = ((resp[pos + 8].toInt() and 0xFF) shl 8) or (resp[pos + 9].toInt() and 0xFF)
            pos += 10
            if (pos + rdLen > resp.size) break
            if (rtype == 1 && rdLen == 4) {
                try {
                    out.add(InetAddress.getByAddress(resp.copyOfRange(pos, pos + 4)))
                } catch (_: Exception) {}
            } else if (rtype == 28 && rdLen == 16) {
                try {
                    out.add(InetAddress.getByAddress(resp.copyOfRange(pos, pos + 16)))
                } catch (_: Exception) {}
            }
            pos += rdLen
        }
        return out
    }

    override fun lookup(hostname: String): List<InetAddress> {
        val clean = hostname.trim().lowercase()
        bootstrapIps[clean]?.let { ips ->
            val list = ips.mapNotNull { try { InetAddress.getByName(it) } catch (_: Exception) { null } }
            if (list.isNotEmpty()) return list
        }
        val now = System.currentTimeMillis()
        cache[clean]?.let { (ts, list) ->
            if (now - ts < 300_000L && list.isNotEmpty()) return list
        }
        try {
            val query = buildDnsQuery(clean, 1)
            val resp = resolveWireQuery(query, null)
            if (resp != null) {
                val addrs = parseARecords(resp)
                if (addrs.isNotEmpty()) {
                    cache[clean] = now to addrs
                    return addrs
                }
            }
        } catch (_: Exception) {}
        return Dns.SYSTEM.lookup(hostname)
    }
}
