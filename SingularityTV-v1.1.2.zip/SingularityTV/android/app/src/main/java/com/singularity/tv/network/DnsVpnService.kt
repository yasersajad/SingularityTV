package com.singularity.tv.network

import android.app.Notification
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.app.NotificationCompat
import com.singularity.tv.MainActivity
import com.singularity.tv.StreambertApp
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

object DnsVpnStateBus {
    @Volatile
    var listener: ((Boolean) -> Unit)? = null

    fun notifyState(running: Boolean) {
        listener?.invoke(running)
    }
}

class DnsVpnService : VpnService() {

    private var vpnInterface: ParcelFileDescriptor? = null
    private var workerThread: Thread? = null
    private var executor: ExecutorService? = null
    private val writeLock = Any()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action
        if (action == ACTION_STOP) {
            stopVpn()
            return START_NOT_STICKY
        }
        startVpn()
        return START_NOT_STICKY
    }

    override fun onTaskRemoved(rootIntent: Intent?) {
        stopVpn()
        super.onTaskRemoved(rootIntent)
    }

    private fun buildNotification(): Notification {
        val openIntent = Intent(this, MainActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        val piFlags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        } else {
            PendingIntent.FLAG_UPDATE_CURRENT
        }
        val pi = PendingIntent.getActivity(this, 4401, openIntent, piFlags)
        return NotificationCompat.Builder(this, StreambertApp.CHANNEL_EPISODES)
            .setSmallIcon(android.R.drawable.ic_lock_lock)
            .setContentTitle("SingularityTV App DNS")
            .setContentText("App-only Encrypted DNS (1.1.1.1 / 8.8.8.8)")
            .setOngoing(true)
            .setContentIntent(pi)
            .build()
    }

    private fun startVpn() {
        if (isRunning && vpnInterface != null) return
        try {
            startForeground(4401, buildNotification())
        } catch (_: Exception) {}

        try {
            val builder = Builder()
                .setSession("SingularityTV DNS")
                .setMtu(1500)
                .addAddress("10.88.0.1", 32)
                .addDnsServer("1.1.1.1")
                .addDnsServer("1.0.0.1")
                .addDnsServer("8.8.8.8")
                .addDnsServer("8.8.4.4")
                .addRoute("1.1.1.1", 32)
                .addRoute("1.0.0.1", 32)
                .addRoute("8.8.8.8", 32)
                .addRoute("8.8.4.4", 32)

            try {
                builder.addAllowedApplication(packageName)
            } catch (_: Exception) {}

            val pfd = builder.establish() ?: run {
                stopVpn()
                return
            }
            vpnInterface = pfd
            isRunning = true
            DnsVpnStateBus.notifyState(true)

            val pool = Executors.newFixedThreadPool(12)
            executor = pool

            workerThread = Thread({
                val input = FileInputStream(pfd.fileDescriptor)
                val output = FileOutputStream(pfd.fileDescriptor)
                val packet = ByteArray(32767)
                while (isRunning && !Thread.currentThread().isInterrupted) {
                    val len = try {
                        input.read(packet)
                    } catch (_: Exception) {
                        break
                    }
                    if (len <= 0) continue
                    val raw = packet.copyOf(len)
                    if (raw.size < 28) continue
                    val version = (raw[0].toInt() ushr 4) and 0x0F
                    if (version != 4) continue
                    val ihl = (raw[0].toInt() and 0x0F) * 4
                    if (ihl < 20 || raw.size < ihl + 8) continue
                    val proto = raw[9].toInt() and 0xFF
                    if (proto != 17) continue
                    val dstPort = ((raw[ihl + 2].toInt() and 0xFF) shl 8) or (raw[ihl + 3].toInt() and 0xFF)
                    if (dstPort != 53) continue

                    val dnsPayload = raw.copyOfRange(ihl + 8, raw.size)
                    pool.execute {
                        try {
                            val dnsResp = AppDnsResolver.resolveWireQuery(dnsPayload, this@DnsVpnService) ?: return@execute
                            val replyPacket = buildIpv4UdpReply(raw, ihl, dnsResp)
                            synchronized(writeLock) {
                                if (isRunning) {
                                    output.write(replyPacket)
                                }
                            }
                        } catch (_: Exception) {}
                    }
                }
            }, "SingularityDnsVpnLoop").apply { start() }
        } catch (_: Exception) {
            stopVpn()
        }
    }

    private fun buildIpv4UdpReply(req: ByteArray, reqIhl: Int, dnsResp: ByteArray): ByteArray {
        val ipHeaderLen = 20
        val udpLen = 8 + dnsResp.size
        val totalLen = ipHeaderLen + udpLen
        val out = ByteArray(totalLen)

        out[0] = 0x45.toByte()
        out[1] = 0x00
        out[2] = ((totalLen ushr 8) and 0xFF).toByte()
        out[3] = (totalLen and 0xFF).toByte()
        out[4] = req[4]
        out[5] = req[5]
        out[6] = 0x40
        out[7] = 0x00
        out[8] = 64
        out[9] = 17
        out[10] = 0
        out[11] = 0

        System.arraycopy(req, 16, out, 12, 4)
        System.arraycopy(req, 12, out, 16, 4)

        var ipSum = 0
        var i = 0
        while (i < ipHeaderLen) {
            val w = ((out[i].toInt() and 0xFF) shl 8) or (out[i + 1].toInt() and 0xFF)
            ipSum += w
            i += 2
        }
        while ((ipSum ushr 16) != 0) {
            ipSum = (ipSum and 0xFFFF) + (ipSum ushr 16)
        }
        val ipChecksum = ipSum.inv() and 0xFFFF
        out[10] = ((ipChecksum ushr 8) and 0xFF).toByte()
        out[11] = (ipChecksum and 0xFF).toByte()

        out[ipHeaderLen] = req[reqIhl + 2]
        out[ipHeaderLen + 1] = req[reqIhl + 3]
        out[ipHeaderLen + 2] = req[reqIhl]
        out[ipHeaderLen + 3] = req[reqIhl + 1]
        out[ipHeaderLen + 4] = ((udpLen ushr 8) and 0xFF).toByte()
        out[ipHeaderLen + 5] = (udpLen and 0xFF).toByte()
        out[ipHeaderLen + 6] = 0
        out[ipHeaderLen + 7] = 0

        System.arraycopy(dnsResp, 0, out, ipHeaderLen + 8, dnsResp.size)

        var udpSum = 0
        for (j in 12 until 20 step 2) {
            udpSum += ((out[j].toInt() and 0xFF) shl 8) or (out[j + 1].toInt() and 0xFF)
        }
        udpSum += 17
        udpSum += udpLen
        var k = ipHeaderLen
        while (k < totalLen) {
            val hi = out[k].toInt() and 0xFF
            val lo = if (k + 1 < totalLen) (out[k + 1].toInt() and 0xFF) else 0
            udpSum += (hi shl 8) or lo
            k += 2
        }
        while ((udpSum ushr 16) != 0) {
            udpSum = (udpSum and 0xFFFF) + (udpSum ushr 16)
        }
        var finalUdpSum = udpSum.inv() and 0xFFFF
        if (finalUdpSum == 0) finalUdpSum = 0xFFFF
        out[ipHeaderLen + 6] = ((finalUdpSum ushr 8) and 0xFF).toByte()
        out[ipHeaderLen + 7] = (finalUdpSum and 0xFF).toByte()

        return out
    }

    private fun stopVpn() {
        isRunning = false
        AppDnsResolver.clearVpnClient()
        DnsVpnStateBus.notifyState(false)
        try { workerThread?.interrupt() } catch (_: Exception) {}
        workerThread = null
        try { executor?.shutdownNow() } catch (_: Exception) {}
        executor = null
        try { vpnInterface?.close() } catch (_: Exception) {}
        vpnInterface = null
        try { stopForeground(STOP_FOREGROUND_REMOVE) } catch (_: Exception) {}
        stopSelf()
    }

    override fun onRevoke() {
        stopVpn()
        super.onRevoke()
    }

    override fun onDestroy() {
        stopVpn()
        super.onDestroy()
    }

    companion object {
        const val ACTION_START = "com.singularity.tv.action.START_DNS_VPN"
        const val ACTION_STOP = "com.singularity.tv.action.STOP_DNS_VPN"

        @Volatile
        var isRunning: Boolean = false
            private set

        fun start(context: Context) {
            val intent = Intent(context, DnsVpnService::class.java).apply {
                action = ACTION_START
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            if (!isRunning) return
            val intent = Intent(context, DnsVpnService::class.java).apply {
                action = ACTION_STOP
            }
            try {
                context.startService(intent)
            } catch (_: Exception) {}
        }
    }
}
