import React, { useState, useEffect } from "react";
import { getAuthUser } from "../utils/supabaseSync";
import {
  SingularityTVLogo,
  SearchIcon,
  HomeIcon,
  HistoryIcon,
  SettingsIcon,
  DownloadsQueueIcon
} from "./Icons";

function LiveTvIcon() {
  return (
    <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <rect x="2" y="7" width="20" height="15" rx="2" ry="2" />
      <polyline points="17 2 12 7 7 2" />
    </svg>
  );
}

export default function TopNav({
  page,
  onNavigate,
  onSearch,
  activeDownloads
}) {
  const [timeStr, setTimeStr] = useState(() =>
    new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })
  );
  const [authUser, setAuthUser] = useState(() => getAuthUser());
  useEffect(() => {
    const onAcc = () => setAuthUser(getAuthUser());
    window.addEventListener("singularity:auth-changed", onAcc);
    return () => window.removeEventListener("singularity:auth-changed", onAcc);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeStr(new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }));
    }, 30000);
    return () => clearInterval(timer);
  }, []);

  const navItems = [
    { id: "home", label: "Home", icon: <HomeIcon /> },
    { id: "live", label: "Live TV", icon: <LiveTvIcon /> },
    { id: "history", label: "Library", icon: <HistoryIcon /> },
    {
      id: "downloads",
      label: "Downloads",
      icon: <DownloadsQueueIcon />,
      badge: activeDownloads > 0 ? activeDownloads : null
    }
  ];

  return (
    <header className="topnav">
      <div className="topnav-left">
        <button
          className="topnav-brand topnav-btn"
          onClick={() => onNavigate("home")}
          aria-label="SingularityTV Home"
        >
          <SingularityTVLogo style={{ width: 26, height: 26 }} />
        </button>

        <button className="topnav-search-btn topnav-btn" onClick={onSearch}>
          <SearchIcon />
          <span>Search</span>
        </button>

        <nav className="topnav-links" aria-label="Primary Navigation">
          {navItems.map(item => (
            <button
              key={item.id}
              className={`topnav-link topnav-btn${page === item.id ? " active" : ""}`}
              onClick={() => onNavigate(item.id)}
            >
              <span className="topnav-link-icon">{item.icon}</span>
              <span>{item.label}</span>
              {item.badge && <span className="topnav-badge">{item.badge}</span>}
            </button>
          ))}
        </nav>
      </div>

      <div className="topnav-right">
        <button
          className="topnav-link topnav-btn"
          onClick={() => onNavigate("settings", { section: "account" })}
          title={authUser ? `Signed in as ${authUser.email}` : "Account"}
          style={{ padding: "5px 11px", gap: 7 }}
        >
          <span
            style={{
              width: 22,
              height: 22,
              borderRadius: "50%",
              background: authUser ? "var(--red)" : "rgba(255,255,255,0.14)",
              color: "#fff",
              fontSize: 11,
              fontWeight: 800,
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center"
            }}
          >
            {authUser ? (authUser.name || authUser.email || "U").charAt(0).toUpperCase() : "U"}
          </span>
          <span style={{ fontSize: 12, maxWidth: 96, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
            {authUser ? authUser.name : "Account"}
          </span>
        </button>
        <button
          className={`topnav-icon-btn topnav-btn${page === "settings" ? " active" : ""}`}
          onClick={() => onNavigate("settings")}
          aria-label="Settings"
        >
          <SettingsIcon />
        </button>
        <div className="topnav-clock">{timeStr}</div>
      </div>
    </header>
  );
}
