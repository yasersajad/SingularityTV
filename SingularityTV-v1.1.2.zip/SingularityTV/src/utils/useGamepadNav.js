import { useEffect, useRef, useState } from "react";
import { BTN, useGamepadLoop } from "./gamepad";
import { moveGamepadFocus, handleGamepadPageScroll, confirmGamepadFocus, dismissActiveOverlay, ensureInitialFocus, clearGamepadFocus } from "./gamepadSpatialNav";
import { isPlayerGamepadActive } from "./gamepadPlayerState";
import { isAndroidTvDevice } from "./androidBridge";
export function useGamepadNav({
  enabled,
  onBack,
  onOpenSearch
}) {
  const [connected, setConnected] = useState(false);
  const lastNavTimeRef = useRef(0);
  const onBackRef = useRef(onBack);
  onBackRef.current = onBack;
  const onOpenSearchRef = useRef(onOpenSearch);
  onOpenSearchRef.current = onOpenSearch;
  const runGuarded = fn => {
    const now = performance.now();
    if (now - lastNavTimeRef.current < 105) return;
    lastNavTimeRef.current = now;
    fn();
  };
  useGamepadLoop({
    onConnectionChange: setConnected,
    onDirection: dir => {
      runGuarded(() => {
        ensureInitialFocus();
        moveGamepadFocus(dir);
      });
    },
    onButtonDown: i => {
      runGuarded(() => {
        if (i === BTN.A) {
          ensureInitialFocus();
          confirmGamepadFocus();
        } else if (i === BTN.B) {
          if (!dismissActiveOverlay()) onBackRef.current?.();
        } else if (i === BTN.START) {
          onOpenSearchRef.current?.();
        }
      });
    }
  }, () => !isPlayerGamepadActive(), enabled);
  useEffect(() => {
    if (!enabled) return;
    if (isAndroidTvDevice()) {
      setTimeout(() => ensureInitialFocus(), 180);
    }
    const handleKeyDown = e => {
      if (e.key === "CapsLock" || e.key === "Shift" || e.key === "Control" || e.key === "Alt" || e.key === "Meta" || e.key === "Pause" || e.key === "Dead" || e.key === "Unidentified") return;
      const active = document.activeElement;
      const tag = (active?.tagName || "").toUpperCase();
      const isTextInput = tag === "INPUT" || tag === "TEXTAREA" || active?.isContentEditable;
      const allowTvKeyCodes = isAndroidTvDevice() && !isTextInput;
      const isUp = e.key === "ArrowUp" || (allowTvKeyCodes && e.keyCode === 19);
      const isDown = e.key === "ArrowDown" || (allowTvKeyCodes && e.keyCode === 20);
      const isLeft = e.key === "ArrowLeft" || (allowTvKeyCodes && e.keyCode === 21);
      const isRight = e.key === "ArrowRight" || (allowTvKeyCodes && e.keyCode === 22);
      const isPgUp = e.key === "PageUp" || (allowTvKeyCodes && e.keyCode === 33);
      const isPgDn = e.key === "PageDown" || (allowTvKeyCodes && e.keyCode === 34);
      const isDirectionKey = isUp || isDown || isLeft || isRight || isPgUp || isPgDn;
      if (e.repeat && !isDirectionKey) return;
      if (isTextInput && (isUp || isDown || isLeft || isRight || isPgUp || isPgDn)) return;
      if (isPgUp) {
        e.preventDefault();
        runGuarded(() => {
          ensureInitialFocus();
          handleGamepadPageScroll("up");
        });
        return;
      }
      if (isPgDn) {
        e.preventDefault();
        runGuarded(() => {
          ensureInitialFocus();
          handleGamepadPageScroll("down");
        });
        return;
      }
      if (isUp) {
        e.preventDefault();
        runGuarded(() => {
          ensureInitialFocus();
          moveGamepadFocus("up");
        });
        return;
      }
      if (isDown) {
        e.preventDefault();
        runGuarded(() => {
          ensureInitialFocus();
          moveGamepadFocus("down");
        });
        return;
      }
      if (isLeft) {
        e.preventDefault();
        runGuarded(() => {
          ensureInitialFocus();
          moveGamepadFocus("left");
        });
        return;
      }
      if (isRight) {
        e.preventDefault();
        runGuarded(() => {
          ensureInitialFocus();
          moveGamepadFocus("right");
        });
        return;
      }
      if (e.key === "Enter" || e.key === " " || e.keyCode === 23 || e.keyCode === 66) {
        if (isTextInput && e.key !== "Enter") return;
        if (isTextInput && tag === "INPUT") return;
        e.preventDefault();
        runGuarded(() => {
          ensureInitialFocus();
          confirmGamepadFocus();
        });
        return;
      }
      if (e.key === "Escape" || e.key === "GoBack" || e.key === "BrowserBack" || e.keyCode === 4 || !isTextInput && e.key === "Backspace") {
        e.preventDefault();
        runGuarded(() => {
          if (!dismissActiveOverlay()) {
            onBackRef.current?.();
          }
        });
        return;
      }
      if (isTextInput) return;
      if (e.key === "ContextMenu" || e.key === "F2") {
        e.preventDefault();
        runGuarded(() => {
          onOpenSearchRef.current?.();
        });
      }
    };
    const handleNativeDpad = ev => {
      const action = ev.detail?.action;
      if (!action) return;
      const active = document.activeElement;
      const tag = (active?.tagName || "").toUpperCase();
      const isTextInput = tag === "INPUT" || tag === "TEXTAREA" || active?.isContentEditable;
      if (isTextInput && (action === "left" || action === "right")) return;
      runGuarded(() => {
        if (action === "page_up") {
          ensureInitialFocus();
          handleGamepadPageScroll("up");
        } else if (action === "page_down") {
          ensureInitialFocus();
          handleGamepadPageScroll("down");
        } else if (["up", "down", "left", "right"].includes(action)) {
          if (isTextInput) {
            try { active.blur(); } catch {}
          }
          ensureInitialFocus();
          moveGamepadFocus(action);
        } else if (action === "select" || action === "center") {
          if (isTextInput && tag === "INPUT") {
            try { active.click(); } catch {}
            return;
          }
          ensureInitialFocus();
          confirmGamepadFocus();
        } else if (action === "back") {
          if (isTextInput) {
            try { active.blur(); } catch {}
            return;
          }
          if (!dismissActiveOverlay()) onBackRef.current?.();
        } else if (action === "menu") {
          onOpenSearchRef.current?.();
        }
      });
    };
    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("streambert:dpad", handleNativeDpad);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("streambert:dpad", handleNativeDpad);
    };
  }, [enabled]);
  useEffect(() => {
    if (!enabled) {
      clearGamepadFocus();
      setConnected(false);
    }
  }, [enabled]);
  return {
    connected
  };
}
