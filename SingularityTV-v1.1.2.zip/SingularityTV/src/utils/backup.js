const PREFIX = "streambert_";
export const BACKUP_KEYS = ["saved", "savedOrder", "history", "progress", "watched", "homeRowOrder", "homeRowVisible", "homeViewMode", "startPage", "playerSource", "hianimeDubMode", "introSkipMode", "ageLimit", "ratingCountry", "watchedThreshold", "autoplayNextEnabled", "autoplayNextDuration", "autoplayNextLayout", "subtitleDownload", "subtitleLang", "downloadPath", "downloaderFolder", "invidiousBase", "autoCheckUpdates", "searchHistory", "accentColor", "fontSize", "compactMode", "reduceAnimations", "librarySort", "historyEnabled", "tmdbLang", "notifyDownloadComplete", "notifyNewEpisode", "episodeReleaseCache", "favorites", "subTextSize", "subTextColor", "subBgStyle", "subBottomOffset", "seriesPrefs", "embedMovieTemplate", "embedTvTemplate", "theme", "customThemeVars", "accentInPlayer", "liveFavorites", "customLiveM3u", "_progressTs", "_watchedTs", "_savedTs", "_liveFavTs", "_settingsTs"];

export function touchBackupTimestamp(mapKey, itemKey) {
  try {
    const raw = localStorage.getItem(PREFIX + mapKey);
    const obj = raw ? JSON.parse(raw) : {};
    obj[itemKey] = Date.now();
    localStorage.setItem(PREFIX + mapKey, JSON.stringify(obj));
  } catch {}
}

export function touchSettingsTimestamp() {
  try {
    localStorage.setItem(PREFIX + "_settingsTs", JSON.stringify(Date.now()));
  } catch {}
}

export function collectBackupData() {
  const data = {};
  for (const key of BACKUP_KEYS) {
    try {
      const raw = localStorage.getItem(PREFIX + key);
      if (raw !== null) data[key] = JSON.parse(raw);
    } catch {}
  }
  const dlTimes = {};
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(PREFIX + "dlTime_")) {
        const raw = localStorage.getItem(k);
        if (raw !== null) dlTimes[k.slice(PREFIX.length)] = JSON.parse(raw);
      }
    }
  } catch {}
  if (Object.keys(dlTimes).length > 0) {
    data._dlTimes = dlTimes;
  }
  return data;
}

export function clearBackupData() {
  for (const key of BACKUP_KEYS) {
    try {
      localStorage.removeItem(PREFIX + key);
    } catch {}
  }
  try {
    const toRemove = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && (k.startsWith(PREFIX + "dlTime_") || k.startsWith("dlTime_"))) {
        toRemove.push(k);
      }
    }
    for (const k of toRemove) {
      localStorage.removeItem(k);
    }
  } catch {}
}

export function mergeBackupData(localData = {}, remoteData = {}) {
  const loc = localData && typeof localData === "object" ? localData : {};
  const rem = remoteData && typeof remoteData === "object" ? remoteData : {};
  const locSetTs = Number(loc._settingsTs || 0);
  const remSetTs = Number(rem._settingsTs || 0);
  const merged = remSetTs >= locSetTs ? { ...loc, ...rem } : { ...rem, ...loc };
  merged._settingsTs = Math.max(locSetTs, remSetTs);

  const locProgTs = loc._progressTs && typeof loc._progressTs === "object" ? loc._progressTs : {};
  const remProgTs = rem._progressTs && typeof rem._progressTs === "object" ? rem._progressTs : {};
  const locProg = loc.progress && typeof loc.progress === "object" ? loc.progress : {};
  const remProg = rem.progress && typeof rem.progress === "object" ? rem.progress : {};
  const locDl = loc._dlTimes && typeof loc._dlTimes === "object" ? loc._dlTimes : {};
  const remDl = rem._dlTimes && typeof rem._dlTimes === "object" ? rem._dlTimes : {};

  const outProg = {};
  const outProgTs = {};
  const outDl = { ...remDl, ...locDl };
  const progKeys = new Set([...Object.keys(locProg), ...Object.keys(remProg)]);
  for (const k of progKeys) {
    const lt = Number(locProgTs[k] || 0);
    const rt = Number(remProgTs[k] || 0);
    const dlKey = "dlTime_" + k;
    if (rt > lt) {
      outProg[k] = remProg[k];
      outProgTs[k] = rt;
      if (remDl[dlKey] !== undefined) outDl[dlKey] = remDl[dlKey];
    } else if (lt > rt) {
      outProg[k] = locProg[k];
      outProgTs[k] = lt;
      if (locDl[dlKey] !== undefined) outDl[dlKey] = locDl[dlKey];
    } else {
      const lv = Number(locProg[k] || 0);
      const rv = Number(remProg[k] || 0);
      outProg[k] = Math.max(lv, rv);
      outProgTs[k] = Math.max(lt, rt);
      if (rv > lv && remDl[dlKey] !== undefined) outDl[dlKey] = remDl[dlKey];
    }
  }
  merged.progress = outProg;
  merged._progressTs = outProgTs;
  merged._dlTimes = outDl;

  const locWatchTs = loc._watchedTs && typeof loc._watchedTs === "object" ? loc._watchedTs : {};
  const remWatchTs = rem._watchedTs && typeof rem._watchedTs === "object" ? rem._watchedTs : {};
  const locWatch = loc.watched && typeof loc.watched === "object" ? loc.watched : {};
  const remWatch = rem.watched && typeof rem.watched === "object" ? rem.watched : {};
  const outWatch = {};
  const outWatchTs = {};
  const watchKeys = new Set([...Object.keys(locWatch), ...Object.keys(remWatch), ...Object.keys(locWatchTs), ...Object.keys(remWatchTs)]);
  for (const k of watchKeys) {
    const lt = Number(locWatchTs[k] || 0);
    const rt = Number(remWatchTs[k] || 0);
    const val = rt > lt ? !!remWatch[k] : lt > rt ? !!locWatch[k] : !!(locWatch[k] || remWatch[k]);
    if (val) outWatch[k] = true;
    const ts = Math.max(lt, rt);
    if (ts > 0) outWatchTs[k] = ts;
  }
  merged.watched = outWatch;
  merged._watchedTs = outWatchTs;

  const locSavedTs = loc._savedTs && typeof loc._savedTs === "object" ? loc._savedTs : {};
  const remSavedTs = rem._savedTs && typeof rem._savedTs === "object" ? rem._savedTs : {};
  const locSaved = loc.saved && typeof loc.saved === "object" ? loc.saved : {};
  const remSaved = rem.saved && typeof rem.saved === "object" ? rem.saved : {};
  const outSaved = {};
  const outSavedTs = {};
  const savedKeys = new Set([...Object.keys(locSaved), ...Object.keys(remSaved), ...Object.keys(locSavedTs), ...Object.keys(remSavedTs)]);
  for (const k of savedKeys) {
    const lt = Number(locSavedTs[k] || 0);
    const rt = Number(remSavedTs[k] || 0);
    const entry = rt > lt ? remSaved[k] : lt > rt ? locSaved[k] : (locSaved[k] || remSaved[k]);
    if (entry) outSaved[k] = entry;
    const ts = Math.max(lt, rt);
    if (ts > 0) outSavedTs[k] = ts;
  }
  merged.saved = outSaved;
  merged._savedTs = outSavedTs;

  const locOrder = Array.isArray(loc.savedOrder) ? loc.savedOrder : [];
  const remOrder = Array.isArray(rem.savedOrder) ? rem.savedOrder : [];
  const orderSet = new Set();
  const outOrder = [];
  for (const k of [...locOrder, ...remOrder, ...Object.keys(outSaved)]) {
    if (outSaved[k] && !orderSet.has(k)) {
      orderSet.add(k);
      outOrder.push(k);
    }
  }
  merged.savedOrder = outOrder;

  const histMap = new Map();
  const allHist = [...(Array.isArray(rem.history) ? rem.history : []), ...(Array.isArray(loc.history) ? loc.history : [])];
  for (const h of allHist) {
    if (!h || !h.id) continue;
    const hk = h.media_type === "tv" ? `tv_${h.id}_s${h.season}_e${h.episode}` : `movie_${h.id}`;
    const prev = histMap.get(hk);
    if (!prev || Number(h.watchedAt || 0) >= Number(prev.watchedAt || 0)) {
      histMap.set(hk, h);
    }
  }
  merged.history = Array.from(histMap.values())
    .sort((a, b) => Number(b.watchedAt || 0) - Number(a.watchedAt || 0))
    .slice(0, 100);

  const locFavTs = loc._liveFavTs && typeof loc._liveFavTs === "object" ? loc._liveFavTs : {};
  const remFavTs = rem._liveFavTs && typeof rem._liveFavTs === "object" ? rem._liveFavTs : {};
  const locFavMap = new Map();
  for (const f of Array.isArray(loc.liveFavorites) ? loc.liveFavorites : []) {
    if (f && f.url) locFavMap.set(f.url, f);
  }
  const remFavMap = new Map();
  for (const f of Array.isArray(rem.liveFavorites) ? rem.liveFavorites : []) {
    if (f && f.url) remFavMap.set(f.url, f);
  }
  const outFavs = [];
  const outFavTs = {};
  const allFavUrls = new Set([...locFavMap.keys(), ...remFavMap.keys(), ...Object.keys(locFavTs), ...Object.keys(remFavTs)]);
  for (const u of allFavUrls) {
    const lt = Number(locFavTs[u] || 0);
    const rt = Number(remFavTs[u] || 0);
    const entry = rt > lt ? remFavMap.get(u) : lt > rt ? locFavMap.get(u) : (locFavMap.get(u) || remFavMap.get(u));
    if (entry) outFavs.push(entry);
    const ts = Math.max(lt, rt);
    if (ts > 0) outFavTs[u] = ts;
  }
  merged.liveFavorites = outFavs;
  merged._liveFavTs = outFavTs;

  return merged;
}

export function restoreBackupData(data) {
  if (!data || typeof data !== "object") throw new Error("Invalid backup data");
  clearBackupData();
  for (const key of BACKUP_KEYS) {
    if (data[key] !== undefined && data[key] !== null) {
      localStorage.setItem(PREFIX + key, JSON.stringify(data[key]));
    }
  }
  if (data._dlTimes && typeof data._dlTimes === "object") {
    for (const [k, v] of Object.entries(data._dlTimes)) {
      try {
        localStorage.setItem(PREFIX + k, JSON.stringify(v));
      } catch {}
    }
  }
}
