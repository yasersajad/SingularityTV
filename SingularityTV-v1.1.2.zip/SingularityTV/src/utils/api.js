const TMDB_BASE = "https://api.themoviedb.org/3";
const TMDB_API_KEY = "21c0592bd4e9052db10be9a910b40ab7";
const TMDB_READ_TOKEN = "eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiIyMWMwNTkyYmQ0ZTkwNTJkYjEwYmU5YTkxMGI0MGFiNyIsIm5iZiI6MTc5NTE4ODE1MS4xMzEsInN1YiI6IjZiMDA2NWI3ZDczZWQ3YWIwZDliY2IzOCIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.Mh_NL0nLx9zlMmImtmYhVHZ5dXfb68wuKbrjYj652nM";
const TMDB_IMG_BASE = "https://image.tmdb.org/t/p";
const ANILIST_API = "https://graphql.anilist.co";

try {
  if (typeof localStorage !== "undefined" && !localStorage.getItem("streambert_tmdb_official_v112")) {
    localStorage.setItem("streambert_tmdb_official_v112", "1");
    localStorage.removeItem("streambert_trendingCache");
    localStorage.setItem("streambert_playerSource", JSON.stringify("vidyst"));
  }
} catch {}

export const imgUrl = (path, size = "w500") => {
  if (!path || typeof path !== "string") return null;
  const trimmed = path.trim();
  if (!trimmed) return null;
  if (trimmed.startsWith("data:") || trimmed.startsWith("blob:") || trimmed.startsWith("file:")) {
    return trimmed;
  }
  if (trimmed.startsWith("https://")) return trimmed;
  if (trimmed.startsWith("http://")) return "https://" + trimmed.slice(7);
  if (trimmed.startsWith("//")) return "https:" + trimmed;
  if (trimmed.startsWith("/")) return `${TMDB_IMG_BASE}/${size || "w500"}${trimmed}`;
  return `${TMDB_IMG_BASE}/${size || "w500"}/${trimmed}`;
};

let _onUnreachable = null;
export const setApiErrorHandlers = (_onAuth, onUnreachable) => {
  _onUnreachable = onUnreachable;
};

const _metaCache = new Map();
const META_CACHE_TTL = 10 * 60 * 1000;

export function clearMetadataCache() {
  _metaCache.clear();
  try {
    localStorage.removeItem("streambert_trendingCache");
  } catch {}
}
export const clearTmdbCache = clearMetadataCache;

const _idMap = new Map();
export function registerIdMapping(ids = {}) {
  const { imdbId, numericId, anilistId, tvmazeId } = ids;
  const merged = {
    ...(imdbId ? _idMap.get(String(imdbId)) : null),
    ...(numericId ? _idMap.get(String(numericId)) : null),
    ...(imdbId ? { imdbId: String(imdbId) } : null),
    ...(numericId ? { numericId: String(numericId) } : null),
    ...(anilistId ? { anilistId: Number(anilistId) } : null),
    ...(tvmazeId ? { tvmazeId: Number(tvmazeId) } : null)
  };
  if (merged.imdbId) _idMap.set(String(merged.imdbId), merged);
  if (merged.numericId) _idMap.set(String(merged.numericId), merged);
  if (merged.anilistId) _idMap.set(`anilist:${merged.anilistId}`, merged);
  if (merged.imdbId && merged.numericId) {
    try {
      localStorage.setItem(`streambert_numid_${merged.imdbId}`, String(merged.numericId));
    } catch {}
  }
}

export const FALLBACK_MOVIES = [];
export const FALLBACK_SERIES = [];

const GENRE_MAP = {
  action: { movie: 28, tv: 10759 },
  adventure: { movie: 12, tv: 10759 },
  animation: { movie: 16, tv: 16 },
  anime: { movie: 16, tv: 16, lang: "ja" },
  comedy: { movie: 35, tv: 35 },
  crime: { movie: 80, tv: 80 },
  documentary: { movie: 99, tv: 99 },
  drama: { movie: 18, tv: 18 },
  family: { movie: 10751, tv: 10751 },
  fantasy: { movie: 14, tv: 10765 },
  history: { movie: 36, tv: 10768 },
  horror: { movie: 27, tv: null },
  music: { movie: 10402, tv: null },
  mystery: { movie: 9648, tv: 9648 },
  romance: { movie: 10749, tv: null },
  "sci-fi": { movie: 878, tv: 10765 },
  scifi: { movie: 878, tv: 10765 },
  "science fiction": { movie: 878, tv: 10765 },
  thriller: { movie: 53, tv: 9648 },
  war: { movie: 10752, tv: 10768 },
  western: { movie: 37, tv: 37 }
};

function getPreferredLang() {
  try {
    const raw = localStorage.getItem("streambert_tmdbLang");
    if (raw) {
      const parsed = JSON.parse(raw);
      if (typeof parsed === "string" && parsed.trim()) return parsed.trim();
    }
  } catch {}
  return "en-US";
}

async function rawTmdbRequest(path, signal = null) {
  const sep = path.includes("?") ? "&" : "?";
  const hasLang = /[?&]language=/.test(path);
  const langParam = hasLang ? "" : `&language=${encodeURIComponent(getPreferredLang())}`;
  const url = `${TMDB_BASE}${path}${sep}api_key=${TMDB_API_KEY}${langParam}`;
  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${TMDB_READ_TOKEN}`,
      Accept: "application/json"
    },
    ...(signal ? { signal } : {})
  });
  if (!res.ok) {
    throw new Error(`TMDB HTTP ${res.status}`);
  }
  return res.json();
}

async function resolveImdbToTmdb(ttId, preferredType = null) {
  const cached = _idMap.get(ttId);
  if (cached?.numericId) return { id: cached.numericId, type: preferredType || "movie" };
  const data = await rawTmdbRequest(`/find/${encodeURIComponent(ttId)}?external_source=imdb_id`);
  const mv = Array.isArray(data?.movie_results) ? data.movie_results[0] : null;
  const tv = Array.isArray(data?.tv_results) ? data.tv_results[0] : null;
  const pick = preferredType === "tv" ? (tv || mv) : preferredType === "movie" ? (mv || tv) : (mv || tv);
  if (pick?.id) {
    const resolvedType = pick === tv ? "tv" : "movie";
    registerIdMapping({ imdbId: ttId, numericId: String(pick.id) });
    return { id: String(pick.id), type: resolvedType };
  }
  return null;
}

export const tmdbFetch = async (path, _unusedApiKey = null, opts = {}) => {
  const cleanPath = String(path || "").trim();
  const signal = opts?.signal || null;
  const cacheKey = `${getPreferredLang()}::${cleanPath}`;
  const cached = _metaCache.get(cacheKey);
  if (cached && Date.now() - cached.ts < META_CACHE_TTL) {
    return cached.data;
  }

  try {
    if (cleanPath.startsWith("/discover/genre")) {
      const qs = new URLSearchParams(cleanPath.split("?")[1] || "");
      const gName = (qs.get("genre") || "").trim().toLowerCase();
      const page = Number(qs.get("page") || 1);
      const spec = GENRE_MAP[gName];
      const langQ = spec?.lang ? `&with_original_language=${spec.lang}` : "";
      const tasks = [];
      if (!spec || spec.movie) {
        const gq = spec?.movie ? `&with_genres=${spec.movie}` : "";
        tasks.push(
          rawTmdbRequest(`/discover/movie?sort_by=popularity.desc&page=${page}${gq}${langQ}`, signal)
            .then(d => ({ total_pages: d.total_pages || 1, results: (d.results || []).map(x => ({ ...x, media_type: "movie", numeric_id: x.id })) }))
            .catch(() => ({ total_pages: 1, results: [] }))
        );
      }
      if (!spec || spec.tv) {
        const gq = spec?.tv ? `&with_genres=${spec.tv}` : "";
        tasks.push(
          rawTmdbRequest(`/discover/tv?sort_by=popularity.desc&page=${page}${gq}${langQ}`, signal)
            .then(d => ({ total_pages: d.total_pages || 1, results: (d.results || []).map(x => ({ ...x, media_type: "tv", numeric_id: x.id })) }))
            .catch(() => ({ total_pages: 1, results: [] }))
        );
      }
      const chunks = await Promise.all(tasks);
      const merged = [];
      const maxLen = Math.max(...chunks.map(c => c.results.length), 0);
      for (let i = 0; i < maxLen; i++) {
        for (const c of chunks) {
          if (c.results[i]) merged.push(c.results[i]);
        }
      }
      const out = {
        page,
        results: merged,
        total_pages: Math.max(...chunks.map(c => c.total_pages || 1), 1)
      };
      _metaCache.set(cacheKey, { ts: Date.now(), data: out });
      return out;
    }

    let finalPath = cleanPath;
    const ttMatch = cleanPath.match(/^\/(movie|tv)\/(tt\d+)(\/.*)?$/i);
    if (ttMatch) {
      const resolved = await resolveImdbToTmdb(ttMatch[2], ttMatch[1].toLowerCase());
      if (resolved?.id) {
        finalPath = `/${ttMatch[1].toLowerCase()}/${resolved.id}${ttMatch[3] || ""}`;
      }
    }

    const isDirectDetail = /^\/(movie|tv)\/\d+(\?.*)?$/.test(finalPath);
    if (isDirectDetail && !finalPath.includes("append_to_response=")) {
      finalPath += (finalPath.includes("?") ? "&" : "?") + "append_to_response=external_ids";
    }

    const data = await rawTmdbRequest(finalPath, signal);

    if (data && typeof data === "object") {
      if (isDirectDetail) {
        const extImdb = data.imdb_id || data.external_ids?.imdb_id || "";
        if (extImdb) {
          data.imdb_id = extImdb;
          registerIdMapping({ imdbId: extImdb, numericId: String(data.id) });
        }
        data.numeric_id = data.id;
      }
      if (Array.isArray(data.results)) {
        const inferredType = finalPath.startsWith("/movie/") || finalPath.startsWith("/trending/movie")
          ? "movie"
          : finalPath.startsWith("/tv/") || finalPath.startsWith("/trending/tv")
          ? "tv"
          : null;
        data.results = data.results.map(item => ({
          ...item,
          media_type: item.media_type || inferredType || (item.first_air_date ? "tv" : "movie"),
          numeric_id: item.id
        }));
      }
    }

    _metaCache.set(cacheKey, { ts: Date.now(), data });
    return data;
  } catch (err) {
    if (err?.name !== "AbortError") {
      _onUnreachable?.();
    }
    throw err;
  }
};

export const PLAYER_SOURCES = [{
  id: "vidyst",
  label: "Singularity Server",
  tag: null,
  note: "HD · TMDB",
  supportsProgress: true,
  progressViaFrames: true,
  idType: "numeric",
  colorParam: null,
  langParam: null,
  params: {},
  movieUrl: id => `https://vidy.st/movie/${id}?color=DC2626&autoplay=true`,
  tvUrl: (id, season, ep) => `https://vidy.st/tv/${id}/${season}/${ep}?color=DC2626&autoplay=true`
}];

export const NEEDS_INTERCEPT = [];

export const getSourceUrl = (sourceId, type, id, season, ep, extraParams = {}, accentColor = null, subtitleLang = null) => {
  const src = PLAYER_SOURCES.find(s => s.id === sourceId) ?? PLAYER_SOURCES[0];
  if (!id) return null;
  if (type !== "movie" && !src.tvUrl) return null;
  const baseUrl = type === "movie" ? src.movieUrl(id) : src.tvUrl(id, season, ep);
  const url = new URL(baseUrl);
  Object.entries(src.params || {}).forEach(([key, value]) => {
    url.searchParams.set(key, value);
  });
  if (accentColor && src.colorParam) {
    const hex = accentColor.replace(/^#/, "");
    url.searchParams.set(src.colorParam, src.colorWithHash ? `#${hex}` : hex);
  }
  if (subtitleLang && src.langParam) {
    url.searchParams.set(src.langParam, subtitleLang);
  }
  Object.entries(extraParams).forEach(([key, value]) => {
    if (value != null) url.searchParams.set(key, value);
  });
  return url.toString();
};

export const CLEAN_USER_AGENT = typeof window !== "undefined" && window.electron?.cleanUserAgent || "";
export const sourceUsesCleanUa = sourceId => PLAYER_SOURCES.find(s => s.id === sourceId)?.cleanUserAgent ?? false;
export const sourceIdType = sourceId => PLAYER_SOURCES.find(s => s.id === sourceId)?.idType ?? "numeric";
export const sourceNeedsImdb = sourceId => sourceIdType(sourceId) === "imdb";
export const sourceNeedsKinopoisk = sourceId => sourceIdType(sourceId) === "kinopoisk";
export const sourceIsMovieOnly = sourceId => PLAYER_SOURCES.find(s => s.id === sourceId)?.movieOnly ?? false;

export async function fetchImdbId(type, mediaId) {
  const str = String(mediaId || "").trim();
  if (/^tt\d+$/i.test(str)) return str;
  const cached = _idMap.get(str);
  if (cached?.imdbId) return cached.imdbId;
  try {
    const data = await rawTmdbRequest(`/${type === "tv" ? "tv" : "movie"}/${encodeURIComponent(str)}/external_ids`);
    if (data?.imdb_id) {
      registerIdMapping({ imdbId: data.imdb_id, numericId: str });
      return data.imdb_id;
    }
  } catch {}
  return "";
}

export async function fetchNumericId(type, mediaId) {
  const str = String(mediaId || "").trim();
  if (/^\d+$/.test(str)) return str;
  const cached = _idMap.get(str);
  if (cached?.numericId) return String(cached.numericId);
  if (/^tt\d+$/i.test(str)) {
    const resolved = await resolveImdbToTmdb(str, type === "tv" ? "tv" : "movie");
    if (resolved?.id) return resolved.id;
  }
  return str;
}

export async function fetchKinopoiskId() {
  return "";
}

export const sourceSupportsProgress = sourceId => PLAYER_SOURCES.find(s => s.id === sourceId)?.supportsProgress ?? true;
export const sourceProgressViaFrames = sourceId => PLAYER_SOURCES.find(s => s.id === sourceId)?.progressViaFrames ?? true;
export const sourceSkipsResetGuard = sourceId => PLAYER_SOURCES.find(s => s.id === sourceId)?.skipResetGuard ?? false;
export const sourceIsAsync = sourceId => PLAYER_SOURCES.find(s => s.id === sourceId)?.async ?? false;
export const sourceSupportsAnime = () => true;
export const sourceIsAnimeCapable = () => true;
export const getAnimeSourceUrl = (_sourceId, id, ep) => (id ? `https://vidy.st/anime/${id}/${ep || 1}?color=DC2626&autoplay=true` : null);
export const getNextNonAsyncSource = () => PLAYER_SOURCES[0].id;

export const cleanAnilistDescription = desc => {
  if (!desc) return "";
  return String(desc).replace(/<br\s*\/?>/gi, "\n").replace(/<[^>]+>/g, "").trim();
};

export const fetchAnilistData = async (title, type = "ANIME") => {
  if (!title) return null;
  try {
    const res = await fetch(ANILIST_API, {
      method: "POST",
      headers: { "Content-Type": "application/json", Accept: "application/json" },
      body: JSON.stringify({
        query: "query ($search: String, $type: MediaType) { Media(search: $search, type: $type) { id title { romaji english } episodes description } }",
        variables: { search: title, type }
      })
    });
    const json = await res.json();
    return json?.data?.Media || null;
  } catch {
    return null;
  }
};

export const buildAnilistSeasons = () => [];

export const isAnimeContent = (item, details) => {
  const genres = details?.genres || item?.genres || [];
  const genreIds = item?.genre_ids || [];
  const isAnim = genreIds.includes(16) || genres.some(g => g?.id === 16 || /animation/i.test(g?.name || ""));
  const lang = (details?.original_language || item?.original_language || "").toLowerCase();
  return isAnim && lang === "ja";
};

export const ANIME_DEFAULT_SOURCE = "vidyst";
export const NON_ANIME_DEFAULT_SOURCE = "vidyst";

export const fetchEpisodeGroup = async groupId => {
  if (!groupId) return null;
  try {
    return await rawTmdbRequest(`/tv/episode_group/${encodeURIComponent(groupId)}`);
  } catch {
    return null;
  }
};

export function resolveGenreFromQuery(query) {
  const q = String(query || "").trim().toLowerCase();
  if (!q) return null;
  if (GENRE_MAP[q]) return q.charAt(0).toUpperCase() + q.slice(1);
  return null;
}
