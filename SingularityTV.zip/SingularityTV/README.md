# SingularityTV

Developed by **@ec1lz** — [t.me/ec1lz](https://t.me/ec1lz)

All rights reserved to Singularity (@ec1lz).
