# Streambert Android v2.7.0 — Complete Desktop-to-Android Migration Architecture & Build Guide

## 1. Executive Summary & Migration Map

Streambert Desktop v2.7.0 has been migrated from an Electron desktop runtime to a native **Kotlin + AndroidX Media3 ExoPlayer + Room Database + WorkManager + React UI** architecture targeting **Android Mobile**, **Android Tablets**, **Android TV**, **Android TV Boxes**, and **Game Controllers / D-Pad Remotes**. All **TMDB API dependencies, token prompts, and configuration screens have been completely removed** and replaced with a keyless multi-provider metadata engine.

| Desktop Component (v2.7.0) | Electron Implementation | Android Native Replacement (v2.7.0-android) |
| :--- | :--- | :--- |
| **Application Runtime** | Electron `BrowserWindow` (`index.js`, `preload.js`, `popout-preload.js`) | Native Kotlin `MainActivity.kt` (Mobile/Tablet) + `TvMainActivity.kt` (`LEANBACK_LAUNCHER` for Android TV) + `StreambertJsBridge.kt` (`@JavascriptInterface`) |
| **Metadata Engine** | `api.themoviedb.org/3` + `SetupScreen.jsx` (mandatory Bearer token) | **100% TMDB-Free Keyless Engine** (`src/utils/api.js`): Stremio Cinemeta (`cinemeta-live.strem.io` / `v3-cinemeta.strem.io`), TVMaze (`api.tvmaze.com`), AniList GraphQL (`graphql.anilist.co`), IMDb Suggestion API (`v3.sg.media-imdb.com`), Wikidata SPARQL (`query.wikidata.org/sparql`), plus offline fallback catalog |
| **Primary Video Player** | Electron `<webview>` + local Node HTTP proxy (`hianime.js`) + external `mpv`/`vlc` spawner (`player.js`) | **AndroidX Media3 ExoPlayer** (`NativeExoPlayerActivity.kt`) + `ExoPlayerOverlay.jsx` + `StreamPlayerFrame.jsx` supporting HLS (`.m3u8`), DASH, MP4, MKV, custom HTTP headers (`Referer`, `Origin`, `User-Agent`), ABR, Speed (`0.5x`–`2.0x`), Audio/Subtitle tracks, and native Picture-in-Picture (`enterPictureInPictureMode`) |
| **Anime Resolution** | Electron Main Process `src/ipc/hianime.js` (`net.fetch` + XOR `otaku-embed-v1` + local HTTP proxy) | Native Kotlin `HiAnimeResolver.kt` using `OkHttpClient` + `Base64`/XOR `otaku-embed-v1` deobfuscation + AniList GraphQL sequel chain + AniSkip (`src/utils/aniSkip.js`) |
| **Download Manager** | External desktop CLI binary spawner (`vid-dl-cli-only` via `child_process.spawn` in `src/ipc/downloads.js`) | Native **AndroidX WorkManager** `StreamDownloadWorker.kt` (`CoroutineWorker` with Foreground `ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC`) supporting HLS `.m3u8` fragment downloads & progressive `.mp4` HTTP `Range` resume, Pause, Resume, Cancel, Retry, ETA, and Scoped Storage |
| **Subtitle System** | Electron `src/ipc/subtitles.js` (SubDL ZIP inflate + Wyzie + temp file write) | Native Kotlin `SubtitleManager.kt` (safe `ZipInputStream` extraction with 10 MB zip-bomb guard, SubDL + Wyzie search by IMDb/numeric ID) + Media3 `SubtitleView` styling + real-time sync delay adjustment (`-5.0s` to `+5.0s`) |
| **Local Persistence** | JSON files in `app.getPath("userData")` + `safeStorage` + `localStorage` | **AndroidX Room Database** (`StreambertDatabase.kt`: `preferences`, `watchlist`, `watch_history`, `playback_progress`, `downloads`, `blocked_domains`) + `EncryptedSharedPreferences` (`AES256_GCM`) |
| **Ad & Tracker Blocker** | `session.webRequest.onBeforeRequest` (`BLOCKED_HOSTS` + `siteTweaks.js`) | `AdBlockerInterceptor.kt` + `StreambertWebViewClient.kt` intercepting 150+ ad/tracker domains, recording per-domain counts in Room DB, injecting per-host CSS tweaks, and capturing `.m3u8`/`.vtt` streams |
| **TV & Remote Navigation** | `navigator.getGamepads()` polling only (`gamepad.js`) | Full Android TV `KEYCODE_DPAD_UP/DOWN/LEFT/RIGHT/CENTER`, `KEYCODE_ENTER`, `KEYCODE_BACK`, `KEYCODE_MENU`, `KEYCODE_MEDIA_PLAY_PAUSE/REWIND/FAST_FORWARD` handling in `MainActivity.kt`, `NativeExoPlayerActivity.kt`, and `useGamepadNav.js` |

## 2. Project Directory Structure

```text
streambert-android/
├── android/                                   # Native Android Studio / Gradle Project
│   ├── build.gradle.kts                       # Root Gradle configuration (AGP 8.5.2, Kotlin 1.9.24, KSP)
│   ├── settings.gradle.kts                    # Module settings (:app)
│   ├── gradle.properties                      # AndroidX & JVM memory flags
│   └── app/
│       ├── build.gradle.kts                   # App dependencies (Media3 1.4.1, Room 2.6.1, WorkManager 2.9.1) & Flavors (universal, mobile, tv)
│       ├── proguard-rules.pro                 # R8 / ProGuard rules for JavascriptInterface & Room
│       └── src/main/
│           ├── AndroidManifest.xml            # Mobile LAUNCHER + Android TV LEANBACK_LAUNCHER + NativeExoPlayerActivity
│           ├── assets/public/                 # Pre-compiled Streambert React UI bundle, CSS, Bebas Neue & DM Sans fonts, SVG icons
│           ├── java/com/truelockmc/streambert/
│           │   ├── StreambertApp.kt           # Application singleton (Room DB, OkHttpClient, NotificationChannels)
│           │   ├── MainActivity.kt            # Mobile/Tablet/TV WebView host, D-Pad key router, PiP & Back stack
│           │   ├── TvMainActivity.kt          # Dedicated Android TV Leanback entry point
│           │   ├── bridge/StreambertJsBridge.kt
│           │   ├── data/Entities.kt
│           │   ├── data/Daos.kt
│           │   ├── data/StreambertDatabase.kt
│           │   ├── download/StreamDownloadWorker.kt
│           │   ├── player/NativeExoPlayerActivity.kt
│           │   ├── stream/HiAnimeResolver.kt
│           │   ├── subtitle/SubtitleManager.kt
│           │   ├── webview/AdBlockerInterceptor.kt
│           │   └── webview/StreambertWebViewClient.kt
│           └── res/                           # Themes, colors, strings, TV banner, mipmap icons, network security config
├── src/                                       # Adapted React UI Source (Zero TMDB, Zero Electron)
│   ├── App.jsx
│   ├── main.jsx
│   ├── components/                            # StreamPlayerFrame.jsx, ExoPlayerOverlay.jsx, MediaCard.jsx, TrendingCarousel.jsx, etc.
│   ├── pages/                                 # HomePage.jsx, MoviePage.jsx, TVPage.jsx, LibraryPage.jsx, DownloadsPage.jsx, SettingsPage.jsx
│   ├── styles/                                # global.css (Mobile bottom nav + Android TV 10-foot UI + themes) & woff2 fonts
│   └── utils/                                 # api.js (Keyless Metadata Engine), androidBridge.js, storage.js, useGamepadNav.js, etc.
├── scripts/
│   └── build-android-assets.js                # Self-contained Babel React compiler generating dist/ and android/app/src/main/assets/public/
├── build-android-apk.sh                       # Universal build script for Mobile, Android TV, and Universal APKs
└── package.json
```

## 3. Building the Debug & Release APKs

> **Build Verification Note**: The web application bundle (`android/app/src/main/assets/public/bundle.js`, `global.css`, `index.html`, and font/icon assets) has been compiled and verified in headless Chromium with zero runtime errors. Because this execution container does not have the Android SDK (`sdkmanager` / `aapt2` / `android.jar`) installed and outbound internet access is disabled in the container, the final `.apk` binary packaging step must be run on a host machine with the Android SDK installed (Android Studio, command-line SDK, or AndroidIDE).

### Option A: One-Command Build via `build-android-apk.sh`
1. Extract `streambert-android-v2.7.0.zip`.
2. Ensure JDK 17 and the Android SDK (`ANDROID_HOME`) are installed.
3. Run:
   ```bash
   chmod +x build-android-apk.sh
   ./build-android-apk.sh
   ```
   This compiles the web assets and generates:
   - `output/app-universal-debug.apk` (Runs on both Android Mobile/Tablet and Android TV)
   - `output/app-mobile-debug.apk` (Mobile & Tablet optimized variant)
   - `output/app-tv-debug.apk` (Android TV & TV Box Leanback variant)
   - `output/app-universal-release.apk` (Minified release variant)

### Option B: Android Studio
1. Open the `android/` folder inside `streambert-android-v2.7.0.zip` in **Android Studio**.
2. Select the desired build variant in **Build Variants** (`universalDebug`, `mobileDebug`, `tvDebug`, or `universalRelease`).
3. Click **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
