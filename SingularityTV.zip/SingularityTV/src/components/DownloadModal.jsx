import { useState, useEffect, useCallback } from "react";
import { CloseIcon, DownloadIcon, SettingsIcon, SubtitlesIcon } from "./Icons";
import { storage, STORAGE_KEYS, secureStorage, isElectron } from "../utils/storage";
import { SUBTITLE_LANGUAGES, LANG_LABEL, sourceBadgeStyle, sourceBadgeLabel } from "../utils/subtitles";
export function SubtitleBrowser({
  tmdbId,
  mediaType,
  season,
  episode,
  subdlApiKey,
  wyzieApiKey,
  selectedSubs,
  setSelectedSubs,
  onClose,
  defaultLang
}) {
  const [langFilter, setLangFilter] = useState(defaultLang);
  const [browseResults, setBrowseResults] = useState(null);
  const [browsing, setBrowsing] = useState(false);
  const [browseError, setBrowseError] = useState(null);
  const doSearch = async lang => {
    setBrowsing(true);
    setBrowseError(null);
    try {
      const res = await window.electron.searchSubtitles({
        tmdbId,
        mediaType,
        season,
        episode,
        languages: lang || "",
        subdlApiKey,
        wyzieApiKey
      });
      if (!res.ok) {
        const errMsg = res.error || "Search failed";
        const is403 = errMsg.includes("403") || errMsg.toLowerCase().includes("cannot consume");
        setBrowseError(is403 ? "API error 403 - your SubDL or Wyzie API key is missing or invalid. Add a valid key in Settings." : errMsg);
        setBrowseResults([]);
      } else setBrowseResults(res.results);
    } catch (e) {
      setBrowseError(e.message);
      setBrowseResults([]);
    } finally {
      setBrowsing(false);
    }
  };
  useEffect(() => {
    doSearch(langFilter);
  }, []);
  return React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      zIndex: 999999,
      background: "rgba(0,0,0,0.75)",
      backdropFilter: "blur(6px)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    },
    onClick: () => onClose()
  }, React.createElement("div", {
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border)",
      borderRadius: 12,
      width: 580,
      maxWidth: "95vw",
      maxHeight: "80vh",
      display: "flex",
      flexDirection: "column",
      boxShadow: "0 24px 64px rgba(0,0,0,0.6)"
    },
    onClick: e => e.stopPropagation()
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "16px 20px",
      borderBottom: "1px solid var(--border)"
    }
  }, React.createElement("span", {
    style: {
      fontWeight: 600,
      fontSize: 15,
      display: "flex",
      alignItems: "center",
      gap: 6
    }
  }, React.createElement(SubtitlesIcon, {
    size: 14
  }), " Browse Subtitles", selectedSubs.length > 0 ? ` · ${selectedSubs.length} selected` : ""), React.createElement("button", {
    className: "icon-btn",
    onClick: () => onClose()
  }, React.createElement(CloseIcon, null))), React.createElement("div", {
    style: {
      padding: "10px 16px",
      borderBottom: "1px solid var(--border)",
      display: "flex",
      gap: 8,
      alignItems: "center",
      flexWrap: "wrap"
    }
  }, React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, "Language:"), React.createElement("select", {
    value: langFilter,
    onChange: e => {
      setLangFilter(e.target.value);
      doSearch(e.target.value);
    },
    style: {
      background: "var(--surface2)",
      border: "1px solid var(--border)",
      borderRadius: 6,
      color: "var(--text)",
      padding: "5px 10px",
      fontSize: 12,
      cursor: "pointer"
    }
  }, React.createElement("option", {
    value: ""
  }, "All languages"), SUBTITLE_LANGUAGES.map(l => React.createElement("option", {
    key: l.code,
    value: l.code
  }, l.label)))), React.createElement("div", {
    style: {
      overflowY: "auto",
      flex: 1,
      padding: "4px 0"
    }
  }, browsing && React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      gap: 10,
      padding: 24,
      color: "var(--text3)",
      fontSize: 13
    }
  }, React.createElement("div", {
    className: "spinner",
    style: {
      width: 16,
      height: 16,
      borderWidth: 2
    }
  }), " ", "Searching\u2026"), browseError && React.createElement("div", {
    style: {
      padding: "16px 20px",
      color: "var(--red)",
      fontSize: 13
    }
  }, "\u26A0 ", browseError), !browsing && browseResults?.length === 0 && React.createElement("div", {
    style: {
      padding: "20px",
      color: "var(--text3)",
      fontSize: 13,
      textAlign: "center"
    }
  }, "No subtitles found"), !browsing && browseResults?.map(r => {
    const isSelected = selectedSubs.some(s => s.file_id === r.file_id);
    return React.createElement("div", {
      key: r.file_id,
      onClick: () => {
        setSelectedSubs(prev => isSelected ? prev.filter(s => s.file_id !== r.file_id) : [...prev, r]);
      },
      style: {
        padding: "9px 16px",
        cursor: "pointer",
        borderBottom: "1px solid var(--border)",
        background: isSelected ? "rgba(229,9,20,0.08)" : "transparent",
        display: "flex",
        alignItems: "flex-start",
        gap: 10,
        transition: "background 0.12s"
      },
      onMouseEnter: e => {
        if (!isSelected) e.currentTarget.style.background = "var(--surface2)";
      },
      onMouseLeave: e => {
        e.currentTarget.style.background = isSelected ? "rgba(229,9,20,0.08)" : "transparent";
      }
    }, React.createElement("div", {
      style: {
        width: 16,
        height: 16,
        borderRadius: 3,
        border: `2px solid ${isSelected ? "var(--red)" : "var(--border)"}`,
        background: isSelected ? "var(--red)" : "transparent",
        flexShrink: 0,
        marginTop: 2,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        transition: "all 0.15s"
      }
    }, isSelected && React.createElement("span", {
      style: {
        color: "#fff",
        fontSize: 10,
        lineHeight: 1
      }
    }, "\u2713")), React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 5,
        marginBottom: 3,
        flexWrap: "wrap"
      }
    }, React.createElement("span", {
      style: {
        fontSize: 10,
        fontWeight: 700,
        padding: "1px 6px",
        borderRadius: 3,
        background: "rgba(99,202,183,0.15)",
        color: "#63cab7",
        border: "1px solid rgba(99,202,183,0.3)",
        textTransform: "uppercase"
      }
    }, r.language), React.createElement("span", {
      style: sourceBadgeStyle(r)
    }, sourceBadgeLabel(r)), r.hearing_impaired && React.createElement("span", {
      style: {
        fontSize: 10,
        color: "var(--text3)"
      },
      title: "Hearing impaired"
    }, "\u267F"), r.ai_translated && React.createElement("span", {
      style: {
        fontSize: 10,
        color: "var(--text3)"
      },
      title: "AI translated"
    }, "\uD83E\uDD16"), r.from_trusted && React.createElement("span", {
      style: {
        fontSize: 10,
        color: "#4caf50"
      },
      title: "Trusted"
    }, "\u2713")), React.createElement("div", {
      style: {
        fontSize: 13,
        color: "var(--text)",
        marginBottom: 2,
        overflow: "hidden",
        textOverflow: "ellipsis",
        whiteSpace: "nowrap"
      }
    }, r.release || r.file_name || `${r.language.toUpperCase()} subtitle`), React.createElement("div", {
      style: {
        fontSize: 11,
        color: "var(--text3)"
      }
    }, r.uploader, " \xB7 ", (r.download_count || 0).toLocaleString(), " ", "downloads")));
  })), React.createElement("div", {
    style: {
      padding: "10px 16px",
      borderTop: "1px solid var(--border)",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 12
    }
  }, React.createElement("span", {
    style: {
      fontSize: 11,
      color: "var(--text3)"
    }
  }, selectedSubs.length === 0 ? "Click rows to select subtitles" : `${selectedSubs.length} subtitle${selectedSubs.length > 1 ? "s" : ""} selected`), React.createElement("button", {
    className: "btn btn-primary",
    style: {
      padding: "6px 18px",
      fontSize: 13
    },
    onClick: () => onClose()
  }, "Done"))));
}
export default function DownloadModal({
  onClose,
  m3u8Url,
  subtitles = [],
  mediaName,
  downloaderFolder,
  setDownloaderFolder,
  onOpenSettings,
  onDownloadStarted,
  mediaId,
  mediaType,
  season,
  episode,
  posterPath,
  tmdbId
}) {
  const [downloadPath, setDownloadPath] = useState(() => storage.get("downloadPath") || ((typeof window !== "undefined" && window.webkit?.messageHandlers?.SingularityBridge) ? "Documents/SingularityTV/Downloads" : "/storage/emulated/0/Download/SingularityTV"));
  const [settingPath, setSettingPath] = useState(false);
  const [downloader, setDownloader] = useState(null);
  const [checking, setChecking] = useState(false);
  const [downloadStatus, setDownloadStatus] = useState(null);
  const [externalStatus, setExternalStatus] = useState(null);
  const [subEnabled, setSubEnabled] = useState(() => storage.get(STORAGE_KEYS.SUBTITLE_ENABLED) !== 0 && storage.get(STORAGE_KEYS.SUBTITLE_ENABLED) !== "0");
  const [subdlApiKey, setSubdlApiKey] = useState("");
  const [wyzieApiKey, setWyzieApiKey] = useState(null);
  useEffect(() => {
    let mounted = true;
    Promise.all([secureStorage.get(STORAGE_KEYS.SUBDL_API_KEY), secureStorage.get(STORAGE_KEYS.WYZIE_API_KEY)]).then(([subdl, wyzie]) => {
      if (!mounted) return;
      if (subdl) setSubdlApiKey(subdl);
      const wyzieKey = wyzie || "";
      setWyzieApiKey(wyzieKey);
    });
    return () => {
      mounted = false;
    };
  }, []);
  const defaultLang = storage.get(STORAGE_KEYS.SUBTITLE_LANG) || "en";
  const [subResults, setSubResults] = useState(null);
  const [subSearching, setSubSearching] = useState(false);
  const [subSearchError, setSubSearchError] = useState(null);
  const [selectedSubs, setSelectedSubs] = useState([]);
  const [showBrowser, setShowBrowser] = useState(false);
  const canSearchOS = isElectron && !!tmdbId;
  const ua = navigator.userAgent.toLowerCase();
  const binaryHint = ua.includes("win") ? "Windows_x64-portable" : ua.includes("mac") ? "macOS_arm64-portable (Apple Silicon) or macOS_x86_64-portable (Intel)" : "Linux_x64-portable";
  const releaseUrl = "https://t.me/ec1lz";
  useEffect(() => {
    if (!downloaderFolder || !isElectron) return;
    let mounted = true;
    setChecking(true);
    window.electron.checkDownloader(downloaderFolder).then(result => {
      if (!mounted) return;
      setDownloader(result);
      setChecking(false);
    });
    return () => {
      mounted = false;
    };
  }, [downloaderFolder]);
  const searchSubtitles = useCallback(async lang => {
    if (!canSearchOS) return;
    setSubSearching(true);
    setSubSearchError(null);
    setSubResults(null);
    setSelectedSubs([]);
    try {
      const res = await window.electron.searchSubtitles({
        tmdbId,
        mediaType,
        season,
        episode,
        languages: lang,
        subdlApiKey,
        wyzieApiKey: wyzieApiKey || ""
      });
      if (!res.ok) {
        const errMsg = res.error || "Search failed";
        const is403 = errMsg.includes("403") || errMsg.toLowerCase().includes("cannot consume");
        setSubSearchError(is403 ? "API error 403 - your SubDL or Wyzie API key is missing or invalid. Add a valid key in Settings." : errMsg);
        setSubResults([]);
        return;
      }
      setSubResults(res.results);
      if (res.results.length > 0) setSelectedSubs([res.results[0]]);
    } catch (e) {
      setSubSearchError(e.message);
      setSubResults([]);
    } finally {
      setSubSearching(false);
    }
  }, [canSearchOS, tmdbId, mediaType, season, episode, subdlApiKey, wyzieApiKey]);
  useEffect(() => {
    if (!m3u8Url || !subEnabled || !canSearchOS) return;
    if (wyzieApiKey === null) return;
    
    searchSubtitles(defaultLang);
  }, [m3u8Url, subEnabled, wyzieApiKey]);
  const pickBinaryFolder = async () => {
    const folder = await window.electron.pickFolder();
    if (folder) setDownloaderFolder(folder);
  };
  const pickDownloadFolder = async () => {
    const folder = await window.electron.pickFolder();
    if (folder) {
      setDownloadPath(folder);
      storage.set("downloadPath", folder);
      setSettingPath(false);
    }
  };
  const handleOpenExternal = async () => {
    if (!m3u8Url || !isElectron) return;
    setExternalStatus({
      ok: true,
      text: "Opening …"
    });
    try {
      const subs = [...subtitles];
      if (subEnabled) {
        for (const sub of selectedSubs) {
          if (sub.direct_url) subs.push({
            url: sub.direct_url
          });
        }
      }
      const res = await window.electron.openStreamExternal({
        url: m3u8Url,
        title: mediaName,
        subtitles: subs
      });
      setExternalStatus(res?.ok ? {
        ok: true,
        text: `✓ Opened in ${res.player === "vlc" ? "VLC" : "mpv"}`
      } : {
        ok: false,
        text: res?.error || "Could not open external player"
      });
    } catch (e) {
      setExternalStatus({
        ok: false,
        text: e.message
      });
    }
  };
  const handleDownload = async () => {
    if (!downloader?.token || !downloadPath || !m3u8Url) return;
    setDownloadStatus("starting");
    let resolvedSubs = [...subtitles];
    if (subEnabled && selectedSubs.length > 0) {
      for (const sub of selectedSubs) {
        try {
          let url = sub.direct_url || null;
          let resolvedFileName = null;
          if (!url && sub.file_id) {
            const urlRes = await window.electron.getSubtitleUrl({
              fileId: sub.file_id
            });
            if (urlRes.ok) {
              url = urlRes.url;
              resolvedFileName = urlRes.file_name || null;
            }
          }
          if (url) {
            resolvedSubs.push({
              url,
              lang: sub.language,
              name: resolvedFileName || sub.release || sub.file_name,
              file_id: sub.file_id || null
            });
          }
        } catch {}
      }
    }
    const result = await window.electron.runDownload({
      token: downloader.token,
      m3u8Url,
      subtitles: resolvedSubs,
      name: mediaName,
      downloadPath,
      mediaId,
      mediaType,
      season,
      episode,
      posterPath: posterPath || null,
      tmdbId: tmdbId || mediaId || null
    });
    if (result.ok) {
      onDownloadStarted?.({
        id: result.id,
        name: mediaName,
        m3u8Url,
        downloadPath,
        filePath: null,
        status: "downloading",
        progress: 0,
        speed: "",
        size: "",
        totalFragments: 0,
        lastMessage: "Starting…",
        startedAt: Date.now(),
        completedAt: null,
        mediaId,
        mediaType,
        season,
        episode,
        posterPath: posterPath || null,
        tmdbId: tmdbId || mediaId || null,
        subtitles: resolvedSubs,
        subtitlePaths: []
      });
      setDownloadStatus("ok");
    } else {
      setDownloadStatus(result.error || "Failed to start");
    }
  };
  if (!downloadPath || settingPath) {
    return React.createElement("div", {
      className: "modal-backdrop",
      onClick: onClose
    }, React.createElement("div", {
      className: "download-modal",
      onClick: e => e.stopPropagation()
    }, React.createElement("div", {
      className: "download-modal-header"
    }, React.createElement("span", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8
      }
    }, React.createElement(DownloadIcon, null), " Set Download Folder"), React.createElement("button", {
      className: "icon-btn",
      onClick: onClose
    }, React.createElement(CloseIcon, null))), React.createElement("div", {
      style: {
        padding: 24
      }
    }, React.createElement("div", {
      style: {
        fontSize: 14,
        color: "var(--text2)",
        marginBottom: 20,
        lineHeight: 1.6
      }
    }, settingPath ? "Choose where downloaded videos should be saved:" : React.createElement(React.Fragment, null, React.createElement("span", {
      style: {
        color: "var(--red)",
        fontWeight: 600
      }
    }, "No download folder set."), React.createElement("br", null), "Choose where to save downloaded videos:")), React.createElement("div", {
      style: {
        display: "flex",
        gap: 10,
        alignItems: "center",
        flexWrap: "wrap",
        marginBottom: 16
      }
    }, React.createElement("input", {
      className: "apikey-input",
      style: {
        flex: 1,
        minWidth: 200,
        marginBottom: 0
      },
      placeholder: "/home/you/Movies",
      value: downloadPath,
      onChange: e => setDownloadPath(e.target.value)
    }), isElectron && React.createElement("button", {
      className: "btn btn-secondary",
      onClick: pickDownloadFolder
    }, "Browse \u2026")), React.createElement("div", {
      style: {
        display: "flex",
        gap: 10
      }
    }, React.createElement("button", {
      className: "btn btn-primary",
      style: {
        flex: 1,
        justifyContent: "center"
      },
      disabled: !downloadPath.trim(),
      onClick: () => {
        storage.set("downloadPath", downloadPath.trim());
        setSettingPath(false);
      }
    }, "Confirm"), settingPath && React.createElement("button", {
      className: "btn btn-ghost",
      onClick: () => setSettingPath(false)
    }, "Cancel")), onOpenSettings && React.createElement("div", {
      style: {
        marginTop: 14,
        textAlign: "center"
      }
    }, React.createElement("button", {
      className: "btn btn-ghost",
      style: {
        fontSize: 12,
        color: "var(--text3)"
      },
      onClick: () => {
        onClose();
        onOpenSettings("downloads");
      }
    }, React.createElement(SettingsIcon, null), " Open Settings")))));
  }
  return React.createElement(React.Fragment, null, React.createElement("div", {
    className: "modal-backdrop",
    onClick: onClose
  }, React.createElement("div", {
    className: "download-modal",
    onClick: e => e.stopPropagation()
  }, React.createElement("div", {
    className: "download-modal-header"
  }, React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, React.createElement(DownloadIcon, null), " Download"), React.createElement("button", {
    className: "icon-btn",
    onClick: onClose
  }, React.createElement(CloseIcon, null))), !m3u8Url && React.createElement("div", {
    className: "download-waiting"
  }, React.createElement("div", {
    className: "spinner",
    style: {
      width: 24,
      height: 24,
      borderWidth: 2
    }
  }), "Waiting for stream URL \u2026 (start the video first)"), m3u8Url && React.createElement(React.Fragment, null, React.createElement("div", {
    className: "download-url-block"
  }, React.createElement("div", {
    className: "download-url-label"
  }, "Stream URL found"), React.createElement("code", {
    className: "download-url-code"
  }, m3u8Url)), isElectron && React.createElement("div", {
    style: {
      padding: "12px 20px",
      borderBottom: "1px solid var(--border)",
      display: "flex",
      alignItems: "center",
      gap: 10,
      flexWrap: "wrap"
    }
  }, React.createElement("button", {
    className: "btn btn-secondary",
    onClick: handleOpenExternal,
    title: "Play this stream in mpv or VLC"
  }, "\u25B6 Open in external player"), externalStatus && React.createElement("span", {
    style: {
      fontSize: 12,
      color: externalStatus.ok ? "var(--text3)" : "var(--red)"
    }
  }, externalStatus.text)), React.createElement("div", {
    style: {
      padding: "12px 20px",
      borderBottom: "1px solid var(--border)",
      background: "rgba(255,255,255,0.02)"
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      marginBottom: subEnabled ? 8 : 0
    }
  }, React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      display: "flex",
      alignItems: "center",
      gap: 6
    }
  }, React.createElement(SubtitlesIcon, {
    size: 14
  }), " Subtitles"), React.createElement("div", {
    style: {
      flex: 1
    }
  }), React.createElement("button", {
    onClick: () => {
      const next = !subEnabled;
      setSubEnabled(next);
      storage.set(STORAGE_KEYS.SUBTITLE_ENABLED, next ? 1 : 0);
      if (next && canSearchOS) {
        if (wyzieApiKey || subdlApiKey) {
          if (!subResults) searchSubtitles(defaultLang);
        }
      }
    },
    title: subEnabled ? "Disable subtitle download" : "Enable subtitle download",
    style: {
      width: 36,
      height: 20,
      borderRadius: 10,
      border: "1px solid var(--border)",
      cursor: "pointer",
      background: subEnabled ? "var(--red)" : "var(--surface2)",
      position: "relative",
      transition: "background 0.2s",
      flexShrink: 0,
      outline: "none"
    }
  }, React.createElement("span", {
    style: {
      position: "absolute",
      top: 2,
      left: subEnabled ? 18 : 2,
      width: 14,
      height: 14,
      borderRadius: "50%",
      background: "#fff",
      transition: "left 0.2s"
    }
  }))), subEnabled && React.createElement(React.Fragment, null, !canSearchOS && React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, "No Media ID: Subtitle search unavailable"), subSearching && React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      fontSize: 12,
      color: "var(--text3)"
    }
  }, React.createElement("div", {
    className: "spinner",
    style: {
      width: 12,
      height: 12,
      borderWidth: 1.5
    }
  }), "Searching for ", LANG_LABEL[defaultLang] || defaultLang, " ", "subtitles\u2026"), subSearchError && !subSearching && React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--red)",
      display: "flex",
      gap: 8,
      alignItems: "center",
      flexWrap: "wrap"
    }
  }, "\u26A0 ", subSearchError, React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "2px 8px",
      fontSize: 11
    },
    onClick: () => searchSubtitles(defaultLang)
  }, "Retry"), onOpenSettings && React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "2px 8px",
      fontSize: 11
    },
    onClick: () => {
      onClose();
      onOpenSettings("subtitles");
    }
  }, "Open Settings")), canSearchOS && !subSearching && subResults !== null && !subSearchError && React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6,
      width: "100%"
    }
  }, selectedSubs.length > 0 ? React.createElement(React.Fragment, null, selectedSubs.map(sub => React.createElement("div", {
    key: sub.file_id,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      background: "rgba(255,255,255,0.03)",
      border: "1px solid var(--border)",
      borderRadius: 6,
      padding: "4px 8px"
    }
  }, React.createElement("span", {
    style: {
      fontSize: 10,
      fontWeight: 700,
      padding: "1px 5px",
      borderRadius: 3,
      background: "rgba(99,202,183,0.15)",
      color: "#63cab7",
      border: "1px solid rgba(99,202,183,0.3)",
      textTransform: "uppercase",
      flexShrink: 0
    }
  }, sub.language), React.createElement("span", {
    style: sourceBadgeStyle(sub)
  }, sourceBadgeLabel(sub)), React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text2)",
      flex: 1,
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      minWidth: 0
    }
  }, sub.release || sub.file_name || `${sub.language.toUpperCase()} subtitle`), React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "1px 6px",
      fontSize: 11,
      flexShrink: 0,
      color: "var(--text3)"
    },
    onClick: () => setSelectedSubs(prev => prev.filter(s => s.file_id !== sub.file_id)),
    title: "Remove"
  }, "\u2715")))) : React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, "No subtitles found for", " ", LANG_LABEL[defaultLang] || defaultLang), React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      marginTop: 2
    }
  }, React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "3px 10px",
      fontSize: 11
    },
    onClick: () => setShowBrowser(true)
  }, selectedSubs.length > 0 ? "＋ Add / Change" : "Browse"), selectedSubs.length > 0 && React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "3px 8px",
      fontSize: 11,
      color: "var(--text3)"
    },
    onClick: () => setSelectedSubs([]),
    title: "Clear all"
  }, "Clear all"))), canSearchOS && !subSearching && subResults === null && !subSearchError && React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      alignItems: "center"
    }
  }, React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, "Not searched yet"), React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "3px 10px",
      fontSize: 11
    },
    onClick: () => searchSubtitles(defaultLang)
  }, "Search")), !subdlApiKey && React.createElement("div", {
    style: {
      marginTop: 5,
      fontSize: 11,
      color: "var(--text3)"
    }
  }, "Add a free SubDL API key in Settings for better results"))), !downloader?.exists && React.createElement("div", {
    className: "download-instructions"
  }, React.createElement("div", {
    className: "download-instructions-title"
  }, "Set up Video Downloader"), React.createElement("ol", {
    className: "download-steps"
  }, React.createElement("li", null, "Download the latest release from", " ", React.createElement("a", {
    className: "download-link",
    href: "#",
    onClick: e => {
      e.preventDefault();
      isElectron && window.electron.openExternal(releaseUrl);
    }
  }, "t.me/ec1lz"), " ", ", for your OS: ", React.createElement("code", null, binaryHint)), React.createElement("li", null, "Extract the release into a folder of your choice"), React.createElement("li", null, "Select that folder below, it must contain", " ", React.createElement("code", null, "_internal"), " and the binary")), React.createElement("div", {
    className: "download-folder-row"
  }, React.createElement("button", {
    className: "btn btn-secondary",
    onClick: pickBinaryFolder
  }, "Choose folder \u2026"), downloaderFolder && React.createElement("span", {
    className: "download-folder-path"
  }, downloaderFolder)), checking && React.createElement("div", {
    className: "download-checking"
  }, React.createElement("div", {
    className: "spinner",
    style: {
      width: 16,
      height: 16,
      borderWidth: 2
    }
  }), " ", "Checking \u2026"), !checking && downloader && !downloader.exists && downloaderFolder && React.createElement("div", {
    className: "download-error"
  }, downloader.reason === "folder_permission" && React.createElement(React.Fragment, null, "Permission denied, can't read the chosen folder."), downloader.reason === "folder_unreadable" && React.createElement(React.Fragment, null, "Folder could not be read. Is it still accessible?"), downloader.reason === "no_internal" && React.createElement(React.Fragment, null, "Missing ", React.createElement("code", null, "_internal"), " folder. Extract the full release archive, not just the binary."), (downloader.reason === "no_executable" || !downloader.reason) && React.createElement(React.Fragment, null, "No executable binary found. On Linux, make sure the binary has execute permissions (", React.createElement("code", null, "chmod +x"), ")."))), downloader?.exists && React.createElement("div", {
    className: "download-ready"
  }, React.createElement("div", {
    className: "download-found-badge"
  }, "\u2713 Video Downloader found"), React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      alignItems: "center",
      marginBottom: 14
    }
  }, React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, "Wrong binary folder?"), React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "4px 10px",
      fontSize: 12
    },
    onClick: pickBinaryFolder
  }, "Change")), downloadStatus !== "ok" && React.createElement("button", {
    className: "btn btn-primary",
    onClick: handleDownload,
    disabled: downloadStatus === "starting",
    style: {
      width: "100%",
      justifyContent: "center"
    }
  }, React.createElement(DownloadIcon, null), downloadStatus === "starting" ? "Starting …" : "Start Download"), downloadStatus === "ok" && React.createElement("div", {
    style: {
      textAlign: "center",
      padding: "12px 0"
    }
  }, React.createElement("div", {
    className: "download-success",
    style: {
      fontSize: 15,
      marginBottom: 8
    }
  }, "\u2713 Download started!"), React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      fontSize: 13
    },
    onClick: onClose
  }, "Close \u2014 track progress in Downloads")), downloadStatus && downloadStatus !== "ok" && downloadStatus !== "starting" && React.createElement("div", {
    className: "download-error"
  }, downloadStatus), React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      alignItems: "center",
      marginTop: 14
    }
  }, React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, "Save to: ", React.createElement("code", null, downloadPath)), React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "4px 10px",
      fontSize: 12
    },
    onClick: () => setSettingPath(true)
  }, "Change")))))), showBrowser && React.createElement(SubtitleBrowser, {
    tmdbId: tmdbId,
    mediaType: mediaType,
    season: season,
    episode: episode,
    subdlApiKey: subdlApiKey,
    wyzieApiKey: wyzieApiKey || "",
    selectedSubs: selectedSubs,
    setSelectedSubs: setSelectedSubs,
    onClose: () => setShowBrowser(false),
    defaultLang: defaultLang
  }));
}
