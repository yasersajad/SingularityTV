import { useEffect } from "react";
import { CloseIcon, ShieldBlockIcon } from "./Icons";
export default function BlockedStatsModal({
  sessionDomains,
  sessionTotal,
  alltimeTotal,
  onClose
}) {
  useEffect(() => {
    const handler = e => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onClose]);
  return React.createElement("div", {
    className: "blocked-modal-overlay",
    onClick: onClose
  }, React.createElement("div", {
    className: "blocked-modal",
    onClick: e => e.stopPropagation()
  }, React.createElement("div", {
    className: "blocked-modal-header"
  }, React.createElement("div", {
    className: "blocked-modal-title"
  }, React.createElement(ShieldBlockIcon, {
    size: 15
  }), "Ads & Trackers Blocked"), React.createElement("button", {
    className: "blocked-modal-close",
    onClick: onClose,
    title: "Close"
  }, React.createElement(CloseIcon, null))), React.createElement("div", {
    className: "blocked-modal-subtitle"
  }, sessionTotal > 0 ? `${sessionTotal} ad/tracker request${sessionTotal === 1 ? "" : "s"} blocked this session` : "Start playing content to see blocked ads & trackers."), React.createElement("div", {
    className: "blocked-modal-list"
  }, sessionDomains.length === 0 ? React.createElement("div", {
    className: "blocked-modal-empty"
  }, "No ads or trackers blocked yet, play something to start.") : sessionDomains.map(([domain, count]) => React.createElement("div", {
    key: domain,
    className: "blocked-modal-row"
  }, React.createElement("span", {
    className: "blocked-modal-domain"
  }, domain), React.createElement("span", {
    className: "blocked-modal-count"
  }, count.toLocaleString())))), React.createElement("div", {
    className: "blocked-modal-footer"
  }, React.createElement(ShieldBlockIcon, {
    size: 13
  }), "All-time:\xA0", React.createElement("strong", null, alltimeTotal.toLocaleString(), " ad & tracker request", alltimeTotal === 1 ? "" : "s"), "\xA0blocked")));
}
