import { DownloadIcon } from "./Icons";
export default function CloseConfirmModal({
  count,
  onConfirm,
  onCancel
}) {
  return React.createElement("div", {
    className: "close-confirm-overlay"
  }, React.createElement("div", {
    className: "close-confirm-modal"
  }, React.createElement("div", {
    className: "close-confirm-icon-wrap"
  }, React.createElement("div", {
    className: "close-confirm-icon-ring"
  }, React.createElement(DownloadIcon, null))), React.createElement("div", {
    className: "close-confirm-title"
  }, "Download", count > 1 ? "s" : "", " in Progress"), React.createElement("div", {
    className: "close-confirm-body"
  }, React.createElement("span", {
    className: "close-confirm-count"
  }, count, " active download", count > 1 ? "s" : ""), " ", "will be cancelled and incomplete files will be deleted."), React.createElement("div", {
    className: "close-confirm-actions"
  }, React.createElement("button", {
    className: "btn close-confirm-btn-cancel",
    onClick: onCancel
  }, "Keep Downloading"), React.createElement("button", {
    className: "btn close-confirm-btn-confirm",
    onClick: onConfirm
  }, "Cancel & Close App"))));
}
