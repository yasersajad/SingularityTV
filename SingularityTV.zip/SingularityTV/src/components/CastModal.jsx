import { useEffect, useMemo } from "react";
import { imgUrl } from "../utils/api";
const normalizeCastPerson = person => {
  if (Array.isArray(person.roles)) {
    return {
      ...person,
      characterList: person.roles.map(r => r.character).filter(Boolean)
    };
  }
  return {
    ...person,
    characterList: person.character ? [person.character] : []
  };
};
const normalizeCrewPerson = person => {
  if (Array.isArray(person.jobs)) {
    return {
      ...person,
      jobList: person.jobs.map(j => j.job)
    };
  }
  return {
    ...person,
    jobList: person.job ? [person.job] : []
  };
};
const dedupeById = people => {
  const seen = new Set();
  return people.filter(p => {
    if (seen.has(p.id)) return false;
    seen.add(p.id);
    return true;
  });
};
const getDirectors = crew => dedupeById(crew.map(normalizeCrewPerson).filter(person => person.jobList.includes("Director")));
const getWriters = crew => {
  const writerJobs = ["Screenplay", "Writer", "Story", "Novel"];
  return dedupeById(crew.map(normalizeCrewPerson).filter(person => person.jobList.some(job => writerJobs.includes(job))));
};
function PersonCard({
  person
}) {
  const subtitle = person.characterList?.join(", ") || person.jobList?.join(", ") || "";
  return React.createElement("div", {
    className: "cast-person"
  }, person.profile_path ? React.createElement("img", {
    src: imgUrl(person.profile_path, "w185"),
    alt: person.name,
    className: "cast-person-photo",
    loading: "lazy"
  }) : React.createElement("div", {
    className: "cast-person-photo cast-person-photo--fallback"
  }, person.name?.[0] ?? "?"), React.createElement("div", {
    className: "cast-person-name"
  }, person.name), React.createElement("div", {
    className: "cast-person-character"
  }, subtitle));
}
function Section({
  title,
  people,
  limit
}) {
  if (!people.length) return null;
  return React.createElement("div", {
    className: "cast-section"
  }, React.createElement("div", {
    className: "cast-section-title"
  }, title), React.createElement("div", {
    className: "cast-grid"
  }, people.slice(0, limit).map(person => React.createElement(PersonCard, {
    key: person.id,
    person: person
  }))));
}
export default function CastModal({
  onClose,
  cast = [],
  crew = [],
  creators = [],
  title
}) {
  useEffect(() => {
    const handler = e => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onClose]);
  useEffect(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);
  const directors = useMemo(() => getDirectors(crew), [crew]);
  const writers = useMemo(() => getWriters(crew), [crew]);
  const normalizedCast = useMemo(() => dedupeById(cast.map(normalizeCastPerson)), [cast]);
  return React.createElement("div", {
    className: "cast-overlay",
    onClick: onClose
  }, React.createElement("div", {
    className: "cast-modal",
    role: "dialog",
    "aria-modal": "true",
    "aria-label": `Cast & Crew — ${title}`,
    onClick: e => e.stopPropagation()
  }, React.createElement("div", {
    className: "cast-modal-header"
  }, React.createElement("span", {
    className: "cast-modal-title"
  }, "\uD83C\uDFAD Cast & Crew \u2014 ", title), React.createElement("button", {
    className: "cast-close-btn",
    onClick: onClose,
    "aria-label": "Close"
  }, "\u2715")), React.createElement("div", {
    className: "cast-modal-body"
  }, React.createElement(Section, {
    title: "Creators",
    people: creators,
    limit: 4
  }), React.createElement(Section, {
    title: "Directors",
    people: directors,
    limit: 4
  }), React.createElement(Section, {
    title: "Writers",
    people: writers,
    limit: 4
  }), normalizedCast.length > 0 ? React.createElement(Section, {
    title: "Cast",
    people: normalizedCast,
    limit: 20
  }) : React.createElement("div", {
    className: "cast-empty"
  }, "No cast information available."))));
}
