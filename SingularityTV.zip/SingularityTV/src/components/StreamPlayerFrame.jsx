import { forwardRef, useImperativeHandle, useRef, useEffect } from "react";
const StreamPlayerFrame = forwardRef(function StreamPlayerFrame({
  src,
  style,
  tabIndex
}, ref) {
  const iframeRef = useRef(null);
  const listenersRef = useRef(new Map());
  useImperativeHandle(ref, () => ({
    get src() {
      return iframeRef.current?.src || "";
    },
    set src(val) {
      if (iframeRef.current) iframeRef.current.src = val;
    },
    getWebContentsId() {
      return 1;
    },
    async executeJavaScript(code) {
      try {
        const win = iframeRef.current?.contentWindow;
        if (win) {
          return win.eval(code);
        }
      } catch {
        if (window.AndroidBridge?.evaluateInPlayerFrame) {
          try {
            const res = window.AndroidBridge.evaluateInPlayerFrame(code);
            return res ? JSON.parse(res) : null;
          } catch {}
        }
      }
      return null;
    },
    addEventListener(type, handler) {
      if (!listenersRef.current.has(type)) {
        listenersRef.current.set(type, new Set());
      }
      listenersRef.current.get(type).add(handler);
      const el = iframeRef.current;
      if (!el) return;
      if (type === "did-finish-load" || type === "dom-ready") {
        el.addEventListener("load", handler);
      } else if (type === "did-fail-load") {
        el.addEventListener("error", handler);
      }
    },
    removeEventListener(type, handler) {
      listenersRef.current.get(type)?.delete(handler);
      const el = iframeRef.current;
      if (!el) return;
      if (type === "did-finish-load" || type === "dom-ready") {
        el.removeEventListener("load", handler);
      } else if (type === "did-fail-load") {
        el.removeEventListener("error", handler);
      }
    }
  }));
  useEffect(() => {
    const el = iframeRef.current;
    if (!el || !src || src === "about:blank") return;
    const t = setTimeout(() => {
      const loadSet = listenersRef.current.get("did-finish-load");
      if (loadSet) {
        for (const fn of loadSet) {
          try {
            fn();
          } catch {}
        }
      }
    }, 900);
    return () => clearTimeout(t);
  }, [src]);
  return React.createElement("iframe", {
    ref: iframeRef,
    src: src || "about:blank",
    allow: "autoplay; fullscreen; encrypted-media; picture-in-picture",
    allowFullScreen: true,
    referrerPolicy: "origin",
    tabIndex: tabIndex,
    style: {
      position: "absolute",
      inset: 0,
      width: "100%",
      height: "100%",
      border: "none",
      background: "#000",
      ...style
    }
  });
});
export default StreamPlayerFrame;
