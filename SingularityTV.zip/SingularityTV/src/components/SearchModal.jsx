import React, { useState, useEffect, useRef, useCallback, useMemo, memo } from "react";
import { tmdbFetch, imgUrl, resolveGenreFromQuery } from "../utils/api";
import { SearchIcon, CloseIcon, WatchedIcon } from "./Icons";
import { setGamepadFocus } from "../utils/gamepadSpatialNav";

const EN_ROWS = [
  ["a", "b", "c", "d", "e", "f"],
  ["g", "h", "i", "j", "k", "l"],
  ["m", "n", "o", "p", "q", "r"],
  ["s", "t", "u", "v", "w", "x"],
  ["y", "z", "1", "2", "3", "4"],
  ["5", "6", "7", "8", "9", "0"]
];

const AR_ROWS = [
  ["ا", "ب", "ت", "ث", "ج", "ح"],
  ["خ", "د", "ذ", "ر", "ز", "س"],
  ["ش", "ص", "ض", "ط", "ظ", "ع"],
  ["غ", "ف", "ق", "ك", "ل", "م"],
  ["ن", "ه", "و", "ي", "ة", "ى"],
  ["أ", "إ", "آ", "ؤ", "ئ", "ء"]
];

const SearchResultCard = memo(function SearchResultCard({ item, onSelect, watched }) {
  const [imgBroken, setImgBroken] = useState(false);
  const thumb = item.backdrop_path
    ? imgUrl(item.backdrop_path, "w300")
    : item.poster_path
      ? imgUrl(item.poster_path, "w185")
      : null;
  const title = item.title || item.name;
  if (!thumb || imgBroken || !title) return null;
  const wKey = item.media_type === "tv" ? `tv_${item.id}` : `movie_${item.id}`;
  const isWatched = !!watched?.[wKey];
  return (
    <button className={`nf-result-card${isWatched ? " ep-watched" : ""}`} onClick={() => onSelect(item)}>
      <div className="nf-result-thumb">
        <img src={thumb} alt={title} loading="lazy" decoding="async" draggable={false} onError={() => setImgBroken(true)} />
        <span className="nf-result-type">
          {item.media_type === "tv" ? "SERIES" : "MOVIE"}
        </span>
        {isWatched && (
          <div className="card-watched-badge">
            <WatchedIcon size={20} />
          </div>
        )}
      </div>
      <div className="nf-result-title">{title}</div>
    </button>
  );
});

const KeyboardPanel = memo(function KeyboardPanel({
  firstKeyRef,
  langMode,
  onToggleLang,
  onAppend,
  onBackspace,
  onClear
}) {
  const rows = langMode === "ar" ? AR_ROWS : EN_ROWS;
  return (
    <div className="nf-keyboard-panel">
      <div className="nf-keyboard-actions">
        <button
          ref={firstKeyRef}
          className="nf-key nf-key--action"
          onClick={onToggleLang}
        >
          {langMode === "ar" ? "EN" : "عربي"}
        </button>
        <button className="nf-key nf-key--action nf-key--space" onClick={() => onAppend(" ")}>
          ␣
        </button>
        <button className="nf-key nf-key--action" onClick={onBackspace}>
          ⌫
        </button>
        <button className="nf-key nf-key--action" onClick={onClear}>
          Clear
        </button>
      </div>

      <div className="nf-keyboard-grid" dir={langMode === "ar" ? "rtl" : "ltr"}>
        {rows.flat().map(ch => (
          <button key={ch} className="nf-key" onClick={() => onAppend(ch)}>
            {ch}
          </button>
        ))}
      </div>
    </div>
  );
});

export default function SearchModal({
  apiKey,
  onSelect,
  onClose,
  offline,
  trending = [],
  trendingTV = [],
  watched = {},
  initialQuery = "",
  onQueryChange,
  initialLangMode = "en",
  onLangModeChange
}) {
  const [query, setQueryState] = useState(initialQuery || "");
  const [langMode, setLangModeState] = useState(initialLangMode || "en");
  const setQuery = useCallback(val => {
    setQueryState(prev => {
      const next = typeof val === "function" ? val(prev) : val;
      onQueryChange?.(next);
      return next;
    });
  }, [onQueryChange]);
  const setLangMode = useCallback(val => {
    setLangModeState(prev => {
      const next = typeof val === "function" ? val(prev) : val;
      onLangModeChange?.(next);
      return next;
    });
  }, [onLangModeChange]);
  const [results, setResults] = useState([]);
  const [fallbackTrending, setFallbackTrending] = useState([]);
  const [loading, setLoading] = useState(false);
  const firstKeyRef = useRef(null);

  useEffect(() => {
    const tid = setTimeout(() => {
      if (firstKeyRef.current) setGamepadFocus(firstKeyRef.current, { scroll: false });
    }, 60);
    return () => clearTimeout(tid);
  }, []);

  const combinedTrending = useMemo(() => {
    const out = [];
    const seen = new Set();
    const maxLen = Math.max(trending.length, trendingTV.length);
    for (let i = 0; i < maxLen; i++) {
      const m = trending[i];
      if (m && m.id && !seen.has(`movie_${m.id}`)) {
        seen.add(`movie_${m.id}`);
        out.push({ ...m, media_type: m.media_type || "movie" });
      }
      const t = trendingTV[i];
      if (t && t.id && !seen.has(`tv_${t.id}`)) {
        seen.add(`tv_${t.id}`);
        out.push({ ...t, media_type: t.media_type || "tv" });
      }
    }
    if (out.length > 0) return out;
    return fallbackTrending;
  }, [trending, trendingTV, fallbackTrending]);

  useEffect(() => {
    if (offline || trending.length > 0 || trendingTV.length > 0) return;
    let mounted = true;
    const controller = new AbortController();
    tmdbFetch("/trending/all/day", apiKey, { signal: controller.signal })
      .then(data => {
        if (!mounted) return;
        const items = (data.results || []).filter(
          x => x && x.id && (x.media_type === "movie" || x.media_type === "tv")
        );
        setFallbackTrending(items);
      })
      .catch(() => {});
    return () => {
      mounted = false;
      controller.abort();
    };
  }, [offline, trending.length, trendingTV.length, apiKey]);

  useEffect(() => {
    const trimmed = query.trim();
    if (trimmed.length < 2) {
      setResults([]);
      setLoading(false);
      return;
    }
    let mounted = true;
    const controller = new AbortController();
    const hasArabic = /[\u0600-\u06FF]/.test(trimmed);

    const timer = setTimeout(async () => {
      setLoading(true);
      try {
        const langParam = hasArabic ? "&language=ar-SA" : "";
        const data = await tmdbFetch(
          `/search/multi?query=${encodeURIComponent(trimmed)}&page=1${langParam}`,
          apiKey,
          { signal: controller.signal }
        );
        const raw = data.results || [];
        const collected = [];
        const seen = new Set();
        const pushUnique = item => {
          if (!item || !item.id) return;
          const mt = item.media_type || (item.first_air_date ? "tv" : "movie");
          if (mt !== "movie" && mt !== "tv") return;
          const key = `${mt}_${item.id}`;
          if (seen.has(key)) return;
          seen.add(key);
          collected.push({ ...item, media_type: mt });
        };

        const people = raw.filter(r => r.media_type === "person");
        for (const r of raw) {
          if (r.media_type === "person") {
            for (const kf of r.known_for || []) {
              pushUnique(kf);
            }
          } else {
            pushUnique(r);
          }
        }

        if (people.length > 0 && collected.length < 12) {
          try {
            const credits = await tmdbFetch(
              `/person/${people[0].id}/combined_credits?${hasArabic ? "language=ar-SA" : ""}`,
              apiKey,
              { signal: controller.signal }
            );
            const cast = (credits.cast || [])
              .sort((a, b) => (b.popularity || 0) - (a.popularity || 0))
              .slice(0, 12);
            for (const c of cast) {
              pushUnique(c);
            }
          } catch {}
        }

        if (mounted) {
          setResults(collected.slice(0, 120));
        }
      } catch {}
      if (mounted) setLoading(false);
    }, 380);

    return () => {
      mounted = false;
      clearTimeout(timer);
      controller.abort();
    };
  }, [query, apiKey]);

  const appendChar = useCallback(ch => {
    setQuery(prev => prev + ch);
  }, []);

  const handleBackspace = useCallback(() => {
    setQuery(prev => prev.slice(0, -1));
  }, []);

  const handleClear = useCallback(() => {
    setQuery("");
  }, []);

  const toggleLang = useCallback(() => {
    setLangMode(prev => (prev === "en" ? "ar" : "en"));
  }, []);

  const handleSelect = useCallback(
    item => {
      try {
        const qTrim = query.trim();
        if (qTrim.length >= 2) {
          const raw = localStorage.getItem("streambert_searchHistory");
          const prev = raw ? JSON.parse(raw) : [];
          const next = [qTrim, ...prev.filter(x => x !== qTrim)].slice(0, 25);
          localStorage.setItem("streambert_searchHistory", JSON.stringify(next));
          window.dispatchEvent(new CustomEvent("streambert:cloud-sync-needed"));
        }
      } catch {}
      onSelect(item);
    },
    [onSelect, query]
  );

  const isSearching = query.trim().length >= 2;
  const displayItems = isSearching ? results : combinedTrending.slice(0, 12);

  return (
    <div
      className="modal-overlay nf-search-overlay"
      onClick={e => e.target === e.currentTarget && onClose()}
    >
      <div className="nf-search-shell">
        <div className="nf-search-left">
          <KeyboardPanel
            firstKeyRef={firstKeyRef}
            langMode={langMode}
            onToggleLang={toggleLang}
            onAppend={appendChar}
            onBackspace={handleBackspace}
            onClear={handleClear}
          />

          <div className="nf-trending-panel">
            <div className="nf-trending-heading">Trending Now</div>
            <div className="nf-trending-list">
              {combinedTrending.slice(0, 8).map(item => (
                <button
                  key={`trend_${item.media_type}_${item.id}`}
                  className="nf-trending-chip"
                  onClick={() => handleSelect(item)}
                >
                  <span className="nf-trending-name">{item.title || item.name}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="nf-search-right">
          <div className="nf-search-bar">
            <SearchIcon />
            <div
              className="nf-search-query-display"
              dir={/[\u0600-\u06FF]/.test(query) ? "rtl" : "ltr"}
            >
              {query ? (
                <span className="nf-search-query-text">{query}</span>
              ) : (
                <span className="nf-search-placeholder">Search movies, actors, shows...</span>
              )}
            </div>
            <button
              className="nf-player-btn nf-search-close-btn"
              data-gamepad-close="1"
              onClick={onClose}
              aria-label="Close"
            >
              <CloseIcon />
            </button>
          </div>

          <div className="nf-search-section-label">
            {isSearching ? (resolveGenreFromQuery(query) ? `Results for "${query}" · ${resolveGenreFromQuery(query)}` : `Results for "${query}"`) : "Top Searches"}
          </div>

          {offline && (
            <div className="nf-search-empty">No internet connection. Search is unavailable offline.</div>
          )}

          {!offline && loading && (
            <div className="loader">
              <div className="spinner" />
            </div>
          )}

          {!offline && !loading && isSearching && results.length === 0 && (
            <div className="nf-search-empty">No results found for "{query}"</div>
          )}

          {!offline && !loading && (
            <div className="nf-results-grid">
              {displayItems.map(r => (
                <SearchResultCard
                  key={`${r.media_type}_${r.id}`}
                  item={r}
                  onSelect={handleSelect}
                  watched={watched}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
