import React, { useState, useEffect } from "react";
import { getGoogleAccount } from "../utils/googleSync";
import {
  SingularityTVLogo,
  SearchIcon,
  HomeIcon,
  HistoryIcon,
  SettingsIcon,
  DownloadsQueueIcon
} from "./Icons";

export default function TopNav({
  page,
  onNavigate,
  onSearch,
  activeDownloads
}) {
  const [timeStr, setTimeStr] = useState(() =>
    new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })
  );
  const [googleUser, setGoogleUser] = useState(() => getGoogleAccount());
  useEffect(() => {
    const onAcc = () => setGoogleUser(getGoogleAccount());
    window.addEventListener("streambert:google-account-changed", onAcc);
    return () => window.removeEventListener("streambert:google-account-changed", onAcc);
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeStr(new Date().toLocaleTimeString([], { hour: "numeric", minute: "2-digit" }));
    }, 30000);
    return () => clearInterval(timer);
  }, []);

  const navItems = [
    { id: "home", label: "Home", icon: <HomeIcon /> },
    { id: "history", label: "Library", icon: <HistoryIcon /> },
    {
      id: "downloads",
      label: "Downloads",
      icon: <DownloadsQueueIcon />,
      badge: activeDownloads > 0 ? activeDownloads : null
    }
  ];

  return (
    <header className="topnav">
      <div className="topnav-left">
        <button
          className="topnav-brand topnav-btn"
          onClick={() => onNavigate("home")}
          aria-label="SingularityTV Home"
        >
          <SingularityTVLogo style={{ width: 26, height: 26 }} />
        </button>

        <button className="topnav-search-btn topnav-btn" onClick={onSearch}>
          <SearchIcon />
          <span>Search</span>
        </button>

        <nav className="topnav-links" aria-label="Primary Navigation">
          {navItems.map(item => (
            <button
              key={item.id}
              className={`topnav-link topnav-btn${page === item.id ? " active" : ""}`}
              onClick={() => onNavigate(item.id)}
            >
              <span className="topnav-link-icon">{item.icon}</span>
              <span>{item.label}</span>
              {item.badge && <span className="topnav-badge">{item.badge}</span>}
            </button>
          ))}
        </nav>
      </div>

      <div className="topnav-right">
        <button
          className="topnav-link topnav-btn"
          onClick={() => onNavigate("settings", { section: "account" })}
          title={googleUser ? `Signed in as ${googleUser.email}` : "Sign in with Google"}
          style={{ padding: "5px 11px", gap: 7 }}
        >
          <span
            style={{
              width: 22,
              height: 22,
              borderRadius: "50%",
              background: googleUser ? "var(--red)" : "rgba(255,255,255,0.14)",
              color: "#fff",
              fontSize: 11,
              fontWeight: 800,
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center"
            }}
          >
            {googleUser ? (googleUser.name || googleUser.email || "G").charAt(0).toUpperCase() : "G"}
          </span>
          <span style={{ fontSize: 12, maxWidth: 96, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
            {googleUser ? googleUser.name : "Sign In"}
          </span>
        </button>
        <button
          className={`topnav-icon-btn topnav-btn${page === "settings" ? " active" : ""}`}
          onClick={() => onNavigate("settings")}
          aria-label="Settings"
        >
          <SettingsIcon />
        </button>
        <div className="topnav-clock">{timeStr}</div>
      </div>
    </header>
  );
}
