import React, { useState, useEffect } from "react";
import { imgUrl } from "../utils/api";
import { PlayIcon, StarIcon } from "./Icons";

export default function HeroBanner({ items = [], onSelect, ratingsMap = {} }) {
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    if (items.length <= 1) return;
    const interval = setInterval(() => {
      setActiveIndex(prev => (prev + 1) % items.length);
    }, 7000);
    return () => clearInterval(interval);
  }, [items.length]);

  const item = items[activeIndex] || items[0];
  if (!item) return null;

  const title = item.title || item.name;
  const year = (item.release_date || item.first_air_date || "").slice(0, 4);
  const mediaType = item.media_type === "tv" ? "tv" : "movie";
  const ratingInfo = ratingsMap[`${mediaType}_${item.id}`] || {};
  const backdrop = imgUrl(item.backdrop_path || item.poster_path, "original");

  return (
    <section className="hero-banner">
      <div
        className="hero-banner-bg"
        style={{ backgroundImage: backdrop ? `url(${backdrop})` : "none" }}
      />
      <div className="hero-banner-scrim" />

      <div className="hero-banner-inner">
        <div className="hero-banner-content">
          <div className="hero-banner-pills">
            <span className="hero-pill hero-pill--accent">FEATURED</span>
            <span className="hero-pill">{mediaType === "tv" ? "SERIES" : "MOVIE"}</span>
            {year && <span className="hero-pill">{year}</span>}
            {ratingInfo.cert && <span className="hero-pill">{ratingInfo.cert}</span>}
            {item.vote_average > 0 && (
              <span className="hero-pill hero-pill--score">
                <StarIcon size={11} />
                {item.vote_average.toFixed(1)}
              </span>
            )}
          </div>

          <h1 className="hero-banner-title">{title}</h1>
          {item.overview && <p className="hero-banner-overview">{item.overview}</p>}

          <div className="hero-actions">
            <button className="btn btn-primary hero-action-btn" onClick={() => onSelect(item)}>
              <PlayIcon />
              <span>Watch Now</span>
            </button>
            <button className="btn btn-secondary hero-action-btn" onClick={() => onSelect(item)}>
              <span>More Info</span>
            </button>
          </div>
        </div>

        <div className="hero-banner-right">
          {items.length > 1 && (
            <div className="hero-dots-pill">
              {items.map((slide, idx) => (
                <button
                  key={slide.id || idx}
                  className={`hero-dot${idx === activeIndex ? " active" : ""}`}
                  onClick={() => setActiveIndex(idx)}
                  aria-label={`Featured item ${idx + 1}`}
                />
              ))}
            </div>
          )}
          <div className="hero-platform-badge">
            <span className="hero-platform-logo">SINGULARITY TV</span>
            <span className="hero-platform-sub">4K HDR · Instant Stream</span>
          </div>
        </div>
      </div>
    </section>
  );
}
