import { useEffect, useRef, useState, useCallback } from "react";
import { CloseIcon, ExternalLinkIcon } from "./Icons";
import { storage } from "../utils/storage";
import StreamPlayerFrame from "./StreamPlayerFrame";
export const DEFAULT_INVIDIOUS_BASE = "https://inv.nadeko.net";
const FALLBACK_INSTANCES = ["https://invidious.privacyredirect.com", "https://inv.tux.pizza", "https://yt.cdaut.de", "https://invidious.lunar.icu", "https://invidious.protokolla.fi", "https://invidious.nerdvpn.de", "https://iv.melmac.space", "https://invidious.perennialte.ch"];
export function getInvidiousBase() {
  return (storage.get("invidiousBase") || DEFAULT_INVIDIOUS_BASE).replace(/\/$/, "");
}
export default function TrailerModal({
  trailerKey,
  title,
  onClose
}) {
  const webviewRef = useRef(null);
  const [currentSrc, setCurrentSrc] = useState(null);
  const [statusMsg, setStatusMsg] = useState("Loading trailer…");
  const [failed, setFailed] = useState(false);
  const instanceIndexRef = useRef(-1);
  const tryNextInstance = useCallback(() => {
    const preferred = getInvidiousBase();
    const list = [preferred, ...FALLBACK_INSTANCES.filter(i => i !== preferred)];
    instanceIndexRef.current += 1;
    const idx = instanceIndexRef.current;
    if (idx >= list.length) {
      setFailed(true);
      setStatusMsg("All Invidious instances failed. Try setting a custom instance in Settings.");
      return;
    }
    const instance = list[idx];
    const label = instance.replace(/^https?:\/\//, "");
    setStatusMsg(idx === 0 ? "Loading trailer…" : `Trying ${label}…`);
    setCurrentSrc(`${instance}/embed/${trailerKey}?autoplay=1&listen=0`);
  }, [trailerKey]);
  useEffect(() => {
    instanceIndexRef.current = -1;
    tryNextInstance();
  }, [tryNextInstance]);
  useEffect(() => {
    const handler = e => {
      if (e.key === "Escape" || e.keyCode === 4) onClose();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onClose]);
  const openInBrowser = () => {
    const preferred = getInvidiousBase();
    const url = `${preferred}/watch?v=${trailerKey}`;
    window.electron?.openExternal(url);
  };
  useEffect(() => {
    const wv = webviewRef.current;
    if (!wv || !currentSrc) return;
    const onLoad = () => {
      setStatusMsg(null);
    };
    const onFailLoad = () => {
      tryNextInstance();
    };
    wv.addEventListener("did-finish-load", onLoad);
    wv.addEventListener("did-fail-load", onFailLoad);
    return () => {
      wv.removeEventListener("did-finish-load", onLoad);
      wv.removeEventListener("did-fail-load", onFailLoad);
    };
  }, [currentSrc, tryNextInstance]);
  return React.createElement("div", {
    className: "trailer-overlay",
    onClick: onClose
  }, React.createElement("div", {
    className: "trailer-modal",
    onClick: e => e.stopPropagation()
  }, React.createElement("div", {
    className: "trailer-modal-header"
  }, React.createElement("span", {
    className: "trailer-modal-title"
  }, "\uD83C\uDFAC ", title, " \u2014 Official Trailer"), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, React.createElement("button", {
    onClick: openInBrowser,
    title: "Open in browser",
    className: "trailer-openbrowser-btn"
  }, React.createElement(ExternalLinkIcon, {
    size: 13
  }), "Open in Browser"), React.createElement("button", {
    className: "trailer-close-btn",
    onClick: onClose,
    title: "Close",
    "data-gamepad-close": "true"
  }, React.createElement(CloseIcon, null)))), React.createElement("div", {
    className: "trailer-embed-wrap",
    style: {
      background: "#000",
      position: "relative"
    }
  }, (statusMsg || failed) && React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 2,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      background: "#000",
      color: failed ? "#ff3860" : "rgba(255,255,255,0.6)",
      fontSize: 14,
      textAlign: "center",
      padding: "0 32px",
      gap: 10
    }
  }, failed ? React.createElement(React.Fragment, null, React.createElement("span", {
    style: {
      fontSize: 28
    }
  }, "\u26A0"), React.createElement("span", null, statusMsg)) : React.createElement(React.Fragment, null, React.createElement("span", {
    style: {
      opacity: 0.5
    }
  }, "\u23F3"), React.createElement("span", null, statusMsg))), currentSrc && React.createElement(StreamPlayerFrame, {
    ref: webviewRef,
    src: currentSrc,
    style: {
      opacity: statusMsg ? 0 : 1,
      transition: "opacity 0.2s"
    }
  }))));
}
