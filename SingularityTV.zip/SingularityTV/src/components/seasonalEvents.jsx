import { useEffect, useState } from "react";
const EVENTS = [{
  id: "pride",
  check: d => d.getMonth() === 5,
  render: () => React.createElement(PrideOverlay, null)
}, {
  id: "christmas",
  check: d => d.getMonth() === 11 && d.getDate() >= 20,
  render: () => React.createElement(SnowOverlay, null)
}, {
  id: "newyear",
  check: d => d.getMonth() === 0 && d.getDate() <= 5,
  render: () => React.createElement(SnowOverlay, null)
}, {
  id: "halloween",
  check: d => d.getMonth() === 9 && d.getDate() >= 24,
  render: () => React.createElement(HalloweenOverlay, null)
}];
export function useSeasonalEvent() {
  const [event, setEvent] = useState(() => getActiveEvent());
  useEffect(() => {
    const msUntilMidnight = () => {
      const now = new Date();
      const midnight = new Date(now);
      midnight.setHours(24, 0, 0, 0);
      return midnight - now;
    };
    let timeout;
    const schedule = () => {
      timeout = setTimeout(() => {
        setEvent(getActiveEvent());
        schedule();
      }, msUntilMidnight());
    };
    schedule();
    return () => clearTimeout(timeout);
  }, []);
  return event;
}
function getActiveEvent() {
  const now = new Date();
  return EVENTS.find(e => e.check(now)) ?? null;
}
const PRIDE_STRIPES = ["#FF0018", "#FFA52C", "#FFFF41", "#008018", "#0000F9", "#86007D"];
function PrideOverlay() {
  return React.createElement("div", {
    style: overlayBase
  }, React.createElement("div", {
    style: {
      position: "absolute",
      bottom: 3,
      right: 2,
      width: 14,
      height: 10,
      borderRadius: 1,
      overflow: "hidden",
      display: "flex",
      flexDirection: "column",
      boxShadow: "0 0 0 1px rgba(0,0,0,0.25)"
    }
  }, PRIDE_STRIPES.map((color, i) => React.createElement("div", {
    key: i,
    style: {
      flex: 1,
      background: color
    }
  }))));
}
const SNOWFLAKES = Array.from({
  length: 7
}, (_, i) => ({
  left: `${10 + i * 13}%`,
  delay: `${i * 0.4}s`,
  duration: `${1.6 + i % 3 * 0.5}s`,
  size: i % 2 === 0 ? 3 : 2
}));
function SnowOverlay() {
  return React.createElement("div", {
    style: {
      ...overlayBase,
      overflow: "hidden"
    }
  }, React.createElement("style", null, `
        @keyframes sb-snow-fall {
          0%   { transform: translateY(-6px) rotate(0deg); opacity: 0; }
          15%  { opacity: 1; }
          85%  { opacity: 1; }
          100% { transform: translateY(44px) rotate(180deg); opacity: 0; }
        }
      `), SNOWFLAKES.map((s, i) => React.createElement("div", {
    key: i,
    style: {
      position: "absolute",
      left: s.left,
      top: 0,
      width: s.size,
      height: s.size,
      borderRadius: "50%",
      background: "#fff",
      opacity: 0,
      animation: `sb-snow-fall ${s.duration} ${s.delay} infinite linear`
    }
  })));
}
function HalloweenOverlay() {
  return React.createElement("div", {
    style: overlayBase
  }, React.createElement("div", {
    style: {
      position: "absolute",
      bottom: 1,
      right: 1,
      width: 14,
      height: 14,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: 12,
      lineHeight: 1
    }
  }, "\uD83C\uDF83"));
}
const overlayBase = {
  position: "absolute",
  inset: 0,
  borderRadius: "inherit",
  display: "flex",
  flexDirection: "column",
  pointerEvents: "none",
  overflow: "hidden"
};
