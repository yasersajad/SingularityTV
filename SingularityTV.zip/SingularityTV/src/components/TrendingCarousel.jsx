import { useState, useEffect, useRef, useCallback, useMemo, memo } from "react";
import { imgUrl, isAnimeContent } from "../utils/api";
import { StarIcon, ChevronLeftIcon, ChevronRightIcon } from "./Icons";
const VISIBLE = 5;
const HALF = Math.floor(VISIBLE / 2);
function visibilityRatio(el, scrollRoot) {
  const r = el.getBoundingClientRect();
  const rootTop = scrollRoot ? scrollRoot.getBoundingClientRect().top : 0;
  const rootHeight = scrollRoot ? scrollRoot.getBoundingClientRect().height : window.innerHeight;
  const visTop = Math.max(r.top, rootTop);
  const visBottom = Math.min(r.bottom, rootTop + rootHeight);
  const px = Math.max(0, visBottom - visTop);
  return r.height > 0 ? px / r.height : 0;
}
const RatingBadge = memo(function RatingBadge({
  cert,
  restricted
}) {
  if (!cert) return null;
  return React.createElement("span", {
    className: `carousel-rating-badge${restricted ? " carousel-rating-badge--restricted" : ""}`,
    title: restricted ? "Age-restricted" : `Rated ${cert}`
  }, cert);
});
const CarouselSlot = memo(function CarouselSlot({
  item,
  offset,
  onSelect,
  onFocus,
  animating,
  ageRating,
  restricted,
  isAnime
}) {
  if (!item) return null;
  const isCenter = offset === 0;
  const abs = Math.abs(offset);
  const title = item.title || item.name;
  const year = (item.release_date || item.first_air_date || "").slice(0, 4);
  const poster = imgUrl(item.poster_path, "w342");
  const scale = isCenter ? 1 : abs === 1 ? 0.75 : 0.54;
  const opacity = isCenter ? 1 : abs === 1 ? 0.65 : 0.35;
  const tx = offset * 230;
  const rawDate = item.release_date || item.first_air_date;
  const isUnreleased = useMemo(() => {
    if (!rawDate) return false;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return new Date(rawDate) > today;
  }, [rawDate]);
  const releaseLabel = useMemo(() => rawDate ? new Date(rawDate).toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric"
  }) : null, [rawDate]);
  return React.createElement("div", {
    className: `carousel-item${isCenter ? " carousel-item--active" : ""}${animating ? " carousel-item--animating" : ""}`,
    style: {
      transform: `translateX(${tx}px) scale(${scale})`,
      opacity,
      zIndex: isCenter ? 10 : abs === 1 ? 6 : 2,
      cursor: "pointer",
      pointerEvents: "auto"
    },
    onClick: isCenter ? onSelect : onFocus
  }, React.createElement("div", {
    className: "carousel-poster-wrap"
  }, poster ? React.createElement("img", {
    src: poster,
    alt: title,
    className: "carousel-poster",
    draggable: false,
    loading: abs > 1 ? "lazy" : "eager"
  }) : React.createElement("div", {
    className: "carousel-poster carousel-poster--placeholder"
  }, React.createElement("span", null, title)), isUnreleased && React.createElement("div", {
    className: "carousel-unreleased-overlay"
  }, React.createElement("span", {
    className: "carousel-unreleased-label"
  }, "\uD83D\uDD12 Coming Soon"), releaseLabel && React.createElement("span", {
    className: "carousel-unreleased-date"
  }, releaseLabel)), isCenter && item.vote_average > 0 && React.createElement("div", {
    className: "carousel-score"
  }, React.createElement(StarIcon, {
    size: 10
  }), item.vote_average.toFixed(1)), isCenter && React.createElement("div", {
    className: "carousel-badge-wrap"
  }, React.createElement(RatingBadge, {
    cert: ageRating,
    restricted: restricted
  })), isCenter && isAnime && React.createElement("div", {
    className: "carousel-anime-badge"
  }, "ANIME")), isCenter && React.createElement("div", {
    className: "carousel-info"
  }, React.createElement("div", {
    className: "carousel-info__title"
  }, title), React.createElement("div", {
    className: "carousel-info__meta"
  }, year && React.createElement("span", null, year), item.media_type && React.createElement("span", {
    className: "carousel-info__type"
  }, item.media_type === "tv" ? "Series" : "Movie"))));
});
export default function TrendingCarousel({
  items,
  onSelect,
  title,
  titleHighlight,
  ratingsMap = {}
}) {
  const count = items.length;
  const activeRef = useRef(0);
  const [active, setActive] = useState(0);
  const [direction, setDirection] = useState(1);
  const [animating, setAnimating] = useState(false);
  const intervalRef = useRef(null);
  const isFocusedRef = useRef(false);
  const wheelThrottle = useRef(false);
  const touchStartX = useRef(null);
  const containerRef = useRef(null);
  const animTimeout = useRef(null);
  const sectionRef = useRef(null);
  const go = useCallback(idx => {
    const next = (idx % count + count) % count;
    const curr = activeRef.current;
    if (next === curr) return;
    const fwd = (next - curr + count) % count;
    setDirection(fwd <= count / 2 ? 1 : -1);
    setAnimating(true);
    clearTimeout(animTimeout.current);
    animTimeout.current = setTimeout(() => setAnimating(false), 420);
    activeRef.current = next;
    setActive(next);
  }, [count]);
  const goNext = useCallback(() => go(activeRef.current + 1), [go]);
  const goPrev = useCallback(() => go(activeRef.current - 1), [go]);
  const startCycle = useCallback(() => {
    clearInterval(intervalRef.current);
    intervalRef.current = setInterval(() => go(activeRef.current + 1), 4500);
  }, [go]);
  const resetInterval = useCallback(() => startCycle(), [startCycle]);
  useEffect(() => {
    if (count <= 1) return;
    const sectionEl = sectionRef.current;
    if (!sectionEl) return;
    const scrollRoot = document.querySelector(".main");
    const updateFocus = () => {
      const allSections = document.querySelectorAll(".carousel-section");
      let bestEl = null;
      let bestRatio = -1;
      allSections.forEach(el => {
        const r = visibilityRatio(el, scrollRoot);
        if (r > bestRatio) {
          bestRatio = r;
          bestEl = el;
        }
      });
      const should = bestEl === sectionEl && bestRatio > 0.1;
      if (should && !isFocusedRef.current) {
        isFocusedRef.current = true;
        startCycle();
      } else if (!should && isFocusedRef.current) {
        isFocusedRef.current = false;
        clearInterval(intervalRef.current);
      }
    };
    const scrollEl = scrollRoot || window;
    scrollEl.addEventListener("scroll", updateFocus, {
      passive: true
    });
    window.addEventListener("resize", updateFocus, {
      passive: true
    });
    const observer = new IntersectionObserver(([entry]) => {
      if (!entry.isIntersecting) {
        isFocusedRef.current = false;
        clearInterval(intervalRef.current);
      } else {
        updateFocus();
      }
    }, {
      root: scrollRoot,
      threshold: 0
    });
    observer.observe(sectionEl);
    const id = requestAnimationFrame(updateFocus);
    return () => {
      scrollEl.removeEventListener("scroll", updateFocus);
      window.removeEventListener("resize", updateFocus);
      observer.disconnect();
      cancelAnimationFrame(id);
      clearInterval(intervalRef.current);
    };
  }, [count, startCycle]);
  const handleWheel = useCallback(e => {
    const isHorizontal = Math.abs(e.deltaX) > Math.abs(e.deltaY);
    if (!isHorizontal) return;
    e.preventDefault();
    if (wheelThrottle.current) return;
    wheelThrottle.current = true;
    setTimeout(() => {
      wheelThrottle.current = false;
    }, 600);
    if (e.deltaX > 0) {
      goNext();
    } else {
      goPrev();
    }
    resetInterval();
  }, [goNext, goPrev, resetInterval]);
  useEffect(() => {
    const el = containerRef.current;
    if (!el) return;
    el.addEventListener("wheel", handleWheel, {
      passive: false
    });
    return () => el.removeEventListener("wheel", handleWheel);
  }, [handleWheel]);
  const touchStartY = useRef(null);
  const onTouchStart = useCallback(e => {
    touchStartX.current = e.touches[0].clientX;
    touchStartY.current = e.touches[0].clientY;
  }, []);
  const onTouchEnd = useCallback(e => {
    if (touchStartX.current === null) return;
    const dx = e.changedTouches[0].clientX - touchStartX.current;
    const dy = e.changedTouches[0].clientY - (touchStartY.current ?? e.changedTouches[0].clientY);
    touchStartX.current = null;
    touchStartY.current = null;
    if (Math.abs(dx) < 48 || Math.abs(dx) < Math.abs(dy) * 1.6) return;
    dx < 0 ? goNext() : goPrev();
    resetInterval();
  }, [goNext, goPrev, resetInterval]);
  const handlePrev = useCallback(() => {
    goPrev();
    resetInterval();
  }, [goPrev, resetInterval]);
  const handleNext = useCallback(() => {
    goNext();
    resetInterval();
  }, [goNext, resetInterval]);
  const handleDot = useCallback(i => {
    go(i);
    resetInterval();
  }, [go, resetInterval]);
  const slots = useMemo(() => Array.from({
    length: VISIBLE
  }, (_, i) => {
    const offset = i - HALF;
    const idx = ((active + offset) % count + count) % count;
    return {
      offset,
      idx
    };
  }), [active, count]);
  const slotHandlers = useMemo(() => {
    const handlers = {};
    for (let i = 0; i < VISIBLE; i++) {
      const offset = i - HALF;
      const idx = ((active + offset) % count + count) % count;
      if (offset === 0) {
        handlers[offset] = {
          onSelect: () => onSelect(items[idx]),
          onFocus: null
        };
      } else {
        const captured = idx;
        handlers[offset] = {
          onSelect: null,
          onFocus: () => {
            go(captured);
            resetInterval();
          }
        };
      }
    }
    return handlers;
  }, [active, count, items, onSelect, go, resetInterval]);
  const activeItem = items[active];
  const activeType = activeItem?.media_type === "tv" ? "tv" : "movie";
  const activeRatingKey = activeItem ? `${activeType}_${activeItem.id}` : null;
  const activeRating = activeRatingKey ? ratingsMap[activeRatingKey] || {} : {};
  const dotCount = Math.min(count, 15);
  if (!items || count === 0) return null;
  return React.createElement("div", {
    className: "carousel-section",
    ref: sectionRef
  }, React.createElement("div", {
    className: "section-title"
  }, titleHighlight ? React.createElement(React.Fragment, null, title, "\xA0", React.createElement("span", {
    style: {
      color: "var(--red)"
    }
  }, titleHighlight)) : title), React.createElement("div", {
    className: "carousel-wrapper",
    ref: containerRef,
    onTouchStart: onTouchStart,
    onTouchEnd: onTouchEnd
  }, React.createElement("button", {
    className: "carousel-btn carousel-btn--left",
    onClick: handlePrev,
    "aria-label": "Previous"
  }, React.createElement(ChevronLeftIcon, {
    size: 22
  })), React.createElement("div", {
    className: `carousel-track${animating ? ` carousel-track--dir-${direction > 0 ? "fwd" : "bwd"}` : ""}`
  }, slots.map(({
    offset,
    idx
  }) => {
    const isCenter = offset === 0;
    const ratingData = isCenter ? activeRating : {};
    const h = slotHandlers[offset];
    return React.createElement(CarouselSlot, {
      key: offset,
      item: items[idx],
      offset: offset,
      onSelect: h.onSelect,
      onFocus: h.onFocus,
      animating: animating,
      ageRating: isCenter ? ratingData.cert : null,
      restricted: isCenter ? ratingData.restricted : false,
      isAnime: isCenter ? isAnimeContent(items[idx]) : false
    });
  })), React.createElement("button", {
    className: "carousel-btn carousel-btn--right",
    onClick: handleNext,
    "aria-label": "Next"
  }, React.createElement(ChevronRightIcon, {
    size: 22
  }))), React.createElement("div", {
    className: "carousel-dots"
  }, Array.from({
    length: dotCount
  }, (_, i) => React.createElement("button", {
    key: `dot-${i}`,
    className: `carousel-dot${active === i ? " carousel-dot--active" : ""}`,
    onClick: () => handleDot(i),
    "aria-label": `Go to ${i + 1}`
  })), count > 15 && React.createElement("span", {
    className: "carousel-dots__more"
  }, "+", count - 15)));
}
