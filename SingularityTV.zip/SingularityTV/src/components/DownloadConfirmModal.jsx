import React, { useState, useEffect, useRef } from "react";
import { DownloadIcon, CloseIcon, SubtitlesIcon } from "./Icons";
import { storage, STORAGE_KEYS } from "../utils/storage";
import { SUBTITLE_LANGUAGES } from "../utils/subtitles";
import { setGamepadFocus } from "../utils/gamepadSpatialNav";

function formatEstimatedSize(runtimeMin, episodeCount = 1) {
  const mins = Number(runtimeMin) > 0 ? Number(runtimeMin) : 110;
  const totalMb = Math.round(mins * 11.5 * Math.max(1, episodeCount));
  if (totalMb >= 1024) {
    return `~${(totalMb / 1024).toFixed(2)} GB`;
  }
  return `~${totalMb} MB`;
}

export default function DownloadConfirmModal({
  title,
  runtimeMin,
  episodeCount = 1,
  onConfirm,
  onCancel
}) {
  const confirmRef = useRef(null);
  const [selectedLang, setSelectedLang] = useState(
    () => storage.get(STORAGE_KEYS.SUBTITLE_LANG) || "ar"
  );
  const estSize = formatEstimatedSize(runtimeMin, episodeCount);

  useEffect(() => {
    const tid = setTimeout(() => {
      if (confirmRef.current) setGamepadFocus(confirmRef.current, { scroll: false });
    }, 60);
    return () => clearTimeout(tid);
  }, []);

  const handleLangChange = e => {
    const val = e.target.value;
    setSelectedLang(val);
    storage.set(STORAGE_KEYS.SUBTITLE_LANG, val);
  };

  return (
    <div className="modal-overlay" onClick={e => e.target === e.currentTarget && onCancel()}>
      <div className="dl-confirm-box" onClick={e => e.stopPropagation()}>
        <div className="dl-confirm-header">
          <div className="dl-confirm-icon">
            <DownloadIcon />
          </div>
          <div>
            <h3 className="dl-confirm-title">Confirm Download</h3>
            <p className="dl-confirm-subtitle">{title}</p>
          </div>
          <button
            className="btn btn-ghost btn-icon"
            data-gamepad-close="1"
            onClick={onCancel}
            aria-label="Close"
          >
            <CloseIcon />
          </button>
        </div>

        <div className="dl-confirm-details">
          <div className="dl-confirm-row">
            <span className="dl-confirm-label">Estimated Size</span>
            <span className="dl-confirm-val">{estSize}</span>
          </div>
          {episodeCount > 1 && (
            <div className="dl-confirm-row">
              <span className="dl-confirm-label">Episodes</span>
              <span className="dl-confirm-val">{episodeCount} episodes</span>
            </div>
          )}
          <div className="dl-confirm-row">
            <span className="dl-confirm-label">
              <SubtitlesIcon size={14} /> Subtitle Language
            </span>
            <select
              className="dl-confirm-select"
              value={selectedLang}
              onChange={handleLangChange}
            >
              {SUBTITLE_LANGUAGES.map(l => (
                <option key={l.code} value={l.code}>
                  {l.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="dl-confirm-actions">
          <button
            ref={confirmRef}
            className="btn btn-primary"
            onClick={() => onConfirm(selectedLang)}
          >
            <DownloadIcon />
            <span>Download with Subtitle</span>
          </button>
          <button className="btn btn-ghost" onClick={onCancel}>
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}
