import React, { useState, useEffect, useRef, useCallback, memo } from "react";
import { imgUrl, isAnimeContent } from "../utils/api";
import { PlayIcon, FilmIcon, TVIcon, WatchedIcon, RatingShieldIcon, RatingLockIcon } from "./Icons";

const MediaCard = memo(function MediaCard({
  item,
  variant = "landscape",
  onClick,
  progress,
  watched,
  onMarkWatched,
  onMarkUnwatched,
  ageRating,
  restricted
}) {
  const title = item.title || item.name;
  const year = (item.release_date || item.first_air_date || "").slice(0, 4);
  const isTV = item.media_type === "tv";
  const isAnime = isAnimeContent(item);
  const isLandscape = variant === "landscape";

  const rawDate = item.release_date || item.first_air_date;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const isUnreleased = rawDate ? new Date(rawDate) > today : false;

  const watchedKey = isTV
    ? item.season != null && item.episode != null
      ? `tv_${item.id}_s${item.season}e${item.episode}`
      : `tv_${item.id}`
    : `movie_${item.id}`;
  const isWatched = !!watched?.[watchedKey];

  const [menu, setMenu] = useState(null);
  const menuRef = useRef(null);
  const canMarkWatched = !isTV || (item.season != null && item.episode != null);

  const openMenu = useCallback(
    e => {
      if (!canMarkWatched) return;
      e.preventDefault();
      e.stopPropagation();
      setMenu({ x: e.clientX, y: e.clientY });
    },
    [canMarkWatched]
  );

  useEffect(() => {
    if (!menu) return;
    const close = () => setMenu(null);
    window.addEventListener("click", close);
    window.addEventListener("contextmenu", close);
    return () => {
      window.removeEventListener("click", close);
      window.removeEventListener("contextmenu", close);
    };
  }, [menu]);

  const [imgFailed, setImgFailed] = useState(false);
  const imagePath = isLandscape
    ? item.backdrop_path || item.poster_path
    : item.poster_path || item.backdrop_path;
  const fallbackPath = isLandscape ? item.poster_path : item.backdrop_path;
  const [useAlt, setUseAlt] = useState(false);
  const activePath = useAlt && fallbackPath ? fallbackPath : imagePath;
  const imageSrc = activePath ? imgUrl(activePath, isLandscape ? "w780" : "w342") : null;

  if (isUnreleased || !imageSrc || imgFailed || !title) return null;

  return (
    <>
      <div
        role="button"
        tabIndex={0}
        className={`card ${isLandscape ? "card--landscape" : "card--poster"}${isWatched ? " ep-watched" : ""}${isUnreleased ? " card--unreleased" : ""}`}
        onClick={onClick}
        onContextMenu={isUnreleased ? undefined : openMenu}
      >
        <div className="card-media">
          {imageSrc ? (
            <img
              src={imageSrc}
              alt={title}
              loading="lazy"
              decoding="async"
              draggable={false}
              onError={() => {
                if (!useAlt && fallbackPath && fallbackPath !== imagePath) {
                  setUseAlt(true);
                } else {
                  setImgFailed(true);
                }
              }}
            />
          ) : (
            <div className="no-poster">
              {isTV ? <TVIcon /> : <FilmIcon />}
              <span style={{ fontSize: 11, color: "var(--text3)" }}>No Image</span>
            </div>
          )}

          <div className="card-gradient-overlay" />

          {ageRating && (
            <div className={`card-age-badge${restricted ? " card-age-badge--restricted" : ""}`}>
              {restricted ? <RatingLockIcon size={9} /> : <RatingShieldIcon size={9} />}
              {ageRating}
            </div>
          )}

          <span
            className={`card-badge${isUnreleased ? " card-badge--unreleased" : ""}${isAnime && !isUnreleased ? " card-badge--anime" : ""}`}
          >
            {isUnreleased ? "SOON" : isAnime ? "ANIME" : isTV ? "TV" : "HD"}
          </span>

          <div className="card-overlay">
            {isUnreleased ? (
              <div className="card-unreleased-overlay">
                <span className="card-unreleased-label"><RatingLockIcon size={12} /> Unreleased</span>
              </div>
            ) : (
              <div className="card-play">
                <PlayIcon />
              </div>
            )}
          </div>

          <div className="card-overlay-meta">
            <div className="card-title" title={title}>
              {title}
            </div>
            <div className="card-year">
              {isTV && item.season != null && item.episode != null
                ? `S${item.season}E${item.episode}${item.episodeName ? ` · ${item.episodeName}` : ""}`
                : `${year ? `${year} · ` : ""}${isTV ? "Series" : "Movie"}`}
            </div>
          </div>

          {!isUnreleased && progress > 0 && !isWatched && (
            <div className="card-progress">
              <div className="card-progress-fill" style={{ width: `${Math.min(progress, 100)}%` }} />
            </div>
          )}

          {!isUnreleased && isWatched && (
            <div className="card-watched-badge">
              <WatchedIcon size={24} />
            </div>
          )}
        </div>
      </div>

      {menu && (
        <div
          ref={menuRef}
          className="context-menu"
          style={{ top: menu.y, left: menu.x }}
          onClick={e => e.stopPropagation()}
        >
          {isWatched ? (
            <button
              className="context-menu-item"
              onClick={e => {
                e.stopPropagation();
                onMarkUnwatched?.(watchedKey);
                setMenu(null);
              }}
            >
              Mark as Unwatched
            </button>
          ) : (
            <button
              className="context-menu-item"
              onClick={e => {
                e.stopPropagation();
                onMarkWatched?.(watchedKey);
                setMenu(null);
              }}
            >
              Mark as Watched
            </button>
          )}
        </div>
      )}
    </>
  );
});

export default MediaCard;
