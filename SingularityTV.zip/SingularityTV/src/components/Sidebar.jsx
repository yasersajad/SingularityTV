import { useState, useRef, useEffect } from "react";
import { imgUrl } from "../utils/api";
import { useSeasonalEvent } from "../components/seasonalEvents.jsx";
import { SingularityTVLogo, HomeIcon, SearchIcon, HistoryIcon, FilmIcon, SettingsIcon, DownloadsQueueIcon, QuitIcon, BackIcon, HelpIcon } from "./Icons";
export default function Sidebar({
  page,
  onNavigate,
  onSearch,
  savedList,
  activeDownloads,
  onReorderSaved,
  onRemoveSaved,
  canGoBack,
  onBack,
  onShowShortcuts
}) {
  const [dragOver, setDragOver] = useState(null);
  const dragItem = useRef(null);
  const dragNode = useRef(null);
  const seasonalEvent = useSeasonalEvent();
  const [tooltip, setTooltip] = useState(null);
  const [contextMenu, setContextMenu] = useState(null);
  useEffect(() => {
    const close = () => setContextMenu(null);
    window.addEventListener("click", close);
    window.addEventListener("contextmenu", close);
    return () => {
      window.removeEventListener("click", close);
      window.removeEventListener("contextmenu", close);
    };
  }, []);
  const handleContextMenu = (e, item) => {
    e.preventDefault();
    e.stopPropagation();
    setTooltip(null);
    setContextMenu({
      item,
      x: e.clientX,
      y: e.clientY
    });
  };
  const handleDragStart = (e, index) => {
    dragItem.current = index;
    dragNode.current = e.currentTarget;
    setTimeout(() => {
      if (dragNode.current) dragNode.current.style.opacity = "0.4";
    }, 0);
    e.dataTransfer.effectAllowed = "move";
  };
  const handleDragEnd = () => {
    if (dragNode.current) dragNode.current.style.opacity = "1";
    dragItem.current = null;
    dragNode.current = null;
    setDragOver(null);
  };
  const handleDragEnter = (e, index) => {
    if (dragItem.current === index) return;
    setDragOver(index);
  };
  const handleDrop = (e, dropIndex) => {
    e.preventDefault();
    const fromIndex = dragItem.current;
    if (fromIndex === null || fromIndex === dropIndex) return;
    const newList = [...savedList];
    const [moved] = newList.splice(fromIndex, 1);
    newList.splice(dropIndex, 0, moved);
    const newOrder = newList.map(item => `${item.media_type}_${item.id}`);
    onReorderSaved(newOrder);
    setDragOver(null);
  };
  const handleDragOver = e => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
  };
  const handleMouseEnter = (e, title) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setTooltip({
      title,
      y: rect.top + rect.height / 2
    });
  };
  const handleMouseLeave = () => {
    setTooltip(null);
  };
  return React.createElement("div", {
    className: "sidebar"
  }, React.createElement("div", {
    className: "sidebar-logo",
    onClick: () => onNavigate("home"),
    title: "SingularityTV",
    style: {
      position: "relative"
    }
  }, React.createElement(SingularityTVLogo, null), seasonalEvent && seasonalEvent.render()), canGoBack && React.createElement(SideBtn, {
    onClick: onBack,
    icon: React.createElement(BackIcon, null),
    label: "Back (Ctrl+Z)"
  }), React.createElement(SideBtn, {
    onClick: onSearch,
    icon: React.createElement(SearchIcon, null),
    label: "Search  (\u2318F)"
  }), React.createElement(SideBtn, {
    active: page === "home",
    onClick: () => onNavigate("home"),
    icon: React.createElement(HomeIcon, null),
    label: "Home"
  }), React.createElement(SideBtn, {
    active: page === "history",
    onClick: () => onNavigate("history"),
    icon: React.createElement(HistoryIcon, null),
    label: "Library & History"
  }), React.createElement(SideBtn, {
    active: page === "downloads",
    onClick: () => onNavigate("downloads"),
    icon: React.createElement(DownloadsQueueIcon, null),
    label: "Downloads",
    badge: activeDownloads > 0 ? activeDownloads : null
  }), React.createElement("div", {
    className: "sidebar-sep"
  }), React.createElement("div", {
    className: "sidebar-saved"
  }, savedList.map((item, index) => {
    const key = `${item.media_type}_${item.id}`;
    const title = item.title || item.name;
    return React.createElement("div", {
      key: key,
      className: `saved-thumb${dragOver === index ? " drag-over" : ""}`,
      draggable: true,
      onDragStart: e => handleDragStart(e, index),
      onDragEnd: handleDragEnd,
      onDragEnter: e => handleDragEnter(e, index),
      onDragOver: handleDragOver,
      onDrop: e => handleDrop(e, index),
      onClick: () => onNavigate(item.media_type === "tv" ? "tv" : "movie", item),
      onContextMenu: e => handleContextMenu(e, item),
      onMouseEnter: e => handleMouseEnter(e, title),
      onMouseLeave: handleMouseLeave,
      style: {
        cursor: "grab",
        position: "relative"
      }
    }, item.poster_path ? React.createElement("img", {
      src: imgUrl(item.poster_path, "w200"),
      alt: title
    }) : React.createElement("div", {
      className: "no-img"
    }, React.createElement(FilmIcon, null)), dragOver === index && React.createElement("div", {
      style: {
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        height: 3,
        background: "var(--accent, #e50914)",
        borderRadius: 2,
        pointerEvents: "none"
      }
    }));
  })), tooltip && React.createElement("div", {
    className: "saved-thumb-tooltip",
    style: {
      top: tooltip.y
    }
  }, tooltip.title), contextMenu && React.createElement("div", {
    className: "sidebar-context-menu",
    style: {
      position: "fixed",
      top: contextMenu.y,
      left: contextMenu.x,
      zIndex: 9999
    },
    onClick: e => e.stopPropagation()
  }, React.createElement("div", {
    className: "sidebar-context-menu-item",
    onClick: () => {
      onRemoveSaved && onRemoveSaved(contextMenu.item);
      setContextMenu(null);
    }
  }, "Remove")), React.createElement("div", {
    className: "sidebar-bottom"
  }, React.createElement(SideBtn, {
    onClick: onShowShortcuts,
    icon: React.createElement(HelpIcon, null),
    label: "Help & Shortcuts (?)"
  }), React.createElement(SideBtn, {
    active: page === "settings",
    onClick: () => onNavigate("settings"),
    icon: React.createElement(SettingsIcon, null),
    label: "Settings"
  }), React.createElement("button", {
    className: "sidebar-btn",
    onClick: () => window.electron?.quitApp?.(),
    title: "Quit App",
    style: {
      color: "#e53e3e",
      marginTop: 4
    }
  }, React.createElement(QuitIcon, null), React.createElement("span", {
    className: "tooltip"
  }, "Quit App"))));
}
function SideBtn({
  active,
  onClick,
  icon,
  label,
  badge
}) {
  return React.createElement("button", {
    className: `sidebar-btn ${active ? "active" : ""}`,
    onClick: onClick,
    style: {
      position: "relative"
    }
  }, icon, React.createElement("span", {
    className: "tooltip"
  }, label), badge && React.createElement("span", {
    style: {
      position: "absolute",
      top: 4,
      right: 4,
      minWidth: 16,
      height: 16,
      borderRadius: 8,
      background: "var(--red)",
      color: "white",
      fontSize: 10,
      fontWeight: 700,
      lineHeight: "16px",
      textAlign: "center",
      padding: "0 4px"
    }
  }, badge));
}
