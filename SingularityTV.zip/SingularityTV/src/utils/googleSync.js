import { collectBackupData, restoreBackupData } from "./backup";

const GOOGLE_USER_KEY = "streambert_googleUser";
const GOOGLE_TOKEN_KEY = "streambert_googleAccessToken";
const GOOGLE_CLIENT_ID_KEY = "streambert_googleClientId";
const GOOGLE_LAST_SYNC_KEY = "streambert_googleLastSync";
const DRIVE_BACKUP_FILENAME = "singularitytv_user_sync.json";

export function getGoogleAccount() {
  try {
    const raw = localStorage.getItem(GOOGLE_USER_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function getGoogleClientId() {
  try {
    return localStorage.getItem(GOOGLE_CLIENT_ID_KEY) || "";
  } catch {
    return "";
  }
}

export function setGoogleClientId(clientId) {
  try {
    localStorage.setItem(GOOGLE_CLIENT_ID_KEY, (clientId || "").trim());
  } catch {}
}

export function getLastCloudSyncTime() {
  try {
    return Number(localStorage.getItem(GOOGLE_LAST_SYNC_KEY) || 0);
  } catch {
    return 0;
  }
}

function getProfileStorageKey(email) {
  const clean = String(email || "").trim().toLowerCase();
  return `streambert_cloud_vault_${clean}`;
}

export function saveAccountSnapshotLocally(user = getGoogleAccount()) {
  if (!user || !user.email) return null;
  const payload = {
    email: user.email,
    name: user.name || user.email.split("@")[0],
    updatedAt: Date.now(),
    data: collectBackupData()
  };
  try {
    localStorage.setItem(getProfileStorageKey(user.email), JSON.stringify(payload));
    localStorage.setItem(GOOGLE_LAST_SYNC_KEY, String(payload.updatedAt));
  } catch {}
  return payload;
}

export function restoreAccountSnapshotLocally(email) {
  const clean = String(email || "").trim().toLowerCase();
  if (!clean) return false;
  try {
    const raw = localStorage.getItem(getProfileStorageKey(clean));
    if (!raw) return false;
    const parsed = JSON.parse(raw);
    if (parsed && parsed.data && typeof parsed.data === "object") {
      restoreBackupData(parsed.data);
      localStorage.setItem(GOOGLE_LAST_SYNC_KEY, String(parsed.updatedAt || Date.now()));
      return true;
    }
  } catch {}
  return false;
}

export async function signInWithGoogleProfile({ email, name, picture, accessToken }) {
  const cleanEmail = String(email || "").trim().toLowerCase();
  if (!cleanEmail || !cleanEmail.includes("@")) {
    throw new Error("Please enter a valid Google email address");
  }
  const displayName = String(name || "").trim() || cleanEmail.split("@")[0];
  const userObj = {
    email: cleanEmail,
    name: displayName,
    picture: picture || "",
    signedInAt: Date.now()
  };
  localStorage.setItem(GOOGLE_USER_KEY, JSON.stringify(userObj));
  if (accessToken) {
    localStorage.setItem(GOOGLE_TOKEN_KEY, accessToken);
  }
  if (accessToken) {
    try {
      const pulled = await pullFromGoogleDrive(accessToken);
      if (pulled) {
        window.dispatchEvent(new CustomEvent("streambert:google-account-changed", { detail: userObj }));
        return { user: userObj, restoredFromCloud: true };
      }
    } catch {}
  }
  const restoredLocal = restoreAccountSnapshotLocally(cleanEmail);
  saveAccountSnapshotLocally(userObj);
  if (accessToken) {
    try {
      await pushToGoogleDrive(accessToken);
    } catch {}
  }
  window.dispatchEvent(new CustomEvent("streambert:google-account-changed", { detail: userObj }));
  return { user: userObj, restoredFromCloud: restoredLocal };
}

export function signOutGoogleAccount() {
  const current = getGoogleAccount();
  if (current) {
    saveAccountSnapshotLocally(current);
  }
  try {
    localStorage.removeItem(GOOGLE_USER_KEY);
    localStorage.removeItem(GOOGLE_TOKEN_KEY);
  } catch {}
  window.dispatchEvent(new CustomEvent("streambert:google-account-changed", { detail: null }));
}

export async function pushToGoogleDrive(token = localStorage.getItem(GOOGLE_TOKEN_KEY)) {
  const user = getGoogleAccount();
  const snapshot = saveAccountSnapshotLocally(user);
  if (!token) return { ok: true, mode: "local_vault", updatedAt: snapshot?.updatedAt || Date.now() };
  const searchRes = await fetch(
    `https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=name='${DRIVE_BACKUP_FILENAME}' and trashed=false&fields=files(id,name,modifiedTime)`,
    { headers: { Authorization: `Bearer ${token}` } }
  );
  if (!searchRes.ok) {
    throw new Error("Google Drive token expired or unauthorized");
  }
  const searchJson = await searchRes.json();
  const existingId = searchJson?.files?.[0]?.id || null;
  const metadata = existingId
    ? { name: DRIVE_BACKUP_FILENAME }
    : { name: DRIVE_BACKUP_FILENAME, parents: ["appDataFolder"] };

  const boundary = "singularity_drive_sync_boundary";
  const body =
    `--${boundary}\r\n` +
    `Content-Type: application/json; charset=UTF-8\r\n\r\n` +
    `${JSON.stringify(metadata)}\r\n` +
    `--${boundary}\r\n` +
    `Content-Type: application/json\r\n\r\n` +
    `${JSON.stringify(snapshot)}\r\n` +
    `--${boundary}--`;

  const uploadUrl = existingId
    ? `https://www.googleapis.com/upload/drive/v3/files/${existingId}?uploadType=multipart`
    : "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart";

  const upRes = await fetch(uploadUrl, {
    method: existingId ? "PATCH" : "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": `multipart/related; boundary=${boundary}`
    },
    body
  });
  if (!upRes.ok) {
    throw new Error("Failed to upload sync data to Google Drive");
  }
  const now = Date.now();
  localStorage.setItem(GOOGLE_LAST_SYNC_KEY, String(now));
  return { ok: true, mode: "google_drive", updatedAt: now };
}

export async function pullFromGoogleDrive(token = localStorage.getItem(GOOGLE_TOKEN_KEY)) {
  if (!token) return false;
  const searchRes = await fetch(
    `https://www.googleapis.com/drive/v3/files?spaces=appDataFolder&q=name='${DRIVE_BACKUP_FILENAME}' and trashed=false&fields=files(id,name,modifiedTime)`,
    { headers: { Authorization: `Bearer ${token}` } }
  );
  if (!searchRes.ok) return false;
  const searchJson = await searchRes.json();
  const fileId = searchJson?.files?.[0]?.id;
  if (!fileId) return false;
  const dlRes = await fetch(`https://www.googleapis.com/drive/v3/files/${fileId}?alt=media`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  if (!dlRes.ok) return false;
  const payload = await dlRes.json();
  const data = payload?.data || payload;
  if (data && typeof data === "object") {
    restoreBackupData(data);
    localStorage.setItem(GOOGLE_LAST_SYNC_KEY, String(Date.now()));
    return true;
  }
  return false;
}

export function launchGoogleOAuthInteractive(clientId) {
  return new Promise((resolve, reject) => {
    const cid = String(clientId || getGoogleClientId()).trim();
    if (!cid) {
      reject(new Error("Missing Google OAuth Client ID"));
      return;
    }
    const redirectUri = window.location.origin + window.location.pathname;
    const scope = encodeURIComponent("openid email profile https://www.googleapis.com/auth/drive.appdata");
    const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?client_id=${encodeURIComponent(cid)}&redirect_uri=${encodeURIComponent(redirectUri)}&response_type=token&scope=${scope}&prompt=select_account`;
    if (window.electron?.openExternal) {
      window.electron.openExternal(authUrl);
      resolve({ externalLaunched: true });
    } else {
      window.open(authUrl, "_blank", "width=520,height=640");
      resolve({ externalLaunched: true });
    }
  });
}

const EMAILJS_CFG_KEY = "streambert_emailjsConfig";

export function getEmailJsConfig() {
  try {
    return JSON.parse(localStorage.getItem(EMAILJS_CFG_KEY) || "{}");
  } catch {
    return {};
  }
}

export function setEmailJsConfig(cfg) {
  try {
    localStorage.setItem(EMAILJS_CFG_KEY, JSON.stringify(cfg || {}));
  } catch {}
}

export async function sendEmailVerificationCode(email, code) {
  const cfg = getEmailJsConfig();
  if (!cfg?.serviceId || !cfg?.templateId || !cfg?.publicKey) {
    return { sentViaEmail: false, code };
  }
  const res = await fetch("https://api.emailjs.com/api/v1.0/email/send", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      service_id: cfg.serviceId,
      template_id: cfg.templateId,
      user_id: cfg.publicKey,
      template_params: {
        to_email: email,
        passcode: code,
        verification_code: code,
        app_name: "SingularityTV"
      }
    })
  });
  if (!res.ok) throw new Error("Failed to send verification email");
  return { sentViaEmail: true, code };
}
