const TOUCH_SELECTOR = [
  "button",
  ".card",
  ".topnav-btn",
  ".hero-action-btn",
  ".hero-dot",
  ".episode-card",
  ".season-btn",
  ".search-result",
  ".nf-key",
  ".nf-trending-chip",
  ".nf-player-btn",
  ".btn",
  '[role="button"]'
].join(",");

let activeTouchEl = null;
let clearTimer = null;
let installed = false;

function clearTouch() {
  if (clearTimer) {
    clearTimeout(clearTimer);
    clearTimer = null;
  }
  if (activeTouchEl) {
    activeTouchEl.classList.remove("touch-active");
    activeTouchEl = null;
  }
}

export function initLiveTouch() {
  if (installed || typeof window === "undefined") return;
  installed = true;

  const onStart = e => {
    if (e.type === "pointerdown" && e.pointerType === "mouse") return;
    const target = e.target instanceof Element ? e.target.closest(TOUCH_SELECTOR) : null;
    clearTouch();
    if (target && !target.hasAttribute("disabled")) {
      activeTouchEl = target;
      activeTouchEl.classList.add("touch-active");
    }
  };

  const onEndSoon = () => {
    if (clearTimer) clearTimeout(clearTimer);
    clearTimer = setTimeout(clearTouch, 90);
  };

  window.addEventListener("pointerdown", onStart, { passive: true, capture: true });
  window.addEventListener("pointerup", clearTouch, { passive: true, capture: true });
  window.addEventListener("pointercancel", clearTouch, { passive: true, capture: true });
  window.addEventListener("touchstart", onStart, { passive: true, capture: true });
  window.addEventListener("touchend", clearTouch, { passive: true, capture: true });
  window.addEventListener("touchcancel", clearTouch, { passive: true, capture: true });
  window.addEventListener("click", onEndSoon, { passive: true, capture: true });
  window.addEventListener("scroll", clearTouch, { passive: true, capture: true });
  window.addEventListener("blur", clearTouch, { passive: true });
  document.addEventListener("visibilitychange", clearTouch, { passive: true });
}
