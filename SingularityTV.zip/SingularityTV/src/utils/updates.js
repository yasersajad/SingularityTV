export const TELEGRAM_HANDLE = "ec1lz";
export const TELEGRAM_URL = "https://t.me/ec1lz";
export const UPDATE_SOURCES = {
  telegram: {
    id: "telegram",
    label: "Telegram @ec1lz",
    apiUrl: "https://t.me/ec1lz",
    headers: {},
    fallbackUrl: "https://t.me/ec1lz"
  }
};
export const DEFAULT_UPDATE_SOURCE = "telegram";
export async function checkForUpdates() {
  return {
    hasUpdate: false,
    current: "2.7.0",
    latest: "2.7.0",
    url: "https://t.me/ec1lz",
    sourceLabel: "Telegram @ec1lz"
  };
}
export async function checkForUpdatesWithFallback() {
  return checkForUpdates();
}
