import { androidBridge } from "./androidBridge";
const PREFIX = "streambert_";
if (typeof window !== "undefined" && window.AndroidBridge?.getAllPreferencesJson) {
  try {
    const rawMap = window.AndroidBridge.getAllPreferencesJson();
    if (rawMap) {
      const parsed = JSON.parse(rawMap);
      for (const [k, v] of Object.entries(parsed)) {
        if (v !== null && v !== undefined) {
          localStorage.setItem(PREFIX + k, v);
        }
      }
    }
  } catch (e) {
    console.warn("[storage] Room hydration warning:", e);
  }
}
export const storage = {
  get(key) {
    try {
      let raw = localStorage.getItem(PREFIX + key);
      if (!raw && typeof window !== "undefined" && window.AndroidBridge?.getPreference) {
        raw = window.AndroidBridge.getPreference(key);
        if (raw) localStorage.setItem(PREFIX + key, raw);
      }
      if (!raw && key === "hianimeDubMode") {
        raw = localStorage.getItem(PREFIX + "allmangaDubMode");
      }
      const value = raw ? JSON.parse(raw) : null;
      if (key === "playerSource" && value === "allmanga") return "hianime";
      return value;
    } catch {
      return null;
    }
  },
  set(key, value) {
    try {
      const serialized = JSON.stringify(value);
      localStorage.setItem(PREFIX + key, serialized);
      if (typeof window !== "undefined" && window.AndroidBridge?.setPreference) {
        window.AndroidBridge.setPreference(key, serialized);
      }
    } catch {}
  },
  remove(key) {
    try {
      localStorage.removeItem(PREFIX + key);
      if (typeof window !== "undefined" && window.AndroidBridge?.removePreference) {
        window.AndroidBridge.removePreference(key);
      }
    } catch {}
  },
  clearAll() {
    try {
      Object.keys(localStorage).filter(k => k.startsWith(PREFIX)).forEach(k => localStorage.removeItem(k));
      if (typeof window !== "undefined" && window.AndroidBridge?.clearPreferences) {
        window.AndroidBridge.clearPreferences();
      }
    } catch {}
  }
};
export const STORAGE_KEYS = {
  UPDATE_SOURCE: "updateSource",
  PLAYER_SOURCE: "playerSource",
  HIANIME_DUB_MODE: "hianimeDubMode",
  WATCH_PROGRESS: "progress",
  WATCHED: "watched",
  HISTORY: "history",
  SAVED: "saved",
  SAVED_ORDER: "savedOrder",
  LOCAL_FILES: "localFiles",
  DOWNLOAD_PATH: "downloadPath",
  DOWNLOADER_FOLDER: "downloaderFolder",
  START_PAGE: "startPage",
  AGE_LIMIT: "ageLimit",
  RATING_COUNTRY: "ratingCountry",
  WATCHED_THRESHOLD: "watchedThreshold",
  HOME_ROW_ORDER: "homeRowOrder",
  HOME_ROW_VISIBLE: "homeRowVisible",
  HOME_VIEW_MODE: "homeViewMode",
  AUTO_CHECK_UPDATES: "autoCheckUpdates",
  INVIDIOUS_BASE: "invidiousBase",
  SUBTITLE_ENABLED: "subtitleDownload",
  SUBTITLE_LANG: "subtitleLang",
  SUBTITLE_DELAY_MS: "subtitleDelayMs",
  SUBTITLE_FONT_SCALE: "subtitleFontScale",
  SUBTITLE_POSITION: "subtitlePosition",
  SUBDL_API_KEY: "subdlApiKey",
  WYZIE_API_KEY: "wyzieApiKey",
  ACCENT_COLOR: "accentColor",
  ACCENT_IN_PLAYER: "accentInPlayer",
  THEME: "theme",
  CUSTOM_THEME_VARS: "customThemeVars",
  FONT_SIZE: "fontSize",
  COMPACT_MODE: "compactMode",
  REDUCE_ANIMATIONS: "reduceAnimations",
  LIBRARY_SORT: "librarySort",
  HISTORY_ENABLED: "historyEnabled",
  NOTIFY_DOWNLOAD_COMPLETE: "notifyDownloadComplete",
  NOTIFY_NEW_EPISODE: "notifyNewEpisode",
  TMDB_LANG: "tmdbLang",
  INTRO_SKIP_MODE: "introSkipMode",
  AUTOPLAY_NEXT_ENABLED: "autoplayNextEnabled",
  AUTOPLAY_NEXT_DURATION: "autoplayNextDuration",
  AUTOPLAY_NEXT_LAYOUT: "autoplayNextLayout",
  DL_SORT_BY: "dlSortBy",
  DL_SORT_DIR: "dlSortDir",
  DL_SHOW_UNTRACKED: "dlShowUntracked",
  EPISODE_RELEASE_CACHE: "episodeReleaseCache",
  SOURCE_FAILOVER_CACHE: "sourceFailoverCache",
  DISCORD_RPC_ENABLED: "discordRpcEnabled",
  DISCORD_RPC_SHOW_COVER: "discordRpcShowCover",
  DISCORD_RPC_SHOW_TIMESTAMP: "discordRpcShowTimestamp",
  DISCORD_RPC_SHOW_BUTTON: "discordRpcShowButton",
  GAMEPAD_ENABLED: "gamepadEnabled",
  FORCE_TV_MODE: "forceTvMode",
  PREFER_NATIVE_EXOPLAYER: "preferNativeExoPlayer"
};
export const getApiKey = () => "KEYLESS_ANDROID_MODE";
const FAILOVER_CACHE_MAX = 200;
export const getFailoverSource = epKey => {
  const cache = storage.get(STORAGE_KEYS.SOURCE_FAILOVER_CACHE) || {};
  return cache[epKey]?.sourceId || null;
};
export const setFailoverSource = (epKey, sourceId) => {
  const cache = storage.get(STORAGE_KEYS.SOURCE_FAILOVER_CACHE) || {};
  const keys = Object.keys(cache);
  if (keys.length >= FAILOVER_CACHE_MAX) {
    const evict = keys.slice(0, keys.length - FAILOVER_CACHE_MAX + 1);
    evict.forEach(k => delete cache[k]);
  }
  cache[epKey] = {
    sourceId,
    ts: Date.now()
  };
  storage.set(STORAGE_KEYS.SOURCE_FAILOVER_CACHE, cache);
};
export const clearFailoverSource = epKey => {
  const cache = storage.get(STORAGE_KEYS.SOURCE_FAILOVER_CACHE) || {};
  if (cache[epKey] !== undefined) {
    delete cache[epKey];
    storage.set(STORAGE_KEYS.SOURCE_FAILOVER_CACHE, cache);
  }
};
export const isElectron = true;
export function formatBytes(bytes) {
  if (bytes === null || bytes === undefined) return "…";
  if (bytes === -1) return null;
  if (bytes === 0) return "0 B";
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
  if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + " MB";
  return (bytes / (1024 * 1024 * 1024)).toFixed(2) + " GB";
}
export const secureStorage = {
  async get(key) {
    return androidBridge.secureGet(key);
  },
  async set(key, value) {
    return androidBridge.secureSet(key, value ?? "");
  }
};
export async function clearAppCaches() {
  try {
    await androidBridge.clearAppCache();
  } catch {}
  localStorage.removeItem("streambert_anilistCache");
  localStorage.removeItem("streambert_episodeGroupCache");
  localStorage.removeItem("streambert_aniskipCache");
  for (const key of Object.keys(localStorage)) {
    if (key.startsWith("dlDur_")) localStorage.removeItem(key);
  }
}
