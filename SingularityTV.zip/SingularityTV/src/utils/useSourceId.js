import { useEffect, useState } from "react";
import { fetchImdbId, fetchNumericId, fetchKinopoiskId, sourceIdType } from "./api";
const LABELS = {
  imdb: "IMDb ID",
  numeric: "Provider ID",
  kinopoisk: "Kinopoisk ID"
};
export function useSourceId(sourceId, type, mediaId) {
  const idType = sourceIdType(sourceId);
  const strId = String(mediaId || "");
  const needsConversion = idType === "imdb" && !strId.startsWith("tt") || idType === "numeric" && strId.startsWith("tt") || idType === "kinopoisk";
  const [state, setState] = useState({
    key: null,
    id: null,
    error: null
  });
  const key = needsConversion ? `${idType}:${type}:${mediaId}` : null;
  useEffect(() => {
    if (!key) return;
    let cancelled = false;
    const resolve = idType === "kinopoisk" ? fetchKinopoiskId : idType === "numeric" ? fetchNumericId : fetchImdbId;
    resolve(type, mediaId).then(id => !cancelled && setState({
      key,
      id,
      error: null
    })).catch(e => !cancelled && setState({
      key,
      id: null,
      error: e.message
    }));
    return () => {
      cancelled = true;
    };
  }, [key, idType, type, mediaId]);
  const idLabel = LABELS[idType] ?? "ID";
  if (!needsConversion) {
    return {
      id: mediaId,
      loading: false,
      error: null,
      idLabel
    };
  }
  if (state.key !== key) return {
    id: null,
    loading: true,
    error: null,
    idLabel
  };
  return {
    id: state.id,
    loading: !state.id && !state.error,
    error: state.error,
    idLabel
  };
}
