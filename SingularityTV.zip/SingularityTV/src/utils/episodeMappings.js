export const EPISODE_GROUP_IDS = {};
export function applyEpisodeMapping(_seriesId, season, episode, groupMap) {
  if (!groupMap) return {
    season,
    episode
  };
  const mapped = groupMap.get(`${season}_${episode}`);
  if (!mapped) return {
    season,
    episode
  };
  return mapped;
}
export function buildEpisodeGroupMap(groupData) {
  const map = new Map();
  if (!groupData?.groups) return map;
  const sortedGroups = [...groupData.groups].sort((a, b) => a.order - b.order);
  sortedGroups.forEach((group, groupIndex) => {
    const sourceSeason = groupIndex + 1;
    const sortedEpisodes = [...(group.episodes || [])].sort((a, b) => a.order - b.order);
    sortedEpisodes.forEach((ep, epIndex) => {
      map.set(`${ep.season_number}_${ep.episode_number}`, {
        season: sourceSeason,
        episode: epIndex + 1
      });
    });
  });
  return map;
}
