let active = false;
export function setPlayerGamepadActive(value) {
  active = !!value;
}
export function isPlayerGamepadActive() {
  return active;
}
