const CINEMETA_URLS = ["https://cinemeta-live.strem.io", "https://v3-cinemeta.strem.io"];
const TVMAZE_BASE = "https://api.tvmaze.com";
const ANILIST_API = "https://graphql.anilist.co";
const WIKIDATA_SPARQL = "https://query.wikidata.org/sparql";
try {
  if (typeof localStorage !== "undefined" && !localStorage.getItem("streambert_hnembed_only_v1")) {
    localStorage.setItem("streambert_hnembed_only_v1", "1");
    const cur = localStorage.getItem("streambert_playerSource");
    if (cur !== '"hnembed"' && cur !== "hnembed" && cur !== '"hianime"' && cur !== "hianime") {
      localStorage.setItem("streambert_playerSource", JSON.stringify("hnembed"));
    }
  }
} catch {}
export const imgUrl = (path, _size = "w500") => {
  if (!path || typeof path !== "string") return null;
  const trimmed = path.trim();
  if (!trimmed) return null;
  if (trimmed.startsWith("data:") || trimmed.startsWith("blob:") || trimmed.startsWith("file:")) {
    return trimmed;
  }
  if (trimmed.startsWith("https://")) return trimmed;
  if (trimmed.startsWith("http://")) {
    return "https://" + trimmed.slice("http://".length);
  }
  if (trimmed.startsWith("//")) return "https:" + trimmed;
  return null;
};
let _onUnreachable = null;
export const setApiErrorHandlers = (_onAuth, onUnreachable) => {
  _onUnreachable = onUnreachable;
};
const _metaCache = new Map();
const META_CACHE_TTL = 15 * 60 * 1000;
export function clearMetadataCache() {
  _metaCache.clear();
  try {
    localStorage.removeItem("streambert_trendingCache");
  } catch {}
}
export const clearTmdbCache = clearMetadataCache;
const _idMap = new Map();
export function registerIdMapping(ids = {}) {
  const {
    imdbId,
    numericId,
    anilistId,
    tvmazeId
  } = ids;
  const merged = {
    ...(imdbId ? _idMap.get(String(imdbId)) : null),
    ...(numericId ? _idMap.get(String(numericId)) : null),
    ...(imdbId ? {
      imdbId: String(imdbId)
    } : null),
    ...(numericId ? {
      numericId: String(numericId)
    } : null),
    ...(anilistId ? {
      anilistId: Number(anilistId)
    } : null),
    ...(tvmazeId ? {
      tvmazeId: Number(tvmazeId)
    } : null)
  };
  if (merged.imdbId) _idMap.set(String(merged.imdbId), merged);
  if (merged.numericId) _idMap.set(String(merged.numericId), merged);
  if (merged.anilistId) _idMap.set(`anilist:${merged.anilistId}`, merged);
  if (merged.imdbId && merged.numericId) {
    try {
      localStorage.setItem(`streambert_numid_${merged.imdbId}`, String(merged.numericId));
    } catch {}
  }
}
export const FALLBACK_MOVIES = [{
  id: "tt0816692",
  imdb_id: "tt0816692",
  numeric_id: 157336,
  title: "Interstellar",
  media_type: "movie",
  release_date: "2014-11-05",
  runtime: 169,
  vote_average: 8.7,
  original_language: "en",
  certification: "PG-13",
  poster_path: "https://images.metahub.space/poster/medium/tt0816692/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt0816692/img",
  genres: [{
    id: "Adventure",
    name: "Adventure"
  }, {
    id: "Drama",
    name: "Drama"
  }, {
    id: "Sci-Fi",
    name: "Sci-Fi"
  }],
  overview: "When Earth becomes uninhabitable in the future, a farmer and ex-NASA pilot, Joseph Cooper, is tasked to pilot a spacecraft, along with a team of researchers, to find a new planet for humans."
}, {
  id: "tt15239678",
  imdb_id: "tt15239678",
  numeric_id: 693134,
  title: "Dune: Part Two",
  media_type: "movie",
  release_date: "2024-02-27",
  runtime: 166,
  vote_average: 8.5,
  original_language: "en",
  certification: "PG-13",
  poster_path: "https://images.metahub.space/poster/medium/tt15239678/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt15239678/img",
  genres: [{
    id: "Action",
    name: "Action"
  }, {
    id: "Adventure",
    name: "Adventure"
  }, {
    id: "Sci-Fi",
    name: "Sci-Fi"
  }],
  overview: "Paul Atreides unites with Chani and the Fremen while on a warpath of revenge against the conspirators who destroyed his family."
}, {
  id: "tt15398776",
  imdb_id: "tt15398776",
  numeric_id: 872585,
  title: "Oppenheimer",
  media_type: "movie",
  release_date: "2023-07-19",
  runtime: 180,
  vote_average: 8.3,
  original_language: "en",
  certification: "R",
  poster_path: "https://images.metahub.space/poster/medium/tt15398776/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt15398776/img",
  genres: [{
    id: "Biography",
    name: "Biography"
  }, {
    id: "Drama",
    name: "Drama"
  }, {
    id: "History",
    name: "History"
  }],
  overview: "The story of J. Robert Oppenheimer's role in the development of the atomic bomb during World War II."
}, {
  id: "tt0133093",
  imdb_id: "tt0133093",
  numeric_id: 603,
  title: "The Matrix",
  media_type: "movie",
  release_date: "1999-03-31",
  runtime: 136,
  vote_average: 8.7,
  original_language: "en",
  certification: "R",
  poster_path: "https://images.metahub.space/poster/medium/tt0133093/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt0133093/img",
  genres: [{
    id: "Action",
    name: "Action"
  }, {
    id: "Sci-Fi",
    name: "Sci-Fi"
  }],
  overview: "When a beautiful stranger leads computer hacker Neo to a forbidding underworld, he discovers the shocking truth—the life he knows is the elaborate deception of an evil cyber-intelligence."
}, {
  id: "tt1375666",
  imdb_id: "tt1375666",
  numeric_id: 27205,
  title: "Inception",
  media_type: "movie",
  release_date: "2010-07-16",
  runtime: 148,
  vote_average: 8.8,
  original_language: "en",
  certification: "PG-13",
  poster_path: "https://images.metahub.space/poster/medium/tt1375666/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt1375666/img",
  genres: [{
    id: "Action",
    name: "Action"
  }, {
    id: "Adventure",
    name: "Adventure"
  }, {
    id: "Sci-Fi",
    name: "Sci-Fi"
  }],
  overview: "A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O."
}, {
  id: "tt0468569",
  imdb_id: "tt0468569",
  numeric_id: 155,
  title: "The Dark Knight",
  media_type: "movie",
  release_date: "2008-07-18",
  runtime: 152,
  vote_average: 9.0,
  original_language: "en",
  certification: "PG-13",
  poster_path: "https://images.metahub.space/poster/medium/tt0468569/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt0468569/img",
  genres: [{
    id: "Action",
    name: "Action"
  }, {
    id: "Crime",
    name: "Crime"
  }, {
    id: "Drama",
    name: "Drama"
  }],
  overview: "When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests of his ability to fight injustice."
}, {
  id: "tt4633694",
  imdb_id: "tt4633694",
  numeric_id: 324857,
  title: "Spider-Man: Into the Spider-Verse",
  media_type: "movie",
  release_date: "2018-12-14",
  runtime: 117,
  vote_average: 8.4,
  original_language: "en",
  certification: "PG",
  poster_path: "https://images.metahub.space/poster/medium/tt4633694/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt4633694/img",
  genres: [{
    id: "Animation",
    name: "Animation"
  }, {
    id: "Action",
    name: "Action"
  }, {
    id: "Adventure",
    name: "Adventure"
  }],
  overview: "Teen Miles Morales becomes the Spider-Man of his universe and must join with five spider-powered individuals from other dimensions to stop a threat for all realities."
}, {
  id: "tt5311514",
  imdb_id: "tt5311514",
  numeric_id: 372058,
  title: "Your Name.",
  media_type: "movie",
  release_date: "2016-08-26",
  runtime: 106,
  vote_average: 8.4,
  original_language: "ja",
  origin_country: ["JP"],
  genre_ids: [16],
  certification: "PG",
  poster_path: "https://images.metahub.space/poster/medium/tt5311514/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt5311514/img",
  genres: [{
    id: 16,
    name: "Animation"
  }, {
    id: "Drama",
    name: "Drama"
  }, {
    id: "Fantasy",
    name: "Fantasy"
  }],
  overview: "Two teenagers share a profound, magical connection upon discovering they are swapping bodies. Things manage to become even more complicated when the boy and girl decide to meet in person."
}];
export const FALLBACK_SERIES = [{
  id: "tt0903747",
  imdb_id: "tt0903747",
  numeric_id: 1396,
  name: "Breaking Bad",
  title: "Breaking Bad",
  media_type: "tv",
  first_air_date: "2008-01-20",
  vote_average: 9.5,
  original_language: "en",
  certification: "TV-MA",
  status: "Ended",
  number_of_seasons: 5,
  number_of_episodes: 62,
  poster_path: "https://images.metahub.space/poster/medium/tt0903747/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt0903747/img",
  genres: [{
    id: "Crime",
    name: "Crime"
  }, {
    id: "Drama",
    name: "Drama"
  }, {
    id: "Thriller",
    name: "Thriller"
  }],
  overview: "A chemistry teacher diagnosed with inoperable lung cancer turns to manufacturing and selling methamphetamine with a former student in order to secure his family's future."
}, {
  id: "tt4574334",
  imdb_id: "tt4574334",
  numeric_id: 66732,
  name: "Stranger Things",
  title: "Stranger Things",
  media_type: "tv",
  first_air_date: "2016-07-15",
  vote_average: 8.7,
  original_language: "en",
  certification: "TV-14",
  status: "Returning Series",
  number_of_seasons: 4,
  number_of_episodes: 34,
  poster_path: "https://images.metahub.space/poster/medium/tt4574334/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt4574334/img",
  genres: [{
    id: "Drama",
    name: "Drama"
  }, {
    id: "Fantasy",
    name: "Fantasy"
  }, {
    id: "Horror",
    name: "Horror"
  }],
  overview: "When a young boy vanishes, a small town uncovers a mystery involving secret experiments, terrifying supernatural forces, and one strange little girl."
}, {
  id: "tt2560140",
  imdb_id: "tt2560140",
  numeric_id: 1429,
  name: "Attack on Titan",
  title: "Attack on Titan",
  media_type: "tv",
  first_air_date: "2013-04-07",
  vote_average: 9.1,
  original_language: "ja",
  origin_country: ["JP"],
  genre_ids: [16],
  certification: "TV-MA",
  status: "Ended",
  number_of_seasons: 4,
  number_of_episodes: 89,
  poster_path: "https://images.metahub.space/poster/medium/tt2560140/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt2560140/img",
  genres: [{
    id: 16,
    name: "Animation"
  }, {
    id: "Action",
    name: "Action"
  }, {
    id: "Adventure",
    name: "Adventure"
  }],
  overview: "After his hometown is destroyed and his mother is killed, young Eren Jaeger vows to cleanse the earth of the giant humanoid Titans that have brought humanity to the brink of extinction."
}, {
  id: "tt11126994",
  imdb_id: "tt11126994",
  numeric_id: 94605,
  name: "Arcane",
  title: "Arcane",
  media_type: "tv",
  first_air_date: "2021-11-06",
  vote_average: 9.0,
  original_language: "en",
  certification: "TV-14",
  status: "Ended",
  number_of_seasons: 2,
  number_of_episodes: 18,
  poster_path: "https://images.metahub.space/poster/medium/tt11126994/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt11126994/img",
  genres: [{
    id: 16,
    name: "Animation"
  }, {
    id: "Action",
    name: "Action"
  }, {
    id: "Sci-Fi",
    name: "Sci-Fi"
  }],
  overview: "Set in Utopian Piltover and the oppressed underground of Zaun, the story follows the origins of two iconic League Of Legends champions and the power that will tear them apart."
}, {
  id: "tt12343534",
  imdb_id: "tt12343534",
  numeric_id: 95479,
  name: "Jujutsu Kaisen",
  title: "Jujutsu Kaisen",
  media_type: "tv",
  first_air_date: "2020-10-03",
  vote_average: 8.6,
  original_language: "ja",
  origin_country: ["JP"],
  genre_ids: [16],
  certification: "TV-MA",
  status: "Returning Series",
  number_of_seasons: 2,
  number_of_episodes: 47,
  poster_path: "https://images.metahub.space/poster/medium/tt12343534/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt12343534/img",
  genres: [{
    id: 16,
    name: "Animation"
  }, {
    id: "Action",
    name: "Action"
  }, {
    id: "Fantasy",
    name: "Fantasy"
  }],
  overview: "A boy swallows a cursed talisman - the finger of a demon - and becomes cursed himself. He enters a shaman's school to be able to locate the demon's other body parts and thus exorcise himself."
}, {
  id: "tt0388629",
  imdb_id: "tt0388629",
  numeric_id: 37854,
  name: "One Piece",
  title: "One Piece",
  media_type: "tv",
  first_air_date: "1999-10-20",
  vote_average: 9.0,
  original_language: "ja",
  origin_country: ["JP"],
  genre_ids: [16],
  certification: "TV-14",
  status: "Returning Series",
  number_of_seasons: 22,
  number_of_episodes: 1122,
  poster_path: "https://images.metahub.space/poster/medium/tt0388629/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt0388629/img",
  genres: [{
    id: 16,
    name: "Animation"
  }, {
    id: "Action",
    name: "Action"
  }, {
    id: "Adventure",
    name: "Adventure"
  }],
  overview: "Monkey D. Luffy sets off on an adventure with his pirate crew in hopes of finding the greatest treasure ever, known as the 'One Piece'."
}];
for (const m of [...FALLBACK_MOVIES, ...FALLBACK_SERIES]) {
  registerIdMapping({
    imdbId: m.imdb_id,
    numericId: m.numeric_id
  });
}
async function fetchJsonWithTimeout(url, options = {}, timeoutMs = 9000) {
  const controller = new AbortController();
  const tid = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      ...options,
      signal: controller.signal
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(tid);
  }
}
async function fetchCinemeta(subpath) {
  let lastErr = null;
  for (const base of CINEMETA_URLS) {
    try {
      const json = await fetchJsonWithTimeout(`${base}${subpath}`, {}, 8000);
      if (json && (json.metas || json.meta)) return json;
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr || new Error("Cinemeta unreachable");
}
function normalizeCinemetaItem(m, forcedType = null) {
  if (!m) return null;
  const mediaType = forcedType || (m.type === "series" || m.type === "tv" ? "tv" : "movie");
  const imdbId = m.imdb_id || (String(m.id || "").startsWith("tt") ? m.id : null);
  const numericId = m.moviedb_id || null;
  const canonicalId = imdbId || numericId || m.id;
  registerIdMapping({
    imdbId,
    numericId
  });
  if (!m.poster && !m.background) return null;
  const curYear = new Date().getFullYear();
  const yearStr = String(m.releaseInfo || m.year || "").slice(0, 4);
  if (yearStr && Number(yearStr) > curYear) return null;
  const releasedStr = m.released ? String(m.released).slice(0, 10) : yearStr ? `${yearStr}-01-01` : "";
  if (m.released && new Date(m.released).getTime() > Date.now() + 86400000) return null;
  const genresRaw = Array.isArray(m.genres) ? m.genres : [];
  const genres = genresRaw.map((g, i) => typeof g === "string" ? {
    id: g === "Animation" ? 16 : g || i,
    name: g
  } : g);
  const isAnim = genresRaw.some(g => String(g?.name || g).toLowerCase().includes("animation") || String(g?.name || g).toLowerCase().includes("anime"));
  const countryStr = String(m.country || "").toUpperCase();
  const isJp = countryStr.includes("JAPAN") || countryStr.includes("JP") || m.original_language === "ja";
  const runtimeMatch = String(m.runtime || "").match(/(\d+)/);
  const runtimeMins = runtimeMatch ? parseInt(runtimeMatch[1], 10) : null;
  return {
    id: canonicalId,
    imdb_id: imdbId,
    moviedb_id: numericId,
    media_type: mediaType,
    title: mediaType === "movie" ? m.name || m.title : undefined,
    name: mediaType === "tv" ? m.name || m.title : undefined,
    overview: m.description || m.overview || "",
    poster_path: m.poster || (imdbId ? `https://images.metahub.space/poster/medium/${imdbId}/img` : null),
    backdrop_path: m.background || (imdbId ? `https://images.metahub.space/background/medium/${imdbId}/img` : m.poster || null),
    release_date: mediaType === "movie" ? releasedStr : undefined,
    first_air_date: mediaType === "tv" ? releasedStr : undefined,
    vote_average: m.imdbRating ? parseFloat(m.imdbRating) : 0,
    runtime: runtimeMins,
    genres,
    genre_ids: isAnim ? [16] : [],
    original_language: isJp ? "ja" : "en",
    origin_country: isJp ? ["JP"] : [],
    certification: m.certification || m.ageRating || null,
    status: m.status || "Released",
    _rawVideos: Array.isArray(m.videos) ? m.videos : null,
    _rawTrailers: Array.isArray(m.trailers) ? m.trailers : null,
    _rawCast: Array.isArray(m.cast) ? m.cast : [],
    _rawDirectors: Array.isArray(m.director) ? m.director : [],
    _rawWriters: Array.isArray(m.writer) ? m.writer : []
  };
}
function buildSeasonsFromVideos(videos = []) {
  const seasonMap = new Map();
  for (const v of videos) {
    const sNum = Number(v.season ?? v.season_number ?? 1);
    const epNum = Number(v.episode ?? v.number ?? v.episode_number ?? 1);
    if (!Number.isFinite(sNum) || sNum < 0) continue;
    if (!seasonMap.has(sNum)) seasonMap.set(sNum, []);
    seasonMap.get(sNum).push({
      id: v.id || `${sNum}_${epNum}`,
      episode_number: epNum,
      season_number: sNum,
      name: v.name || v.title || `Episode ${epNum}`,
      overview: v.overview || v.description || "",
      still_path: v.thumbnail || null,
      air_date: v.released ? String(v.released).slice(0, 10) : null
    });
  }
  const seasons = [...seasonMap.entries()].sort((a, b) => a[0] - b[0]).map(([sNum, eps]) => {
    eps.sort((a, b) => a.episode_number - b.episode_number);
    return {
      season_number: sNum,
      name: sNum === 0 ? "Specials" : `Season ${sNum}`,
      episode_count: eps.length,
      episodes: eps
    };
  });
  return seasons;
}
async function fetchTvMazeSeries(idOrImdb) {
  let show = null;
  const str = String(idOrImdb);
  if (str.startsWith("tt")) {
    show = await fetchJsonWithTimeout(`${TVMAZE_BASE}/lookup/shows?imdb=${encodeURIComponent(str)}`);
  } else if (str.startsWith("tvmaze:")) {
    const tvmId = str.split(":")[1];
    show = await fetchJsonWithTimeout(`${TVMAZE_BASE}/shows/${tvmId}`);
  }
  if (!show || !show.id) return null;
  const [episodes, cast] = await Promise.all([fetchJsonWithTimeout(`${TVMAZE_BASE}/shows/${show.id}/episodes?specials=1`).catch(() => []), fetchJsonWithTimeout(`${TVMAZE_BASE}/shows/${show.id}/cast`).catch(() => [])]);
  const stripHtml = s => String(s || "").replace(/<[^>]+>/g, "").trim();
  const mappedVideos = (episodes || []).map(ep => ({
    id: ep.id,
    season: ep.season,
    episode: ep.number || 1,
    name: ep.name || `Episode ${ep.number || 1}`,
    overview: stripHtml(ep.summary),
    thumbnail: ep.image?.original || ep.image?.medium || null,
    released: ep.airdate || null
  }));
  const seasons = buildSeasonsFromVideos(mappedVideos);
  const imdbId = show.externals?.imdb || (str.startsWith("tt") ? str : null);
  registerIdMapping({
    imdbId,
    tvmazeId: show.id
  });
  return {
    id: imdbId || `tvmaze:${show.id}`,
    imdb_id: imdbId,
    name: show.name,
    title: show.name,
    media_type: "tv",
    first_air_date: show.premiered || "",
    vote_average: show.rating?.average || 0,
    status: show.status || "Ended",
    original_language: show.language?.toLowerCase().startsWith("ja") ? "ja" : "en",
    origin_country: show.network?.country?.code ? [show.network.country.code] : [],
    poster_path: show.image?.original || show.image?.medium || null,
    backdrop_path: show.image?.original || show.image?.medium || null,
    overview: stripHtml(show.summary),
    genres: (show.genres || []).map(g => ({
      id: g === "Anime" ? 16 : g,
      name: g
    })),
    genre_ids: (show.genres || []).includes("Anime") ? [16] : [],
    seasons,
    number_of_seasons: seasons.filter(s => s.season_number > 0).length,
    number_of_episodes: mappedVideos.length,
    _seasonsByNumber: Object.fromEntries(seasons.map(s => [s.season_number, s])),
    _cast: (cast || []).map((c, idx) => ({
      id: c.person?.id || idx,
      name: c.person?.name || "Unknown",
      character: c.character?.name || "",
      profile_path: c.person?.image?.medium || c.person?.image?.original || null
    }))
  };
}
async function searchImdbSuggestions(query) {
  const q = String(query || "").trim();
  if (!q) return [];
  const slug = q.toLowerCase().replace(/\s+/g, "_").replace(/[^a-z0-9_]/g, "");
  if (!slug.replace(/_/g, "")) return [];
  const firstChar = slug[0];
  const data = await fetchJsonWithTimeout(`https://v3.sg.media-imdb.com/suggestion/${firstChar}/${encodeURIComponent(slug)}.json`, {}, 6000);
  const items = Array.isArray(data?.d) ? data.d : [];
  const curYear = new Date().getFullYear();
  return items.filter(i => i.id && String(i.id).startsWith("tt") && i.i?.imageUrl && (!i.y || Number(i.y) <= curYear)).map(i => {
    const qid = String(i.qid || i.q || "").toLowerCase();
    const isTv = qid.includes("tv") || qid.includes("series");
    return {
      id: i.id,
      imdb_id: i.id,
      media_type: isTv ? "tv" : "movie",
      title: !isTv ? i.l : undefined,
      name: isTv ? i.l : undefined,
      release_date: !isTv && i.y ? `${i.y}-01-01` : undefined,
      first_air_date: isTv && i.y ? `${i.y}-01-01` : undefined,
      poster_path: i.i?.imageUrl || `https://images.metahub.space/poster/medium/${i.id}/img`,
      backdrop_path: `https://images.metahub.space/background/medium/${i.id}/img`,
      vote_average: 0,
      overview: i.s ? `Starring: ${i.s}` : ""
    };
  });
}

async function searchArabicViaWikidata(query) {
  const q = String(query || "").trim();
  if (!q) return [];
  const collected = [];
  const seen = new Set();
  const pushItem = item => {
    if (!item || !item.id) return;
    const key = `${item.media_type}_${item.id}`;
    if (seen.has(key)) return;
    seen.add(key);
    collected.push(item);
  };
  try {
    const searchData = await fetchJsonWithTimeout(
      `https://www.wikidata.org/w/api.php?action=wbsearchentities&search=${encodeURIComponent(q)}&language=ar&uselang=ar&type=item&limit=10&format=json&origin=*`,
      {},
      5500
    );
    const hits = Array.isArray(searchData?.search) ? searchData.search : [];
    const qids = hits.map(h => h.id).filter(Boolean).slice(0, 10);
    if (qids.length > 0) {
      const entData = await fetchJsonWithTimeout(
        `https://www.wikidata.org/w/api.php?action=wbgetentities&ids=${qids.join("|")}&props=claims|labels&languages=ar|en&format=json&origin=*`,
        {},
        5500
      );
      const entities = entData?.entities || {};
      const enQueries = [];
      for (const qid of qids) {
        const ent = entities[qid];
        if (!ent) continue;
        const claims = ent.claims || {};
        const imdbVal = claims.P345?.[0]?.mainsnak?.datavalue?.value || "";
        const enLabel = ent.labels?.en?.value || "";
        const arLabel = ent.labels?.ar?.value || q;
        const p31Ids = (claims.P31 || []).map(c => c?.mainsnak?.datavalue?.value?.id).filter(Boolean);
        const isTv = p31Ids.includes("Q5398426") || p31Ids.includes("Q581714") || p31Ids.includes("Q15416");
        const isPerson = p31Ids.includes("Q5");
        if (imdbVal && imdbVal.startsWith("tt")) {
          pushItem({
            id: imdbVal,
            imdb_id: imdbVal,
            media_type: isTv ? "tv" : "movie",
            title: !isTv ? (enLabel || arLabel) : undefined,
            name: isTv ? (enLabel || arLabel) : undefined,
            poster_path: `https://images.metahub.space/poster/medium/${imdbVal}/img`,
            backdrop_path: `https://images.metahub.space/background/medium/${imdbVal}/img`,
            vote_average: 0,
            overview: arLabel && enLabel && arLabel !== enLabel ? arLabel : ""
          });
        } else if (enLabel && (isPerson || !imdbVal)) {
          enQueries.push(enLabel);
        }
      }
      if (enQueries.length > 0 && collected.length < 8) {
        const extra = await Promise.all(enQueries.slice(0, 2).map(eq => searchImdbSuggestions(eq).catch(() => [])));
        for (const list of extra) {
          for (const item of list) pushItem(item);
        }
      }
    }
  } catch {}
  if (collected.length < 6) {
    try {
      const tr = await fetchJsonWithTimeout(
        `https://translate.googleapis.com/translate_a/single?client=gtx&sl=ar&tl=en&dt=t&q=${encodeURIComponent(q)}`,
        {},
        4000
      );
      const enText = Array.isArray(tr?.[0]) ? tr[0].map(p => p?.[0] || "").join("").trim() : "";
      if (enText && /[a-zA-Z]/.test(enText)) {
        const [mList, sList, iList] = await Promise.all([
          fetchCinemeta(`/catalog/movie/top/search=${encodeURIComponent(enText)}.json`).then(d => (d.metas || []).map(m => normalizeCinemetaItem(m, "movie"))).catch(() => []),
          fetchCinemeta(`/catalog/series/top/search=${encodeURIComponent(enText)}.json`).then(d => (d.metas || []).map(m => normalizeCinemetaItem(m, "tv"))).catch(() => []),
          searchImdbSuggestions(enText).catch(() => [])
        ]);
        for (const item of [...iList, ...mList, ...sList]) pushItem(item);
      }
    } catch {}
  }
  return collected;
}

async function resolveIdsViaWikidata(id, type = "movie") {
  const str = String(id || "").trim();
  if (!str) return null;
  const cached = _idMap.get(str);
  if (cached?.imdbId && cached?.numericId) return cached;
  const isImdb = str.startsWith("tt");
  const tmdbProp = type === "tv" ? "P4983" : "P4947";
  const query = isImdb ? `SELECT ?mId ?tvId ?kp WHERE { ?item wdt:P345 "${str}" . OPTIONAL { ?item wdt:P4947 ?mId . } OPTIONAL { ?item wdt:P4983 ?tvId . } OPTIONAL { ?item wdt:P2603 ?kp . } } LIMIT 1` : `SELECT ?imdb ?kp WHERE { ?item wdt:${tmdbProp} "${str}" . OPTIONAL { ?item wdt:P345 ?imdb . } OPTIONAL { ?item wdt:P2603 ?kp . } } LIMIT 1`;
  try {
    const data = await fetchJsonWithTimeout(`${WIKIDATA_SPARQL}?format=json&query=${encodeURIComponent(query)}`, {
      headers: {
        Accept: "application/sparql-results+json"
      }
    }, 6000);
    const row = data?.results?.bindings?.[0];
    if (!row) return cached || null;
    const imdbId = isImdb ? str : row.imdb?.value || null;
    const mVal = row.mId?.value || null;
    const tvVal = row.tvId?.value || null;
    const numericId = !isImdb ? str : type === "tv" ? tvVal || mVal : mVal || tvVal;
    const kpId = row.kp?.value || null;
    registerIdMapping({
      imdbId,
      numericId
    });
    return {
      imdbId,
      numericId,
      kpId
    };
  } catch {
    return cached || null;
  }
}
export const tmdbFetch = async (path, _unusedApiKey = null) => {
  const cleanPath = String(path || "").split("?")[0];
  const cached = _metaCache.get(path);
  if (cached && Date.now() < cached.expiresAt) return cached.data;
  const storeCache = data => {
    _metaCache.set(path, {
      data,
      expiresAt: Date.now() + META_CACHE_TTL
    });
    return data;
  };
  try {
    if (cleanPath === "/trending/movie/week") {
      try {
        const data = await fetchCinemeta("/catalog/movie/top.json");
        const results = (data.metas || []).slice(0, 28).map(m => normalizeCinemetaItem(m, "movie")).filter(Boolean);
        if (results.length > 0) return storeCache({
          results
        });
      } catch {}
      return storeCache({
        results: FALLBACK_MOVIES
      });
    }
    if (cleanPath === "/trending/tv/week") {
      try {
        const data = await fetchCinemeta("/catalog/series/top.json");
        const results = (data.metas || []).slice(0, 28).map(m => normalizeCinemetaItem(m, "tv")).filter(Boolean);
        if (results.length > 0) return storeCache({
          results
        });
      } catch {}
      return storeCache({
        results: FALLBACK_SERIES
      });
    }
    if (cleanPath === "/movie/top_rated") {
      try {
        const data = await fetchCinemeta("/catalog/movie/imdbRating.json");
        const results = (data.metas || []).slice(0, 20).map(m => normalizeCinemetaItem(m, "movie")).filter(Boolean);
        if (results.length > 0) return storeCache({
          results
        });
      } catch {}
      return storeCache({
        results: [...FALLBACK_MOVIES].reverse()
      });
    }
    if (cleanPath === "/tv/top_rated") {
      try {
        const data = await fetchCinemeta("/catalog/series/imdbRating.json");
        const results = (data.metas || []).slice(0, 20).map(m => normalizeCinemetaItem(m, "tv")).filter(Boolean);
        if (results.length > 0) return storeCache({
          results
        });
      } catch {}
      return storeCache({
        results: [...FALLBACK_SERIES].reverse()
      });
    }
    if (cleanPath === "/discover/genre") {
      const params = new URLSearchParams(path.split("?")[1] || "");
      const genre = (params.get("genre") || "").trim();
      const page = Math.max(1, parseInt(params.get("page") || "1", 10) || 1);
      if (!genre) return { results: [], hasMore: false, page };
      const skip = (page - 1) * 100;
      const suffix = skip > 0 ? `&skip=${skip}.json` : ".json";
      const [mRaw, sRaw] = await Promise.all([
        fetchCinemeta(`/catalog/movie/top/genre=${encodeURIComponent(genre)}${suffix}`).then(d => d.metas || []).catch(() => []),
        fetchCinemeta(`/catalog/series/top/genre=${encodeURIComponent(genre)}${suffix}`).then(d => d.metas || []).catch(() => [])
      ]);
      const mRes = mRaw.map(m => normalizeCinemetaItem(m, "movie")).filter(Boolean);
      const sRes = sRaw.map(m => normalizeCinemetaItem(m, "tv")).filter(Boolean);
      const merged = [];
      const maxLen = Math.max(mRes.length, sRes.length);
      for (let i = 0; i < maxLen; i++) {
        if (mRes[i]) merged.push(mRes[i]);
        if (sRes[i]) merged.push(sRes[i]);
      }
      return storeCache({ results: merged, hasMore: mRaw.length >= 40 || sRaw.length >= 40, page });
    }
    if (cleanPath === "/search/multi") {
      const qParam = new URLSearchParams(path.split("?")[1] || "").get("query") || "";
      const q = qParam.trim();
      if (!q) return {
        results: []
      };
      if (/^tt\d+$/i.test(q)) {
        return {
          results: [{
            id: q.toLowerCase(),
            imdb_id: q.toLowerCase(),
            title: `IMDb Title (${q.toLowerCase()})`,
            media_type: "movie",
            poster_path: `https://images.metahub.space/poster/medium/${q.toLowerCase()}/img`
          }, {
            id: q.toLowerCase(),
            imdb_id: q.toLowerCase(),
            name: `IMDb Series (${q.toLowerCase()})`,
            media_type: "tv",
            poster_path: `https://images.metahub.space/poster/medium/${q.toLowerCase()}/img`
          }]
        };
      }
      const hasArabic = /[\u0600-\u06FF]/.test(q);
      const matchedGenre = resolveGenreFromQuery(q);
      const [genreSearch, arabicSearch, movieSearch, seriesSearch, imdbSearch] = await Promise.all([
        matchedGenre ? tmdbFetch(`/discover/genre?genre=${encodeURIComponent(matchedGenre)}&page=1`, _unusedApiKey).then(d => d?.results || []).catch(() => []) : Promise.resolve([]),
        hasArabic ? searchArabicViaWikidata(q).catch(() => []) : Promise.resolve([]),
        hasArabic ? Promise.resolve([]) : fetchCinemeta(`/catalog/movie/top/search=${encodeURIComponent(q)}.json`).then(d => (d.metas || []).map(m => normalizeCinemetaItem(m, "movie"))).catch(() => []),
        hasArabic ? Promise.resolve([]) : fetchCinemeta(`/catalog/series/top/search=${encodeURIComponent(q)}.json`).then(d => (d.metas || []).map(m => normalizeCinemetaItem(m, "tv"))).catch(() => []),
        hasArabic ? Promise.resolve([]) : searchImdbSuggestions(q).catch(() => [])
      ]);
      const merged = [];
      const seen = new Set();
      for (const item of genreSearch) {
        if (!item) continue;
        const k = `${item.media_type}_${item.id}`;
        if (!seen.has(k)) {
          seen.add(k);
          merged.push(item);
        }
      }
      const maxLen = Math.max(arabicSearch.length, movieSearch.length, seriesSearch.length, imdbSearch.length);
      for (let i = 0; i < maxLen; i++) {
        for (const list of [arabicSearch, movieSearch, seriesSearch, imdbSearch]) {
          const item = list[i];
          if (!item) continue;
          const k = `${item.media_type}_${item.id}`;
          if (!seen.has(k)) {
            seen.add(k);
            merged.push(item);
          }
        }
      }
      if (merged.length === 0) {
        const ql = q.toLowerCase();
        const localHits = [...FALLBACK_MOVIES, ...FALLBACK_SERIES].filter(i => (i.title || i.name || "").toLowerCase().includes(ql));
        return storeCache({
          results: localHits
        });
      }
      return storeCache({
        results: merged.slice(0, 20)
      });
    }
    const movieMatch = cleanPath.match(/^\/movie\/([^/]+)(?:\/(.+))?$/);
    if (movieMatch) {
      let movieId = movieMatch[1];
      const subResource = movieMatch[2] || null;
      if (!String(movieId).startsWith("tt")) {
        const resolved = await resolveIdsViaWikidata(movieId, "movie");
        if (resolved?.imdbId) movieId = resolved.imdbId;
      }
      let metaItem = null;
      try {
        const raw = await fetchCinemeta(`/meta/movie/${encodeURIComponent(movieId)}.json`);
        if (raw?.meta) metaItem = normalizeCinemetaItem(raw.meta, "movie");
      } catch {}
      if (!metaItem) {
        metaItem = FALLBACK_MOVIES.find(m => String(m.id) === String(movieId) || String(m.numeric_id) === String(movieId)) || {
          id: movieId,
          imdb_id: String(movieId).startsWith("tt") ? movieId : null,
          title: String(movieId),
          media_type: "movie",
          genres: [],
          overview: "Metadata unavailable — stream playback remains active."
        };
      }
      if (!subResource) {
        return storeCache(metaItem);
      }
      if (subResource === "videos") {
        const trailers = (metaItem._rawTrailers || []).filter(t => t.source).map(t => ({
          key: t.source,
          site: "YouTube",
          type: t.type || "Trailer"
        }));
        return storeCache({
          results: trailers
        });
      }
      if (subResource === "credits") {
        const cast = (metaItem._rawCast || []).map((name, idx) => ({
          id: `cast_${idx}`,
          name: typeof name === "string" ? name : name?.name || "Cast",
          character: typeof name === "object" ? name.character || "" : "",
          profile_path: null
        }));
        const crew = [...(metaItem._rawDirectors || []).map((name, idx) => ({
          id: `dir_${idx}`,
          name,
          job: "Director"
        })), ...(metaItem._rawWriters || []).map((name, idx) => ({
          id: `wri_${idx}`,
          name,
          job: "Writer"
        }))];
        return storeCache({
          cast,
          crew
        });
      }
      if (subResource === "release_dates") {
        const cert = metaItem.certification || "PG-13";
        return storeCache({
          results: [{
            iso_3166_1: "US",
            release_dates: [{
              certification: cert,
              type: 3
            }]
          }]
        });
      }
      if (subResource === "recommendations" || subResource === "similar") {
        return storeCache({
          results: FALLBACK_MOVIES.filter(m => m.id !== metaItem.id).slice(0, 6)
        });
      }
      if (subResource === "external_ids") {
        const resolved = await resolveIdsViaWikidata(movieId, "movie");
        return storeCache({
          imdb_id: metaItem.imdb_id || resolved?.imdbId || (String(movieId).startsWith("tt") ? movieId : null)
        });
      }
    }
    const tvSeasonMatch = cleanPath.match(/^\/tv\/([^/]+)\/season\/(\d+)$/);
    if (tvSeasonMatch) {
      const tvId = tvSeasonMatch[1];
      const seasonNum = parseInt(tvSeasonMatch[2], 10);
      const series = await tmdbFetch(`/tv/${tvId}`);
      const seasonObj = series?._seasonsByNumber?.[seasonNum] || (series?.seasons || []).find(s => s.season_number === seasonNum);
      if (seasonObj && Array.isArray(seasonObj.episodes)) {
        return storeCache({
          season_number: seasonNum,
          name: seasonObj.name || `Season ${seasonNum}`,
          episodes: seasonObj.episodes
        });
      }
      const fallbackCount = seasonObj?.episode_count || 12;
      const fallbackEpisodes = Array.from({
        length: fallbackCount
      }, (_, idx) => ({
        id: `${tvId}_s${seasonNum}_e${idx + 1}`,
        episode_number: idx + 1,
        season_number: seasonNum,
        name: `Episode ${idx + 1}`,
        overview: "",
        still_path: series?.backdrop_path || series?.poster_path || null,
        air_date: series?.first_air_date || "2020-01-01"
      }));
      return storeCache({
        season_number: seasonNum,
        name: `Season ${seasonNum}`,
        episodes: fallbackEpisodes
      });
    }
    const tvMatch = cleanPath.match(/^\/tv\/([^/]+)(?:\/(.+))?$/);
    if (tvMatch) {
      let tvId = tvMatch[1];
      const subResource = tvMatch[2] || null;
      if (!String(tvId).startsWith("tt") && !String(tvId).startsWith("tvmaze:")) {
        const resolved = await resolveIdsViaWikidata(tvId, "tv");
        if (resolved?.imdbId) tvId = resolved.imdbId;
      }
      let seriesItem = null;
      try {
        const raw = await fetchCinemeta(`/meta/series/${encodeURIComponent(tvId)}.json`);
        if (raw?.meta) {
          const norm = normalizeCinemetaItem(raw.meta, "tv");
          const seasons = buildSeasonsFromVideos(norm._rawVideos || []);
          const validSeasons = seasons.filter(s => s.season_number > 0);
          seriesItem = {
            ...norm,
            seasons: seasons.length > 0 ? seasons : [{
              season_number: 1,
              name: "Season 1",
              episode_count: 12
            }],
            number_of_seasons: validSeasons.length || 1,
            number_of_episodes: (norm._rawVideos || []).length || 12,
            _seasonsByNumber: Object.fromEntries(seasons.map(s => [s.season_number, s]))
          };
        }
      } catch {}
      if (!seriesItem || !seriesItem.seasons || seriesItem.seasons.length === 0) {
        const tvm = await fetchTvMazeSeries(tvId).catch(() => null);
        if (tvm) seriesItem = tvm;
      }
      if (!seriesItem) {
        const fb = FALLBACK_SERIES.find(s => String(s.id) === String(tvId) || String(s.numeric_id) === String(tvId));
        seriesItem = fb ? {
          ...fb,
          seasons: Array.from({
            length: fb.number_of_seasons || 1
          }, (_, idx) => ({
            season_number: idx + 1,
            name: `Season ${idx + 1}`,
            episode_count: 12
          }))
        } : {
          id: tvId,
          imdb_id: String(tvId).startsWith("tt") ? tvId : null,
          name: String(tvId),
          title: String(tvId),
          media_type: "tv",
          seasons: [{
            season_number: 1,
            name: "Season 1",
            episode_count: 12
          }],
          number_of_seasons: 1,
          number_of_episodes: 12,
          genres: [],
          overview: "Metadata unavailable — stream playback remains active."
        };
      }
      if (!subResource) {
        return storeCache(seriesItem);
      }
      if (subResource === "videos") {
        const trailers = (seriesItem._rawTrailers || []).filter(t => t.source).map(t => ({
          key: t.source,
          site: "YouTube",
          type: t.type || "Trailer"
        }));
        return storeCache({
          results: trailers
        });
      }
      if (subResource === "aggregate_credits" || subResource === "credits") {
        if (seriesItem._cast) {
          return storeCache({
            cast: seriesItem._cast,
            crew: []
          });
        }
        const cast = (seriesItem._rawCast || []).map((name, idx) => ({
          id: `cast_${idx}`,
          name: typeof name === "string" ? name : name?.name || "Cast",
          roles: [{
            character: typeof name === "object" ? name.character || "" : ""
          }],
          profile_path: null
        }));
        const crew = (seriesItem._rawDirectors || []).map((name, idx) => ({
          id: `dir_${idx}`,
          name,
          jobs: [{
            job: "Director"
          }]
        }));
        return storeCache({
          cast,
          crew
        });
      }
      if (subResource === "content_ratings") {
        const rating = seriesItem.certification || "TV-14";
        return storeCache({
          results: [{
            iso_3166_1: "US",
            rating
          }]
        });
      }
      if (subResource === "recommendations" || subResource === "similar") {
        return storeCache({
          results: FALLBACK_SERIES.filter(s => s.id !== seriesItem.id).slice(0, 6)
        });
      }
      if (subResource === "external_ids") {
        const resolved = await resolveIdsViaWikidata(tvId, "tv");
        return storeCache({
          imdb_id: seriesItem.imdb_id || resolved?.imdbId || (String(tvId).startsWith("tt") ? tvId : null)
        });
      }
    }
    return {
      results: []
    };
  } catch (err) {
    _onUnreachable?.();
    throw err;
  }
};
export const PLAYER_SOURCES = [{
  id: "hnembed",
  label: "HnEmbed",
  tag: null,
  note: "HD",
  supportsProgress: true,
  progressViaFrames: true,
  idType: "any",
  colorParam: null,
  langParam: null,
  params: {},
  movieUrl: id => `https://hnembed.cc/embed/movie/${id}`,
  tvUrl: (id, season, ep) => `https://hnembed.cc/embed/tv/${id}/${season}/${ep}`
}];
export const NEEDS_INTERCEPT = ["vidsrc", "autoembed", "vidsrcnet", "multiembed", "twoembed", "devideosrc", "frembed", "kinohub"];
export const getSourceUrl = (sourceId, type, id, season, ep, extraParams = {}, accentColor = null, subtitleLang = null) => {
  let src = PLAYER_SOURCES.find(s => s.id === sourceId) ?? PLAYER_SOURCES[0];
  if (!id) return null;
  if (type !== "movie" && !src.tvUrl) return null;
  if (src.idType === "numeric" && String(id).startsWith("tt")) {
    src = PLAYER_SOURCES[0];
  }
  const baseUrl = type === "movie" ? src.movieUrl(id) : src.tvUrl(id, season, ep);
  const url = new URL(baseUrl);
  Object.entries(src.params || {}).forEach(([key, value]) => {
    url.searchParams.set(key, value);
  });
  if (accentColor && src.colorParam) {
    const hex = accentColor.replace(/^#/, "");
    url.searchParams.set(src.colorParam, src.colorWithHash ? `#${hex}` : hex);
  }
  if (subtitleLang && src.langParam) {
    url.searchParams.set(src.langParam, subtitleLang);
  }
  Object.entries(extraParams).forEach(([key, value]) => {
    if (value != null) {
      url.searchParams.set(key, value);
    }
  });
  return url.toString();
};
export const CLEAN_USER_AGENT = typeof window !== "undefined" && window.electron?.cleanUserAgent || "";
export const sourceUsesCleanUa = sourceId => PLAYER_SOURCES.find(s => s.id === sourceId)?.cleanUserAgent ?? false;
export const sourceIdType = sourceId => PLAYER_SOURCES.find(s => s.id === sourceId)?.idType ?? "any";
export const sourceNeedsImdb = sourceId => sourceIdType(sourceId) === "imdb";
export const sourceNeedsKinopoisk = sourceId => sourceIdType(sourceId) === "kinopoisk";
export const sourceIsMovieOnly = sourceId => PLAYER_SOURCES.find(s => s.id === sourceId)?.movieOnly ?? false;
export async function fetchImdbId(type, mediaId) {
  const str = String(mediaId || "").trim();
  if (/^tt\d+$/i.test(str)) return str;
  const cached = _idMap.get(str);
  if (cached?.imdbId) return cached.imdbId;
  const resolved = await resolveIdsViaWikidata(str, type);
  if (resolved?.imdbId) return resolved.imdbId;
  throw new Error(`No IMDb ID found for ${type} ${mediaId}`);
}
export async function fetchNumericId(type, mediaId) {
  const str = String(mediaId || "").trim();
  if (/^\d+$/.test(str)) return str;
  const cached = _idMap.get(str);
  if (cached?.numericId) return String(cached.numericId);
  try {
    const savedNum = localStorage.getItem(`streambert_numid_${str}`);
    if (savedNum && /^\d+$/.test(savedNum)) {
      registerIdMapping({
        imdbId: str,
        numericId: savedNum
      });
      return savedNum;
    }
  } catch {}
  if (typeof window !== "undefined" && window.AndroidBridge?.resolveNumericId) {
    try {
      const nativeNum = window.AndroidBridge.resolveNumericId(str, type === "tv" ? "tv" : "movie");
      if (nativeNum && /^\d+$/.test(String(nativeNum).trim())) {
        const cleanNum = String(nativeNum).trim();
        registerIdMapping({
          imdbId: str,
          numericId: cleanNum
        });
        return cleanNum;
      }
    } catch {}
  }
  try {
    const cType = type === "tv" ? "series" : "movie";
    const raw = await fetchCinemeta(`/meta/${cType}/${encodeURIComponent(str)}.json`);
    if (raw?.meta?.moviedb_id) {
      const numStr = String(raw.meta.moviedb_id);
      registerIdMapping({
        imdbId: str,
        numericId: numStr
      });
      return numStr;
    }
  } catch {}
  const resolved = await resolveIdsViaWikidata(str, type);
  if (resolved?.numericId) {
    return String(resolved.numericId);
  }
  return str;
}
export async function fetchKinopoiskId(type, mediaId) {
  const str = String(mediaId || "").trim();
  const resolved = await resolveIdsViaWikidata(str, type);
  if (resolved?.kpId) return resolved.kpId;
  throw new Error(`No Kinopoisk ID found for ${type} ${mediaId}`);
}
export const sourceSupportsProgress = sourceId => PLAYER_SOURCES.find(s => s.id === sourceId)?.supportsProgress ?? false;
export const sourceProgressViaFrames = sourceId => PLAYER_SOURCES.find(s => s.id === sourceId)?.progressViaFrames ?? false;
export const sourceSkipsResetGuard = sourceId => PLAYER_SOURCES.find(s => s.id === sourceId)?.skipResetGuard ?? false;
export const sourceIsAsync = sourceId => PLAYER_SOURCES.find(s => s.id === sourceId)?.async ?? false;
export const sourceSupportsAnime = sourceId => PLAYER_SOURCES.find(s => s.id === sourceId)?.supportsAnime ?? false;
export const sourceIsAnimeCapable = sourceId => {
  const src = PLAYER_SOURCES.find(s => s.id === sourceId);
  return !!(src && (src.tag === "ANIME" || src.supportsAnime));
};
export const getAnimeSourceUrl = (sourceId, anilistId, episode, dubMode = "sub", extraParams = {}) => {
  const src = PLAYER_SOURCES.find(s => s.id === sourceId);
  if (!src?.animeUrl || !anilistId || !episode) return null;
  const url = new URL(src.animeUrl(anilistId, episode, dubMode === "dub" ? "dub" : "sub"));
  Object.entries(src.params || {}).forEach(([k, v]) => url.searchParams.set(k, v));
  Object.entries(extraParams).forEach(([k, v]) => {
    if (v != null) url.searchParams.set(k, v);
  });
  return url.toString();
};
export const getNextNonAsyncSource = currentId => {
  const nonAsync = PLAYER_SOURCES.filter(s => !s.async);
  if (nonAsync.length === 0) return null;
  const idx = nonAsync.findIndex(s => s.id === currentId);
  if (idx < 0) return nonAsync[0].id;
  return nonAsync[(idx + 1) % nonAsync.length].id;
};
export const cleanAnilistDescription = desc => {
  if (!desc) return desc;
  let clean = desc.split("<").map((chunk, i) => i === 0 ? chunk : chunk.slice(chunk.indexOf(">") + 1)).join("").replace(/>/g, "");
  clean = clean.replace(/\(Source:[^)]*\)/gi, "");
  clean = clean.replace(/\bNote:[^\n]*/gi, "");
  clean = clean.replace(/[\s\n]+$/, "").trim();
  return clean;
};
const ANILIST_QUERY = `
query ($search: String, $type: MediaType) {
  Media(search: $search, type: $type, sort: SEARCH_MATCH) {
    id
    idMal
    title { romaji english native }
    description(asHtml: false)
    coverImage { extraLarge large }
    bannerImage
    genres
    averageScore
    episodes
    status
    season
    seasonYear
    studios(isMain: true) { nodes { name } }
    startDate { year month }
    relations {
      edges {
        relationType
        node {
          id
          type
          format
          title { romaji english }
          episodes
          startDate { year month }
          seasonYear
        }
      }
    }
  }
}`;
const ANILIST_CACHE_KEY = "streambert_anilistCache";
const ANILIST_CACHE_TTL = 1000 * 60 * 60 * 24 * 7;
let _anilistCache = null;
function getAnilistCache() {
  if (_anilistCache) return _anilistCache;
  try {
    const raw = localStorage.getItem(ANILIST_CACHE_KEY);
    _anilistCache = raw ? JSON.parse(raw) : {};
  } catch {
    _anilistCache = {};
  }
  const now = Date.now();
  for (const key of Object.keys(_anilistCache)) {
    if (now - _anilistCache[key].ts > ANILIST_CACHE_TTL) {
      delete _anilistCache[key];
    }
  }
  return _anilistCache;
}
let _anilistFlushTimer = null;
function flushAnilistCache() {
  if (_anilistFlushTimer) clearTimeout(_anilistFlushTimer);
  _anilistFlushTimer = setTimeout(() => {
    _anilistFlushTimer = null;
    try {
      localStorage.setItem(ANILIST_CACHE_KEY, JSON.stringify(_anilistCache));
    } catch {}
  }, 500);
}
export const fetchAnilistData = async (title, type = "ANIME", mediaId = null) => {
  if (!title) return null;
  const cacheKey = mediaId ? `${type}__id_${mediaId}` : `${type}__${title.toLowerCase().trim()}`;
  const cache = getAnilistCache();
  const entry = cache[cacheKey];
  if (entry && Date.now() - entry.ts <= ANILIST_CACHE_TTL) {
    return entry.data;
  }
  try {
    const res = await fetch(ANILIST_API, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json"
      },
      body: JSON.stringify({
        query: ANILIST_QUERY,
        variables: {
          search: title,
          type
        }
      })
    });
    const json = await res.json();
    const data = json?.data?.Media || null;
    cache[cacheKey] = {
      data,
      ts: Date.now()
    };
    flushAnilistCache();
    return data;
  } catch {
    if (entry) return entry.data;
    return null;
  }
};
export const buildAnilistSeasons = anilistData => {
  if (!anilistData) return null;
  const main = {
    id: anilistData.id,
    title: anilistData.title?.english || anilistData.title?.romaji || anilistData.title?.native,
    episodes: anilistData.episodes || null,
    year: anilistData.startDate?.year || anilistData.seasonYear || 9999,
    month: anilistData.startDate?.month || 0
  };
  const sequels = (anilistData.relations?.edges || []).filter(e => e.relationType === "SEQUEL" && e.node.type === "ANIME" && (e.node.format === "TV" || e.node.format === "TV_SHORT")).map(e => ({
    id: e.node.id,
    title: e.node.title?.english || e.node.title?.romaji,
    episodes: e.node.episodes || null,
    year: e.node.startDate?.year || e.node.seasonYear || 9999,
    month: e.node.startDate?.month || 0
  }));
  const all = [main, ...sequels].sort((a, b) => a.year !== b.year ? a.year - b.year : a.month - b.month);
  return all.map((s, i) => ({
    seasonNum: i + 1,
    ...s
  }));
};
export const isAnimeContent = (item, details) => {
  const d = details || item;
  if (!d) return false;
  const lang = d.original_language;
  const countries = d.origin_country || [];
  const genreIds = d.genre_ids || (d.genres || []).map(g => g.id || g.name);
  const hasAnimation = genreIds.some(g => g === 16 || String(g).toLowerCase() === "animation" || String(g).toLowerCase() === "anime");
  return hasAnimation && (lang === "ja" || countries.includes("JP"));
};
export const ANIME_DEFAULT_SOURCE = "hianime";
export const NON_ANIME_DEFAULT_SOURCE = "hnembed";
export const fetchEpisodeGroup = async _groupId => {
  return null;
};


const GENRE_ALIASES = {
  "Horror": ["horror", "horor", "horro", "horrer", "scary", "slasher", "رعب", "رهب", "مرعب", "رعيب", "مخيف", "اشباح"],
  "Action": ["action", "acton", "actoin", "akshen", "اكشن", "حركه", "قتال", "اكش"],
  "Sci-Fi": ["sci-fi", "scifi", "scifi", "sci fi", "science fiction", "scfi", "خيال علمي", "خيال", "علمي", "فضاء"],
  "Fantasy": ["fantasy", "fantazy", "fantasi", "فانتازيا", "فانتسي", "فانتازي", "سحر", "اساطير"],
  "Comedy": ["comedy", "comedi", "comdey", "komedy", "funny", "كوميديا", "كوميدي", "كومدي", "مضحك", "ضحك"],
  "Drama": ["drama", "darma", "دراما", "درامي"],
  "Thriller": ["thriller", "thriler", "triller", "suspense", "اثاره", "تشويق", "مثير"],
  "Animation": ["animation", "animaton", "anime", "cartoon", "انميشن", "انمي", "كارتون", "كرتون", "رسوم متحركه", "رسوم"],
  "Mystery": ["mystery", "mystry", "mistery", "غموض", "غامض", "لغز", "الغاز"],
  "Crime": ["crime", "crim", "detective", "جريمه", "جرائم", "عصابات", "تحقيق"],
  "Adventure": ["adventure", "adventur", "advnture", "مغامره", "مغامرات", "مغامر"],
  "Romance": ["romance", "romanc", "romantic", "love", "رومانسي", "رومانسيه", "حب", "عشق"],
  "Family": ["family", "famly", "kids", "عائلي", "عائله", "اطفال"],
  "Documentary": ["documentary", "documantary", "docu", "وثائقي", "وثائقيه", "وثائق"]
};

function normalizeGenreSearchText(text) {
  return String(text || "")
    .toLowerCase()
    .replace(/[\u064B-\u065F\u0670]/g, "")
    .replace(/[أإآ]/g, "ا")
    .replace(/ة/g, "ه")
    .replace(/ى/g, "ي")
    .replace(/\b(movies|movie|films|film|series|shows|show)\b/g, "")
    .replace(/(افلام|فلم|فيلم|مسلسلات|مسلسل)\s*/g, "")
    .replace(/^ال(?=[\u0600-\u06FF]{2,})/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function editDistance(a, b) {
  const m = a.length;
  const n = b.length;
  if (Math.abs(m - n) > 2) return 99;
  const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost);
    }
  }
  return dp[m][n];
}

export function resolveGenreFromQuery(query) {
  const norm = normalizeGenreSearchText(query);
  if (!norm || norm.length < 3) return null;
  for (const [genre, aliases] of Object.entries(GENRE_ALIASES)) {
    for (const alias of aliases) {
      const na = normalizeGenreSearchText(alias);
      if (norm === na) return genre;
    }
  }
  for (const [genre, aliases] of Object.entries(GENRE_ALIASES)) {
    for (const alias of aliases) {
      const na = normalizeGenreSearchText(alias);
      const maxDist = na.length >= 6 ? 2 : 1;
      if (editDistance(norm, na) <= maxDist) return genre;
    }
  }
  return null;
}
