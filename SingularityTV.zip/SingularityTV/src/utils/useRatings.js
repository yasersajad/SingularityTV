import { useState, useEffect, useMemo } from "react";
import { certToMinAge, fetchMovieRating, fetchTVRating, getAgeLimitSetting, getRatingCountry } from "./ageRating";
import { storage } from "./storage";
const CACHE_KEY = "ratingsCache";
const CACHE_TTL = 1000 * 60 * 60 * 24 * 7;
function readCache() {
  try {
    return storage.get(CACHE_KEY) || {};
  } catch {
    return {};
  }
}
function writeCache(cache) {
  try {
    storage.set(CACHE_KEY, cache);
  } catch {}
}
function evictStale(cache) {
  const now = Date.now();
  for (const key of Object.keys(cache)) {
    if (now - cache[key].ts > CACHE_TTL) {
      delete cache[key];
    }
  }
  return cache;
}
export function useRatings(items) {
  const [ratingsMap, setRatingsMap] = useState({});
  const [ageLimitSetting] = useState(() => getAgeLimitSetting(storage));
  const [ratingCountry] = useState(() => getRatingCountry(storage));
  const itemsKey = useMemo(() => {
    if (!items?.length) return "";
    return items.map(i => `${i.media_type === "tv" ? "tv" : "movie"}_${i.id}`).sort().join(",");
  }, [items]);
  useEffect(() => {
    if (!itemsKey) return;
    const cache = evictStale(readCache());
    let cacheModified = false;
    const initial = {};
    const missing = [];
    for (const item of items) {
      const type = item.media_type === "tv" ? "tv" : "movie";
      const mapKey = `${type}_${item.id}`;
      const cacheKey = `${type}_${item.id}_${ratingCountry}`;
      if (item.certification) {
        const minAge = certToMinAge(item.certification, ratingCountry);
        initial[mapKey] = {
          cert: item.certification,
          minAge
        };
        continue;
      }
      const entry = cache[cacheKey];
      const isValid = entry && Date.now() - entry.ts <= CACHE_TTL;
      if (isValid) {
        initial[mapKey] = {
          cert: entry.cert,
          minAge: entry.minAge
        };
      } else {
        missing.push(item);
      }
    }
    if (Object.keys(initial).length) {
      setRatingsMap(prev => ({
        ...prev,
        ...initial
      }));
    }
    if (!missing.length || ageLimitSetting === null) return;
    let cancelled = false;
    (async () => {
      for (let i = 0; i < Math.min(missing.length, 8); i++) {
        if (cancelled) break;
        const item = missing[i];
        const type = item.media_type === "tv" ? "tv" : "movie";
        const mapKey = `${type}_${item.id}`;
        const cacheKey = `${type}_${item.id}_${ratingCountry}`;
        try {
          const result = type === "tv" ? await fetchTVRating(item.id, null, ratingCountry) : await fetchMovieRating(item.id, null, ratingCountry);
          if (!cancelled) {
            cache[cacheKey] = {
              cert: result.cert,
              minAge: result.minAge,
              ts: Date.now()
            };
            cacheModified = true;
            setRatingsMap(prev => ({
              ...prev,
              [mapKey]: result
            }));
          }
        } catch {}
      }
      if (cacheModified && !cancelled) writeCache(cache);
    })();
    return () => {
      cancelled = true;
    };
  }, [itemsKey, ratingCountry, ageLimitSetting]);
  return {
    ratingsMap,
    ageLimitSetting,
    ratingCountry
  };
}
export function getRatingForItem(item, ratingsMap) {
  if (!item) return {
    cert: null,
    minAge: null
  };
  const type = item.media_type === "tv" ? "tv" : "movie";
  return ratingsMap[`${type}_${item.id}`] || {
    cert: item.certification || null,
    minAge: item.certification ? certToMinAge(item.certification, "US") : null
  };
}
