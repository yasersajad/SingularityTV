import React, { useCallback, useMemo, useState, useEffect } from "react";
import MediaCard from "../components/MediaCard";
import { imgUrl } from "../utils/api";
import { EyeIcon, WatchedIcon, PlayIcon, DownloadIcon, FilmIcon } from "../components/Icons";
import { useRatings, getRatingForItem } from "../utils/useRatings";
import { isRestricted } from "../utils/ageRating";
import { storage, STORAGE_KEYS } from "../utils/storage";

export default function LibraryPage({
  history,
  inProgress,
  saved,
  progress,
  onSelect,
  watched,
  onMarkWatched,
  onMarkUnwatched,
  onRemoveHistory,
  downloads = [],
  onOpenExoPlayer
}) {
  const allItems = useMemo(() => [...inProgress, ...saved], [inProgress, saved]);
  const { ratingsMap, ageLimitSetting } = useRatings(allItems);
  const [sort, setSort] = useState(() => storage.get(STORAGE_KEYS.LIBRARY_SORT) || "manual");

  useEffect(() => {
    const handler = e => setSort(e.detail);
    window.addEventListener("streambert:library-sort-changed", handler);
    return () => window.removeEventListener("streambert:library-sort-changed", handler);
  }, []);

  const offlineDownloads = useMemo(() => {
    return (downloads || []).filter(
      d => d && (d.status === "completed" || d.status === "local") && (d.outputPath || d.filePath || d.path)
    );
  }, [downloads]);

  const playOfflineDownload = useCallback(
    dl => {
      const fileUrl = dl.outputPath || dl.filePath || dl.path;
      if (!fileUrl) return;
      const pk =
        dl.mediaType === "tv"
          ? `tv_${dl.tmdbId || dl.mediaId}_s${dl.season || 1}e${dl.episode || 1}`
          : `movie_${dl.tmdbId || dl.mediaId}`;
      const startSec = storage.get("dlTime_" + pk) || 0;
      const payload = {
        url: fileUrl,
        title: dl.name || dl.title || "Offline Video",
        startTimeSec: startSec,
        subtitles: dl.subtitles || [],
        progressKey: pk,
        mediaType: dl.mediaType || "movie",
        subTextColor: storage.get("subtitleTextColor") || "#FFFFFF",
          subBgStyle: storage.get("subtitleBgStyle") || "dark",
          subFontSizeSp: Number(storage.get("subtitleFontSizeSp") || 22),
          preferredSubLang: storage.get(STORAGE_KEYS.SUBTITLE_LANG) || "ar"
      };
      if (window.AndroidBridge?.openExoPlayer) {
        window.AndroidBridge.openExoPlayer(JSON.stringify(payload));
      } else {
        onOpenExoPlayer?.(payload);
      }
    },
    [onOpenExoPlayer]
  );

  const sortLabels = {
    manual: "Custom order",
    title: "A-Z",
    rating: "Top rated",
    year: "Newest first"
  };

  const getRating = useCallback(item => getRatingForItem(item, ratingsMap), [ratingsMap]);
  const itemRestricted = useCallback(
    item => isRestricted(getRating(item).minAge, ageLimitSetting),
    [getRating, ageLimitSetting]
  );

  return (
    <div className="fade-in">
      <div className="library-header">
        <div className="library-title">My Library</div>
        <div className="library-sub">Offline downloads, watch history, and saved titles</div>
      </div>

      {offlineDownloads.length > 0 && (
        <div className="library-section">
          <div className="library-section-title" style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <DownloadIcon />
            <span>Downloaded · Watch Offline ({offlineDownloads.length})</span>
          </div>
          <div className="offline-grid">
            {offlineDownloads.map(dl => (
              <button
                key={dl.id}
                className="offline-card"
                onClick={() => playOfflineDownload(dl)}
              >
                <div className="offline-card-poster">
                  {dl.posterPath ? (
                    <img src={imgUrl(dl.posterPath, "w185")} alt={dl.name || dl.title} />
                  ) : (
                    <div className="offline-card-fallback">
                      <FilmIcon />
                    </div>
                  )}
                  <div className="offline-card-play">
                    <PlayIcon />
                  </div>
                </div>
                <div className="offline-card-info">
                  <div className="offline-card-title">{dl.name || dl.title}</div>
                  <div className="offline-card-meta">
                    {dl.size || "Offline Ready"} · {dl.mediaType === "tv" ? "Series" : "Movie"}
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {inProgress.length > 0 && (
        <div className="library-section">
          <div className="library-section-title">Continue Watching</div>
          <div className="cards-grid">
            {inProgress.map(item => {
              const pk =
                item.media_type === "movie"
                  ? `movie_${item.id}`
                  : `tv_${item.id}_s${item.season}e${item.episode}`;
              const r = getRating(item);
              const restr = itemRestricted(item);
              return (
                <MediaCard
                  key={pk}
                  item={item}
                  onClick={() => onSelect(item)}
                  progress={progress[pk] || 0}
                  watched={watched}
                  onMarkWatched={onMarkWatched}
                  onMarkUnwatched={onMarkUnwatched}
                  ageRating={r.cert}
                  restricted={restr}
                />
              );
            })}
          </div>
        </div>
      )}

      {saved.length > 0 && (
        <div className="library-section">
          <div className="library-section-title">
            Watchlist ({saved.length})
            {sort !== "manual" && (
              <span style={{ fontSize: 12, fontWeight: 400, color: "var(--text3)", marginLeft: 10 }}>
                {sortLabels[sort]}
              </span>
            )}
          </div>
          <div className="cards-grid">
            {saved.map(item => {
              const r = getRating(item);
              const restr = itemRestricted(item);
              return (
                <MediaCard
                  key={`${item.media_type}_${item.id}`}
                  item={item}
                  onClick={() => onSelect(item)}
                  watched={watched}
                  onMarkWatched={onMarkWatched}
                  onMarkUnwatched={onMarkUnwatched}
                  ageRating={r.cert}
                  restricted={restr}
                />
              );
            })}
          </div>
        </div>
      )}

      {history.length > 0 && (
        <div className="library-section">
          <div className="library-section-title">Watch History</div>
          <div className="history-rows">
            {history.map(item => {
              const pk =
                item.media_type === "movie"
                  ? `movie_${item.id}`
                  : `tv_${item.id}_s${item.season}e${item.episode}`;
              const isWatched = !!watched?.[pk];
              return (
                <div
                  key={`${pk}_${item.watchedAt}`}
                  className="history-row"
                  onClick={() => onSelect(item)}
                >
                  <div className="history-thumb">
                    {item.poster_path && <img src={imgUrl(item.poster_path, "w92")} alt="" />}
                  </div>
                  <div style={{ flex: 1 }}>
                    <div
                      style={{
                        fontSize: 14,
                        fontWeight: 500,
                        display: "flex",
                        alignItems: "center",
                        gap: 6
                      }}
                    >
                      {item.title}
                      {isWatched && <WatchedIcon size={16} />}
                    </div>
                    <div style={{ fontSize: 12, color: "var(--text3)" }}>
                      {item.media_type === "tv" && item.season != null && item.episode != null && (
                        <>
                          {`S${item.season}E${item.episode}`}
                          {item.episodeName ? ` · ${item.episodeName}` : ""}
                          {" · "}
                        </>
                      )}
                      {new Date(item.watchedAt).toLocaleDateString("en-US", {
                        year: "numeric",
                        month: "short",
                        day: "numeric"
                      })}
                    </div>
                  </div>
                  <span
                    className={`search-result-type ${
                      item.media_type === "tv" ? "type-tv" : "type-movie"
                    }`}
                  >
                    {item.media_type === "tv" ? "Series" : "Movie"}
                  </span>
                  {onRemoveHistory && (
                    <button
                      className="history-remove-btn"
                      title="Remove from history"
                      onClick={e => {
                        e.stopPropagation();
                        onRemoveHistory(item);
                      }}
                    >
                      ✕
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {offlineDownloads.length === 0 && history.length === 0 && saved.length === 0 && (
        <div className="empty-state">
          <EyeIcon />
          <h3>Nothing here yet</h3>
          <p>Start watching or download a movie or series to watch offline.</p>
        </div>
      )}
    </div>
  );
}
