import { useState, useEffect, useLayoutEffect, useRef, useMemo, useCallback, memo } from "react";
import { EPISODE_GROUP_IDS, applyEpisodeMapping, buildEpisodeGroupMap } from "../utils/episodeMappings";
import { tmdbFetch, imgUrl, PLAYER_SOURCES, getSourceUrl, sourceSupportsProgress, sourceSkipsResetGuard, sourceProgressViaFrames, sourceIsAsync, sourceSupportsAnime, sourceIsAnimeCapable, sourceIsMovieOnly, getAnimeSourceUrl, fetchAnilistData, fetchEpisodeGroup, buildAnilistSeasons, cleanAnilistDescription, isAnimeContent, ANIME_DEFAULT_SOURCE, NON_ANIME_DEFAULT_SOURCE, NEEDS_INTERCEPT, CLEAN_USER_AGENT, sourceUsesCleanUa, getNextNonAsyncSource } from "../utils/api";
import { BookmarkIcon, BookmarkFillIcon, BackIcon, StarIcon, PlayIcon, TVIcon, DownloadIcon, WatchedIcon, TrailerIcon, RatingShieldIcon, RatingLockIcon, AlertIcon, SourceIcon, ShieldBlockIcon, PopOutIcon, CastIcon } from "../components/Icons";
import DownloadModal from "../components/DownloadModal";
import TrailerModal from "../components/TrailerModal";
import BlockedStatsModal from "../components/BlockedStatsModal";
import { useBlockedStats } from "../utils/useBlockedStats";
import { storage, STORAGE_KEYS, getFailoverSource, setFailoverSource, clearFailoverSource } from "../utils/storage";
import { useAutoplay } from "../utils/useAutoplay";
import { fetchAniSkipTimings } from "../utils/aniSkip";
import { fetchTVRating, isRestricted, getAgeLimitSetting, getRatingCountry } from "../utils/ageRating";
import DownloadConfirmModal from "../components/DownloadConfirmModal";
import { useCredits } from "../utils/useCredits";
import { GAMEPAD_PLAYER_SCRIPT, GAMEPAD_EXIT_CHECK_JS, GAMEPAD_EXIT_RESET_JS, GAMEPAD_CLEANUP_JS } from "../utils/playerGamepadScript";
import { useSourceId } from "../utils/useSourceId";
import { setPlayerGamepadActive } from "../utils/gamepadPlayerState";
import HiAnimeLoader from "../components/HiAnimeLoader";
import StreamPlayerFrame from "../components/StreamPlayerFrame";
function _makePartialCircle(pct) {
  const r = 5;
  const cx = 7;
  const cy = 7;
  const angle = pct / 100 * 2 * Math.PI - Math.PI / 2;
  const x = cx + r * Math.cos(angle);
  const y = cy + r * Math.sin(angle);
  const large = pct > 50 ? 1 : 0;
  return React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 14 14",
    style: {
      display: "inline-block",
      verticalAlign: "middle",
      marginRight: 4,
      flexShrink: 0
    }
  }, React.createElement("circle", {
    cx: cx,
    cy: cy,
    r: r,
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.5",
    opacity: "0.25"
  }), React.createElement("path", {
    d: `M ${cx} ${cy - r} A ${r} ${r} 0 ${large} 1 ${x.toFixed(3)} ${y.toFixed(3)} L ${cx} ${cy} Z`,
    fill: "currentColor",
    opacity: "0.9"
  }));
}
const _CIRCLE_25 = _makePartialCircle(25);
const _CIRCLE_50 = _makePartialCircle(50);
const _CIRCLE_75 = _makePartialCircle(75);
const _CIRCLE_MAP = {
  25: _CIRCLE_25,
  50: _CIRCLE_50,
  75: _CIRCLE_75
};
function PartialCircleIcon({
  pct
}) {
  return _CIRCLE_MAP[pct] ?? null;
}
function ContextMenu({
  x,
  y,
  isWatched,
  hasProgress,
  watchedLabel,
  unwatchedLabel,
  onMarkWatched,
  onMarkUnwatched,
  onMarkNotStarted,
  onClose
}) {
  const onCloseRef = useRef(onClose);
  onCloseRef.current = onClose;
  useEffect(() => {
    const close = () => onCloseRef.current();
    window.addEventListener("click", close);
    window.addEventListener("contextmenu", close);
    return () => {
      window.removeEventListener("click", close);
      window.removeEventListener("contextmenu", close);
    };
  }, []);
  return React.createElement("div", {
    className: "context-menu",
    style: {
      top: y,
      left: x
    },
    onClick: e => e.stopPropagation()
  }, isWatched ? React.createElement("button", {
    className: "context-menu-item",
    onClick: e => {
      e.stopPropagation();
      onMarkUnwatched();
      onCloseRef.current();
    }
  }, "\u21A9 ", unwatchedLabel) : React.createElement("button", {
    className: "context-menu-item",
    onClick: e => {
      e.stopPropagation();
      onMarkWatched();
      onCloseRef.current();
    }
  }, "\u2713 ", watchedLabel), onMarkNotStarted && !isWatched && hasProgress && React.createElement("button", {
    className: "context-menu-item",
    onClick: e => {
      e.stopPropagation();
      onMarkNotStarted();
      onCloseRef.current();
    }
  }, "\u2298 Mark as Not Started"));
}
function EpisodeDesc({
  overview,
  episodeName
}) {
  const [open, setOpen] = useState(false);
  if (!overview) return React.createElement("div", {
    className: "episode-desc"
  });
  return React.createElement(React.Fragment, null, React.createElement("div", {
    className: "episode-desc-wrap"
  }, React.createElement("div", {
    className: "episode-desc"
  }, overview), React.createElement("button", {
    className: "episode-desc-toggle",
    onClick: e => {
      e.stopPropagation();
      setOpen(true);
    }
  }, "More")), open && React.createElement("div", {
    className: "ep-desc-overlay",
    onClick: e => {
      e.stopPropagation();
      setOpen(false);
    }
  }, React.createElement("div", {
    className: "ep-desc-popup",
    onClick: e => e.stopPropagation()
  }, episodeName && React.createElement("div", {
    className: "ep-desc-popup-title"
  }, episodeName), React.createElement("p", {
    className: "ep-desc-popup-text"
  }, overview), React.createElement("button", {
    className: "ep-desc-popup-close",
    onClick: () => setOpen(false)
  }, "Close"))));
}
const INJECT_SKIP_CONTROLS = `
(function() {
  if (window.__skipControlsInjected) return;
  var style = document.createElement('style');
  style.innerHTML =
    '*:focus, *:focus-visible {' +
    'outline: none !important;' +
    'box-shadow: none !important;' +
    '}' +
    'video:focus, video:focus-visible {' +
    'outline: none !important;' +
    'box-shadow: none !important;' +
    '}';
  document.head.appendChild(style);
  window.__skipControlsInjected = true;

  var BACK_SVG = '<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" style=\"width:26px;height:26px\"><polyline points=\"1 4 1 10 7 10\"/><path d=\"M3.51 15a9 9 0 1 0 .49-4.53\"/><text x=\"13.5\" y=\"15.5\" text-anchor=\"middle\" font-size=\"6.5\" fill=\"currentColor\" stroke=\"none\" font-weight=\"800\" font-family=\"system-ui,sans-serif\">15</text></svg>';
  var FWD_SVG  = '<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" style=\"width:26px;height:26px\"><polyline points=\"23 4 23 10 17 10\"/><path d=\"M20.49 15a9 9 0 1 1-.49-4.53\"/><text x=\"10.5\" y=\"15.5\" text-anchor=\"middle\" font-size=\"6.5\" fill=\"currentColor\" stroke=\"none\" font-weight=\"800\" font-family=\"system-ui,sans-serif\">15</text></svg>';

  var wrap = document.createElement('div');
  wrap.id = '__skip-ui';
  wrap.style.cssText = [
    'position:fixed',
    'top:0','left:0','right:0','bottom:0',
    'pointer-events:none',
    'z-index:2147483647',
    'opacity:0',
    'transition:opacity 0.25s ease',
  ].join(';');

  function makeBtn(seconds, svg, label, side) {
    var btn = document.createElement('button');
    btn.innerHTML = svg + '<span style="font-size:11px;font-family:system-ui,sans-serif">' + label + '</span>';
    btn.setAttribute('tabindex', '-1');
    btn.title = label;
    btn.style.cssText = [
      'pointer-events:auto',
      'background:rgba(0,0,0,0.72)',
      'border:1px solid rgba(255,255,255,0.18)',
      'border-radius:8px',
      'color:white',
      'cursor:pointer',
      'padding:10px 18px',
      'display:flex',
      'align-items:center',
      'gap:7px',
      'backdrop-filter:blur(6px)',
      '-webkit-backdrop-filter:blur(6px)',
      'transition:background 0.15s',
      'font-size:12px',
    ].join(';');
    btn.style.position = 'absolute';
    btn.style.top = '50%';
    btn.style.transform = 'translateY(-50%)';

    if (side === 'left') {
      btn.style.left = '24px';
    } else {
      btn.style.right = '24px';
    }
    btn.onmouseenter = function() { btn.style.background = 'rgba(229,9,20,0.85)'; btn.style.borderColor = '#e5091466'; };
    btn.onmouseleave = function() { btn.style.background = 'rgba(0,0,0,0.72)'; btn.style.borderColor = 'rgba(255,255,255,0.18)'; };
    btn.onclick = function(e) {
      e.stopPropagation();
      var v = document.querySelector('video');
      if (v) v.currentTime = Math.max(0, Math.min(v.duration || 0, v.currentTime + seconds));
      show();
    };
    return btn;
  }

  wrap.appendChild(makeBtn(-15, BACK_SVG, '−15s', 'left'));
  wrap.appendChild(makeBtn(15,  FWD_SVG,  '+15s', 'right'));
  document.documentElement.appendChild(wrap);

  var idleTimer;
  function show() {
    wrap.style.opacity = '1';
    clearTimeout(idleTimer);
    idleTimer = setTimeout(function() { wrap.style.opacity = '0'; }, 2500);
  }
  document.addEventListener('mousemove', show, true);
  document.addEventListener('keydown', function(e) {
    const active = document.activeElement;

    // Keine Shortcuts wenn User tippt
    if (
      active &&
      active.matches('input, textarea, [contenteditable="true"]')
    ) {
      return;
    }

    // Key repeat blockieren (wenn Taste gehalten wird)
    if (e.repeat) return;

    const v = document.querySelector('video');
    if (!v) return;

    // Throttle (max 1 Aktion alle 250ms)
    const now = Date.now();
    if (window.__skipKeyCooldown && now < window.__skipKeyCooldown) return;
    window.__skipKeyCooldown = now + 250;

    if (e.code === 'Space') {
      e.preventDefault(); // verhindert Scrollen
      if (v.paused) v.play();
      else v.pause();
      show();
    }

    if (e.key === 'ArrowLeft') {
      v.currentTime = Math.max(0, v.currentTime - 10);
      show();
    }

    if (e.key === 'ArrowRight') {
      v.currentTime = Math.min(v.duration || 0, v.currentTime + 10);
      show();
    }
  }, true);
})();
`;
function parseAirDate(airDate) {
  if (!airDate) return null;
  const [y, m, d] = String(airDate).slice(0, 10).split("-").map(Number);
  if (!y || !m || !d) return null;
  return new Date(y, m - 1, d);
}
function startOfToday() {
  const t = new Date();
  t.setHours(0, 0, 0, 0);
  return t;
}
function isUnreleased(airDate) {
  const target = parseAirDate(airDate);
  return !!target && target > startOfToday();
}
function getDaysUntilRelease(airDate) {
  const target = parseAirDate(airDate);
  if (!target) return "";
  const days = Math.round((target - startOfToday()) / 86400000);
  if (days <= 0) return "Releasing today";
  if (days === 1) return "1 day left";
  return `${days} days left`;
}
export default function TVPage({
  item,
  apiKey,
  playerSettings,
  onSave,
  isSaved,
  onHistory,
  progress,
  saveProgress,
  onBack,
  onSettings,
  onDownloadStarted,
  watched,
  onMarkWatched,
  onMarkUnwatched,
  downloads,
  onGoToDownloads,
  onEpisodeChange,
  onOpenExoPlayer,
  history = []
}) {
  const [details, setDetails] = useState(null);
  const [seasonData, setSeasonData] = useState(null);
  const [failedSeasons, setFailedSeasons] = useState(() => new Set());
  const [selectedSeason, setSelectedSeason] = useState(() => item.season != null ? Number(item.season) : 1);
  const [selectedEp, setSelectedEp] = useState(null);
  const [playing, setPlaying] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loadingSeason, setLoadingSeason] = useState(false);
  const [showDownload, setShowDownload] = useState(false);
  const [trailerKey, setTrailerKey] = useState(null);
  const [showTrailer, setShowTrailer] = useState(false);
  const [downloadConfirm, setDownloadConfirm] = useState(null);
  const [pendingEpDownload, setPendingEpDownload] = useState(false);
  const credits = useCredits("tv", item.id, apiKey);
  const [m3u8Url, setM3u8Url] = useState(null);
  const m3u8FoundRef = useRef(false);
  const autoExoLaunchedRef = useRef(null);
  const pendingFailoverRef = useRef(false);
  m3u8FoundRef.current = !!m3u8Url;
  const [interceptedSubs, setInterceptedSubs] = useState([]);
  const [playerSource, setPlayerSource] = useState(() => storage.get("playerSource") || NON_ANIME_DEFAULT_SOURCE);
  const playerAccentColor = playerSettings?.accentColor ?? null;
  const playerSubLang = playerSettings?.subtitleLang ?? null;
  const [showSourceMenu, setShowSourceMenu] = useState(false);
  const isAsync = useMemo(() => sourceIsAsync(playerSource), [playerSource]);
  const supportsProgress = useMemo(() => sourceSupportsProgress(playerSource), [playerSource]);
  const progressViaFrames = useMemo(() => sourceProgressViaFrames(playerSource), [playerSource]);
  const [dubMode, setDubMode] = useState(() => storage.get(STORAGE_KEYS.HIANIME_DUB_MODE) || "sub");
  const [resolvedPlayerUrl, setResolvedPlayerUrl] = useState(null);
  const [resolvingUrl, setResolvingUrl] = useState(false);
  const [resolveError, setResolveError] = useState(null);
  const resolvingUrlRef = useRef(false);
  const resolvedPlayerUrlRef = useRef(null);
  const [anilistData, setAnilistData] = useState(null);
  const [anilistSeasons, setAnilistSeasons] = useState(null);
  const [anilistLoading, setAnilistLoading] = useState(false);
  const [episodeGroupData, setEpisodeGroupData] = useState(null);
  const [episodeGroupMap, setEpisodeGroupMap] = useState(null);
  const [webviewLoading, setWebviewLoading] = useState(false);
  const srcId = useSourceId(playerSource, "tv", item.id, apiKey);
  useEffect(() => {
    if (srcId.id && playing) setWebviewLoading(true);
  }, [srcId.id]);
  const [playerFullscreen, setPlayerFullscreen] = useState(false);
  const togglePlayerFullscreen = useCallback((forceState) => {
    setPlayerFullscreen(prev => {
      const next = typeof forceState === "boolean" ? forceState : !prev;
      if (next) {
        document.documentElement.setAttribute("data-player-fullscreen", "1");
        try { window.AndroidBridge?.setImmersiveMode?.(true); } catch {}
      } else {
        document.documentElement.removeAttribute("data-player-fullscreen");
      }
      return next;
    });
  }, []);
  useEffect(() => {
    window.__streambertExitFullscreen = () => { setPlaying(false); setPlayerFullscreen(false); document.documentElement.removeAttribute("data-player-fullscreen"); };
    return () => {
      if (window.__streambertExitFullscreen) delete window.__streambertExitFullscreen;
      document.documentElement.removeAttribute("data-player-fullscreen");
    };
  }, [togglePlayerFullscreen]);
  const [pipOpen, setPipOpen] = useState(false);
  const pipUrlRef = useRef(null);
  const pipWebContentsIdRef = useRef(null);
  const [menuPos, setMenuPos] = useState(null);
  const [skipTimings, setSkipTimings] = useState(null);
  const [skipPrompt, setSkipPrompt] = useState(null);
  const [introSkipMode] = useState(() => storage.get(STORAGE_KEYS.INTRO_SKIP_MODE) || "off");
  const sourceRef = useRef(null);
  const playerWrapRef = useRef(null);
  const webviewRef = useRef(null);
  const saveProgressRef = useRef(saveProgress);
  saveProgressRef.current = saveProgress;
  const onMarkWatchedRef = useRef(onMarkWatched);
  onMarkWatchedRef.current = onMarkWatched;
  const watchedRef = useRef(watched);
  watchedRef.current = watched;
  const isAnime = useMemo(() => isAnimeContent(item, details), [item.id, details]);
  const [downloaderFolder, setDownloaderFolder] = useState(() => storage.get("downloaderFolder") || "");
  const [epMenu, setEpMenu] = useState(null);
  const blockedResetKey = `${item.id}_s${selectedSeason}_e${selectedEp?.episode_number ?? 0}`;
  const {
    sessionTotal: blockedSession,
    alltimeTotal: blockedAlltime,
    showModal: showBlockedModal,
    setShowModal: setShowBlockedModal,
    getSessionDomains: getBlockedDomains
  } = useBlockedStats(blockedResetKey);
  const [rating, setRating] = useState({
    cert: null,
    minAge: null
  });
  const ageLimitSetting = useMemo(() => getAgeLimitSetting(storage), []);
  const ratingCountry = useMemo(() => getRatingCountry(storage), []);
  const restricted = isRestricted(rating.minAge, ageLimitSetting);
  const [seasonMenu, setSeasonMenu] = useState(null);
  useEffect(() => {
    if (!onEpisodeChange) return;
    if (!selectedEp) {
      onEpisodeChange(null);
      return;
    }
    onEpisodeChange({
      season: selectedSeason,
      episode: selectedEp.episode_number,
      episodeName: selectedEp.name || null
    });
  }, [onEpisodeChange, selectedSeason, selectedEp?.episode_number]);
  useEffect(() => {
    if (!item?.id) return;
    const ep = selectedEp?.episode_number || 1;
    const sea = selectedSeason || 1;
    const im = details?.imdb_id || (String(item.id).startsWith("tt") ? String(item.id) : "");
    const tm = String(details?.id || item.id).startsWith("tt") ? "" : String(details?.id || item.id);
    if (!im && !tm) return;
    window.electron?.preprobeStream?.(JSON.stringify({
      imdbId: im,
      tmdbId: tm,
      mediaType: "tv",
      season: sea,
      episode: ep,
      progressKey: `tv_${item.id}_s${sea}e${ep}`
    }));
  }, [item?.id, details?.imdb_id, details?.id, selectedSeason, selectedEp?.episode_number]);
  const resetAutoplayRef = useRef(() => {});
  const triggerAutoplayRef = useRef(() => {});
  const setCountdownStartedRef = useRef(() => {});
  const localCountdownStartedRef = useRef(false);
  const [watchedThreshold] = useState(() => storage.get("watchedThreshold") ?? 20);
  const autoMarkedRef = useRef(false);
  const lastKnownTimeRef = useRef(0);
  const durationRef = useRef(0);
  const seekBackCooldownRef = useRef(0);
  useEffect(() => {
    let mounted = true;
    setLoading(true);
    tmdbFetch(`/tv/${item.id}`, apiKey).then(d => {
      if (!mounted) return;
      setDetails(d);
      if (item.season == null) {
        const validSeasons = (d.seasons || []).filter(s => s.season_number > 0);
        const incomplete = validSeasons.find(s => {
          const count = s.episode_count || 0;
          if (!count) return false;
          for (let i = 1; i <= count; i++) {
            if (!watchedRef.current?.[`tv_${item.id}_s${s.season_number}e${i}`]) return true;
          }
          return false;
        });
        const target = incomplete || validSeasons[0] || d.seasons?.[0];
        if (target) setSelectedSeason(target.season_number);
      }
    }).catch(() => {
      if (mounted) setDetails(item);
    }).finally(() => {
      if (mounted) setLoading(false);
    });
    return () => {
      mounted = false;
    };
  }, [item.id, apiKey]);
  useEffect(() => {
    const groupId = EPISODE_GROUP_IDS[Number(item.id)];
    if (!groupId || !apiKey) {
      setEpisodeGroupData(null);
      setEpisodeGroupMap(null);
      return;
    }
    let mounted = true;
    fetchEpisodeGroup(groupId, apiKey).then(data => {
      if (!mounted) return;
      setEpisodeGroupData(data);
      setEpisodeGroupMap(buildEpisodeGroupMap(data));
    }).catch(() => {
      if (mounted) {
        setEpisodeGroupData(null);
        setEpisodeGroupMap(null);
      }
    });
    return () => {
      mounted = false;
    };
  }, [item.id, apiKey]);
  useEffect(() => {
    let mounted = true;
    tmdbFetch(`/tv/${item.id}/videos`, apiKey).then(data => {
      if (!mounted) return;
      const videos = data.results || [];
      const trailer = videos.find(v => v.type === "Trailer" && v.site === "YouTube") || videos.find(v => v.site === "YouTube");
      if (trailer) setTrailerKey(trailer.key);
    }).catch(() => {});
    return () => {
      mounted = false;
    };
  }, [item.id, apiKey]);
  useEffect(() => {
    let mounted = true;
    fetchTVRating(item.id, apiKey, ratingCountry).then(r => {
      if (mounted) setRating(r);
    });
    return () => {
      mounted = false;
    };
  }, [item.id, apiKey, ratingCountry]);
  useEffect(() => {
    if (!apiKey || !item.id) return;
    if (episodeGroupData) {
      setSelectedEp(null);
      setPlaying(false);
      setSeasonData(null);
      setLoadingSeason(false);
      return;
    }
    setLoadingSeason(true);
    setSelectedEp(null);
    setPlaying(false);
    setSeasonData(null);
    const tmdbSeasonToFetch = isAnime && anilistSeasons?.length > 0 && tmdbSeasons.length <= 1 ? 1 : selectedSeason;
    let mounted = true;
    tmdbFetch(`/tv/${item.id}/season/${tmdbSeasonToFetch}`, apiKey).then(d => {
      if (mounted) setSeasonData(d);
    }).catch(() => {
      if (mounted) {
        setSeasonData(null);
        if (selectedSeason === 0) {
          setFailedSeasons(prev => new Set([...prev, selectedSeason]));
        }
      }
    }).finally(() => {
      if (mounted) setLoadingSeason(false);
    });
    return () => {
      mounted = false;
    };
  }, [item.id, selectedSeason, apiKey, anilistSeasons]);
  useEffect(() => {
    setM3u8Url(null);
    setInterceptedSubs([]);
    setShowSourceMenu(false);
    resolvedPlayerUrlRef.current = null;
    setResolvedPlayerUrl(null);
    resolvingUrlRef.current = false;
    setResolvingUrl(false);
    setResolveError(null);
    setWebviewLoading(true);
  }, [item.id, selectedEp?.episode_number, selectedSeason, playerSource, dubMode]);
  useEffect(() => {
    const savedSrc = storage.get("playerSource");
    if (savedSrc && savedSrc !== playerSource) {
      setPlayerSource(savedSrc);
    }
    const h = window.electron?.onPreferredSourceUpdated?.(srcId => {
      if (srcId && typeof srcId === "string") {
        storage.set("playerSource", srcId);
        setPlayerSource(prev => prev !== srcId ? srcId : prev);
      }
    });
    return () => {
      if (h) window.electron?.offPreferredSourceUpdated?.(h);
    };
  }, [item.id]);
  useEffect(() => {
    let mounted = true;
    setAnilistData(null);
    setAnilistSeasons(null);
    if (isAnime) {
      setAnilistLoading(true);
      fetchAnilistData(item.name || item.title, "ANIME", item.id).then(data => {
        if (!mounted) return;
        if (data) {
          setAnilistData(data);
          const seasons = buildAnilistSeasons(data);
          if (seasons?.length) setAnilistSeasons(seasons);
        }
        if (mounted) setAnilistLoading(false);
      }).catch(() => {
        if (mounted) setAnilistLoading(false);
      });
      if (!sourceIsAnimeCapable(playerSource)) {
        const saved = storage.get("playerSource");
        setPlayerSource(sourceIsAnimeCapable(saved) ? saved : ANIME_DEFAULT_SOURCE);
      }
    } else {
      setAnilistLoading(false);
      const currentSrc = PLAYER_SOURCES.find(s => s.id === playerSource);
      if (currentSrc?.tag === "ANIME") {
        const saved = storage.get("playerSource");
        const savedSrc = PLAYER_SOURCES.find(s => s.id === saved);
        setPlayerSource(savedSrc?.tag !== "ANIME" ? saved : NON_ANIME_DEFAULT_SOURCE);
      }
    }
    return () => {
      mounted = false;
    };
  }, [item.id, isAnime]);
  useEffect(() => {
    if (sourceIsMovieOnly(playerSource)) {
      setPlayerSource(NON_ANIME_DEFAULT_SOURCE);
    }
  }, [playerSource]);
  useEffect(() => {
    if (!playing || !selectedEp) return;
    const epNum = selectedEp.episode_number;
    const epKey = `tv_${item.id}_s${selectedSeason}_e${epNum}_${dubMode}`;
    if (isAsync) {
      const cached = getFailoverSource(epKey);
      if (cached && cached !== playerSource) {
        setM3u8Url(null);
        setInterceptedSubs([]);
        resolvedPlayerUrlRef.current = null;
        setResolvedPlayerUrl(null);
        resolvingUrlRef.current = false;
        setResolvingUrl(false);
        setResolveError(null);
        setPlayerSource(cached);
        return;
      }
    }
    if (!isAsync) return;
    if (resolvedPlayerUrlRef.current || resolvingUrlRef.current) return;
    resolvingUrlRef.current = true;
    setResolvingUrl(true);
    setResolveError(null);
    const progressKey = `tv_${item.id}_s${selectedSeason}e${epNum}`;
    const startTime = storage.get("dlTime_" + progressKey) || 0;
    let mounted = true;
    window.electron.resolveHiAnime({
      title,
      seasonNumber: selectedSeason,
      episodeNumber: epNum,
      translationType: dubMode
    }).then(res => {
      if (!mounted) return;
      if (res?.ok && res.url) {
        clearFailoverSource(epKey);
        if (res.isDirectMp4 !== undefined) {
          window.electron.setPlayerVideo({
            url: res.url,
            referer: res.referer || "https://hianime.at/",
            subtitle: res.subtitle || null,
            startTime
          }).then(r => {
            if (!mounted) return;
            resolvedPlayerUrlRef.current = r.playerUrl;
            setResolvedPlayerUrl(r.playerUrl);
            setM3u8Url(res.url);
          }).catch(() => {
            if (mounted) setResolveError("Failed to start local player");
          });
        } else {
          resolvedPlayerUrlRef.current = res.url;
          setResolvedPlayerUrl(res.url);
        }
      } else {
        const next = getNextNonAsyncSource(playerSource);
        if (next) {
          setFailoverSource(epKey, next);
          setM3u8Url(null);
          setInterceptedSubs([]);
          resolvedPlayerUrlRef.current = null;
          setResolvedPlayerUrl(null);
          setResolveError(null);
          setPlayerSource(next);
        } else {
          setResolveError(res?.error || "Episode not found on HiAnime");
        }
      }
    }).catch(e => {
      if (mounted) setResolveError(e.message || "Error");
    }).finally(() => {
      if (mounted) {
        resolvingUrlRef.current = false;
        setResolvingUrl(false);
      }
    });
    return () => {
      mounted = false;
    };
  }, [playing, selectedEp, playerSource, selectedSeason, dubMode]);
  useEffect(() => {
    if (!window.electron) return;
    const handler = window.electron.onM3u8Found(url => {
      setM3u8Url(prev => prev !== url ? url : prev);
    });
    return () => window.electron.offM3u8Found(handler);
  }, []);

  useEffect(() => {
    if (!playing || m3u8Url || !selectedEp) return;
    const switchNext = () => {
      if (m3u8FoundRef.current) return;
      const order = ["hnembed"];
      const idx = order.indexOf(playerSource);
      const nextSrc = order[(idx + 1) % order.length];
      try {
        if (webviewRef.current) webviewRef.current.src = "about:blank";
      } catch {}
      if (nextSrc && nextSrc !== playerSource) {
        setPlayerSource(nextSrc);
      }
    };
    const chHandler = window.electron?.onServerChallenge?.(() => switchNext());
    const t = setTimeout(switchNext, 4200);
    return () => {
      clearTimeout(t);
      if (chHandler) window.electron?.offServerChallenge?.(chHandler);
    };
  }, [playing, m3u8Url, selectedEp, playerSource]);

  useEffect(() => {
    const h = false && window.electron?.onNeedNextServer?.(data => {
      const cur = data?.currentSource || playerSource;
      const order = ["hnembed"];
      const idx = order.indexOf(cur);
      const nextSrc = order[(idx + 1) % order.length];
      pendingFailoverRef.current = true;
      setM3u8Url(null);
      setPlaying(true);
      try {
        if (webviewRef.current) webviewRef.current.src = "about:blank";
      } catch {}
      if (nextSrc) setPlayerSource(nextSrc);
    });
    return () => {
      if (h) window.electron?.offNeedNextServer?.(h);
    };
  }, [playerSource]);

  useEffect(() => {
    if (!playing || !m3u8Url || !selectedEp) return;
    const launchKey = `tv_${item.id}_s${selectedSeason}_e${selectedEp.episode_number}_${playerSource}`;
    if (!pendingFailoverRef.current && autoExoLaunchedRef.current === launchKey) return;
    const timer = setTimeout(() => {
      autoExoLaunchedRef.current = launchKey;
      if (playerSource && !sourceIsAsync(playerSource)) {
        storage.set("playerSource", playerSource);
      }
      if (window.AndroidBridge?.openExoPlayer) {
        if (pendingFailoverRef.current) {
          pendingFailoverRef.current = false;
          window.AndroidBridge?.deliverNextServerStream?.(m3u8Url, playerSource);
          return;
        }
        const epPct = progress?.[currentProgressKey] || 0;
        const epDone = !!watched?.[currentProgressKey] || epPct >= 90;
        const startSec = epDone ? 0 : (storage.get("dlTime_" + currentProgressKey) || 0);
        const payload = {
          url: m3u8Url,
          title: mediaName || title,
          currentSource: playerSource,
          startTimeSec: startSec,
          subtitles: interceptedSubs,
          progressKey: currentProgressKey,
          imdbId: item.imdb_id || item.id,
          tmdbId: item.numeric_id || item.tmdb_id || (!String(item.id || "").startsWith("tt") ? String(item.id) : ""),
          mediaType: "tv",
          season: selectedSeason,
          episode: selectedEp.episode_number,
          subTextColor: storage.get("subtitleTextColor") || "#FFFFFF",
          subBgStyle: storage.get("subtitleBgStyle") || "dark",
          subFontSizeSp: Number(storage.get("subtitleFontSizeSp") || 22),
          preferredSubLang: playerSubLang || "ar"
        };
        try {
          if (webviewRef.current) webviewRef.current.src = "about:blank";
        } catch {}
        window.AndroidBridge.openExoPlayer(JSON.stringify(payload));
        setPlaying(false);
        setPlayerFullscreen(false);
        document.documentElement.removeAttribute("data-player-fullscreen");
      }
    }, 300);
    return () => clearTimeout(timer);
  }, [playing, m3u8Url, selectedEp, item.id, selectedSeason, playerSource]);
  useEffect(() => {
    if (!showSourceMenu) return;
    const close = () => setShowSourceMenu(false);
    window.addEventListener("scroll", close, {
      capture: true,
      passive: true
    });
    const handleClick = e => {
      if (sourceRef.current?.contains(e.target) || e.target.closest(".source-dropdown")) return;
      close();
    };
    document.addEventListener("mousedown", handleClick);
    return () => {
      window.removeEventListener("scroll", close, {
        capture: true
      });
      document.removeEventListener("mousedown", handleClick);
    };
  }, [showSourceMenu]);
  useEffect(() => {
    if (!window.electron) return;
    const handler = window.electron.onSubtitleFound(({
      url,
      lang
    }) => {
      if (!url || !url.toLowerCase().includes(".vtt")) return;
      setInterceptedSubs(prev => {
        const filtered = prev.filter(s => s.lang !== lang);
        return [...filtered, {
          url,
          lang: lang || "unknown"
        }];
      });
    });
    return () => window.electron.offSubtitleFound(handler);
  }, []);
  const d = details || item;
  const title = d.name || d.title;
  const year = (d.first_air_date || "").slice(0, 4);
  const status = d.status;
  const tmdbSeasons = useMemo(() => (d.seasons || []).filter(s => s.season_number > 0), [d.seasons]);
  const tmdbSeasonsWithSpecials = useMemo(() => {
    if (isAnime) return tmdbSeasons;
    if (failedSeasons.has(0)) return tmdbSeasons;
    const specials = (d.seasons || []).filter(s => s.season_number === 0);
    return [...tmdbSeasons, ...specials];
  }, [d.seasons, tmdbSeasons, isAnime, failedSeasons]);
  const useAnilistSeasons = useMemo(() => isAnime && anilistSeasons?.length > 0 && (tmdbSeasons.length <= 1 || anilistSeasons.length > tmdbSeasons.length), [isAnime, anilistSeasons, tmdbSeasons]);
  const episodeGroupSeasons = useMemo(() => {
    if (!episodeGroupData?.groups) return null;
    return [...episodeGroupData.groups].sort((a, b) => a.order - b.order).map((g, i) => ({
      season_number: i + 1,
      name: g.name || `Season ${i + 1}`,
      episode_count: (g.episodes || []).length
    }));
  }, [episodeGroupData]);
  const seasons = useMemo(() => {
    if (episodeGroupSeasons) return episodeGroupSeasons;
    if (useAnilistSeasons) return anilistSeasons.map(s => ({
      season_number: s.seasonNum,
      name: s.title || `Season ${s.seasonNum}`,
      episode_count: s.episodes || 0
    }));
    return tmdbSeasonsWithSpecials;
  }, [episodeGroupSeasons, useAnilistSeasons, anilistSeasons, tmdbSeasonsWithSpecials]);
  const episodeGroupCurrentEpisodes = useMemo(() => {
    if (!episodeGroupData?.groups) return null;
    const sortedGroups = [...episodeGroupData.groups].sort((a, b) => a.order - b.order);
    const group = sortedGroups[selectedSeason - 1];
    if (!group) return null;
    return [...(group.episodes || [])].sort((a, b) => a.order - b.order).map((ep, i) => ({
      ...ep,
      episode_number: i + 1,
      _tmdbSeason: ep.season_number,
      _tmdbAbsolute: ep.episode_number
    }));
  }, [episodeGroupData, selectedSeason]);
  const getSeasonEpisodes = useCallback(rawEpisodes => {
    if (!useAnilistSeasons || !rawEpisodes) return rawEpisodes;
    if (tmdbSeasons.length > 1) return rawEpisodes;
    let offset = 0;
    for (const s of anilistSeasons) {
      if (s.seasonNum < selectedSeason) offset += s.episodes || 0;
    }
    const count = anilistSeasons.find(s => s.seasonNum === selectedSeason)?.episodes || rawEpisodes.length;
    return rawEpisodes.slice(offset, offset + count).map((ep, i) => ({
      ...ep,
      episode_number: i + 1,
      _tmdbAbsolute: ep.episode_number
    }));
  }, [useAnilistSeasons, tmdbSeasons.length, anilistSeasons, selectedSeason]);
  const playerEp = useMemo(() => {
    if (!selectedEp) return {
      season: selectedSeason,
      episode: undefined
    };
    const rawSeason = selectedEp._tmdbSeason ?? selectedSeason;
    const rawEpisode = selectedEp._tmdbAbsolute ?? selectedEp.episode_number;
    return applyEpisodeMapping(item.id, rawSeason, rawEpisode, episodeGroupMap);
  }, [selectedEp, selectedSeason, item.id, episodeGroupMap]);
  const playerDirectUrl = useMemo(() => {
    if (isAnime && sourceSupportsAnime(playerSource)) {
      if (anilistLoading) return null;
      const seasonEntry = anilistSeasons?.find(s => s.seasonNum === selectedSeason);
      const anilistId = seasonEntry?.id ?? (anilistData?.id || null);
      const animeUrl = getAnimeSourceUrl(playerSource, anilistId, selectedEp?.episode_number, dubMode);
      if (animeUrl) return animeUrl;
    }
    return getSourceUrl(playerSource, "tv", srcId.id, playerEp.season, playerEp.episode, {}, playerAccentColor, playerSubLang);
  }, [isAnime, playerSource, anilistLoading, anilistSeasons, anilistData, selectedSeason, selectedEp, dubMode, srcId.id, playerEp, playerAccentColor, playerSubLang]);
  const episodeGroupPending = useMemo(() => !!EPISODE_GROUP_IDS[Number(item.id)] && !episodeGroupData, [item.id, episodeGroupData]);
  const currentSeasonEpisodes = useMemo(() => {
    if (episodeGroupPending) return [];
    if (anilistLoading) return [];
    return episodeGroupCurrentEpisodes || getSeasonEpisodes(seasonData?.episodes) || [];
  }, [episodeGroupPending, anilistLoading, episodeGroupCurrentEpisodes, getSeasonEpisodes, seasonData]);
  const autoSelectKeyRef = useRef(null);
  useEffect(() => {
    if (!item.episode || currentSeasonEpisodes.length === 0) return;
    const key = `${item.id}_e${item.episode}`;
    if (autoSelectKeyRef.current === key) return;
    const target = Number(item.episode);
    const ep = currentSeasonEpisodes.find(e => e.episode_number === target);
    if (ep) {
      autoSelectKeyRef.current = key;
      setSelectedEp(ep);
    }
  }, [item.id, item.episode, currentSeasonEpisodes]);
  const downloadsByEpisodeKey = useMemo(() => {
    const map = new Map();
    for (const dl of downloads || []) {
      if (dl.mediaType === "tv" && (dl.tmdbId === item.id || dl.mediaId === item.id) && (dl.status === "completed" || dl.status === "local" || dl.status === "downloading")) {
        map.set(`s${dl.season}e${dl.episode}`, dl);
      }
    }
    return map;
  }, [downloads, item.id]);
  const displaySeasonCount = useMemo(() => anilistLoading ? null : seasons.length || d.number_of_seasons || 0, [anilistLoading, seasons, d.number_of_seasons]);
  const displayEpisodeCount = useMemo(() => anilistLoading ? null : useAnilistSeasons ? anilistSeasons.reduce((sum, s) => sum + (s.episodes || 0), 0) : d.number_of_episodes || 0, [anilistLoading, useAnilistSeasons, anilistSeasons, d.number_of_episodes]);
  const displayOverview = useMemo(() => anilistLoading ? null : isAnime && anilistData?.description ? cleanAnilistDescription(anilistData.description) : d.overview, [anilistLoading, isAnime, anilistData?.description, d.overview]);
  const displayScore = useMemo(() => anilistLoading ? null : isAnime && anilistData?.averageScore ? (anilistData.averageScore / 10).toFixed(1) : d.vote_average > 0 ? d.vote_average.toFixed(1) : null, [anilistLoading, isAnime, anilistData?.averageScore, d.vote_average]);
  const displayGenres = useMemo(() => anilistLoading ? [] : isAnime && anilistData?.genres?.length ? anilistData.genres.map((g, i) => ({
    id: i,
    name: g
  })) : d.genres || [], [anilistLoading, isAnime, anilistData?.genres, d.genres]);
  const seasonWatchedMap = useMemo(() => {
    const map = {};
    for (const s of seasons) {
      const num = s.season_number;
      const count = num === selectedSeason ? currentSeasonEpisodes.length || s.episode_count || 0 : s.episode_count || 0;
      if (!count) {
        map[num] = "none";
        continue;
      }
      let watchedCount = 0;
      for (let i = 1; i <= count; i++) {
        if (watched?.[`tv_${item.id}_s${num}e${i}`]) watchedCount++;
      }
      if (watchedCount === 0) {
        map[num] = "none";
      } else if (watchedCount === count) {
        map[num] = "all";
      } else {
        const pct = watchedCount / count;
        map[num] = pct < 0.375 ? "some25" : pct < 0.625 ? "some50" : "some75";
      }
    }
    return map;
  }, [seasons, selectedSeason, currentSeasonEpisodes, watched, item.id]);
  const isSeasonWatched = useCallback(seasonNum => seasonWatchedMap[seasonNum] === "all", [seasonWatchedMap]);
  const markSeasonWatched = useCallback(seasonNum => {
    const seasonInfo = seasons.find(s => s.season_number === seasonNum);
    const episodes = seasonNum === selectedSeason ? currentSeasonEpisodes : null;
    const count = episodes?.length || seasonInfo?.episode_count || 0;
    for (let i = 1; i <= count; i++) {
      if (episodes) {
        const ep = episodes.find(e => e.episode_number === i);
        if (ep && isUnreleased(ep.air_date)) continue;
      }
      onMarkWatched?.(`tv_${item.id}_s${seasonNum}e${i}`);
    }
  }, [seasons, selectedSeason, currentSeasonEpisodes, item.id, onMarkWatched]);
  const markSeasonUnwatched = useCallback(seasonNum => {
    const seasonInfo = seasons.find(s => s.season_number === seasonNum);
    const episodes = seasonNum === selectedSeason ? currentSeasonEpisodes : null;
    const count = episodes?.length || seasonInfo?.episode_count || 0;
    for (let i = 1; i <= count; i++) {
      onMarkUnwatched?.(`tv_${item.id}_s${seasonNum}e${i}`);
    }
  }, [seasons, selectedSeason, currentSeasonEpisodes, item.id, onMarkUnwatched]);
  const currentProgressKey = selectedEp ? `tv_${item.id}_s${selectedSeason}e${selectedEp.episode_number}` : null;
  const currentEpDownload = selectedEp ? downloadsByEpisodeKey.get(`s${selectedSeason}e${selectedEp.episode_number}`) ?? null : null;
  useEffect(() => {
    autoMarkedRef.current = false;
    lastKnownTimeRef.current = 0;
    seekBackCooldownRef.current = 0;
    durationRef.current = 0;
    localCountdownStartedRef.current = false;
    resetAutoplayRef.current?.();
  }, [currentProgressKey]);
  useEffect(() => {
    if (playing) setWebviewLoading(true);
    try {
      window.AndroidBridge?.setImmersiveMode?.(!!playing);
    } catch {}
  }, [playing]);
  useLayoutEffect(() => {
    if (playing) return;
    const wv = webviewRef.current;
    if (wv) {
      try {
        wv.src = "about:blank";
      } catch {}
    }
  }, [playing]);
  useEffect(() => {
    return () => {
      window.electron?.playerStopped?.();
    };
  }, []);
  useEffect(() => {
    if (!playing) return;
    const wv = webviewRef.current;
    if (!wv) return;
    const done = () => {
      setWebviewLoading(false);
      playerWrapRef.current?.scrollIntoView({ behavior: "auto", block: "center" });
      setTimeout(() => {
        if (!m3u8FoundRef.current) tapCenterOfPlayer();
      }, 1400);
      setTimeout(() => {
        if (!m3u8FoundRef.current) tapCenterOfPlayer();
      }, 2800);
    };
    wv.addEventListener("did-finish-load", done);
    wv.addEventListener("did-fail-load", done);
    let attempts = 0;
    const pollDuration = !isAsync ? null : setInterval(async () => {
      if (durationRef.current > 0 || attempts++ > 30) {
        clearInterval(pollDuration);
        return;
      }
      try {
        const dur = await wv.executeJavaScript(`(() => { const v = document.querySelector('video'); return (v && v.duration > 0 && isFinite(v.duration)) ? v.duration : null; })()`);
        if (dur) {
          durationRef.current = dur;
          setSkipTimings(t => t ? {
            ...t
          } : t);
          clearInterval(pollDuration);
        }
      } catch {}
    }, 1000);
    return () => {
      wv.removeEventListener("did-finish-load", done);
      wv.removeEventListener("did-fail-load", done);
      clearInterval(pollDuration);
    };
  }, [playing, playerSource, isAsync, item.id, selectedEp?.episode_number]);
  useEffect(() => {
    setSkipTimings(null);
    setSkipPrompt(null);
    if (introSkipMode === "off" || !isAsync || !isAnime) return;
    const anilistId = anilistData?.idMal;
    const epNum = selectedEp?.episode_number;
    if (!anilistId || !epNum) return;
    let cancelled = false;
    fetchAniSkipTimings(anilistId, epNum).then(timings => {
      if (!cancelled) setSkipTimings(timings);
    });
    return () => {
      cancelled = true;
    };
  }, [anilistData?.idMal, selectedEp?.episode_number, playerSource, isAnime, introSkipMode]);
  const handleManualSkip = useCallback(async () => {
    if (!skipPrompt || !skipTimings?.[skipPrompt]) return;
    const rawEnd = skipTimings[skipPrompt].endTime;
    const endTime = Number(rawEnd);
    if (!Number.isFinite(endTime)) return;
    const wv = webviewRef.current;
    if (!wv) return;
    try {
      await wv.executeJavaScript(`(() => { const v = document.querySelector('video'); if (v) v.currentTime = ${endTime}; })()`);
    } catch {}
    setSkipPrompt(null);
  }, [skipPrompt, skipTimings]);
  useEffect(() => {
    if (!skipPrompt) return;
    const wv = webviewRef.current;
    if (!wv) return;
    const handler = e => {
      if (e.key === "Return" && e.type === "keyDown") {
        handleManualSkip();
      }
    };
    wv.addEventListener("before-input-event", handler);
    return () => wv.removeEventListener("before-input-event", handler);
  }, [skipPrompt, handleManualSkip]);
  useEffect(() => {
    const aniSkipActive = introSkipMode !== "off" && playing && !!skipTimings && isAsync;
    if (!aniSkipActive) setSkipPrompt(null);
    if (!playing || !currentProgressKey) return;
    const TICK = aniSkipActive ? 1000 : 5000;
    let tickCount = 0;
    let interval = null;
    const timer = setTimeout(() => {
      interval = setInterval(async () => {
        try {
          const wv = webviewRef.current;
          if (!wv) return;
          let result;
          if (pipWebContentsIdRef.current != null && window.electron?.queryVideoProgress) {
            result = await window.electron.queryVideoProgress(pipWebContentsIdRef.current);
          } else if (progressViaFrames && window.electron?.queryVideoProgress) {
            result = await window.electron.queryVideoProgress(wv.getWebContentsId());
          } else {
            result = await wv.executeJavaScript(`
              (() => {
                const v = document.querySelector('video')
                if (!v || !v.duration || v.duration === Infinity || v.paused) return null
                // Re-attach seek tracker if video element was recreated (e.g. quality change)
                if (!v._seekTracked) {
                  v._seekTracked = true
                  v.addEventListener('seeked', () => {
                    v._lastUserSeek = Date.now()
                    v._lastUserSeekTo = v.currentTime
                  })
                }
                return {
                  currentTime: v.currentTime,
                  duration: v.duration,
                  recentUserSeek: v._lastUserSeek ? (Date.now() - v._lastUserSeek < 6000) : false,
                  lastUserSeekTo: v._lastUserSeekTo ?? null,
                }
              })()
            `);
          }
          if (aniSkipActive && result?.currentTime != null) {
            const ct = result.currentTime;
            const {
              intro,
              outro
            } = skipTimings;
            const inIntro = intro && ct >= intro.startTime && ct < intro.endTime - 1;
            const inOutro = outro && ct >= outro.startTime && ct < outro.endTime - 1;
            const activeSegment = inIntro ? "intro" : inOutro ? "outro" : null;
            if (!activeSegment) {
              setSkipPrompt(null);
            } else if (introSkipMode === "auto") {
              setSkipPrompt(null);
              const endTime = Number(skipTimings[activeSegment].endTime);
              if (Number.isFinite(endTime)) {
                try {
                  await wv.executeJavaScript(`(() => { const v = document.querySelector('video'); if (v) v.currentTime = ${endTime}; })()`);
                } catch {}
              }
            } else {
              setSkipPrompt(activeSegment);
            }
          }
          tickCount++;
          if (aniSkipActive && tickCount % 5 !== 0) return;
          if (result && result.duration > 0) {
            durationRef.current = result.duration;
            const ct = result.currentTime;
            const now = Date.now();
            if (!sourceSkipsResetGuard(playerSource) && lastKnownTimeRef.current > 30 && ct <= 5 && !result.recentUserSeek) {
              if (now > seekBackCooldownRef.current) {
                const seekTo = lastKnownTimeRef.current;
                seekBackCooldownRef.current = now + 8000;
                try {
                  await wv.executeJavaScript(`
                    (() => {
                      const v = document.querySelector('video')
                      if (v) v.currentTime = ${seekTo}
                    })()
                  `);
                } catch {}
              }
              return;
            }
            if (result.recentUserSeek && result.lastUserSeekTo !== null) {
              lastKnownTimeRef.current = result.lastUserSeekTo;
            } else {
              lastKnownTimeRef.current = ct;
            }
            const p = Math.floor(ct / result.duration * 100);
            saveProgressRef.current(currentProgressKey, Math.min(p, 100));
            storage.set("dlTime_" + currentProgressKey, Math.floor(ct));
            const remaining = result.duration - ct;
            if (!autoMarkedRef.current && remaining <= watchedThreshold && remaining >= 0) {
              autoMarkedRef.current = true;
              onMarkWatchedRef.current?.(currentProgressKey);
            }
            if (remaining <= watchedThreshold && !localCountdownStartedRef.current) {
              localCountdownStartedRef.current = true;
              setCountdownStartedRef.current?.(true);
              triggerAutoplayRef.current?.();
            }
          }
        } catch {}
      }, TICK);
    }, 3000);
    return () => {
      clearTimeout(timer);
      clearInterval(interval);
      setSkipPrompt(null);
    };
  }, [playing, skipTimings, playerSource, introSkipMode, currentProgressKey, watchedThreshold, progressViaFrames]);
  const seekBy = useCallback(async seconds => {
    try {
      const wv = webviewRef.current;
      if (!wv) return;
      await wv.executeJavaScript(`
        (() => {
          const v = document.querySelector('video');
          if (v) v.currentTime = Math.max(0, Math.min(v.duration || 0, v.currentTime + ${seconds}));
        })()
      `);
    } catch {}
  }, []);
  useEffect(() => {
    const wv = webviewRef.current;
    if (!wv || !playing || !isAsync) return;
    const inject = () => {
      wv.executeJavaScript(INJECT_SKIP_CONTROLS).catch(() => {});
    };
    wv.addEventListener("dom-ready", inject);
    try {
      inject();
    } catch {}
    return () => {
      wv.removeEventListener("dom-ready", inject);
      try {
        wv.executeJavaScript(`
          (() => {
            const el = document.getElementById('__skip-ui');
            if (el) el.remove();
            window.__skipControlsInjected = false;
          })()
        `);
      } catch {}
    };
  }, [playing, playerSource]);
  const [gamepadEnabled, setGamepadEnabled] = useState(() => storage.get(STORAGE_KEYS.GAMEPAD_ENABLED) !== false);
  useEffect(() => {
    const handler = () => setGamepadEnabled(storage.get(STORAGE_KEYS.GAMEPAD_ENABLED) !== false);
    window.addEventListener("streambert:gamepad-settings-changed", handler);
    return () => window.removeEventListener("streambert:gamepad-settings-changed", handler);
  }, []);
  useEffect(() => {
    setPlayerGamepadActive(gamepadEnabled && playing);
    return () => setPlayerGamepadActive(false);
  }, [playing, gamepadEnabled]);
  useEffect(() => {
    const wv = webviewRef.current;
    if (!wv || !playing || !gamepadEnabled) return;
    const inject = () => {
      wv.executeJavaScript(GAMEPAD_PLAYER_SCRIPT).catch(() => {});
    };
    wv.addEventListener("dom-ready", inject);
    try {
      inject();
    } catch {}
    const exitPoll = setInterval(async () => {
      try {
        const requested = await wv.executeJavaScript(GAMEPAD_EXIT_CHECK_JS);
        if (requested) {
          wv.executeJavaScript(GAMEPAD_EXIT_RESET_JS).catch(() => {});
          setPlaying(false);
        }
      } catch {}
    }, 250);
    return () => {
      wv.removeEventListener("dom-ready", inject);
      clearInterval(exitPoll);
      try {
        wv.executeJavaScript(GAMEPAD_CLEANUP_JS);
      } catch {}
    };
  }, [playing, gamepadEnabled, playerSource]);
  const tapCenterOfPlayer = useCallback(() => {
    try {
      const el = playerWrapRef.current;
      if (!el || !window.AndroidBridge?.tapPlayerCenter) return;
      const r = el.getBoundingClientRect();
      if (r.width <= 0 || r.height <= 0) return;
      const rx = (r.left + r.width / 2) / Math.max(1, window.innerWidth);
      const ry = (r.top + r.height / 2) / Math.max(1, window.innerHeight);
      if (ry > 0.05 && ry < 0.95) {
        window.AndroidBridge.tapPlayerCenter(rx, ry);
      }
    } catch {}
  }, []);

  const playEpisode = useCallback(ep => {
    if (ep) {
      const pkCheck = `tv_${item.id}_s${selectedSeason}e${ep.episode_number}`;
      const epPctCheck = progress?.[pkCheck] || 0;
      if (watched?.[pkCheck] || epPctCheck >= 90) {
        onMarkUnwatched?.(pkCheck);
        saveProgress?.(pkCheck, 0);
        storage.set("dlTime_" + pkCheck, 0);
      }
    }
    if (window.AndroidBridge?.openExoPlayer && !sourceIsAsync(playerSource) && ep) {
      const pk = `tv_${item.id}_s${selectedSeason}e${ep.episode_number}`;
      const epPct = progress?.[pk] || 0;
      const epDone = !!watched?.[pk] || epPct >= 90;
      const startSec = epDone ? 0 : (storage.get("dlTime_" + pk) || 0);
      const tmdbVal = item.numeric_id || item.tmdb_id || (!String(item.id || "").startsWith("tt") ? String(item.id) : "");
      const cleanShowTitle = title || mediaName || "SingularityTV";
      const epTitle = `${cleanShowTitle} · S${selectedSeason}E${ep.episode_number}`;
      const payload = {
        url: "",
        title: epTitle,
        seriesTitle: cleanShowTitle,
        totalEpisodes: currentSeasonEpisodes?.length || 0,
        currentSource: playerSource,
        startTimeSec: startSec,
        subtitles: [],
        progressKey: pk,
        imdbId: item.imdb_id || item.id,
        tmdbId: tmdbVal,
        mediaType: "tv",
        season: selectedSeason,
        episode: ep.episode_number,
        subTextColor: storage.get("subtitleTextColor") || "#FFFFFF",
        subBgStyle: storage.get("subtitleBgStyle") || "dark",
        subFontSizeSp: Number(storage.get("subtitleFontSizeSp") || 22),
        preferredSubLang: playerSubLang || "ar"
      };
      onHistory?.({
        ...d,
        media_type: "tv",
        season: selectedSeason,
        episode: ep.episode_number
      });
      window.AndroidBridge.openExoPlayer(JSON.stringify(payload));
      return;
    }
    autoExoLaunchedRef.current = null;
    setM3u8Url(null);
    setInterceptedSubs([]);
    resolvedPlayerUrlRef.current = null;
    setResolvedPlayerUrl(null);
    resolvingUrlRef.current = false;
    setResolvingUrl(false);
    setResolveError(null);
    setSelectedEp(ep);
    setPlaying(true);
    setTimeout(() => {
      playerWrapRef.current?.scrollIntoView({
        behavior: "smooth",
        block: "center"
      });
    }, 100);
    onHistory({
      ...d,
      media_type: "tv",
      season: selectedSeason,
      episode: ep.episode_number,
      episodeName: ep.name
    });
  }, [d, selectedSeason, onHistory]);
  const nextEp = useMemo(() => {
    if (!selectedEp || !currentSeasonEpisodes) return null;
    const idx = currentSeasonEpisodes.findIndex(e => e.episode_number === selectedEp.episode_number);
    if (idx >= 0 && idx < currentSeasonEpisodes.length - 1) {
      const candidate = currentSeasonEpisodes[idx + 1];
      return isUnreleased(candidate.air_date) ? null : candidate;
    }
    return null;
  }, [selectedEp, currentSeasonEpisodes]);
  const {
    autoplayCountdown,
    countdownStarted,
    setCountdownStarted,
    triggerAutoplay,
    cancelAutoplay,
    playNow,
    resetAutoplay
  } = useAutoplay({
    nextEp,
    playEpisode,
    restricted
  });
  useEffect(() => {
    resetAutoplayRef.current = resetAutoplay;
    triggerAutoplayRef.current = triggerAutoplay;
    setCountdownStartedRef.current = setCountdownStarted;
  }, [resetAutoplay, triggerAutoplay, setCountdownStarted]);
  useEffect(() => {
    localCountdownStartedRef.current = countdownStarted;
  }, [countdownStarted]);
  const autoplayNextLayout = storage.get(STORAGE_KEYS.AUTOPLAY_NEXT_LAYOUT) || "right";
  const handleSetDownloaderFolder = useCallback(folder => {
    setDownloaderFolder(folder);
    storage.set("downloaderFolder", folder);
  }, []);
  useEffect(() => {
    if (!playing) return;
    if (!NEEDS_INTERCEPT.includes(playerSource)) return;
    const enterH = window.electron?.onWebviewEnterFullscreen?.(() => {
      setPlayerFullscreen(true);
      document.documentElement.setAttribute("data-player-fullscreen", "1");
    });
    const leaveH = window.electron?.onWebviewLeaveFullscreen?.(() => {
      setPlayerFullscreen(false);
      document.documentElement.removeAttribute("data-player-fullscreen");
      if (document.fullscreenElement) document.exitFullscreen?.();
    });
    return () => {
      if (enterH) window.electron?.offWebviewEnterFullscreen?.(enterH);
      if (leaveH) window.electron?.offWebviewLeaveFullscreen?.(leaveH);
      document.documentElement.removeAttribute("data-player-fullscreen");
    };
  }, [playing, playerSource]);
  useEffect(() => {
    if (!playing) return;
    const openH = window.electron?.onPipOpened?.(async () => {
      setPipOpen(true);
      pipWebContentsIdRef.current = (await window.electron.getPipWebContentsId?.()) ?? null;
    });
    const closeH = window.electron?.onPipClosed?.(() => {
      pipUrlRef.current = null;
      pipWebContentsIdRef.current = null;
      setPipOpen(false);
    });
    return () => {
      if (openH) window.electron?.offPipOpened?.(openH);
      if (closeH) window.electron?.offPipClosed?.(closeH);
    };
  }, [playing]);
  const effectiveYear = year || (isAnime && anilistData?.startDate?.year ? String(anilistData.startDate.year) : "");
  const mediaName = selectedEp ? `${title}${effectiveYear ? ` (${effectiveYear})` : ""} S${String(selectedSeason).padStart(2, "0")} E${String(selectedEp.episode_number).padStart(2, "0")}` : title;
  const currentEpWatched = currentProgressKey ? !!watched?.[currentProgressKey] : false;
  return React.createElement("div", {
    className: "fade-in"
  }, React.createElement("button", {
    className: "detail-floating-back",
    onClick: onBack,
    "aria-label": "Back"
  }, React.createElement(BackIcon, null)), loading && React.createElement("div", {
    className: "loader"
  }, React.createElement("div", {
    className: "spinner"
  })), !loading && React.createElement(React.Fragment, null, React.createElement("div", {
    className: "detail-hero"
  }, React.createElement("div", {
    className: "detail-bg",
    style: {
      backgroundImage: `url(${imgUrl(d.backdrop_path, "w1280")})`
    }
  }), React.createElement("div", {
    className: "detail-gradient"
  }), React.createElement("div", {
    className: "detail-content"
  }, React.createElement("div", {
    className: "detail-poster"
  }, d.poster_path ? React.createElement("img", {
    src: imgUrl(d.poster_path),
    alt: title,
    loading: "lazy"
  }) : React.createElement("div", {
    style: {
      width: "100%",
      height: "100%",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: "var(--text3)"
    }
  }, React.createElement(TVIcon, null))), React.createElement("div", {
    className: "detail-info"
  }, React.createElement("div", {
    className: "detail-type"
  }, "Series"), React.createElement("div", {
    className: "detail-title"
  }, title), React.createElement("div", {
    className: "genres"
  }, displayGenres.map(g => React.createElement("span", {
    key: g.id,
    className: "genre-tag"
  }, g.name))), React.createElement("div", {
    className: "detail-meta"
  }, displayScore && React.createElement("span", {
    className: "detail-rating"
  }, React.createElement(StarIcon, null), " ", displayScore), year && React.createElement("span", null, year), displaySeasonCount > 0 && React.createElement("span", null, displaySeasonCount, " Season", displaySeasonCount !== 1 ? "s" : ""), displayEpisodeCount > 0 && React.createElement("span", null, displayEpisodeCount, " Episode", displayEpisodeCount !== 1 ? "s" : ""), React.createElement("span", null, status)), rating.cert && React.createElement("div", {
    className: `age-rating-pill${restricted ? " age-rating-pill--restricted" : ""}`
  }, restricted ? React.createElement(RatingLockIcon, AlertIcon, {
    size: 13
  }) : React.createElement(RatingShieldIcon, {
    size: 13
  }), React.createElement("span", {
    className: "age-rating-pill-cert"
  }, rating.cert), restricted && React.createElement("span", {
    className: "age-rating-pill-label"
  }, "Inappropriate for your age setting")), React.createElement("p", {
    className: "detail-overview"
  }, displayOverview), (() => {
    const recentHist = (history || []).find(h => h.media_type === "tv" && String(h.id) === String(item.id) && h.season != null && h.episode != null);
    const targetEpNum = item.episode || recentHist?.episode || currentSeasonEpisodes?.[0]?.episode_number || 1;
    const targetSeasonNum = item.season || recentHist?.season || selectedSeason || 1;
    const targetEpObj = currentSeasonEpisodes?.find(e => e.episode_number === Number(targetEpNum)) || currentSeasonEpisodes?.[0] || { episode_number: Number(targetEpNum), name: `Episode ${targetEpNum}` };
    const contPk = `tv_${item.id}_s${targetSeasonNum}e${targetEpObj.episode_number}`;
    const contPct = progress?.[contPk] || 0;
    const isCont = contPct > 2 && contPct < 98 && !watched?.[contPk];
    return React.createElement("div", {
      className: "detail-actions"
    }, !restricted && targetEpObj && React.createElement("button", {
      className: "btn btn-primary",
      onClick: () => playEpisode(targetEpObj)
    }, React.createElement(PlayIcon, null), isCont ? ` Continue S${targetSeasonNum}E${targetEpObj.episode_number}` : ` Play S${targetSeasonNum}E${targetEpObj.episode_number}`), trailerKey && (restricted ? React.createElement("button", {
    className: "btn btn-secondary btn-restricted",
    disabled: true,
    title: "Inappropriate for your age rating setting"
  }, React.createElement(RatingLockIcon, { size: 14 }), " Trailer") : React.createElement("button", {
    className: "btn btn-secondary",
    onClick: () => setShowTrailer(true)
  }, React.createElement(TrailerIcon, null), " Trailer")), React.createElement("button", {
    className: "btn btn-secondary",
    onClick: () => setDownloadConfirm({ type: "season", season: selectedSeason, episodes: currentSeasonEpisodes })
  }, React.createElement(DownloadIcon, null), " Download Season"), React.createElement("button", {
    className: "btn btn-secondary",
    onClick: onSave
  }, isSaved ? React.createElement(BookmarkFillIcon, null) : React.createElement(BookmarkIcon, null), isSaved ? "Saved" : "Save"), React.createElement("button", {
    className: "btn btn-ghost",
    onClick: onBack
  }, React.createElement(BackIcon, null), " Back")); })()))), playing && selectedEp && React.createElement("div", {
    className: "section"
  }, React.createElement("div", {
    style: {
      marginBottom: 12,
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, React.createElement("span", {
    className: "tag tag-red"
  }, "Season ", selectedSeason, " \xB7 E", selectedEp.episode_number), React.createElement("span", {
    style: {
      fontSize: 14,
      fontWeight: 500
    }
  }, selectedEp.name), currentEpWatched ? React.createElement("button", {
    className: "btn btn-ghost watched-btn",
    style: {
      marginLeft: "auto"
    },
    onClick: () => onMarkUnwatched?.(currentProgressKey)
  }, React.createElement(WatchedIcon, {
    size: 14
  }), " Watched") : React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      marginLeft: "auto"
    },
    onClick: () => onMarkWatched?.(currentProgressKey)
  }, "\u2713 Mark Watched")), React.createElement("div", {
    className: "player-wrap player-wrap--fullscreen player-wrap--silent-exo",
    ref: playerWrapRef
  }, webviewLoading && !resolveError && React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 10,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      background: "rgba(0,0,0,0.75)",
      pointerEvents: "none",
      gap: 14,
      borderRadius: "inherit"
    }
  }, sourceIsAsync(playerSource) ? React.createElement(HiAnimeLoader, {
    what: "episode",
    playerStarting: !resolvingUrl && !!resolvedPlayerUrl
  }) : React.createElement(React.Fragment, null, React.createElement("div", {
    className: "spinner"
  }), React.createElement("span", {
    style: {
      fontSize: 14,
      color: "var(--text2)"
    }
  }, `Loading ${PLAYER_SOURCES.find(s => s.id === playerSource)?.label ?? "source"}…`))), isAsync && resolveError && !resolvingUrl && React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 10,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      background: "rgba(0,0,0,0.85)",
      gap: 10,
      borderRadius: "inherit"
    }
  }, React.createElement("span", {
    style: {
      fontSize: 28
    }
  }, React.createElement(AlertIcon, { size: 28 })), React.createElement("span", {
    style: {
      fontSize: 14,
      color: "var(--text2)"
    }
  }, "Episode not found on HiAnime"), React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, resolveError), React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, "Try a different source, or switch sub/dub.")), srcId.error && React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 11,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      background: "rgba(0,0,0,0.85)",
      gap: 10,
      borderRadius: "inherit"
    }
  }, React.createElement("span", {
    style: {
      fontSize: 28
    }
  }, React.createElement(AlertIcon, { size: 28 })), React.createElement("span", {
    style: {
      fontSize: 14,
      color: "var(--text2)"
    }
  }, "Could not resolve the ", srcId.idLabel, " for this title"), React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, srcId.error, ". Try a different source.")), pipOpen && React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 20,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      background: "rgba(0,0,0,0.92)",
      gap: 16,
      borderRadius: "inherit"
    }
  }, React.createElement(PopOutIcon, {
    size: 36
  }), React.createElement("span", {
    style: {
      fontSize: 15,
      color: "var(--text1)",
      fontWeight: 600
    }
  }, "Playing in pop-out window"), React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text2)",
      textAlign: "center",
      maxWidth: 260
    }
  }, "Closing the pop-out will reload the player here."), React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => window.electron?.closePipWindow?.(),
    style: {
      marginTop: 4
    }
  }, "Close pop-out & return")), autoplayCountdown !== null && React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 30,
      display: "flex",
      justifyContent: autoplayNextLayout === "left" ? "flex-start" : "flex-end",
      background: "rgba(0,0,0,0.88)",
      borderRadius: "inherit",
      backdropFilter: "blur(6px)",
      animation: "fadeIn 0.4s ease"
    }
  }, React.createElement("div", {
    style: {
      width: "40%",
      minWidth: "320px",
      maxWidth: "480px",
      height: "100%",
      background: autoplayNextLayout === "left" ? "linear-gradient(90deg, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.85) 60%, rgba(0,0,0,0) 100%)" : "linear-gradient(270deg, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.85) 60%, rgba(0,0,0,0) 100%)",
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      padding: "40px",
      boxSizing: "border-box",
      textAlign: "left"
    }
  }, React.createElement("div", {
    style: {
      fontSize: "11px",
      fontWeight: "700",
      letterSpacing: "1.5px",
      textTransform: "uppercase",
      color: "var(--red)",
      marginBottom: "8px"
    }
  }, "Up Next"), React.createElement("div", {
    style: {
      width: "100%",
      aspectRatio: "16/9",
      borderRadius: "8px",
      overflow: "hidden",
      border: "1px solid rgba(255,255,255,0.1)",
      marginBottom: "18px",
      boxShadow: "0 8px 24px rgba(0,0,0,0.6)",
      background: "var(--surface3)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, nextEp?.still_path ? React.createElement("img", {
    src: imgUrl(nextEp.still_path, "w300"),
    alt: nextEp?.name,
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover"
    }
  }) : React.createElement("span", {
    style: {
      display: "inline-flex",
      width: 32,
      height: 32,
      color: "var(--text3)"
    }
  }, React.createElement(PlayIcon, null))), React.createElement("div", {
    style: {
      fontSize: "13px",
      fontWeight: "600",
      color: "var(--text2)",
      marginBottom: "4px"
    }
  }, "Season ", selectedSeason, " \xB7 Episode", " ", nextEp?.episode_number), React.createElement("div", {
    style: {
      fontSize: "20px",
      fontWeight: "700",
      color: "white",
      marginBottom: "8px",
      lineHeight: "1.3",
      wordBreak: "break-word"
    }
  }, nextEp?.name), autoplayCountdown > 0 ? React.createElement("div", {
    style: {
      fontSize: "14px",
      color: "var(--text3)",
      marginBottom: "20px"
    }
  }, "Starting in", " ", React.createElement("span", {
    style: {
      color: "white",
      fontWeight: "600"
    }
  }, autoplayCountdown), "s...") : React.createElement("div", {
    style: {
      height: "20px",
      marginBottom: "20px"
    }
  }), React.createElement("div", {
    style: {
      display: "flex",
      gap: "12px",
      marginTop: "4px"
    }
  }, React.createElement("button", {
    className: "btn btn-primary",
    style: {
      padding: "10px 22px",
      fontSize: "14px",
      fontWeight: "600",
      background: "var(--red)",
      borderColor: "var(--red)",
      boxShadow: "var(--red-glow)"
    },
    onClick: playNow
  }, "Play Now"), React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "10px 22px",
      fontSize: "14px",
      fontWeight: "600",
      background: "rgba(255,255,255,0.05)"
    },
    onClick: cancelAutoplay
  }, "Cancel")))), React.createElement(StreamPlayerFrame, {
    ref: webviewRef,
    key: sourceUsesCleanUa(playerSource) ? "ua-clean" : "ua-default",
    useragent: sourceUsesCleanUa(playerSource) ? CLEAN_USER_AGENT : undefined,
    src: pipOpen ? "about:blank" : isAsync ? resolvedPlayerUrl || "about:blank" : playerDirectUrl || "about:blank",
    partition: "persist:player",
    allowpopups: "false",
    sandbox: "allow-scripts allow-same-origin allow-forms",
    style: {
      position: "absolute",
      inset: 0,
      width: "100%",
      height: "100%",
      border: "none",
      outline: "none",
      boxShadow: "none",
      background: "black",
      visibility: isAsync && !resolvedPlayerUrl ? "hidden" : "visible"
    },
    tabIndex: -1
  }), React.createElement("div", {
    className: "player-overlay-group"
  }, React.createElement("button", {
    ref: sourceRef,
    className: "player-overlay-btn",
    onClick: () => {
      const rect = sourceRef.current?.getBoundingClientRect();
      if (rect) setMenuPos({
        top: rect.bottom + 6,
        left: rect.left
      });
      setShowSourceMenu(v => !v);
    },
    title: "Change source"
  }, React.createElement(SourceIcon, null), PLAYER_SOURCES.find(s => s.id === playerSource)?.label ?? "Source"), (isAsync || isAnime && sourceSupportsAnime(playerSource)) && React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => {
      const next = dubMode === "sub" ? "dub" : "sub";
      setDubMode(next);
      storage.set(STORAGE_KEYS.HIANIME_DUB_MODE, next);
      setM3u8Url(null);
      setInterceptedSubs([]);
      resolvedPlayerUrlRef.current = null;
      setResolvedPlayerUrl(null);
      resolvingUrlRef.current = false;
      setResolvingUrl(false);
      setResolveError(null);
    },
    title: "Toggle Sub/Dub"
  }, dubMode === "sub" ? "SUB" : "DUB"), React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => {
      setShowSourceMenu(false);
      setShowBlockedModal(true);
    },
    title: "Blocked ads & trackers"
  }, React.createElement(ShieldBlockIcon, null), blockedSession > 0 && React.createElement("span", {
    className: "player-blocked-badge"
  }, blockedSession)), m3u8Url && React.createElement("button", {
    className: "player-overlay-btn",
    style: {
      background: "rgba(229,9,20,0.88)",
      borderColor: "var(--red)"
    },
    onClick: () => {
      const pk = typeof progressKey !== "undefined" ? progressKey : currentProgressKey;
      const epPct = progress?.[pk] || 0;
      const epDone = !!watched?.[pk] || epPct >= 90;
      const startSec = epDone ? 0 : (storage.get("dlTime_" + pk) || 0);
      const payload = {
        url: m3u8Url,
        title: mediaName || title,
        currentSource: playerSource,
        startTimeSec: startSec,
        subtitles: interceptedSubs,
        progressKey: typeof progressKey !== "undefined" ? progressKey : currentProgressKey,
        imdbId: item.imdb_id || item.id,
        mediaType: "tv",
        season: selectedSeason,
        episode: selectedEp?.episode_number || 1,
        subTextColor: storage.get("subtitleTextColor") || "#FFFFFF",
          subBgStyle: storage.get("subtitleBgStyle") || "dark",
          subFontSizeSp: Number(storage.get("subtitleFontSizeSp") || 22),
          preferredSubLang: playerSubLang || "ar"
      };
      if (window.AndroidBridge?.openExoPlayer) {
        window.AndroidBridge.openExoPlayer(JSON.stringify(payload));
        setPlaying(false);
        setPlayerFullscreen(false);
        document.documentElement.removeAttribute("data-player-fullscreen");
      } else {
        onOpenExoPlayer?.(payload);
      }
    },
    title: "Play stream in Native Media3 ExoPlayer"
  }, "\u25B6 ExoPlayer"), React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => tapCenterOfPlayer(),
    title: "Play / Pause"
  }, "\u23EF"), React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => {
      setPlaying(false);
      setPlayerFullscreen(false);
      document.documentElement.removeAttribute("data-player-fullscreen");
    },
    title: "Exit Player"
  }, "\u2715 Exit"), React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => {
      if (pipOpen) {
        window.electron?.closePipWindow?.();
        return;
      }
      const url = isAsync ? resolvedPlayerUrl : playerDirectUrl;
      if (!url) return;
      pipUrlRef.current = url;
      window.electron?.openPipWindow?.(url, item.name ?? item.title, sourceUsesCleanUa(playerSource) ? CLEAN_USER_AGENT : null);
    },
    title: pipOpen ? "Close pop-out" : "Pop out player",
    disabled: !pipOpen && (webviewLoading || !!(isAsync && !resolvedPlayerUrl)),
    style: pipOpen ? {
      color: "var(--red)"
    } : undefined
  }, React.createElement(PopOutIcon, null))), showSourceMenu && menuPos && React.createElement("div", {
    className: "source-dropdown source-dropdown--fixed",
    style: {
      top: menuPos.top,
      left: menuPos.left
    },
    onClick: e => e.stopPropagation()
  }, PLAYER_SOURCES.filter(src => !src.movieOnly).map(src => React.createElement("button", {
    key: src.id,
    className: "source-dropdown__item" + (playerSource === src.id ? " source-dropdown__item--active" : ""),
    onClick: () => {
      setShowSourceMenu(false);
      if (src.id === playerSource) return;
      if (selectedEp) {
        clearFailoverSource(`tv_${item.id}_s${selectedSeason}_e${selectedEp.episode_number}_${dubMode}`);
      }
      setPlayerSource(src.id);
      storage.set(STORAGE_KEYS.PLAYER_SOURCE, src.id);
      setM3u8Url(null);
      setInterceptedSubs([]);
      resolvedPlayerUrlRef.current = null;
      setResolvedPlayerUrl(null);
      resolvingUrlRef.current = false;
      setResolvingUrl(false);
      setResolveError(null);
    }
  }, React.createElement("span", null, src.label), src.tag && React.createElement("span", {
    className: "source-dropdown__tag"
  }, src.tag), src.note && React.createElement("span", {
    className: "source-dropdown__note"
  }, src.note)))), React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => currentEpDownload ? onGoToDownloads?.(currentEpDownload.id) : (setShowSourceMenu(false), setShowDownload(true)),
    title: currentEpDownload ? currentEpDownload.status === "downloading" ? "Downloading… - view in Downloads" : "Already downloaded - view in Downloads" : "Download"
  }, currentEpDownload ? React.createElement("span", {
    className: "player-downloaded-icon",
    style: {
      color: currentEpDownload.status === "downloading" ? "var(--red)" : "#4caf50"
    }
  }, currentEpDownload.status === "downloading" ? "↓" : "✓") : React.createElement(DownloadIcon, null), !currentEpDownload && m3u8Url && React.createElement("span", {
    className: "player-overlay-dot"
  }), !supportsProgress && React.createElement("span", {
    className: "player-no-progress-hint",
    title: "No automatic progress tracking for this source"
  }, "\u26A0 no tracking")), skipPrompt && React.createElement("button", {
    onClick: handleManualSkip,
    style: {
      position: "absolute",
      bottom: 24,
      right: 24,
      zIndex: 50,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 1,
      background: "rgba(0,0,0,0.72)",
      border: "1px solid rgba(255,255,255,0.18)",
      borderRadius: 8,
      color: "white",
      cursor: "pointer",
      padding: "9px 18px",
      backdropFilter: "blur(6px)",
      WebkitBackdropFilter: "blur(6px)",
      transition: "background 0.15s, border-color 0.15s",
      fontFamily: "var(--font-body)",
      animation: "slideDown 0.2s ease"
    },
    onMouseEnter: e => {
      e.currentTarget.style.background = "rgba(229,9,20,0.85)";
      e.currentTarget.style.borderColor = "rgba(229,9,20,0.5)";
    },
    onMouseLeave: e => {
      e.currentTarget.style.background = "rgba(0,0,0,0.72)";
      e.currentTarget.style.borderColor = "rgba(255,255,255,0.18)";
    }
  }, React.createElement("span", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      letterSpacing: 1
    }
  }, "SKIP"), React.createElement("span", {
    style: {
      fontSize: 10,
      color: "rgba(255,255,255,0.7)",
      letterSpacing: 1
    }
  }, skipPrompt === "intro" ? "INTRO" : "OUTRO"))), currentProgressKey && (() => {
    const epPct = progress[currentProgressKey] || 0;
    const dur = durationRef.current;
    const hasMarkers = dur > 0 && (skipTimings?.intro || skipTimings?.outro);
    return epPct > 0 || hasMarkers ? React.createElement("div", {
      className: "progress-bar-row"
    }, React.createElement("div", {
      className: "progress-bar-outer",
      style: {
        position: "relative"
      }
    }, React.createElement("div", {
      className: "progress-bar-fill",
      style: {
        width: `${Math.min(epPct, 100)}%`
      }
    }), dur > 0 && skipTimings?.intro && React.createElement("div", {
      title: "Intro",
      style: {
        position: "absolute",
        top: 0,
        left: `${skipTimings.intro.startTime / dur * 100}%`,
        width: `${(skipTimings.intro.endTime - skipTimings.intro.startTime) / dur * 100}%`,
        height: "100%",
        background: "rgba(251,191,36,0.75)",
        borderRadius: 2,
        pointerEvents: "none"
      }
    }), dur > 0 && skipTimings?.outro && React.createElement("div", {
      title: "Outro",
      style: {
        position: "absolute",
        top: 0,
        left: `${skipTimings.outro.startTime / dur * 100}%`,
        width: `${(skipTimings.outro.endTime - skipTimings.outro.startTime) / dur * 100}%`,
        height: "100%",
        background: "rgba(251,191,36,0.75)",
        borderRadius: 2,
        pointerEvents: "none"
      }
    })), React.createElement("span", {
      style: {
        fontSize: 12,
        color: "var(--text3)"
      }
    }, epPct > 0 ? `${epPct.toFixed(0)}% watched` : "")) : null;
  })(), currentProgressKey && React.createElement("div", {
    className: "progress-mark-row"
  }, React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginRight: 4
    }
  }, "Mark progress:"), [25, 50, 75, 100].map(p => React.createElement("button", {
    key: p,
    className: "btn btn-ghost",
    style: {
      padding: "5px 14px",
      fontSize: 12
    },
    onClick: () => saveProgress(currentProgressKey, p)
  }, p, "%")))), React.createElement("div", {
    className: "section"
  }, React.createElement("div", {
    className: "section-title"
  }, "Episodes"), seasons.length > 0 && React.createElement("div", {
    className: "season-selector"
  }, seasons.map(s => {
    const sw = seasonWatchedMap[s.season_number] ?? "none";
    return React.createElement("button", {
      key: s.season_number,
      className: `season-btn ${selectedSeason === s.season_number ? "active" : ""} ${sw === "all" ? "season-watched" : sw.startsWith("some") ? "season-partial" : ""}`,
      onClick: () => setSelectedSeason(s.season_number),
      onContextMenu: e => {
        e.preventDefault();
        e.stopPropagation();
        setSeasonMenu({
          x: e.clientX,
          y: e.clientY,
          seasonNum: s.season_number
        });
      },
      title: "Right-click to mark season as watched/unwatched"
    }, sw === "all" && React.createElement("span", {
      className: "season-watched-icon"
    }, "\u2713"), sw === "some25" && React.createElement(PartialCircleIcon, {
      pct: 25
    }), sw === "some50" && React.createElement(PartialCircleIcon, {
      pct: 50
    }), sw === "some75" && React.createElement(PartialCircleIcon, {
      pct: 75
    }), s.season_number === 0 ? "Specials" : `Season ${s.season_number}`);
  })), selectedSeason === 0 && !loadingSeason && React.createElement("div", {
    style: {
      margin: "8px 0",
      padding: "8px 12px",
      borderRadius: 8,
      background: "rgba(255,200,50,0.08)",
      border: "1px solid rgba(255,200,50,0.2)",
      fontSize: 12,
      color: "var(--text3)",
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, React.createElement("span", null, React.createElement(AlertIcon, { size: 28 })), React.createElement("span", null, "Specials support varies by provider. If the wrong episode plays, try switching to a different source. But it can't be guaranteed that the correct Episode will be available.")), loadingSeason && React.createElement("div", {
    className: "loader"
  }, React.createElement("div", {
    className: "spinner"
  })), !loadingSeason && (seasonData?.episodes || episodeGroupCurrentEpisodes?.length) && React.createElement("div", {
    className: "episodes-grid"
  }, currentSeasonEpisodes.map(ep => {
    const pk = `tv_${item.id}_s${selectedSeason}e${ep.episode_number}`;
    return React.createElement(EpisodeCard, {
      key: ep.episode_number,
      ep: ep,
      itemId: item.id,
      selectedSeason: selectedSeason,
      epPct: progress[pk] || 0,
      epWatched: !!watched?.[pk],
      playing: playing,
      selectedEpNumber: selectedEp?.episode_number,
      downloadsByEpisodeKey: downloadsByEpisodeKey,
      restricted: restricted,
      onPlay: playEpisode,
      onContextMenu: setEpMenu,
      onGoToDownloads: onGoToDownloads
    });
  })))), showTrailer && trailerKey && React.createElement(TrailerModal, {
    trailerKey: trailerKey,
    title: title,
    onClose: () => setShowTrailer(false)
  }), downloadConfirm && React.createElement(DownloadConfirmModal, {
    title: downloadConfirm.type === "season"
      ? `${title} · Season ${downloadConfirm.season}`
      : `${title} · S${selectedSeason}E${downloadConfirm.ep.episode_number} ${downloadConfirm.ep.name || ""}`,
    runtimeMin: downloadConfirm.type === "season" ? (d.episode_run_time?.[0] || 45) : (downloadConfirm.ep.runtime || d.episode_run_time?.[0] || 45),
    episodeCount: downloadConfirm.type === "season" ? Math.max(1, (downloadConfirm.episodes || []).length) : 1,
    onCancel: () => setDownloadConfirm(null),
    onConfirm: () => {
      const target = downloadConfirm;
      setDownloadConfirm(null);
      const targetEp = target.type === "season" ? (target.episodes || [])[0] : target.ep;
      if (!targetEp) return;
      if (selectedEp?.episode_number === targetEp.episode_number && m3u8Url) {
        setShowDownload(true);
      } else {
        setPendingEpDownload(true);
        playEpisode(targetEp);
      }
    }
  }), epMenu && React.createElement(ContextMenu, {
    x: epMenu.x,
    y: epMenu.y,
    isWatched: !!watched?.[epMenu.pk],
    hasProgress: (progress?.[epMenu.pk] ?? 0) > 0,
    watchedLabel: "Mark as Watched",
    unwatchedLabel: "Mark as Unwatched",
    onMarkWatched: () => onMarkWatched?.(epMenu.pk),
    onMarkUnwatched: () => onMarkUnwatched?.(epMenu.pk),
    onMarkNotStarted: () => {
      onMarkUnwatched?.(epMenu.pk);
      saveProgress?.(epMenu.pk, 0);
      storage.set("dlTime_" + epMenu.pk, null);
    },
    onClose: () => setEpMenu(null)
  }), seasonMenu && React.createElement(ContextMenu, {
    x: seasonMenu.x,
    y: seasonMenu.y,
    isWatched: isSeasonWatched(seasonMenu.seasonNum),
    watchedLabel: "Mark Season as Watched",
    unwatchedLabel: "Mark Season as Unwatched",
    onMarkWatched: () => markSeasonWatched(seasonMenu.seasonNum),
    onMarkUnwatched: () => markSeasonUnwatched(seasonMenu.seasonNum),
    onClose: () => setSeasonMenu(null)
  }), showBlockedModal && React.createElement(BlockedStatsModal, {
    sessionDomains: getBlockedDomains(),
    sessionTotal: blockedSession,
    alltimeTotal: blockedAlltime,
    onClose: () => setShowBlockedModal(false)
  }), showDownload && React.createElement(DownloadModal, {
    onClose: () => setShowDownload(false),
    m3u8Url: m3u8Url,
    subtitles: interceptedSubs,
    mediaName: mediaName,
    downloaderFolder: downloaderFolder,
    setDownloaderFolder: handleSetDownloaderFolder,
    onOpenSettings: onSettings,
    onDownloadStarted: onDownloadStarted,
    mediaId: item.id,
    mediaType: "tv",
    season: selectedSeason,
    episode: selectedEp?.episode_number,
    posterPath: d.poster_path,
    tmdbId: item.id
  }));
}
const EpisodeCard = memo(function EpisodeCard({
  ep,
  itemId,
  selectedSeason,
  epPct,
  epWatched,
  playing,
  selectedEpNumber,
  downloadsByEpisodeKey,
  restricted,
  onPlay,
  onContextMenu,
  onGoToDownloads,
  onDownloadEp
}) {
  const pk = `tv_${itemId}_s${selectedSeason}e${ep.episode_number}`;
  const isPlaying = playing && selectedEpNumber === ep.episode_number;
  const epUnreleased = isUnreleased(ep.air_date);
  const epDownload = downloadsByEpisodeKey.get(`s${selectedSeason}e${ep.episode_number}`) ?? null;
  return React.createElement("div", {
    className: `episode-card ${isPlaying ? "playing" : ""} ${epWatched ? "ep-watched" : ""} ${restricted ? "episode-card--restricted" : ""} ${epUnreleased ? "episode-card--unreleased" : ""}`,
    onClick: () => restricted || epUnreleased ? null : onPlay(ep),
    onContextMenu: e => {
      e.preventDefault();
      e.stopPropagation();
      if (!restricted && !epUnreleased) onContextMenu({
        x: e.clientX,
        y: e.clientY,
        pk
      });
    },
    style: epUnreleased ? {
      cursor: "default"
    } : undefined
  }, React.createElement("div", {
    className: "episode-thumb"
  }, ep.still_path ? React.createElement("img", {
    src: imgUrl(ep.still_path, "w300"),
    alt: ep.name,
    loading: "lazy"
  }) : React.createElement("div", {
    style: {
      width: "100%",
      height: "100%",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: "var(--text3)"
    }
  }, React.createElement(PlayIcon, null)), restricted ? React.createElement("div", {
    className: "episode-restricted-overlay"
  }, React.createElement(RatingLockIcon, { size: 18 }), React.createElement("span", null, "Inappropriate for your age")) : epUnreleased ? React.createElement("div", {
    className: "episode-restricted-overlay"
  }, React.createElement(RatingLockIcon, { size: 18 }), React.createElement("span", null, "Unreleased"), React.createElement("span", null, getDaysUntilRelease(ep.air_date))) : isPlaying ? React.createElement("div", {
    className: "episode-playing-badge"
  }, React.createElement("span", {
    className: "episode-playing-dot"
  }), "Playing") : React.createElement("div", {
    className: "episode-thumb-play"
  }, React.createElement(PlayIcon, null))), React.createElement("div", {
    className: "episode-info"
  }, React.createElement("div", {
    className: "episode-num",
    style: {
      display: "flex",
      alignItems: "center",
      gap: 5
    }
  }, "E", ep.episode_number, epWatched && React.createElement(WatchedIcon, {
    size: 14
  }), epDownload && React.createElement("span", {
    className: "ep-downloaded-badge",
    title: epDownload.status === "downloading" ? "Downloading… - click to view in Downloads" : "Downloaded - click to view in Downloads",
    style: {
      borderColor: epDownload.status === "downloading" ? "rgba(229,9,20,0.5)" : "rgba(72,199,116,0.5)",
      color: epDownload.status === "downloading" ? "var(--red)" : "#4caf50",
      background: epDownload.status === "downloading" ? "rgba(229,9,20,0.12)" : "rgba(72,199,116,0.18)"
    },
    onClick: e => {
      e.stopPropagation();
      onGoToDownloads?.(epDownload.id);
    }
  }, "\u2193")), React.createElement("div", {
    className: "episode-name"
  }, ep.name), React.createElement(EpisodeDesc, {
    overview: ep.overview,
    episodeName: ep.name
  }), !epWatched && epPct > 0 && React.createElement("div", {
    className: "episode-progress-bar"
  }, React.createElement("div", {
    className: "episode-progress-fill",
    style: {
      width: `${Math.min(epPct, 100)}%`
    }
  }))));
});
