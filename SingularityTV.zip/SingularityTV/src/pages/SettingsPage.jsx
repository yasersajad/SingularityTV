import { useState, useEffect, useRef } from "react";
import UpdateModal from "../components/UpdateModal";
import { storage, STORAGE_KEYS, secureStorage, isElectron, clearAppCaches } from "../utils/storage";
import { clearTmdbCache } from "../utils/api";
import { ACCENT_PRESETS, applyAccentColor, THEME_PRESETS, applyTheme, DEFAULT_CUSTOM_VARS } from "../utils/appearance";
import { SUBTITLE_LANGUAGES } from "../utils/subtitles";
import { DEFAULT_INVIDIOUS_BASE } from "../components/TrailerModal";
import { RATING_COUNTRIES } from "../utils/ageRating";
import { WarningIcon } from "../components/Icons";
import { checkForUpdatesWithFallback, UPDATE_SOURCES, DEFAULT_UPDATE_SOURCE } from "../utils/updates";
import { HOME_ROWS, loadHomeLayout, loadHomeViewMode, saveHomeViewMode } from "../utils/homeLayout";
import { collectBackupData, restoreBackupData } from "../utils/backup";
import {
  getGoogleAccount,
  getGoogleClientId,
  setGoogleClientId,
  getLastCloudSyncTime,
  signInWithGoogleProfile,
  signOutGoogleAccount,
  pushToGoogleDrive,
  pullFromGoogleDrive,
  launchGoogleOAuthInteractive
} from "../utils/googleSync";
import { formatBytes } from "../utils/storage";
function SettingsSelect({
  value,
  onChange,
  options,
  style
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  const selectedLabel = options.find(o => String(o.value) === String(value))?.label ?? value;
  useEffect(() => {
    const handler = e => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);
  return React.createElement("div", {
    ref: ref,
    style: {
      position: "relative",
      display: "inline-block",
      ...style
    }
  }, React.createElement("button", {
    type: "button",
    onClick: () => setOpen(o => !o),
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 28,
      padding: "9px 14px",
      background: open ? "var(--surface3)" : "var(--surface2)",
      border: `1px solid ${open ? "var(--red)" : "var(--border)"}`,
      boxShadow: open ? "0 0 0 3px rgba(229,9,20,0.12)" : "none",
      borderRadius: 8,
      color: "var(--text)",
      fontFamily: "var(--font-body)",
      fontSize: 14,
      cursor: "pointer",
      whiteSpace: "nowrap",
      minWidth: 0,
      transition: "border-color 0.15s, background 0.15s, box-shadow 0.15s"
    },
    onMouseEnter: e => {
      if (!open) e.currentTarget.style.background = "var(--surface3)";
    },
    onMouseLeave: e => {
      if (!open) e.currentTarget.style.background = "var(--surface2)";
    }
  }, React.createElement("span", {
    style: {
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  }, selectedLabel), React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "var(--text3)",
    strokeWidth: "2.5",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      flexShrink: 0,
      transform: open ? "rotate(180deg)" : "rotate(0deg)",
      transition: "transform 0.2s"
    }
  }, React.createElement("polyline", {
    points: "6 9 12 15 18 9"
  }))), open && React.createElement("div", {
    className: "settings-select-menu",
    style: {
      position: "absolute",
      top: "calc(100% + 6px)",
      left: 0,
      zIndex: 999,
      background: "var(--surface3)",
      border: "1px solid var(--border)",
      borderRadius: 10,
      boxShadow: "0 12px 40px rgba(0,0,0,0.55)",
      minWidth: "100%",
      maxHeight: 280,
      overflowY: "auto",
      padding: "4px"
    }
  }, options.map(o => {
    const active = String(o.value) === String(value);
    return React.createElement("div", {
      key: o.value,
      className: "settings-select-option",
      role: "button",
      tabIndex: 0,
      onClick: e => {
        e.stopPropagation();
        onChange(o.value);
        setOpen(false);
      },
      onMouseDown: e => {
        e.stopPropagation();
        onChange(o.value);
        setOpen(false);
      },
      style: {
        padding: "8px 12px",
        fontSize: 14,
        borderRadius: 7,
        cursor: "pointer",
        color: active ? "var(--red)" : "var(--text)",
        background: active ? "rgba(229,9,20,0.10)" : "transparent",
        fontWeight: active ? 600 : 400,
        transition: "background 0.1s, color 0.1s",
        whiteSpace: "nowrap"
      },
      onMouseEnter: e => {
        if (!active) e.currentTarget.style.background = "rgba(255,255,255,0.06)";
      },
      onMouseLeave: e => {
        if (!active) e.currentTarget.style.background = "transparent";
      }
    }, o.label);
  })));
}
const AGE_LIMIT_OPTIONS = [{
  value: "",
  label: "No restriction"
}, {
  value: "0",
  label: "0 — All audiences (G / FSK 0)"
}, {
  value: "7",
  label: "7 — Family friendly (PG / FSK 6)"
}, {
  value: "12",
  label: "12 — Teens and up"
}, {
  value: "13",
  label: "13 — PG-13 and equivalent"
}, {
  value: "15",
  label: "15 — Older teens"
}, {
  value: "16",
  label: "16 — FSK 16 and equivalent"
}, {
  value: "17",
  label: "17 — R / 17+ and equivalent"
}, {
  value: "18",
  label: "18 — Adults only (NC-17 / FSK 18)"
}];
function ResetConfirmDialog({
  onConfirm,
  onCancel
}) {
  return React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      zIndex: 1000,
      background: "rgba(0,0,0,0.75)",
      backdropFilter: "blur(6px)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, React.createElement("div", {
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border)",
      borderRadius: 12,
      padding: "36px 40px",
      maxWidth: 460,
      width: "90%",
      boxShadow: "0 24px 64px rgba(0,0,0,0.6)"
    }
  }, React.createElement("div", {
    style: {
      width: 52,
      height: 52,
      borderRadius: "50%",
      background: "rgba(229,9,20,0.12)",
      border: "1px solid rgba(229,9,20,0.3)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      marginBottom: 20
    }
  }, React.createElement(WarningIcon, {
    size: 24
  })), React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 26,
      letterSpacing: 1,
      marginBottom: 10
    }
  }, "RESET SINGULARITYTV?"), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text2)",
      lineHeight: 1.7,
      marginBottom: 28
    }
  }, "This will permanently delete all your settings, watch history, saved titles, progress data, and cached data. Your downloaded video files will", " ", React.createElement("span", {
    style: {
      color: "var(--text)",
      fontWeight: 600
    }
  }, "not"), " be deleted.", React.createElement("br", null), React.createElement("br", null), React.createElement("span", {
    style: {
      color: "var(--red)"
    }
  }, "This action cannot be undone.")), React.createElement("div", {
    style: {
      display: "flex",
      gap: 12
    }
  }, React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      flex: 1
    },
    onClick: onCancel
  }, "Cancel"), React.createElement("button", {
    className: "btn",
    style: {
      flex: 1,
      background: "var(--red)",
      color: "#fff",
      border: "none",
      fontWeight: 600
    },
    onClick: onConfirm
  }, "Yes, Reset Everything"))));
}
function ConfirmDialog({
  title,
  description,
  confirmLabel = "Confirm",
  onConfirm,
  onCancel
}) {
  return React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      zIndex: 1000,
      background: "rgba(0,0,0,0.75)",
      backdropFilter: "blur(6px)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, React.createElement("div", {
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border)",
      borderRadius: 12,
      padding: "36px 40px",
      maxWidth: 460,
      width: "90%",
      boxShadow: "0 24px 64px rgba(0,0,0,0.6)"
    }
  }, React.createElement("div", {
    style: {
      width: 52,
      height: 52,
      borderRadius: "50%",
      background: "rgba(229,9,20,0.12)",
      border: "1px solid rgba(229,9,20,0.3)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      marginBottom: 20
    }
  }, React.createElement(WarningIcon, {
    size: 24
  })), React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 22,
      letterSpacing: 1,
      marginBottom: 10
    }
  }, title), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text2)",
      lineHeight: 1.7,
      marginBottom: 28
    }
  }, description, React.createElement("br", null), React.createElement("br", null), React.createElement("span", {
    style: {
      color: "var(--red)"
    }
  }, "This action cannot be undone.")), React.createElement("div", {
    style: {
      display: "flex",
      gap: 12
    }
  }, React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      flex: 1
    },
    onClick: onCancel
  }, "Cancel"), React.createElement("button", {
    className: "btn",
    style: {
      flex: 1,
      background: "var(--red)",
      color: "#fff",
      border: "none",
      fontWeight: 600
    },
    onClick: onConfirm
  }, confirmLabel))));
}
function Toggle({
  value,
  onChange,
  title
}) {
  return React.createElement("button", {
    onClick: () => onChange(!value),
    title: title,
    style: {
      background: value ? "var(--red)" : "var(--surface2)",
      border: "1px solid " + (value ? "var(--red)" : "var(--border)"),
      borderRadius: 20,
      width: 40,
      height: 22,
      cursor: "pointer",
      position: "relative",
      flexShrink: 0,
      transition: "background 0.2s, border-color 0.2s"
    }
  }, React.createElement("span", {
    style: {
      position: "absolute",
      top: 2,
      left: value ? 20 : 2,
      width: 16,
      height: 16,
      background: "#fff",
      borderRadius: "50%",
      transition: "left 0.2s",
      boxShadow: "0 1px 3px rgba(0,0,0,0.3)"
    }
  }));
}
function StatusBadge({
  status
}) {
  if (!status) return null;
  const isError = status.startsWith("✕");
  return React.createElement("div", {
    style: {
      marginTop: 10,
      fontSize: 13,
      fontWeight: 500,
      color: isError ? "var(--red)" : "#48c774"
    }
  }, status);
}
function CleanRow({
  title,
  description,
  buttonLabel,
  onAction,
  danger,
  sizeLabel
}) {
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState(null);
  const [hovered, setHovered] = useState(false);
  const handle = async () => {
    setBusy(true);
    setStatus(null);
    try {
      const result = await onAction();
      if (result?.cancelled) {
        return;
      }
      setStatus(result?.msg || "✓ Done");
      setTimeout(() => setStatus(null), 4000);
    } catch (e) {
      setStatus("✕ " + (e.message || "Something went wrong"));
      setTimeout(() => setStatus(null), 4000);
    } finally {
      setBusy(false);
    }
  };
  return React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      justifyContent: "space-between",
      gap: 24
    }
  }, React.createElement("div", {
    style: {
      flex: 1
    }
  }, React.createElement("div", {
    style: {
      fontSize: 15,
      fontWeight: 600,
      color: "var(--text)",
      marginBottom: 4,
      display: "flex",
      alignItems: "center",
      gap: 10
    }
  }, title, sizeLabel && React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: "var(--text2)",
      background: "var(--surface2)",
      border: "1px solid var(--border)",
      borderRadius: 6,
      padding: "3px 10px",
      letterSpacing: 0.2,
      fontVariantNumeric: "tabular-nums"
    }
  }, sizeLabel)), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      lineHeight: 1.6
    }
  }, description), React.createElement(StatusBadge, {
    status: status
  })), React.createElement("div", {
    style: {
      flexShrink: 0,
      paddingTop: 2
    }
  }, React.createElement("button", {
    className: "btn btn-ghost",
    disabled: busy,
    onClick: handle,
    onMouseEnter: () => setHovered(true),
    onMouseLeave: () => setHovered(false),
    style: danger ? {
      color: hovered ? "#fff" : "var(--red)",
      background: hovered ? "rgba(229,9,20,0.85)" : "transparent",
      borderColor: hovered ? "transparent" : "rgba(229,9,20,0.35)",
      opacity: busy ? 0.5 : 1,
      transition: "all 0.2s"
    } : {
      opacity: busy ? 0.5 : 1
    }
  }, busy ? "Working…" : buttonLabel)));
}
function GoogleAccountSection() {
  const [user, setUser] = useState(() => getGoogleAccount());
  const [emailInput, setEmailInput] = useState(() => getGoogleAccount()?.email || "");
  const [nameInput, setNameInput] = useState(() => getGoogleAccount()?.name || "");
  const [tokenInput, setTokenInput] = useState("");
  const [clientIdInput, setClientIdInput] = useState(() => getGoogleClientId());
  const [showAdvancedOAuth, setShowAdvancedOAuth] = useState(false);
  const [lastSync, setLastSync] = useState(() => getLastCloudSyncTime());
  const [statusMsg, setStatusMsg] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const onAcc = () => {
      const u = getGoogleAccount();
      setUser(u);
      setLastSync(getLastCloudSyncTime());
    };
    window.addEventListener("streambert:google-account-changed", onAcc);
    return () => window.removeEventListener("streambert:google-account-changed", onAcc);
  }, []);

  const handleSignIn = async () => {
    setBusy(true);
    setStatusMsg("");
    try {
      const res = await signInWithGoogleProfile({
        email: emailInput,
        name: nameInput,
        accessToken: tokenInput.trim() || undefined
      });
      setUser(res.user);
      setLastSync(getLastCloudSyncTime());
      setStatusMsg(res.restoredFromCloud ? "✓ Signed in & restored your saved profile data!" : "✓ Signed in with Google Account & synced all settings, watch history, and search history.");
      if (res.restoredFromCloud) {
        setTimeout(() => window.location.reload(), 900);
      }
    } catch (e) {
      setStatusMsg("⚠ " + (e.message || "Could not sign in"));
    } finally {
      setBusy(false);
    }
  };

  const handleSyncNow = async () => {
    setBusy(true);
    setStatusMsg("");
    try {
      const res = await pushToGoogleDrive();
      setLastSync(res.updatedAt || Date.now());
      setStatusMsg(res.mode === "google_drive" ? "✓ Synced to Google Drive AppData!" : "✓ Saved to account vault (settings, watch history, watchlist, search history).");
    } catch (e) {
      setStatusMsg("⚠ " + (e.message || "Sync failed"));
    } finally {
      setBusy(false);
    }
  };

  const handleRestoreCloud = async () => {
    setBusy(true);
    setStatusMsg("");
    try {
      const pulled = await pullFromGoogleDrive();
      if (pulled) {
        setStatusMsg("✓ Restored from Google Drive! Reloading…");
        setTimeout(() => window.location.reload(), 800);
      } else {
        setStatusMsg("✓ Local account vault is already up to date.");
      }
    } catch (e) {
      setStatusMsg("⚠ " + (e.message || "Could not restore"));
    } finally {
      setBusy(false);
    }
  };

  return React.createElement("div", {
    style: {
      marginBottom: 36,
      padding: "20px 22px",
      background: "var(--surface2)",
      border: "1px solid var(--border)",
      borderRadius: 12
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 14,
      flexWrap: "wrap",
      marginBottom: 14
    }
  }, React.createElement("div", {
    style: { display: "flex", alignItems: "center", gap: 12 }
  }, React.createElement("div", {
    style: {
      width: 42,
      height: 42,
      borderRadius: "50%",
      background: user ? "var(--red)" : "rgba(255,255,255,0.1)",
      color: "#fff",
      fontWeight: 800,
      fontSize: 18,
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, user ? (user.name || user.email || "G").charAt(0).toUpperCase() : "G"), React.createElement("div", null, React.createElement("div", {
    style: { fontSize: 15, fontWeight: 700, color: "var(--text)" }
  }, user ? `${user.name} (${user.email})` : "Sign in with Google"), React.createElement("div", {
    style: { fontSize: 12, color: "var(--text3)", marginTop: 2 }
  }, user
    ? `Auto-syncing settings, watch progress, watchlist & search history${lastSync ? ` · Last synced ${new Date(lastSync).toLocaleTimeString()}` : ""}`
    : "Link your Google account to automatically save & restore your settings, watch history, watchlist, and search history.")))), user ? React.createElement("div", {
    style: { display: "flex", gap: 10, flexWrap: "wrap", marginTop: 10 }
  }, React.createElement("button", {
    className: "btn btn-primary",
    disabled: busy,
    onClick: handleSyncNow
  }, busy ? "Syncing…" : "Sync Now"), React.createElement("button", {
    className: "btn btn-secondary",
    disabled: busy,
    onClick: handleRestoreCloud
  }, "Restore from Account"), React.createElement("button", {
    className: "btn btn-ghost",
    onClick: () => {
      signOutGoogleAccount();
      setUser(null);
      setStatusMsg("Signed out of Google Account.");
    }
  }, "Sign Out")) : React.createElement("div", {
    style: { display: "flex", flexDirection: "column", gap: 12, marginTop: 10 }
  }, React.createElement("div", {
    style: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(210px, 1fr))", gap: 10 }
  }, React.createElement("input", {
    className: "search-input",
    style: { marginBottom: 0 },
    placeholder: "Google Email (e.g. you@gmail.com)",
    value: emailInput,
    onChange: e => setEmailInput(e.target.value)
  }), React.createElement("input", {
    className: "search-input",
    style: { marginBottom: 0 },
    placeholder: "Display Name (optional)",
    value: nameInput,
    onChange: e => setNameInput(e.target.value)
  })), showAdvancedOAuth && React.createElement("div", {
    style: { display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(210px, 1fr))", gap: 10 }
  }, React.createElement("input", {
    className: "search-input",
    style: { marginBottom: 0 },
    placeholder: "Google OAuth Client ID (optional)",
    value: clientIdInput,
    onChange: e => {
      setClientIdInput(e.target.value);
      setGoogleClientId(e.target.value);
    }
  }), React.createElement("input", {
    className: "search-input",
    style: { marginBottom: 0 },
    placeholder: "Google Drive Access Token (optional)",
    value: tokenInput,
    onChange: e => setTokenInput(e.target.value)
  })), React.createElement("div", {
    style: { display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }
  }, React.createElement("button", {
    className: "btn btn-primary",
    disabled: busy,
    onClick: handleSignIn
  }, busy ? "Signing in…" : "Sign in with Google"), React.createElement("button", {
    className: "btn btn-ghost",
    onClick: () => setShowAdvancedOAuth(v => !v)
  }, showAdvancedOAuth ? "Hide Drive OAuth Options" : "Google Drive OAuth Options"), showAdvancedOAuth && clientIdInput.trim() && React.createElement("button", {
    className: "btn btn-secondary",
    onClick: () => launchGoogleOAuthInteractive(clientIdInput).catch(err => setStatusMsg("⚠ " + err.message))
  }, "Launch Google OAuth ↗"))), statusMsg && React.createElement("div", {
    style: { marginTop: 12, fontSize: 13, color: statusMsg.startsWith("⚠") ? "var(--red)" : "#48c774" }
  }, statusMsg));
}

function VersionSection() {
  const [checking, setChecking] = useState(false);
  const [result, setResult] = useState(null);
  const [showUpdateModal, setShowUpdateModal] = useState(false);
  const [autoCheck, setAutoCheck] = useState(() => {
    const stored = storage.get(STORAGE_KEYS.AUTO_CHECK_UPDATES);
    return stored === null || stored === undefined ? true : !!stored;
  });
  const [autoSaved, setAutoSaved] = useState(false);
  const [currentVersion, setCurrentVersion] = useState("0.0.0");
  const [updateSource, setUpdateSource] = useState(() => storage.get(STORAGE_KEYS.UPDATE_SOURCE) || DEFAULT_UPDATE_SOURCE);
  useEffect(() => {
    if (window.electron?.getAppVersion) {
      window.electron.getAppVersion().then(v => {
        setCurrentVersion(v);
      });
    }
  }, []);
  const runCheck = async () => {
    setChecking(true);
    setResult(null);
    try {
      const r = await checkForUpdatesWithFallback(updateSource);
      setResult(r);
    } catch (e) {
      setResult({
        error: e.message || `Could not reach ${UPDATE_SOURCES[updateSource]?.label || "the update server"}.`
      });
    } finally {
      setChecking(false);
    }
  };
  const changeSource = src => {
    setUpdateSource(src);
    storage.set(STORAGE_KEYS.UPDATE_SOURCE, src);
    setResult(null);
  };
  const toggleAuto = val => {
    setAutoCheck(val);
    storage.set(STORAGE_KEYS.AUTO_CHECK_UPDATES, val ? 1 : 0);
    setAutoSaved(true);
    setTimeout(() => setAutoSaved(false), 1800);
  };
  return React.createElement("div", {
    style: {
      marginBottom: 40
    }
  }, React.createElement("div", {
    className: "settings-section-title"
  }, "SingularityTV · By @ec1lz"), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 12,
      padding: "14px 16px",
      marginBottom: 18,
      background: "var(--surface2)",
      border: "1px solid var(--border)",
      borderRadius: 10
    }
  }, React.createElement("div", null, React.createElement("div", {
    style: { fontSize: 14, fontWeight: 700, color: "var(--text)" }
  }, "SingularityTV Official · @ec1lz"), React.createElement("div", {
    style: { fontSize: 12, color: "var(--text3)", marginTop: 2 }
  }, "All rights reserved to Singularity (@ec1lz)")), React.createElement("button", {
    className: "btn btn-primary",
    onClick: () => window.electron?.openExternal("https://t.me/ec1lz")
  }, "Telegram @ec1lz ↗")), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 16,
      flexWrap: "wrap",
      marginBottom: 20
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10
    }
  }, React.createElement("span", {
    style: {
      fontSize: 13,
      color: "var(--text3)"
    }
  }, "Current version"), React.createElement("code", {
    style: {
      fontSize: 14,
      fontWeight: 700,
      color: "var(--text)",
      background: "var(--surface2)",
      border: "1px solid var(--border)",
      borderRadius: 6,
      padding: "4px 12px"
    }
  }, "v", currentVersion)), React.createElement("button", {
    className: "btn btn-ghost",
    disabled: checking,
    onClick: runCheck,
    style: {
      opacity: checking ? 0.6 : 1
    }
  }, checking ? "Checking…" : "Check for Updates"), React.createElement("div", {
    style: {
      display: "inline-flex",
      border: "1px solid var(--border)",
      borderRadius: 8,
      overflow: "hidden"
    }
  }, Object.values(UPDATE_SOURCES).map(src => React.createElement("button", {
    key: src.id,
    onClick: () => changeSource(src.id),
    disabled: checking,
    title: `Check for updates via ${src.label}`,
    style: {
      border: "none",
      padding: "6px 12px",
      fontSize: 12,
      fontWeight: 600,
      cursor: checking ? "not-allowed" : "pointer",
      background: updateSource === src.id ? "var(--red)" : "var(--surface2)",
      color: updateSource === src.id ? "#fff" : "var(--text3)"
    }
  }, src.label))), result && !result.error && result.hasUpdate && React.createElement("button", {
    onClick: () => setShowUpdateModal(true),
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      background: "rgba(229,9,20,0.12)",
      border: "1px solid rgba(229,9,20,0.4)",
      color: "var(--red)",
      borderRadius: 8,
      padding: "6px 14px",
      fontSize: 13,
      fontWeight: 600,
      cursor: "pointer",
      transition: "background 0.2s"
    },
    onMouseEnter: e => e.currentTarget.style.background = "rgba(229,9,20,0.22)",
    onMouseLeave: e => e.currentTarget.style.background = "rgba(229,9,20,0.12)"
  }, "\uD83C\uDF89 v", result.latest, " available. Install Update"), result?.usedFallback && React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, "(", UPDATE_SOURCES[result.fallbackFrom]?.label || result.fallbackFrom, " ", "unavailable, used ", result.sourceLabel, " instead)"), result && !result.error && !result.hasUpdate && React.createElement("span", {
    style: {
      fontSize: 13,
      color: "#48c774",
      fontWeight: 500
    }
  }, "\u2713 You're up to date"), result?.error && React.createElement("span", {
    style: {
      fontSize: 13,
      color: "var(--red)"
    }
  }, "\u2715 ", result.error)), showUpdateModal && result?.hasUpdate && React.createElement(UpdateModal, {
    updateInfo: result,
    onClose: () => setShowUpdateModal(false)
  }), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      flexWrap: "wrap"
    }
  }, React.createElement(Toggle, {
    value: autoCheck,
    onChange: toggleAuto,
    title: autoCheck ? "Disable auto-check" : "Enable auto-check"
  }), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: "var(--text)"
    }
  }, "Check for updates on startup"), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 2
    }
  }, "Shows a notification banner if a new version is available. Turned on by default.")), autoSaved && React.createElement("span", {
    style: {
      fontSize: 12,
      color: "#48c774"
    }
  }, "\u2713 Saved")));
}
function HomeLayoutSection() {
  const [order, setOrder] = useState(() => {
    const {
      order: o
    } = loadHomeLayout();
    return o;
  });
  const [visible, setVisible] = useState(() => {
    const {
      visible: v
    } = loadHomeLayout();
    return v;
  });
  const [viewMode, setViewMode] = useState(() => loadHomeViewMode());
  const [saved, setSaved] = useState(false);
  const dragItem = useRef(null);
  const dragOver = useRef(null);
  const handleDragStart = idx => {
    dragItem.current = idx;
  };
  const handleDragEnter = idx => {
    dragOver.current = idx;
  };
  const handleDragEnd = () => {
    const newOrder = [...order];
    const dragged = newOrder.splice(dragItem.current, 1)[0];
    newOrder.splice(dragOver.current, 0, dragged);
    dragItem.current = null;
    dragOver.current = null;
    setOrder(newOrder);
  };
  const toggleVisible = id => {
    setVisible(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };
  const handleSave = () => {
    storage.set(STORAGE_KEYS.HOME_ROW_ORDER, order);
    storage.set(STORAGE_KEYS.HOME_ROW_VISIBLE, visible);
    saveHomeViewMode(viewMode);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };
  const rowLabels = Object.fromEntries(HOME_ROWS.map(r => [r.id, r.label]));
  return React.createElement("div", {
    style: {
      marginBottom: 40
    }
  }, React.createElement("div", {
    className: "settings-section-title"
  }, "Home Page Layout"), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      marginBottom: 16,
      lineHeight: 1.6
    }
  }, "Choose which rows appear on the Home page and drag to reorder them. The hero banner is always shown at the top."), React.createElement("div", {
    style: {
      marginBottom: 20
    }
  }, React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: "var(--text2)",
      marginBottom: 8,
      textTransform: "uppercase",
      letterSpacing: "0.05em"
    }
  }, "Row display style"), React.createElement("div", {
    style: {
      display: "flex",
      gap: 10
    }
  }, [{
    value: "carousel",
    label: "Carousel",
    desc: "Scrollable spotlight with featured poster"
  }, {
    value: "list",
    label: "⊞ Grid",
    desc: "Compact grid of all items"
  }].map(({
    value,
    label,
    desc
  }) => React.createElement("button", {
    key: value,
    onClick: () => setViewMode(value),
    style: {
      flex: 1,
      maxWidth: 220,
      padding: "10px 14px",
      borderRadius: 8,
      border: `2px solid ${viewMode === value ? "var(--red)" : "var(--border)"}`,
      background: viewMode === value ? "color-mix(in srgb, var(--red) 12%, var(--surface))" : "var(--surface)",
      color: viewMode === value ? "var(--text)" : "var(--text2)",
      cursor: "pointer",
      textAlign: "left",
      transition: "border-color 0.15s, background 0.15s"
    }
  }, React.createElement("div", {
    style: {
      fontWeight: 600,
      fontSize: 14
    }
  }, label), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 2
    }
  }, desc))))), React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 8,
      maxWidth: 480
    }
  }, order.map((id, idx) => React.createElement("div", {
    key: id,
    draggable: true,
    onDragStart: () => handleDragStart(idx),
    onDragEnter: () => handleDragEnter(idx),
    onDragEnd: handleDragEnd,
    onDragOver: e => e.preventDefault(),
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      background: "var(--surface)",
      border: "1px solid var(--border)",
      borderRadius: 8,
      padding: "10px 14px",
      cursor: "grab",
      opacity: visible[id] ? 1 : 0.45,
      transition: "opacity 0.2s",
      userSelect: "none"
    }
  }, React.createElement("span", {
    style: {
      color: "var(--text3)",
      fontSize: 16,
      lineHeight: 1,
      flexShrink: 0
    }
  }, "\u283F"), React.createElement("span", {
    style: {
      flex: 1,
      fontSize: 14,
      fontWeight: 500,
      color: "var(--text)"
    }
  }, rowLabels[id] || id), React.createElement(Toggle, {
    value: visible[id],
    onChange: () => toggleVisible(id),
    title: visible[id] ? "Hide row" : "Show row"
  })))), React.createElement("div", {
    style: {
      marginTop: 16,
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, React.createElement("button", {
    className: "btn btn-primary",
    onClick: handleSave
  }, "Save Layout"), saved && React.createElement("span", {
    style: {
      fontSize: 13,
      color: "#48c774"
    }
  }, "\u2713 Saved")));
}
const FREQUENCY_OPTIONS = [{
  value: "startup",
  label: "On App Start"
}, {
  value: "daily",
  label: "Daily"
}, {
  value: "weekly",
  label: "Weekly"
}, {
  value: "monthly",
  label: "Monthly"
}];
function ScheduledBackupSection() {
  const [enabled, setEnabled] = useState(false);
  const [backupPath, setBackupPath] = useState("");
  const [keepCount, setKeepCount] = useState(5);
  const [frequency, setFrequency] = useState("startup");
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    if (!isElectron) {
      setLoading(false);
      return;
    }
    window.electron.getScheduledBackupSettings().then(s => {
      if (s) {
        setEnabled(!!s.enabled);
        setBackupPath(s.path || "");
        setKeepCount(s.keepCount ?? 5);
        setFrequency(s.frequency || "startup");
      }
      setLoading(false);
    });
  }, []);
  const pickFolder = async () => {
    if (!isElectron) return;
    const folder = await window.electron.pickFolder();
    if (folder) setBackupPath(folder);
  };
  const handleSave = async () => {
    if (!isElectron) return;
    const settings = {
      enabled,
      path: backupPath,
      keepCount: Math.max(1, Math.min(99, Number(keepCount) || 5)),
      frequency,
      lastRun: null
    };
    const existing = await window.electron.getScheduledBackupSettings();
    if (existing?.lastRun) settings.lastRun = existing.lastRun;
    await window.electron.setScheduledBackupSettings(settings);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };
  if (!isElectron || loading) return null;
  return React.createElement("div", {
    style: {
      marginTop: 28,
      padding: "20px 22px",
      background: "var(--surface2)",
      border: "1px solid var(--border)",
      borderRadius: 10
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      marginBottom: enabled ? 20 : 0
    }
  }, React.createElement(Toggle, {
    value: enabled,
    onChange: setEnabled
  }), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 600,
      color: "var(--text)"
    }
  }, "Scheduled Backups"), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 2
    }
  }, "Automatically save a backup file on a schedule"))), enabled && React.createElement(React.Fragment, null, React.createElement("div", {
    style: {
      marginBottom: 14
    }
  }, React.createElement("div", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      color: "var(--text2)",
      marginBottom: 6
    }
  }, "Backup Folder"), React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      alignItems: "center"
    }
  }, React.createElement("input", {
    className: "apikey-input",
    style: {
      flex: 1,
      marginBottom: 0
    },
    placeholder: "/home/you/Backups",
    value: backupPath,
    onChange: e => setBackupPath(e.target.value)
  }), React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "7px 14px",
      fontSize: 13
    },
    onClick: pickFolder
  }, "Browse\u2026"))), React.createElement("div", {
    style: {
      display: "flex",
      gap: 16,
      flexWrap: "wrap",
      marginBottom: 16
    }
  }, React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 160
    }
  }, React.createElement("div", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      color: "var(--text2)",
      marginBottom: 6
    }
  }, "Frequency"), React.createElement(SettingsSelect, {
    value: frequency,
    onChange: v => setFrequency(v),
    options: FREQUENCY_OPTIONS,
    style: {
      width: "100%"
    }
  })), React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 120
    }
  }, React.createElement("div", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      color: "var(--text2)",
      marginBottom: 6
    }
  }, "Keep Last N Backups"), React.createElement("input", {
    type: "number",
    min: 1,
    max: 99,
    className: "apikey-input",
    style: {
      width: "100%",
      marginBottom: 0
    },
    value: keepCount,
    onChange: e => setKeepCount(e.target.value)
  }))), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, React.createElement("button", {
    className: "btn btn-primary",
    onClick: handleSave
  }, "Save"), saved && React.createElement("span", {
    style: {
      fontSize: 13,
      color: "#48c774"
    }
  }, "\u2713 Saved"))), !enabled && React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "flex-end",
      marginTop: 0
    }
  }));
}
function BackupRestoreSection({
  onRestored
}) {
  const [restoreStatus, setRestoreStatus] = useState(null);
  const handleExport = () => {
    const backup = {
      version: 1,
      exportedAt: new Date().toISOString(),
      data: collectBackupData()
    };
    const blob = new Blob([JSON.stringify(backup, null, 2)], {
      type: "application/json"
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `streambert-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    try { navigator.clipboard?.writeText(JSON.stringify(backup)); } catch {}
    setRestoreStatus("✓ Backup exported");
    setTimeout(() => setRestoreStatus(null), 3000);
  };
  const handleImport = e => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      try {
        const backup = JSON.parse(ev.target.result);
        if (!backup?.data) throw new Error("Invalid backup file, missing data field.");
        restoreBackupData(backup.data);
        setRestoreStatus("✓ Backup restored: reloading…");
        setTimeout(() => window.location.reload(), 1200);
        onRestored?.();
      } catch (err) {
        setRestoreStatus("✕ " + (err.message || "Could not read backup file."));
        setTimeout(() => setRestoreStatus(null), 4000);
      }
    };
    reader.readAsText(file);
    e.target.value = "";
  };
  return React.createElement("div", {
    style: {
      marginBottom: 40
    }
  }, React.createElement("div", {
    className: "settings-section-title"
  }, "Backup & Restore"), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      marginBottom: 20,
      lineHeight: 1.6
    }
  }, "Export your watchlist, watch history, progress, and all settings to a JSON file. Import it later to restore everything, useful before reinstalling or switching devices."), React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      flexWrap: "wrap",
      alignItems: "center"
    }
  }, React.createElement("button", {
    className: "btn btn-primary",
    onClick: handleExport
  }, "\u2B06 Export Backup"), React.createElement("label", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 8,
      padding: "9px 18px",
      background: "var(--surface2)",
      border: "1px solid var(--border)",
      borderRadius: 8,
      fontSize: 14,
      fontWeight: 600,
      color: "var(--text)",
      cursor: "pointer",
      transition: "background 0.15s"
    },
    onMouseEnter: e => e.currentTarget.style.background = "var(--surface)",
    onMouseLeave: e => e.currentTarget.style.background = "var(--surface2)"
  }, "\u2B07 Import Backup", React.createElement("input", {
    type: "file",
    accept: ".json,application/json",
    onChange: handleImport,
    style: {
      display: "none"
    }
  })), restoreStatus && React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 500,
      color: restoreStatus.startsWith("✕") ? "var(--red)" : "#48c774"
    }
  }, restoreStatus)), React.createElement(ScheduledBackupSection, null));
}
function AppearanceSection() {
  const [accent, setAccent] = useState(() => storage.get(STORAGE_KEYS.ACCENT_COLOR) || "red");
  const [fontSize, setFontSize] = useState(() => storage.get(STORAGE_KEYS.FONT_SIZE) || "normal");
  const [compact, setCompact] = useState(() => !!storage.get(STORAGE_KEYS.COMPACT_MODE));
  const [noAnim, setNoAnim] = useState(() => !!storage.get(STORAGE_KEYS.REDUCE_ANIMATIONS));
  const [gamepadEnabled, setGamepadEnabled] = useState(() => storage.get(STORAGE_KEYS.GAMEPAD_ENABLED) !== false);
  const [accentInPlayer, setAccentInPlayer] = useState(() => storage.get(STORAGE_KEYS.ACCENT_IN_PLAYER) !== false);
  const [theme, setTheme] = useState(() => storage.get(STORAGE_KEYS.THEME) || "dark");
  const [customVars, setCustomVars] = useState(() => storage.get(STORAGE_KEYS.CUSTOM_THEME_VARS) || {
    ...DEFAULT_CUSTOM_VARS
  });
  const [showCustomEditor, setShowCustomEditor] = useState(false);
  const [saved, setSaved] = useState(false);
  const committedRef = useRef({
    accent: storage.get(STORAGE_KEYS.ACCENT_COLOR) || "red",
    theme: storage.get(STORAGE_KEYS.THEME) || "dark",
    customVars: storage.get(STORAGE_KEYS.CUSTOM_THEME_VARS) || {
      ...DEFAULT_CUSTOM_VARS
    }
  });
  const savedRef = useRef(false);
  useEffect(() => {
    return () => {
      if (!savedRef.current) {
        const {
          accent,
          theme,
          customVars
        } = committedRef.current;
        applyAccentColor(accent);
        applyTheme(theme, theme === "custom" ? customVars : null);
      }
    };
  }, []);
  const handleThemeSelect = id => {
    setTheme(id);
    if (id !== "custom") {
      applyTheme(id);
    } else {
      applyTheme("custom", customVars);
      setShowCustomEditor(true);
    }
  };
  const handleCustomVarChange = (prop, value) => {
    const next = {
      ...customVars,
      [prop]: value
    };
    setCustomVars(next);
    applyTheme("custom", next);
  };
  const handleSave = () => {
    storage.set(STORAGE_KEYS.ACCENT_COLOR, accent);
    storage.set(STORAGE_KEYS.ACCENT_IN_PLAYER, accentInPlayer);
    storage.set(STORAGE_KEYS.FONT_SIZE, fontSize);
    storage.set(STORAGE_KEYS.COMPACT_MODE, compact ? 1 : 0);
    storage.set(STORAGE_KEYS.REDUCE_ANIMATIONS, noAnim ? 1 : 0);
    storage.set(STORAGE_KEYS.GAMEPAD_ENABLED, gamepadEnabled);
    window.dispatchEvent(new CustomEvent("streambert:gamepad-settings-changed"));
    storage.set(STORAGE_KEYS.THEME, theme);
    if (theme === "custom") {
      storage.set(STORAGE_KEYS.CUSTOM_THEME_VARS, customVars);
    }
    applyAccentColor(accent);
    applyTheme(theme, theme === "custom" ? customVars : null);
    const zoomMap = {
      sm: 0.85,
      normal: 1,
      lg: 1.15
    };
    const fz = zoomMap[fontSize] ?? 1;
    document.documentElement.style.zoom = String(fz);
    if (window.electron?.setZoomFactor) window.electron.setZoomFactor(fz);
    document.body.classList.toggle("compact-mode", compact);
    document.body.classList.toggle("no-anim", noAnim);
    savedRef.current = true;
    committedRef.current = {
      accent,
      theme,
      customVars
    };
    window.dispatchEvent(new CustomEvent("streambert:player-settings-changed"));
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };
  const CUSTOM_VAR_LABELS = {
    "--bg": "Background",
    "--surface": "Surface",
    "--surface2": "Surface 2",
    "--surface3": "Surface 3",
    "--border": "Border",
    "--text": "Text",
    "--text2": "Text 2",
    "--text3": "Text 3"
  };
  return React.createElement("div", {
    style: {
      marginBottom: 40
    }
  }, React.createElement("div", {
    className: "settings-section-title"
  }, "Appearance"), React.createElement("div", {
    style: {
      marginBottom: 24
    }
  }, React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: "var(--text2)",
      marginBottom: 10
    }
  }, "Theme"), React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      flexWrap: "wrap"
    }
  }, THEME_PRESETS.map(t => React.createElement("button", {
    key: t.id,
    onClick: () => handleThemeSelect(t.id),
    title: t.description,
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 6,
      padding: "10px 14px",
      borderRadius: "var(--radius)",
      background: theme === t.id ? "color-mix(in srgb, var(--red) 15%, var(--surface2))" : "var(--surface2)",
      border: theme === t.id ? "1.5px solid var(--red)" : "1.5px solid var(--border)",
      cursor: "pointer",
      transition: "border-color 0.15s, background 0.15s",
      minWidth: 70
    }
  }, React.createElement("div", {
    style: {
      width: 40,
      height: 28,
      borderRadius: 4,
      background: t.id === "custom" ? `linear-gradient(135deg, ${customVars["--bg"]} 50%, ${customVars["--surface2"]} 50%)` : t.vars ? `linear-gradient(135deg, ${t.vars["--bg"]} 50%, ${t.vars["--surface2"]} 50%)` : "var(--surface3)",
      border: "1px solid rgba(255,255,255,0.08)",
      flexShrink: 0
    }
  }), React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: theme === t.id ? 600 : 400,
      color: theme === t.id ? "var(--text)" : "var(--text2)",
      whiteSpace: "nowrap"
    }
  }, t.label)))), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 8
    }
  }, THEME_PRESETS.find(t => t.id === theme)?.description)), theme === "custom" && React.createElement("div", {
    style: {
      marginBottom: 24
    }
  }, React.createElement("button", {
    onClick: () => setShowCustomEditor(v => !v),
    className: "btn btn-ghost",
    style: {
      fontSize: 12,
      padding: "5px 12px",
      marginBottom: 12
    }
  }, showCustomEditor ? "▲ Hide" : "▼ Edit", " custom colours"), showCustomEditor && React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fill, minmax(180px, 1fr))",
      gap: 12,
      padding: 16,
      background: "var(--surface2)",
      borderRadius: "var(--radius)",
      border: "1px solid var(--border)"
    }
  }, Object.entries(CUSTOM_VAR_LABELS).map(([prop, label]) => React.createElement("div", {
    key: prop,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, React.createElement("input", {
    type: "color",
    value: customVars[prop] || "#000000",
    onChange: e => handleCustomVarChange(prop, e.target.value),
    style: {
      width: 32,
      height: 32,
      borderRadius: 4,
      border: "1px solid var(--border)",
      cursor: "pointer",
      background: "none",
      padding: 2,
      flexShrink: 0
    }
  }), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text)",
      fontWeight: 500
    }
  }, label), React.createElement("div", {
    style: {
      fontSize: 11,
      color: "var(--text3)",
      fontFamily: "monospace"
    }
  }, customVars[prop])))), React.createElement("div", {
    style: {
      gridColumn: "1 / -1",
      display: "flex",
      gap: 8,
      marginTop: 4
    }
  }, React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      fontSize: 12,
      padding: "5px 12px"
    },
    onClick: () => {
      setCustomVars({
        ...DEFAULT_CUSTOM_VARS
      });
      applyTheme("custom", DEFAULT_CUSTOM_VARS);
    }
  }, "Reset to defaults")))), React.createElement("div", {
    style: {
      marginBottom: 24
    }
  }, React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: "var(--text2)",
      marginBottom: 10
    }
  }, "Accent Colour"), React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      flexWrap: "wrap"
    }
  }, ACCENT_PRESETS.map(p => React.createElement("button", {
    key: p.id,
    onClick: () => {
      setAccent(p.id);
      applyAccentColor(p.id);
    },
    title: p.label,
    style: {
      width: 32,
      height: 32,
      borderRadius: "50%",
      background: p.color,
      border: accent === p.id ? `3px solid var(--text)` : "3px solid transparent",
      outline: accent === p.id ? `2px solid ${p.color}` : "none",
      outlineOffset: 2,
      cursor: "pointer",
      transition: "transform 0.15s",
      transform: accent === p.id ? "scale(1.15)" : "scale(1)",
      flexShrink: 0
    }
  }))), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 8
    }
  }, ACCENT_PRESETS.find(p => p.id === accent)?.label, ", applied to buttons, highlights, and indicators."), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      marginTop: 14
    }
  }, React.createElement(Toggle, {
    value: accentInPlayer,
    onChange: setAccentInPlayer
  }), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: "var(--text)"
    }
  }, "Apply accent colour to streaming player"), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 2
    }
  }, "Passes the selected accent colour to the player source (Videasy, Vidking). VidSrc does not support colour theming.")))), React.createElement("div", {
    style: {
      marginBottom: 24
    }
  }, React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: "var(--text2)",
      marginBottom: 10
    }
  }, "Font Size"), React.createElement("div", {
    style: {
      display: "flex",
      gap: 8
    }
  }, [{
    id: "sm",
    label: "Small"
  }, {
    id: "normal",
    label: "Normal"
  }, {
    id: "lg",
    label: "Large"
  }].map(o => React.createElement("button", {
    key: o.id,
    onClick: () => setFontSize(o.id),
    className: fontSize === o.id ? "btn btn-primary" : "btn btn-ghost",
    style: {
      padding: "7px 18px",
      fontSize: o.id === "sm" ? 12 : o.id === "lg" ? 16 : 14
    }
  }, o.label)))), React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16,
      marginBottom: 24
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, React.createElement(Toggle, {
    value: compact,
    onChange: setCompact
  }), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: "var(--text)"
    }
  }, "Compact card grid"), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 2
    }
  }, "Shows more titles per row by reducing card size."))), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, React.createElement(Toggle, {
    value: noAnim,
    onChange: setNoAnim
  }), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: "var(--text)"
    }
  }, "Reduce animations"), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 2
    }
  }, "Disables transitions and hover effects throughout the app."))), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, React.createElement(Toggle, {
    value: localStorage.getItem("streambert_forceTvMode") === "1",
    onChange: v => {
      localStorage.setItem("streambert_forceTvMode", v ? "1" : "0");
      window.dispatchEvent(new CustomEvent("streambert:tv-mode-changed"));
    }
  }), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: "var(--text)"
    }
  }, "Android TV / 10-Foot UI Mode"), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 2
    }
  }, "Optimizes typography, poster sizes, overscan margins, and D-Pad focus rings for large TV screens."))), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, React.createElement(Toggle, {
    value: gamepadEnabled,
    onChange: setGamepadEnabled
  }), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: "var(--text)"
    }
  }, "Controller support"), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 2
    }
  }, "Navigate menus with a D-pad/stick and use A/B to select and go back. In the player: A play/pause, D-pad seek/volume, LB/RB skip \xB115s, Y fullscreen, B exit.")))), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, React.createElement("button", {
    className: "btn btn-primary",
    onClick: handleSave
  }, "Save"), saved && React.createElement("span", {
    style: {
      fontSize: 13,
      color: "#48c774"
    }
  }, "\u2713 Saved")));
}
function LibraryPrivacySection() {
  const [sort, setSort] = useState(() => storage.get(STORAGE_KEYS.LIBRARY_SORT) || "manual");
  const [historyEnabled, setHistoryEnabled] = useState(() => {
    const v = storage.get(STORAGE_KEYS.HISTORY_ENABLED);
    return v === 0 || v === false ? false : true;
  });
  const [saved, setSaved] = useState(false);
  const handleSave = () => {
    storage.set(STORAGE_KEYS.LIBRARY_SORT, sort);
    storage.set(STORAGE_KEYS.HISTORY_ENABLED, historyEnabled ? 1 : 0);
    window.dispatchEvent(new CustomEvent("streambert:library-sort-changed", {
      detail: sort
    }));
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };
  const SORT_OPTIONS = [{
    value: "manual",
    label: "Custom order"
  }, {
    value: "title",
    label: "Title A-Z"
  }, {
    value: "rating",
    label: "Top rated"
  }, {
    value: "year",
    label: "Newest first"
  }];
  return React.createElement("div", {
    style: {
      marginBottom: 40
    }
  }, React.createElement("div", {
    className: "settings-section-title"
  }, "Library & Privacy"), React.createElement("div", {
    style: {
      marginBottom: 24
    }
  }, React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: "var(--text2)",
      marginBottom: 8
    }
  }, "Watchlist sort order"), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      marginBottom: 12,
      lineHeight: 1.6
    }
  }, "How titles in your watchlist are sorted. \"Custom order\" keeps your drag-and-drop arrangement."), React.createElement(SettingsSelect, {
    value: sort,
    onChange: v => setSort(v),
    options: SORT_OPTIONS
  })), React.createElement("div", {
    style: {
      marginBottom: 24
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, React.createElement(Toggle, {
    value: historyEnabled,
    onChange: setHistoryEnabled
  }), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: "var(--text)"
    }
  }, "Record watch history"), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 2
    }
  }, "When off, nothing you watch will be added to history or \"Continue Watching\"."))), !historyEnabled && React.createElement("div", {
    style: {
      marginTop: 12,
      fontSize: 13,
      color: "var(--red)",
      background: "rgba(229,9,20,0.08)",
      border: "1px solid rgba(229,9,20,0.2)",
      borderRadius: 8,
      padding: "10px 14px"
    }
  }, "\u26A0 Watch history is disabled. Progress tracking and \"Continue Watching\" will not work.")), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, React.createElement("button", {
    className: "btn btn-primary",
    onClick: handleSave
  }, "Save"), saved && React.createElement("span", {
    style: {
      fontSize: 13,
      color: "#48c774"
    }
  }, "\u2713 Saved")));
}
function StartPageSection() {
  const [startPage, setStartPage] = useState(() => storage.get(STORAGE_KEYS.START_PAGE) || "home");
  const [saved, setSaved] = useState(false);
  const handleSave = () => {
    storage.set(STORAGE_KEYS.START_PAGE, startPage);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };
  return React.createElement("div", {
    style: {
      marginBottom: 40
    }
  }, React.createElement("div", {
    className: "settings-section-title"
  }, "Start Page"), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      marginBottom: 16,
      lineHeight: 1.6
    }
  }, "Choose which page opens when you launch SingularityTV."), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      flexWrap: "wrap"
    }
  }, React.createElement(SettingsSelect, {
    value: startPage,
    onChange: v => setStartPage(v),
    options: [{
      value: "home",
      label: "Home"
    }, {
      value: "history",
      label: "Library / History"
    }, {
      value: "downloads",
      label: "⬇  Downloads"
    }]
  }), React.createElement("button", {
    className: "btn btn-primary",
    onClick: handleSave
  }, "Save"), saved && React.createElement("span", {
    style: {
      fontSize: 13,
      color: "#48c774"
    }
  }, "\u2713 Saved")));
}
const TMDB_LANGUAGES = [{
  value: "en-US",
  label: "English (en-US)"
}, {
  value: "de-DE",
  label: "Deutsch (de-DE)"
}, {
  value: "fr-FR",
  label: "Français (fr-FR)"
}, {
  value: "es-ES",
  label: "Español (es-ES)"
}, {
  value: "it-IT",
  label: "Italiano (it-IT)"
}, {
  value: "pt-BR",
  label: "Português (Brasil) (pt-BR)"
}, {
  value: "nl-NL",
  label: "Nederlands (nl-NL)"
}, {
  value: "pl-PL",
  label: "Polski (pl-PL)"
}, {
  value: "sv-SE",
  label: "Svenska (sv-SE)"
}, {
  value: "nb-NO",
  label: "Norsk (nb-NO)"
}, {
  value: "da-DK",
  label: "Dansk (da-DK)"
}, {
  value: "fi-FI",
  label: "Suomi (fi-FI)"
}, {
  value: "tr-TR",
  label: "Türkçe (tr-TR)"
}, {
  value: "ru-RU",
  label: "Русский (ru-RU)"
}, {
  value: "ja-JP",
  label: "日本語 (ja-JP)"
}, {
  value: "ko-KR",
  label: "한국어 (ko-KR)"
}, {
  value: "zh-CN",
  label: "中文 (简体) (zh-CN)"
}, {
  value: "ar-SA",
  label: "العربية (ar-SA)"
}];
function TmdbLanguageSection() {
  const [lang, setLang] = useState(() => storage.get(STORAGE_KEYS.TMDB_LANG) || "en-US");
  const [saved, setSaved] = useState(false);
  const handleSave = () => {
    storage.set(STORAGE_KEYS.TMDB_LANG, lang);
    clearTmdbCache();
    window.dispatchEvent(new CustomEvent("streambert:tmdb-lang-changed"));
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };
  return React.createElement("div", {
    style: {
      marginBottom: 40
    }
  }, React.createElement("div", {
    className: "settings-section-title"
  }, "Metadata Language"), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      marginBottom: 16,
      lineHeight: 1.6
    }
  }, "Language used when fetching titles, descriptions, and metadata from keyless providers (Cinemeta, TVMaze, AniList). Changing this clears the metadata cache so updated content loads immediately."), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      flexWrap: "wrap"
    }
  }, React.createElement(SettingsSelect, {
    value: lang,
    onChange: v => setLang(v),
    options: TMDB_LANGUAGES
  }), React.createElement("button", {
    className: "btn btn-primary",
    onClick: handleSave
  }, "Save"), saved && React.createElement("span", {
    style: {
      fontSize: 13,
      color: "#48c774"
    }
  }, "\u2713 Saved, cache cleared")));
}
function SubtitleSettingsSection() {
  const [enabled, setEnabled] = useState(() => storage.get(STORAGE_KEYS.SUBTITLE_ENABLED) !== 0 && storage.get(STORAGE_KEYS.SUBTITLE_ENABLED) !== "0");
  const [lang, setLang] = useState(() => storage.get(STORAGE_KEYS.SUBTITLE_LANG) || "en");
  const [subColor, setSubColor] = useState(() => storage.get("subtitleTextColor") || "#FFFFFF");
  const [subBg, setSubBg] = useState(() => storage.get("subtitleBgStyle") || "dark");
  const [subSize, setSubSize] = useState(() => String(storage.get("subtitleFontSizeSp") || "22"));
  const [subdlApiKey, setSubdlApiKey] = useState("");
  const [showSubdlKey, setShowSubdlKey] = useState(false);
  const [wyzieApiKey, setWyzieApiKey] = useState("");
  const [showWyzieKey, setShowWyzieKey] = useState(false);
  const [wyzieCopied, setWyzieCopied] = useState(false);
  const [wyzieClearConfirm, setWyzieClearConfirm] = useState(false);
  const [saved, setSaved] = useState(false);
  useEffect(() => {
    secureStorage.get(STORAGE_KEYS.SUBDL_API_KEY).then(val => {
      if (val) setSubdlApiKey(val);
    });
    secureStorage.get(STORAGE_KEYS.WYZIE_API_KEY).then(val => {
      if (val) setWyzieApiKey(val);
    });
  }, []);
  const hasSubdlKey = subdlApiKey.trim().length > 0;
  const hasWyzieKey = wyzieApiKey.trim().length > 0;
  const handleWyzieCopy = () => {
    navigator.clipboard.writeText(wyzieApiKey.trim()).then(() => {
      setWyzieCopied(true);
      setTimeout(() => setWyzieCopied(false), 1500);
    });
  };
  const handleSave = () => {
    storage.set(STORAGE_KEYS.SUBTITLE_ENABLED, enabled ? 1 : 0);
    storage.set(STORAGE_KEYS.SUBTITLE_LANG, lang);
    storage.set("subtitleTextColor", subColor);
    storage.set("subtitleBgStyle", subBg);
    storage.set("subtitleFontSizeSp", Number(subSize));
    secureStorage.set(STORAGE_KEYS.SUBDL_API_KEY, subdlApiKey.trim());
    secureStorage.set(STORAGE_KEYS.WYZIE_API_KEY, wyzieApiKey.trim());
    window.dispatchEvent(new CustomEvent("streambert:player-settings-changed"));
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };
  return React.createElement("div", {
    style: {
      marginBottom: 40
    }
  }, React.createElement("div", {
    className: "settings-section-title"
  }, "Subtitle Downloads"), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      marginBottom: 20,
      lineHeight: 1.7
    }
  }, React.createElement("span", {
    style: {
      color: "var(--text)",
      fontWeight: 600
    }
  }, "Wyzie Subs"), " ", "is used by default and requires a free API key (no account needed). Optionally add a", " ", React.createElement("span", {
    style: {
      color: "var(--red)",
      cursor: "pointer",
      textDecoration: "underline"
    },
    onClick: () => window.electron?.openExternal("https://subdl.com/settings")
  }, "SubDL API key"), " ", "(free), to use SubDL as the primary source instead.", hasSubdlKey && React.createElement("span", {
    style: {
      display: "inline-block",
      marginLeft: 8,
      fontSize: 11,
      fontWeight: 700,
      padding: "1px 7px",
      borderRadius: 3,
      background: "rgba(229,9,20,0.15)",
      color: "#ff4d57",
      border: "1px solid rgba(229,9,20,0.35)"
    }
  }, "SubDL ACTIVE")), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      marginBottom: 20
    }
  }, React.createElement(Toggle, {
    value: enabled,
    onChange: setEnabled
  }), React.createElement("span", {
    style: {
      fontSize: 14,
      color: enabled ? "var(--text)" : "var(--text3)"
    }
  }, enabled ? "Auto-download subtitles when downloading videos" : "Subtitle download disabled")), enabled && React.createElement(React.Fragment, null, React.createElement("div", {
    style: {
      marginBottom: 16
    }
  }, React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginBottom: 6
    }
  }, "Default language"), React.createElement(SettingsSelect, {
    value: lang,
    onChange: v => setLang(v),
    options: SUBTITLE_LANGUAGES.map(l => ({
      value: l.code,
      label: l.label
    }))
  })), React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))",
      gap: 12,
      marginBottom: 16
    }
  }, React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginBottom: 6
    }
  }, "Subtitle Color"), React.createElement(SettingsSelect, {
    value: subColor,
    onChange: v => {
      setSubColor(v);
      storage.set("subtitleTextColor", v);
    },
    options: [
      { value: "#FFFFFF", label: "White" },
      { value: "#FACC15", label: "Yellow" },
      { value: "#38BDF8", label: "Cyan" },
      { value: "#4ADE80", label: "Green" }
    ]
  })), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginBottom: 6
    }
  }, "Subtitle Background"), React.createElement(SettingsSelect, {
    value: subBg,
    onChange: v => {
      setSubBg(v);
      storage.set("subtitleBgStyle", v);
    },
    options: [
      { value: "dark", label: "Dark Box" },
      { value: "semi", label: "Semi-Transparent" },
      { value: "none", label: "None (Shadow Only)" }
    ]
  })), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginBottom: 6
    }
  }, "Subtitle Size"), React.createElement(SettingsSelect, {
    value: subSize,
    onChange: v => {
      setSubSize(v);
      storage.set("subtitleFontSizeSp", Number(v));
    },
    options: [
      { value: "16", label: "Small" },
      { value: "22", label: "Normal" },
      { value: "28", label: "Large" },
      { value: "34", label: "TV XL" }
    ]
  }))), React.createElement("div", {
    style: {
      marginBottom: 20
    }
  }, React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginBottom: 6
    }
  }, "Wyzie API key", " ", React.createElement("span", {
    style: {
      marginLeft: 8,
      fontSize: 10,
      fontWeight: 700,
      padding: "1px 5px",
      borderRadius: 3,
      background: hasWyzieKey ? "rgba(99,202,183,0.12)" : "rgba(255,180,80,0.12)",
      color: hasWyzieKey ? "#63cab7" : "#ffb450",
      border: `1px solid ${hasWyzieKey ? "rgba(99,202,183,0.25)" : "rgba(255,180,80,0.25)"}`
    }
  }, hasWyzieKey ? "SET" : "REQUIRED")), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginBottom: 8,
      lineHeight: 1.5
    }
  }, "Required for Wyzie Subs. Get a free key by following the tutorial.", " ", React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      display: "inline",
      padding: 0,
      fontSize: 12,
      color: "var(--red)",
      background: "none",
      border: "none",
      cursor: "pointer"
    },
    onClick: () => window.electron?.openExternal("https://t.me/ec1lz")
  }, "How to get a key \u2197")), React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      alignItems: "center",
      flexWrap: "wrap"
    }
  }, React.createElement("input", {
    className: "apikey-input",
    style: {
      flex: 1,
      maxWidth: 340,
      marginBottom: 0
    },
    type: showWyzieKey ? "text" : "password",
    placeholder: "wyzie-...",
    value: wyzieApiKey,
    onChange: e => setWyzieApiKey(e.target.value)
  }), React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "6px 12px",
      fontSize: 12
    },
    onClick: () => setShowWyzieKey(v => !v)
  }, showWyzieKey ? "Hide" : "Show"), hasWyzieKey && React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "6px 12px",
      fontSize: 12
    },
    onClick: handleWyzieCopy,
    title: "Copy key"
  }, wyzieCopied ? "Copied!" : "Copy"), hasWyzieKey && React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "6px 12px",
      fontSize: 12
    },
    onClick: () => window.electron?.openExternal(`https://store.wyzie.io/dashboard?key=${wyzieApiKey.trim()}`),
    title: "Open your wyzie dashboard"
  }, "Dashboard \u2197"))), React.createElement("div", {
    style: {
      marginBottom: 8
    }
  }, React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginBottom: 6
    }
  }, "SubDL API key", " ", React.createElement("span", {
    style: {
      color: "var(--text3)",
      cursor: "pointer",
      fontSize: 11
    },
    onClick: () => window.electron?.openExternal("https://subdl.com/settings")
  }, "(free, register at subdl.com \u2197)"), React.createElement("span", {
    style: {
      marginLeft: 8,
      fontSize: 10,
      fontWeight: 700,
      padding: "1px 5px",
      borderRadius: 3,
      background: "rgba(99,202,183,0.12)",
      color: "#63cab7",
      border: "1px solid rgba(99,202,183,0.25)"
    }
  }, "OPTIONAL")), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginBottom: 8,
      lineHeight: 1.5
    }
  }, "Leave empty to use", " ", React.createElement("strong", {
    style: {
      color: "var(--text)"
    }
  }, "Wyzie Subs"), " ", "(default, requires Wyzie API key above). Add a SubDL key to switch to SubDL as the primary source."), React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      alignItems: "center"
    }
  }, React.createElement("input", {
    className: "apikey-input",
    style: {
      flex: 1,
      maxWidth: 400,
      marginBottom: 0
    },
    type: showSubdlKey ? "text" : "password",
    placeholder: "SubDL API key, leave empty to use Wyzie",
    value: subdlApiKey,
    onChange: e => setSubdlApiKey(e.target.value)
  }), React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "6px 12px",
      fontSize: 12
    },
    onClick: () => setShowSubdlKey(v => !v)
  }, showSubdlKey ? "Hide" : "Show"), subdlApiKey.trim() && React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "6px 12px",
      fontSize: 12,
      color: "var(--text3)"
    },
    onClick: () => setSubdlApiKey(""),
    title: "Clear key (revert to Wyzie)"
  }, "Clear")))), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      marginTop: 8
    }
  }, React.createElement("button", {
    className: "btn btn-primary",
    onClick: handleSave
  }, "Save"), saved && React.createElement("span", {
    style: {
      fontSize: 13,
      color: "#4caf50"
    }
  }, "\u2713 Saved")));
}
function NotificationsSection() {
  const [notifyDownload, setNotifyDownload] = useState(() => storage.get(STORAGE_KEYS.NOTIFY_DOWNLOAD_COMPLETE) !== false);
  const [notifyEpisode, setNotifyEpisode] = useState(() => {
    const stored = storage.get(STORAGE_KEYS.NOTIFY_NEW_EPISODE);
    return stored === null || stored === undefined ? true : !!stored;
  });
  const [saved, setSaved] = useState(false);
  const saveSettings = () => {
    storage.set(STORAGE_KEYS.NOTIFY_DOWNLOAD_COMPLETE, notifyDownload);
    storage.set(STORAGE_KEYS.NOTIFY_NEW_EPISODE, notifyEpisode);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };
  const ToggleRow = ({
    label,
    description,
    value,
    onChange
  }) => React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      gap: 14,
      padding: "16px 0",
      borderBottom: "1px solid var(--border)"
    }
  }, React.createElement(Toggle, {
    value: value,
    onChange: onChange
  }), React.createElement("div", {
    style: {
      flex: 1
    }
  }, React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: "var(--text)"
    }
  }, label), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 3,
      lineHeight: 1.5
    }
  }, description)));
  return React.createElement("div", {
    style: {
      marginBottom: 40
    }
  }, React.createElement("div", {
    className: "settings-section-title"
  }, "Desktop Notifications"), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      marginBottom: 16,
      lineHeight: 1.6
    }
  }, "Control which events trigger a desktop notification."), React.createElement("div", {
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border)",
      borderRadius: 10,
      padding: "0 16px",
      marginBottom: 20
    }
  }, React.createElement(ToggleRow, {
    label: "Notify when a download completes",
    description: "Shows a desktop notification when an item finishes downloading.",
    value: notifyDownload,
    onChange: setNotifyDownload
  }), React.createElement(ToggleRow, {
    label: "Notify about new episodes on startup",
    description: "On startup, checks every TV series you have saved for newly released episodes and notifies you if any aired since the last check.",
    value: notifyEpisode,
    onChange: setNotifyEpisode
  })), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, React.createElement("button", {
    className: "btn btn-primary",
    onClick: saveSettings
  }, "Save"), saved && React.createElement("span", {
    style: {
      fontSize: 13,
      color: "#48c774"
    }
  }, "\u2713 Saved")));
}
function DiscordRpcSection() {
  const [enabled, setEnabledState] = useState(() => !!storage.get(STORAGE_KEYS.DISCORD_RPC_ENABLED));
  const [showCover, setShowCover] = useState(() => storage.get(STORAGE_KEYS.DISCORD_RPC_SHOW_COVER) !== false);
  const [showTimestamp, setShowTimestamp] = useState(() => storage.get(STORAGE_KEYS.DISCORD_RPC_SHOW_TIMESTAMP) !== false);
  const [showButton, setShowButton] = useState(() => storage.get(STORAGE_KEYS.DISCORD_RPC_SHOW_BUTTON) !== false);
  const [saved, setSaved] = useState(false);
  const saveSettings = () => {
    storage.set(STORAGE_KEYS.DISCORD_RPC_ENABLED, enabled);
    storage.set(STORAGE_KEYS.DISCORD_RPC_SHOW_COVER, showCover);
    storage.set(STORAGE_KEYS.DISCORD_RPC_SHOW_TIMESTAMP, showTimestamp);
    storage.set(STORAGE_KEYS.DISCORD_RPC_SHOW_BUTTON, showButton);
    window.dispatchEvent(new CustomEvent("streambert:discord-rpc-settings-changed"));
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };
  const ToggleRow = ({
    label,
    description,
    value,
    onChange,
    disabled
  }) => React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      gap: 14,
      padding: "16px 0",
      borderBottom: "1px solid var(--border)",
      opacity: disabled ? 0.45 : 1,
      pointerEvents: disabled ? "none" : "auto"
    }
  }, React.createElement(Toggle, {
    value: value,
    onChange: onChange
  }), React.createElement("div", {
    style: {
      flex: 1
    }
  }, React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: "var(--text)"
    }
  }, label), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 3,
      lineHeight: 1.5
    }
  }, description)));
  return React.createElement("div", {
    style: {
      marginBottom: 40
    }
  }, React.createElement("div", {
    className: "settings-section-title"
  }, "Discord Rich Presence"), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      marginBottom: 16,
      lineHeight: 1.6
    }
  }, "Shows what you're currently watching on your Discord profile (title + cover, or \"Idling\" when nothing is open). Off by default. Requires the Discord desktop client to be running."), React.createElement("div", {
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border)",
      borderRadius: 10,
      padding: "0 16px",
      marginBottom: 20
    }
  }, React.createElement(ToggleRow, {
    label: "Enable Discord Rich Presence",
    description: "Connects to your local Discord client and updates your status automatically.",
    value: enabled,
    onChange: setEnabledState
  }), React.createElement(ToggleRow, {
    label: "Show cover art",
    description: "Uses the movie/show poster as the large image. When off, only the SingularityTV icon is shown.",
    value: showCover,
    onChange: setShowCover,
    disabled: !enabled
  }), React.createElement(ToggleRow, {
    label: "Show elapsed time",
    description: "Displays how long you've been on the current title's page.",
    value: showTimestamp,
    onChange: setShowTimestamp,
    disabled: !enabled
  }), React.createElement(ToggleRow, {
    label: "Show Telegram @ec1lz button",
    description: "Adds a button linking to @ec1lz on Telegram.",
    value: showButton,
    onChange: setShowButton,
    disabled: !enabled
  })), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, React.createElement("button", {
    className: "btn btn-primary",
    onClick: saveSettings
  }, "Save"), saved && React.createElement("span", {
    style: {
      fontSize: 13,
      color: "#48c774"
    }
  }, "\u2713 Saved")));
}
function SectionGroupHeader({
  title,
  subtitle
}) {
  return React.createElement("div", {
    style: {
      marginBottom: 32,
      marginTop: 4
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 14,
      marginBottom: subtitle ? 6 : 0
    }
  }, React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 16,
      letterSpacing: 2,
      color: "var(--red)",
      textTransform: "uppercase",
      fontWeight: 700,
      whiteSpace: "nowrap"
    }
  }, title), React.createElement("div", {
    style: {
      flex: 1,
      height: 1,
      background: "rgba(229,9,20,0.18)"
    }
  })), subtitle && React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      lineHeight: 1.5
    }
  }, subtitle));
}
function Divider() {
  return React.createElement("div", {
    style: {
      height: 1,
      background: "var(--border)",
      marginBottom: 40
    }
  });
}
const SUPPORTS_HIGHLIGHT = typeof CSS !== "undefined" && typeof CSS.highlights !== "undefined";
const SECTION_NAV = [{
  id: "updates",
  label: "Updates & API",
  icon: "↑",
  keywords: ["update", "version", "metadata", "api", "token", "key", "check", "startup", "auto", "app", "language", "metadata", "locale", "german", "french", "spanish"]
}, {
  id: "content",
  label: "Age Rating",
  icon: "🔞",
  keywords: ["age", "rating", "parental", "content", "country", "restriction", "pg", "fsk", "adults"]
}, {
  id: "subtitles",
  label: "Subtitles",
  icon: "CC",
  keywords: ["subtitle", "subdl", "wyzie", "language", "caption", "srt", "download", "cc"]
}, {
  id: "downloads",
  label: "Downloads",
  icon: "⬇",
  keywords: ["download", "folder", "path", "save", "video", "movies", "files"]
}, {
  id: "notifications",
  label: "Notifications",
  icon: "🔔",
  keywords: ["notification", "notify", "alert", "desktop", "episode", "download", "watchlist", "new episode", "release"]
}, {
  id: "interface",
  label: "Interface",
  icon: "✦",
  keywords: ["home", "layout", "start page", "appearance", "accent", "colour", "color", "font", "compact", "animation", "theme", "rows", "hero"]
}, {
  id: "library",
  label: "Library",
  icon: "📚",
  keywords: ["library", "watchlist", "sort", "history", "privacy", "watch history", "continue"]
}, {
  id: "backup",
  label: "Backup",
  icon: "💾",
  keywords: ["backup", "restore", "export", "import", "scheduled", "json", "backup file"]
}, {
  id: "storage",
  label: "Storage & Data",
  icon: "🗄",
  keywords: ["storage", "cache", "clear", "reset", "delete", "data", "wipe", "progress", "factory"]
}];
function SettingsTopBar({
  sectionRefs,
  contentRef
}) {
  const [searchOpen, setSearchOpen] = useState(false);
  const [navOpen, setNavOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [matchCount, setMatchCount] = useState(0);
  const [currentMatch, setCurrentMatch] = useState(0);
  const matchRanges = useRef([]);
  const currentMatchRef = useRef(0);
  const matchCountRef = useRef(0);
  const inputRef = useRef(null);
  const navRef = useRef(null);
  const searchBarRef = useRef(null);
  const debounceTimer = useRef(null);
  const rafHandle = useRef(null);
  const clearHighlights = () => {
    if (SUPPORTS_HIGHLIGHT) {
      CSS.highlights.delete("settings-search");
      CSS.highlights.delete("settings-search-active");
    }
    matchRanges.current = [];
    matchCountRef.current = 0;
    currentMatchRef.current = 0;
    setMatchCount(0);
    setCurrentMatch(0);
  };
  const scrollToRange = range => {
    if (!range) return;
    if (rafHandle.current) cancelAnimationFrame(rafHandle.current);
    rafHandle.current = requestAnimationFrame(() => {
      rafHandle.current = null;
      try {
        const el = range.startContainer.parentElement;
        if (el) el.scrollIntoView({
          behavior: "smooth",
          block: "center"
        });
      } catch (_) {}
    });
  };
  const setActiveMatch = idx => {
    const range = matchRanges.current[idx];
    if (!range) return;
    if (SUPPORTS_HIGHLIGHT) {
      CSS.highlights.set("settings-search-active", new Highlight(range));
    }
    scrollToRange(range);
    currentMatchRef.current = idx + 1;
    setCurrentMatch(idx + 1);
  };
  const runSearch = searchQuery => {
    clearHighlights();
    if (!contentRef?.current || !searchQuery.trim()) return;
    const str = searchQuery.toLowerCase();
    const ranges = [];
    const walker = document.createTreeWalker(contentRef.current, NodeFilter.SHOW_TEXT);
    let node;
    while (node = walker.nextNode()) {
      const text = node.textContent.toLowerCase();
      let idx = 0;
      while ((idx = text.indexOf(str, idx)) !== -1) {
        const range = new Range();
        range.setStart(node, idx);
        range.setEnd(node, idx + searchQuery.length);
        ranges.push(range);
        idx += str.length;
      }
    }
    matchRanges.current = ranges;
    matchCountRef.current = ranges.length;
    setMatchCount(ranges.length);
    if (ranges.length > 0) {
      if (SUPPORTS_HIGHLIGHT) {
        const hl = new Highlight();
        for (const r of ranges) hl.add(r);
        CSS.highlights.set("settings-search", hl);
      }
      setActiveMatch(0);
    }
  };
  const findMatches = searchQuery => {
    if (debounceTimer.current) clearTimeout(debounceTimer.current);
    debounceTimer.current = setTimeout(() => {
      debounceTimer.current = null;
      runSearch(searchQuery);
    }, 80);
  };
  const goNext = () => {
    const total = matchCountRef.current;
    if (total === 0) return;
    const next = currentMatchRef.current < total ? currentMatchRef.current : 0;
    setActiveMatch(next);
  };
  const goPrev = () => {
    const total = matchCountRef.current;
    if (total === 0) return;
    const prev = currentMatchRef.current > 1 ? currentMatchRef.current - 2 : total - 1;
    setActiveMatch(prev);
  };
  const closeSearch = () => {
    setSearchOpen(false);
    setQuery("");
    clearHighlights();
  };
  useEffect(() => {
    if (searchOpen) {
      setTimeout(() => {
        inputRef.current?.focus();
        inputRef.current?.select();
      }, 30);
    }
  }, [searchOpen]);
  useEffect(() => () => {
    clearHighlights();
    if (debounceTimer.current) clearTimeout(debounceTimer.current);
    if (rafHandle.current) cancelAnimationFrame(rafHandle.current);
  }, []);
  useEffect(() => {
    const handler = e => {
      if (e.key === "Escape") {
        closeSearch();
        setNavOpen(false);
        return;
      }
      if ((e.metaKey || e.ctrlKey) && (e.key === "k" || e.key === "f")) {
        e.preventDefault();
        setSearchOpen(true);
        return;
      }
      if (e.key === "F3") {
        e.preventDefault();
        if (e.shiftKey) goPrev();else goNext();
        return;
      }
      if (searchOpen && e.key === "Enter") {
        e.preventDefault();
        if (e.shiftKey) goPrev();else goNext();
      }
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [searchOpen]);
  useEffect(() => {
    if (!navOpen) return;
    const handler = e => {
      if (navRef.current && !navRef.current.contains(e.target)) setNavOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [navOpen]);
  useEffect(() => {
    if (!searchOpen) return;
    const handler = e => {
      if (searchBarRef.current && !searchBarRef.current.contains(e.target)) {
        clearHighlights();
        setSearchOpen(false);
        setQuery("");
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [searchOpen]);
  const scrollTo = id => {
    const el = sectionRefs[id]?.current;
    if (el) el.scrollIntoView({
      behavior: "smooth",
      block: "start"
    });
    setNavOpen(false);
  };
  const handleQueryChange = e => {
    const val = e.target.value;
    setQuery(val);
    findMatches(val);
  };
  const noMatch = query.trim().length > 0 && matchCount === 0;
  const hasQuery = query.trim().length > 0;
  const navBtnStyle = {
    background: "none",
    border: "none",
    cursor: "pointer",
    color: "var(--text2)",
    display: "flex",
    alignItems: "center",
    padding: "4px 5px",
    borderRadius: 5,
    transition: "background 0.1s",
    flexShrink: 0
  };
  return React.createElement("div", {
    style: {
      position: "sticky",
      top: 0,
      zIndex: 100,
      background: "var(--bg, #141414)",
      borderBottom: "1px solid var(--border)",
      padding: "0 48px",
      backdropFilter: "blur(12px)"
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      padding: "10px 0"
    }
  }, React.createElement("div", {
    style: {
      flex: 1,
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, searchOpen ? React.createElement("div", {
    ref: searchBarRef,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      flex: 1,
      maxWidth: 540,
      background: "var(--surface2)",
      border: `1px solid ${noMatch ? "#ff3860" : "var(--red)"}`,
      borderRadius: 8,
      padding: "5px 8px 5px 12px",
      boxShadow: `0 0 0 3px ${noMatch ? "rgba(255,56,96,0.1)" : "rgba(229,9,20,0.1)"}`,
      transition: "border-color 0.15s, box-shadow 0.15s"
    }
  }, React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "var(--text3)",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      flexShrink: 0
    }
  }, React.createElement("circle", {
    cx: "11",
    cy: "11",
    r: "8"
  }), React.createElement("line", {
    x1: "21",
    y1: "21",
    x2: "16.65",
    y2: "16.65"
  })), React.createElement("input", {
    ref: inputRef,
    value: query,
    onChange: handleQueryChange,
    placeholder: "Search on this page\u2026",
    style: {
      flex: 1,
      background: "transparent",
      border: "none",
      outline: "none",
      fontSize: 14,
      color: noMatch ? "#ff3860" : "var(--text)",
      fontFamily: "var(--font-body)",
      minWidth: 0
    }
  }), hasQuery && React.createElement("span", {
    style: {
      fontSize: 12,
      color: noMatch ? "#ff3860" : "var(--text3)",
      fontVariantNumeric: "tabular-nums",
      whiteSpace: "nowrap",
      padding: "0 8px",
      borderLeft: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      margin: "0 2px",
      flexShrink: 0
    }
  }, noMatch ? "No results" : `${currentMatch} / ${matchCount}`), matchCount > 0 && React.createElement("button", {
    onClick: goPrev,
    title: "Previous match (Shift+Enter)",
    style: navBtnStyle,
    onMouseEnter: e => e.currentTarget.style.background = "rgba(255,255,255,0.08)",
    onMouseLeave: e => e.currentTarget.style.background = "none"
  }, React.createElement("svg", {
    width: "13",
    height: "13",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, React.createElement("polyline", {
    points: "18 15 12 9 6 15"
  }))), matchCount > 0 && React.createElement("button", {
    onClick: goNext,
    title: "Next match (Enter)",
    style: navBtnStyle,
    onMouseEnter: e => e.currentTarget.style.background = "rgba(255,255,255,0.08)",
    onMouseLeave: e => e.currentTarget.style.background = "none"
  }, React.createElement("svg", {
    width: "13",
    height: "13",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, React.createElement("polyline", {
    points: "6 9 12 15 18 9"
  }))), query && React.createElement("button", {
    onClick: () => {
      setQuery("");
      clearHighlights();
      inputRef.current?.focus();
    },
    title: "Clear search",
    style: {
      ...navBtnStyle,
      color: "var(--text3)"
    },
    onMouseEnter: e => e.currentTarget.style.background = "rgba(255,255,255,0.08)",
    onMouseLeave: e => e.currentTarget.style.background = "none"
  }, React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.5",
    strokeLinecap: "round"
  }, React.createElement("line", {
    x1: "18",
    y1: "6",
    x2: "6",
    y2: "18"
  }), React.createElement("line", {
    x1: "6",
    y1: "6",
    x2: "18",
    y2: "18"
  }))), React.createElement("button", {
    onClick: closeSearch,
    title: "Close (Esc)",
    style: {
      background: "none",
      border: "none",
      cursor: "pointer",
      color: "var(--text3)",
      fontSize: 11,
      padding: "3px 7px",
      borderRadius: 4,
      fontFamily: "var(--font-body)",
      flexShrink: 0,
      letterSpacing: 0.3
    }
  }, "Esc")) : React.createElement("button", {
    onClick: () => setSearchOpen(true),
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      background: "var(--surface2)",
      border: "1px solid var(--border)",
      borderRadius: 8,
      padding: "6px 14px",
      fontSize: 13,
      color: "var(--text3)",
      cursor: "pointer",
      transition: "all 0.15s",
      fontFamily: "var(--font-body)"
    },
    onMouseEnter: e => e.currentTarget.style.background = "var(--surface3)",
    onMouseLeave: e => e.currentTarget.style.background = "var(--surface2)"
  }, React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, React.createElement("circle", {
    cx: "11",
    cy: "11",
    r: "8"
  }), React.createElement("line", {
    x1: "21",
    y1: "21",
    x2: "16.65",
    y2: "16.65"
  })), "Search settings\u2026", React.createElement("span", {
    style: {
      fontSize: 10,
      color: "var(--text3)",
      background: "var(--surface)",
      border: "1px solid var(--border)",
      borderRadius: 4,
      padding: "1px 6px",
      fontFamily: "monospace",
      letterSpacing: 0.5
    }
  }, "\u2318K"))), React.createElement("div", {
    ref: navRef,
    style: {
      position: "relative",
      flexShrink: 0
    }
  }, React.createElement("button", {
    onClick: () => setNavOpen(o => !o),
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      background: navOpen ? "var(--surface3)" : "var(--surface2)",
      border: `1px solid ${navOpen ? "var(--red)" : "var(--border)"}`,
      boxShadow: navOpen ? "0 0 0 3px rgba(229,9,20,0.1)" : "none",
      borderRadius: 8,
      padding: "6px 14px",
      fontSize: 13,
      color: "var(--text)",
      cursor: "pointer",
      transition: "all 0.15s",
      fontFamily: "var(--font-body)"
    }
  }, React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, React.createElement("line", {
    x1: "8",
    y1: "6",
    x2: "21",
    y2: "6"
  }), React.createElement("line", {
    x1: "8",
    y1: "12",
    x2: "21",
    y2: "12"
  }), React.createElement("line", {
    x1: "8",
    y1: "18",
    x2: "21",
    y2: "18"
  }), React.createElement("circle", {
    cx: "3",
    cy: "6",
    r: "1",
    fill: "currentColor"
  }), React.createElement("circle", {
    cx: "3",
    cy: "12",
    r: "1",
    fill: "currentColor"
  }), React.createElement("circle", {
    cx: "3",
    cy: "18",
    r: "1",
    fill: "currentColor"
  })), "Jump to Section", React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "var(--text3)",
    strokeWidth: "2.5",
    strokeLinecap: "round",
    style: {
      transform: navOpen ? "rotate(180deg)" : "rotate(0deg)",
      transition: "transform 0.2s",
      flexShrink: 0
    }
  }, React.createElement("polyline", {
    points: "6 9 12 15 18 9"
  }))), navOpen && React.createElement("div", {
    style: {
      position: "absolute",
      top: "calc(100% + 6px)",
      right: 0,
      zIndex: 200,
      background: "var(--surface3)",
      border: "1px solid var(--border)",
      borderRadius: 12,
      boxShadow: "0 20px 60px rgba(0,0,0,0.55)",
      minWidth: 230,
      padding: 6
    }
  }, SECTION_NAV.map(s => React.createElement("button", {
    key: s.id,
    onMouseDown: () => scrollTo(s.id),
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      width: "100%",
      textAlign: "left",
      background: "transparent",
      border: "none",
      borderRadius: 8,
      padding: "9px 12px",
      fontSize: 13,
      color: "var(--text)",
      cursor: "pointer",
      transition: "background 0.1s",
      fontFamily: "var(--font-body)"
    },
    onMouseEnter: e => e.currentTarget.style.background = "rgba(255,255,255,0.07)",
    onMouseLeave: e => e.currentTarget.style.background = "transparent"
  }, React.createElement("span", {
    style: {
      width: 22,
      textAlign: "center",
      fontSize: 13,
      flexShrink: 0
    }
  }, s.icon), React.createElement("span", {
    style: {
      flex: 1
    }
  }, s.label), React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "var(--text3)",
    strokeWidth: "2.5",
    strokeLinecap: "round"
  }, React.createElement("polyline", {
    points: "9 18 15 12 9 6"
  }))))))));
}
export default function SettingsPage({
  apiKey,
  onChangeApiKey,
  initialSection
}) {
  const [downloadPath, setDownloadPath] = useState(() => storage.get(STORAGE_KEYS.DOWNLOAD_PATH) || "");
  const [watchedThreshold, setWatchedThreshold] = useState(() => storage.get(STORAGE_KEYS.WATCHED_THRESHOLD) ?? 20);
  const [introSkipMode, setIntroSkipMode] = useState(() => storage.get(STORAGE_KEYS.INTRO_SKIP_MODE) || "off");
  const [autoplayNextEnabled, setAutoplayNextEnabled] = useState(() => storage.get(STORAGE_KEYS.AUTOPLAY_NEXT_ENABLED) ?? true);
  const [autoplayNextDuration, setAutoplayNextDuration] = useState(() => storage.get(STORAGE_KEYS.AUTOPLAY_NEXT_DURATION) ?? 5);
  const [autoplayNextLayout, setAutoplayNextLayout] = useState(() => storage.get(STORAGE_KEYS.AUTOPLAY_NEXT_LAYOUT) || "right");
  const [saved, setSaved] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);
  const [resetHovered, setResetHovered] = useState(false);
  const [showProgressConfirm, setShowProgressConfirm] = useState(false);
  const [showDeleteDlConfirm, setShowDeleteDlConfirm] = useState(false);
  const secUpdates = useRef(null);
  const secContent = useRef(null);
  const secPlayback = useRef(null);
  const secSubtitles = useRef(null);
  const secDownloads = useRef(null);
  const secNotifications = useRef(null);
  const secDiscordRpc = useRef(null);
  const secInterface = useRef(null);
  const secLibrary = useRef(null);
  const secBackup = useRef(null);
  const secStorage = useRef(null);
  const sectionRefs = {
    updates: secUpdates,
    content: secContent,
    playback: secPlayback,
    subtitles: secSubtitles,
    downloads: secDownloads,
    notifications: secNotifications,
    discordRpc: secDiscordRpc,
    interface: secInterface,
    library: secLibrary,
    backup: secBackup,
    storage: secStorage
  };
  const contentRef = useRef(null);
  useEffect(() => {
    if (!initialSection) return;
    const el = sectionRefs[initialSection]?.current;
    if (!el) return;
    const t = setTimeout(() => {
      el.scrollIntoView({
        behavior: "smooth",
        block: "start"
      });
    }, 120);
    return () => clearTimeout(t);
  }, []);
  const [ratingCountry, setRatingCountry] = useState(() => storage.get(STORAGE_KEYS.RATING_COUNTRY) || "US");
  const [ageLimit, setAgeLimit] = useState(() => {
    const v = storage.get(STORAGE_KEYS.AGE_LIMIT);
    return v === null || v === undefined ? "" : String(v);
  });
  const [ageSaved, setAgeSaved] = useState(false);
  const saveAgeSettings = () => {
    storage.set(STORAGE_KEYS.RATING_COUNTRY, ratingCountry);
    if (ageLimit === "" || ageLimit === null) {
      storage.remove(STORAGE_KEYS.AGE_LIMIT);
    } else {
      storage.set(STORAGE_KEYS.AGE_LIMIT, Number(ageLimit));
    }
    setAgeSaved(true);
    setTimeout(() => setAgeSaved(false), 2000);
  };
  const [invidiousBase, setInvidiousBase] = useState(() => storage.get(STORAGE_KEYS.INVIDIOUS_BASE) || DEFAULT_INVIDIOUS_BASE);
  const [invidiousStatus, setInvidiousStatus] = useState(null);
  const [invidiousChecking, setInvidiousChecking] = useState(false);
  const [invidiousSaved, setInvidiousSaved] = useState(false);
  const checkInvidious = async baseUrl => {
    const clean = (baseUrl || "").trim().replace(/\/$/, "");
    if (!clean) {
      setInvidiousStatus({
        ok: false,
        msg: "Please enter a URL first."
      });
      return;
    }
    setInvidiousChecking(true);
    setInvidiousStatus(null);
    try {
      const url = `${clean}/api/v1/stats`;
      const res = await fetch(url, {
        signal: AbortSignal.timeout(6000)
      });
      if (res.ok) {
        setInvidiousStatus({
          ok: true,
          msg: "Instance reachable and responding."
        });
      } else {
        setInvidiousStatus({
          ok: false,
          msg: `Server responded with status ${res.status}.`
        });
      }
    } catch (e) {
      setInvidiousStatus({
        ok: false,
        msg: "Could not reach instance. Check the URL or try another."
      });
    } finally {
      setInvidiousChecking(false);
    }
  };
  const saveInvidiousBase = () => {
    const clean = (invidiousBase || "").trim().replace(/\/$/, "");
    storage.set(STORAGE_KEYS.INVIDIOUS_BASE, clean || DEFAULT_INVIDIOUS_BASE);
    setInvidiousBase(clean || DEFAULT_INVIDIOUS_BASE);
    setInvidiousSaved(true);
    setTimeout(() => setInvidiousSaved(false), 2000);
  };
  const [sizes, setSizes] = useState({
    cache: null,
    downloads: null
  });
  useEffect(() => {
    if (typeof window === "undefined" || !window.electron) {
      setSizes({
        cache: -1,
        downloads: -1
      });
      return;
    }
    (async () => {
      try {
        const [cacheRes, downloadsRes] = await Promise.all([window.electron.getCacheSize?.() ?? null, window.electron.getDownloadsSize?.() ?? null]);
        setSizes({
          cache: cacheRes?.bytes ?? -1,
          downloads: downloadsRes?.bytes ?? -1
        });
      } catch {
        setSizes({
          cache: -1,
          downloads: -1
        });
      }
    })();
  }, []);
  const pickFolder = async () => {
    if (!isElectron) return;
    const folder = await window.electron.pickFolder();
    if (folder) {
      setDownloadPath(folder);
      storage.set(STORAGE_KEYS.DOWNLOAD_PATH, folder);
      flash();
    }
  };
  const handleSavePath = () => {
    storage.set(STORAGE_KEYS.DOWNLOAD_PATH, downloadPath);
    flash();
  };
  const handleSaveThreshold = () => {
    const val = Math.max(1, Math.min(300, Number(watchedThreshold) || 20));
    setWatchedThreshold(val);
    storage.set(STORAGE_KEYS.WATCHED_THRESHOLD, val);
    flash();
  };
  const flash = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };
  const handleClearCache = async () => {
    await clearAppCaches();
    setSizes(prev => ({
      ...prev,
      cache: 0
    }));
    return {
      msg: "✓ Cache cleared successfully"
    };
  };
  const handleClearWatchProgress = async () => {
    storage.remove(STORAGE_KEYS.WATCH_PROGRESS);
    storage.remove(STORAGE_KEYS.HISTORY);
    storage.remove(STORAGE_KEYS.WATCHED);
    if (isElectron) await window.electron.clearWatchData();
    setTimeout(() => window.location.reload(), 800);
    return {
      msg: "✓ Watch data cleared"
    };
  };
  const handleDeleteAllDownloads = async () => {
    let msg = "✓ All downloads removed";
    setSizes(prev => ({
      ...prev,
      downloads: 0
    }));
    if (isElectron) {
      const res = await window.electron.deleteAllDownloads();
      if (res?.deleted != null) {
        msg = `✓ Removed ${res.deleted} file${res.deleted !== 1 ? "s" : ""}`;
        if (res.errors > 0) msg += ` (${res.errors} could not be deleted)`;
      }
    } else {
      storage.remove(STORAGE_KEYS.LOCAL_FILES);
    }
    return {
      msg
    };
  };
  const handleResetApp = async () => {
    setShowResetConfirm(false);
    if (isElectron) await window.electron.resetApp();
    storage.clearAll();
    for (const key of Object.keys(localStorage)) {
      if (key.startsWith("dlDur_")) localStorage.removeItem(key);
    }
    window.location.reload();
  };
  return React.createElement(React.Fragment, null, showProgressConfirm && React.createElement(ConfirmDialog, {
    title: "CLEAR WATCH PROGRESS?",
    description: "This will permanently delete all watch history, continue-watching progress, and watched/completed markings for all movies and series.",
    confirmLabel: "Yes, Clear Everything",
    onConfirm: async () => {
      setShowProgressConfirm(false);
      await handleClearWatchProgress();
      window.__progressConfirmResolve?.({
        msg: "✓ Watch data cleared"
      });
      window.__progressConfirmResolve = null;
    },
    onCancel: () => {
      setShowProgressConfirm(false);
      window.__progressConfirmResolve?.({
        cancelled: true
      });
      window.__progressConfirmResolve = null;
    }
  }), showDeleteDlConfirm && React.createElement(ConfirmDialog, {
    title: "DELETE ALL DOWNLOADS?",
    description: "This will permanently delete all video files downloaded through SingularityTV and remove them from the download list.",
    confirmLabel: "Yes, Delete All",
    onConfirm: async () => {
      setShowDeleteDlConfirm(false);
      const result = await handleDeleteAllDownloads();
      window.__deleteDlConfirmResolve?.(result);
      window.__deleteDlConfirmResolve = null;
    },
    onCancel: () => {
      setShowDeleteDlConfirm(false);
      window.__deleteDlConfirmResolve?.({
        cancelled: true
      });
      window.__deleteDlConfirmResolve = null;
    }
  }), showResetConfirm && React.createElement(ResetConfirmDialog, {
    onConfirm: handleResetApp,
    onCancel: () => setShowResetConfirm(false)
  }), React.createElement(SettingsTopBar, {
    sectionRefs: sectionRefs,
    contentRef: contentRef
  }), React.createElement("div", {
    ref: contentRef,
    className: "fade-in",
    style: {
      padding: "40px 48px 80px"
    }
  }, React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 48,
      letterSpacing: 1,
      marginBottom: 6
    }
  }, "SETTINGS"), React.createElement("div", {
    style: {
      color: "var(--text3)",
      fontSize: 14,
      marginBottom: 48
    }
  }, "SingularityTV · Developed by @ec1lz (t.me/ec1lz)"), React.createElement("div", {
    ref: secUpdates,
    style: {
      scrollMarginTop: 80
    }
  }, React.createElement(SectionGroupHeader, {
    title: "Google Account & General",
    subtitle: "Google Account cloud sync, app version, updates, and metadata preferences"
  }), React.createElement(GoogleAccountSection, null), React.createElement(VersionSection, null)), React.createElement("div", {
    ref: secContent,
    style: {
      scrollMarginTop: 80
    }
  }, React.createElement(SectionGroupHeader, {
    title: "Content",
    subtitle: "Parental controls and content filtering by age rating"
  }), React.createElement("div", {
    style: {
      marginBottom: 40
    }
  }, React.createElement("div", {
    className: "settings-section-title"
  }, "Age Rating & Parental Controls"), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      marginBottom: 20,
      lineHeight: 1.6
    }
  }, "Set a maximum age rating. Content rated above this age will still be visible but", " ", React.createElement("strong", {
    style: {
      color: "var(--text)"
    }
  }, "you won't be able to play it."), " ", "Set to ", React.createElement("em", null, "No restriction"), " to disable this feature entirely."), React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: "var(--text2)",
      marginBottom: 8
    }
  }, "Rating Country"), React.createElement(SettingsSelect, {
    value: ratingCountry,
    onChange: v => setRatingCountry(v),
    options: RATING_COUNTRIES.map(c => ({
      value: c.code,
      label: c.label
    }))
  })), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: "var(--text2)",
      marginBottom: 8
    }
  }, "Maximum Allowed Age Rating"), React.createElement(SettingsSelect, {
    value: ageLimit,
    onChange: v => setAgeLimit(v),
    options: AGE_LIMIT_OPTIONS
  })), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, React.createElement("button", {
    className: "btn btn-primary",
    onClick: saveAgeSettings
  }, "Save"), ageSaved && React.createElement("span", {
    style: {
      fontSize: 13,
      color: "#48c774"
    }
  }, "\u2713 Saved"))))), React.createElement("div", {
    ref: secSubtitles,
    style: {
      scrollMarginTop: 80
    }
  }, React.createElement(SectionGroupHeader, {
    title: "Subtitles",
    subtitle: "Subtitle download source, preferred language, and API key"
  }), React.createElement(SubtitleSettingsSection, null)), React.createElement("div", {
    ref: secDownloads,
    style: {
      scrollMarginTop: 80
    }
  }, React.createElement(SectionGroupHeader, {
    title: "Downloads",
    subtitle: "Where downloaded video files are saved on disk"
  }), React.createElement("div", {
    style: {
      marginBottom: 40
    }
  }, React.createElement("div", {
    className: "settings-section-title"
  }, "Download Folder"), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      marginBottom: 16,
      lineHeight: 1.6
    }
  }, "Downloaded videos will be saved here. Make sure the folder exists and SingularityTV has write access to it."), React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      alignItems: "center",
      flexWrap: "wrap"
    }
  }, React.createElement("input", {
    className: "apikey-input",
    style: {
      flex: 1,
      minWidth: 260,
      marginBottom: 0
    },
    placeholder: "/home/you/Movies",
    value: downloadPath,
    onChange: e => setDownloadPath(e.target.value)
  }), isElectron && React.createElement("button", {
    className: "btn btn-secondary",
    onClick: pickFolder
  }, "Browse \u2026"), React.createElement("button", {
    className: "btn btn-primary",
    onClick: handleSavePath
  }, "Save")), saved && React.createElement("div", {
    style: {
      marginTop: 10,
      fontSize: 13,
      color: "#4caf50"
    }
  }, "\u2713 Saved"), !downloadPath && React.createElement("div", {
    style: {
      marginTop: 10,
      fontSize: 13,
      color: "var(--red)"
    }
  }, "\u26A0 No download folder set - videos cannot be downloaded until you set one."))), React.createElement("div", {
    ref: secNotifications,
    style: {
      scrollMarginTop: 80
    }
  }, React.createElement(SectionGroupHeader, {
    title: "Notifications",
    subtitle: "Desktop alerts for downloads and new episode releases"
  }), React.createElement(NotificationsSection, null)), React.createElement("div", {
    ref: secInterface,
    style: {
      scrollMarginTop: 80
    }
  }, React.createElement(SectionGroupHeader, {
    title: "Interface",
    subtitle: "Home layout, start page, appearance, and display options"
  }), React.createElement(HomeLayoutSection, null), React.createElement(Divider, null), React.createElement(StartPageSection, null), React.createElement(Divider, null), React.createElement(AppearanceSection, null)), React.createElement("div", {
    ref: secLibrary,
    style: {
      scrollMarginTop: 80
    }
  }, React.createElement(SectionGroupHeader, {
    title: "Library",
    subtitle: "Watchlist sort order and watch history preferences"
  }), React.createElement(LibraryPrivacySection, null)), React.createElement("div", {
    ref: secBackup,
    style: {
      scrollMarginTop: 80
    }
  }, React.createElement(SectionGroupHeader, {
    title: "Backup & Restore",
    subtitle: "Export your data or restore from a previous backup file"
  }), React.createElement(BackupRestoreSection, null)), React.createElement("div", {
    ref: secStorage,
    style: {
      scrollMarginTop: 80
    }
  }, React.createElement(SectionGroupHeader, {
    title: "Storage & Data",
    subtitle: "Clear cache, watch progress, downloads, or reset the entire app"
  }), React.createElement("div", {
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border)",
      borderRadius: 10,
      overflow: "hidden"
    }
  }, React.createElement("div", {
    style: {
      padding: "22px 24px"
    }
  }, React.createElement(CleanRow, {
    title: "Install Location",
    description: "Opens the folder where SingularityTV is installed.",
    buttonLabel: "Open Folder",
    onAction: async () => {
      const p = await window.electron?.getInstallPath?.();
      if (p) window.electron.openPath(p);
    }
  })), React.createElement("div", {
    style: {
      height: 1,
      background: "var(--border)"
    }
  }), React.createElement("div", {
    style: {
      padding: "22px 24px"
    }
  }, React.createElement(CleanRow, {
    title: "Clear Cache",
    description: "Removes temporary browser cache, shader cache, and service worker data from all internal sessions (main, video player, trailer). Does not affect your personal data or settings.",
    buttonLabel: "Clear Cache",
    onAction: handleClearCache,
    sizeLabel: formatBytes(sizes.cache)
  })), React.createElement("div", {
    style: {
      height: 1,
      background: "var(--border)"
    }
  }), React.createElement("div", {
    style: {
      padding: "22px 24px"
    }
  }, React.createElement(CleanRow, {
    title: "Clear Watch Progress",
    description: "Resets all watch history, continue-watching progress, and watched / completed markings for movies and series. Also clears internal video player session data.",
    buttonLabel: "Clear Progress",
    onAction: () => new Promise(resolve => {
      setShowProgressConfirm(true);
      window.__progressConfirmResolve = resolve;
    }),
    danger: true
  })), React.createElement("div", {
    style: {
      height: 1,
      background: "var(--border)"
    }
  }), React.createElement("div", {
    style: {
      padding: "22px 24px"
    }
  }, React.createElement(CleanRow, {
    title: "Delete All Downloads",
    description: "Permanently deletes all video files that were downloaded through SingularityTV and removes them from the download list. Only files downloaded through the app will be deleted, nothing else in your folder is touched.",
    buttonLabel: "Delete All",
    onAction: () => new Promise(resolve => {
      setShowDeleteDlConfirm(true);
      window.__deleteDlConfirmResolve = resolve;
    }),
    sizeLabel: formatBytes(sizes.downloads),
    danger: true
  })), React.createElement("div", {
    style: {
      height: 1,
      background: "var(--border)"
    }
  }), React.createElement("div", {
    style: {
      padding: "22px 24px",
      background: "rgba(229,9,20,0.03)"
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      justifyContent: "space-between",
      gap: 24
    }
  }, React.createElement("div", {
    style: {
      flex: 1
    }
  }, React.createElement("div", {
    style: {
      fontSize: 15,
      fontWeight: 600,
      color: "var(--text)",
      marginBottom: 4,
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, "Reset App", React.createElement("span", {
    style: {
      fontSize: 10,
      fontWeight: 700,
      letterSpacing: 1,
      color: "var(--red)",
      background: "rgba(229,9,20,0.12)",
      border: "1px solid rgba(229,9,20,0.25)",
      padding: "2px 7px",
      borderRadius: 4,
      textTransform: "uppercase"
    }
  }, "Irreversible")), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      lineHeight: 1.6
    }
  }, "Completely resets SingularityTV to factory defaults, clears all settings, API Token, saved library, watch history/progress, and all cached data. Your downloaded video files will not be touched.")), React.createElement("div", {
    style: {
      flexShrink: 0,
      paddingTop: 2
    }
  }, React.createElement("button", {
    className: "btn",
    onClick: () => setShowResetConfirm(true),
    onMouseEnter: () => setResetHovered(true),
    onMouseLeave: () => setResetHovered(false),
    style: {
      color: resetHovered ? "#fff" : "var(--red)",
      background: resetHovered ? "rgba(229,9,20,0.85)" : "rgba(229,9,20,0.08)",
      border: resetHovered ? "1px solid transparent" : "1px solid rgba(229,9,20,0.3)",
      transition: "all 0.2s"
    }
  }, "Reset App"))))))));
}
