import React, { useState, useEffect, useMemo, useCallback } from "react";
import MediaCard from "../components/MediaCard";
import HeroBanner from "../components/HeroBanner";
import { tmdbFetch } from "../utils/api";
import { WifiOffIcon } from "../components/Icons";
import { useRatings, getRatingForItem } from "../utils/useRatings";
import { isRestricted } from "../utils/ageRating";
import { loadHomeLayout, loadHomeViewMode } from "../utils/homeLayout";

function getRecentHistoryItems(history, count = 5) {
  if (!history || history.length === 0) return [];
  const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;
  const recent = history
    .filter(h => h.watchedAt && h.watchedAt > thirtyDaysAgo)
    .sort((a, b) => b.watchedAt - a.watchedAt);
  const seen = new Set();
  const unique = [];
  for (const item of recent) {
    const key = `${item.media_type || "movie"}_${item.id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    unique.push(item);
    if (unique.length >= count) break;
  }
  return unique;
}

export default function HomePage({
  trending,
  trendingTV,
  loading,
  onSelect,
  progress,
  inProgress,
  offline,
  onRetry,
  watched,
  onMarkWatched,
  onMarkUnwatched,
  history,
  apiKey
}) {
  const [recommendedItems, setRecommendedItems] = useState([]);
  const [topRatedItems, setTopRatedItems] = useState([]);
  const [layout, setLayout] = useState(() => loadHomeLayout());
  const [viewMode, setViewMode] = useState(() => loadHomeViewMode());
  useEffect(() => {
    const onLayout = () => setLayout(loadHomeLayout());
    const onView = () => setViewMode(loadHomeViewMode());
    window.addEventListener("streambert:home-layout-changed", onLayout);
    window.addEventListener("streambert:home-view-changed", onView);
    return () => {
      window.removeEventListener("streambert:home-layout-changed", onLayout);
      window.removeEventListener("streambert:home-view-changed", onView);
    };
  }, []);
  const { order: rowOrder, visible: rowVisible } = layout;

  const allItems = useMemo(
    () => [
      ...inProgress,
      ...trending.map(i => ({ ...i, media_type: "movie" })),
      ...trendingTV.map(i => ({ ...i, media_type: "tv" })),
      ...recommendedItems,
      ...topRatedItems
    ],
    [inProgress, trending, trendingTV, recommendedItems, topRatedItems]
  );

  const { ratingsMap, ageLimitSetting } = useRatings(allItems);
  const itemRestricted = useCallback(
    item => isRestricted(getRatingForItem(item, ratingsMap).minAge, ageLimitSetting),
    [ratingsMap, ageLimitSetting]
  );

  const enrichedRatingsMap = useMemo(() => {
    const out = {};
    for (const [k, v] of Object.entries(ratingsMap)) {
      out[k] = { ...v, restricted: isRestricted(v.minAge, ageLimitSetting) };
    }
    return out;
  }, [ratingsMap, ageLimitSetting]);

  const filteredRecommendedItems = useMemo(
    () => recommendedItems.filter(item => !itemRestricted(item)),
    [recommendedItems, itemRestricted]
  );

  useEffect(() => {
    if (!apiKey || offline || !history || history.length === 0) return;
    const sources = getRecentHistoryItems(history, 5);
    if (sources.length === 0) return;
    const controller = new AbortController();
    const watchedIds = new Set((history || []).map(h => `${h.media_type || "movie"}_${h.id}`));
    const fetches = sources.map(source => {
      const type = source.media_type === "tv" ? "tv" : "movie";
      return tmdbFetch(`/${type}/${source.id}/recommendations`, apiKey, { signal: controller.signal })
        .then(data => {
          const results = (data.results || []).map(i => ({ ...i, media_type: type }));
          if (results.length > 0) return results;
          return tmdbFetch(`/${type}/${source.id}/similar`, apiKey, { signal: controller.signal })
            .then(d => (d.results || []).map(i => ({ ...i, media_type: type })));
        })
        .catch(() => []);
    });
    Promise.all(fetches)
      .then(arrays => {
        const merged = [];
        const maxLen = Math.max(...arrays.map(a => a.length));
        for (let i = 0; i < maxLen; i++) {
          for (const arr of arrays) {
            if (arr[i]) merged.push(arr[i]);
          }
        }
        const seen = new Set();
        const deduped = merged.filter(item => {
          const key = `${item.media_type}_${item.id}`;
          if (seen.has(key) || watchedIds.has(key)) return false;
          seen.add(key);
          return true;
        });
        setRecommendedItems(deduped.slice(0, 20));
      })
      .catch(() => {});
    return () => controller.abort();
  }, [apiKey, offline, history?.length]);

  useEffect(() => {
    if (!apiKey || offline) return;
    const controller = new AbortController();
    Promise.all([
      tmdbFetch("/movie/top_rated?page=1", apiKey, { signal: controller.signal }),
      tmdbFetch("/tv/top_rated?page=1", apiKey, { signal: controller.signal })
    ])
      .then(([moviesData, tvData]) => {
        const movies = (moviesData.results || []).slice(0, 10).map(i => ({ ...i, media_type: "movie" }));
        const tv = (tvData.results || []).slice(0, 10).map(i => ({ ...i, media_type: "tv" }));
        const merged = [];
        const max = Math.max(movies.length, tv.length);
        for (let i = 0; i < max; i++) {
          if (movies[i]) merged.push(movies[i]);
          if (tv[i]) merged.push(tv[i]);
        }
        setTopRatedItems(merged);
      })
      .catch(() => {});
    return () => controller.abort();
  }, [apiKey, offline]);

  const trendingMovieItems = useMemo(
    () => trending.slice(0, 16).map(i => ({ ...i, media_type: "movie" })),
    [trending]
  );

  const trendingTVItems = useMemo(
    () => trendingTV.slice(0, 16).map(i => ({ ...i, media_type: "tv" })),
    [trendingTV]
  );

  const heroItems = useMemo(
    () => trendingMovieItems.slice(0, 5),
    [trendingMovieItems]
  );

  const renderRow = (key, title, items, variant = "landscape") => {
    if (!items || items.length === 0) return null;
    return (
      <section key={key} className="tv-row-section">
        <div className="tv-row-header">
          <h2 className="tv-row-title">{title}</h2>
        </div>
        <div className={viewMode === "list" ? "cards-grid tv-cards-grid" : "scroll-row tv-scroll-row"}>
          {items.map(item => {
            const type = item.media_type === "tv" ? "tv" : "movie";
            const rk = `${type}_${item.id}`;
            const rd = enrichedRatingsMap[rk] || {};
            const pk = item.media_type === "movie"
              ? `movie_${item.id}`
              : item.season != null && item.episode != null
                ? `tv_${item.id}_s${item.season}e${item.episode}`
                : null;
            return (
              <MediaCard
                key={`${type}_${item.id}_${item.season || ""}_${item.episode || ""}`}
                item={item}
                variant={variant}
                onClick={() => onSelect(item)}
                progress={pk ? progress[pk] || 0 : 0}
                watched={watched}
                onMarkWatched={onMarkWatched}
                onMarkUnwatched={onMarkUnwatched}
                ageRating={rd.cert}
                restricted={rd.restricted}
              />
            );
          })}
        </div>
      </section>
    );
  };

  const topPicksItems = filteredRecommendedItems.length > 0 ? filteredRecommendedItems : trendingMovieItems;

  return (
    <div className="tv-home fade-in">
      {offline && (
        <div className="tv-offline-state">
          <WifiOffIcon size={48} />
          <div style={{ fontSize: 20, fontWeight: 600, color: "var(--text)" }}>No internet connection</div>
          <div style={{ fontSize: 14, color: "var(--text3)" }}>
            Trending and search require an internet connection. Your downloads and library still work offline.
          </div>
          <button className="btn btn-primary" onClick={onRetry}>
            Retry
          </button>
        </div>
      )}

      {!offline && loading && (
        <div className="loader">
          <div className="spinner" />
        </div>
      )}

      {!offline && !loading && heroItems.length > 0 && (
        <HeroBanner items={heroItems} onSelect={onSelect} ratingsMap={enrichedRatingsMap} />
      )}

      <div className="tv-rows-container">
        {rowOrder.map(id => {
          if (!rowVisible[id]) return null;
          if (id === "continue") {
            return renderRow("continue", "Continue watching", inProgress, "landscape");
          }
          if (id === "recommended") {
            return renderRow("recommended", "Top picks for you", topPicksItems, "landscape");
          }
          if (id === "trendingTV") {
            return renderRow("trendingTV", "Trending TV Shows", trendingTVItems, "landscape");
          }
          if (id === "trendingMovies") {
            return renderRow("trendingMovies", "New movies and shows", trendingMovieItems, "poster");
          }
          if (id === "topRated") {
            return renderRow("topRated", "Top Rated", topRatedItems, "poster");
          }
          return null;
        })}
      </div>
    </div>
  );
}
