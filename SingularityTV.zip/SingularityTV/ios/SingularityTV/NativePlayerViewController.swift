import UIKit
import AVFoundation
import AVKit
import MediaPlayer
import WebKit

private struct IosSubCue {
    let startSec: Double
    let endSec: Double
    let text: String
}

private struct IosSubTrack {
    let lang: String
    let url: String
    let score: Int
    let syncMatch: Bool
}

class NativePlayerViewController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate, AVPictureInPictureControllerDelegate {
    private let payloadJson: String
    var onProgressUpdate: ((String, Int, Int, Int, Bool) -> Void)?
    var onPreferredSource: ((String) -> Void)?

    private var player: AVPlayer?
    private var playerLayer: AVPlayerLayer?
    private var pipController: AVPictureInPictureController?
    private var timeObserver: Any?
    private var itemStatusObserver: NSKeyValueObservation?

    private var streamUrl: String = ""
    private var streamTitle: String = "SingularityTV"
    private var progressKey: String = ""
    private var startTimeSec: Double = 0
    private var imdbId: String = ""
    private var mediaType: String = "movie"
    private var seasonNum: Int = 1
    private var episodeNum: Int = 1
    private var preferredLang: String = "ar"
    private var currentSource: String = "vidlink"
    private var currentSpeed: Float = 1.0
    private var subDelaySec: Double = 0.0
    private var lastProgressSaveTime: TimeInterval = 0

    private let serverOrder = [
        "vidlink", "videasy", "vidsrccc", "vidsrcxyz", "vidsrcme",
        "vidsrcnet", "vidsrcin", "vidsrcpm", "vidsrc", "vidsrcicu",
        "vidfast", "vidnest", "vidlove", "autoembed", "embedsu",
        "smashy", "multiembed", "superembed", "twoembed", "moviesapi", "nontongo"
    ]
    private var failoverAttempts: Int = 0
    private var isSwitchingServer: Bool = false
    private var pendingNextSource: String = ""
    private var activeReferer: String = ""
    private var resolverWebView: WKWebView?
    private var failoverTimer: Timer?

    private var availableSubs: [IosSubTrack] = []
    private var activeCues: [IosSubCue] = []
    private var activeSubIndex: Int = -1

    private let videoContainer = UIView()
    private let overlayView = UIView()
    private let subtitleLabel = UILabel()
    private let titleLabel = UILabel()
    private let playPauseButton = UIButton(type: .system)
    private let seekSlider = UISlider()
    private let currentPosLabel = UILabel()
    private let durationLabel = UILabel()
    private let subButton = UIButton(type: .system)
    private let syncButton = UIButton(type: .system)
    private let speedButton = UIButton(type: .system)
    private let pipButton = UIButton(type: .system)
    private let leftSeekBadge = UILabel()
    private let rightSeekBadge = UILabel()
    private let statusToastLabel = UILabel()

    private var isControllerVisible = true
    private var isScrubbing = false
    private var hideControllerWorkItem: DispatchWorkItem?
    private var singleTapWorkItem: DispatchWorkItem?
    private var hideLeftSeekWorkItem: DispatchWorkItem?
    private var hideRightSeekWorkItem: DispatchWorkItem?
    private var accumLeftSeek = 0
    private var accumRightSeek = 0
    private var lastTapTime: TimeInterval = 0
    private var lastTapSide = 0
    private var activeSeekSide = 0
    private var lastSeekEventTime: TimeInterval = 0

    private var gestureMode = 0
    private var gestureStartPoint = CGPoint.zero
    private var gestureStartVal: CGFloat = 0.5
    private let hiddenVolumeView = MPVolumeView(frame: CGRect(x: -1000, y: -1000, width: 100, height: 40))

    private let brightnessHudView = UIView()
    private let brightnessTrackView = UIView()
    private let brightnessFillView = UIView()
    private var brightnessFillHeightConstraint: NSLayoutConstraint?
    private let brightnessPctLabel = UILabel()
    private let volumeHudView = UIView()
    private let volumeTrackView = UIView()
    private let volumeFillView = UIView()
    private var volumeFillHeightConstraint: NSLayoutConstraint?
    private let volumePctLabel = UILabel()
    private var hideHudWorkItem: DispatchWorkItem?

    init(payloadJson: String) {
        self.payloadJson = payloadJson
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .landscape }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        view.addSubview(hiddenVolumeView)
        setupUi()
        setupResolverWebView()
        parsePayloadAndPlay()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        playerLayer?.frame = videoContainer.bounds
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        saveProgress(forceCompleted: false)
        failoverTimer?.invalidate()
        player?.pause()
    }

    deinit {
        if let obs = timeObserver {
            player?.removeTimeObserver(obs)
        }
        itemStatusObserver?.invalidate()
        failoverTimer?.invalidate()
    }

    private func setupUi() {
        videoContainer.frame = view.bounds
        videoContainer.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        videoContainer.backgroundColor = .black
        view.addSubview(videoContainer)

        subtitleLabel.translatesAutoresizingMaskIntoConstraints = false
        subtitleLabel.textColor = .white
        subtitleLabel.font = .boldSystemFont(ofSize: 20)
        subtitleLabel.textAlignment = .center
        subtitleLabel.numberOfLines = 0
        subtitleLabel.layer.shadowColor = UIColor.black.cgColor
        subtitleLabel.layer.shadowRadius = 4
        subtitleLabel.layer.shadowOpacity = 0.95
        subtitleLabel.layer.shadowOffset = CGSize(width: 0, height: 1)
        subtitleLabel.isHidden = true
        overlayView.frame = view.bounds
        overlayView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        overlayView.backgroundColor = UIColor.black.withAlphaComponent(0.32)
        view.addSubview(overlayView)
        view.addSubview(subtitleLabel)

        let backBtn = UIButton(type: .system)
        backBtn.translatesAutoresizingMaskIntoConstraints = false
        backBtn.setImage(UIImage(systemName: "chevron.backward"), for: .normal)
        backBtn.tintColor = .white
        backBtn.addTarget(self, action: #selector(handleBack), for: .touchUpInside)

        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.textColor = .white
        titleLabel.font = .boldSystemFont(ofSize: 17)
        titleLabel.lineBreakMode = .byTruncatingTail

        overlayView.addSubview(backBtn)
        overlayView.addSubview(titleLabel)

        let rewBtn = UIButton(type: .system)
        rewBtn.translatesAutoresizingMaskIntoConstraints = false
        rewBtn.setImage(UIImage(systemName: "gobackward.10"), for: .normal)
        rewBtn.tintColor = .white
        rewBtn.setPreferredSymbolConfiguration(UIImage.SymbolConfiguration(pointSize: 26, weight: .semibold), forImageIn: .normal)
        rewBtn.addTarget(self, action: #selector(handleRewind10), for: .touchUpInside)

        playPauseButton.translatesAutoresizingMaskIntoConstraints = false
        playPauseButton.setImage(UIImage(systemName: "pause.fill"), for: .normal)
        playPauseButton.tintColor = .white
        playPauseButton.backgroundColor = UIColor.white.withAlphaComponent(0.16)
        playPauseButton.layer.cornerRadius = 32
        playPauseButton.setPreferredSymbolConfiguration(UIImage.SymbolConfiguration(pointSize: 28, weight: .bold), forImageIn: .normal)
        playPauseButton.addTarget(self, action: #selector(handlePlayPause), for: .touchUpInside)

        let fwdBtn = UIButton(type: .system)
        fwdBtn.translatesAutoresizingMaskIntoConstraints = false
        fwdBtn.setImage(UIImage(systemName: "goforward.10"), for: .normal)
        fwdBtn.tintColor = .white
        fwdBtn.setPreferredSymbolConfiguration(UIImage.SymbolConfiguration(pointSize: 26, weight: .semibold), forImageIn: .normal)
        fwdBtn.addTarget(self, action: #selector(handleForward10), for: .touchUpInside)

        overlayView.addSubview(rewBtn)
        overlayView.addSubview(playPauseButton)
        overlayView.addSubview(fwdBtn)

        currentPosLabel.translatesAutoresizingMaskIntoConstraints = false
        currentPosLabel.textColor = .white
        currentPosLabel.font = .monospacedDigitSystemFont(ofSize: 12, weight: .semibold)
        currentPosLabel.text = "0:00"

        durationLabel.translatesAutoresizingMaskIntoConstraints = false
        durationLabel.textColor = UIColor.white.withAlphaComponent(0.8)
        durationLabel.font = .monospacedDigitSystemFont(ofSize: 12, weight: .semibold)
        durationLabel.text = "0:00"

        seekSlider.translatesAutoresizingMaskIntoConstraints = false
        seekSlider.minimumTrackTintColor = UIColor(red: 229/255, green: 9/255, blue: 20/255, alpha: 1)
        seekSlider.maximumTrackTintColor = UIColor.white.withAlphaComponent(0.3)
        seekSlider.addTarget(self, action: #selector(onSliderStart), for: .touchDown)
        seekSlider.addTarget(self, action: #selector(onSliderChanged), for: .valueChanged)
        seekSlider.addTarget(self, action: #selector(onSliderEnd), for: [.touchUpInside, .touchUpOutside, .touchCancel])

        overlayView.addSubview(currentPosLabel)
        overlayView.addSubview(seekSlider)
        overlayView.addSubview(durationLabel)

        subButton.translatesAutoresizingMaskIntoConstraints = false
        subButton.setTitle("Subtitles", for: .normal)
        subButton.setTitleColor(.white, for: .normal)
        subButton.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
        subButton.addTarget(self, action: #selector(openSubtitleMenu), for: .touchUpInside)

        speedButton.translatesAutoresizingMaskIntoConstraints = false
        speedButton.setTitle("1.0x", for: .normal)
        speedButton.setTitleColor(.white, for: .normal)
        speedButton.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
        speedButton.addTarget(self, action: #selector(openSpeedMenu), for: .touchUpInside)

        pipButton.translatesAutoresizingMaskIntoConstraints = false
        pipButton.setTitle("PiP", for: .normal)
        pipButton.setTitleColor(.white, for: .normal)
        pipButton.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
        pipButton.addTarget(self, action: #selector(togglePip), for: .touchUpInside)

        syncButton.translatesAutoresizingMaskIntoConstraints = false
        syncButton.setTitle("Sync 0.0s", for: .normal)
        syncButton.setTitleColor(.white, for: .normal)
        syncButton.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
        syncButton.addTarget(self, action: #selector(openSyncMenu), for: .touchUpInside)

        let actionsStack = UIStackView(arrangedSubviews: [subButton, syncButton, speedButton, pipButton])
        actionsStack.translatesAutoresizingMaskIntoConstraints = false
        actionsStack.axis = .horizontal
        actionsStack.spacing = 24
        overlayView.addSubview(actionsStack)

        setupSeekBadges()
        setupGestureHuds()

        statusToastLabel.translatesAutoresizingMaskIntoConstraints = false
        statusToastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.75)
        statusToastLabel.textColor = .white
        statusToastLabel.font = .systemFont(ofSize: 13, weight: .semibold)
        statusToastLabel.textAlignment = .center
        statusToastLabel.layer.cornerRadius = 14
        statusToastLabel.layer.masksToBounds = true
        statusToastLabel.isHidden = true
        view.addSubview(statusToastLabel)

        NSLayoutConstraint.activate([
            backBtn.topAnchor.constraint(equalTo: overlayView.safeAreaLayoutGuide.topAnchor, constant: 12),
            backBtn.leadingAnchor.constraint(equalTo: overlayView.safeAreaLayoutGuide.leadingAnchor, constant: 18),
            backBtn.widthAnchor.constraint(equalToConstant: 40),
            backBtn.heightAnchor.constraint(equalToConstant: 40),

            titleLabel.centerYAnchor.constraint(equalTo: backBtn.centerYAnchor),
            titleLabel.leadingAnchor.constraint(equalTo: backBtn.trailingAnchor, constant: 10),
            titleLabel.trailingAnchor.constraint(equalTo: overlayView.safeAreaLayoutGuide.trailingAnchor, constant: -20),

            playPauseButton.centerXAnchor.constraint(equalTo: overlayView.centerXAnchor),
            playPauseButton.centerYAnchor.constraint(equalTo: overlayView.centerYAnchor),
            playPauseButton.widthAnchor.constraint(equalToConstant: 64),
            playPauseButton.heightAnchor.constraint(equalToConstant: 64),

            rewBtn.centerYAnchor.constraint(equalTo: playPauseButton.centerYAnchor),
            rewBtn.trailingAnchor.constraint(equalTo: playPauseButton.leadingAnchor, constant: -42),

            fwdBtn.centerYAnchor.constraint(equalTo: playPauseButton.centerYAnchor),
            fwdBtn.leadingAnchor.constraint(equalTo: playPauseButton.trailingAnchor, constant: 42),

            actionsStack.bottomAnchor.constraint(equalTo: overlayView.safeAreaLayoutGuide.bottomAnchor, constant: -10),
            actionsStack.centerXAnchor.constraint(equalTo: overlayView.centerXAnchor),

            currentPosLabel.leadingAnchor.constraint(equalTo: overlayView.safeAreaLayoutGuide.leadingAnchor, constant: 22),
            currentPosLabel.bottomAnchor.constraint(equalTo: actionsStack.topAnchor, constant: -14),

            durationLabel.trailingAnchor.constraint(equalTo: overlayView.safeAreaLayoutGuide.trailingAnchor, constant: -22),
            durationLabel.centerYAnchor.constraint(equalTo: currentPosLabel.centerYAnchor),

            seekSlider.leadingAnchor.constraint(equalTo: currentPosLabel.trailingAnchor, constant: 12),
            seekSlider.trailingAnchor.constraint(equalTo: durationLabel.leadingAnchor, constant: -12),
            seekSlider.centerYAnchor.constraint(equalTo: currentPosLabel.centerYAnchor),

            subtitleLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            subtitleLabel.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -24),
            subtitleLabel.widthAnchor.constraint(lessThanOrEqualTo: view.widthAnchor, multiplier: 0.85),

            statusToastLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            statusToastLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            statusToastLabel.heightAnchor.constraint(equalToConstant: 30),
            statusToastLabel.widthAnchor.constraint(greaterThanOrEqualToConstant: 160)
        ])
    }

    private func setupSeekBadges() {
        for (badge, isLeft) in [(leftSeekBadge, true), (rightSeekBadge, false)] {
            badge.translatesAutoresizingMaskIntoConstraints = false
            badge.textColor = .white
            badge.font = .boldSystemFont(ofSize: 17)
            badge.textAlignment = .center
            badge.backgroundColor = UIColor.black.withAlphaComponent(0.55)
            badge.layer.cornerRadius = 20
            badge.layer.masksToBounds = true
            badge.isHidden = true
            view.addSubview(badge)
            NSLayoutConstraint.activate([
                badge.centerYAnchor.constraint(equalTo: view.centerYAnchor),
                badge.widthAnchor.constraint(equalToConstant: 105),
                badge.heightAnchor.constraint(equalToConstant: 42),
                isLeft
                    ? badge.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 60)
                    : badge.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -60)
            ])
        }
    }

    private func setupGestureHuds() {
        func configureHud(container: UIView, track: UIView, fill: UIView, label: UILabel, iconName: String, fillColor: UIColor, isLeft: Bool) -> NSLayoutConstraint {
            container.translatesAutoresizingMaskIntoConstraints = false
            container.isHidden = true
            view.addSubview(container)

            let icon = UIImageView(image: UIImage(systemName: iconName))
            icon.translatesAutoresizingMaskIntoConstraints = false
            icon.tintColor = .white
            icon.contentMode = .scaleAspectFit

            track.translatesAutoresizingMaskIntoConstraints = false
            track.backgroundColor = UIColor.white.withAlphaComponent(0.32)
            track.layer.cornerRadius = 3
            track.clipsToBounds = true

            fill.translatesAutoresizingMaskIntoConstraints = false
            fill.backgroundColor = fillColor
            fill.layer.cornerRadius = 3
            track.addSubview(fill)

            label.translatesAutoresizingMaskIntoConstraints = false
            label.textColor = .white
            label.font = .boldSystemFont(ofSize: 11)
            label.textAlignment = .center

            container.addSubview(icon)
            container.addSubview(track)
            container.addSubview(label)

            let heightConstraint = fill.heightAnchor.constraint(equalToConstant: 64)
            NSLayoutConstraint.activate([
                container.centerYAnchor.constraint(equalTo: view.centerYAnchor),
                container.widthAnchor.constraint(equalToConstant: 42),
                container.heightAnchor.constraint(equalToConstant: 180),
                isLeft
                    ? container.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 22)
                    : container.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -22),

                icon.topAnchor.constraint(equalTo: container.topAnchor),
                icon.centerXAnchor.constraint(equalTo: container.centerXAnchor),
                icon.widthAnchor.constraint(equalToConstant: 20),
                icon.heightAnchor.constraint(equalToConstant: 20),

                label.bottomAnchor.constraint(equalTo: container.bottomAnchor),
                label.centerXAnchor.constraint(equalTo: container.centerXAnchor),

                track.topAnchor.constraint(equalTo: icon.bottomAnchor, constant: 8),
                track.bottomAnchor.constraint(equalTo: label.topAnchor, constant: -8),
                track.centerXAnchor.constraint(equalTo: container.centerXAnchor),
                track.widthAnchor.constraint(equalToConstant: 6),

                fill.leadingAnchor.constraint(equalTo: track.leadingAnchor),
                fill.trailingAnchor.constraint(equalTo: track.trailingAnchor),
                fill.bottomAnchor.constraint(equalTo: track.bottomAnchor),
                heightConstraint
            ])
            return heightConstraint
        }

        brightnessFillHeightConstraint = configureHud(
            container: brightnessHudView,
            track: brightnessTrackView,
            fill: brightnessFillView,
            label: brightnessPctLabel,
            iconName: "sun.max.fill",
            fillColor: UIColor(red: 250/255, green: 204/255, blue: 21/255, alpha: 1),
            isLeft: true
        )
        volumeFillHeightConstraint = configureHud(
            container: volumeHudView,
            track: volumeTrackView,
            fill: volumeFillView,
            label: volumePctLabel,
            iconName: "speaker.wave.2.fill",
            fillColor: UIColor(red: 229/255, green: 9/255, blue: 20/255, alpha: 1),
            isLeft: false
        )
    }

    private func setupResolverWebView() {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        let ucc = WKUserContentController()
        ucc.add(self, name: "PlayerSniffer")
        let snifferJs = """
        (function(){
          function post(u) {
            if (!u || typeof u !== 'string') return;
            var l = u.toLowerCase();
            if (l.indexOf('.m3u8') !== -1 || l.indexOf('.mpd') !== -1 || l.indexOf('master.txt') !== -1 || l.indexOf('playlist.txt') !== -1 || l.indexOf('/hls/') !== -1 || (l.indexOf('.mp4') !== -1 && l.indexOf('preview') === -1 && l.indexOf('trailer') === -1)) {
              try { window.webkit.messageHandlers.PlayerSniffer.postMessage({ url: u, ref: location.href }); } catch(e) {}
            }
          }
          if (window.fetch) {
            var of = window.fetch;
            window.fetch = function(i) { try { post(typeof i === 'string' ? i : (i && i.url)); } catch(e) {} return of.apply(this, arguments); };
          }
          if (window.XMLHttpRequest) {
            var oo = XMLHttpRequest.prototype.open;
            XMLHttpRequest.prototype.open = function(m, u) { try { post(u); } catch(e) {} return oo.apply(this, arguments); };
          }
          try {
            new PerformanceObserver(function(list){ list.getEntries().forEach(function(e){ post(e.name); }); }).observe({ entryTypes: ['resource'] });
          } catch(e) {}
        })();
        """
        ucc.addUserScript(WKUserScript(source: snifferJs, injectionTime: .atDocumentStart, forMainFrameOnly: false))
        config.userContentController = ucc

        let wv = WKWebView(frame: CGRect(x: 0, y: 0, width: 120, height: 80), configuration: config)
        wv.alpha = 0.01
        wv.isUserInteractionEnabled = false
        wv.navigationDelegate = self
        wv.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"
        view.insertSubview(wv, at: 0)
        resolverWebView = wv
    }

    private func parsePayloadAndPlay() {
        guard let data = payloadJson.data(using: .utf8),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            dismiss(animated: true)
            return
        }
        streamUrl = obj["url"] as? String ?? ""
        streamTitle = obj["title"] as? String ?? "SingularityTV"
        progressKey = obj["progressKey"] as? String ?? ""
        startTimeSec = (obj["startTimeSec"] as? NSNumber)?.doubleValue ?? 0
        imdbId = obj["imdbId"] as? String ?? ""
        mediaType = obj["mediaType"] as? String ?? "movie"
        seasonNum = (obj["season"] as? NSNumber)?.intValue ?? 1
        episodeNum = (obj["episode"] as? NSNumber)?.intValue ?? 1
        preferredLang = (obj["preferredSubLang"] as? String ?? "ar").lowercased()
        currentSource = obj["currentSource"] as? String ?? "vidlink"
        activeReferer = obj["referer"] as? String ?? buildReferer(for: currentSource)

        titleLabel.text = streamTitle

        if let subs = obj["subtitles"] as? [[String: Any]] {
            for s in subs {
                let u = (s["url"] as? String) ?? (s["path"] as? String) ?? ""
                if u.isEmpty { continue }
                let lang = (s["lang"] as? String ?? "en").lowercased()
                let label = (s["label"] as? String) ?? "Stream · \(lang.uppercased())"
                availableSubs.append(IosSubTrack(lang: lang, url: u, score: 100, syncMatch: true))
            }
        }
        subButton.setTitle("Subtitles (\(availableSubs.count))", for: .normal)

        startPlayback(urlString: streamUrl, referer: activeReferer, seekSec: startTimeSec)
        fetchSubtitlesInBackground()
        showControllerTemporarily()
    }

    private func buildReferer(for sourceId: String) -> String {
        switch sourceId {
        case "vidlink": return "https://vidlink.pro/"
        case "videasy": return "https://player.videasy.net/"
        case "vidsrccc": return "https://vidsrc.cc/"
        case "vidsrcxyz": return "https://vidsrc.xyz/"
        case "vidsrcme": return "https://vidsrc.me/"
        default: return "https://vidlink.pro/"
        }
    }

    private func buildEmbedUrl(for sourceId: String) -> String {
        guard !imdbId.isEmpty else { return "" }
        let isTv = mediaType.lowercased() == "tv"
        let s = max(1, seasonNum)
        let e = max(1, episodeNum)
        switch sourceId {
        case "vidlink": return isTv ? "https://vidlink.pro/tv/\(imdbId)/\(s)/\(e)?autoplay=true" : "https://vidlink.pro/movie/\(imdbId)?autoplay=true"
        case "videasy": return isTv ? "https://player.videasy.net/tv/\(imdbId)/\(s)/\(e)" : "https://player.videasy.net/movie/\(imdbId)"
        case "vidsrccc": return isTv ? "https://vidsrc.cc/v2/embed/tv/\(imdbId)/\(s)/\(e)?autoPlay=true" : "https://vidsrc.cc/v2/embed/movie/\(imdbId)?autoPlay=true"
        case "vidsrcxyz": return isTv ? "https://vidsrc.xyz/embed/tv/\(imdbId)/\(s)-\(e)" : "https://vidsrc.xyz/embed/movie/\(imdbId)"
        case "vidsrcme": return isTv ? "https://vidsrc.me/embed/tv?imdb=\(imdbId)&season=\(s)&episode=\(e)" : "https://vidsrc.me/embed/movie?imdb=\(imdbId)"
        case "vidsrcnet": return isTv ? "https://vidsrc.net/embed/tv/\(imdbId)/\(s)-\(e)?autoplay=1" : "https://vidsrc.net/embed/movie/\(imdbId)?autoplay=1"
        case "vidsrcin": return isTv ? "https://vidsrc.in/embed/tv/\(imdbId)/\(s)-\(e)" : "https://vidsrc.in/embed/movie/\(imdbId)"
        case "vidsrcpm": return isTv ? "https://vidsrc.pm/embed/tv/\(imdbId)/\(s)-\(e)" : "https://vidsrc.pm/embed/movie/\(imdbId)"
        case "vidsrc": return isTv ? "https://vsembed.su/embed/tv/\(imdbId)/\(s)/\(e)?autoplay=1" : "https://vsembed.su/embed/movie/\(imdbId)?autoplay=1"
        case "vidsrcicu": return isTv ? "https://vidsrc.icu/embed/tv/\(imdbId)/\(s)/\(e)" : "https://vidsrc.icu/embed/movie/\(imdbId)"
        case "vidfast": return isTv ? "https://vidfast.pro/tv/\(imdbId)/\(s)/\(e)?autoPlay=true" : "https://vidfast.pro/movie/\(imdbId)?autoPlay=true"
        case "vidnest": return isTv ? "https://vidnest.fun/tv/\(imdbId)/\(s)/\(e)" : "https://vidnest.fun/movie/\(imdbId)"
        case "autoembed": return isTv ? "https://player.autoembed.cc/embed/tv/\(imdbId)/\(s)/\(e)?server=1" : "https://player.autoembed.cc/embed/movie/\(imdbId)?server=1"
        case "embedsu": return isTv ? "https://embed.su/embed/tv/\(imdbId)/\(s)/\(e)" : "https://embed.su/embed/movie/\(imdbId)"
        case "smashy": return isTv ? "https://player.smashy.stream/tv/\(imdbId)?s=\(s)&e=\(e)" : "https://player.smashy.stream/movie/\(imdbId)"
        case "multiembed": return isTv ? "https://multiembed.mov/?video_id=\(imdbId)&s=\(s)&e=\(e)" : "https://multiembed.mov/?video_id=\(imdbId)"
        case "moviesapi": return isTv ? "https://moviesapi.club/tv/\(imdbId)-\(s)-\(e)" : "https://moviesapi.club/movie/\(imdbId)"
        default: return isTv ? "https://vidsrc.xyz/embed/tv/\(imdbId)/\(s)-\(e)" : "https://vidsrc.xyz/embed/movie/\(imdbId)"
        }
    }

    private func startPlayback(urlString: String, referer: String, seekSec: Double) {
        guard let url = URL(string: urlString) else { return }
        if let obs = timeObserver {
            player?.removeTimeObserver(obs)
            timeObserver = nil
        }
        itemStatusObserver?.invalidate()
        player?.pause()
        playerLayer?.removeFromSuperlayer()

        var headers: [String: String] = [
            "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"
        ]
        if !referer.isEmpty {
            headers["Referer"] = referer
            if let ru = URL(string: referer), let scheme = ru.scheme, let host = ru.host {
                headers["Origin"] = "\(scheme)://\(host)"
            }
        }

        let asset = AVURLAsset(url: url, options: ["AVURLAssetHTTPHeaderFieldsKey": headers])
        let item = AVPlayerItem(asset: asset)
        let newPlayer = AVPlayer(playerItem: item)
        let layer = AVPlayerLayer(player: newPlayer)
        layer.frame = videoContainer.bounds
        layer.videoGravity = .resizeAspect
        videoContainer.layer.addSublayer(layer)

        player = newPlayer
        playerLayer = layer

        if AVPictureInPictureController.isPictureInPictureSupported() {
            pipController = AVPictureInPictureController(playerLayer: layer)
            pipController?.delegate = self
        }

        itemStatusObserver = item.observe(\.status, options: [.new]) { [weak self] avItem, _ in
            DispatchQueue.main.async {
                guard let self = self else { return }
                if avItem.status == .readyToPlay {
                    self.failoverAttempts = 0
                    self.isSwitchingServer = false
                    self.failoverTimer?.invalidate()
                    UserDefaults.standard.set(self.currentSource, forKey: "streambert_lastWorkingSource")
                    self.onPreferredSource?(self.currentSource)
                    let dur = CMTimeGetSeconds(avItem.duration)
                    if seekSec > 0 && dur.isFinite && seekSec < dur - 15 {
                        newPlayer.seek(to: CMTime(seconds: seekSec, preferredTimescale: 600))
                    }
                    newPlayer.rate = self.currentSpeed
                    newPlayer.play()
                    self.updatePlayPauseIcon()
                } else if avItem.status == .failed {
                    self.triggerNextServerFailover()
                }
            }
        }

        NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime,
            object: item,
            queue: .main
        ) { [weak self] _ in
            self?.saveProgress(forceCompleted: true)
        }

        let interval = CMTime(seconds: 0.25, preferredTimescale: 600)
        timeObserver = newPlayer.addPeriodicTimeObserver(forInterval: interval, queue: .main) { [weak self] _ in
            guard let self = self else { return }
            self.updateTimeAndSubtitles()
            let now = Date().timeIntervalSince1970
            if now - self.lastProgressSaveTime >= 5.0 {
                self.lastProgressSaveTime = now
                self.saveProgress(forceCompleted: false)
            }
        }
    }

    private func triggerNextServerFailover() {
        if isSwitchingServer || failoverAttempts >= serverOrder.count { return }
        isSwitchingServer = true
        failoverAttempts += 1
        let idx = serverOrder.firstIndex(of: currentSource) ?? 0
        let nextSrc = serverOrder[(idx + 1) % serverOrder.count]
        pendingNextSource = nextSrc
        showToast("Switching to \(nextSrc)...")
        let embed = buildEmbedUrl(for: nextSrc)
        if !embed.isEmpty, let u = URL(string: embed) {
            resolverWebView?.load(URLRequest(url: u))
        }
        failoverTimer?.invalidate()
        failoverTimer = Timer.scheduledTimer(withTimeInterval: 6.0, repeats: false) { [weak self] _ in
            guard let self = self, self.isSwitchingServer else { return }
            self.isSwitchingServer = false
            self.currentSource = self.pendingNextSource
            self.triggerNextServerFailover()
        }
    }

    func applyExternalResolvedStream(url: String, sourceId: String) {
        if url.isEmpty { return }
        DispatchQueue.main.async {
            self.failoverTimer?.invalidate()
            self.isSwitchingServer = false
            self.streamUrl = url
            if !sourceId.isEmpty { self.currentSource = sourceId }
            let cur = self.player.map { CMTimeGetSeconds($0.currentTime()) } ?? self.startTimeSec
            let resume = cur.isFinite && cur > 0 ? cur : self.startTimeSec
            self.startPlayback(urlString: url, referer: self.buildReferer(for: self.currentSource), seekSec: resume)
        }
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "PlayerSniffer",
              let dict = message.body as? [String: Any],
              let url = dict["url"] as? String else { return }
        let ref = dict["ref"] as? String ?? buildReferer(for: pendingNextSource)
        if isSwitchingServer {
            failoverTimer?.invalidate()
            isSwitchingServer = false
            currentSource = pendingNextSource.isEmpty ? currentSource : pendingNextSource
            let cur = player.map { CMTimeGetSeconds($0.currentTime()) } ?? startTimeSec
            let resume = cur.isFinite && cur > 0 ? cur : startTimeSec
            startPlayback(urlString: url, referer: ref, seekSec: resume)
        }
    }

    private func showToast(_ text: String) {
        statusToastLabel.text = "  \(text)  "
        statusToastLabel.isHidden = false
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { [weak self] in
            self?.statusToastLabel.isHidden = true
        }
    }

    private func updateTimeAndSubtitles() {
        guard let player = player else { return }
        let pos = CMTimeGetSeconds(player.currentTime())
        let dur = CMTimeGetSeconds(player.currentItem?.duration ?? .zero)
        if !isScrubbing && pos.isFinite && dur.isFinite && dur > 0 {
            currentPosLabel.text = formatTime(pos)
            durationLabel.text = formatTime(dur)
            seekSlider.value = Float(min(1.0, max(0.0, pos / dur)))
        }
        if !activeCues.isEmpty && pos.isFinite {
            let adj = pos - subDelaySec
            if let cue = activeCues.first(where: { adj >= $0.startSec && adj <= $0.endSec }) {
                subtitleLabel.text = cue.text
                subtitleLabel.isHidden = false
            } else {
                subtitleLabel.isHidden = true
            }
        } else {
            subtitleLabel.isHidden = true
        }
    }

    private func formatTime(_ sec: Double) -> String {
        let total = max(0, Int(sec))
        let h = total / 3600
        let m = (total % 3600) / 60
        let s = total % 60
        return h > 0 ? String(format: "%d:%02d:%02d", h, m, s) : String(format: "%d:%02d", m, s)
    }

    private func updatePlayPauseIcon() {
        let playing = (player?.rate ?? 0) > 0
        playPauseButton.setImage(UIImage(systemName: playing ? "pause.fill" : "play.fill"), for: .normal)
    }

    private func showControllerTemporarily() {
        isControllerVisible = true
        overlayView.isHidden = false
        UIView.animate(withDuration: 0.18) { self.overlayView.alpha = 1 }
        hideControllerWorkItem?.cancel()
        let item = DispatchWorkItem { [weak self] in
            guard let self = self, (self.player?.rate ?? 0) > 0, !self.isScrubbing else { return }
            self.setControllerVisible(false)
        }
        hideControllerWorkItem = item
        DispatchQueue.main.asyncAfter(deadline: .now() + 4.0, execute: item)
    }

    private func setControllerVisible(_ visible: Bool) {
        isControllerVisible = visible
        if visible {
            showControllerTemporarily()
        } else {
            hideControllerWorkItem?.cancel()
            UIView.animate(withDuration: 0.18, animations: { self.overlayView.alpha = 0 }) { _ in
                if !self.isControllerVisible { self.overlayView.isHidden = true }
            }
        }
    }

    @objc private func handleBack() {
        saveProgress(forceCompleted: false)
        dismiss(animated: true)
    }

    @objc private func handlePlayPause() {
        guard let player = player else { return }
        if player.rate > 0 {
            player.pause()
        } else {
            player.rate = currentSpeed
            player.play()
        }
        updatePlayPauseIcon()
        showControllerTemporarily()
    }

    @objc private func handleRewind10() { seekBy(-10) }
    @objc private func handleForward10() { seekBy(10) }

    private func seekBy(_ delta: Double) {
        guard let player = player else { return }
        let cur = CMTimeGetSeconds(player.currentTime())
        let dur = CMTimeGetSeconds(player.currentItem?.duration ?? .zero)
        var target = max(0, cur + delta)
        if dur.isFinite && dur > 0 { target = min(dur, target) }
        player.seek(to: CMTime(seconds: target, preferredTimescale: 600))
    }

    @objc private func onSliderStart() {
        isScrubbing = true
        hideControllerWorkItem?.cancel()
    }

    @objc private func onSliderChanged() {
        guard let dur = player?.currentItem?.duration else { return }
        let d = CMTimeGetSeconds(dur)
        if d.isFinite && d > 0 {
            currentPosLabel.text = formatTime(Double(seekSlider.value) * d)
        }
    }

    @objc private func onSliderEnd() {
        isScrubbing = false
        if let dur = player?.currentItem?.duration {
            let d = CMTimeGetSeconds(dur)
            if d.isFinite && d > 0 {
                player?.seek(to: CMTime(seconds: Double(seekSlider.value) * d, preferredTimescale: 600))
            }
        }
        showControllerTemporarily()
    }

    @objc private func openSpeedMenu() {
        let sheet = UIAlertController(title: "Playback Speed", message: nil, preferredStyle: .actionSheet)
        for s: Float in [0.5, 0.75, 1.0, 1.25, 1.5, 2.0] {
            sheet.addAction(UIAlertAction(title: "\(s)x", style: .default) { _ in
                self.currentSpeed = s
                self.speedButton.setTitle("\(s)x", for: .normal)
                if (self.player?.rate ?? 0) > 0 { self.player?.rate = s }
            })
        }
        sheet.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        sheet.popoverPresentationController?.sourceView = speedButton
        present(sheet, animated: true)
    }

    private func languageDisplayName(_ code: String) -> String {
        switch code.lowercased() {
        case "ar": return "Arabic"
        case "en": return "English"
        case "ko": return "Korea"
        case "ja": return "Japanese"
        case "fr": return "French"
        case "es": return "Spanish"
        case "de": return "German"
        case "tr": return "Turkish"
        case "pt": return "Portuguese"
        case "it": return "Italian"
        case "ru": return "Russian"
        case "hi": return "Hindi"
        case "id": return "Indonesian"
        case "zh": return "Chinese"
        case "nl": return "Dutch"
        case "pl": return "Polish"
        case "sv": return "Swedish"
        case "th": return "Thai"
        case "vi": return "Vietnamese"
        case "fa": return "Persian"
        default: return code.uppercased()
        }
    }

    @objc private func openSyncMenu() {
        let sheet = UIAlertController(
            title: String(format: "Subtitle Sync (%.1fs)", subDelaySec),
            message: "Adjust if subtitles appear too early or too late",
            preferredStyle: .actionSheet
        )
        let steps: [(String, Double)] = [
            ("Earlier -5.0s", -5.0),
            ("Earlier -1.0s", -1.0),
            ("Earlier -0.5s", -0.5),
            ("Later +0.5s", 0.5),
            ("Later +1.0s", 1.0),
            ("Later +5.0s", 5.0),
            ("Reset 0.0s", 0.0)
        ]
        for (label, delta) in steps {
            sheet.addAction(UIAlertAction(title: label, style: .default) { _ in
                if delta == 0.0 {
                    self.subDelaySec = 0.0
                } else {
                    self.subDelaySec += delta
                }
                self.syncButton.setTitle(String(format: "Sync %.1fs", self.subDelaySec), for: .normal)
                self.updateTimeAndSubtitles()
            })
        }
        sheet.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        sheet.popoverPresentationController?.sourceView = syncButton
        present(sheet, animated: true)
    }

    @objc private func openSubtitleMenu() {
        var langCounts: [String: Int] = [:]
        var recommendedLangs = Set<String>()
        for sub in availableSubs where sub.syncMatch {
            recommendedLangs.insert(sub.lang)
        }
        let hasAnySyncMatch = !recommendedLangs.isEmpty
        let msg = hasAnySyncMatch
            ? "Recommend marks the best-synced subtitle"
            : "No exact sync match found — use Sync to adjust timing"
        let sheet = UIAlertController(title: "Subtitles", message: msg, preferredStyle: .actionSheet)
        sheet.addAction(UIAlertAction(title: "Off", style: .default) { _ in
            self.activeSubIndex = -1
            self.activeCues = []
            self.subtitleLabel.isHidden = true
        })
        var bestSeenForLang = Set<String>()
        for (idx, sub) in availableSubs.enumerated() {
            let num = (langCounts[sub.lang] ?? 0) + 1
            langCounts[sub.lang] = num
            let langName = languageDisplayName(sub.lang)
            let isRec = sub.syncMatch && !bestSeenForLang.contains(sub.lang)
            if isRec { bestSeenForLang.insert(sub.lang) }
            let prefix = idx == activeSubIndex ? "✓ " : ""
            let suffix = isRec ? " · Recommend" : (!recommendedLangs.contains(sub.lang) && num == 1 ? " · Needs Sync" : "")
            sheet.addAction(UIAlertAction(title: "\(prefix)\(langName) sub \(num)\(suffix)", style: .default) { _ in
                self.activeSubIndex = idx
                self.loadSubtitleFile(url: sub.url)
            })
        }
        sheet.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        sheet.popoverPresentationController?.sourceView = subButton
        present(sheet, animated: true)
    }

    @objc private func togglePip() {
        guard let pip = pipController else { return }
        if pip.isPictureInPictureActive {
            pip.stopPictureInPicture()
        } else {
            pip.startPictureInPicture()
        }
    }

    private func normalizeSubLang(_ raw: String) -> String {
        let c = raw.trimmingCharacters(in: .whitespacesAndNewlines).lowercased().components(separatedBy: "-").first ?? "en"
        switch c {
        case "ara", "arabic", "ar": return "ar"
        case "eng", "english", "en": return "en"
        case "kor", "korean", "ko": return "ko"
        case "jpn", "japanese", "ja": return "ja"
        case "fre", "fra", "french", "fr": return "fr"
        case "spa", "spanish", "es": return "es"
        case "ger", "deu", "german", "de": return "de"
        case "tur", "turkish", "tr": return "tr"
        case "por", "portuguese", "pt": return "pt"
        case "ita", "italian", "it": return "it"
        case "rus", "russian", "ru": return "ru"
        case "hin", "hindi", "hi": return "hi"
        case "ind", "indonesian", "id": return "id"
        case "chi", "zho", "chinese", "zh": return "zh"
        case "dut", "nld", "dutch", "nl": return "nl"
        case "pol", "polish", "pl": return "pl"
        case "swe", "swedish", "sv": return "sv"
        case "tha", "thai", "th": return "th"
        case "vie", "vietnamese", "vi": return "vi"
        case "per", "fas", "persian", "fa": return "fa"
        default: return c.isEmpty ? "en" : c
        }
    }

    private func scoreRelease(_ name: String) -> (Int, Bool) {
        let l = name.lowercased()
        var score = 40
        var syncMatch = false
        if l.contains("web-dl") || l.contains("webrip") || l.contains("web.") || l.contains("bluray") || l.contains("brrip") || l.contains("bdrip") || l.contains("1080p") || l.contains("720p") {
            score += 45
            syncMatch = true
        }
        if l.contains("cam") || l.contains("ts") || l.contains("hdcam") {
            score -= 20
        }
        return (score, syncMatch)
    }

    private func mergeSubtitleTracks(_ tracks: [IosSubTrack]) {
        if tracks.isEmpty { return }
        DispatchQueue.main.async {
            let existing = Set(self.availableSubs.map { $0.url })
            let fresh = tracks.filter { !existing.contains($0.url) }
            if fresh.isEmpty { return }
            self.availableSubs.append(contentsOf: fresh)
            self.availableSubs.sort { a, b in
                let aRank = a.lang == self.preferredLang ? 0 : (a.lang == "ar" ? 1 : (a.lang == "en" ? 2 : 3))
                let bRank = b.lang == self.preferredLang ? 0 : (b.lang == "ar" ? 1 : (b.lang == "en" ? 2 : 3))
                if aRank != bRank { return aRank < bRank }
                if a.lang != b.lang { return a.lang < b.lang }
                return a.score > b.score
            }
            self.subButton.setTitle("Subtitles (\(self.availableSubs.count))", for: .normal)
            if self.activeSubIndex == -1, let firstPref = self.availableSubs.firstIndex(where: { $0.lang == self.preferredLang || $0.lang == "ar" }) {
                self.activeSubIndex = firstPref
                self.loadSubtitleFile(url: self.availableSubs[firstPref].url)
            }
        }
    }

    private func fetchSubtitlesInBackground() {
        guard !imdbId.isEmpty else { return }
        let isTv = mediaType.lowercased() == "tv"

        let osType = isTv ? "series" : "movie"
        let osTarget = isTv ? "\(imdbId):\(seasonNum):\(episodeNum)" : imdbId
        if let encoded = osTarget.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed),
           let osUrl = URL(string: "https://opensubtitles-v3.strem.io/subtitles/\(osType)/\(encoded).json") {
            var req = URLRequest(url: osUrl)
            req.setValue("SingularityTV/2.7.3", forHTTPHeaderField: "User-Agent")
            URLSession.shared.dataTask(with: req) { [weak self] data, _, _ in
                guard let self = self, let data = data,
                      let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                      let arr = root["subtitles"] as? [[String: Any]] else { return }
                var added: [IosSubTrack] = []
                for item in arr.prefix(120) {
                    guard let subUrl = item["url"] as? String, !subUrl.isEmpty else { continue }
                    let lang = self.normalizeSubLang(item["lang"] as? String ?? "en")
                    added.append(IosSubTrack(lang: lang, url: subUrl, score: 65, syncMatch: true))
                }
                self.mergeSubtitleTracks(added)
            }.resume()
        }

        let numericImdb = imdbId.replacingOccurrences(of: "tt", with: "")
        if !numericImdb.isEmpty {
            let restPaths = isTv
                ? [
                    "https://rest.opensubtitles.org/search/episode-\(episodeNum)/imdbid-\(numericImdb)/season-\(seasonNum)/sublanguageid-ara",
                    "https://rest.opensubtitles.org/search/episode-\(episodeNum)/imdbid-\(numericImdb)/season-\(seasonNum)/sublanguageid-all"
                  ]
                : [
                    "https://rest.opensubtitles.org/search/imdbid-\(numericImdb)/sublanguageid-ara",
                    "https://rest.opensubtitles.org/search/imdbid-\(numericImdb)/sublanguageid-all"
                  ]
            for restStr in restPaths {
                guard let ru = URL(string: restStr) else { continue }
                var rreq = URLRequest(url: ru)
                rreq.setValue("TemporaryUserAgent", forHTTPHeaderField: "X-User-Agent")
                rreq.setValue("TemporaryUserAgent", forHTTPHeaderField: "User-Agent")
                URLSession.shared.dataTask(with: rreq) { [weak self] data, _, _ in
                    guard let self = self, let data = data,
                          let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { return }
                    var added: [IosSubTrack] = []
                    for item in arr.prefix(60) {
                        guard var dl = item["SubDownloadLink"] as? String, !dl.isEmpty else { continue }
                        dl = dl.replacingOccurrences(of: ".gz", with: "")
                        let rawLang = (item["ISO639"] as? String) ?? (item["SubLanguageID"] as? String) ?? "en"
                        let normLang = self.normalizeSubLang(rawLang)
                        let rel = (item["MovieReleaseName"] as? String) ?? ""
                        let (sc, match) = self.scoreRelease(rel)
                        added.append(IosSubTrack(lang: normLang, url: dl, score: sc + 20, syncMatch: match))
                    }
                    self.mergeSubtitleTracks(added)
                }.resume()
            }
        }

        let langs = Array(Set([preferredLang, "ar", "en", "fr", "es", "de", "tr", "pt", "it", "ru", "ja", "ko", "hi", "id", "zh", "nl", "pl", "sv", "th", "vi", "fa", ""]))
        for lang in langs {
            var qs = "id=\(imdbId)&format=srt"
            if !lang.isEmpty { qs += "&language=\(lang)" }
            if isTv { qs += "&season=\(seasonNum)&episode=\(episodeNum)" }
            guard let u = URL(string: "https://subs.wyzie.ru/search?\(qs)") else { continue }
            var req = URLRequest(url: u)
            req.setValue("SingularityTV/2.7.3", forHTTPHeaderField: "User-Agent")
            URLSession.shared.dataTask(with: req) { [weak self] data, _, _ in
                guard let self = self, let data = data,
                      let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { return }
                var added: [IosSubTrack] = []
                let limit = lang.isEmpty ? 80 : 20
                for item in arr.prefix(limit) {
                    guard let rawUrl = item["url"] as? String, !rawUrl.isEmpty else { continue }
                    let fullUrl = rawUrl.hasPrefix("http") ? rawUrl : "https://subs.wyzie.ru\(rawUrl)"
                    let rawItemLang = (item["language"] as? String) ?? (item["lang"] as? String) ?? (item["iso639"] as? String) ?? (lang.isEmpty ? "en" : lang)
                    let normLang = self.normalizeSubLang(rawItemLang)
                    let rel = (item["display_name"] as? String) ?? (item["release_name"] as? String) ?? (item["display"] as? String) ?? ""
                    let (sc, match) = self.scoreRelease(rel)
                    added.append(IosSubTrack(lang: normLang, url: fullUrl, score: sc, syncMatch: match))
                }
                self.mergeSubtitleTracks(added)
            }.resume()
        }
    }

    private func decodeSubtitleData(_ data: Data) -> String? {
        if let utf8 = String(data: data, encoding: .utf8) {
            return utf8
        }
        let cp1256 = String.Encoding(rawValue: CFStringConvertEncodingToNSStringEncoding(CFStringEncoding(CFStringEncodings.windowsArabic.rawValue)))
        if let ar = String(data: data, encoding: cp1256) {
            return ar
        }
        if let latin = String(data: data, encoding: .isoLatin1) {
            return latin
        }
        return nil
    }

    private func loadSubtitleFile(url: String) {
        guard let u = URL(string: url) else { return }
        var req = URLRequest(url: u)
        req.setValue("SingularityTV/2.7.3", forHTTPHeaderField: "User-Agent")
        URLSession.shared.dataTask(with: req) { [weak self] data, _, _ in
            guard let self = self, let data = data, let text = self.decodeSubtitleData(data) else { return }
            let parsed = self.parseSrtOrVtt(text)
            DispatchQueue.main.async {
                self.activeCues = parsed
                self.updateTimeAndSubtitles()
            }
        }.resume()
    }

    private func parseSrtOrVtt(_ raw: String) -> [IosSubCue] {
        var cues: [IosSubCue] = []
        let cleaned = raw
            .replacingOccurrences(of: "\u{FEFF}", with: "")
            .replacingOccurrences(of: "\r\n", with: "\n")
            .replacingOccurrences(of: "\r", with: "\n")
        let lines = cleaned.components(separatedBy: "\n")
        var i = 0
        while i < lines.count {
            let line = lines[i].trimmingCharacters(in: .whitespaces)
            if line.contains("-->") {
                let parts = line.components(separatedBy: "-->")
                if parts.count >= 2 {
                    let startStr = parts[0].trimmingCharacters(in: .whitespaces).components(separatedBy: " ").first ?? parts[0]
                    let endStr = parts[1].trimmingCharacters(in: .whitespaces).components(separatedBy: " ").first ?? parts[1]
                    let start = parseTimestamp(startStr)
                    let end = parseTimestamp(endStr)
                    var bodyLines: [String] = []
                    var j = i + 1
                    while j < lines.count {
                        let nextLine = lines[j].trimmingCharacters(in: .whitespaces)
                        if nextLine.isEmpty || nextLine.contains("-->") { break }
                        bodyLines.append(nextLine)
                        j += 1
                    }
                    let body = bodyLines.joined(separator: "\n")
                        .replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression)
                        .trimmingCharacters(in: .whitespacesAndNewlines)
                    if !body.isEmpty && end > start {
                        cues.append(IosSubCue(startSec: start, endSec: end, text: body))
                    }
                    i = j
                    continue
                }
            }
            i += 1
        }
        return cues
    }

    private func parseTimestamp(_ raw: String) -> Double {
        let clean = raw.trimmingCharacters(in: .whitespaces).replacingOccurrences(of: ",", with: ".")
        let comps = clean.components(separatedBy: ":")
        if comps.count == 3 {
            return (Double(comps[0]) ?? 0) * 3600 + (Double(comps[1]) ?? 0) * 60 + (Double(comps[2]) ?? 0)
        } else if comps.count == 2 {
            return (Double(comps[0]) ?? 0) * 60 + (Double(comps[1]) ?? 0)
        }
        return Double(clean) ?? 0
    }

    private func saveProgress(forceCompleted: Bool) {
        guard !progressKey.isEmpty, let player = player else { return }
        let pos = CMTimeGetSeconds(player.currentTime())
        let dur = CMTimeGetSeconds(player.currentItem?.duration ?? .zero)
        guard pos.isFinite, dur.isFinite, dur > 0 else { return }
        let pct = forceCompleted ? 100 : min(100, max(0, Int((pos / dur) * 100)))
        let watched = forceCompleted || (dur - pos <= 20)
        onProgressUpdate?(progressKey, pct, Int(pos), Int(dur), watched)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        gestureMode = 0
        gestureStartPoint = touch.location(in: view)
        if gestureStartPoint.x < view.bounds.width * 0.5 {
            gestureStartVal = UIScreen.main.brightness
        } else {
            gestureStartVal = CGFloat(AVAudioSession.sharedInstance().outputVolume)
        }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let p = touch.location(in: view)
        let w = max(1, view.bounds.width)
        let h = max(1, view.bounds.height)
        let dx = p.x - gestureStartPoint.x
        let dy = gestureStartPoint.y - p.y
        let inSafeY = gestureStartPoint.y >= h * 0.14 && gestureStartPoint.y <= h * 0.84
        let inLeft = gestureStartPoint.x >= 20 && gestureStartPoint.x <= w * 0.24
        let inRight = gestureStartPoint.x >= w * 0.76 && gestureStartPoint.x <= w - 20

        if gestureMode == 0 && inSafeY && (inLeft || inRight) && abs(dy) > 20 && abs(dy) > abs(dx) * 1.25 {
            gestureMode = inLeft ? 1 : 2
        }
        if gestureMode != 0 {
            let nextVal = min(1, max(0, gestureStartVal + dy / (h * 0.6)))
            hideHudWorkItem?.cancel()
            if gestureMode == 1 {
                UIScreen.main.brightness = max(0.04, nextVal)
                brightnessPctLabel.text = "\(Int(nextVal * 100))%"
                brightnessHudView.isHidden = false
                let trackH = brightnessTrackView.bounds.height > 10 ? brightnessTrackView.bounds.height : 128
                brightnessFillHeightConstraint?.constant = max(2, trackH * nextVal)
                brightnessHudView.layoutIfNeeded()
            } else {
                if let slider = hiddenVolumeView.subviews.compactMap({ $0 as? UISlider }).first {
                    slider.value = Float(nextVal)
                }
                volumePctLabel.text = "\(Int(nextVal * 100))%"
                volumeHudView.isHidden = false
                let trackH = volumeTrackView.bounds.height > 10 ? volumeTrackView.bounds.height : 128
                volumeFillHeightConstraint?.constant = max(2, trackH * nextVal)
                volumeHudView.layoutIfNeeded()
            }
            let item = DispatchWorkItem { [weak self] in
                self?.brightnessHudView.isHidden = true
                self?.volumeHudView.isHidden = true
            }
            hideHudWorkItem = item
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.9, execute: item)
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if gestureMode != 0 {
            gestureMode = 0
            return
        }
        guard let touch = touches.first else { return }
        let p = touch.location(in: view)
        let dist = hypot(p.x - gestureStartPoint.x, p.y - gestureStartPoint.y)
        if dist > 18 { return }

        let now = Date().timeIntervalSince1970
        let w = view.bounds.width
        let tapSide = p.x < w * 0.42 ? -1 : (p.x > w * 0.58 ? 1 : 0)

        if tapSide != 0 && activeSeekSide == tapSide && (now - lastSeekEventTime) < 1.25 {
            singleTapWorkItem?.cancel()
            triggerMultiTapSeek(side: tapSide)
        } else if tapSide != 0 && tapSide == lastTapSide && (now - lastTapTime) < 0.52 {
            singleTapWorkItem?.cancel()
            lastTapTime = 0
            triggerMultiTapSeek(side: tapSide)
        } else if tapSide == 0 {
            singleTapWorkItem?.cancel()
            lastTapTime = 0
            lastTapSide = 0
            setControllerVisible(!isControllerVisible)
        } else {
            lastTapTime = now
            lastTapSide = tapSide
            singleTapWorkItem?.cancel()
            let item = DispatchWorkItem { [weak self] in
                guard let self = self, self.activeSeekSide == 0 else { return }
                self.setControllerVisible(!self.isControllerVisible)
            }
            singleTapWorkItem = item
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.36, execute: item)
        }
    }

    private func triggerMultiTapSeek(side: Int) {
        activeSeekSide = side
        lastSeekEventTime = Date().timeIntervalSince1970
        seekBy(side < 0 ? -10 : 10)
        if side < 0 {
            accumLeftSeek += 10
            leftSeekBadge.text = "« -\(accumLeftSeek)s"
            leftSeekBadge.isHidden = false
            hideLeftSeekWorkItem?.cancel()
            let item = DispatchWorkItem { [weak self] in
                self?.accumLeftSeek = 0
                if self?.activeSeekSide == -1 { self?.activeSeekSide = 0 }
                self?.leftSeekBadge.isHidden = true
            }
            hideLeftSeekWorkItem = item
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.1, execute: item)
        } else {
            accumRightSeek += 10
            rightSeekBadge.text = "+\(accumRightSeek)s »"
            rightSeekBadge.isHidden = false
            hideRightSeekWorkItem?.cancel()
            let item = DispatchWorkItem { [weak self] in
                self?.accumRightSeek = 0
                if self?.activeSeekSide == 1 { self?.activeSeekSide = 0 }
                self?.rightSeekBadge.isHidden = true
            }
            hideRightSeekWorkItem = item
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.1, execute: item)
        }
    }
}
