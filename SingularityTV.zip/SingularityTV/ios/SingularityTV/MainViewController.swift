import UIKit
import WebKit

class MainViewController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate {
    private var webView: WKWebView!
    private var lastM3u8Url: String = ""
    private var lastM3u8Time: TimeInterval = 0
    private weak var activePlayerVC: NativePlayerViewController?

    override var preferredStatusBarStyle: UIStatusBarStyle { .lightContent }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor(red: 8/255, green: 10/255, blue: 15/255, alpha: 1)

        let config = WKWebViewConfiguration()
        config.websiteDataStore = WKWebsiteDataStore.default()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.preferences.javaScriptCanOpenWindowsAutomatically = false
        config.preferences.setValue(true, forKey: "allowFileAccessFromFileURLs")
        config.setValue(true, forKey: "allowUniversalAccessFromFileURLs")

        let ucc = WKUserContentController()
        ucc.add(self, name: "SingularityBridge")
        ucc.add(self, name: "StreamSniffer")

        let snifferJs = """
        (function(){
          if (window.__sbSnifferInstalled) return;
          window.__sbSnifferInstalled = true;
          function post(kind, url) {
            try {
              if (!url || typeof url !== 'string') return;
              window.webkit.messageHandlers.StreamSniffer.postMessage({ kind: kind, url: url, ref: location.href });
            } catch(e) {}
          }
          function checkUrl(u) {
            if (!u || typeof u !== 'string') return;
            var l = u.toLowerCase();
            if (l.indexOf('.m3u8') !== -1 || l.indexOf('.mpd') !== -1 || l.indexOf('master.txt') !== -1 || l.indexOf('playlist.txt') !== -1 || l.indexOf('/hls/') !== -1) {
              post('m3u8', u);
            } else if (l.indexOf('.mp4') !== -1 && l.indexOf('favicon') === -1 && l.indexOf('preview') === -1 && l.indexOf('trailer') === -1 && l.indexOf('logo') === -1) {
              post('m3u8', u);
            } else if (l.indexOf('.vtt') !== -1 || l.indexOf('.srt') !== -1) {
              post('sub', u);
            }
          }
          if (window.fetch) {
            var origFetch = window.fetch;
            window.fetch = function(input) {
              try { checkUrl(typeof input === 'string' ? input : (input && input.url)); } catch(e) {}
              return origFetch.apply(this, arguments);
            };
          }
          if (window.XMLHttpRequest) {
            var origOpen = XMLHttpRequest.prototype.open;
            XMLHttpRequest.prototype.open = function(m, u) {
              try { checkUrl(u); } catch(e) {}
              return origOpen.apply(this, arguments);
            };
          }
          try {
            var po = new PerformanceObserver(function(list) {
              list.getEntries().forEach(function(e) { checkUrl(e.name); });
            });
            po.observe({ entryTypes: ['resource'] });
          } catch(e) {}
        })();
        """
        ucc.addUserScript(WKUserScript(source: snifferJs, injectionTime: .atDocumentStart, forMainFrameOnly: false))
        config.userContentController = ucc

        webView = WKWebView(frame: .zero, configuration: config)
        webView.translatesAutoresizingMaskIntoConstraints = false
        webView.isOpaque = false
        webView.backgroundColor = UIColor(red: 8/255, green: 10/255, blue: 15/255, alpha: 1)
        webView.scrollView.backgroundColor = UIColor(red: 8/255, green: 10/255, blue: 15/255, alpha: 1)
        webView.scrollView.contentInsetAdjustmentBehavior = .never
        webView.navigationDelegate = self
        webView.uiDelegate = self
        webView.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"

        view.addSubview(webView)
        NSLayoutConstraint.activate([
            webView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor),
            webView.bottomAnchor.constraint(equalTo: view.bottomAnchor),
            webView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor),
            webView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor)
        ])

        loadAppBundle()
    }

    private func loadAppBundle() {
        let baseOrigin = URL(string: "https://ios.singularitytv.local/app/index.html")!
        let bundlePath = Bundle.main.bundlePath
        let standalonePaths = [
            bundlePath + "/WebAssets/standalone.html",
            bundlePath + "/standalone.html"
        ]
        for path in standalonePaths {
            if let html = try? String(contentsOfFile: path, encoding: .utf8), !html.isEmpty {
                webView.loadHTMLString(html, baseURL: baseOrigin)
                return
            }
        }
        let cssPaths = [bundlePath + "/WebAssets/global.css", bundlePath + "/global.css"]
        let jsPaths = [bundlePath + "/WebAssets/bundle.js", bundlePath + "/bundle.js"]
        var cssContent = ""
        var jsContent = ""
        for p in cssPaths {
            if let s = try? String(contentsOfFile: p, encoding: .utf8), !s.isEmpty { cssContent = s; break }
        }
        for p in jsPaths {
            if let s = try? String(contentsOfFile: p, encoding: .utf8), !s.isEmpty { jsContent = s; break }
        }
        if !jsContent.isEmpty {
            let combinedHtml = """
            <!doctype html>
            <html lang="en">
            <head>
              <meta charset="UTF-8" />
              <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" />
              <title>SingularityTV</title>
              <style>\(cssContent)</style>
            </head>
            <body>
              <div id="root"></div>
              <script>\(jsContent)</script>
            </body>
            </html>
            """
            webView.loadHTMLString(combinedHtml, baseURL: baseOrigin)
            return
        }
        if let htmlUrl = Bundle.main.url(forResource: "index", withExtension: "html", subdirectory: "WebAssets") ?? Bundle.main.url(forResource: "index", withExtension: "html") {
            let folderUrl = htmlUrl.deletingLastPathComponent()
            webView.loadFileURL(htmlUrl, allowingReadAccessTo: folderUrl)
        }
    }

    func dispatchToReact(channel: String, payloadJson: String) {
        let safeChannel = String(data: try! JSONSerialization.data(withJSONObject: [channel]), encoding: .utf8) ?? "[\"\"]"
        let js = "window.__streambertDispatch && window.__streambertDispatch((\(safeChannel))[0], \(payloadJson));"
        DispatchQueue.main.async {
            self.webView.evaluateJavaScript(js, completionHandler: nil)
        }
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        if message.name == "StreamSniffer" {
            guard let dict = message.body as? [String: Any],
                  let kind = dict["kind"] as? String,
                  let url = dict["url"] as? String else { return }
            if kind == "m3u8" {
                let now = Date().timeIntervalSince1970
                if url != lastM3u8Url || now - lastM3u8Time > 2.5 {
                    lastM3u8Url = url
                    lastM3u8Time = now
                    if let data = try? JSONSerialization.data(withJSONObject: [url]),
                       let arr = String(data: data, encoding: .utf8) {
                        let quoted = String(arr.dropFirst().dropLast())
                        dispatchToReact(channel: "m3u8-found", payloadJson: quoted)
                    }
                }
            } else if kind == "sub" {
                let payload: [String: Any] = ["url": url, "lang": "en"]
                if let data = try? JSONSerialization.data(withJSONObject: payload),
                   let str = String(data: data, encoding: .utf8) {
                    dispatchToReact(channel: "subtitle-found", payloadJson: str)
                }
            }
            return
        }

        if message.name == "SingularityBridge" {
            guard let body = message.body as? [String: Any],
                  let method = body["method"] as? String else { return }
            let args = body["args"] as? [Any] ?? []

            if method == "openExoPlayer", let payloadStr = args.first as? String {
                let playerVC = NativePlayerViewController(payloadJson: payloadStr)
                playerVC.modalPresentationStyle = .fullScreen
                playerVC.onProgressUpdate = { [weak self] key, pct, posSec, durSec, watched in
                    let payload: [String: Any] = [
                        "progressKey": key,
                        "percent": pct,
                        "positionSec": posSec,
                        "durationSec": durSec,
                        "watched": watched
                    ]
                    if let data = try? JSONSerialization.data(withJSONObject: payload),
                       let str = String(data: data, encoding: .utf8) {
                        self?.dispatchToReact(channel: "exo-progress", payloadJson: str)
                    }
                }
                playerVC.onPreferredSource = { [weak self] sourceId in
                    if let data = try? JSONSerialization.data(withJSONObject: [sourceId]),
                       let arr = String(data: data, encoding: .utf8) {
                        let quoted = String(arr.dropFirst().dropLast())
                        self?.dispatchToReact(channel: "preferred-source-updated", payloadJson: quoted)
                    }
                }
                activePlayerVC = playerVC
                present(playerVC, animated: true)
            } else if method == "deliverNextServerStream" {
                let url = args.first as? String ?? ""
                let sourceId = args.count > 1 ? (args[1] as? String ?? "") : ""
                activePlayerVC?.applyExternalResolvedStream(url: url, sourceId: sourceId)
            }
        }
    }

    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
        if let saved = UserDefaults.standard.string(forKey: "streambert_lastWorkingSource"), !saved.isEmpty {
            if let data = try? JSONSerialization.data(withJSONObject: [saved]),
               let arr = String(data: data, encoding: .utf8) {
                let quoted = String(arr.dropFirst().dropLast())
                dispatchToReact(channel: "preferred-source-updated", payloadJson: quoted)
            }
        }
    }

    func webView(
        _ webView: WKWebView,
        createWebViewWith configuration: WKWebViewConfiguration,
        for navigationAction: WKNavigationAction,
        windowFeatures: WKWindowFeatures
    ) -> WKWebView? {
        return nil
    }
}
