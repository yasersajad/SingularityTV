-keepattributes JavascriptInterface
-keepattributes *Annotation*
-keepclassmembers class com.singularity.tv.bridge.StreambertJsBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.singularity.tv.** { *; }
-keep class androidx.media3.** { *; }
-dontwarn okhttp3.**
