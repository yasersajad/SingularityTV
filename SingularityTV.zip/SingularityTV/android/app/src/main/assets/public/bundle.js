
(function() {

  let safeStorage;
  try {
    const testKey = "__sb_test__";
    window.localStorage.setItem(testKey, "1");
    window.localStorage.removeItem(testKey);
    safeStorage = window.localStorage;
  } catch (e) {
    const mem = new Map();
    safeStorage = {
      getItem: (k) => (mem.has(String(k)) ? mem.get(String(k)) : null),
      setItem: (k, v) => { mem.set(String(k), String(v)); },
      removeItem: (k) => { mem.delete(String(k)); },
      clear: () => { mem.clear(); },
      key: (i) => Array.from(mem.keys())[i] ?? null,
      get length() { return mem.size; }
    };
    try {
      Object.defineProperty(window, "localStorage", { value: safeStorage, configurable: true });
    } catch (_) {}
  }
  const localStorage = safeStorage;

  const componentHooksMap = new Map();
  const classInstanceMap = new Map(); 
  let compStack = [];
  let mountedKeysThisPass = new Set();
  let prevMountedKeys = new Set();
  let rootRenderFn = null;
  let renderScheduled = false;
  const pendingEffects = [];

  function getCurrentComp() {
    return compStack[compStack.length - 1] || { key: "root", hookIdx: 0 };
  }

  function getHookSlot() {
    const comp = getCurrentComp();
    if (!componentHooksMap.has(comp.key)) {
      componentHooksMap.set(comp.key, []);
    }
    const slots = componentHooksMap.get(comp.key);
    const idx = comp.hookIdx++;
    return { slots, idx, compKey: comp.key };
  }

  function scheduleRender() {
    if (renderScheduled) return;
    renderScheduled = true;
    Promise.resolve().then(() => {
      renderScheduled = false;
      if (rootRenderFn) rootRenderFn();
    });
  }

  const React = {
    Fragment: Symbol.for("react.fragment"),
    StrictMode: function StrictMode(props) { return props.children; },
    Suspense: function Suspense(props) { return props.children; },
    Component: class Component {
      constructor(props) { this.props = props || {}; this.state = {}; }
      setState(updater) {
        const next = typeof updater === "function" ? updater(this.state) : updater;
        this.state = Object.assign({}, this.state, next);
        scheduleRender();
      }
    },
    createElement(type, props, ...children) {
      const flatChildren = [];
      const pushChild = (c) => {
        if (Array.isArray(c)) c.forEach(pushChild);
        else flatChildren.push(c);
      };
      children.forEach(pushChild);
      return {
        $$typeof: Symbol.for("react.element"),
        type,
        props: Object.assign({}, props, {
          children: flatChildren.length === 0 ? undefined : flatChildren.length === 1 ? flatChildren[0] : flatChildren
        }),
        key: props && props.key !== undefined ? String(props.key) : null,
        ref: props && props.ref !== undefined ? props.ref : null,
      };
    },
    useState(initial) {
      const { slots, idx, compKey } = getHookSlot();
      if (slots[idx] === undefined) {
        slots[idx] = typeof initial === "function" ? initial() : initial;
      }
      const setState = (updater) => {
        const targetSlots = componentHooksMap.get(compKey);
        if (!targetSlots) return;
        const next = typeof updater === "function" ? updater(targetSlots[idx]) : updater;
        if (!Object.is(targetSlots[idx], next)) {
          targetSlots[idx] = next;
          scheduleRender();
        }
      };
      return [slots[idx], setState];
    },
    useRef(initial) {
      const { slots, idx } = getHookSlot();
      if (slots[idx] === undefined) {
        slots[idx] = { current: initial };
      }
      return slots[idx];
    },
    useMemo(factory, deps) {
      const { slots, idx } = getHookSlot();
      const prev = slots[idx];
      if (!prev || !deps || !prev.deps || deps.length !== prev.deps.length || deps.some((d, i) => !Object.is(d, prev.deps[i]))) {
        const val = factory();
        slots[idx] = { val, deps };
        return val;
      }
      return prev.val;
    },
    useCallback(fn, deps) {
      return React.useMemo(() => fn, deps);
    },
    useEffect(effect, deps) {
      const { slots, idx } = getHookSlot();
      const prev = slots[idx];
      const changed = !prev || !deps || !prev.deps || deps.length !== prev.deps.length || deps.some((d, i) => !Object.is(d, prev.deps[i]));
      if (changed) {
        const slotObj = { isEffect: true, deps, cleanup: prev ? prev.cleanup : null };
        slots[idx] = slotObj;
        pendingEffects.push(() => {
          if (typeof slotObj.cleanup === "function") {
            try { slotObj.cleanup(); } catch (e) {}
          }
          const c = effect();
          slotObj.cleanup = typeof c === "function" ? c : null;
        });
      }
    },
    useLayoutEffect(effect, deps) {
      return React.useEffect(effect, deps);
    },
    memo(comp) { return comp; },
    forwardRef(render) {
      return function ForwardRefWrapper(props) {
        return render(props, props.ref || null);
      };
    },
    useImperativeHandle(ref, createHandle) {
      if (ref) {
        const h = createHandle();
        if (typeof ref === "function") ref(h);
        else ref.current = h;
      }
    },
    lazy(loader) {
      let resolved = null;
      let loading = false;
      return function LazyWrapper(props) {
        if (!resolved) {
          if (!loading) {
            loading = true;
            loader().then((m) => {
              resolved = m.default || m;
              scheduleRender();
            });
          }
          return null;
        }
        return React.createElement(resolved, props);
      };
    }
  };

  const SVG_TAGS = new Set([
    "svg", "path", "circle", "rect", "line", "polyline", "polygon", "ellipse", "g", "defs", "linearGradient", "stop", "text"
  ]);
  const UNITLESS_STYLES = new Set([
    "opacity", "zIndex", "flex", "flexGrow", "flexShrink", "fontWeight", "lineHeight", "order", "zoom", "scale"
  ]);


  function expandToHostList(vnode, pathPrefix, out = []) {
    if (vnode === null || vnode === undefined || typeof vnode === "boolean") {
      out.push({ kind: "empty", key: null });
      return out;
    }
    if (typeof vnode === "string" || typeof vnode === "number") {
      out.push({ kind: "text", text: String(vnode), key: null });
      return out;
    }
    if (Array.isArray(vnode)) {
      for (let i = 0; i < vnode.length; i++) {
        expandToHostList(vnode[i], pathPrefix + "." + i, out);
      }
      return out;
    }
    if (vnode.type === React.Fragment) {
      const ch = vnode.props?.children;
      if (Array.isArray(ch)) {
        for (let i = 0; i < ch.length; i++) {
          expandToHostList(ch[i], pathPrefix + ".f" + i, out);
        }
      } else if (ch !== undefined) {
        expandToHostList(ch, pathPrefix + ".f0", out);
      }
      return out;
    }
    if (typeof vnode.type === "function") {
      const compName = vnode.type.displayName || vnode.type.name || "Anon";
      const compKey = pathPrefix + "/" + compName + (vnode.key !== null ? "#" + vnode.key : "");
      mountedKeysThisPass.add(compKey);
      compStack.push({ key: compKey, hookIdx: 0 });
      let rendered;
      try {
        if (vnode.type.prototype && vnode.type.prototype.render) {
          let inst = classInstanceMap.get(compKey);
          if (!inst) {
            inst = new vnode.type(vnode.props || {});
            classInstanceMap.set(compKey, inst);
          } else {
            inst.props = vnode.props || {};
          }
          rendered = inst.render();
        } else {
          rendered = vnode.type(vnode.props || {});
        }
      } finally {
        compStack.pop();
      }
      expandToHostList(rendered, compKey, out);
      return out;
    }
    if (typeof vnode.type === "string") {
      const props = vnode.props || {};
      const ch = props.children;
      const expandedChildren = [];
      if (Array.isArray(ch)) {
        for (let i = 0; i < ch.length; i++) {
          expandToHostList(ch[i], pathPrefix + "." + i, expandedChildren);
        }
      } else if (ch !== undefined) {
        expandToHostList(ch, pathPrefix + ".0", expandedChildren);
      }
      out.push({
        kind: "host",
        type: vnode.type,
        props,
        key: vnode.key,
        ref: vnode.ref,
        children: expandedChildren,
      });
      return out;
    }
    out.push({ kind: "empty", key: null });
    return out;
  }

  function applyProp(el, k, v, prevV, isSvg, tagType) {
    if (k === "children" || k === "key" || k === "ref") return;
    if (k === "className") {
      const nextCls = v || "";
      if (prevV !== nextCls) {
        if (isSvg) el.setAttribute("class", nextCls);
        else el.className = nextCls;
      }
      return;
    }
    if (k === "style") {
      const prevStyle = (prevV && typeof prevV === "object") ? prevV : {};
      const nextStyle = (v && typeof v === "object") ? v : {};
      for (const sk of Object.keys(prevStyle)) {
        if (!(sk in nextStyle) || nextStyle[sk] === undefined || nextStyle[sk] === null) {
          if (sk.startsWith("--")) el.style.removeProperty(sk);
          else el.style[sk] = "";
        }
      }
      for (const [sk, sv] of Object.entries(nextStyle)) {
        if (sv === undefined || sv === null) continue;
        if (prevStyle[sk] === sv) continue;
        if (sk.startsWith("--")) el.style.setProperty(sk, String(sv));
        else if (typeof sv === "number" && !UNITLESS_STYLES.has(sk)) {
          el.style[sk] = sv + "px";
        } else {
          el.style[sk] = sv;
        }
      }
      return;
    }
    if (k.startsWith("on")) {
      const rawEv = k.slice(2).toLowerCase();
      const evName = rawEv === "doubleclick" ? "dblclick" : (rawEv === "change" && tagType === "input" ? "input" : rawEv);
      if (!el.__sbListeners) el.__sbListeners = {};
      if (!el.__sbBound) el.__sbBound = {};
      el.__sbListeners[evName] = typeof v === "function" ? v : null;
      if (!el.__sbBound[evName] && typeof v === "function") {
        const wrapper = (e) => {
          const fn = el.__sbListeners && el.__sbListeners[evName];
          if (typeof fn === "function") fn(e);
        };
        el.__sbBound[evName] = wrapper;
        el.addEventListener(evName, wrapper);
      }
      return;
    }
    if (v === prevV) return;
    if (k === "src" && tagType === "iframe") {
      const nextSrc = v ? String(v) : "about:blank";
      if (el.__sbIframeSrc !== nextSrc) {
        el.__sbIframeSrc = nextSrc;
        el.setAttribute("src", nextSrc);
      }
      return;
    }
    if (k === "value" && (tagType === "input" || tagType === "textarea" || tagType === "select")) {
      const nextStr = v === undefined || v === null ? "" : String(v);
      if (el.value !== nextStr) el.value = nextStr;
      return;
    }
    if (k === "checked" && tagType === "input") {
      el.checked = !!v;
      return;
    }
    if (k === "disabled") {
      if (v) el.setAttribute("disabled", "disabled");
      else el.removeAttribute("disabled");
      return;
    }
    if (v === undefined || v === null || v === false) {
      el.removeAttribute(k);
      return;
    }
    if (v === true) {
      el.setAttribute(k, "");
      return;
    }
    const attrName = k === "viewBox" ? "viewBox" : (isSvg ? k.replace(/([A-Z])/g, (m) => "-" + m.toLowerCase()) : k);
    el.setAttribute(attrName, String(v));
  }

  function patchHostProps(el, prevProps, nextProps, isSvg, tagType) {
    for (const k of Object.keys(prevProps)) {
      if (!(k in nextProps)) {
        applyProp(el, k, undefined, prevProps[k], isSvg, tagType);
      }
    }
    for (const [k, v] of Object.entries(nextProps)) {
      applyProp(el, k, v, prevProps[k], isSvg, tagType);
    }
    el.__sbProps = nextProps;
  }

  function createDomFromDescriptor(desc) {
    if (desc.kind === "empty") {
      const c = document.createComment("sb");
      c.__sbKind = "empty";
      return c;
    }
    if (desc.kind === "text") {
      const t = document.createTextNode(desc.text);
      t.__sbKind = "text";
      return t;
    }
    const isSvg = SVG_TAGS.has(desc.type);
    const el = isSvg
      ? document.createElementNS("http://www.w3.org/2000/svg", desc.type)
      : document.createElement(desc.type);
    el.__sbKind = "host";
    el.__sbType = desc.type;
    el.__sbKey = desc.key;
    el.__sbProps = {};
    patchHostProps(el, {}, desc.props, isSvg, desc.type);
    reconcileChildren(el, desc.children);
    if (desc.ref) {
      if (typeof desc.ref === "function") desc.ref(el);
      else desc.ref.current = el;
    }
    return el;
  }

  function canReuseDom(domNode, desc) {
    if (!domNode) return false;
    if (desc.kind === "empty") return domNode.nodeType === 8 && domNode.__sbKind === "empty";
    if (desc.kind === "text") return domNode.nodeType === 3;
    if (desc.kind === "host") {
      return (
        domNode.nodeType === 1 &&
        domNode.__sbType === desc.type &&
        (domNode.__sbKey ?? null) === (desc.key ?? null)
      );
    }
    return false;
  }

  function reconcileChildren(parentDom, nextDescs) {
    const existingNodes = Array.from(parentDom.childNodes);
    const keyedMap = new Map();
    for (const node of existingNodes) {
      if (node.nodeType === 1 && node.__sbKey != null) {
        keyedMap.set(node.__sbType + "#" + node.__sbKey, node);
      }
    }

    const usedNodes = new Set();
    const finalNodes = new Array(nextDescs.length);

    for (let i = 0; i < nextDescs.length; i++) {
      const desc = nextDescs[i];
      let matched = null;

      if (desc.kind === "host" && desc.key != null) {
        const k = desc.type + "#" + desc.key;
        const cand = keyedMap.get(k);
        if (cand && !usedNodes.has(cand)) {
          matched = cand;
        }
      } else {
        const positional = existingNodes[i];
        if (positional && !usedNodes.has(positional) && canReuseDom(positional, desc)) {
          matched = positional;
        }
      }

      if (matched) {
        usedNodes.add(matched);
        if (desc.kind === "text") {
          if (matched.nodeValue !== desc.text) {
            matched.nodeValue = desc.text;
          }
        } else if (desc.kind === "host") {
          const isSvg = SVG_TAGS.has(desc.type);
          patchHostProps(matched, matched.__sbProps || {}, desc.props, isSvg, desc.type);
          reconcileChildren(matched, desc.children);
          if (desc.ref) {
            if (typeof desc.ref === "function") desc.ref(matched);
            else desc.ref.current = matched;
          }
        }
        finalNodes[i] = matched;
      } else {
        finalNodes[i] = createDomFromDescriptor(desc);
      }
    }

    for (const oldNode of existingNodes) {
      if (!usedNodes.has(oldNode) && oldNode.parentNode === parentDom) {
        parentDom.removeChild(oldNode);
      }
    }

    for (let i = 0; i < finalNodes.length; i++) {
      const node = finalNodes[i];
      const currentAtPos = parentDom.childNodes[i] || null;
      if (currentAtPos !== node) {
        parentDom.insertBefore(node, currentAtPos);
      }
    }
  }

  const ReactDOMClient = {
    createRoot(container) {
      return {
        render(element) {
          rootRenderFn = () => {
            compStack = [];
            mountedKeysThisPass = new Set();
            const hostDescs = expandToHostList(element, "root");
            reconcileChildren(container, hostDescs);

            for (const oldKey of prevMountedKeys) {
              if (!mountedKeysThisPass.has(oldKey)) {
                const slots = componentHooksMap.get(oldKey) || [];
                for (const s of slots) {
                  if (s && s.isEffect && typeof s.cleanup === "function") {
                    try { s.cleanup(); } catch (e) {}
                  }
                }
                componentHooksMap.delete(oldKey);
                classInstanceMap.delete(oldKey);
              }
            }
            prevMountedKeys = new Set(mountedKeysThisPass);
            while (pendingEffects.length > 0) {
              const eff = pendingEffects.shift();
              try { eff(); } catch (e) { console.error(e); }
            }
          };
          rootRenderFn();
        }
      };
    }
  };
  window.React = React;
  window.ReactDOM = ReactDOMClient;

  const moduleFactories = {
"./App": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = App;
var _react = require("react");
var _androidBridge = require("./utils/androidBridge");
var _ErrorBoundary = _interopRequireDefault(require("./components/ErrorBoundary"));
var _ExoPlayerOverlay = _interopRequireDefault(require("./components/ExoPlayerOverlay"));
var _storage = require("./utils/storage");
var _appearance = require("./utils/appearance");
var _backup = require("./utils/backup");
var _api = require("./utils/api");
var _TopNav = _interopRequireDefault(require("./components/TopNav"));
var _liveTouch = require("./utils/liveTouch");
var _SearchModal = _interopRequireDefault(require("./components/SearchModal"));
var _CloseConfirmModal = _interopRequireDefault(require("./components/CloseConfirmModal"));
var _UpdateModal = _interopRequireDefault(require("./components/UpdateModal"));
var _useGamepadNav = require("./utils/useGamepadNav");
var _updates = require("./utils/updates");
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function (nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
const HomePage = (0, _react.lazy)(() => Promise.resolve().then(() => _interopRequireWildcard(require("./pages/HomePage"))));
const MoviePage = (0, _react.lazy)(() => Promise.resolve().then(() => _interopRequireWildcard(require("./pages/MoviePage"))));
const TVPage = (0, _react.lazy)(() => Promise.resolve().then(() => _interopRequireWildcard(require("./pages/TVPage"))));
const LibraryPage = (0, _react.lazy)(() => Promise.resolve().then(() => _interopRequireWildcard(require("./pages/LibraryPage"))));
const SettingsPage = (0, _react.lazy)(() => Promise.resolve().then(() => _interopRequireWildcard(require("./pages/SettingsPage"))));
const DownloadsPage = (0, _react.lazy)(() => Promise.resolve().then(() => _interopRequireWildcard(require("./pages/DownloadsPage"))));
function App() {
  const apiKey = "KEYLESS_ANDROID_MODE";
  const [page, setPage] = (0, _react.useState)(() => _storage.storage.get("startPage") || "home");
  const [selected, setSelected] = (0, _react.useState)(null);
  const [showSearch, setShowSearch] = (0, _react.useState)(false);
  const [dlSearchOpen, setDlSearchOpen] = (0, _react.useState)(false);
  const [librarySort, setLibrarySort] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.LIBRARY_SORT) || "manual");
  const [isTvMode, setIsTvMode] = (0, _react.useState)(() => (0, _androidBridge.isAndroidTvDevice)());
  const [exoSession, setExoSession] = (0, _react.useState)(null);
  const [navStack, setNavStack] = (0, _react.useState)([]);
  const [saved, setSaved] = (0, _react.useState)(() => _storage.storage.get("saved") || {});
  const [savedOrder, setSavedOrder] = (0, _react.useState)(() => _storage.storage.get("savedOrder") || null);
  const [progress, setProgress] = (0, _react.useState)(() => _storage.storage.get("progress") || {});
  const [history, setHistory] = (0, _react.useState)(() => _storage.storage.get("history") || []);
  const [watched, setWatched] = (0, _react.useState)(() => _storage.storage.get("watched") || {});
  const [toast, setToast] = (0, _react.useState)(null);
  const [updateBanner, setUpdateBanner] = (0, _react.useState)(null);
  const [showUpdateModal, setShowUpdateModal] = (0, _react.useState)(false);
  const [episodeCheckStatus, setEpisodeCheckStatus] = (0, _react.useState)(null);
  const episodeDismissTimerRef = (0, _react.useRef)(null);
  const [trending, setTrending] = (0, _react.useState)([]);
  const [trendingTV, setTrendingTV] = (0, _react.useState)([]);
  const [loadingHome, setLoadingHome] = (0, _react.useState)(false);
  const [offline, setOffline] = (0, _react.useState)(() => !navigator.onLine);
  const readPlayerSettings = () => {
    const accentId = _storage.storage.get(_storage.STORAGE_KEYS.ACCENT_COLOR) || "red";
    const inPlayer = _storage.storage.get(_storage.STORAGE_KEYS.ACCENT_IN_PLAYER) !== false;
    const accentHex = inPlayer ? _appearance.ACCENT_PRESETS.find(p => p.id === accentId)?.color ?? null : null;
    const subtitleLang = _storage.storage.get(_storage.STORAGE_KEYS.SUBTITLE_LANG) || null;
    return {
      accentColor: accentHex,
      subtitleLang
    };
  };
  const [playerSettings, setPlayerSettings] = (0, _react.useState)(readPlayerSettings);
  (0, _react.useEffect)(() => {
    (0, _liveTouch.initLiveTouch)();
    const h = window.electron?.onPreferredSourceUpdated?.(srcId => {
      if (srcId && typeof srcId === "string") {
        _storage.storage.set("playerSource", srcId);
      }
    });
    return () => {
      if (h) window.electron?.offPreferredSourceUpdated?.(h);
    };
  }, []);
  (0, _react.useEffect)(() => {
    const updateDeviceClass = () => {
      const tv = (0, _androidBridge.isAndroidTvDevice)();
      setIsTvMode(tv);
      document.documentElement.setAttribute("data-device-type", tv ? "tv" : "mobile");
      document.body.classList.toggle("tv-mode", tv);
    };
    updateDeviceClass();
    window.addEventListener("streambert:tv-mode-changed", updateDeviceClass);
    return () => window.removeEventListener("streambert:tv-mode-changed", updateDeviceClass);
  }, []);
  (0, _react.useEffect)(() => {
    const h = _androidBridge.androidBridge.onM3u8Found ? null : null;
    const handler = args => setExoSession(args);
    window.addEventListener("streambert:open-exo-overlay", e => setExoSession(e.detail));
    return () => {};
  }, []);
  (0, _react.useEffect)(() => {
    if (!window.electron?.onScheduledBackupRequested) return;
    const handler = window.electron.onScheduledBackupRequested(async () => {
      try {
        const settings = await window.electron.getScheduledBackupSettings();
        if (!settings?.enabled || !settings?.path) return;
        const data = (0, _backup.collectBackupData)();
        await window.electron.performScheduledBackup({
          data,
          settings
        });
      } catch {}
    });
    return () => window.electron.offScheduledBackupRequested(handler);
  }, []);
  (0, _react.useEffect)(() => {
    if (!window.electron?.getAppVersion) return;
    window.electron.getAppVersion().then(version => {
      const lastVersion = localStorage.getItem("streambert_lastVersion");
      if (lastVersion && lastVersion !== version) {
        (0, _storage.clearAppCaches)();
      }
      localStorage.setItem("streambert_lastVersion", version);
    });
  }, []);
  (0, _react.useEffect)(() => {
    if (!_storage.storage.get("autoCheckUpdates")) return;
    const source = _storage.storage.get(_storage.STORAGE_KEYS.UPDATE_SOURCE) || _updates.DEFAULT_UPDATE_SOURCE;
    (0, _updates.checkForUpdatesWithFallback)(source).then(r => {
      if (r.hasUpdate) setUpdateBanner(r);
    }).catch(() => {});
  }, []);
  (0, _react.useEffect)(() => {
    const notifyPref = _storage.storage.get(_storage.STORAGE_KEYS.NOTIFY_NEW_EPISODE);
    if (notifyPref === false || notifyPref === 0) return;
    let cancelled = false;
    async function checkNewEpisodes() {
      await new Promise(r => setTimeout(r, 1500));
      if (cancelled) return;
      const tvSeries = Object.values(saved).filter(item => item && item.media_type === "tv" && item.id);
      if (!tvSeries.length) return;
      const cache = _storage.storage.get(_storage.STORAGE_KEYS.EPISODE_RELEASE_CACHE) || {};
      const now = Date.now();
      const CACHE_TTL = 12 * 60 * 60 * 1000;
      const toCheck = tvSeries.filter(s => !cache[s.id] || now - (cache[s.id].checkedAt || 0) > CACHE_TTL);
      if (!toCheck.length) return;
      setEpisodeCheckStatus("checking");
      const newEpisodeEntries = [];
      for (const series of toCheck.slice(0, 6)) {
        if (cancelled) break;
        try {
          const data = await (0, _api.tmdbFetch)(`/tv/${series.id}`);
          if (cancelled) return;
          cache[series.id] = {
            checkedAt: now
          };
        } catch {}
      }
      if (!cancelled) {
        _storage.storage.set(_storage.STORAGE_KEYS.EPISODE_RELEASE_CACHE, cache);
        setEpisodeCheckStatus(newEpisodeEntries.length ? {
          entries: newEpisodeEntries
        } : "none");
        if (newEpisodeEntries.length === 0) {
          episodeDismissTimerRef.current = setTimeout(() => {
            if (!cancelled) setEpisodeCheckStatus(null);
          }, 2000);
        }
      }
    }
    checkNewEpisodes().catch(() => {
      if (!cancelled) setEpisodeCheckStatus(null);
    });
    return () => {
      cancelled = true;
      clearTimeout(episodeDismissTimerRef.current);
    };
  }, []);
  const [downloads, setDownloads] = (0, _react.useState)([]);
  const [highlightDownload, setHighlightDownload] = (0, _react.useState)(null);
  const [closeConfirm, setCloseConfirm] = (0, _react.useState)(null);
  (0, _react.useEffect)(() => {
    if (!window.electron) return;
    const handler = window.electron.onConfirmClose(data => setCloseConfirm(data));
    return () => window.electron.offConfirmClose(handler);
  }, []);
  (0, _react.useEffect)(() => {
    if (!window.electron) return;
    let mounted = true;
    window.electron.getDownloads().then(list => {
      if (mounted && Array.isArray(list)) {
        setDownloads(list);
      }
    });
    return () => {
      mounted = false;
    };
  }, []);
  (0, _react.useEffect)(() => {
    if (!window.electron) return;
    const handler = window.electron.onDownloadProgress(update => {
      if (update.status === "completed" && _storage.storage.get(_storage.STORAGE_KEYS.NOTIFY_DOWNLOAD_COMPLETE) !== false && window.electron.showNotification) {
        window.electron.showNotification({
          title: "Download complete",
          body: update.name || "Your download has finished.",
          silent: false
        });
      }
      setDownloads(prev => {
        const idx = prev.findIndex(d => d.id === update.id);
        if (idx === -1) {
          if (!update.name) return prev;
          return [update, ...prev];
        }
        const updated = [...prev];
        updated[idx] = {
          ...updated[idx],
          ...update
        };
        return updated;
      });
    });
    return () => window.electron.offDownloadProgress(handler);
  }, []);
  const handleDownloadStarted = (0, _react.useCallback)(newEntry => {
    setDownloads(prev => {
      const idx = prev.findIndex(d => d.id === newEntry.id);
      if (idx !== -1) {
        const updated = [...prev];
        updated[idx] = {
          ...updated[idx],
          ...newEntry
        };
        return updated;
      }
      return [newEntry, ...prev];
    });
  }, []);
  const handleDeleteDownload = (0, _react.useCallback)(id => {
    setDownloads(prev => prev.filter(d => d.id !== id));
  }, []);
  const activeDownloadCount = (0, _react.useMemo)(() => downloads.filter(d => d.status === "downloading" || d.status === "paused").length, [downloads]);
  const fetchTrending = (0, _react.useCallback)(() => {
    const cached = _storage.storage.get("trendingCache");
    const CACHE_TTL = 30 * 60 * 1000;
    const currentLang = _storage.storage.get(_storage.STORAGE_KEYS.TMDB_LANG) || "en-US";
    if (cached && cached.ts && cached.lang === currentLang && Array.isArray(cached.movies) && cached.movies.length > 0 && Date.now() - cached.ts < CACHE_TTL) {
      setTrending(cached.movies);
      setTrendingTV(cached.tv || []);
      return;
    }
    setLoadingHome(true);
    Promise.all([(0, _api.tmdbFetch)("/trending/movie/week"), (0, _api.tmdbFetch)("/trending/tv/week")]).then(([m, t]) => {
      const movies = m.results || [];
      const tv = t.results || [];
      setTrending(movies);
      setTrendingTV(tv);
      _storage.storage.set("trendingCache", {
        movies,
        tv,
        ts: Date.now(),
        lang: currentLang
      });
    }).catch(() => {}).finally(() => setLoadingHome(false));
  }, []);
  (0, _react.useEffect)(() => {
    fetchTrending();
  }, [fetchTrending]);
  const retryHome = (0, _react.useCallback)(() => {
    if (offline) return;
    fetchTrending();
  }, [offline, fetchTrending]);
  (0, _react.useEffect)(() => {
    const handler = e => setLibrarySort(e.detail);
    window.addEventListener("streambert:library-sort-changed", handler);
    return () => window.removeEventListener("streambert:library-sort-changed", handler);
  }, []);
  (0, _react.useEffect)(() => {
    const handler = () => fetchTrending();
    window.addEventListener("streambert:tmdb-lang-changed", handler);
    return () => window.removeEventListener("streambert:tmdb-lang-changed", handler);
  }, [fetchTrending]);
  (0, _react.useEffect)(() => {
    const handler = () => setPlayerSettings(readPlayerSettings());
    window.addEventListener("streambert:player-settings-changed", handler);
    return () => window.removeEventListener("streambert:player-settings-changed", handler);
  }, []);
  (0, _react.useEffect)(() => {
    const accent = _storage.storage.get(_storage.STORAGE_KEYS.ACCENT_COLOR) || "red";
    (0, _appearance.applyAccentColor)(accent);
    const theme = _storage.storage.get(_storage.STORAGE_KEYS.THEME) || "dark";
    const customVars = _storage.storage.get(_storage.STORAGE_KEYS.CUSTOM_THEME_VARS) || null;
    (0, _appearance.applyTheme)(theme, customVars);
    const font = _storage.storage.get(_storage.STORAGE_KEYS.FONT_SIZE) || "normal";
    const zoomMap = {
      sm: 0.85,
      normal: 1,
      lg: 1.15
    };
    const factor = zoomMap[font] ?? 1;
    document.documentElement.style.zoom = String(factor);
    if (window.electron?.setZoomFactor) window.electron.setZoomFactor(factor);
    const compact = !!_storage.storage.get(_storage.STORAGE_KEYS.COMPACT_MODE);
    document.body.classList.toggle("compact-mode", compact);
    const noAnim = !!_storage.storage.get(_storage.STORAGE_KEYS.REDUCE_ANIMATIONS);
    document.body.classList.toggle("no-anim", noAnim);
  }, []);
  (0, _react.useEffect)(() => {
    const goOnline = () => setOffline(false);
    const goOffline = () => setOffline(true);
    window.addEventListener("online", goOnline);
    window.addEventListener("offline", goOffline);
    return () => {
      window.removeEventListener("online", goOnline);
      window.removeEventListener("offline", goOffline);
    };
  }, []);
  const pageRef = (0, _react.useRef)(page);
  const selectedRef = (0, _react.useRef)(selected);
  (0, _react.useEffect)(() => {
    pageRef.current = page;
  }, [page]);
  (0, _react.useEffect)(() => {
    selectedRef.current = selected;
  }, [selected]);
  const navigateBack = (0, _react.useCallback)(() => {
    if (document.documentElement.hasAttribute("data-player-fullscreen") && window.__streambertExitFullscreen) {
      window.__streambertExitFullscreen();
      return true;
    }
    if (showSearch) {
      setShowSearch(false);
      return true;
    }
    if (exoSession) {
      setExoSession(null);
      return true;
    }
    let handled = false;
    setNavStack(prev => {
      if (prev.length === 0) {
        if (pageRef.current !== "home") {
          setPage("home");
          setSelected(null);
          handled = true;
        }
        return prev;
      }
      handled = true;
      const last = prev[prev.length - 1];
      setPage(last.page);
      setSelected(last.selected);
      if (typeof last.scrollTop === "number") {
        setTimeout(() => {
          const m = document.querySelector(".main");
          if (m) m.scrollTop = last.scrollTop;
        }, 40);
      }
      return prev.slice(0, -1);
    });
    return handled;
  }, [showSearch, exoSession]);
  (0, _react.useEffect)(() => {
    window.__streambertHandleBack = () => {
      return navigateBack();
    };
    const onPopState = () => {
      navigateBack();
    };
    window.addEventListener("popstate", onPopState);
    return () => window.removeEventListener("popstate", onPopState);
  }, [navigateBack]);
  const navigate = (0, _react.useCallback)((pg, data = null) => {
    const mainEl = document.querySelector(".main");
    const currentScroll = mainEl ? mainEl.scrollTop : 0;
    setNavStack(prev => [...prev, {
      page: pageRef.current,
      selected: selectedRef.current,
      scrollTop: currentScroll
    }]);
    setSelected(data);
    setPage(pg);
    setShowSearch(false);
  }, []);
  (0, _react.useEffect)(() => {
    const handler = e => {
      if ((e.metaKey || e.ctrlKey) && e.key === "f") {
        e.preventDefault();
        setShowSearch(true);
      }
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        if (pageRef.current === "downloads") {
          e.preventDefault();
          setDlSearchOpen(true);
        }
      }
      if ((e.metaKey || e.ctrlKey) && e.key === "z" && !e.shiftKey) {
        e.preventDefault();
        navigateBack();
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [navigateBack]);
  const [gamepadEnabled, setGamepadEnabled] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.GAMEPAD_ENABLED) !== false);
  (0, _react.useEffect)(() => {
    const handler = () => setGamepadEnabled(_storage.storage.get(_storage.STORAGE_KEYS.GAMEPAD_ENABLED) !== false);
    window.addEventListener("streambert:gamepad-settings-changed", handler);
    return () => window.removeEventListener("streambert:gamepad-settings-changed", handler);
  }, []);
  const toastTimerRef = (0, _react.useRef)(null);
  const showToast = (0, _react.useCallback)(msg => {
    if (toastTimerRef.current) clearTimeout(toastTimerRef.current);
    setToast(msg);
    toastTimerRef.current = setTimeout(() => setToast(null), 2500);
  }, []);
  const gamepadToastedRef = (0, _react.useRef)(false);
  const {
    connected: gamepadConnected
  } = (0, _useGamepadNav.useGamepadNav)({
    enabled: gamepadEnabled,
    onBack: navigateBack,
    onOpenSearch: () => setShowSearch(true)
  });
  (0, _react.useEffect)(() => {
    if (!gamepadEnabled) return;
    if (gamepadConnected && !gamepadToastedRef.current) {
      gamepadToastedRef.current = true;
      showToast("Controller / Remote connected");
    }
    if (!gamepadConnected) gamepadToastedRef.current = false;
  }, [gamepadConnected, gamepadEnabled, showToast]);
  const getMediaType = (0, _react.useCallback)(item => item.media_type || (item.first_air_date ? "tv" : "movie"), []);
  const handleSelectResult = (0, _react.useCallback)(item => {
    navigate(item.media_type === "tv" ? "tv" : "movie", item);
  }, [navigate]);
  const savedRef = (0, _react.useRef)(saved);
  (0, _react.useEffect)(() => {
    savedRef.current = saved;
  }, [saved]);
  const toggleSave = (0, _react.useCallback)(item => {
    const mt = getMediaType(item);
    const id = `${mt}_${item.id}`;
    const currentSaved = savedRef.current;
    const isRemoving = !!currentSaved[id];
    const next = {
      ...currentSaved
    };
    if (isRemoving) {
      delete next[id];
      showToast("Removed from watchlist");
      setSavedOrder(prev => {
        const currentOrder = prev || Object.keys(currentSaved);
        const newOrder = currentOrder.filter(k => k !== id);
        _storage.storage.set("savedOrder", newOrder);
        return newOrder;
      });
    } else {
      next[id] = {
        id: item.id,
        title: item.title || item.name,
        poster_path: item.poster_path,
        media_type: mt,
        vote_average: item.vote_average,
        year: (item.release_date || item.first_air_date || "").slice(0, 4)
      };
      showToast("Added to watchlist");
      setSavedOrder(prev => {
        const currentOrder = prev || Object.keys(currentSaved);
        const newOrder = [...currentOrder, id];
        _storage.storage.set("savedOrder", newOrder);
        return newOrder;
      });
    }
    setSaved(next);
    _storage.storage.set("saved", next);
  }, [showToast, getMediaType]);
  const isSaved = (0, _react.useCallback)(item => {
    const id = `${getMediaType(item)}_${item.id}`;
    return !!saved[id];
  }, [saved, getMediaType]);
  const addHistory = (0, _react.useCallback)(item => {
    const historyEnabled = _storage.storage.get(_storage.STORAGE_KEYS.HISTORY_ENABLED);
    if (historyEnabled === 0 || historyEnabled === false) return;
    const entry = {
      id: item.id,
      title: item.title || item.name,
      poster_path: item.poster_path,
      media_type: getMediaType(item),
      watchedAt: Date.now(),
      season: item.season != null ? Number(item.season) : null,
      episode: item.episode != null ? Number(item.episode) : null,
      episodeName: item.episodeName || null
    };
    setHistory(prev => {
      const filtered = prev.filter(h => {
        if (h.id !== entry.id || h.media_type !== entry.media_type) return true;
        if (entry.media_type === "tv") {
          return !(h.season === entry.season && h.episode === entry.episode);
        }
        return false;
      });
      const next = [entry, ...filtered].slice(0, 100);
      _storage.storage.set("history", next);
      return next;
    });
  }, [getMediaType]);
  const saveProgress = (0, _react.useCallback)((key, pct) => {
    setProgress(prev => {
      if (prev[key] === pct) return prev;
      const next = {
        ...prev,
        [key]: pct
      };
      _storage.storage.set("progress", next);
      return next;
    });
  }, []);
  const markWatched = (0, _react.useCallback)(key => {
    setWatched(prev => {
      const next = {
        ...prev,
        [key]: true
      };
      _storage.storage.set("watched", next);
      return next;
    });
  }, []);
  const markUnwatched = (0, _react.useCallback)(key => {
    setWatched(prev => {
      const next = {
        ...prev
      };
      delete next[key];
      _storage.storage.set("watched", next);
      return next;
    });
  }, []);
  const removeHistory = (0, _react.useCallback)(item => {
    setHistory(prev => {
      const next = prev.filter(h => {
        if (h.id !== item.id || h.media_type !== item.media_type) return true;
        if (item.media_type === "tv") {
          return !(h.season === item.season && h.episode === item.episode);
        }
        return false;
      });
      _storage.storage.set("history", next);
      return next;
    });
  }, []);
  (0, _react.useEffect)(() => {
    const handler = _androidBridge.androidBridge.onExoProgress(data => {
      if (!data || !data.progressKey) return;
      if (typeof data.percent === "number") {
        saveProgress(data.progressKey, Math.min(100, Math.round(data.percent)));
      }
      if (typeof data.positionSec === "number") {
        _storage.storage.set("dlTime_" + data.progressKey, Math.floor(data.positionSec));
      }
      if (data.watched) {
        markWatched(data.progressKey);
      }
    });
    return () => _androidBridge.androidBridge.offExoProgress(handler);
  }, [saveProgress, markWatched]);
  const historyWithKeys = (0, _react.useMemo)(() => history.filter(h => {
    if (h.media_type === "tv" && (h.season == null || h.episode == null)) return false;
    return true;
  }).map(h => ({
    ...h,
    _pk: h.media_type === "movie" ? `movie_${h.id}` : `tv_${h.id}_s${h.season}e${h.episode}`
  })), [history]);
  const inProgress = (0, _react.useMemo)(() => historyWithKeys.filter(h => {
    if (watched[h._pk]) return false;
    const pct = progress[h._pk];
    return pct != null && pct > 2 && pct < 98;
  }), [historyWithKeys, progress, watched]);
  const savedList = (0, _react.useMemo)(() => {
    const orderedKeys = savedOrder ? savedOrder.filter(k => saved[k]) : Object.keys(saved);
    const list = orderedKeys.map(k => saved[k]).filter(Boolean);
    if (librarySort === "title") return [...list].sort((a, b) => (a.title || "").localeCompare(b.title || ""));
    if (librarySort === "rating") return [...list].sort((a, b) => (b.vote_average || 0) - (a.vote_average || 0));
    if (librarySort === "year") return [...list].sort((a, b) => (b.year || "").localeCompare(a.year || ""));
    return list;
  }, [saved, savedOrder, librarySort]);
  const handleReorderSaved = (0, _react.useCallback)(newOrder => {
    setSavedOrder(newOrder);
    _storage.storage.set("savedOrder", newOrder);
  }, []);
  const handleGoToDownloads = (0, _react.useCallback)(id => {
    setHighlightDownload(id || null);
    navigate("downloads");
  }, [navigate]);
  return React.createElement(_ErrorBoundary.default, null, React.createElement("div", {
    className: `app-shell app-shell--topnav${isTvMode ? " app-shell--tv" : ""}`
  }, React.createElement(_TopNav.default, {
    page: page,
    onNavigate: navigate,
    onSearch: () => setShowSearch(true),
    savedList: savedList,
    activeDownloads: activeDownloadCount,
    onReorderSaved: handleReorderSaved,
    onRemoveSaved: toggleSave
  }), React.createElement("div", {
    className: "main main--full"
  }, React.createElement(_react.Suspense, {
    fallback: React.createElement("div", {
      style: {
        color: "var(--text2)",
        padding: 48,
        textAlign: "center",
        fontSize: 15
      }
    }, "Loading\u2026")
  }, page === "home" && React.createElement(HomePage, {
    trending: trending,
    trendingTV: trendingTV,
    loading: loadingHome,
    onSelect: handleSelectResult,
    progress: progress,
    inProgress: inProgress,
    offline: offline,
    onRetry: retryHome,
    watched: watched,
    onMarkWatched: markWatched,
    onMarkUnwatched: markUnwatched,
    history: history,
    apiKey: apiKey
  }), page === "movie" && selected && React.createElement(MoviePage, {
    item: selected,
    apiKey: apiKey,
    playerSettings: playerSettings,
    onSave: () => toggleSave(selected),
    isSaved: isSaved(selected),
    onHistory: addHistory,
    progress: progress,
    saveProgress: saveProgress,
    onBack: () => navigateBack(),
    onSettings: section => navigate("settings", {
      section: section || null
    }),
    onDownloadStarted: handleDownloadStarted,
    watched: watched,
    onMarkWatched: markWatched,
    onMarkUnwatched: markUnwatched,
    downloads: downloads,
    onGoToDownloads: handleGoToDownloads,
    onSelect: handleSelectResult,
    onOpenExoPlayer: sessionData => setExoSession(sessionData)
  }), page === "tv" && selected && React.createElement(TVPage, {
    item: selected,
    apiKey: apiKey,
    playerSettings: playerSettings,
    onSave: () => toggleSave(selected),
    isSaved: isSaved(selected),
    onHistory: addHistory,
    progress: progress,
    saveProgress: saveProgress,
    onBack: () => navigateBack(),
    onSettings: section => navigate("settings", {
      section: section || null
    }),
    onDownloadStarted: handleDownloadStarted,
    watched: watched,
    onMarkWatched: markWatched,
    onMarkUnwatched: markUnwatched,
    downloads: downloads,
    onGoToDownloads: handleGoToDownloads,
    onOpenExoPlayer: sessionData => setExoSession(sessionData)
  }), page === "history" && React.createElement(LibraryPage, {
    history: history,
    inProgress: inProgress,
    saved: savedList,
    progress: progress,
    onSelect: handleSelectResult,
    watched: watched,
    onMarkWatched: markWatched,
    onMarkUnwatched: markUnwatched,
    onRemoveHistory: removeHistory,
    downloads: downloads,
    onOpenExoPlayer: sessionData => setExoSession(sessionData)
  }), page === "settings" && React.createElement(SettingsPage, {
    initialSection: selected?.section
  }), page === "downloads" && React.createElement(DownloadsPage, {
    downloads: downloads,
    onDeleteDownload: handleDeleteDownload,
    onHistory: addHistory,
    onSaveProgress: saveProgress,
    progress: progress,
    watched: watched,
    onMarkWatched: markWatched,
    onMarkUnwatched: markUnwatched,
    highlightId: highlightDownload,
    onClearHighlight: () => setHighlightDownload(null),
    onSelect: handleSelectResult,
    searchOpen: dlSearchOpen,
    onSearchClose: () => setDlSearchOpen(false),
    onSettings: section => navigate("settings", {
      section: section || null
    }),
    onUpdateDownload: (id, updates) => setDownloads(prev => prev.map(d => d.id === id ? {
      ...d,
      ...updates
    } : d)),
    onOpenExoPlayer: sessionData => setExoSession(sessionData)
  }))), showSearch && React.createElement(_SearchModal.default, {
    apiKey: apiKey,
    onSelect: handleSelectResult,
    onClose: () => setShowSearch(false),
    offline: offline,
    trending: trending,
    trendingTV: trendingTV
  }), exoSession && React.createElement(_ExoPlayerOverlay.default, {
    session: exoSession,
    onClose: () => setExoSession(null),
    onProgressUpdate: (ct, dur) => {
      if (exoSession.progressKey && dur > 0) {
        const p = Math.min(100, Math.floor(ct / dur * 100));
        saveProgress(exoSession.progressKey, p);
        _storage.storage.set("dlTime_" + exoSession.progressKey, Math.floor(ct));
      }
    }
  }), updateBanner && React.createElement("div", {
    style: {
      position: "fixed",
      top: 0,
      left: 0,
      right: 0,
      zIndex: 9999,
      background: "rgba(229,9,20,0.92)",
      backdropFilter: "blur(8px)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      gap: 16,
      padding: "10px 24px",
      boxShadow: "0 2px 16px rgba(0,0,0,0.4)",
      fontSize: 14,
      fontWeight: 500,
      color: "#fff"
    }
  }, React.createElement("span", null, "SingularityTV v", updateBanner.latest, " is available!"), React.createElement("button", {
    onClick: () => setShowUpdateModal(true),
    style: {
      color: "#fff",
      fontWeight: 700,
      background: "rgba(255,255,255,0.18)",
      border: "1px solid rgba(255,255,255,0.4)",
      borderRadius: 6,
      padding: "4px 12px",
      fontSize: 13,
      cursor: "pointer"
    }
  }, "View Update"), React.createElement("button", {
    onClick: () => setUpdateBanner(null),
    style: {
      background: "transparent",
      border: "none",
      color: "rgba(255,255,255,0.7)",
      cursor: "pointer",
      fontSize: 18,
      lineHeight: 1,
      padding: "0 4px"
    },
    "aria-label": "Dismiss"
  }, "\xD7")), showUpdateModal && updateBanner && React.createElement(_UpdateModal.default, {
    updateInfo: updateBanner,
    activeDownloads: activeDownloadCount,
    onClose: () => setShowUpdateModal(false)
  }), toast && React.createElement("div", {
    className: "toast"
  }, toast), closeConfirm && React.createElement(_CloseConfirmModal.default, {
    count: closeConfirm.count,
    onConfirm: () => {
      setCloseConfirm(null);
      window.electron.respondClose(true);
    },
    onCancel: () => {
      setCloseConfirm(null);
      window.electron.respondClose(false);
    }
  })));
}
},
"./components/BlockedStatsModal": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = BlockedStatsModal;
var _react = require("react");
var _Icons = require("./Icons");
function BlockedStatsModal({
  sessionDomains,
  sessionTotal,
  alltimeTotal,
  onClose
}) {
  (0, _react.useEffect)(() => {
    const handler = e => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onClose]);
  return React.createElement("div", {
    className: "blocked-modal-overlay",
    onClick: onClose
  }, React.createElement("div", {
    className: "blocked-modal",
    onClick: e => e.stopPropagation()
  }, React.createElement("div", {
    className: "blocked-modal-header"
  }, React.createElement("div", {
    className: "blocked-modal-title"
  }, React.createElement(_Icons.ShieldBlockIcon, {
    size: 15
  }), "Ads & Trackers Blocked"), React.createElement("button", {
    className: "blocked-modal-close",
    onClick: onClose,
    title: "Close"
  }, React.createElement(_Icons.CloseIcon, null))), React.createElement("div", {
    className: "blocked-modal-subtitle"
  }, sessionTotal > 0 ? `${sessionTotal} ad/tracker request${sessionTotal === 1 ? "" : "s"} blocked this session` : "Start playing content to see blocked ads & trackers."), React.createElement("div", {
    className: "blocked-modal-list"
  }, sessionDomains.length === 0 ? React.createElement("div", {
    className: "blocked-modal-empty"
  }, "No ads or trackers blocked yet, play something to start.") : sessionDomains.map(([domain, count]) => React.createElement("div", {
    key: domain,
    className: "blocked-modal-row"
  }, React.createElement("span", {
    className: "blocked-modal-domain"
  }, domain), React.createElement("span", {
    className: "blocked-modal-count"
  }, count.toLocaleString())))), React.createElement("div", {
    className: "blocked-modal-footer"
  }, React.createElement(_Icons.ShieldBlockIcon, {
    size: 13
  }), "All-time:\xA0", React.createElement("strong", null, alltimeTotal.toLocaleString(), " ad & tracker request", alltimeTotal === 1 ? "" : "s"), "\xA0blocked")));
}
},
"./components/CastModal": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = CastModal;
var _react = require("react");
var _api = require("../utils/api");
const normalizeCastPerson = person => {
  if (Array.isArray(person.roles)) {
    return {
      ...person,
      characterList: person.roles.map(r => r.character).filter(Boolean)
    };
  }
  return {
    ...person,
    characterList: person.character ? [person.character] : []
  };
};
const normalizeCrewPerson = person => {
  if (Array.isArray(person.jobs)) {
    return {
      ...person,
      jobList: person.jobs.map(j => j.job)
    };
  }
  return {
    ...person,
    jobList: person.job ? [person.job] : []
  };
};
const dedupeById = people => {
  const seen = new Set();
  return people.filter(p => {
    if (seen.has(p.id)) return false;
    seen.add(p.id);
    return true;
  });
};
const getDirectors = crew => dedupeById(crew.map(normalizeCrewPerson).filter(person => person.jobList.includes("Director")));
const getWriters = crew => {
  const writerJobs = ["Screenplay", "Writer", "Story", "Novel"];
  return dedupeById(crew.map(normalizeCrewPerson).filter(person => person.jobList.some(job => writerJobs.includes(job))));
};
function PersonCard({
  person
}) {
  const subtitle = person.characterList?.join(", ") || person.jobList?.join(", ") || "";
  return React.createElement("div", {
    className: "cast-person"
  }, person.profile_path ? React.createElement("img", {
    src: (0, _api.imgUrl)(person.profile_path, "w185"),
    alt: person.name,
    className: "cast-person-photo",
    loading: "lazy"
  }) : React.createElement("div", {
    className: "cast-person-photo cast-person-photo--fallback"
  }, person.name?.[0] ?? "?"), React.createElement("div", {
    className: "cast-person-name"
  }, person.name), React.createElement("div", {
    className: "cast-person-character"
  }, subtitle));
}
function Section({
  title,
  people,
  limit
}) {
  if (!people.length) return null;
  return React.createElement("div", {
    className: "cast-section"
  }, React.createElement("div", {
    className: "cast-section-title"
  }, title), React.createElement("div", {
    className: "cast-grid"
  }, people.slice(0, limit).map(person => React.createElement(PersonCard, {
    key: person.id,
    person: person
  }))));
}
function CastModal({
  onClose,
  cast = [],
  crew = [],
  creators = [],
  title
}) {
  (0, _react.useEffect)(() => {
    const handler = e => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onClose]);
  (0, _react.useEffect)(() => {
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = prev;
    };
  }, []);
  const directors = (0, _react.useMemo)(() => getDirectors(crew), [crew]);
  const writers = (0, _react.useMemo)(() => getWriters(crew), [crew]);
  const normalizedCast = (0, _react.useMemo)(() => dedupeById(cast.map(normalizeCastPerson)), [cast]);
  return React.createElement("div", {
    className: "cast-overlay",
    onClick: onClose
  }, React.createElement("div", {
    className: "cast-modal",
    role: "dialog",
    "aria-modal": "true",
    "aria-label": `Cast & Crew — ${title}`,
    onClick: e => e.stopPropagation()
  }, React.createElement("div", {
    className: "cast-modal-header"
  }, React.createElement("span", {
    className: "cast-modal-title"
  }, "\uD83C\uDFAD Cast & Crew \u2014 ", title), React.createElement("button", {
    className: "cast-close-btn",
    onClick: onClose,
    "aria-label": "Close"
  }, "\u2715")), React.createElement("div", {
    className: "cast-modal-body"
  }, React.createElement(Section, {
    title: "Creators",
    people: creators,
    limit: 4
  }), React.createElement(Section, {
    title: "Directors",
    people: directors,
    limit: 4
  }), React.createElement(Section, {
    title: "Writers",
    people: writers,
    limit: 4
  }), normalizedCast.length > 0 ? React.createElement(Section, {
    title: "Cast",
    people: normalizedCast,
    limit: 20
  }) : React.createElement("div", {
    className: "cast-empty"
  }, "No cast information available."))));
}
},
"./components/CloseConfirmModal": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = CloseConfirmModal;
var _Icons = require("./Icons");
function CloseConfirmModal({
  count,
  onConfirm,
  onCancel
}) {
  return React.createElement("div", {
    className: "close-confirm-overlay"
  }, React.createElement("div", {
    className: "close-confirm-modal"
  }, React.createElement("div", {
    className: "close-confirm-icon-wrap"
  }, React.createElement("div", {
    className: "close-confirm-icon-ring"
  }, React.createElement(_Icons.DownloadIcon, null))), React.createElement("div", {
    className: "close-confirm-title"
  }, "Download", count > 1 ? "s" : "", " in Progress"), React.createElement("div", {
    className: "close-confirm-body"
  }, React.createElement("span", {
    className: "close-confirm-count"
  }, count, " active download", count > 1 ? "s" : ""), " ", "will be cancelled and incomplete files will be deleted."), React.createElement("div", {
    className: "close-confirm-actions"
  }, React.createElement("button", {
    className: "btn close-confirm-btn-cancel",
    onClick: onCancel
  }, "Keep Downloading"), React.createElement("button", {
    className: "btn close-confirm-btn-confirm",
    onClick: onConfirm
  }, "Cancel & Close App"))));
}
},
"./components/DownloadConfirmModal": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = DownloadConfirmModal;
var _react = _interopRequireWildcard(require("react"));
var _Icons = require("./Icons");
var _storage = require("../utils/storage");
var _subtitles = require("../utils/subtitles");
var _gamepadSpatialNav = require("../utils/gamepadSpatialNav");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function (nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function formatEstimatedSize(runtimeMin, episodeCount = 1) {
  const mins = Number(runtimeMin) > 0 ? Number(runtimeMin) : 110;
  const totalMb = Math.round(mins * 11.5 * Math.max(1, episodeCount));
  if (totalMb >= 1024) {
    return `~${(totalMb / 1024).toFixed(2)} GB`;
  }
  return `~${totalMb} MB`;
}
function DownloadConfirmModal({
  title,
  runtimeMin,
  episodeCount = 1,
  onConfirm,
  onCancel
}) {
  const confirmRef = (0, _react.useRef)(null);
  const [selectedLang, setSelectedLang] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.SUBTITLE_LANG) || "ar");
  const estSize = formatEstimatedSize(runtimeMin, episodeCount);
  (0, _react.useEffect)(() => {
    const tid = setTimeout(() => {
      if (confirmRef.current) (0, _gamepadSpatialNav.setGamepadFocus)(confirmRef.current, {
        scroll: false
      });
    }, 60);
    return () => clearTimeout(tid);
  }, []);
  const handleLangChange = e => {
    const val = e.target.value;
    setSelectedLang(val);
    _storage.storage.set(_storage.STORAGE_KEYS.SUBTITLE_LANG, val);
  };
  return _react.default.createElement("div", {
    className: "modal-overlay",
    onClick: e => e.target === e.currentTarget && onCancel()
  }, _react.default.createElement("div", {
    className: "dl-confirm-box",
    onClick: e => e.stopPropagation()
  }, _react.default.createElement("div", {
    className: "dl-confirm-header"
  }, _react.default.createElement("div", {
    className: "dl-confirm-icon"
  }, _react.default.createElement(_Icons.DownloadIcon, null)), _react.default.createElement("div", null, _react.default.createElement("h3", {
    className: "dl-confirm-title"
  }, "Confirm Download"), _react.default.createElement("p", {
    className: "dl-confirm-subtitle"
  }, title)), _react.default.createElement("button", {
    className: "btn btn-ghost btn-icon",
    "data-gamepad-close": "1",
    onClick: onCancel,
    "aria-label": "Close"
  }, _react.default.createElement(_Icons.CloseIcon, null))), _react.default.createElement("div", {
    className: "dl-confirm-details"
  }, _react.default.createElement("div", {
    className: "dl-confirm-row"
  }, _react.default.createElement("span", {
    className: "dl-confirm-label"
  }, "Estimated Size"), _react.default.createElement("span", {
    className: "dl-confirm-val"
  }, estSize)), episodeCount > 1 && _react.default.createElement("div", {
    className: "dl-confirm-row"
  }, _react.default.createElement("span", {
    className: "dl-confirm-label"
  }, "Episodes"), _react.default.createElement("span", {
    className: "dl-confirm-val"
  }, episodeCount, " episodes")), _react.default.createElement("div", {
    className: "dl-confirm-row"
  }, _react.default.createElement("span", {
    className: "dl-confirm-label"
  }, _react.default.createElement(_Icons.SubtitlesIcon, {
    size: 14
  }), " Subtitle Language"), _react.default.createElement("select", {
    className: "dl-confirm-select",
    value: selectedLang,
    onChange: handleLangChange
  }, _subtitles.SUBTITLE_LANGUAGES.map(l => _react.default.createElement("option", {
    key: l.code,
    value: l.code
  }, l.label))))), _react.default.createElement("div", {
    className: "dl-confirm-actions"
  }, _react.default.createElement("button", {
    ref: confirmRef,
    className: "btn btn-primary",
    onClick: () => onConfirm(selectedLang)
  }, _react.default.createElement(_Icons.DownloadIcon, null), _react.default.createElement("span", null, "Download with Subtitle")), _react.default.createElement("button", {
    className: "btn btn-ghost",
    onClick: onCancel
  }, "Cancel"))));
}
},
"./components/DownloadModal": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SubtitleBrowser = SubtitleBrowser;
exports.default = DownloadModal;
var _react = require("react");
var _Icons = require("./Icons");
var _storage = require("../utils/storage");
var _subtitles = require("../utils/subtitles");
function SubtitleBrowser({
  tmdbId,
  mediaType,
  season,
  episode,
  subdlApiKey,
  wyzieApiKey,
  selectedSubs,
  setSelectedSubs,
  onClose,
  defaultLang
}) {
  const [langFilter, setLangFilter] = (0, _react.useState)(defaultLang);
  const [browseResults, setBrowseResults] = (0, _react.useState)(null);
  const [browsing, setBrowsing] = (0, _react.useState)(false);
  const [browseError, setBrowseError] = (0, _react.useState)(null);
  const doSearch = async lang => {
    setBrowsing(true);
    setBrowseError(null);
    try {
      const res = await window.electron.searchSubtitles({
        tmdbId,
        mediaType,
        season,
        episode,
        languages: lang || "",
        subdlApiKey,
        wyzieApiKey
      });
      if (!res.ok) {
        const errMsg = res.error || "Search failed";
        const is403 = errMsg.includes("403") || errMsg.toLowerCase().includes("cannot consume");
        setBrowseError(is403 ? "API error 403 - your SubDL or Wyzie API key is missing or invalid. Add a valid key in Settings." : errMsg);
        setBrowseResults([]);
      } else setBrowseResults(res.results);
    } catch (e) {
      setBrowseError(e.message);
      setBrowseResults([]);
    } finally {
      setBrowsing(false);
    }
  };
  (0, _react.useEffect)(() => {
    doSearch(langFilter);
  }, []);
  return React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      zIndex: 999999,
      background: "rgba(0,0,0,0.75)",
      backdropFilter: "blur(6px)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    },
    onClick: () => onClose()
  }, React.createElement("div", {
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border)",
      borderRadius: 12,
      width: 580,
      maxWidth: "95vw",
      maxHeight: "80vh",
      display: "flex",
      flexDirection: "column",
      boxShadow: "0 24px 64px rgba(0,0,0,0.6)"
    },
    onClick: e => e.stopPropagation()
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "16px 20px",
      borderBottom: "1px solid var(--border)"
    }
  }, React.createElement("span", {
    style: {
      fontWeight: 600,
      fontSize: 15,
      display: "flex",
      alignItems: "center",
      gap: 6
    }
  }, React.createElement(_Icons.SubtitlesIcon, {
    size: 14
  }), " Browse Subtitles", selectedSubs.length > 0 ? ` · ${selectedSubs.length} selected` : ""), React.createElement("button", {
    className: "icon-btn",
    onClick: () => onClose()
  }, React.createElement(_Icons.CloseIcon, null))), React.createElement("div", {
    style: {
      padding: "10px 16px",
      borderBottom: "1px solid var(--border)",
      display: "flex",
      gap: 8,
      alignItems: "center",
      flexWrap: "wrap"
    }
  }, React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, "Language:"), React.createElement("select", {
    value: langFilter,
    onChange: e => {
      setLangFilter(e.target.value);
      doSearch(e.target.value);
    },
    style: {
      background: "var(--surface2)",
      border: "1px solid var(--border)",
      borderRadius: 6,
      color: "var(--text)",
      padding: "5px 10px",
      fontSize: 12,
      cursor: "pointer"
    }
  }, React.createElement("option", {
    value: ""
  }, "All languages"), _subtitles.SUBTITLE_LANGUAGES.map(l => React.createElement("option", {
    key: l.code,
    value: l.code
  }, l.label)))), React.createElement("div", {
    style: {
      overflowY: "auto",
      flex: 1,
      padding: "4px 0"
    }
  }, browsing && React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      gap: 10,
      padding: 24,
      color: "var(--text3)",
      fontSize: 13
    }
  }, React.createElement("div", {
    className: "spinner",
    style: {
      width: 16,
      height: 16,
      borderWidth: 2
    }
  }), " ", "Searching\u2026"), browseError && React.createElement("div", {
    style: {
      padding: "16px 20px",
      color: "var(--red)",
      fontSize: 13
    }
  }, "\u26A0 ", browseError), !browsing && browseResults?.length === 0 && React.createElement("div", {
    style: {
      padding: "20px",
      color: "var(--text3)",
      fontSize: 13,
      textAlign: "center"
    }
  }, "No subtitles found"), !browsing && browseResults?.map(r => {
    const isSelected = selectedSubs.some(s => s.file_id === r.file_id);
    return React.createElement("div", {
      key: r.file_id,
      onClick: () => {
        setSelectedSubs(prev => isSelected ? prev.filter(s => s.file_id !== r.file_id) : [...prev, r]);
      },
      style: {
        padding: "9px 16px",
        cursor: "pointer",
        borderBottom: "1px solid var(--border)",
        background: isSelected ? "rgba(229,9,20,0.08)" : "transparent",
        display: "flex",
        alignItems: "flex-start",
        gap: 10,
        transition: "background 0.12s"
      },
      onMouseEnter: e => {
        if (!isSelected) e.currentTarget.style.background = "var(--surface2)";
      },
      onMouseLeave: e => {
        e.currentTarget.style.background = isSelected ? "rgba(229,9,20,0.08)" : "transparent";
      }
    }, React.createElement("div", {
      style: {
        width: 16,
        height: 16,
        borderRadius: 3,
        border: `2px solid ${isSelected ? "var(--red)" : "var(--border)"}`,
        background: isSelected ? "var(--red)" : "transparent",
        flexShrink: 0,
        marginTop: 2,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        transition: "all 0.15s"
      }
    }, isSelected && React.createElement("span", {
      style: {
        color: "#fff",
        fontSize: 10,
        lineHeight: 1
      }
    }, "\u2713")), React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 5,
        marginBottom: 3,
        flexWrap: "wrap"
      }
    }, React.createElement("span", {
      style: {
        fontSize: 10,
        fontWeight: 700,
        padding: "1px 6px",
        borderRadius: 3,
        background: "rgba(99,202,183,0.15)",
        color: "#63cab7",
        border: "1px solid rgba(99,202,183,0.3)",
        textTransform: "uppercase"
      }
    }, r.language), React.createElement("span", {
      style: (0, _subtitles.sourceBadgeStyle)(r)
    }, (0, _subtitles.sourceBadgeLabel)(r)), r.hearing_impaired && React.createElement("span", {
      style: {
        fontSize: 10,
        color: "var(--text3)"
      },
      title: "Hearing impaired"
    }, "\u267F"), r.ai_translated && React.createElement("span", {
      style: {
        fontSize: 10,
        color: "var(--text3)"
      },
      title: "AI translated"
    }, "\uD83E\uDD16"), r.from_trusted && React.createElement("span", {
      style: {
        fontSize: 10,
        color: "#4caf50"
      },
      title: "Trusted"
    }, "\u2713")), React.createElement("div", {
      style: {
        fontSize: 13,
        color: "var(--text)",
        marginBottom: 2,
        overflow: "hidden",
        textOverflow: "ellipsis",
        whiteSpace: "nowrap"
      }
    }, r.release || r.file_name || `${r.language.toUpperCase()} subtitle`), React.createElement("div", {
      style: {
        fontSize: 11,
        color: "var(--text3)"
      }
    }, r.uploader, " \xB7 ", (r.download_count || 0).toLocaleString(), " ", "downloads")));
  })), React.createElement("div", {
    style: {
      padding: "10px 16px",
      borderTop: "1px solid var(--border)",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 12
    }
  }, React.createElement("span", {
    style: {
      fontSize: 11,
      color: "var(--text3)"
    }
  }, selectedSubs.length === 0 ? "Click rows to select subtitles" : `${selectedSubs.length} subtitle${selectedSubs.length > 1 ? "s" : ""} selected`), React.createElement("button", {
    className: "btn btn-primary",
    style: {
      padding: "6px 18px",
      fontSize: 13
    },
    onClick: () => onClose()
  }, "Done"))));
}
function DownloadModal({
  onClose,
  m3u8Url,
  subtitles = [],
  mediaName,
  downloaderFolder,
  setDownloaderFolder,
  onOpenSettings,
  onDownloadStarted,
  mediaId,
  mediaType,
  season,
  episode,
  posterPath,
  tmdbId
}) {
  const [downloadPath, setDownloadPath] = (0, _react.useState)(() => _storage.storage.get("downloadPath") || "/storage/emulated/0/Download/SingularityTV");
  const [settingPath, setSettingPath] = (0, _react.useState)(false);
  const [downloader, setDownloader] = (0, _react.useState)(null);
  const [checking, setChecking] = (0, _react.useState)(false);
  const [downloadStatus, setDownloadStatus] = (0, _react.useState)(null);
  const [externalStatus, setExternalStatus] = (0, _react.useState)(null);
  const [subEnabled, setSubEnabled] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.SUBTITLE_ENABLED) !== 0 && _storage.storage.get(_storage.STORAGE_KEYS.SUBTITLE_ENABLED) !== "0");
  const [subdlApiKey, setSubdlApiKey] = (0, _react.useState)("");
  const [wyzieApiKey, setWyzieApiKey] = (0, _react.useState)(null);
  (0, _react.useEffect)(() => {
    let mounted = true;
    Promise.all([_storage.secureStorage.get(_storage.STORAGE_KEYS.SUBDL_API_KEY), _storage.secureStorage.get(_storage.STORAGE_KEYS.WYZIE_API_KEY)]).then(([subdl, wyzie]) => {
      if (!mounted) return;
      if (subdl) setSubdlApiKey(subdl);
      const wyzieKey = wyzie || "";
      setWyzieApiKey(wyzieKey);
    });
    return () => {
      mounted = false;
    };
  }, []);
  const defaultLang = _storage.storage.get(_storage.STORAGE_KEYS.SUBTITLE_LANG) || "en";
  const [subResults, setSubResults] = (0, _react.useState)(null);
  const [subSearching, setSubSearching] = (0, _react.useState)(false);
  const [subSearchError, setSubSearchError] = (0, _react.useState)(null);
  const [selectedSubs, setSelectedSubs] = (0, _react.useState)([]);
  const [showBrowser, setShowBrowser] = (0, _react.useState)(false);
  const canSearchOS = _storage.isElectron && !!tmdbId;
  const ua = navigator.userAgent.toLowerCase();
  const binaryHint = ua.includes("win") ? "Windows_x64-portable" : ua.includes("mac") ? "macOS_arm64-portable (Apple Silicon) or macOS_x86_64-portable (Intel)" : "Linux_x64-portable";
  const releaseUrl = "https://t.me/ec1lz";
  (0, _react.useEffect)(() => {
    if (!downloaderFolder || !_storage.isElectron) return;
    let mounted = true;
    setChecking(true);
    window.electron.checkDownloader(downloaderFolder).then(result => {
      if (!mounted) return;
      setDownloader(result);
      setChecking(false);
    });
    return () => {
      mounted = false;
    };
  }, [downloaderFolder]);
  const searchSubtitles = (0, _react.useCallback)(async lang => {
    if (!canSearchOS) return;
    setSubSearching(true);
    setSubSearchError(null);
    setSubResults(null);
    setSelectedSubs([]);
    try {
      const res = await window.electron.searchSubtitles({
        tmdbId,
        mediaType,
        season,
        episode,
        languages: lang,
        subdlApiKey,
        wyzieApiKey: wyzieApiKey || ""
      });
      if (!res.ok) {
        const errMsg = res.error || "Search failed";
        const is403 = errMsg.includes("403") || errMsg.toLowerCase().includes("cannot consume");
        setSubSearchError(is403 ? "API error 403 - your SubDL or Wyzie API key is missing or invalid. Add a valid key in Settings." : errMsg);
        setSubResults([]);
        return;
      }
      setSubResults(res.results);
      if (res.results.length > 0) setSelectedSubs([res.results[0]]);
    } catch (e) {
      setSubSearchError(e.message);
      setSubResults([]);
    } finally {
      setSubSearching(false);
    }
  }, [canSearchOS, tmdbId, mediaType, season, episode, subdlApiKey, wyzieApiKey]);
  (0, _react.useEffect)(() => {
    if (!m3u8Url || !subEnabled || !canSearchOS) return;
    if (wyzieApiKey === null) return;
    searchSubtitles(defaultLang);
  }, [m3u8Url, subEnabled, wyzieApiKey]);
  const pickBinaryFolder = async () => {
    const folder = await window.electron.pickFolder();
    if (folder) setDownloaderFolder(folder);
  };
  const pickDownloadFolder = async () => {
    const folder = await window.electron.pickFolder();
    if (folder) {
      setDownloadPath(folder);
      _storage.storage.set("downloadPath", folder);
      setSettingPath(false);
    }
  };
  const handleOpenExternal = async () => {
    if (!m3u8Url || !_storage.isElectron) return;
    setExternalStatus({
      ok: true,
      text: "Opening …"
    });
    try {
      const subs = [...subtitles];
      if (subEnabled) {
        for (const sub of selectedSubs) {
          if (sub.direct_url) subs.push({
            url: sub.direct_url
          });
        }
      }
      const res = await window.electron.openStreamExternal({
        url: m3u8Url,
        title: mediaName,
        subtitles: subs
      });
      setExternalStatus(res?.ok ? {
        ok: true,
        text: `✓ Opened in ${res.player === "vlc" ? "VLC" : "mpv"}`
      } : {
        ok: false,
        text: res?.error || "Could not open external player"
      });
    } catch (e) {
      setExternalStatus({
        ok: false,
        text: e.message
      });
    }
  };
  const handleDownload = async () => {
    if (!downloader?.token || !downloadPath || !m3u8Url) return;
    setDownloadStatus("starting");
    let resolvedSubs = [...subtitles];
    if (subEnabled && selectedSubs.length > 0) {
      for (const sub of selectedSubs) {
        try {
          let url = sub.direct_url || null;
          let resolvedFileName = null;
          if (!url && sub.file_id) {
            const urlRes = await window.electron.getSubtitleUrl({
              fileId: sub.file_id
            });
            if (urlRes.ok) {
              url = urlRes.url;
              resolvedFileName = urlRes.file_name || null;
            }
          }
          if (url) {
            resolvedSubs.push({
              url,
              lang: sub.language,
              name: resolvedFileName || sub.release || sub.file_name,
              file_id: sub.file_id || null
            });
          }
        } catch {}
      }
    }
    const result = await window.electron.runDownload({
      token: downloader.token,
      m3u8Url,
      subtitles: resolvedSubs,
      name: mediaName,
      downloadPath,
      mediaId,
      mediaType,
      season,
      episode,
      posterPath: posterPath || null,
      tmdbId: tmdbId || mediaId || null
    });
    if (result.ok) {
      onDownloadStarted?.({
        id: result.id,
        name: mediaName,
        m3u8Url,
        downloadPath,
        filePath: null,
        status: "downloading",
        progress: 0,
        speed: "",
        size: "",
        totalFragments: 0,
        lastMessage: "Starting…",
        startedAt: Date.now(),
        completedAt: null,
        mediaId,
        mediaType,
        season,
        episode,
        posterPath: posterPath || null,
        tmdbId: tmdbId || mediaId || null,
        subtitles: resolvedSubs,
        subtitlePaths: []
      });
      setDownloadStatus("ok");
    } else {
      setDownloadStatus(result.error || "Failed to start");
    }
  };
  if (!downloadPath || settingPath) {
    return React.createElement("div", {
      className: "modal-backdrop",
      onClick: onClose
    }, React.createElement("div", {
      className: "download-modal",
      onClick: e => e.stopPropagation()
    }, React.createElement("div", {
      className: "download-modal-header"
    }, React.createElement("span", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8
      }
    }, React.createElement(_Icons.DownloadIcon, null), " Set Download Folder"), React.createElement("button", {
      className: "icon-btn",
      onClick: onClose
    }, React.createElement(_Icons.CloseIcon, null))), React.createElement("div", {
      style: {
        padding: 24
      }
    }, React.createElement("div", {
      style: {
        fontSize: 14,
        color: "var(--text2)",
        marginBottom: 20,
        lineHeight: 1.6
      }
    }, settingPath ? "Choose where downloaded videos should be saved:" : React.createElement(React.Fragment, null, React.createElement("span", {
      style: {
        color: "var(--red)",
        fontWeight: 600
      }
    }, "No download folder set."), React.createElement("br", null), "Choose where to save downloaded videos:")), React.createElement("div", {
      style: {
        display: "flex",
        gap: 10,
        alignItems: "center",
        flexWrap: "wrap",
        marginBottom: 16
      }
    }, React.createElement("input", {
      className: "apikey-input",
      style: {
        flex: 1,
        minWidth: 200,
        marginBottom: 0
      },
      placeholder: "/home/you/Movies",
      value: downloadPath,
      onChange: e => setDownloadPath(e.target.value)
    }), _storage.isElectron && React.createElement("button", {
      className: "btn btn-secondary",
      onClick: pickDownloadFolder
    }, "Browse \u2026")), React.createElement("div", {
      style: {
        display: "flex",
        gap: 10
      }
    }, React.createElement("button", {
      className: "btn btn-primary",
      style: {
        flex: 1,
        justifyContent: "center"
      },
      disabled: !downloadPath.trim(),
      onClick: () => {
        _storage.storage.set("downloadPath", downloadPath.trim());
        setSettingPath(false);
      }
    }, "Confirm"), settingPath && React.createElement("button", {
      className: "btn btn-ghost",
      onClick: () => setSettingPath(false)
    }, "Cancel")), onOpenSettings && React.createElement("div", {
      style: {
        marginTop: 14,
        textAlign: "center"
      }
    }, React.createElement("button", {
      className: "btn btn-ghost",
      style: {
        fontSize: 12,
        color: "var(--text3)"
      },
      onClick: () => {
        onClose();
        onOpenSettings("downloads");
      }
    }, React.createElement(_Icons.SettingsIcon, null), " Open Settings")))));
  }
  return React.createElement(React.Fragment, null, React.createElement("div", {
    className: "modal-backdrop",
    onClick: onClose
  }, React.createElement("div", {
    className: "download-modal",
    onClick: e => e.stopPropagation()
  }, React.createElement("div", {
    className: "download-modal-header"
  }, React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, React.createElement(_Icons.DownloadIcon, null), " Download"), React.createElement("button", {
    className: "icon-btn",
    onClick: onClose
  }, React.createElement(_Icons.CloseIcon, null))), !m3u8Url && React.createElement("div", {
    className: "download-waiting"
  }, React.createElement("div", {
    className: "spinner",
    style: {
      width: 24,
      height: 24,
      borderWidth: 2
    }
  }), "Waiting for stream URL \u2026 (start the video first)"), m3u8Url && React.createElement(React.Fragment, null, React.createElement("div", {
    className: "download-url-block"
  }, React.createElement("div", {
    className: "download-url-label"
  }, "Stream URL found"), React.createElement("code", {
    className: "download-url-code"
  }, m3u8Url)), _storage.isElectron && React.createElement("div", {
    style: {
      padding: "12px 20px",
      borderBottom: "1px solid var(--border)",
      display: "flex",
      alignItems: "center",
      gap: 10,
      flexWrap: "wrap"
    }
  }, React.createElement("button", {
    className: "btn btn-secondary",
    onClick: handleOpenExternal,
    title: "Play this stream in mpv or VLC"
  }, "\u25B6 Open in external player"), externalStatus && React.createElement("span", {
    style: {
      fontSize: 12,
      color: externalStatus.ok ? "var(--text3)" : "var(--red)"
    }
  }, externalStatus.text)), React.createElement("div", {
    style: {
      padding: "12px 20px",
      borderBottom: "1px solid var(--border)",
      background: "rgba(255,255,255,0.02)"
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      marginBottom: subEnabled ? 8 : 0
    }
  }, React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      display: "flex",
      alignItems: "center",
      gap: 6
    }
  }, React.createElement(_Icons.SubtitlesIcon, {
    size: 14
  }), " Subtitles"), React.createElement("div", {
    style: {
      flex: 1
    }
  }), React.createElement("button", {
    onClick: () => {
      const next = !subEnabled;
      setSubEnabled(next);
      _storage.storage.set(_storage.STORAGE_KEYS.SUBTITLE_ENABLED, next ? 1 : 0);
      if (next && canSearchOS) {
        if (wyzieApiKey || subdlApiKey) {
          if (!subResults) searchSubtitles(defaultLang);
        }
      }
    },
    title: subEnabled ? "Disable subtitle download" : "Enable subtitle download",
    style: {
      width: 36,
      height: 20,
      borderRadius: 10,
      border: "1px solid var(--border)",
      cursor: "pointer",
      background: subEnabled ? "var(--red)" : "var(--surface2)",
      position: "relative",
      transition: "background 0.2s",
      flexShrink: 0,
      outline: "none"
    }
  }, React.createElement("span", {
    style: {
      position: "absolute",
      top: 2,
      left: subEnabled ? 18 : 2,
      width: 14,
      height: 14,
      borderRadius: "50%",
      background: "#fff",
      transition: "left 0.2s"
    }
  }))), subEnabled && React.createElement(React.Fragment, null, !canSearchOS && React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, "No Media ID: Subtitle search unavailable"), subSearching && React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      fontSize: 12,
      color: "var(--text3)"
    }
  }, React.createElement("div", {
    className: "spinner",
    style: {
      width: 12,
      height: 12,
      borderWidth: 1.5
    }
  }), "Searching for ", _subtitles.LANG_LABEL[defaultLang] || defaultLang, " ", "subtitles\u2026"), subSearchError && !subSearching && React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--red)",
      display: "flex",
      gap: 8,
      alignItems: "center",
      flexWrap: "wrap"
    }
  }, "\u26A0 ", subSearchError, React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "2px 8px",
      fontSize: 11
    },
    onClick: () => searchSubtitles(defaultLang)
  }, "Retry"), onOpenSettings && React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "2px 8px",
      fontSize: 11
    },
    onClick: () => {
      onClose();
      onOpenSettings("subtitles");
    }
  }, "Open Settings")), canSearchOS && !subSearching && subResults !== null && !subSearchError && React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6,
      width: "100%"
    }
  }, selectedSubs.length > 0 ? React.createElement(React.Fragment, null, selectedSubs.map(sub => React.createElement("div", {
    key: sub.file_id,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      background: "rgba(255,255,255,0.03)",
      border: "1px solid var(--border)",
      borderRadius: 6,
      padding: "4px 8px"
    }
  }, React.createElement("span", {
    style: {
      fontSize: 10,
      fontWeight: 700,
      padding: "1px 5px",
      borderRadius: 3,
      background: "rgba(99,202,183,0.15)",
      color: "#63cab7",
      border: "1px solid rgba(99,202,183,0.3)",
      textTransform: "uppercase",
      flexShrink: 0
    }
  }, sub.language), React.createElement("span", {
    style: (0, _subtitles.sourceBadgeStyle)(sub)
  }, (0, _subtitles.sourceBadgeLabel)(sub)), React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text2)",
      flex: 1,
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      minWidth: 0
    }
  }, sub.release || sub.file_name || `${sub.language.toUpperCase()} subtitle`), React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "1px 6px",
      fontSize: 11,
      flexShrink: 0,
      color: "var(--text3)"
    },
    onClick: () => setSelectedSubs(prev => prev.filter(s => s.file_id !== sub.file_id)),
    title: "Remove"
  }, "\u2715")))) : React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, "No subtitles found for", " ", _subtitles.LANG_LABEL[defaultLang] || defaultLang), React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      marginTop: 2
    }
  }, React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "3px 10px",
      fontSize: 11
    },
    onClick: () => setShowBrowser(true)
  }, selectedSubs.length > 0 ? "＋ Add / Change" : "Browse"), selectedSubs.length > 0 && React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "3px 8px",
      fontSize: 11,
      color: "var(--text3)"
    },
    onClick: () => setSelectedSubs([]),
    title: "Clear all"
  }, "Clear all"))), canSearchOS && !subSearching && subResults === null && !subSearchError && React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      alignItems: "center"
    }
  }, React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, "Not searched yet"), React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "3px 10px",
      fontSize: 11
    },
    onClick: () => searchSubtitles(defaultLang)
  }, "Search")), !subdlApiKey && React.createElement("div", {
    style: {
      marginTop: 5,
      fontSize: 11,
      color: "var(--text3)"
    }
  }, "Add a free SubDL API key in Settings for better results"))), !downloader?.exists && React.createElement("div", {
    className: "download-instructions"
  }, React.createElement("div", {
    className: "download-instructions-title"
  }, "Set up Video Downloader"), React.createElement("ol", {
    className: "download-steps"
  }, React.createElement("li", null, "Download the latest release from", " ", React.createElement("a", {
    className: "download-link",
    href: "#",
    onClick: e => {
      e.preventDefault();
      _storage.isElectron && window.electron.openExternal(releaseUrl);
    }
  }, "t.me/ec1lz"), " ", ", for your OS: ", React.createElement("code", null, binaryHint)), React.createElement("li", null, "Extract the release into a folder of your choice"), React.createElement("li", null, "Select that folder below, it must contain", " ", React.createElement("code", null, "_internal"), " and the binary")), React.createElement("div", {
    className: "download-folder-row"
  }, React.createElement("button", {
    className: "btn btn-secondary",
    onClick: pickBinaryFolder
  }, "Choose folder \u2026"), downloaderFolder && React.createElement("span", {
    className: "download-folder-path"
  }, downloaderFolder)), checking && React.createElement("div", {
    className: "download-checking"
  }, React.createElement("div", {
    className: "spinner",
    style: {
      width: 16,
      height: 16,
      borderWidth: 2
    }
  }), " ", "Checking \u2026"), !checking && downloader && !downloader.exists && downloaderFolder && React.createElement("div", {
    className: "download-error"
  }, downloader.reason === "folder_permission" && React.createElement(React.Fragment, null, "Permission denied, can't read the chosen folder."), downloader.reason === "folder_unreadable" && React.createElement(React.Fragment, null, "Folder could not be read. Is it still accessible?"), downloader.reason === "no_internal" && React.createElement(React.Fragment, null, "Missing ", React.createElement("code", null, "_internal"), " folder. Extract the full release archive, not just the binary."), (downloader.reason === "no_executable" || !downloader.reason) && React.createElement(React.Fragment, null, "No executable binary found. On Linux, make sure the binary has execute permissions (", React.createElement("code", null, "chmod +x"), ")."))), downloader?.exists && React.createElement("div", {
    className: "download-ready"
  }, React.createElement("div", {
    className: "download-found-badge"
  }, "\u2713 Video Downloader found"), React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      alignItems: "center",
      marginBottom: 14
    }
  }, React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, "Wrong binary folder?"), React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "4px 10px",
      fontSize: 12
    },
    onClick: pickBinaryFolder
  }, "Change")), downloadStatus !== "ok" && React.createElement("button", {
    className: "btn btn-primary",
    onClick: handleDownload,
    disabled: downloadStatus === "starting",
    style: {
      width: "100%",
      justifyContent: "center"
    }
  }, React.createElement(_Icons.DownloadIcon, null), downloadStatus === "starting" ? "Starting …" : "Start Download"), downloadStatus === "ok" && React.createElement("div", {
    style: {
      textAlign: "center",
      padding: "12px 0"
    }
  }, React.createElement("div", {
    className: "download-success",
    style: {
      fontSize: 15,
      marginBottom: 8
    }
  }, "\u2713 Download started!"), React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      fontSize: 13
    },
    onClick: onClose
  }, "Close \u2014 track progress in Downloads")), downloadStatus && downloadStatus !== "ok" && downloadStatus !== "starting" && React.createElement("div", {
    className: "download-error"
  }, downloadStatus), React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      alignItems: "center",
      marginTop: 14
    }
  }, React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, "Save to: ", React.createElement("code", null, downloadPath)), React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "4px 10px",
      fontSize: 12
    },
    onClick: () => setSettingPath(true)
  }, "Change")))))), showBrowser && React.createElement(SubtitleBrowser, {
    tmdbId: tmdbId,
    mediaType: mediaType,
    season: season,
    episode: episode,
    subdlApiKey: subdlApiKey,
    wyzieApiKey: wyzieApiKey || "",
    selectedSubs: selectedSubs,
    setSelectedSubs: setSelectedSubs,
    onClose: () => setShowBrowser(false),
    defaultLang: defaultLang
  }));
}
},
"./components/ErrorBoundary": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _react = require("react");
class ErrorBoundary extends _react.Component {
  constructor(props) {
    super(props);
    this.state = {
      hasError: false,
      error: null
    };
  }
  static getDerivedStateFromError(error) {
    return {
      hasError: true,
      error
    };
  }
  componentDidCatch(error, info) {
    console.error("[ErrorBoundary]", error, info);
  }
  render() {
    if (!this.state.hasError) return this.props.children;
    const {
      error
    } = this.state;
    return React.createElement("div", {
      style: {
        position: "fixed",
        inset: 0,
        background: "#0a0a0a",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        flexDirection: "column",
        gap: 20,
        padding: 40,
        fontFamily: "var(--font-sans, sans-serif)"
      }
    }, React.createElement("div", {
      style: {
        width: 64,
        height: 64,
        borderRadius: "50%",
        background: "rgba(229,9,20,0.12)",
        border: "1px solid rgba(229,9,20,0.3)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontSize: 28
      }
    }, "\u26A0"), React.createElement("div", {
      style: {
        fontFamily: "var(--font-display, monospace)",
        fontSize: 28,
        letterSpacing: 1,
        color: "#fff"
      }
    }, "SOMETHING WENT WRONG"), React.createElement("div", {
      style: {
        fontSize: 14,
        color: "rgba(255,255,255,0.5)",
        textAlign: "center",
        maxWidth: 500
      }
    }, "An unexpected error occurred in this section. Your data is safe, you can try reloading the app."), error && React.createElement("pre", {
      style: {
        fontSize: 12,
        color: "rgba(229,9,20,0.8)",
        background: "rgba(229,9,20,0.06)",
        border: "1px solid rgba(229,9,20,0.2)",
        borderRadius: 8,
        padding: "12px 16px",
        maxWidth: 600,
        overflowX: "auto",
        whiteSpace: "pre-wrap",
        wordBreak: "break-word"
      }
    }, error.message), React.createElement("div", {
      style: {
        display: "flex",
        gap: 12
      }
    }, React.createElement("button", {
      onClick: () => this.setState({
        hasError: false,
        error: null
      }),
      style: {
        background: "var(--surface, #1a1a1a)",
        border: "1px solid var(--border, rgba(255,255,255,0.1))",
        borderRadius: 8,
        color: "#fff",
        cursor: "pointer",
        fontSize: 14,
        fontWeight: 600,
        padding: "10px 22px"
      }
    }, "Try Again"), React.createElement("button", {
      onClick: () => window.location.reload(),
      style: {
        background: "rgba(229,9,20,0.85)",
        border: "none",
        borderRadius: 8,
        color: "#fff",
        cursor: "pointer",
        fontSize: 14,
        fontWeight: 600,
        padding: "10px 22px"
      }
    }, "Reload App")));
  }
}
exports.default = ErrorBoundary;
},
"./components/ExoPlayerOverlay": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = ExoPlayerOverlay;
exports.parseSubtitleCues = parseSubtitleCues;
var _react = _interopRequireWildcard(require("react"));
var _Icons = require("./Icons");
var _storage = require("../utils/storage");
var _gamepadSpatialNav = require("../utils/gamepadSpatialNav");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function (nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function parseSubtitleCues(rawText) {
  if (!rawText || typeof rawText !== "string") return [];
  const normalized = rawText.replace(/\r\n/g, "\n").replace(/\r/g, "\n");
  const blocks = normalized.split(/\n\n+/);
  const cues = [];
  const parseTime = t => {
    const clean = t.trim().replace(",", ".");
    const parts = clean.split(":");
    if (parts.length === 3) {
      return parseInt(parts[0], 10) * 3600 + parseInt(parts[1], 10) * 60 + parseFloat(parts[2]);
    }
    if (parts.length === 2) {
      return parseInt(parts[0], 10) * 60 + parseFloat(parts[1]);
    }
    return 0;
  };
  for (const block of blocks) {
    const lines = block.split("\n").map(l => l.trim()).filter(Boolean);
    if (!lines.length || lines[0].startsWith("WEBVTT")) continue;
    const arrowIdx = lines.findIndex(l => l.includes("-->"));
    if (arrowIdx === -1) continue;
    const [startStr, endPart] = lines[arrowIdx].split("-->");
    const endStr = (endPart || "").trim().split(/\s+/)[0];
    const start = parseTime(startStr);
    const end = parseTime(endStr);
    const text = lines.slice(arrowIdx + 1).join("\n").replace(/<[^>]+>/g, "");
    if (Number.isFinite(start) && Number.isFinite(end) && text) {
      cues.push({
        start,
        end,
        text
      });
    }
  }
  return cues;
}
const SPEEDS = [0.75, 1.0, 1.25, 1.5, 2.0];
const SUB_SIZES = [{
  id: "sm",
  label: "Small",
  px: 16
}, {
  id: "normal",
  label: "Normal",
  px: 22
}, {
  id: "lg",
  label: "Large",
  px: 28
}, {
  id: "xl",
  label: "TV XL",
  px: 34
}];
function ExoPlayerOverlay({
  session,
  onClose,
  onProgressUpdate
}) {
  const videoRef = (0, _react.useRef)(null);
  const playBtnRef = (0, _react.useRef)(null);
  const hideTimerRef = (0, _react.useRef)(null);
  const [playing, setPlaying] = (0, _react.useState)(true);
  const [controlsVisible, setControlsVisible] = (0, _react.useState)(true);
  const [currentTime, setCurrentTime] = (0, _react.useState)(session?.startTimeSec || 0);
  const [duration, setDuration] = (0, _react.useState)(0);
  const [speed, setSpeed] = (0, _react.useState)(1.0);
  const [subDelaySec, setSubDelaySec] = (0, _react.useState)(() => (Number(_storage.storage.get(_storage.STORAGE_KEYS.SUBTITLE_DELAY_MS)) || 0) / 1000);
  const [subSize, setSubSize] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.SUBTITLE_FONT_SCALE) || "normal");
  const [subBottomPct, setSubBottomPct] = (0, _react.useState)(() => Number(_storage.storage.get(_storage.STORAGE_KEYS.SUBTITLE_POSITION)) || 10);
  const [activeSubIdx, setActiveSubIdx] = (0, _react.useState)(0);
  const [cues, setCues] = (0, _react.useState)([]);
  const [activeCueText, setActiveCueText] = (0, _react.useState)("");
  const [showSubPanel, setShowSubPanel] = (0, _react.useState)(false);
  const [errorMsg, setErrorMsg] = (0, _react.useState)(null);
  const subtitles = session?.subtitles || [];
  const revealControls = (0, _react.useCallback)(() => {
    setControlsVisible(true);
    if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    hideTimerRef.current = setTimeout(() => {
      if (videoRef.current && !videoRef.current.paused && !showSubPanel) {
        setControlsVisible(false);
      }
    }, 4500);
  }, [showSubPanel]);
  (0, _react.useEffect)(() => {
    revealControls();
    const tid = setTimeout(() => {
      if (playBtnRef.current) (0, _gamepadSpatialNav.setGamepadFocus)(playBtnRef.current, {
        scroll: false
      });
    }, 80);
    return () => {
      clearTimeout(tid);
      if (hideTimerRef.current) clearTimeout(hideTimerRef.current);
    };
  }, [revealControls]);
  (0, _react.useEffect)(() => {
    if (activeSubIdx < 0 || !subtitles[activeSubIdx]?.url) {
      setCues([]);
      return;
    }
    let cancelled = false;
    fetch(subtitles[activeSubIdx].url).then(r => r.text()).then(txt => {
      if (!cancelled) setCues(parseSubtitleCues(txt));
    }).catch(() => {
      if (!cancelled) setCues([]);
    });
    return () => {
      cancelled = true;
    };
  }, [activeSubIdx, subtitles]);
  (0, _react.useEffect)(() => {
    if (!cues.length) {
      setActiveCueText("");
      return;
    }
    const adjusted = currentTime - subDelaySec;
    const hit = cues.find(c => adjusted >= c.start && adjusted <= c.end);
    setActiveCueText(hit ? hit.text : "");
  }, [currentTime, subDelaySec, cues]);
  const changeSpeed = next => {
    setSpeed(next);
    if (videoRef.current) videoRef.current.playbackRate = next;
    revealControls();
  };
  const seekBy = (0, _react.useCallback)(delta => {
    const v = videoRef.current;
    if (!v) return;
    v.currentTime = Math.max(0, Math.min(v.duration || 1e9, v.currentTime + delta));
    revealControls();
  }, [revealControls]);
  const togglePlay = (0, _react.useCallback)(() => {
    const v = videoRef.current;
    if (!v) return;
    if (v.paused) v.play();else v.pause();
    revealControls();
  }, [revealControls]);
  (0, _react.useEffect)(() => {
    const onActivity = () => revealControls();
    window.addEventListener("keydown", onActivity);
    window.addEventListener("streambert:dpad", onActivity);
    return () => {
      window.removeEventListener("keydown", onActivity);
      window.removeEventListener("streambert:dpad", onActivity);
    };
  }, [revealControls]);
  if (!session) return null;
  const fmtTime = s => {
    if (!s || !Number.isFinite(s)) return "0:00";
    const h = Math.floor(s / 3600);
    const m = Math.floor(s % 3600 / 60);
    const sec = Math.floor(s % 60);
    return h > 0 ? `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}` : `${m}:${String(sec).padStart(2, "0")}`;
  };
  const fontPx = SUB_SIZES.find(s => s.id === subSize)?.px ?? 22;
  const pct = duration > 0 ? Math.min(100, currentTime / duration * 100) : 0;
  return _react.default.createElement("div", {
    className: "nf-player-overlay",
    onMouseMove: revealControls,
    onTouchStart: revealControls
  }, _react.default.createElement("video", {
    ref: videoRef,
    src: session.url,
    autoPlay: true,
    playsInline: true,
    controls: false,
    onClick: togglePlay,
    onLoadedMetadata: e => {
      setDuration(e.currentTarget.duration || 0);
      if (session.startTimeSec > 0) {
        e.currentTarget.currentTime = session.startTimeSec;
      }
    },
    onTimeUpdate: e => {
      const ct = e.currentTarget.currentTime;
      const dur = e.currentTarget.duration || 0;
      setCurrentTime(ct);
      if (dur > 0 && onProgressUpdate) {
        onProgressUpdate(ct, dur);
      }
    },
    onPlay: () => setPlaying(true),
    onPause: () => {
      setPlaying(false);
      setControlsVisible(true);
    },
    onError: () => setErrorMsg("Stream requires Native Android ExoPlayer headers or a different source."),
    className: "nf-player-video"
  }), activeCueText && _react.default.createElement("div", {
    className: "nf-subtitle-wrap",
    style: {
      bottom: `${subBottomPct}%`
    }
  }, _react.default.createElement("span", {
    className: "nf-subtitle-text",
    style: {
      fontSize: fontPx
    }
  }, activeCueText)), _react.default.createElement("div", {
    className: `nf-player-chrome${controlsVisible || !playing || showSubPanel ? " visible" : ""}`
  }, _react.default.createElement("div", {
    className: "nf-player-topbar"
  }, _react.default.createElement("div", {
    className: "nf-player-title-group"
  }, _react.default.createElement("button", {
    className: "nf-player-btn nf-player-back",
    "data-gamepad-close": "1",
    onClick: onClose,
    "aria-label": "Back"
  }, _react.default.createElement(_Icons.BackIcon, null)), _react.default.createElement("div", {
    className: "nf-player-title-text"
  }, _react.default.createElement("span", {
    className: "nf-player-badge"
  }, "NETFLIX PLAYER"), _react.default.createElement("h2", {
    className: "nf-player-title"
  }, session.title || "SingularityTV"))), _react.default.createElement("button", {
    className: `nf-player-btn nf-player-pill-btn${showSubPanel ? " active" : ""}`,
    onClick: () => setShowSubPanel(v => !v)
  }, _react.default.createElement(_Icons.SubtitlesIcon, {
    size: 16
  }), _react.default.createElement("span", null, "Audio & Subtitles"))), showSubPanel && _react.default.createElement("div", {
    className: "nf-sub-panel",
    onClick: e => e.stopPropagation()
  }, _react.default.createElement("div", {
    className: "nf-sub-panel-header"
  }, _react.default.createElement("span", null, "Subtitles & Sync"), _react.default.createElement("button", {
    className: "nf-player-btn nf-sub-close",
    onClick: () => setShowSubPanel(false)
  }, _react.default.createElement(_Icons.CloseIcon, null))), _react.default.createElement("div", {
    className: "nf-sub-section"
  }, _react.default.createElement("div", {
    className: "nf-sub-label"
  }, "Track"), _react.default.createElement("div", {
    className: "nf-sub-row"
  }, _react.default.createElement("button", {
    className: `nf-player-btn nf-sub-chip${activeSubIdx === -1 ? " active" : ""}`,
    onClick: () => setActiveSubIdx(-1)
  }, "Off"), subtitles.map((s, idx) => _react.default.createElement("button", {
    key: idx,
    className: `nf-player-btn nf-sub-chip${activeSubIdx === idx ? " active" : ""}`,
    onClick: () => setActiveSubIdx(idx)
  }, (s.lang || `Track ${idx + 1}`).toUpperCase())))), _react.default.createElement("div", {
    className: "nf-sub-section"
  }, _react.default.createElement("div", {
    className: "nf-sub-label"
  }, "Sync Delay (", subDelaySec >= 0 ? `+${subDelaySec.toFixed(1)}s` : `${subDelaySec.toFixed(1)}s`, ")"), _react.default.createElement("div", {
    className: "nf-sub-row"
  }, _react.default.createElement("button", {
    className: "nf-player-btn nf-sub-chip",
    onClick: () => {
      const next = Math.round((subDelaySec - 0.2) * 10) / 10;
      setSubDelaySec(next);
      _storage.storage.set(_storage.STORAGE_KEYS.SUBTITLE_DELAY_MS, next * 1000);
    }
  }, "-0.2s"), _react.default.createElement("button", {
    className: "nf-player-btn nf-sub-chip",
    onClick: () => {
      setSubDelaySec(0);
      _storage.storage.set(_storage.STORAGE_KEYS.SUBTITLE_DELAY_MS, 0);
    }
  }, "0.0s"), _react.default.createElement("button", {
    className: "nf-player-btn nf-sub-chip",
    onClick: () => {
      const next = Math.round((subDelaySec + 0.2) * 10) / 10;
      setSubDelaySec(next);
      _storage.storage.set(_storage.STORAGE_KEYS.SUBTITLE_DELAY_MS, next * 1000);
    }
  }, "+0.2s"))), _react.default.createElement("div", {
    className: "nf-sub-section"
  }, _react.default.createElement("div", {
    className: "nf-sub-label"
  }, "Font Size"), _react.default.createElement("div", {
    className: "nf-sub-row"
  }, SUB_SIZES.map(s => _react.default.createElement("button", {
    key: s.id,
    className: `nf-player-btn nf-sub-chip${subSize === s.id ? " active" : ""}`,
    onClick: () => {
      setSubSize(s.id);
      _storage.storage.set(_storage.STORAGE_KEYS.SUBTITLE_FONT_SCALE, s.id);
    }
  }, s.label))))), _react.default.createElement("div", {
    className: "nf-player-bottom"
  }, _react.default.createElement("div", {
    className: "nf-progress-row"
  }, _react.default.createElement("div", {
    className: "nf-progress-track-wrap"
  }, _react.default.createElement("input", {
    type: "range",
    className: "nf-progress",
    min: 0,
    max: Math.max(1, Math.floor(duration)),
    value: Math.floor(currentTime),
    style: {
      background: `linear-gradient(to right, #e50914 ${pct}%, rgba(255,255,255,0.25) ${pct}%)`
    },
    onChange: e => {
      const val = Number(e.target.value);
      setCurrentTime(val);
      if (videoRef.current) videoRef.current.currentTime = val;
      revealControls();
    }
  })), _react.default.createElement("span", {
    className: "nf-time-display"
  }, fmtTime(currentTime), " / ", fmtTime(duration))), _react.default.createElement("div", {
    className: "nf-player-main-controls"
  }, _react.default.createElement("div", {
    className: "nf-controls-left"
  }, _react.default.createElement("button", {
    ref: playBtnRef,
    className: "nf-player-btn nf-play-toggle",
    onClick: togglePlay
  }, _react.default.createElement(_Icons.PlayIcon, null), _react.default.createElement("span", null, playing ? "Pause" : "Play")), _react.default.createElement("button", {
    className: "nf-player-btn nf-seek-btn",
    onClick: () => seekBy(-10)
  }, "\u21BA 10s"), _react.default.createElement("button", {
    className: "nf-player-btn nf-seek-btn",
    onClick: () => seekBy(10)
  }, "10s \u21BB")), _react.default.createElement("div", {
    className: "nf-controls-right"
  }, SPEEDS.map(s => _react.default.createElement("button", {
    key: s,
    className: `nf-player-btn nf-speed-btn${speed === s ? " active" : ""}`,
    onClick: () => changeSpeed(s)
  }, s, "x")))))), errorMsg && _react.default.createElement("div", {
    className: "nf-player-error"
  }, _react.default.createElement("div", {
    style: {
      fontSize: 16,
      fontWeight: 600,
      color: "#e50914"
    }
  }, "\u26A0 ", errorMsg), _react.default.createElement("button", {
    className: "nf-player-btn nf-play-toggle",
    onClick: onClose
  }, "Return")));
}
},
"./components/HeroBanner": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = HeroBanner;
var _react = _interopRequireWildcard(require("react"));
var _api = require("../utils/api");
var _Icons = require("./Icons");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function (nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function HeroBanner({
  items = [],
  onSelect,
  ratingsMap = {}
}) {
  const [activeIndex, setActiveIndex] = (0, _react.useState)(0);
  (0, _react.useEffect)(() => {
    if (items.length <= 1) return;
    const interval = setInterval(() => {
      setActiveIndex(prev => (prev + 1) % items.length);
    }, 7000);
    return () => clearInterval(interval);
  }, [items.length]);
  const item = items[activeIndex] || items[0];
  if (!item) return null;
  const title = item.title || item.name;
  const year = (item.release_date || item.first_air_date || "").slice(0, 4);
  const mediaType = item.media_type === "tv" ? "tv" : "movie";
  const ratingInfo = ratingsMap[`${mediaType}_${item.id}`] || {};
  const backdrop = (0, _api.imgUrl)(item.backdrop_path || item.poster_path, "original");
  return _react.default.createElement("section", {
    className: "hero-banner"
  }, _react.default.createElement("div", {
    className: "hero-banner-bg",
    style: {
      backgroundImage: backdrop ? `url(${backdrop})` : "none"
    }
  }), _react.default.createElement("div", {
    className: "hero-banner-scrim"
  }), _react.default.createElement("div", {
    className: "hero-banner-inner"
  }, _react.default.createElement("div", {
    className: "hero-banner-content"
  }, _react.default.createElement("div", {
    className: "hero-banner-pills"
  }, _react.default.createElement("span", {
    className: "hero-pill hero-pill--accent"
  }, "FEATURED"), _react.default.createElement("span", {
    className: "hero-pill"
  }, mediaType === "tv" ? "SERIES" : "MOVIE"), year && _react.default.createElement("span", {
    className: "hero-pill"
  }, year), ratingInfo.cert && _react.default.createElement("span", {
    className: "hero-pill"
  }, ratingInfo.cert), item.vote_average > 0 && _react.default.createElement("span", {
    className: "hero-pill hero-pill--score"
  }, _react.default.createElement(_Icons.StarIcon, {
    size: 11
  }), item.vote_average.toFixed(1))), _react.default.createElement("h1", {
    className: "hero-banner-title"
  }, title), item.overview && _react.default.createElement("p", {
    className: "hero-banner-overview"
  }, item.overview), _react.default.createElement("div", {
    className: "hero-actions"
  }, _react.default.createElement("button", {
    className: "btn btn-primary hero-action-btn",
    onClick: () => onSelect(item)
  }, _react.default.createElement(_Icons.PlayIcon, null), _react.default.createElement("span", null, "Watch Now")), _react.default.createElement("button", {
    className: "btn btn-secondary hero-action-btn",
    onClick: () => onSelect(item)
  }, _react.default.createElement("span", null, "More Info")))), _react.default.createElement("div", {
    className: "hero-banner-right"
  }, items.length > 1 && _react.default.createElement("div", {
    className: "hero-dots-pill"
  }, items.map((slide, idx) => _react.default.createElement("button", {
    key: slide.id || idx,
    className: `hero-dot${idx === activeIndex ? " active" : ""}`,
    onClick: () => setActiveIndex(idx),
    "aria-label": `Featured item ${idx + 1}`
  }))), _react.default.createElement("div", {
    className: "hero-platform-badge"
  }, _react.default.createElement("span", {
    className: "hero-platform-logo"
  }, "SINGULARITY TV"), _react.default.createElement("span", {
    className: "hero-platform-sub"
  }, "4K HDR \xB7 Instant Stream")))));
}
},
"./components/HiAnimeLoader": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = HiAnimeLoader;
var _react = require("react");
const STEPS = [{
  id: "search",
  label: "Searching title"
}, {
  id: "episodes",
  label: "Loading episode list"
}, {
  id: "stream",
  label: "Fetching stream"
}, {
  id: "player",
  label: "Starting player"
}];
function HiAnimeLoader({
  what = "episode",
  playerStarting
}) {
  const [stage, setStage] = (0, _react.useState)("search");
  (0, _react.useEffect)(() => {
    setStage("search");
    const off = window.electron?.onHiAnimeProgress?.(s => {
      if (s) setStage(s);
    });
    return () => {
      if (typeof off === "function") off();
    };
  }, []);
  const current = playerStarting ? STEPS.length - 1 : Math.max(0, STEPS.findIndex(s => s.id === stage));
  return React.createElement(React.Fragment, null, React.createElement("div", {
    className: "spinner"
  }), React.createElement("span", {
    style: {
      fontSize: 14,
      color: "var(--text2)"
    }
  }, "Looking up ", what, " on HiAnime\u2026"), React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 6,
      minWidth: 190
    },
    role: "status",
    "aria-live": "polite"
  }, STEPS.map((step, i) => React.createElement("div", {
    key: step.id,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      fontSize: 12,
      color: i < current ? "var(--text2)" : i === current ? "var(--text)" : "var(--text3)",
      opacity: i > current ? 0.5 : 1,
      fontWeight: i === current ? 600 : 400
    }
  }, React.createElement("span", {
    style: {
      width: 14,
      textAlign: "center"
    }
  }, i < current ? "✓" : i === current ? "●" : "○"), step.label))));
}
},
"./components/Icons": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.WifiOffIcon = exports.WatchedIcon = exports.WarningIcon = exports.TrashIcon = exports.TrailerIcon = exports.TVIcon = exports.SubtitlesIcon = exports.StarIcon = exports.SourceIcon = exports.SingularityTVLogo = exports.ShieldBlockIcon = exports.SettingsIcon = exports.SearchIcon = exports.RatingShieldIcon = exports.RatingLockIcon = exports.QuitIcon = exports.PopOutIcon = exports.PlayIcon = exports.HomeIcon = exports.HistoryIcon = exports.HelpIcon = exports.FolderIcon = exports.FilmIcon = exports.EyeIcon = exports.ExternalLinkIcon = exports.DownloadsQueueIcon = exports.DownloadIcon = exports.CloseIcon = exports.ChevronRightIcon = exports.ChevronLeftIcon = exports.CastIcon = exports.BookmarkIcon = exports.BookmarkFillIcon = exports.BackIcon = exports.AlertIcon = void 0;
function _extends() {
  _extends = Object.assign ? Object.assign.bind() : function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];
      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }
    return target;
  };
  return _extends.apply(this, arguments);
}
const SingularityTVLogo = ({
  style
}) => React.createElement("img", {
  src: "./logo.svg",
  alt: "SingularityTV",
  width: "44",
  height: "44",
  style: {
    width: "100%",
    height: "100%",
    display: "block",
    ...style
  }
});
exports.SingularityTVLogo = SingularityTVLogo;
const SearchIcon = () => React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("circle", {
  cx: "11",
  cy: "11",
  r: "8"
}), React.createElement("path", {
  d: "m21 21-4.35-4.35"
}));
exports.SearchIcon = SearchIcon;
const HistoryIcon = () => React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("path", {
  d: "M12 8v4l3 3"
}), React.createElement("path", {
  d: "M3.05 11a9 9 0 1 1 .5 4"
}), React.createElement("path", {
  d: "M3 3v5h5"
}));
exports.HistoryIcon = HistoryIcon;
const BookmarkIcon = () => React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("path", {
  d: "M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"
}));
exports.BookmarkIcon = BookmarkIcon;
const BookmarkFillIcon = () => React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "currentColor"
}, React.createElement("path", {
  d: "M19 21l-7-5-7 5V5a2 2 0 0 1 2-2h10a2 2 0 0 1 2 2z"
}));
exports.BookmarkFillIcon = BookmarkFillIcon;
const PlayIcon = () => React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "currentColor"
}, React.createElement("polygon", {
  points: "5 3 19 12 5 21 5 3"
}));
exports.PlayIcon = PlayIcon;
const CloseIcon = () => React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("line", {
  x1: "18",
  y1: "6",
  x2: "6",
  y2: "18"
}), React.createElement("line", {
  x1: "6",
  y1: "6",
  x2: "18",
  y2: "18"
}));
exports.CloseIcon = CloseIcon;
const FilmIcon = () => React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("rect", {
  x: "2",
  y: "2",
  width: "20",
  height: "20",
  rx: "2.18",
  ry: "2.18"
}), React.createElement("line", {
  x1: "7",
  y1: "2",
  x2: "7",
  y2: "22"
}), React.createElement("line", {
  x1: "17",
  y1: "2",
  x2: "17",
  y2: "22"
}), React.createElement("line", {
  x1: "2",
  y1: "12",
  x2: "22",
  y2: "12"
}), React.createElement("line", {
  x1: "2",
  y1: "7",
  x2: "7",
  y2: "7"
}), React.createElement("line", {
  x1: "17",
  y1: "7",
  x2: "22",
  y2: "7"
}), React.createElement("line", {
  x1: "17",
  y1: "17",
  x2: "22",
  y2: "17"
}), React.createElement("line", {
  x1: "2",
  y1: "17",
  x2: "7",
  y2: "17"
}));
exports.FilmIcon = FilmIcon;
const TVIcon = () => React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("rect", {
  x: "2",
  y: "7",
  width: "20",
  height: "15",
  rx: "2",
  ry: "2"
}), React.createElement("polyline", {
  points: "17 2 12 7 7 2"
}));
exports.TVIcon = TVIcon;
const HomeIcon = () => React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("path", {
  d: "m3 9 9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"
}), React.createElement("polyline", {
  points: "9 22 9 12 15 12 15 22"
}));
exports.HomeIcon = HomeIcon;
const StarIcon = ({
  size = 16
}) => React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "currentColor",
  width: size,
  height: size
}, React.createElement("polygon", {
  points: "12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"
}));
exports.StarIcon = StarIcon;
const SettingsIcon = () => React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("circle", {
  cx: "12",
  cy: "12",
  r: "3"
}), React.createElement("path", {
  d: "M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"
}));
exports.SettingsIcon = SettingsIcon;
const HelpIcon = () => React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2",
  style: {
    width: 24,
    height: 24
  }
}, React.createElement("circle", {
  cx: "12",
  cy: "12",
  r: "10"
}), React.createElement("path", {
  d: "M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"
}), React.createElement("line", {
  x1: "12",
  y1: "17",
  x2: "12.01",
  y2: "17",
  strokeWidth: "2.5",
  strokeLinecap: "round"
}));
exports.HelpIcon = HelpIcon;
const EyeIcon = () => React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("path", {
  d: "M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"
}), React.createElement("circle", {
  cx: "12",
  cy: "12",
  r: "3"
}));
exports.EyeIcon = EyeIcon;
const DownloadIcon = () => React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("path", {
  d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"
}), React.createElement("polyline", {
  points: "7 10 12 15 17 10"
}), React.createElement("line", {
  x1: "12",
  y1: "15",
  x2: "12",
  y2: "3"
}));
exports.DownloadIcon = DownloadIcon;
const TrashIcon = () => React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("polyline", {
  points: "3 6 5 6 21 6"
}), React.createElement("path", {
  d: "M19 6l-1 14H6L5 6"
}), React.createElement("path", {
  d: "M10 11v6M14 11v6"
}), React.createElement("path", {
  d: "M9 6V4h6v2"
}));
exports.TrashIcon = TrashIcon;
const FolderIcon = () => React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("path", {
  d: "M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"
}));
exports.FolderIcon = FolderIcon;
const WatchedIcon = ({
  size = 22
}) => React.createElement("svg", {
  viewBox: "0 0 24 24",
  width: size,
  height: size,
  fill: "none",
  style: {
    filter: "drop-shadow(0 0 4px rgba(72,199,116,0.7))"
  }
}, React.createElement("circle", {
  cx: "12",
  cy: "12",
  r: "11",
  fill: "#1a2e1a",
  stroke: "#48c774",
  strokeWidth: "1.5"
}), React.createElement("path", {
  d: "M6.5 12.5l3.5 3.5 7-7",
  stroke: "#48c774",
  strokeWidth: "2.2",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}));
exports.WatchedIcon = WatchedIcon;
const TrailerIcon = () => React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("rect", {
  x: "2",
  y: "2",
  width: "20",
  height: "20",
  rx: "2",
  ry: "2"
}), React.createElement("polygon", {
  points: "10 8 16 12 10 16 10 8",
  fill: "currentColor",
  stroke: "none"
}));
exports.TrailerIcon = TrailerIcon;
const DownloadsQueueIcon = () => React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2"
}, React.createElement("path", {
  d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"
}), React.createElement("polyline", {
  points: "7 10 12 15 17 10"
}), React.createElement("line", {
  x1: "12",
  y1: "15",
  x2: "12",
  y2: "3"
}), React.createElement("line", {
  x1: "3",
  y1: "21",
  x2: "21",
  y2: "21"
}));
exports.DownloadsQueueIcon = DownloadsQueueIcon;
const QuitIcon = () => React.createElement("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  width: "22",
  height: "22",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2.2",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, React.createElement("path", {
  d: "M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"
}), React.createElement("polyline", {
  points: "16 17 21 12 16 7"
}), React.createElement("line", {
  x1: "21",
  y1: "12",
  x2: "9",
  y2: "12"
}));
exports.QuitIcon = QuitIcon;
const BackIcon = () => React.createElement("svg", {
  xmlns: "http://www.w3.org/2000/svg",
  width: "22",
  height: "22",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2.2",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, React.createElement("polyline", {
  points: "15 18 9 12 15 6"
}));
exports.BackIcon = BackIcon;
const RatingShieldIcon = ({
  size = 10
}) => React.createElement("svg", {
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "currentColor",
  style: {
    flexShrink: 0
  }
}, React.createElement("path", {
  d: "M12 1L3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z"
}));
exports.RatingShieldIcon = RatingShieldIcon;
const RatingLockIcon = ({
  size = 10
}) => React.createElement("svg", {
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2.5",
  strokeLinecap: "round",
  strokeLinejoin: "round",
  style: {
    flexShrink: 0
  }
}, React.createElement("rect", {
  x: "3",
  y: "11",
  width: "18",
  height: "11",
  rx: "2",
  ry: "2"
}), React.createElement("path", {
  d: "M7 11V7a5 5 0 0 1 10 0v4"
}));
exports.RatingLockIcon = RatingLockIcon;
const SourceIcon = () => React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, React.createElement("ellipse", {
  cx: "12",
  cy: "12",
  rx: "10",
  ry: "10"
}), React.createElement("ellipse", {
  cx: "12",
  cy: "12",
  rx: "4",
  ry: "10"
}), React.createElement("line", {
  x1: "2",
  y1: "12",
  x2: "22",
  y2: "12"
}));
exports.SourceIcon = SourceIcon;
const WarningIcon = ({
  size = 24,
  color = "var(--red)"
}) => React.createElement("svg", {
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: color,
  strokeWidth: "2",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, React.createElement("path", {
  d: "M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"
}), React.createElement("line", {
  x1: "12",
  y1: "9",
  x2: "12",
  y2: "13"
}), React.createElement("line", {
  x1: "12",
  y1: "17",
  x2: "12.01",
  y2: "17"
}));
exports.WarningIcon = WarningIcon;
const ExternalLinkIcon = ({
  size = 13
}) => React.createElement("svg", {
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, React.createElement("path", {
  d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"
}), React.createElement("polyline", {
  points: "15 3 21 3 21 9"
}), React.createElement("line", {
  x1: "10",
  y1: "14",
  x2: "21",
  y2: "3"
}));
exports.ExternalLinkIcon = ExternalLinkIcon;
const ChevronLeftIcon = ({
  size = 26
}) => React.createElement("svg", {
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2.5",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, React.createElement("polyline", {
  points: "15 18 9 12 15 6"
}));
exports.ChevronLeftIcon = ChevronLeftIcon;
const ChevronRightIcon = ({
  size = 26
}) => React.createElement("svg", {
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2.5",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, React.createElement("polyline", {
  points: "9 18 15 12 9 6"
}));
exports.ChevronRightIcon = ChevronRightIcon;
const ShieldBlockIcon = ({
  size = 16
}) => React.createElement("svg", {
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, React.createElement("path", {
  d: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"
}), React.createElement("polyline", {
  points: "9 12 11 14 15 10"
}));
exports.ShieldBlockIcon = ShieldBlockIcon;
const SubtitlesIcon = ({
  size = 16,
  ...props
}) => React.createElement("svg", _extends({
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, props), React.createElement("rect", {
  x: "2",
  y: "4",
  width: "20",
  height: "16",
  rx: "2"
}), React.createElement("path", {
  d: "M7 15h4M15 15h2M7 11h2M13 11h4"
}));
exports.SubtitlesIcon = SubtitlesIcon;
const PopOutIcon = ({
  size = 16
}) => React.createElement("svg", {
  width: size,
  height: size,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, React.createElement("rect", {
  x: "2",
  y: "7",
  width: "13",
  height: "10",
  rx: "2"
}), React.createElement("path", {
  d: "M15 3h6v6"
}), React.createElement("path", {
  d: "M10 14L21 3"
}));
exports.PopOutIcon = PopOutIcon;
const CastIcon = ({
  size = 20
}) => React.createElement("svg", {
  width: size,
  height: size,
  fill: "currentColor",
  stroke: "none",
  viewBox: "0 0 32 32",
  xmlns: "http://www.w3.org/2000/svg"
}, React.createElement("path", {
  d: "M16 15.503A5.041 5.041 0 1 0 16 5.42a5.041 5.041 0 0 0 0 10.083zm0 2.215c-6.703 0-11 3.699-11 5.5v3.363h22v-3.363c0-2.178-4.068-5.5-11-5.5z"
}));
exports.CastIcon = CastIcon;
const WifiOffIcon = ({
  size = 44
}) => React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2",
  strokeLinecap: "round",
  strokeLinejoin: "round",
  width: size,
  height: size
}, React.createElement("line", {
  x1: "1",
  y1: "1",
  x2: "23",
  y2: "23"
}), React.createElement("path", {
  d: "M16.72 11.06A10.94 10.94 0 0 1 19 12.55"
}), React.createElement("path", {
  d: "M5 12.55a10.94 10.94 0 0 1 5.17-2.39"
}), React.createElement("path", {
  d: "M10.71 5.05A16 16 0 0 1 22.58 9"
}), React.createElement("path", {
  d: "M1.42 9a15.91 15.91 0 0 1 4.7-2.88"
}), React.createElement("path", {
  d: "M8.53 16.11a6 6 0 0 1 6.95 0"
}), React.createElement("line", {
  x1: "12",
  y1: "20",
  x2: "12.01",
  y2: "20"
}));
exports.WifiOffIcon = WifiOffIcon;
const AlertIcon = ({
  size = 24
}) => React.createElement("svg", {
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "2",
  strokeLinecap: "round",
  strokeLinejoin: "round",
  width: size,
  height: size
}, React.createElement("path", {
  d: "M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"
}), React.createElement("line", {
  x1: "12",
  y1: "9",
  x2: "12",
  y2: "13"
}), React.createElement("line", {
  x1: "12",
  y1: "17",
  x2: "12.01",
  y2: "17"
}));
exports.AlertIcon = AlertIcon;
},
"./components/MediaCard": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _react = _interopRequireWildcard(require("react"));
var _api = require("../utils/api");
var _Icons = require("./Icons");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function (nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
const MediaCard = (0, _react.memo)(function MediaCard({
  item,
  variant = "landscape",
  onClick,
  progress,
  watched,
  onMarkWatched,
  onMarkUnwatched,
  ageRating,
  restricted
}) {
  const title = item.title || item.name;
  const year = (item.release_date || item.first_air_date || "").slice(0, 4);
  const isTV = item.media_type === "tv";
  const isAnime = (0, _api.isAnimeContent)(item);
  const isLandscape = variant === "landscape";
  const rawDate = item.release_date || item.first_air_date;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const isUnreleased = rawDate ? new Date(rawDate) > today : false;
  const watchedKey = isTV ? item.season != null && item.episode != null ? `tv_${item.id}_s${item.season}e${item.episode}` : `tv_${item.id}` : `movie_${item.id}`;
  const isWatched = !!watched?.[watchedKey];
  const [menu, setMenu] = (0, _react.useState)(null);
  const menuRef = (0, _react.useRef)(null);
  const canMarkWatched = !isTV || item.season != null && item.episode != null;
  const openMenu = (0, _react.useCallback)(e => {
    if (!canMarkWatched) return;
    e.preventDefault();
    e.stopPropagation();
    setMenu({
      x: e.clientX,
      y: e.clientY
    });
  }, [canMarkWatched]);
  (0, _react.useEffect)(() => {
    if (!menu) return;
    const close = () => setMenu(null);
    window.addEventListener("click", close);
    window.addEventListener("contextmenu", close);
    return () => {
      window.removeEventListener("click", close);
      window.removeEventListener("contextmenu", close);
    };
  }, [menu]);
  const imagePath = isLandscape ? item.backdrop_path || item.poster_path : item.poster_path || item.backdrop_path;
  const imageSrc = imagePath ? (0, _api.imgUrl)(imagePath, isLandscape ? "w780" : "w342") : null;
  return _react.default.createElement(_react.default.Fragment, null, _react.default.createElement("div", {
    role: "button",
    tabIndex: 0,
    className: `card ${isLandscape ? "card--landscape" : "card--poster"}${isWatched ? " ep-watched" : ""}${isUnreleased ? " card--unreleased" : ""}`,
    onClick: onClick,
    onContextMenu: isUnreleased ? undefined : openMenu
  }, _react.default.createElement("div", {
    className: "card-media"
  }, imageSrc ? _react.default.createElement("img", {
    src: imageSrc,
    alt: title,
    loading: "lazy",
    draggable: false
  }) : _react.default.createElement("div", {
    className: "no-poster"
  }, isTV ? _react.default.createElement(_Icons.TVIcon, null) : _react.default.createElement(_Icons.FilmIcon, null), _react.default.createElement("span", {
    style: {
      fontSize: 11,
      color: "var(--text3)"
    }
  }, "No Image")), _react.default.createElement("div", {
    className: "card-gradient-overlay"
  }), ageRating && _react.default.createElement("div", {
    className: `card-age-badge${restricted ? " card-age-badge--restricted" : ""}`
  }, restricted ? _react.default.createElement(_Icons.RatingLockIcon, {
    size: 9
  }) : _react.default.createElement(_Icons.RatingShieldIcon, {
    size: 9
  }), ageRating), _react.default.createElement("span", {
    className: `card-badge${isUnreleased ? " card-badge--unreleased" : ""}${isAnime && !isUnreleased ? " card-badge--anime" : ""}`
  }, isUnreleased ? "SOON" : isAnime ? "ANIME" : isTV ? "TV" : "HD"), _react.default.createElement("div", {
    className: "card-overlay"
  }, isUnreleased ? _react.default.createElement("div", {
    className: "card-unreleased-overlay"
  }, _react.default.createElement("span", {
    className: "card-unreleased-label"
  }, _react.default.createElement(_Icons.RatingLockIcon, {
    size: 12
  }), " Unreleased")) : _react.default.createElement("div", {
    className: "card-play"
  }, _react.default.createElement(_Icons.PlayIcon, null))), _react.default.createElement("div", {
    className: "card-overlay-meta"
  }, _react.default.createElement("div", {
    className: "card-title",
    title: title
  }, title), _react.default.createElement("div", {
    className: "card-year"
  }, isTV && item.season != null && item.episode != null ? `S${item.season}E${item.episode}${item.episodeName ? ` · ${item.episodeName}` : ""}` : `${year ? `${year} · ` : ""}${isTV ? "Series" : "Movie"}`)), !isUnreleased && progress > 0 && !isWatched && _react.default.createElement("div", {
    className: "card-progress"
  }, _react.default.createElement("div", {
    className: "card-progress-fill",
    style: {
      width: `${Math.min(progress, 100)}%`
    }
  })), !isUnreleased && isWatched && _react.default.createElement("div", {
    className: "card-watched-badge"
  }, _react.default.createElement(_Icons.WatchedIcon, {
    size: 24
  })))), menu && _react.default.createElement("div", {
    ref: menuRef,
    className: "context-menu",
    style: {
      top: menu.y,
      left: menu.x
    },
    onClick: e => e.stopPropagation()
  }, isWatched ? _react.default.createElement("button", {
    className: "context-menu-item",
    onClick: e => {
      e.stopPropagation();
      onMarkUnwatched?.(watchedKey);
      setMenu(null);
    }
  }, "\u21A9 Mark as Unwatched") : _react.default.createElement("button", {
    className: "context-menu-item",
    onClick: e => {
      e.stopPropagation();
      onMarkWatched?.(watchedKey);
      setMenu(null);
    }
  }, "\u2713 Mark as Watched")));
});
var _default = MediaCard;
exports.default = _default;
},
"./components/SearchModal": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = SearchModal;
var _react = _interopRequireWildcard(require("react"));
var _api = require("../utils/api");
var _Icons = require("./Icons");
var _gamepadSpatialNav = require("../utils/gamepadSpatialNav");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function (nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
const EN_ROWS = [["a", "b", "c", "d", "e", "f"], ["g", "h", "i", "j", "k", "l"], ["m", "n", "o", "p", "q", "r"], ["s", "t", "u", "v", "w", "x"], ["y", "z", "1", "2", "3", "4"], ["5", "6", "7", "8", "9", "0"]];
const AR_ROWS = [["ا", "ب", "ت", "ث", "ج", "ح"], ["خ", "د", "ذ", "ر", "ز", "س"], ["ش", "ص", "ض", "ط", "ظ", "ع"], ["غ", "ف", "ق", "ك", "ل", "م"], ["ن", "ه", "و", "ي", "ة", "ى"], ["أ", "إ", "آ", "ؤ", "ئ", "ء"]];
const SearchResultCard = (0, _react.memo)(function SearchResultCard({
  item,
  onSelect
}) {
  const thumb = item.backdrop_path ? (0, _api.imgUrl)(item.backdrop_path, "w300") : item.poster_path ? (0, _api.imgUrl)(item.poster_path, "w185") : "data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='300' height='169'%3E%3Crect fill='%23181e2c' width='300' height='169'/%3E%3C/svg%3E";
  const title = item.title || item.name;
  return _react.default.createElement("button", {
    className: "nf-result-card",
    onClick: () => onSelect(item)
  }, _react.default.createElement("div", {
    className: "nf-result-thumb"
  }, _react.default.createElement("img", {
    src: thumb,
    alt: title,
    loading: "lazy",
    decoding: "async",
    draggable: false
  }), _react.default.createElement("span", {
    className: "nf-result-type"
  }, item.media_type === "tv" ? "SERIES" : "MOVIE")), _react.default.createElement("div", {
    className: "nf-result-title"
  }, title));
});
const KeyboardPanel = (0, _react.memo)(function KeyboardPanel({
  firstKeyRef,
  langMode,
  onToggleLang,
  onAppend,
  onBackspace,
  onClear
}) {
  const rows = langMode === "ar" ? AR_ROWS : EN_ROWS;
  return _react.default.createElement("div", {
    className: "nf-keyboard-panel"
  }, _react.default.createElement("div", {
    className: "nf-keyboard-actions"
  }, _react.default.createElement("button", {
    ref: firstKeyRef,
    className: "nf-key nf-key--action",
    onClick: onToggleLang
  }, langMode === "ar" ? "EN" : "عربي"), _react.default.createElement("button", {
    className: "nf-key nf-key--action nf-key--space",
    onClick: () => onAppend(" ")
  }, "\u2423"), _react.default.createElement("button", {
    className: "nf-key nf-key--action",
    onClick: onBackspace
  }, "\u232B"), _react.default.createElement("button", {
    className: "nf-key nf-key--action",
    onClick: onClear
  }, "Clear")), _react.default.createElement("div", {
    className: "nf-keyboard-grid",
    dir: langMode === "ar" ? "rtl" : "ltr"
  }, rows.flat().map(ch => _react.default.createElement("button", {
    key: ch,
    className: "nf-key",
    onClick: () => onAppend(ch)
  }, ch))));
});
function SearchModal({
  apiKey,
  onSelect,
  onClose,
  offline,
  trending = [],
  trendingTV = []
}) {
  const [query, setQuery] = (0, _react.useState)("");
  const [langMode, setLangMode] = (0, _react.useState)("en");
  const [results, setResults] = (0, _react.useState)([]);
  const [fallbackTrending, setFallbackTrending] = (0, _react.useState)([]);
  const [loading, setLoading] = (0, _react.useState)(false);
  const firstKeyRef = (0, _react.useRef)(null);
  (0, _react.useEffect)(() => {
    const tid = setTimeout(() => {
      if (firstKeyRef.current) (0, _gamepadSpatialNav.setGamepadFocus)(firstKeyRef.current, {
        scroll: false
      });
    }, 60);
    return () => clearTimeout(tid);
  }, []);
  const combinedTrending = (0, _react.useMemo)(() => {
    const out = [];
    const seen = new Set();
    const maxLen = Math.max(trending.length, trendingTV.length);
    for (let i = 0; i < maxLen; i++) {
      const m = trending[i];
      if (m && m.id && !seen.has(`movie_${m.id}`)) {
        seen.add(`movie_${m.id}`);
        out.push({
          ...m,
          media_type: m.media_type || "movie"
        });
      }
      const t = trendingTV[i];
      if (t && t.id && !seen.has(`tv_${t.id}`)) {
        seen.add(`tv_${t.id}`);
        out.push({
          ...t,
          media_type: t.media_type || "tv"
        });
      }
    }
    if (out.length > 0) return out;
    return fallbackTrending;
  }, [trending, trendingTV, fallbackTrending]);
  (0, _react.useEffect)(() => {
    if (offline || trending.length > 0 || trendingTV.length > 0) return;
    let mounted = true;
    const controller = new AbortController();
    (0, _api.tmdbFetch)("/trending/all/day", apiKey, {
      signal: controller.signal
    }).then(data => {
      if (!mounted) return;
      const items = (data.results || []).filter(x => x && x.id && (x.media_type === "movie" || x.media_type === "tv"));
      setFallbackTrending(items);
    }).catch(() => {});
    return () => {
      mounted = false;
      controller.abort();
    };
  }, [offline, trending.length, trendingTV.length, apiKey]);
  (0, _react.useEffect)(() => {
    const trimmed = query.trim();
    if (trimmed.length < 2) {
      setResults([]);
      setLoading(false);
      return;
    }
    let mounted = true;
    const controller = new AbortController();
    const hasArabic = /[\u0600-\u06FF]/.test(trimmed);
    const timer = setTimeout(async () => {
      setLoading(true);
      try {
        const langParam = hasArabic ? "&language=ar-SA" : "";
        const data = await (0, _api.tmdbFetch)(`/search/multi?query=${encodeURIComponent(trimmed)}&page=1${langParam}`, apiKey, {
          signal: controller.signal
        });
        const raw = data.results || [];
        const collected = [];
        const seen = new Set();
        const pushUnique = item => {
          if (!item || !item.id) return;
          const mt = item.media_type || (item.first_air_date ? "tv" : "movie");
          if (mt !== "movie" && mt !== "tv") return;
          const key = `${mt}_${item.id}`;
          if (seen.has(key)) return;
          seen.add(key);
          collected.push({
            ...item,
            media_type: mt
          });
        };
        const people = raw.filter(r => r.media_type === "person");
        for (const r of raw) {
          if (r.media_type === "person") {
            for (const kf of r.known_for || []) {
              pushUnique(kf);
            }
          } else {
            pushUnique(r);
          }
        }
        if (people.length > 0 && collected.length < 12) {
          try {
            const credits = await (0, _api.tmdbFetch)(`/person/${people[0].id}/combined_credits?${hasArabic ? "language=ar-SA" : ""}`, apiKey, {
              signal: controller.signal
            });
            const cast = (credits.cast || []).sort((a, b) => (b.popularity || 0) - (a.popularity || 0)).slice(0, 12);
            for (const c of cast) {
              pushUnique(c);
            }
          } catch {}
        }
        if (mounted) {
          setResults(collected.slice(0, 12));
        }
      } catch {}
      if (mounted) setLoading(false);
    }, 380);
    return () => {
      mounted = false;
      clearTimeout(timer);
      controller.abort();
    };
  }, [query, apiKey]);
  const appendChar = (0, _react.useCallback)(ch => {
    setQuery(prev => prev + ch);
  }, []);
  const handleBackspace = (0, _react.useCallback)(() => {
    setQuery(prev => prev.slice(0, -1));
  }, []);
  const handleClear = (0, _react.useCallback)(() => {
    setQuery("");
  }, []);
  const toggleLang = (0, _react.useCallback)(() => {
    setLangMode(prev => prev === "en" ? "ar" : "en");
  }, []);
  const handleSelect = (0, _react.useCallback)(item => {
    onSelect(item);
    onClose();
  }, [onSelect, onClose]);
  const isSearching = query.trim().length >= 2;
  const displayItems = isSearching ? results : combinedTrending.slice(0, 12);
  return _react.default.createElement("div", {
    className: "modal-overlay nf-search-overlay",
    onClick: e => e.target === e.currentTarget && onClose()
  }, _react.default.createElement("div", {
    className: "nf-search-shell"
  }, _react.default.createElement("div", {
    className: "nf-search-left"
  }, _react.default.createElement(KeyboardPanel, {
    firstKeyRef: firstKeyRef,
    langMode: langMode,
    onToggleLang: toggleLang,
    onAppend: appendChar,
    onBackspace: handleBackspace,
    onClear: handleClear
  }), _react.default.createElement("div", {
    className: "nf-trending-panel"
  }, _react.default.createElement("div", {
    className: "nf-trending-heading"
  }, "Trending Now"), _react.default.createElement("div", {
    className: "nf-trending-list"
  }, combinedTrending.slice(0, 8).map(item => _react.default.createElement("button", {
    key: `trend_${item.media_type}_${item.id}`,
    className: "nf-trending-chip",
    onClick: () => handleSelect(item)
  }, _react.default.createElement("span", {
    className: "nf-trending-name"
  }, item.title || item.name)))))), _react.default.createElement("div", {
    className: "nf-search-right"
  }, _react.default.createElement("div", {
    className: "nf-search-bar"
  }, _react.default.createElement(_Icons.SearchIcon, null), _react.default.createElement("div", {
    className: "nf-search-query-display",
    dir: /[\u0600-\u06FF]/.test(query) ? "rtl" : "ltr"
  }, query ? _react.default.createElement("span", {
    className: "nf-search-query-text"
  }, query) : _react.default.createElement("span", {
    className: "nf-search-placeholder"
  }, "Search movies, actors, shows...")), _react.default.createElement("button", {
    className: "nf-player-btn nf-search-close-btn",
    "data-gamepad-close": "1",
    onClick: onClose,
    "aria-label": "Close"
  }, _react.default.createElement(_Icons.CloseIcon, null))), _react.default.createElement("div", {
    className: "nf-search-section-label"
  }, isSearching ? `Results for "${query}"` : "Top Searches"), offline && _react.default.createElement("div", {
    className: "nf-search-empty"
  }, "No internet connection. Search is unavailable offline."), !offline && loading && _react.default.createElement("div", {
    className: "loader"
  }, _react.default.createElement("div", {
    className: "spinner"
  })), !offline && !loading && isSearching && results.length === 0 && _react.default.createElement("div", {
    className: "nf-search-empty"
  }, "No results found for \"", query, "\""), !offline && !loading && _react.default.createElement("div", {
    className: "nf-results-grid"
  }, displayItems.map(r => _react.default.createElement(SearchResultCard, {
    key: `${r.media_type}_${r.id}`,
    item: r,
    onSelect: handleSelect
  }))))));
}
},
"./components/Sidebar": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = Sidebar;
var _react = require("react");
var _api = require("../utils/api");
var _seasonalEvents = require("../components/seasonalEvents.jsx");
var _Icons = require("./Icons");
function Sidebar({
  page,
  onNavigate,
  onSearch,
  savedList,
  activeDownloads,
  onReorderSaved,
  onRemoveSaved,
  canGoBack,
  onBack,
  onShowShortcuts
}) {
  const [dragOver, setDragOver] = (0, _react.useState)(null);
  const dragItem = (0, _react.useRef)(null);
  const dragNode = (0, _react.useRef)(null);
  const seasonalEvent = (0, _seasonalEvents.useSeasonalEvent)();
  const [tooltip, setTooltip] = (0, _react.useState)(null);
  const [contextMenu, setContextMenu] = (0, _react.useState)(null);
  (0, _react.useEffect)(() => {
    const close = () => setContextMenu(null);
    window.addEventListener("click", close);
    window.addEventListener("contextmenu", close);
    return () => {
      window.removeEventListener("click", close);
      window.removeEventListener("contextmenu", close);
    };
  }, []);
  const handleContextMenu = (e, item) => {
    e.preventDefault();
    e.stopPropagation();
    setTooltip(null);
    setContextMenu({
      item,
      x: e.clientX,
      y: e.clientY
    });
  };
  const handleDragStart = (e, index) => {
    dragItem.current = index;
    dragNode.current = e.currentTarget;
    setTimeout(() => {
      if (dragNode.current) dragNode.current.style.opacity = "0.4";
    }, 0);
    e.dataTransfer.effectAllowed = "move";
  };
  const handleDragEnd = () => {
    if (dragNode.current) dragNode.current.style.opacity = "1";
    dragItem.current = null;
    dragNode.current = null;
    setDragOver(null);
  };
  const handleDragEnter = (e, index) => {
    if (dragItem.current === index) return;
    setDragOver(index);
  };
  const handleDrop = (e, dropIndex) => {
    e.preventDefault();
    const fromIndex = dragItem.current;
    if (fromIndex === null || fromIndex === dropIndex) return;
    const newList = [...savedList];
    const [moved] = newList.splice(fromIndex, 1);
    newList.splice(dropIndex, 0, moved);
    const newOrder = newList.map(item => `${item.media_type}_${item.id}`);
    onReorderSaved(newOrder);
    setDragOver(null);
  };
  const handleDragOver = e => {
    e.preventDefault();
    e.dataTransfer.dropEffect = "move";
  };
  const handleMouseEnter = (e, title) => {
    const rect = e.currentTarget.getBoundingClientRect();
    setTooltip({
      title,
      y: rect.top + rect.height / 2
    });
  };
  const handleMouseLeave = () => {
    setTooltip(null);
  };
  return React.createElement("div", {
    className: "sidebar"
  }, React.createElement("div", {
    className: "sidebar-logo",
    onClick: () => onNavigate("home"),
    title: "SingularityTV",
    style: {
      position: "relative"
    }
  }, React.createElement(_Icons.SingularityTVLogo, null), seasonalEvent && seasonalEvent.render()), canGoBack && React.createElement(SideBtn, {
    onClick: onBack,
    icon: React.createElement(_Icons.BackIcon, null),
    label: "Back (Ctrl+Z)"
  }), React.createElement(SideBtn, {
    onClick: onSearch,
    icon: React.createElement(_Icons.SearchIcon, null),
    label: "Search  (\u2318F)"
  }), React.createElement(SideBtn, {
    active: page === "home",
    onClick: () => onNavigate("home"),
    icon: React.createElement(_Icons.HomeIcon, null),
    label: "Home"
  }), React.createElement(SideBtn, {
    active: page === "history",
    onClick: () => onNavigate("history"),
    icon: React.createElement(_Icons.HistoryIcon, null),
    label: "Library & History"
  }), React.createElement(SideBtn, {
    active: page === "downloads",
    onClick: () => onNavigate("downloads"),
    icon: React.createElement(_Icons.DownloadsQueueIcon, null),
    label: "Downloads",
    badge: activeDownloads > 0 ? activeDownloads : null
  }), React.createElement("div", {
    className: "sidebar-sep"
  }), React.createElement("div", {
    className: "sidebar-saved"
  }, savedList.map((item, index) => {
    const key = `${item.media_type}_${item.id}`;
    const title = item.title || item.name;
    return React.createElement("div", {
      key: key,
      className: `saved-thumb${dragOver === index ? " drag-over" : ""}`,
      draggable: true,
      onDragStart: e => handleDragStart(e, index),
      onDragEnd: handleDragEnd,
      onDragEnter: e => handleDragEnter(e, index),
      onDragOver: handleDragOver,
      onDrop: e => handleDrop(e, index),
      onClick: () => onNavigate(item.media_type === "tv" ? "tv" : "movie", item),
      onContextMenu: e => handleContextMenu(e, item),
      onMouseEnter: e => handleMouseEnter(e, title),
      onMouseLeave: handleMouseLeave,
      style: {
        cursor: "grab",
        position: "relative"
      }
    }, item.poster_path ? React.createElement("img", {
      src: (0, _api.imgUrl)(item.poster_path, "w200"),
      alt: title
    }) : React.createElement("div", {
      className: "no-img"
    }, React.createElement(_Icons.FilmIcon, null)), dragOver === index && React.createElement("div", {
      style: {
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        height: 3,
        background: "var(--accent, #e50914)",
        borderRadius: 2,
        pointerEvents: "none"
      }
    }));
  })), tooltip && React.createElement("div", {
    className: "saved-thumb-tooltip",
    style: {
      top: tooltip.y
    }
  }, tooltip.title), contextMenu && React.createElement("div", {
    className: "sidebar-context-menu",
    style: {
      position: "fixed",
      top: contextMenu.y,
      left: contextMenu.x,
      zIndex: 9999
    },
    onClick: e => e.stopPropagation()
  }, React.createElement("div", {
    className: "sidebar-context-menu-item",
    onClick: () => {
      onRemoveSaved && onRemoveSaved(contextMenu.item);
      setContextMenu(null);
    }
  }, "Remove")), React.createElement("div", {
    className: "sidebar-bottom"
  }, React.createElement(SideBtn, {
    onClick: onShowShortcuts,
    icon: React.createElement(_Icons.HelpIcon, null),
    label: "Help & Shortcuts (?)"
  }), React.createElement(SideBtn, {
    active: page === "settings",
    onClick: () => onNavigate("settings"),
    icon: React.createElement(_Icons.SettingsIcon, null),
    label: "Settings"
  }), React.createElement("button", {
    className: "sidebar-btn",
    onClick: () => window.electron?.quitApp?.(),
    title: "Quit App",
    style: {
      color: "#e53e3e",
      marginTop: 4
    }
  }, React.createElement(_Icons.QuitIcon, null), React.createElement("span", {
    className: "tooltip"
  }, "Quit App"))));
}
function SideBtn({
  active,
  onClick,
  icon,
  label,
  badge
}) {
  return React.createElement("button", {
    className: `sidebar-btn ${active ? "active" : ""}`,
    onClick: onClick,
    style: {
      position: "relative"
    }
  }, icon, React.createElement("span", {
    className: "tooltip"
  }, label), badge && React.createElement("span", {
    style: {
      position: "absolute",
      top: 4,
      right: 4,
      minWidth: 16,
      height: 16,
      borderRadius: 8,
      background: "var(--red)",
      color: "white",
      fontSize: 10,
      fontWeight: 700,
      lineHeight: "16px",
      textAlign: "center",
      padding: "0 4px"
    }
  }, badge));
}
},
"./components/StreamPlayerFrame": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;
var _react = require("react");
const StreamPlayerFrame = (0, _react.forwardRef)(function StreamPlayerFrame({
  src,
  style,
  tabIndex
}, ref) {
  const iframeRef = (0, _react.useRef)(null);
  const listenersRef = (0, _react.useRef)(new Map());
  (0, _react.useImperativeHandle)(ref, () => ({
    get src() {
      return iframeRef.current?.src || "";
    },
    set src(val) {
      if (iframeRef.current) iframeRef.current.src = val;
    },
    getWebContentsId() {
      return 1;
    },
    async executeJavaScript(code) {
      try {
        const win = iframeRef.current?.contentWindow;
        if (win) {
          return win.eval(code);
        }
      } catch {
        if (window.AndroidBridge?.evaluateInPlayerFrame) {
          try {
            const res = window.AndroidBridge.evaluateInPlayerFrame(code);
            return res ? JSON.parse(res) : null;
          } catch {}
        }
      }
      return null;
    },
    addEventListener(type, handler) {
      if (!listenersRef.current.has(type)) {
        listenersRef.current.set(type, new Set());
      }
      listenersRef.current.get(type).add(handler);
      const el = iframeRef.current;
      if (!el) return;
      if (type === "did-finish-load" || type === "dom-ready") {
        el.addEventListener("load", handler);
      } else if (type === "did-fail-load") {
        el.addEventListener("error", handler);
      }
    },
    removeEventListener(type, handler) {
      listenersRef.current.get(type)?.delete(handler);
      const el = iframeRef.current;
      if (!el) return;
      if (type === "did-finish-load" || type === "dom-ready") {
        el.removeEventListener("load", handler);
      } else if (type === "did-fail-load") {
        el.removeEventListener("error", handler);
      }
    }
  }));
  (0, _react.useEffect)(() => {
    const el = iframeRef.current;
    if (!el || !src || src === "about:blank") return;
    const t = setTimeout(() => {
      const loadSet = listenersRef.current.get("did-finish-load");
      if (loadSet) {
        for (const fn of loadSet) {
          try {
            fn();
          } catch {}
        }
      }
    }, 900);
    return () => clearTimeout(t);
  }, [src]);
  return React.createElement("iframe", {
    ref: iframeRef,
    src: src || "about:blank",
    allow: "autoplay; fullscreen; encrypted-media; picture-in-picture",
    allowFullScreen: true,
    referrerPolicy: "origin",
    tabIndex: tabIndex,
    style: {
      position: "absolute",
      inset: 0,
      width: "100%",
      height: "100%",
      border: "none",
      background: "#000",
      ...style
    }
  });
});
var _default = StreamPlayerFrame;
exports.default = _default;
},
"./components/SubtitleDownloaderModal": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = SubtitleDownloaderModal;
var _react = require("react");
var _Icons = require("./Icons");
var _storage = require("../utils/storage");
var _subtitles = require("../utils/subtitles");
function SubtitleDownloaderModal({
  dl,
  onClose,
  onSubtitlesSaved,
  onSubtitleDeleted,
  onOpenSettings
}) {
  const defaultLang = _storage.storage.get(_storage.STORAGE_KEYS.SUBTITLE_LANG) || "en";
  const [subdlApiKey, setSubdlApiKey] = (0, _react.useState)(null);
  const [wyzieApiKey, setWyzieApiKey] = (0, _react.useState)(null);
  (0, _react.useEffect)(() => {
    let mounted = true;
    Promise.all([_storage.secureStorage.get(_storage.STORAGE_KEYS.SUBDL_API_KEY), _storage.secureStorage.get(_storage.STORAGE_KEYS.WYZIE_API_KEY)]).then(([subdl, wyzie]) => {
      if (!mounted) return;
      setSubdlApiKey(subdl || "");
      setWyzieApiKey(wyzie || "");
    });
    return () => {
      mounted = false;
    };
  }, []);
  const [langFilter, setLangFilter] = (0, _react.useState)(defaultLang);
  const [results, setResults] = (0, _react.useState)(null);
  const [searching, setSearching] = (0, _react.useState)(false);
  const [searchError, setSearchError] = (0, _react.useState)(null);
  const [selectedSubs, setSelectedSubs] = (0, _react.useState)([]);
  const [downloading, setDownloading] = (0, _react.useState)(false);
  const [dlError, setDlError] = (0, _react.useState)(null);
  const [done, setDone] = (0, _react.useState)(false);
  const doneTimerRef = (0, _react.useRef)(null);
  (0, _react.useEffect)(() => () => {
    if (doneTimerRef.current) clearTimeout(doneTimerRef.current);
  }, []);
  const [deletingPath, setDeletingPath] = (0, _react.useState)(null);
  const existingSubs = dl.subtitlePaths || [];
  const existingFileIds = new Set(existingSubs.map(s => s.file_id).filter(Boolean));
  const existingLangs = new Set(existingSubs.map(s => s.lang));
  const doSearch = (0, _react.useCallback)(async lang => {
    if (!dl.tmdbId) return;
    setSearching(true);
    setSearchError(null);
    setResults(null);
    try {
      const res = await window.electron.searchSubtitles({
        tmdbId: dl.tmdbId,
        mediaType: dl.mediaType,
        season: dl.season,
        episode: dl.episode,
        languages: lang || "",
        subdlApiKey,
        wyzieApiKey
      });
      if (!res.ok) {
        setSearchError(res.error || "Search failed");
        setResults([]);
      } else setResults(res.results || []);
    } catch (e) {
      setSearchError(e.message);
      setResults([]);
    } finally {
      setSearching(false);
    }
  }, [dl, subdlApiKey, wyzieApiKey]);
  (0, _react.useEffect)(() => {
    if (subdlApiKey === null || wyzieApiKey === null) return;
    if (!subdlApiKey && !wyzieApiKey) return;
    doSearch(langFilter);
  }, [subdlApiKey, wyzieApiKey]);
  const handleDownload = async () => {
    if (!selectedSubs.length || !dl.filePath) return;
    setDownloading(true);
    setDlError(null);
    try {
      const res = await window.electron.downloadSubtitlesForFile({
        filePath: dl.filePath,
        selectedSubs
      });
      if (res.ok && res.subtitlePaths?.length > 0) {
        setDone(true);
        onSubtitlesSaved(res.subtitlePaths);
        doneTimerRef.current = setTimeout(() => {
          setDone(false);
          setSelectedSubs([]);
        }, 1500);
      } else {
        setDlError(res.error || "No subtitles could be saved.");
      }
    } catch (e) {
      setDlError(e.message);
    } finally {
      setDownloading(false);
    }
  };
  const handleDeleteSub = async sp => {
    if (!confirm(`Delete subtitle "${(sp.lang || "?").toUpperCase()}"${sp.release ? ` (${sp.release})` : ""}?`)) return;
    setDeletingPath(sp.path);
    try {
      await window.electron.deleteSubtitleFile({
        downloadId: dl.id,
        subtitlePath: sp.path
      });
      onSubtitleDeleted(sp.path);
    } catch (e) {
      console.error("Delete subtitle error:", e);
    } finally {
      setDeletingPath(null);
    }
  };
  return React.createElement(React.Fragment, null, React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      zIndex: 999999,
      background: "rgba(0,0,0,0.78)",
      backdropFilter: "blur(6px)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    },
    onClick: onClose
  }, React.createElement("div", {
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border)",
      borderRadius: 12,
      width: 620,
      maxWidth: "95vw",
      maxHeight: "85vh",
      display: "flex",
      flexDirection: "column",
      boxShadow: "0 24px 64px rgba(0,0,0,0.6)"
    },
    onClick: e => e.stopPropagation()
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "15px 20px",
      borderBottom: "1px solid var(--border)",
      flexShrink: 0
    }
  }, React.createElement("span", {
    style: {
      fontWeight: 600,
      fontSize: 14,
      display: "flex",
      alignItems: "center",
      gap: 7
    }
  }, React.createElement(_Icons.SubtitlesIcon, {
    size: 14
  }), "Subtitles: ", dl.name), React.createElement("button", {
    className: "icon-btn",
    onClick: onClose
  }, "\u2715")), existingSubs.length > 0 && React.createElement("div", {
    style: {
      padding: "10px 20px 12px",
      borderBottom: "1px solid var(--border)",
      flexShrink: 0,
      background: "rgba(99,202,183,0.04)"
    }
  }, React.createElement("div", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      color: "var(--text3)",
      letterSpacing: "0.06em",
      textTransform: "uppercase",
      marginBottom: 8
    }
  }, "Downloaded subtitles"), React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 5
    }
  }, existingSubs.map(sp => React.createElement("div", {
    key: sp.path,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      background: "rgba(255,255,255,0.03)",
      border: "1px solid var(--border)",
      borderRadius: 7,
      padding: "6px 10px"
    }
  }, React.createElement("span", {
    style: {
      fontSize: 10,
      fontWeight: 700,
      padding: "1px 6px",
      borderRadius: 3,
      background: "rgba(99,202,183,0.15)",
      color: "#63cab7",
      border: "1px solid rgba(99,202,183,0.3)",
      textTransform: "uppercase",
      flexShrink: 0
    }
  }, (sp.lang || "?").toUpperCase()), sp.source && React.createElement("span", {
    style: {
      fontSize: 9,
      fontWeight: 700,
      padding: "1px 5px",
      borderRadius: 3,
      background: sp.source === "subdl" ? "rgba(229,9,20,0.15)" : "rgba(180,130,255,0.15)",
      color: sp.source === "subdl" ? "#ff4d57" : "#b482ff",
      border: `1px solid ${sp.source === "subdl" ? "rgba(229,9,20,0.35)" : "rgba(180,130,255,0.3)"}`,
      textTransform: "uppercase",
      flexShrink: 0
    }
  }, sp.source === "subdl" ? "SubDL" : "Wyzie"), React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text2)",
      flex: 1,
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap",
      minWidth: 0
    },
    title: sp.release || sp.path
  }, sp.release || sp.path.split(/[\\/]/).pop()), React.createElement("span", {
    style: {
      fontSize: 10,
      color: "var(--text3)",
      flexShrink: 0
    },
    title: sp.path
  }, ".", sp.path.split(".").pop()), React.createElement("button", {
    className: "icon-btn",
    disabled: deletingPath === sp.path,
    onClick: () => handleDeleteSub(sp),
    title: "Delete this subtitle file",
    style: {
      flexShrink: 0,
      opacity: deletingPath === sp.path ? 0.4 : 1,
      fontSize: 13
    }
  }, deletingPath === sp.path ? "…" : React.createElement(_Icons.TrashIcon, null)))))), React.createElement("div", {
    style: {
      padding: "10px 16px",
      borderBottom: "1px solid var(--border)",
      display: "flex",
      gap: 8,
      alignItems: "center",
      flexShrink: 0
    }
  }, React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, "Download more:"), React.createElement("select", {
    value: langFilter,
    onChange: e => {
      setLangFilter(e.target.value);
      doSearch(e.target.value);
    },
    style: {
      background: "var(--surface2)",
      border: "1px solid var(--border)",
      borderRadius: 6,
      color: "var(--text)",
      padding: "5px 10px",
      fontSize: 12,
      cursor: "pointer"
    }
  }, React.createElement("option", {
    value: ""
  }, "All languages"), _subtitles.SUBTITLE_LANGUAGES.map(l => React.createElement("option", {
    key: l.code,
    value: l.code
  }, l.label))), React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "4px 10px",
      fontSize: 11
    },
    onClick: () => doSearch(langFilter),
    disabled: searching
  }, searching ? "…" : "⟳ Refresh"), selectedSubs.length > 0 && React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginLeft: "auto"
    }
  }, selectedSubs.length, " selected")), React.createElement("div", {
    style: {
      flex: 1,
      overflowY: "auto"
    }
  }, !wyzieApiKey && !subdlApiKey && wyzieApiKey !== null && React.createElement("div", {
    style: {
      margin: "16px 20px",
      padding: "12px 14px",
      background: "var(--surface2)",
      border: "1px solid var(--border)",
      borderRadius: 8,
      fontSize: 13,
      display: "flex",
      flexDirection: "column",
      gap: 8
    }
  }, React.createElement("span", null, React.createElement("span", {
    style: {
      color: "var(--red)",
      fontWeight: 600
    }
  }, "No subtitle API key set."), " ", "Add/Generate a Wyzie or SubDL key in Settings to search and download subtitles."), onOpenSettings && React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      alignSelf: "flex-start",
      padding: "2px 8px",
      fontSize: 11
    },
    onClick: () => {
      onClose();
      onOpenSettings("subtitles");
    }
  }, React.createElement(_Icons.SettingsIcon, null), " Open Settings \u2192 Subtitles")), searching && React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      padding: 24,
      color: "var(--text3)",
      fontSize: 13,
      justifyContent: "center"
    }
  }, React.createElement("div", {
    className: "spinner",
    style: {
      width: 16,
      height: 16,
      borderWidth: 2
    }
  }), " ", "Searching\u2026"), searchError && !searching && React.createElement("div", {
    style: {
      padding: "16px 20px",
      color: "var(--red)",
      fontSize: 13
    }
  }, "\u26A0 ", searchError), !searching && results?.length === 0 && React.createElement("div", {
    style: {
      padding: 20,
      color: "var(--text3)",
      fontSize: 13,
      textAlign: "center"
    }
  }, "No subtitles found for this language"), !searching && results?.map(r => {
    const isSelected = selectedSubs.some(s => s.file_id === r.file_id);
    const rLang = (r.language || "").replace(/[^a-z0-9_-]/gi, "").toLowerCase();
    const alreadyHave = r.file_id ? existingFileIds.has(r.file_id) : existingLangs.has(rLang);
    return React.createElement("div", {
      key: r.file_id,
      onClick: () => {
        if (alreadyHave) return;
        setSelectedSubs(prev => isSelected ? prev.filter(s => s.file_id !== r.file_id) : [...prev, r]);
      },
      style: {
        padding: "8px 16px",
        cursor: alreadyHave ? "default" : "pointer",
        borderBottom: "1px solid var(--border)",
        background: alreadyHave ? "rgba(255,255,255,0.01)" : isSelected ? "rgba(229,9,20,0.07)" : "transparent",
        display: "flex",
        alignItems: "flex-start",
        gap: 10,
        transition: "background 0.1s",
        opacity: alreadyHave ? 0.45 : 1
      },
      onMouseEnter: e => {
        if (!isSelected && !alreadyHave) e.currentTarget.style.background = "var(--surface2)";
      },
      onMouseLeave: e => {
        e.currentTarget.style.background = alreadyHave ? "rgba(255,255,255,0.01)" : isSelected ? "rgba(229,9,20,0.07)" : "transparent";
      }
    }, React.createElement("div", {
      style: {
        width: 15,
        height: 15,
        borderRadius: 3,
        border: `2px solid ${alreadyHave ? "var(--border)" : isSelected ? "var(--red)" : "var(--border)"}`,
        background: alreadyHave ? "var(--surface2)" : isSelected ? "var(--red)" : "transparent",
        flexShrink: 0,
        marginTop: 3,
        display: "flex",
        alignItems: "center",
        justifyContent: "center"
      }
    }, alreadyHave ? React.createElement("span", {
      style: {
        color: "var(--text3)",
        fontSize: 9
      }
    }, "\u2713") : isSelected ? React.createElement("span", {
      style: {
        color: "#fff",
        fontSize: 9
      }
    }, "\u2713") : null), React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 5,
        marginBottom: 2,
        flexWrap: "wrap"
      }
    }, React.createElement("span", {
      style: {
        fontSize: 10,
        fontWeight: 700,
        padding: "1px 5px",
        borderRadius: 3,
        background: "rgba(99,202,183,0.15)",
        color: "#63cab7",
        border: "1px solid rgba(99,202,183,0.3)",
        textTransform: "uppercase"
      }
    }, r.language), React.createElement("span", {
      style: {
        fontSize: 9,
        fontWeight: 700,
        padding: "1px 5px",
        borderRadius: 3,
        background: r.via_subdl ? "rgba(229,9,20,0.15)" : "rgba(180,130,255,0.15)",
        color: r.via_subdl ? "#ff4d57" : "#b482ff",
        border: `1px solid ${r.via_subdl ? "rgba(229,9,20,0.35)" : "rgba(180,130,255,0.3)"}`,
        textTransform: "uppercase"
      }
    }, r.via_subdl ? "SubDL" : "Wyzie"), alreadyHave && React.createElement("span", {
      style: {
        fontSize: 10,
        color: "var(--text3)",
        fontStyle: "italic"
      }
    }, "already downloaded"), r.hearing_impaired && React.createElement("span", {
      style: {
        fontSize: 10,
        color: "var(--text3)"
      },
      title: "HI"
    }, "\u267F"), r.ai_translated && React.createElement("span", {
      style: {
        fontSize: 10,
        color: "var(--text3)"
      },
      title: "AI"
    }, "\uD83E\uDD16")), React.createElement("div", {
      style: {
        fontSize: 12,
        color: "var(--text)",
        overflow: "hidden",
        textOverflow: "ellipsis",
        whiteSpace: "nowrap"
      }
    }, r.release || r.file_name || `${r.language?.toUpperCase()} subtitle`), React.createElement("div", {
      style: {
        fontSize: 11,
        color: "var(--text3)"
      }
    }, r.uploader, " \xB7", " ", (r.download_count || 0).toLocaleString(), " downloads")));
  })), React.createElement("div", {
    style: {
      padding: "12px 20px",
      borderTop: "1px solid var(--border)",
      display: "flex",
      alignItems: "center",
      gap: 12,
      flexShrink: 0
    }
  }, done ? React.createElement("span", {
    style: {
      fontSize: 13,
      color: "#48c774",
      fontWeight: 600
    }
  }, "\u2713 Subtitles downloaded!") : React.createElement(React.Fragment, null, React.createElement("button", {
    className: "btn btn-primary",
    disabled: downloading || selectedSubs.length === 0 || !dl.filePath,
    onClick: handleDownload,
    style: {
      opacity: downloading || selectedSubs.length === 0 ? 0.5 : 1
    }
  }, downloading ? "Downloading…" : selectedSubs.length > 0 ? `↓ Download (${selectedSubs.length})` : "Select subtitles above"), !dl.filePath && React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--red)"
    }
  }, "No file path, needs completed download"), dlError && React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--red)"
    }
  }, "\u26A0 ", dlError)), React.createElement("div", {
    style: {
      flex: 1
    }
  }), React.createElement("button", {
    className: "btn btn-ghost",
    onClick: onClose
  }, "Close")))));
}
},
"./components/TopNav": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = TopNav;
var _react = _interopRequireWildcard(require("react"));
var _Icons = require("./Icons");
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function (nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function TopNav({
  page,
  onNavigate,
  onSearch,
  activeDownloads
}) {
  const [timeStr, setTimeStr] = (0, _react.useState)(() => new Date().toLocaleTimeString([], {
    hour: "numeric",
    minute: "2-digit"
  }));
  (0, _react.useEffect)(() => {
    const timer = setInterval(() => {
      setTimeStr(new Date().toLocaleTimeString([], {
        hour: "numeric",
        minute: "2-digit"
      }));
    }, 30000);
    return () => clearInterval(timer);
  }, []);
  const navItems = [{
    id: "home",
    label: "Home",
    icon: _react.default.createElement(_Icons.HomeIcon, null)
  }, {
    id: "history",
    label: "Library",
    icon: _react.default.createElement(_Icons.HistoryIcon, null)
  }, {
    id: "downloads",
    label: "Downloads",
    icon: _react.default.createElement(_Icons.DownloadsQueueIcon, null),
    badge: activeDownloads > 0 ? activeDownloads : null
  }];
  return _react.default.createElement("header", {
    className: "topnav"
  }, _react.default.createElement("div", {
    className: "topnav-left"
  }, _react.default.createElement("button", {
    className: "topnav-brand topnav-btn",
    onClick: () => onNavigate("home"),
    "aria-label": "SingularityTV Home"
  }, _react.default.createElement(_Icons.SingularityTVLogo, {
    style: {
      width: 26,
      height: 26
    }
  })), _react.default.createElement("button", {
    className: "topnav-search-btn topnav-btn",
    onClick: onSearch
  }, _react.default.createElement(_Icons.SearchIcon, null), _react.default.createElement("span", null, "Search")), _react.default.createElement("nav", {
    className: "topnav-links",
    "aria-label": "Primary Navigation"
  }, navItems.map(item => _react.default.createElement("button", {
    key: item.id,
    className: `topnav-link topnav-btn${page === item.id ? " active" : ""}`,
    onClick: () => onNavigate(item.id)
  }, _react.default.createElement("span", {
    className: "topnav-link-icon"
  }, item.icon), _react.default.createElement("span", null, item.label), item.badge && _react.default.createElement("span", {
    className: "topnav-badge"
  }, item.badge))))), _react.default.createElement("div", {
    className: "topnav-right"
  }, _react.default.createElement("button", {
    className: `topnav-icon-btn topnav-btn${page === "settings" ? " active" : ""}`,
    onClick: () => onNavigate("settings"),
    "aria-label": "Settings"
  }, _react.default.createElement(_Icons.SettingsIcon, null)), _react.default.createElement("div", {
    className: "topnav-clock"
  }, timeStr)));
}
},
"./components/TrailerModal": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.DEFAULT_INVIDIOUS_BASE = void 0;
exports.default = TrailerModal;
exports.getInvidiousBase = getInvidiousBase;
var _react = require("react");
var _Icons = require("./Icons");
var _storage = require("../utils/storage");
var _StreamPlayerFrame = _interopRequireDefault(require("./StreamPlayerFrame"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
const DEFAULT_INVIDIOUS_BASE = "https://inv.nadeko.net";
exports.DEFAULT_INVIDIOUS_BASE = DEFAULT_INVIDIOUS_BASE;
const FALLBACK_INSTANCES = ["https://invidious.privacyredirect.com", "https://inv.tux.pizza", "https://yt.cdaut.de", "https://invidious.lunar.icu", "https://invidious.protokolla.fi", "https://invidious.nerdvpn.de", "https://iv.melmac.space", "https://invidious.perennialte.ch"];
function getInvidiousBase() {
  return (_storage.storage.get("invidiousBase") || DEFAULT_INVIDIOUS_BASE).replace(/\/$/, "");
}
function TrailerModal({
  trailerKey,
  title,
  onClose
}) {
  const webviewRef = (0, _react.useRef)(null);
  const [currentSrc, setCurrentSrc] = (0, _react.useState)(null);
  const [statusMsg, setStatusMsg] = (0, _react.useState)("Loading trailer…");
  const [failed, setFailed] = (0, _react.useState)(false);
  const instanceIndexRef = (0, _react.useRef)(-1);
  const tryNextInstance = (0, _react.useCallback)(() => {
    const preferred = getInvidiousBase();
    const list = [preferred, ...FALLBACK_INSTANCES.filter(i => i !== preferred)];
    instanceIndexRef.current += 1;
    const idx = instanceIndexRef.current;
    if (idx >= list.length) {
      setFailed(true);
      setStatusMsg("All Invidious instances failed. Try setting a custom instance in Settings.");
      return;
    }
    const instance = list[idx];
    const label = instance.replace(/^https?:\/\//, "");
    setStatusMsg(idx === 0 ? "Loading trailer…" : `Trying ${label}…`);
    setCurrentSrc(`${instance}/embed/${trailerKey}?autoplay=1&listen=0`);
  }, [trailerKey]);
  (0, _react.useEffect)(() => {
    instanceIndexRef.current = -1;
    tryNextInstance();
  }, [tryNextInstance]);
  (0, _react.useEffect)(() => {
    const handler = e => {
      if (e.key === "Escape" || e.keyCode === 4) onClose();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [onClose]);
  const openInBrowser = () => {
    const preferred = getInvidiousBase();
    const url = `${preferred}/watch?v=${trailerKey}`;
    window.electron?.openExternal(url);
  };
  (0, _react.useEffect)(() => {
    const wv = webviewRef.current;
    if (!wv || !currentSrc) return;
    const onLoad = () => {
      setStatusMsg(null);
    };
    const onFailLoad = () => {
      tryNextInstance();
    };
    wv.addEventListener("did-finish-load", onLoad);
    wv.addEventListener("did-fail-load", onFailLoad);
    return () => {
      wv.removeEventListener("did-finish-load", onLoad);
      wv.removeEventListener("did-fail-load", onFailLoad);
    };
  }, [currentSrc, tryNextInstance]);
  return React.createElement("div", {
    className: "trailer-overlay",
    onClick: onClose
  }, React.createElement("div", {
    className: "trailer-modal",
    onClick: e => e.stopPropagation()
  }, React.createElement("div", {
    className: "trailer-modal-header"
  }, React.createElement("span", {
    className: "trailer-modal-title"
  }, "\uD83C\uDFAC ", title, " \u2014 Official Trailer"), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, React.createElement("button", {
    onClick: openInBrowser,
    title: "Open in browser",
    className: "trailer-openbrowser-btn"
  }, React.createElement(_Icons.ExternalLinkIcon, {
    size: 13
  }), "Open in Browser"), React.createElement("button", {
    className: "trailer-close-btn",
    onClick: onClose,
    title: "Close",
    "data-gamepad-close": "true"
  }, React.createElement(_Icons.CloseIcon, null)))), React.createElement("div", {
    className: "trailer-embed-wrap",
    style: {
      background: "#000",
      position: "relative"
    }
  }, (statusMsg || failed) && React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 2,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      background: "#000",
      color: failed ? "#ff3860" : "rgba(255,255,255,0.6)",
      fontSize: 14,
      textAlign: "center",
      padding: "0 32px",
      gap: 10
    }
  }, failed ? React.createElement(React.Fragment, null, React.createElement("span", {
    style: {
      fontSize: 28
    }
  }, "\u26A0"), React.createElement("span", null, statusMsg)) : React.createElement(React.Fragment, null, React.createElement("span", {
    style: {
      opacity: 0.5
    }
  }, "\u23F3"), React.createElement("span", null, statusMsg))), currentSrc && React.createElement(_StreamPlayerFrame.default, {
    ref: webviewRef,
    src: currentSrc,
    style: {
      opacity: statusMsg ? 0 : 1,
      transition: "opacity 0.2s"
    }
  }))));
}
},
"./components/TrendingCarousel": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = TrendingCarousel;
var _react = require("react");
var _api = require("../utils/api");
var _Icons = require("./Icons");
const VISIBLE = 5;
const HALF = Math.floor(VISIBLE / 2);
function visibilityRatio(el, scrollRoot) {
  const r = el.getBoundingClientRect();
  const rootTop = scrollRoot ? scrollRoot.getBoundingClientRect().top : 0;
  const rootHeight = scrollRoot ? scrollRoot.getBoundingClientRect().height : window.innerHeight;
  const visTop = Math.max(r.top, rootTop);
  const visBottom = Math.min(r.bottom, rootTop + rootHeight);
  const px = Math.max(0, visBottom - visTop);
  return r.height > 0 ? px / r.height : 0;
}
const RatingBadge = (0, _react.memo)(function RatingBadge({
  cert,
  restricted
}) {
  if (!cert) return null;
  return React.createElement("span", {
    className: `carousel-rating-badge${restricted ? " carousel-rating-badge--restricted" : ""}`,
    title: restricted ? "Age-restricted" : `Rated ${cert}`
  }, cert);
});
const CarouselSlot = (0, _react.memo)(function CarouselSlot({
  item,
  offset,
  onSelect,
  onFocus,
  animating,
  ageRating,
  restricted,
  isAnime
}) {
  if (!item) return null;
  const isCenter = offset === 0;
  const abs = Math.abs(offset);
  const title = item.title || item.name;
  const year = (item.release_date || item.first_air_date || "").slice(0, 4);
  const poster = (0, _api.imgUrl)(item.poster_path, "w342");
  const scale = isCenter ? 1 : abs === 1 ? 0.75 : 0.54;
  const opacity = isCenter ? 1 : abs === 1 ? 0.65 : 0.35;
  const tx = offset * 230;
  const rawDate = item.release_date || item.first_air_date;
  const isUnreleased = (0, _react.useMemo)(() => {
    if (!rawDate) return false;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return new Date(rawDate) > today;
  }, [rawDate]);
  const releaseLabel = (0, _react.useMemo)(() => rawDate ? new Date(rawDate).toLocaleDateString(undefined, {
    month: "short",
    day: "numeric",
    year: "numeric"
  }) : null, [rawDate]);
  return React.createElement("div", {
    className: `carousel-item${isCenter ? " carousel-item--active" : ""}${animating ? " carousel-item--animating" : ""}`,
    style: {
      transform: `translateX(${tx}px) scale(${scale})`,
      opacity,
      zIndex: isCenter ? 10 : abs === 1 ? 6 : 2,
      cursor: "pointer",
      pointerEvents: "auto"
    },
    onClick: isCenter ? onSelect : onFocus
  }, React.createElement("div", {
    className: "carousel-poster-wrap"
  }, poster ? React.createElement("img", {
    src: poster,
    alt: title,
    className: "carousel-poster",
    draggable: false,
    loading: abs > 1 ? "lazy" : "eager"
  }) : React.createElement("div", {
    className: "carousel-poster carousel-poster--placeholder"
  }, React.createElement("span", null, title)), isUnreleased && React.createElement("div", {
    className: "carousel-unreleased-overlay"
  }, React.createElement("span", {
    className: "carousel-unreleased-label"
  }, "\uD83D\uDD12 Coming Soon"), releaseLabel && React.createElement("span", {
    className: "carousel-unreleased-date"
  }, releaseLabel)), isCenter && item.vote_average > 0 && React.createElement("div", {
    className: "carousel-score"
  }, React.createElement(_Icons.StarIcon, {
    size: 10
  }), item.vote_average.toFixed(1)), isCenter && React.createElement("div", {
    className: "carousel-badge-wrap"
  }, React.createElement(RatingBadge, {
    cert: ageRating,
    restricted: restricted
  })), isCenter && isAnime && React.createElement("div", {
    className: "carousel-anime-badge"
  }, "ANIME")), isCenter && React.createElement("div", {
    className: "carousel-info"
  }, React.createElement("div", {
    className: "carousel-info__title"
  }, title), React.createElement("div", {
    className: "carousel-info__meta"
  }, year && React.createElement("span", null, year), item.media_type && React.createElement("span", {
    className: "carousel-info__type"
  }, item.media_type === "tv" ? "Series" : "Movie"))));
});
function TrendingCarousel({
  items,
  onSelect,
  title,
  titleHighlight,
  ratingsMap = {}
}) {
  const count = items.length;
  const activeRef = (0, _react.useRef)(0);
  const [active, setActive] = (0, _react.useState)(0);
  const [direction, setDirection] = (0, _react.useState)(1);
  const [animating, setAnimating] = (0, _react.useState)(false);
  const intervalRef = (0, _react.useRef)(null);
  const isFocusedRef = (0, _react.useRef)(false);
  const wheelThrottle = (0, _react.useRef)(false);
  const touchStartX = (0, _react.useRef)(null);
  const containerRef = (0, _react.useRef)(null);
  const animTimeout = (0, _react.useRef)(null);
  const sectionRef = (0, _react.useRef)(null);
  const go = (0, _react.useCallback)(idx => {
    const next = (idx % count + count) % count;
    const curr = activeRef.current;
    if (next === curr) return;
    const fwd = (next - curr + count) % count;
    setDirection(fwd <= count / 2 ? 1 : -1);
    setAnimating(true);
    clearTimeout(animTimeout.current);
    animTimeout.current = setTimeout(() => setAnimating(false), 420);
    activeRef.current = next;
    setActive(next);
  }, [count]);
  const goNext = (0, _react.useCallback)(() => go(activeRef.current + 1), [go]);
  const goPrev = (0, _react.useCallback)(() => go(activeRef.current - 1), [go]);
  const startCycle = (0, _react.useCallback)(() => {
    clearInterval(intervalRef.current);
    intervalRef.current = setInterval(() => go(activeRef.current + 1), 4500);
  }, [go]);
  const resetInterval = (0, _react.useCallback)(() => startCycle(), [startCycle]);
  (0, _react.useEffect)(() => {
    if (count <= 1) return;
    const sectionEl = sectionRef.current;
    if (!sectionEl) return;
    const scrollRoot = document.querySelector(".main");
    const updateFocus = () => {
      const allSections = document.querySelectorAll(".carousel-section");
      let bestEl = null;
      let bestRatio = -1;
      allSections.forEach(el => {
        const r = visibilityRatio(el, scrollRoot);
        if (r > bestRatio) {
          bestRatio = r;
          bestEl = el;
        }
      });
      const should = bestEl === sectionEl && bestRatio > 0.1;
      if (should && !isFocusedRef.current) {
        isFocusedRef.current = true;
        startCycle();
      } else if (!should && isFocusedRef.current) {
        isFocusedRef.current = false;
        clearInterval(intervalRef.current);
      }
    };
    const scrollEl = scrollRoot || window;
    scrollEl.addEventListener("scroll", updateFocus, {
      passive: true
    });
    window.addEventListener("resize", updateFocus, {
      passive: true
    });
    const observer = new IntersectionObserver(([entry]) => {
      if (!entry.isIntersecting) {
        isFocusedRef.current = false;
        clearInterval(intervalRef.current);
      } else {
        updateFocus();
      }
    }, {
      root: scrollRoot,
      threshold: 0
    });
    observer.observe(sectionEl);
    const id = requestAnimationFrame(updateFocus);
    return () => {
      scrollEl.removeEventListener("scroll", updateFocus);
      window.removeEventListener("resize", updateFocus);
      observer.disconnect();
      cancelAnimationFrame(id);
      clearInterval(intervalRef.current);
    };
  }, [count, startCycle]);
  const handleWheel = (0, _react.useCallback)(e => {
    const isHorizontal = Math.abs(e.deltaX) > Math.abs(e.deltaY);
    if (!isHorizontal) return;
    e.preventDefault();
    if (wheelThrottle.current) return;
    wheelThrottle.current = true;
    setTimeout(() => {
      wheelThrottle.current = false;
    }, 600);
    if (e.deltaX > 0) {
      goNext();
    } else {
      goPrev();
    }
    resetInterval();
  }, [goNext, goPrev, resetInterval]);
  (0, _react.useEffect)(() => {
    const el = containerRef.current;
    if (!el) return;
    el.addEventListener("wheel", handleWheel, {
      passive: false
    });
    return () => el.removeEventListener("wheel", handleWheel);
  }, [handleWheel]);
  const touchStartY = (0, _react.useRef)(null);
  const onTouchStart = (0, _react.useCallback)(e => {
    touchStartX.current = e.touches[0].clientX;
    touchStartY.current = e.touches[0].clientY;
  }, []);
  const onTouchEnd = (0, _react.useCallback)(e => {
    if (touchStartX.current === null) return;
    const dx = e.changedTouches[0].clientX - touchStartX.current;
    const dy = e.changedTouches[0].clientY - (touchStartY.current ?? e.changedTouches[0].clientY);
    touchStartX.current = null;
    touchStartY.current = null;
    if (Math.abs(dx) < 48 || Math.abs(dx) < Math.abs(dy) * 1.6) return;
    dx < 0 ? goNext() : goPrev();
    resetInterval();
  }, [goNext, goPrev, resetInterval]);
  const handlePrev = (0, _react.useCallback)(() => {
    goPrev();
    resetInterval();
  }, [goPrev, resetInterval]);
  const handleNext = (0, _react.useCallback)(() => {
    goNext();
    resetInterval();
  }, [goNext, resetInterval]);
  const handleDot = (0, _react.useCallback)(i => {
    go(i);
    resetInterval();
  }, [go, resetInterval]);
  const slots = (0, _react.useMemo)(() => Array.from({
    length: VISIBLE
  }, (_, i) => {
    const offset = i - HALF;
    const idx = ((active + offset) % count + count) % count;
    return {
      offset,
      idx
    };
  }), [active, count]);
  const slotHandlers = (0, _react.useMemo)(() => {
    const handlers = {};
    for (let i = 0; i < VISIBLE; i++) {
      const offset = i - HALF;
      const idx = ((active + offset) % count + count) % count;
      if (offset === 0) {
        handlers[offset] = {
          onSelect: () => onSelect(items[idx]),
          onFocus: null
        };
      } else {
        const captured = idx;
        handlers[offset] = {
          onSelect: null,
          onFocus: () => {
            go(captured);
            resetInterval();
          }
        };
      }
    }
    return handlers;
  }, [active, count, items, onSelect, go, resetInterval]);
  const activeItem = items[active];
  const activeType = activeItem?.media_type === "tv" ? "tv" : "movie";
  const activeRatingKey = activeItem ? `${activeType}_${activeItem.id}` : null;
  const activeRating = activeRatingKey ? ratingsMap[activeRatingKey] || {} : {};
  const dotCount = Math.min(count, 15);
  if (!items || count === 0) return null;
  return React.createElement("div", {
    className: "carousel-section",
    ref: sectionRef
  }, React.createElement("div", {
    className: "section-title"
  }, titleHighlight ? React.createElement(React.Fragment, null, title, "\xA0", React.createElement("span", {
    style: {
      color: "var(--red)"
    }
  }, titleHighlight)) : title), React.createElement("div", {
    className: "carousel-wrapper",
    ref: containerRef,
    onTouchStart: onTouchStart,
    onTouchEnd: onTouchEnd
  }, React.createElement("button", {
    className: "carousel-btn carousel-btn--left",
    onClick: handlePrev,
    "aria-label": "Previous"
  }, React.createElement(_Icons.ChevronLeftIcon, {
    size: 22
  })), React.createElement("div", {
    className: `carousel-track${animating ? ` carousel-track--dir-${direction > 0 ? "fwd" : "bwd"}` : ""}`
  }, slots.map(({
    offset,
    idx
  }) => {
    const isCenter = offset === 0;
    const ratingData = isCenter ? activeRating : {};
    const h = slotHandlers[offset];
    return React.createElement(CarouselSlot, {
      key: offset,
      item: items[idx],
      offset: offset,
      onSelect: h.onSelect,
      onFocus: h.onFocus,
      animating: animating,
      ageRating: isCenter ? ratingData.cert : null,
      restricted: isCenter ? ratingData.restricted : false,
      isAnime: isCenter ? (0, _api.isAnimeContent)(items[idx]) : false
    });
  })), React.createElement("button", {
    className: "carousel-btn carousel-btn--right",
    onClick: handleNext,
    "aria-label": "Next"
  }, React.createElement(_Icons.ChevronRightIcon, {
    size: 22
  }))), React.createElement("div", {
    className: "carousel-dots"
  }, Array.from({
    length: dotCount
  }, (_, i) => React.createElement("button", {
    key: `dot-${i}`,
    className: `carousel-dot${active === i ? " carousel-dot--active" : ""}`,
    onClick: () => handleDot(i),
    "aria-label": `Go to ${i + 1}`
  })), count > 15 && React.createElement("span", {
    className: "carousel-dots__more"
  }, "+", count - 15)));
}
},
"./components/UpdateModal": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = UpdateModal;
var _react = require("react");
function ReleaseImage({
  src,
  alt,
  style
}) {
  const [resolvedSrc, setResolvedSrc] = (0, _react.useState)(null);
  (0, _react.useEffect)(() => {
    if (!src) return;
    if (window.electron?.fetchReleaseImage) {
      window.electron.fetchReleaseImage(src).then(dataUri => {
        setResolvedSrc(dataUri || src);
      });
    } else {
      setResolvedSrc(src);
    }
  }, [src]);
  if (!resolvedSrc) return null;
  return React.createElement("img", {
    src: resolvedSrc,
    alt: alt,
    style: style,
    onError: e => {
      e.currentTarget.style.display = "none";
    }
  });
}
function inlineFormat(text) {
  const parts = [];
  const re = /(~~[^~]+~~|\*\*[^*]+\*\*|\*[^*\n]+\*|_[^_\n]+_|`[^`]+`|!\[[^\]]*\]\([^)]+\)|\[[^\]]+\]\([^)]+\)|https?:\/\/[^\s<>"')]+|@[\w-]+)/g;
  let last = 0,
    m,
    k = 0;
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) parts.push(React.createElement("span", {
      key: k++
    }, text.slice(last, m.index)));
    const raw = m[0];
    if (raw.startsWith("~~")) {
      parts.push(React.createElement("s", {
        key: k++,
        style: {
          color: "var(--text3)"
        }
      }, raw.slice(2, -2)));
    } else if (raw.startsWith("**")) {
      parts.push(React.createElement("strong", {
        key: k++,
        style: {
          color: "var(--text)",
          fontWeight: 600
        }
      }, raw.slice(2, -2)));
    } else if (raw.startsWith("*") || raw.startsWith("_")) {
      parts.push(React.createElement("em", {
        key: k++,
        style: {
          color: "var(--text2)",
          fontStyle: "italic"
        }
      }, raw.slice(1, -1)));
    } else if (raw.startsWith("`")) {
      parts.push(React.createElement("code", {
        key: k++,
        style: {
          fontSize: 11,
          background: "var(--surface)",
          border: "1px solid var(--border)",
          borderRadius: 3,
          padding: "1px 5px",
          fontFamily: "monospace",
          color: "var(--text)"
        }
      }, raw.slice(1, -1)));
    } else if (raw.startsWith("![")) {
      const mm = raw.match(/^!\[([^\]]*)\]\(([^)]+)\)$/);
      if (mm) {
        parts.push(React.createElement(ReleaseImage, {
          key: k++,
          src: mm[2],
          alt: mm[1],
          style: {
            maxWidth: "100%",
            verticalAlign: "middle",
            borderRadius: 6,
            border: "1px solid var(--border)"
          }
        }));
      }
    } else if (raw.startsWith("[")) {
      const mm = raw.match(/^\[([^\]]+)\]\(([^)]+)\)$/);
      if (mm) {
        parts.push(React.createElement("a", {
          key: k++,
          href: mm[2],
          onClick: e => {
            e.preventDefault();
            window.electron?.openExternal(mm[2]);
          },
          style: {
            color: "var(--red)",
            textDecoration: "underline",
            cursor: "pointer"
          }
        }, mm[1]));
      }
    } else if (raw.startsWith("@")) {
      const username = raw.slice(1);
      parts.push(React.createElement("a", {
        key: k++,
        href: `https://t.me/${username}`,
        onClick: e => {
          e.preventDefault();
          window.electron?.openExternal(`https://t.me/${username}`);
        },
        style: {
          color: "var(--red)",
          textDecoration: "none",
          fontWeight: 500,
          cursor: "pointer"
        }
      }, raw));
    } else if (raw.startsWith("http")) {
      let label = raw;
      try {
        const u = new URL(raw);
        const prMatch = u.pathname.match(/\/(pull|issues?)\/(\d+)$/);
        if (prMatch) label = `#${prMatch[2]}`;else label = u.hostname.replace(/^www\./, "") + u.pathname;
      } catch {}
      parts.push(React.createElement("a", {
        key: k++,
        href: raw,
        onClick: e => {
          e.preventDefault();
          window.electron?.openExternal(raw);
        },
        style: {
          color: "var(--red)",
          textDecoration: "underline",
          cursor: "pointer",
          fontSize: "0.95em"
        }
      }, label));
    }
    last = m.index + raw.length;
  }
  if (last < text.length) parts.push(React.createElement("span", {
    key: k++
  }, text.slice(last)));
  return parts.length ? parts : text;
}
function renderChangelog(text) {
  if (!text) return null;
  const lines = text.split("\n");
  const elements = [];
  let key = 0;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    if (line.startsWith("### ")) {
      elements.push(React.createElement("div", {
        key: key++,
        style: {
          fontSize: 13,
          fontWeight: 700,
          color: "var(--text)",
          marginTop: 14,
          marginBottom: 4,
          letterSpacing: 0.3
        }
      }, inlineFormat(line.slice(4))));
      continue;
    }
    if (line.startsWith("## ")) {
      elements.push(React.createElement("div", {
        key: key++,
        style: {
          fontSize: 14,
          fontWeight: 700,
          color: "var(--text)",
          marginTop: 16,
          marginBottom: 6,
          borderBottom: "1px solid var(--border)",
          paddingBottom: 4
        }
      }, inlineFormat(line.slice(3))));
      continue;
    }
    if (line.startsWith("# ")) {
      elements.push(React.createElement("div", {
        key: key++,
        style: {
          fontSize: 15,
          fontWeight: 700,
          color: "var(--text)",
          marginTop: 16,
          marginBottom: 8
        }
      }, inlineFormat(line.slice(2))));
      continue;
    }
    if (/^([-*_])\1{2,}\s*$/.test(line.trim())) {
      elements.push(React.createElement("div", {
        key: key++,
        style: {
          borderBottom: "1px solid var(--border)",
          margin: "12px 0"
        }
      }));
      continue;
    }
    if (line.startsWith("> ")) {
      elements.push(React.createElement("div", {
        key: key++,
        style: {
          borderLeft: "3px solid var(--red)",
          paddingLeft: 10,
          margin: "4px 0",
          color: "var(--text3)",
          fontSize: 13,
          fontStyle: "italic",
          lineHeight: 1.6
        }
      }, inlineFormat(line.slice(2))));
      continue;
    }
    const htmlImgMatch = line.match(/<img\b[^>]*\bsrc="([^"]+)"[^>]*>/i);
    if (htmlImgMatch) {
      const src = htmlImgMatch[1];
      const altMatch = line.match(/\balt="([^"]*)"/i);
      const alt = altMatch ? altMatch[1] : "";
      elements.push(React.createElement("div", {
        key: key++,
        style: {
          margin: "10px 0"
        }
      }, React.createElement(ReleaseImage, {
        src: src,
        alt: alt,
        style: {
          maxWidth: "100%",
          borderRadius: 8,
          border: "1px solid var(--border)",
          display: "block"
        }
      }), alt && React.createElement("div", {
        style: {
          fontSize: 11,
          color: "var(--text3)",
          textAlign: "center",
          marginTop: 4,
          fontStyle: "italic"
        }
      }, alt)));
      continue;
    }
    const imgMatch = line.match(/^!\[([^\]]*)\]\(([^)]+)\)$/);
    if (imgMatch) {
      const [, alt, src] = imgMatch;
      elements.push(React.createElement("div", {
        key: key++,
        style: {
          margin: "10px 0"
        }
      }, React.createElement("img", {
        src: src,
        alt: alt,
        style: {
          maxWidth: "100%",
          borderRadius: 8,
          border: "1px solid var(--border)",
          display: "block"
        },
        onError: e => {
          e.currentTarget.style.display = "none";
        }
      }), alt && React.createElement("div", {
        style: {
          fontSize: 11,
          color: "var(--text3)",
          textAlign: "center",
          marginTop: 4,
          fontStyle: "italic"
        }
      }, alt)));
      continue;
    }
    const numMatch = line.match(/^(\d+)\. (.*)$/);
    if (numMatch) {
      elements.push(React.createElement("div", {
        key: key++,
        style: {
          display: "flex",
          gap: 8,
          fontSize: 13,
          color: "var(--text2)",
          lineHeight: 1.6,
          marginBottom: 2
        }
      }, React.createElement("span", {
        style: {
          color: "var(--red)",
          flexShrink: 0,
          fontWeight: 600,
          minWidth: 18,
          textAlign: "right"
        }
      }, numMatch[1], "."), React.createElement("span", null, inlineFormat(numMatch[2]))));
      continue;
    }
    if (/^[-*] /.test(line)) {
      elements.push(React.createElement("div", {
        key: key++,
        style: {
          display: "flex",
          gap: 8,
          fontSize: 13,
          color: "var(--text2)",
          lineHeight: 1.6,
          marginBottom: 2
        }
      }, React.createElement("span", {
        style: {
          color: "var(--red)",
          flexShrink: 0,
          marginTop: 1
        }
      }, "\u2022"), React.createElement("span", null, inlineFormat(line.slice(2)))));
      continue;
    }
    if (line.trim() === "") {
      elements.push(React.createElement("div", {
        key: key++,
        style: {
          height: 6
        }
      }));
      continue;
    }
    elements.push(React.createElement("div", {
      key: key++,
      style: {
        fontSize: 13,
        color: "var(--text2)",
        lineHeight: 1.6,
        marginBottom: 2
      }
    }, inlineFormat(line)));
  }
  return elements;
}
function UpdateModal({
  updateInfo,
  activeDownloads = 0,
  onClose
}) {
  const {
    latest,
    current,
    url,
    changelog,
    assets,
    sourceLabel
  } = updateInfo;
  const [phase, setPhase] = (0, _react.useState)("idle");
  const [format, setFormat] = (0, _react.useState)(null);
  const [progress, setProgress] = (0, _react.useState)(0);
  const [progressLabel, setProgressLabel] = (0, _react.useState)("");
  const [errorMsg, setErrorMsg] = (0, _react.useState)("");
  const cancelRef = (0, _react.useRef)(false);
  (0, _react.useEffect)(() => {
    if (!window.electron?.detectUpdateFormat) return;
    let mounted = true;
    window.electron.detectUpdateFormat().then(fmt => {
      if (mounted) setFormat(fmt);
    });
    return () => {
      mounted = false;
    };
  }, []);
  (0, _react.useEffect)(() => {
    if (!window.electron?.onUpdateProgress) return;
    const handler = window.electron.onUpdateProgress(data => {
      setProgress(data.percent ?? 0);
      setProgressLabel(data.label ?? "");
    });
    return () => window.electron.offUpdateProgress(handler);
  }, []);
  const assetUrl = format && assets?.[format];
  const canInstall = format && assetUrl && activeDownloads === 0 && phase === "idle";
  const handleInstall = async () => {
    if (!canInstall) return;
    cancelRef.current = false;
    setPhase("downloading");
    setProgress(0);
    setProgressLabel("Preparing…");
    try {
      const result = await window.electron.downloadAndInstallUpdate({
        url: assetUrl,
        format
      });
      if (cancelRef.current) return;
      if (!result.ok) throw new Error(result.error || "Update failed");
      setPhase("installing");
      setProgressLabel("Launching installer…");
    } catch (e) {
      if (cancelRef.current) return;
      setPhase("error");
      setErrorMsg(e.message || "Update failed");
    }
  };
  const handleCancel = () => {
    if (phase === "downloading") {
      cancelRef.current = true;
      window.electron?.cancelUpdate?.();
    }
    onClose();
  };
  const formatLabel = {
    appimage: "AppImage",
    deb: ".deb package",
    pacman: ".pacman (Arch)",
    exe: "Windows installer",
    dmg: "macOS installer (Universal)"
  }[format] || "installer";
  const busy = phase === "downloading" || phase === "installing";
  return React.createElement("div", {
    onClick: busy ? undefined : handleCancel,
    style: {
      position: "fixed",
      inset: 0,
      zIndex: 6000,
      background: "rgba(0,0,0,0.78)",
      backdropFilter: "blur(10px)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      padding: 24,
      cursor: busy ? "default" : "auto"
    }
  }, React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border)",
      borderRadius: 14,
      width: "100%",
      maxWidth: 560,
      maxHeight: "85vh",
      display: "flex",
      flexDirection: "column",
      boxShadow: "0 32px 80px rgba(0,0,0,0.7)",
      overflow: "hidden"
    }
  }, React.createElement("div", {
    style: {
      padding: "24px 28px 16px",
      borderBottom: "1px solid var(--border)",
      flexShrink: 0
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      justifyContent: "space-between",
      gap: 12
    }
  }, React.createElement("div", null, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      marginBottom: 4
    }
  }, React.createElement("span", {
    style: {
      fontSize: 20
    }
  }, "\uD83C\uDF89"), React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 22,
      letterSpacing: 1
    }
  }, "UPDATE AVAILABLE")), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      display: "flex",
      alignItems: "center",
      gap: 8,
      flexWrap: "wrap"
    }
  }, current && React.createElement(React.Fragment, null, React.createElement("span", {
    style: {
      color: "var(--text3)"
    }
  }, "v", current), React.createElement("span", {
    style: {
      color: "var(--text3)",
      fontSize: 11
    }
  }, "\u2192")), React.createElement("a", {
    href: url,
    onClick: e => {
      e.preventDefault();
      window.electron?.openExternal(url);
    },
    style: {
      color: "var(--red)",
      fontWeight: 600,
      textDecoration: "none",
      cursor: "pointer"
    },
    title: `View on ${sourceLabel || "Telegram @ec1lz"}`
  }, "v", latest, " \u2197"), "is ready to install", format && React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      background: "var(--surface2)",
      border: "1px solid var(--border)",
      borderRadius: 4,
      padding: "1px 7px"
    }
  }, formatLabel))), React.createElement("button", {
    onClick: handleCancel,
    disabled: busy,
    style: {
      background: "transparent",
      border: "1px solid var(--border)",
      borderRadius: 6,
      color: "var(--text3)",
      cursor: busy ? "not-allowed" : "pointer",
      fontSize: 18,
      width: 28,
      height: 28,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      flexShrink: 0,
      opacity: busy ? 0.35 : 1
    }
  }, "\xD7"))), React.createElement("div", {
    style: {
      flex: 1,
      overflowY: "auto",
      padding: "20px 28px"
    }
  }, changelog ? React.createElement(React.Fragment, null, React.createElement("div", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      letterSpacing: 1.5,
      color: "var(--text3)",
      textTransform: "uppercase",
      marginBottom: 12
    }
  }, "What's New"), React.createElement("div", null, renderChangelog(changelog))) : React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      fontStyle: "italic"
    }
  }, "No changelog available.")), React.createElement("div", {
    style: {
      padding: "16px 28px",
      borderTop: "1px solid var(--border)",
      flexShrink: 0
    }
  }, activeDownloads > 0 && phase === "idle" && React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--red)",
      marginBottom: 12,
      display: "flex",
      alignItems: "center",
      gap: 6
    }
  }, "\u26A0 ", activeDownloads, " download", activeDownloads > 1 ? "s" : "", " ", "running, finish or cancel them before updating."), !format && phase === "idle" && React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginBottom: 12
    }
  }, "Could not detect install format. Use the", " ", React.createElement("a", {
    href: url,
    onClick: e => {
      e.preventDefault();
      window.electron?.openExternal(url);
    },
    style: {
      color: "var(--red)",
      cursor: "pointer"
    }
  }, sourceLabel || "Telegram @ec1lz", " releases page"), " ", "to download manually."), (phase === "downloading" || phase === "installing") && React.createElement("div", {
    style: {
      marginBottom: 14
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      fontSize: 12,
      color: "var(--text3)",
      marginBottom: 6
    }
  }, React.createElement("span", null, progressLabel || (phase === "downloading" ? "Downloading update…" : "Installing…")), phase === "downloading" && React.createElement("span", null, Math.round(progress), "%")), React.createElement("div", {
    style: {
      height: 4,
      background: "var(--surface2)",
      borderRadius: 2,
      overflow: "hidden"
    }
  }, React.createElement("div", {
    style: {
      height: "100%",
      width: phase === "installing" ? "100%" : `${progress}%`,
      background: "var(--red)",
      borderRadius: 2,
      transition: "width 0.3s ease",
      animation: phase === "installing" ? "progress-indeterminate 1.2s ease-in-out infinite" : "none"
    }
  }))), phase === "error" && React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--red)",
      marginBottom: 12
    }
  }, "\u2715 ", errorMsg, React.createElement("span", {
    style: {
      marginLeft: 10
    }
  }, React.createElement("a", {
    href: url,
    onClick: e => {
      e.preventDefault();
      window.electron?.openExternal(url);
    },
    style: {
      color: "var(--red)",
      textDecoration: "underline",
      cursor: "pointer"
    }
  }, "Download manually \u2197"))), phase === "done" && React.createElement("div", {
    style: {
      fontSize: 13,
      color: "#48c774",
      marginBottom: 12
    }
  }, "\u2713 Update downloaded, installer is running"), React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      justifyContent: "flex-end"
    }
  }, React.createElement("button", {
    className: "btn btn-ghost",
    onClick: handleCancel
  }, phase === "downloading" ? "Cancel" : "Close"), phase === "idle" && React.createElement(React.Fragment, null, React.createElement("a", {
    href: url,
    onClick: e => {
      e.preventDefault();
      window.electron?.openExternal(url);
    },
    style: {
      display: "inline-flex",
      alignItems: "center",
      padding: "9px 18px",
      background: "var(--surface2)",
      border: "1px solid var(--border)",
      borderRadius: 8,
      fontSize: 14,
      fontWeight: 600,
      color: "var(--text)",
      textDecoration: "none",
      cursor: "pointer"
    }
  }, sourceLabel || "Telegram @ec1lz", " \u2197"), React.createElement("button", {
    className: "btn",
    disabled: !canInstall,
    onClick: handleInstall,
    style: {
      background: canInstall ? "var(--red)" : "rgba(229,9,20,0.3)",
      color: "#fff",
      border: "none",
      fontWeight: 600,
      opacity: canInstall ? 1 : 0.6,
      cursor: canInstall ? "pointer" : "not-allowed"
    }
  }, "Install Update"))))), React.createElement("style", null, `
        @keyframes progress-indeterminate {
          0%   { transform: translateX(-100%); width: 60%; }
          100% { transform: translateX(200%);  width: 60%; }
        }
      `));
}
},
"./components/WyzieKeyModal": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = WyzieKeyModal;
var _react = require("react");
var _storage = require("../utils/storage");
function WyzieKeyModal({
  onDone,
  onSkip
}) {
  const [manualKey, setManualKey] = (0, _react.useState)("");
  const [phase, setPhase] = (0, _react.useState)("prompt");
  const [errorMsg, setErrorMsg] = (0, _react.useState)("");
  const isElectron = typeof window !== "undefined" && !!window.electron;
  const saveAndFinish = async key => {
    await _storage.secureStorage.set(_storage.STORAGE_KEYS.WYZIE_API_KEY, key.trim());
    setPhase("success");
    setTimeout(() => onDone(key.trim()), 1000);
  };
  const handleManualSubmit = async () => {
    const key = manualKey.trim();
    if (!key) return;
    setPhase("validating");
    setErrorMsg("");
    try {
      const res = isElectron ? await window.electron.wyzieValidateKey(key) : {
        ok: true
      };
      if (res.ok) {
        await saveAndFinish(key);
      } else {
        setPhase("manual");
        setErrorMsg(res.error || "Invalid key, please try again.");
      }
    } catch (e) {
      setPhase("manual");
      setErrorMsg(e.message);
    }
  };
  const handleRedeem = async () => {
    if (!isElectron) return;
    setPhase("redeeming");
    setErrorMsg("");
    try {
      const res = await window.electron.wyzieOpenRedeem();
      if (res.cancelled) {
        setPhase("prompt");
        return;
      }
      if (res.timeout) {
        setPhase("timeout");
        return;
      }
      if (res.ok && res.key) {
        await saveAndFinish(res.key);
      } else {
        setPhase("prompt");
        setErrorMsg("Could not extract API key. Please copy it manually.");
      }
    } catch (e) {
      setPhase("prompt");
      setErrorMsg(e.message);
    }
  };
  const cardStyle = {
    background: "var(--bg2)",
    border: "1px solid var(--border)",
    borderRadius: 12,
    padding: "28px 32px",
    width: 440,
    maxWidth: "90vw",
    boxShadow: "0 20px 60px rgba(0,0,0,0.6)"
  };
  return React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      background: "rgba(0,0,0,0.75)",
      zIndex: 9999,
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    },
    onClick: e => e.target === e.currentTarget && onSkip()
  }, React.createElement("div", {
    style: cardStyle
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      marginBottom: 16
    }
  }, React.createElement("div", {
    style: {
      width: 36,
      height: 36,
      borderRadius: 8,
      background: "rgba(180,130,255,0.15)",
      border: "1px solid rgba(180,130,255,0.3)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: 18,
      flexShrink: 0
    }
  }, "KEY"), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 15,
      fontWeight: 700,
      color: "var(--text)"
    }
  }, "Wyzie Subs requires an API key"), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 2
    }
  }, "Free, no account required"))), (phase === "prompt" || phase === "error") && React.createElement(React.Fragment, null, React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      lineHeight: 1.65,
      marginBottom: 22
    }
  }, "Wyzie Subs now requires a free API key. Claim one instantly by solving a quick captcha, no registration needed.", errorMsg && React.createElement("div", {
    style: {
      marginTop: 10,
      padding: "8px 12px",
      borderRadius: 6,
      background: "rgba(255,80,80,0.1)",
      border: "1px solid rgba(255,80,80,0.25)",
      color: "#ff6060",
      fontSize: 12
    }
  }, errorMsg)), React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, React.createElement("button", {
    className: "btn btn-primary",
    style: {
      width: "100%",
      padding: "10px 0",
      fontSize: 13
    },
    onClick: handleRedeem
  }, "Get free key \u2014 opens redeem page"), React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      width: "100%",
      padding: "9px 0",
      fontSize: 13
    },
    onClick: () => {
      setPhase("manual");
      setErrorMsg("");
    }
  }, "I already have a key \u2014 enter manually"), React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      width: "100%",
      padding: "8px 0",
      fontSize: 12,
      color: "var(--text3)"
    },
    onClick: onSkip
  }, "Skip \u2014 use without subtitles"))), phase === "manual" && React.createElement(React.Fragment, null, React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      marginBottom: 14,
      lineHeight: 1.6
    }
  }, "Paste your Wyzie API key below. It looks like", " ", React.createElement("code", {
    style: {
      color: "var(--text)",
      fontSize: 11
    }
  }, "wyzie-xxxxxxxxxxxxxxxx")), React.createElement("input", {
    className: "apikey-input",
    style: {
      width: "100%",
      marginBottom: 10,
      boxSizing: "border-box"
    },
    type: "text",
    placeholder: "wyzie-...",
    value: manualKey,
    onChange: e => setManualKey(e.target.value),
    onKeyDown: e => e.key === "Enter" && handleManualSubmit(),
    autoFocus: true
  }), errorMsg && React.createElement("div", {
    style: {
      marginBottom: 10,
      padding: "7px 10px",
      borderRadius: 6,
      background: "rgba(255,80,80,0.1)",
      border: "1px solid rgba(255,80,80,0.25)",
      color: "#ff6060",
      fontSize: 12
    }
  }, errorMsg), React.createElement("div", {
    style: {
      display: "flex",
      gap: 8
    }
  }, React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      fontSize: 12,
      padding: "7px 14px"
    },
    onClick: () => {
      setPhase("prompt");
      setErrorMsg("");
    }
  }, "Back"), React.createElement("button", {
    className: "btn btn-primary",
    style: {
      flex: 1,
      fontSize: 13,
      padding: "8px 0"
    },
    onClick: handleManualSubmit,
    disabled: !manualKey.trim()
  }, "Confirm & validate"))), phase === "redeeming" && React.createElement("div", {
    style: {
      textAlign: "center",
      padding: "24px 0",
      color: "var(--text3)",
      fontSize: 13
    }
  }, React.createElement("div", {
    style: {
      fontSize: 28,
      marginBottom: 12
    }
  }, "\uD83C\uDF10"), React.createElement("div", {
    style: {
      color: "var(--text)",
      fontWeight: 600,
      marginBottom: 6
    }
  }, "Complete the captcha in the popup window"), "Please wait \u2014 key will be saved automatically\u2026"), phase === "validating" && React.createElement("div", {
    style: {
      textAlign: "center",
      padding: "24px 0",
      color: "var(--text3)",
      fontSize: 13
    }
  }, React.createElement("div", {
    style: {
      fontSize: 28,
      marginBottom: 12
    }
  }, "\u23F3"), "Validating key\u2026"), phase === "success" && React.createElement("div", {
    style: {
      textAlign: "center",
      padding: "24px 0",
      color: "#63cab7",
      fontSize: 14,
      fontWeight: 600
    }
  }, React.createElement("div", {
    style: {
      fontSize: 28,
      marginBottom: 10
    }
  }, "\u2705"), "API key saved! Loading subtitles\u2026"), phase === "timeout" && React.createElement(React.Fragment, null, React.createElement("div", {
    style: {
      textAlign: "center",
      padding: "20px 0 16px",
      color: "var(--text3)",
      fontSize: 13,
      lineHeight: 1.6
    }
  }, React.createElement("div", {
    style: {
      fontSize: 28,
      marginBottom: 10
    }
  }, "\u23F1\uFE0F"), "No key received within 10 seconds.", React.createElement("br", null), "The captcha may not have been completed, or the redirect failed."), React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 10
    }
  }, React.createElement("button", {
    className: "btn btn-primary",
    style: {
      width: "100%",
      padding: "9px 0",
      fontSize: 13
    },
    onClick: handleRedeem
  }, "Try again"), React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      width: "100%",
      padding: "9px 0",
      fontSize: 13
    },
    onClick: () => {
      setPhase("manual");
      setErrorMsg("");
    }
  }, "Enter key manually"), React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      width: "100%",
      padding: "8px 0",
      fontSize: 12,
      color: "var(--text3)"
    },
    onClick: onSkip
  }, "Skip")))));
}
},
"./components/seasonalEvents": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useSeasonalEvent = useSeasonalEvent;
var _react = require("react");
const EVENTS = [{
  id: "pride",
  check: d => d.getMonth() === 5,
  render: () => React.createElement(PrideOverlay, null)
}, {
  id: "christmas",
  check: d => d.getMonth() === 11 && d.getDate() >= 20,
  render: () => React.createElement(SnowOverlay, null)
}, {
  id: "newyear",
  check: d => d.getMonth() === 0 && d.getDate() <= 5,
  render: () => React.createElement(SnowOverlay, null)
}, {
  id: "halloween",
  check: d => d.getMonth() === 9 && d.getDate() >= 24,
  render: () => React.createElement(HalloweenOverlay, null)
}];
function useSeasonalEvent() {
  const [event, setEvent] = (0, _react.useState)(() => getActiveEvent());
  (0, _react.useEffect)(() => {
    const msUntilMidnight = () => {
      const now = new Date();
      const midnight = new Date(now);
      midnight.setHours(24, 0, 0, 0);
      return midnight - now;
    };
    let timeout;
    const schedule = () => {
      timeout = setTimeout(() => {
        setEvent(getActiveEvent());
        schedule();
      }, msUntilMidnight());
    };
    schedule();
    return () => clearTimeout(timeout);
  }, []);
  return event;
}
function getActiveEvent() {
  const now = new Date();
  return EVENTS.find(e => e.check(now)) ?? null;
}
const PRIDE_STRIPES = ["#FF0018", "#FFA52C", "#FFFF41", "#008018", "#0000F9", "#86007D"];
function PrideOverlay() {
  return React.createElement("div", {
    style: overlayBase
  }, React.createElement("div", {
    style: {
      position: "absolute",
      bottom: 3,
      right: 2,
      width: 14,
      height: 10,
      borderRadius: 1,
      overflow: "hidden",
      display: "flex",
      flexDirection: "column",
      boxShadow: "0 0 0 1px rgba(0,0,0,0.25)"
    }
  }, PRIDE_STRIPES.map((color, i) => React.createElement("div", {
    key: i,
    style: {
      flex: 1,
      background: color
    }
  }))));
}
const SNOWFLAKES = Array.from({
  length: 7
}, (_, i) => ({
  left: `${10 + i * 13}%`,
  delay: `${i * 0.4}s`,
  duration: `${1.6 + i % 3 * 0.5}s`,
  size: i % 2 === 0 ? 3 : 2
}));
function SnowOverlay() {
  return React.createElement("div", {
    style: {
      ...overlayBase,
      overflow: "hidden"
    }
  }, React.createElement("style", null, `
        @keyframes sb-snow-fall {
          0%   { transform: translateY(-6px) rotate(0deg); opacity: 0; }
          15%  { opacity: 1; }
          85%  { opacity: 1; }
          100% { transform: translateY(44px) rotate(180deg); opacity: 0; }
        }
      `), SNOWFLAKES.map((s, i) => React.createElement("div", {
    key: i,
    style: {
      position: "absolute",
      left: s.left,
      top: 0,
      width: s.size,
      height: s.size,
      borderRadius: "50%",
      background: "#fff",
      opacity: 0,
      animation: `sb-snow-fall ${s.duration} ${s.delay} infinite linear`
    }
  })));
}
function HalloweenOverlay() {
  return React.createElement("div", {
    style: overlayBase
  }, React.createElement("div", {
    style: {
      position: "absolute",
      bottom: 1,
      right: 1,
      width: 14,
      height: 14,
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      fontSize: 12,
      lineHeight: 1
    }
  }, "\uD83C\uDF83"));
}
const overlayBase = {
  position: "absolute",
  inset: 0,
  borderRadius: "inherit",
  display: "flex",
  flexDirection: "column",
  pointerEvents: "none",
  overflow: "hidden"
};
},
"./main": function(module, exports, require) {
"use strict";

var _react = _interopRequireDefault(require("react"));
var _client = _interopRequireDefault(require("react-dom/client"));
var _App = _interopRequireDefault(require("./App"));
require("./styles/global.css");
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
_client.default.createRoot(document.getElementById("root")).render(_react.default.createElement(_react.default.StrictMode, null, _react.default.createElement(_App.default, null)));
},
"./pages/DownloadsPage": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = DownloadsPage;
var _react = require("react");
var _Icons = require("../components/Icons");
var _storage = require("../utils/storage");
var _SubtitleDownloaderModal = _interopRequireDefault(require("../components/SubtitleDownloaderModal"));
var _api = require("../utils/api");
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
const STATUS_CLASS = {
  downloading: "dl-status--downloading",
  completed: "dl-status--completed",
  error: "dl-status--error",
  interrupted: "dl-status--interrupted",
  paused: "dl-status--interrupted",
  cancelled: "dl-status--error"
};
const STATUS_LABEL = {
  downloading: "Downloading",
  completed: "Completed",
  error: "Error",
  interrupted: "Interrupted",
  paused: "Paused",
  cancelled: "Cancelled"
};
function timeAgo(ts) {
  if (!ts) return "";
  const sec = Math.floor((Date.now() - ts) / 1000);
  if (sec < 60) return "just now";
  if (sec < 3600) return Math.floor(sec / 60) + "m ago";
  if (sec < 86400) return Math.floor(sec / 3600) + "h ago";
  return Math.floor(sec / 86400) + "d ago";
}
const Poster = (0, _react.memo)(function Poster({
  posterPath,
  size = 48
}) {
  const [errored, setErrored] = (0, _react.useState)(false);
  const style = {
    width: size,
    height: size * 1.5
  };
  if (posterPath && !errored) {
    return React.createElement("img", {
      src: (0, _api.imgUrl)(posterPath, "w154"),
      alt: "",
      onError: () => setErrored(true),
      className: "dl-poster",
      style: style
    });
  }
  return React.createElement("div", {
    className: "dl-poster dl-poster--fallback",
    style: style
  }, React.createElement(_Icons.FilmIcon, null));
});
function parseSize(str) {
  if (!str) return 0;
  const m = String(str).match(/([\d.]+)\s*(B|KB|MB|GB|TB)/i);
  if (!m) return 0;
  const n = parseFloat(m[1]);
  const map = {
    B: 1,
    KB: 1024,
    MB: 1048576,
    GB: 1073741824,
    TB: 1099511627776
  };
  return n * (map[m[2].toUpperCase()] || 1);
}
const SORT_OPTIONS = [{
  value: "date",
  label: "Date"
}, {
  value: "name",
  label: "Name"
}, {
  value: "size",
  label: "Size"
}, {
  value: "type",
  label: "Type"
}];
function DownloadsPage({
  downloads,
  onDeleteDownload,
  onHistory,
  onSaveProgress,
  progress,
  watched,
  onMarkWatched,
  onMarkUnwatched,
  highlightId,
  onClearHighlight,
  onSelect,
  onUpdateDownload,
  onSettings,
  searchOpen: searchOpenProp = false,
  onSearchClose
}) {
  const [fileExistsCache, setFileExistsCache] = (0, _react.useState)({});
  const [localFiles, setLocalFiles] = (0, _react.useState)(() => _storage.storage.get("localFiles") || []);
  const [scanning, setScanning] = (0, _react.useState)(false);
  const [scanFolder, setScanFolder] = (0, _react.useState)(() => _storage.storage.get("downloadPath") || "");
  const highlightRef = (0, _react.useRef)(null);
  const [subtitleModalDl, setSubtitleModalDl] = (0, _react.useState)(null);
  const [showUntracked, setShowUntracked] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.DL_SHOW_UNTRACKED) ?? true);
  const [sortBy, setSortBy] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.DL_SORT_BY) ?? "date");
  const [sortDir, setSortDir] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.DL_SORT_DIR) ?? "desc");
  const [searchOpen, setSearchOpen] = (0, _react.useState)(false);
  const [searchQuery, setSearchQuery] = (0, _react.useState)("");
  const searchInputRef = (0, _react.useRef)(null);
  (0, _react.useEffect)(() => {
    _storage.storage.set(_storage.STORAGE_KEYS.DL_SORT_BY, sortBy);
  }, [sortBy]);
  (0, _react.useEffect)(() => {
    _storage.storage.set(_storage.STORAGE_KEYS.DL_SORT_DIR, sortDir);
  }, [sortDir]);
  (0, _react.useEffect)(() => {
    _storage.storage.set(_storage.STORAGE_KEYS.DL_SHOW_UNTRACKED, showUntracked);
  }, [showUntracked]);
  (0, _react.useEffect)(() => {
    if (searchOpenProp) {
      setSearchOpen(true);
      onSearchClose?.();
    }
  }, [searchOpenProp]);
  (0, _react.useEffect)(() => {
    const handler = e => {
      if (e.key === "Escape") {
        setSearchOpen(false);
        setSearchQuery("");
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);
  (0, _react.useEffect)(() => {
    if (searchOpen) setTimeout(() => searchInputRef.current?.focus(), 50);
  }, [searchOpen]);
  const active = (0, _react.useMemo)(() => downloads.filter(d => d.status === "downloading" || d.status === "paused"), [downloads]);
  const finished = (0, _react.useMemo)(() => downloads.filter(d => d.status !== "downloading" && d.status !== "paused").sort((a, b) => (b.completedAt || 0) - (a.completedAt || 0)), [downloads]);
  const localFileItems = (0, _react.useMemo)(() => localFiles.map(f => ({
    id: f.filePath,
    name: f.name,
    filePath: f.filePath,
    size: f.size,
    status: "local",
    isLocalOnly: true
  })), [localFiles]);
  const allLocalItemsRaw = (0, _react.useMemo)(() => {
    const finishedVisible = finished.filter(d => fileExistsCache[d.id] !== false);
    const finishedPaths = new Set(finished.map(d => d.filePath));
    const extraLocal = localFileItems.filter(lf => !finishedPaths.has(lf.filePath));
    return [...finishedVisible, ...extraLocal];
  }, [finished, localFileItems, fileExistsCache]);
  const untrackedCount = (0, _react.useMemo)(() => allLocalItemsRaw.filter(d => d.isLocalOnly).length, [allLocalItemsRaw]);
  const allLocalItems = (0, _react.useMemo)(() => {
    const step1 = showUntracked ? allLocalItemsRaw : allLocalItemsRaw.filter(d => !d.isLocalOnly);
    const q = searchQuery.trim().toLowerCase();
    const step2 = q ? step1.filter(d => (d.name || "").toLowerCase().includes(q)) : step1;
    return [...step2].sort((a, b) => {
      let cmp = 0;
      if (sortBy === "date") cmp = (a.completedAt || 0) - (b.completedAt || 0);
      if (sortBy === "name") cmp = (a.name || "").localeCompare(b.name || "");
      if (sortBy === "size") cmp = parseSize(a.size) - parseSize(b.size);
      if (sortBy === "type") cmp = (a.mediaType || "local").localeCompare(b.mediaType || "local");
      return sortDir === "desc" ? -cmp : cmp;
    });
  }, [allLocalItemsRaw, showUntracked, searchQuery, sortBy, sortDir]);
  const q = searchQuery.trim().toLowerCase();
  const searchResultCount = q ? allLocalItems.length : null;
  (0, _react.useEffect)(() => {
    if (!highlightId || !highlightRef.current) return;
    const el = highlightRef.current;
    const tScroll = setTimeout(() => el.scrollIntoView({
      behavior: "smooth",
      block: "center"
    }), 150);
    const t = setTimeout(() => onClearHighlight?.(), 3000);
    return () => {
      clearTimeout(tScroll);
      clearTimeout(t);
    };
  }, [highlightId]);
  (0, _react.useEffect)(() => {
    if (!_storage.isElectron) return;
    let mounted = true;
    finished.forEach(d => {
      if (d.filePath && d.status === "completed" && fileExistsCache[d.id] === undefined) {
        window.electron.fileExists(d.filePath).then(exists => {
          if (!mounted) return;
          setFileExistsCache(prev => ({
            ...prev,
            [d.id]: exists
          }));
          if (!exists) {
            window.electron.deleteDownload({
              id: d.id,
              filePath: null
            });
            onDeleteDownload(d.id);
          }
        });
      }
      if (d.status === "completed" && d.subtitlePaths?.length > 0 && window.electron.pruneSubtitlePaths) {
        window.electron.pruneSubtitlePaths(d.id).then(res => {
          if (!mounted) return;
          if (res?.ok && res.subtitlePaths.length !== d.subtitlePaths.length) {
            onUpdateDownload?.(d.id, {
              subtitlePaths: res.subtitlePaths
            });
          }
        });
      }
    });
    return () => {
      mounted = false;
    };
  }, [finished, onDeleteDownload, onUpdateDownload]);
  const handleScanFolder = (0, _react.useCallback)(async () => {
    if (!_storage.isElectron || !scanFolder) return;
    setScanning(true);
    try {
      const files = await window.electron.scanDirectory(scanFolder);
      const knownPaths = new Set(downloads.map(d => d.filePath).filter(Boolean));
      const unique = (files || []).filter(f => !knownPaths.has(f.filePath));
      setLocalFiles(unique);
      _storage.storage.set("localFiles", unique);
      if (window.electron.pruneSubtitlePaths) {
        for (const d of finished) {
          if (d.subtitlePaths?.length > 0) {
            const res = await window.electron.pruneSubtitlePaths(d.id);
            if (res?.ok && res.subtitlePaths.length !== d.subtitlePaths.length) {
              onUpdateDownload?.(d.id, {
                subtitlePaths: res.subtitlePaths
              });
            }
          }
        }
      }
    } finally {
      setScanning(false);
    }
  }, [scanFolder, downloads, finished, onUpdateDownload]);
  const handleDelete = (0, _react.useCallback)(async dl => {
    if (!confirm(`Delete "${dl.name}"${dl.filePath ? " and its file" : ""}?`)) return;
    await window.electron.deleteDownload({
      id: dl.id,
      filePath: dl.filePath
    });
    if (dl.id) _storage.storage.set(DURATION_PREFIX + dl.id, null);
    const watchedKey = dl.mediaType === "movie" ? `movie_${dl.tmdbId || dl.mediaId}` : dl.mediaType === "tv" && dl.tmdbId && dl.season && dl.episode ? `tv_${dl.tmdbId}_s${dl.season}e${dl.episode}` : null;
    if (watchedKey) _storage.storage.set(PROGRESS_TIME_PREFIX + watchedKey, null);
    onDeleteDownload(dl.id);
  }, [onDeleteDownload]);
  return React.createElement("div", {
    className: "fade-in dl-page"
  }, subtitleModalDl && React.createElement(_SubtitleDownloaderModal.default, {
    dl: subtitleModalDl,
    onClose: () => setSubtitleModalDl(null),
    onOpenSettings: onSettings,
    onSubtitlesSaved: newPaths => {
      const existing = subtitleModalDl.subtitlePaths || [];
      const existingIds = new Set(existing.map(e => e.file_id).filter(Boolean));
      const existingLangsSet = new Set(existing.map(e => e.lang));
      const updated = [...existing, ...newPaths.filter(np => np.file_id ? !existingIds.has(np.file_id) : !existingLangsSet.has(np.lang))];
      onUpdateDownload?.(subtitleModalDl.id, {
        subtitlePaths: updated
      });
      setSubtitleModalDl(prev => prev ? {
        ...prev,
        subtitlePaths: updated
      } : null);
    },
    onSubtitleDeleted: deletedPath => {
      const updated = (subtitleModalDl.subtitlePaths || []).filter(sp => sp.path !== deletedPath);
      onUpdateDownload?.(subtitleModalDl.id, {
        subtitlePaths: updated
      });
      setSubtitleModalDl(prev => prev ? {
        ...prev,
        subtitlePaths: updated
      } : null);
    }
  }), React.createElement("div", {
    className: "dl-page__title"
  }, "DOWNLOADS"), React.createElement("div", {
    className: "dl-page__subtitle"
  }, active.length > 0 ? `${active.length} active` : "No active downloads", " ", "\xB7 ", allLocalItemsRaw.length, " completed"), searchOpen && React.createElement("div", {
    className: "dl-search-bar"
  }, React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "var(--text3)",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      flexShrink: 0
    }
  }, React.createElement("circle", {
    cx: "11",
    cy: "11",
    r: "8"
  }), React.createElement("line", {
    x1: "21",
    y1: "21",
    x2: "16.65",
    y2: "16.65"
  })), React.createElement("input", {
    ref: searchInputRef,
    className: "dl-search-bar__input",
    value: searchQuery,
    onChange: e => setSearchQuery(e.target.value),
    placeholder: "Filter downloads\u2026"
  }), q && React.createElement("span", {
    className: "dl-search-bar__count"
  }, searchResultCount === 0 ? "No results" : `${searchResultCount} result${searchResultCount !== 1 ? "s" : ""}`), React.createElement("button", {
    className: "dl-search-bar__close",
    onClick: () => {
      setSearchOpen(false);
      setSearchQuery("");
    },
    title: "Close (Esc)"
  }, "\u2715")), React.createElement("div", {
    className: "dl-toolbar"
  }, React.createElement("div", {
    className: "dl-toolbar__group"
  }, React.createElement("span", {
    className: "dl-toolbar__label"
  }, "Sort by"), React.createElement("div", {
    className: "dl-toolbar__sort-btns"
  }, SORT_OPTIONS.map(({
    value,
    label
  }) => React.createElement("button", {
    key: value,
    className: `dl-toolbar__sort-btn${sortBy === value ? " dl-toolbar__sort-btn--active" : ""}`,
    onClick: () => setSortBy(value)
  }, label))), React.createElement("button", {
    className: "dl-toolbar__dir-btn",
    onClick: () => setSortDir(d => d === "desc" ? "asc" : "desc"),
    title: sortDir === "desc" ? "Descending" : "Ascending"
  }, sortDir === "desc" ? "↓" : "↑")), React.createElement("div", {
    className: "dl-toolbar__group"
  }, React.createElement("button", {
    className: `dl-toolbar__toggle${showUntracked ? " dl-toolbar__toggle--on" : ""}`,
    onClick: () => setShowUntracked(v => !v),
    title: showUntracked ? "Hide untracked files" : "Show untracked files"
  }, showUntracked ? "⊙" : "⊘", " Untracked", untrackedCount > 0 ? ` (${untrackedCount})` : ""), !searchOpen && React.createElement("button", {
    className: "dl-toolbar__search-hint",
    onClick: () => setSearchOpen(true),
    title: "Search (Ctrl+K)"
  }, React.createElement("svg", {
    width: "13",
    height: "13",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, React.createElement("circle", {
    cx: "11",
    cy: "11",
    r: "8"
  }), React.createElement("line", {
    x1: "21",
    y1: "21",
    x2: "16.65",
    y2: "16.65"
  })), React.createElement("span", {
    className: "dl-toolbar__search-hint-key"
  }, "Ctrl+K")))), active.length > 0 && React.createElement("div", {
    className: "dl-page__section"
  }, React.createElement("div", {
    className: "settings-section-title dl-section-title"
  }, "Active"), React.createElement("div", {
    className: "dl-page__list"
  }, active.map(dl => React.createElement(ActiveCard, {
    key: dl.id,
    dl: dl,
    onDelete: () => handleDelete(dl),
    onSelect: dl.tmdbId && dl.mediaType ? () => onSelect?.({
      id: dl.tmdbId,
      media_type: dl.mediaType,
      title: dl.mediaType === "movie" ? dl.name : undefined,
      name: dl.mediaType === "tv" ? dl.name : undefined,
      poster_path: dl.posterPath || null,
      season: dl.mediaType === "tv" && dl.season != null ? Number(dl.season) : undefined
    }) : null
  })))), React.createElement("div", null, React.createElement("div", {
    className: "dl-page__local-header"
  }, React.createElement("div", {
    className: "settings-section-title dl-section-title--inline"
  }, "Local Files"), React.createElement("div", {
    className: "dl-page__scan-controls"
  }, _storage.isElectron && React.createElement(React.Fragment, null, React.createElement("input", {
    className: "dl-page__scan-input",
    placeholder: "Folder to scan\u2026",
    value: scanFolder,
    onChange: e => setScanFolder(e.target.value)
  }), React.createElement("button", {
    className: "btn btn-secondary btn--sm",
    onClick: async () => {
      const folder = await window.electron.pickFolder();
      if (folder) {
        setScanFolder(folder);
        _storage.storage.set("downloadPath", folder);
      }
    }
  }, "Browse"), React.createElement("button", {
    className: "btn btn-ghost btn--sm",
    onClick: handleScanFolder,
    disabled: scanning || !scanFolder
  }, scanning ? "Scanning…" : "⟳ Scan")))), allLocalItems.length > 0 ? React.createElement("div", {
    className: "dl-page__local-list"
  }, allLocalItems.map(dl => {
    const isHighlighted = dl.id === highlightId;
    const watchedKey = dl.mediaType === "movie" ? `movie_${dl.tmdbId || dl.mediaId}` : dl.mediaType === "tv" && dl.tmdbId && dl.season && dl.episode ? `tv_${dl.tmdbId}_s${dl.season}e${dl.episode}` : null;
    return React.createElement(LocalFileCard, {
      key: dl.id,
      dl: dl,
      fileExists: dl.isLocalOnly ? true : fileExistsCache[dl.id],
      onWatch: subtitlePaths => subtitlePaths?.length > 0 ? window.electron.openPathAtTime(dl.filePath, 0, subtitlePaths) : window.electron.openPath(dl.filePath),
      onHistory: onHistory,
      onShowFolder: () => window.electron?.showInFolder(dl.filePath),
      onDelete: dl.isLocalOnly ? undefined : () => handleDelete(dl),
      isHighlighted: isHighlighted,
      highlightRef: isHighlighted ? highlightRef : null,
      watchedKey: watchedKey,
      isWatched: watchedKey ? !!watched?.[watchedKey] : false,
      onMarkWatched: watchedKey ? () => onMarkWatched?.(watchedKey) : null,
      onMarkUnwatched: watchedKey ? () => onMarkUnwatched?.(watchedKey) : null,
      onSelect: dl.tmdbId && dl.mediaType ? () => onSelect?.({
        id: dl.tmdbId,
        media_type: dl.mediaType,
        title: dl.mediaType === "movie" ? dl.name : undefined,
        name: dl.mediaType === "tv" ? dl.name : undefined,
        poster_path: dl.posterPath || null,
        season: dl.mediaType === "tv" && dl.season != null ? Number(dl.season) : undefined
      }) : null,
      onOpenSubtitleDownloader: dl.tmdbId ? () => setSubtitleModalDl(dl) : null,
      onOpenLog: dl.logPath && dl.status === "error" ? () => window.electron.openPath(dl.logPath) : null
    });
  })) : React.createElement("div", {
    className: "dl-page__empty-text"
  }, q ? `No downloads match "${searchQuery}".` : downloads.length === 0 && localFiles.length === 0 ? "No local files yet. Scan a folder or start a download." : "No completed downloads or local files found.")), downloads.length === 0 && localFiles.length === 0 && active.length === 0 && React.createElement("div", {
    className: "empty-state"
  }, React.createElement(_Icons.DownloadIcon, null), React.createElement("h3", null, "No downloads yet"), React.createElement("p", null, "Start a download from any movie or series page, or scan a folder to find local video files.")));
}
const ActiveCard = (0, _react.memo)(function ActiveCard({
  dl,
  onDelete,
  onSelect
}) {
  const pct = dl.progress || 0;
  return React.createElement("div", {
    className: "dl-card dl-card-active"
  }, React.createElement("div", {
    className: "dl-card__header"
  }, React.createElement(Poster, {
    posterPath: dl.posterPath,
    size: 42
  }), React.createElement("div", {
    className: "dl-card__info"
  }, React.createElement("div", {
    className: `dl-card__name${onSelect ? " dl-card__title--clickable" : ""}`,
    onClick: onSelect || undefined,
    onMouseEnter: e => {
      if (onSelect) e.currentTarget.style.color = "var(--red)";
    },
    onMouseLeave: e => {
      if (onSelect) e.currentTarget.style.color = "";
    },
    title: onSelect ? `Open ${dl.name}` : undefined
  }, dl.name), React.createElement("div", {
    className: "dl-card__meta"
  }, dl.speed && React.createElement("span", null, "\u2193 ", dl.speed), dl.eta && React.createElement("span", null, "\u23F1 ", dl.eta), dl.size && React.createElement("span", null, dl.size), dl.totalFragments > 0 && React.createElement("span", null, dl.completedFragments || 0, "/", dl.totalFragments, " fragments"), dl.subtitles?.length > 0 && React.createElement("span", {
    style: {
      fontSize: 10,
      fontWeight: 700,
      padding: "1px 6px",
      borderRadius: 3,
      background: "rgba(99,202,183,0.12)",
      color: "#63cab7",
      border: "1px solid rgba(99,202,183,0.25)"
    },
    title: dl.subtitles.map(s => s.lang?.toUpperCase()).join(", ")
  }, React.createElement(_Icons.SubtitlesIcon, {
    size: 11,
    style: {
      verticalAlign: "middle",
      marginRight: 3
    }
  }), dl.subtitles.map(s => (s.lang || "?").toUpperCase()).join(" · ")))), React.createElement("div", {
    className: "dl-card__right"
  }, React.createElement("div", {
    className: "dl-card__pct"
  }, pct.toFixed(1), "%"), dl.status === "downloading" ? React.createElement("button", {
    className: "btn btn-secondary btn--sm",
    onClick: () => window.androidBridge?.pauseDownload?.(dl.id),
    title: "Pause Download"
  }, "\u23F8 Pause") : React.createElement("button", {
    className: "btn btn-primary btn--sm",
    onClick: () => window.androidBridge?.resumeDownload?.(dl.id),
    title: "Resume Download"
  }, "\u25B6 Resume"), React.createElement("button", {
    className: "btn btn-ghost btn--sm",
    onClick: () => window.androidBridge?.cancelDownload?.(dl.id),
    title: "Cancel Download"
  }, "\u2715 Cancel"), React.createElement("button", {
    className: "icon-btn",
    onClick: onDelete,
    title: "Remove"
  }, React.createElement(_Icons.TrashIcon, null)))), React.createElement("div", {
    className: "dl-card__bar-wrap"
  }, React.createElement("div", {
    className: `dl-card__bar-fill${pct > 0 ? " dl-card__bar-fill--active" : ""}`,
    style: {
      width: `${Math.min(pct, 100)}%`
    }
  })), dl.lastMessage && React.createElement("div", {
    className: "dl-card__log"
  }, dl.lastMessage));
});
function secsToHms(s) {
  if (!s || s <= 0) return null;
  const h = Math.floor(s / 3600);
  const m = Math.floor(s % 3600 / 60);
  const sec = Math.floor(s % 60);
  return [h, m, sec].map(v => String(v).padStart(2, "0")).join(":");
}
function hmsToSecs(str) {
  const parts = str.trim().split(":").map(Number);
  if (parts.some(isNaN)) return null;
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  if (parts.length === 1 && parts[0] >= 0) return parts[0];
  return null;
}
const PROGRESS_TIME_PREFIX = "dlTime_";
const DURATION_PREFIX = "dlDur_";
const LocalFileCard = (0, _react.memo)(function LocalFileCard({
  dl,
  fileExists,
  onWatch,
  onShowFolder,
  onDelete,
  isHighlighted,
  highlightRef,
  isWatched,
  onMarkWatched,
  onMarkUnwatched,
  onSelect,
  watchedKey,
  onHistory,
  onOpenSubtitleDownloader,
  onOpenLog
}) {
  const isDownload = !dl.isLocalOnly;
  const canWatch = !!fileExists && !!dl.filePath;
  const storageKey = watchedKey ? PROGRESS_TIME_PREFIX + watchedKey : null;
  const durKey = dl.id ? DURATION_PREFIX + dl.id : null;
  const [savedSecs, setSavedSecs] = (0, _react.useState)(() => storageKey ? _storage.storage.get(storageKey) ?? null : null);
  const [showPopover, setShowPopover] = (0, _react.useState)(false);
  const [popoverSecs, setPopoverSecs] = (0, _react.useState)(0);
  const [popoverHH, setPopoverHH] = (0, _react.useState)("00");
  const [popoverMM, setPopoverMM] = (0, _react.useState)("00");
  const [popoverSS, setPopoverSS] = (0, _react.useState)("00");
  const [videoDuration, setVideoDuration] = (0, _react.useState)(() => durKey ? _storage.storage.get(durKey) ?? null : null);
  const [durationLoading, setDurationLoading] = (0, _react.useState)(false);
  const popoverRef = (0, _react.useRef)(null);
  const fetchingRef = (0, _react.useRef)(false);
  const hhRef = (0, _react.useRef)(null);
  const mmRef = (0, _react.useRef)(null);
  const ssRef = (0, _react.useRef)(null);
  (0, _react.useEffect)(() => {
    if (!storageKey) return;
    setSavedSecs(_storage.storage.get(storageKey) ?? null);
  }, [storageKey]);
  (0, _react.useEffect)(() => {
    if (!showPopover || !dl.filePath || videoDuration !== null || fetchingRef.current) return;
    if (!window.electron?.getVideoDuration) return;
    let mounted = true;
    fetchingRef.current = true;
    setDurationLoading(true);
    window.electron.getVideoDuration(dl.filePath).then(res => {
      if (mounted && res?.ok && res.duration > 0) {
        setVideoDuration(res.duration);
        if (durKey) _storage.storage.set(durKey, res.duration);
      }
    }).catch(() => {}).finally(() => {
      if (mounted) {
        setDurationLoading(false);
      }
      fetchingRef.current = false;
    });
    return () => {
      mounted = false;
    };
  }, [showPopover, dl.filePath, videoDuration, durKey]);
  (0, _react.useEffect)(() => {
    if (!showPopover) return;
    const handler = e => {
      if (popoverRef.current && !popoverRef.current.contains(e.target)) setShowPopover(false);
    };
    const tid = setTimeout(() => document.addEventListener("mousedown", handler), 0);
    return () => {
      clearTimeout(tid);
      document.removeEventListener("mousedown", handler);
    };
  }, [showPopover]);
  const openPopover = (0, _react.useCallback)(() => {
    const s = savedSecs ?? 0;
    setPopoverSecs(s);
    const hms = secsToHms(s) ?? "00:00:00";
    const [hh, mm, ss] = hms.split(":");
    setPopoverHH(hh ?? "00");
    setPopoverMM(mm ?? "00");
    setPopoverSS(ss ?? "00");
    setShowPopover(true);
  }, [savedSecs]);
  const handleSliderChange = (0, _react.useCallback)(e => {
    const s = Number(e.target.value);
    setPopoverSecs(s);
    const hms = secsToHms(s) ?? "00:00:00";
    const [hh, mm, ss] = hms.split(":");
    setPopoverHH(hh ?? "00");
    setPopoverMM(mm ?? "00");
    setPopoverSS(ss ?? "00");
  }, []);
  const makeSegmentHandler = (0, _react.useCallback)((setter, nextRef) => e => {
    const raw = e.target.value.replace(/\D/g, "").slice(0, 2);
    setter(raw);
    if (raw.length === 2 && nextRef?.current) nextRef.current.focus();
    const hh = setter === setPopoverHH ? raw : popoverHH;
    const mm = setter === setPopoverMM ? raw : popoverMM;
    const ss = setter === setPopoverSS ? raw : popoverSS;
    const s = hmsToSecs(`${hh}:${mm}:${ss}`);
    if (s !== null) setPopoverSecs(s);
  }, [popoverHH, popoverMM, popoverSS]);
  const commitPopover = (0, _react.useCallback)(() => {
    const str = `${popoverHH}:${popoverMM}:${popoverSS}`;
    let s = hmsToSecs(str);
    if (s === null) s = popoverSecs;
    if (s !== null && storageKey) {
      const clamped = videoDuration ? Math.min(Math.max(0, s), videoDuration) : Math.max(0, s);
      _storage.storage.set(storageKey, clamped);
      setSavedSecs(clamped);
    }
    setShowPopover(false);
  }, [popoverHH, popoverMM, popoverSS, popoverSecs, storageKey, videoDuration]);
  const resetProgress = (0, _react.useCallback)(() => {
    if (storageKey) {
      _storage.storage.set(storageKey, null);
      setSavedSecs(null);
    }
    setShowPopover(false);
  }, [storageKey]);
  const handleWatch = (0, _react.useCallback)(() => {
    if (!dl.filePath) return;
    if (onHistory && dl.tmdbId && dl.mediaType) {
      onHistory({
        id: dl.tmdbId,
        title: dl.mediaType === "movie" ? dl.name : undefined,
        name: dl.mediaType === "tv" ? dl.name : undefined,
        poster_path: dl.posterPath || null,
        media_type: dl.mediaType,
        season: dl.season != null ? Number(dl.season) : null,
        episode: dl.episode != null ? Number(dl.episode) : null
      });
    }
    if (savedSecs > 0 && window.electron?.openPathAtTime) {
      window.electron.openPathAtTime(dl.filePath, savedSecs, dl.subtitlePaths);
    } else {
      onWatch(dl.subtitlePaths);
    }
  }, [dl.filePath, savedSecs, onWatch, onHistory, dl]);
  const progressLabel = (() => {
    if (isWatched) return null;
    if (!storageKey) return null;
    if (!savedSecs) return "Not started";
    return videoDuration ? `${secsToHms(savedSecs)} / ${secsToHms(videoDuration)}` : secsToHms(savedSecs);
  })();
  return React.createElement("div", {
    ref: highlightRef,
    className: `dl-card${isHighlighted ? " dl-card-highlighted" : ""}`
  }, React.createElement("div", {
    className: "dl-card__row"
  }, React.createElement("div", {
    className: `dl-card__poster-wrap${onSelect ? " dl-card__poster-wrap--clickable" : ""}`,
    onClick: onSelect || undefined,
    title: onSelect ? "Go to page" : undefined,
    onMouseEnter: e => {
      if (onSelect) e.currentTarget.style.opacity = "0.75";
    },
    onMouseLeave: e => {
      e.currentTarget.style.opacity = "1";
    }
  }, React.createElement(Poster, {
    posterPath: dl.posterPath,
    size: 40
  })), React.createElement("div", {
    className: "dl-card__body"
  }, React.createElement("div", {
    className: "dl-card__title-row"
  }, React.createElement("div", {
    className: `dl-card__title${onSelect ? " dl-card__title--clickable" : ""}`,
    onClick: onSelect || undefined,
    onMouseEnter: e => {
      if (onSelect) e.currentTarget.style.color = "var(--red)";
    },
    onMouseLeave: e => {
      e.currentTarget.style.color = "";
    },
    title: onSelect ? `Open ${dl.name}` : undefined
  }, dl.name), isWatched && React.createElement("span", {
    className: "dl-card__watched-icon",
    title: "Watched"
  }, React.createElement(_Icons.WatchedIcon, {
    size: 14
  }))), React.createElement("div", {
    className: "dl-card__meta"
  }, isDownload && React.createElement("span", {
    className: `dl-status ${STATUS_CLASS[dl.status] || ""}`
  }, STATUS_LABEL[dl.status]), !isDownload && React.createElement("span", {
    className: "dl-status dl-status--local"
  }, "Local"), dl.completedAt && React.createElement("span", null, timeAgo(dl.completedAt)), dl.size && React.createElement("span", null, dl.size), (() => {
    const hasSubs = (dl.subtitlePaths?.length ?? 0) > 0;
    const langs = hasSubs ? dl.subtitlePaths.map(s => (s.lang || "?").toUpperCase()).join(" · ") : null;
    return React.createElement("span", {
      title: onOpenSubtitleDownloader ? hasSubs ? `Subtitles: ${langs}: click to manage` : "No subtitles: click to download" : hasSubs ? `Subtitles: ${langs}` : "No subtitles",
      onClick: onOpenSubtitleDownloader || undefined,
      style: {
        fontSize: 10,
        fontWeight: 700,
        padding: "1px 6px",
        borderRadius: 3,
        background: hasSubs ? "rgba(99,202,183,0.12)" : "rgba(255,255,255,0.04)",
        color: hasSubs ? "#63cab7" : "var(--text3)",
        border: hasSubs ? "1px solid rgba(99,202,183,0.25)" : "1px solid var(--border)",
        cursor: onOpenSubtitleDownloader ? "pointer" : "default",
        letterSpacing: "0.03em",
        display: "inline-flex",
        alignItems: "center",
        gap: 3,
        transition: "opacity 0.15s"
      },
      onMouseEnter: e => {
        if (onOpenSubtitleDownloader) e.currentTarget.style.opacity = "0.75";
      },
      onMouseLeave: e => {
        e.currentTarget.style.opacity = "1";
      }
    }, React.createElement(_Icons.SubtitlesIcon, {
      size: 10,
      style: {
        verticalAlign: "middle"
      }
    }), hasSubs ? langs : "No subtitles");
  })(), fileExists === false && React.createElement("span", {
    className: "dl-status--missing"
  }, "File missing"), progressLabel !== null && storageKey && React.createElement("span", {
    style: {
      position: "relative",
      display: "inline-flex"
    }
  }, React.createElement("span", {
    className: `dl-progress-pill${savedSecs ? " dl-progress-pill--active" : " dl-progress-pill--empty"}`,
    onClick: openPopover,
    title: "Set watch progress",
    style: {
      cursor: "pointer",
      userSelect: "none"
    }
  }, React.createElement("span", {
    className: "dl-progress-pill__label"
  }, progressLabel), React.createElement("span", {
    className: "dl-progress-pill__edit-icon"
  }, "\u270E")), showPopover && React.createElement("div", {
    ref: popoverRef,
    style: {
      position: "absolute",
      bottom: "calc(100% + 6px)",
      left: 0,
      zIndex: 9999,
      background: "var(--surface)",
      border: "1px solid var(--border)",
      borderRadius: 10,
      padding: "10px 12px 9px",
      width: 240,
      boxShadow: "0 6px 24px rgba(0,0,0,0.55)",
      display: "flex",
      flexDirection: "column",
      gap: 7
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      justifyContent: "space-between"
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      gap: 4
    }
  }, React.createElement("span", {
    style: {
      fontSize: 16,
      fontWeight: 700,
      fontVariantNumeric: "tabular-nums",
      color: "var(--text)"
    }
  }, secsToHms(popoverSecs) ?? "00:00:00"), React.createElement("span", {
    style: {
      fontSize: 11,
      color: "var(--text3)",
      fontVariantNumeric: "tabular-nums"
    }
  }, durationLoading ? "/ …" : videoDuration ? `/ ${secsToHms(videoDuration)}` : "")), React.createElement("button", {
    className: "icon-btn",
    onClick: () => setShowPopover(false),
    style: {
      fontSize: 12,
      padding: "0 3px"
    }
  }, "\u2715")), videoDuration && React.createElement("div", null, React.createElement("input", {
    type: "range",
    min: 0,
    max: Math.floor(videoDuration),
    step: 1,
    value: Math.min(popoverSecs, Math.floor(videoDuration)),
    onChange: handleSliderChange,
    style: {
      width: "100%",
      accentColor: "var(--red)",
      cursor: "pointer",
      height: 3
    }
  }), React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      fontSize: 10,
      color: "var(--text3)",
      marginTop: 1
    }
  }, React.createElement("span", null, "0:00"), React.createElement("span", {
    style: {
      fontWeight: 600,
      color: "var(--text2)"
    }
  }, Math.round(popoverSecs / videoDuration * 100), "%"), React.createElement("span", null, secsToHms(videoDuration)))), React.createElement("div", {
    style: {
      display: "flex",
      gap: 5
    }
  }, React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      display: "flex",
      alignItems: "center",
      background: "var(--surface2)",
      border: "1px solid var(--border)",
      borderRadius: 6,
      padding: "4px 8px",
      gap: 2
    },
    onFocus: e => {
      e.currentTarget.style.borderColor = "var(--red)";
    },
    onBlur: e => {
      if (!e.currentTarget.contains(e.relatedTarget)) e.currentTarget.style.borderColor = "var(--border)";
    }
  }, [{
    ref: hhRef,
    value: popoverHH,
    setter: setPopoverHH,
    next: mmRef,
    label: "HH"
  }, {
    ref: mmRef,
    value: popoverMM,
    setter: setPopoverMM,
    next: ssRef,
    label: "MM"
  }, {
    ref: ssRef,
    value: popoverSS,
    setter: setPopoverSS,
    next: null,
    label: "SS"
  }].map(({
    ref,
    value,
    setter,
    next,
    label
  }, i) => React.createElement("span", {
    key: label,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 2
    }
  }, i > 0 && React.createElement("span", {
    style: {
      color: "var(--text3)",
      fontWeight: 700,
      fontSize: 13,
      userSelect: "none"
    }
  }, ":"), React.createElement("input", {
    ref: ref,
    type: "text",
    inputMode: "numeric",
    maxLength: 2,
    value: value,
    placeholder: label,
    autoFocus: i === 0,
    onChange: makeSegmentHandler(setter, next),
    onFocus: e => e.target.select(),
    onKeyDown: e => {
      if (e.key === "Enter") commitPopover();
      if (e.key === "Escape") setShowPopover(false);
    },
    style: {
      width: 26,
      background: "transparent",
      border: "none",
      outline: "none",
      color: "var(--text)",
      fontSize: 12,
      fontVariantNumeric: "tabular-nums",
      fontWeight: 600,
      textAlign: "center",
      letterSpacing: "0.04em",
      padding: 0
    }
  })))), React.createElement("button", {
    className: "btn btn-ghost btn--sm",
    onClick: resetProgress,
    style: {
      fontSize: 11,
      padding: "4px 7px"
    },
    title: "Reset"
  }, "\u21BA"), React.createElement("button", {
    className: "btn btn-primary btn--sm",
    onClick: commitPopover,
    style: {
      fontSize: 11,
      padding: "4px 9px"
    }
  }, "Save")))))), React.createElement("div", {
    className: "dl-card__actions"
  }, onMarkWatched && (isWatched ? React.createElement("button", {
    className: "btn btn-ghost watched-btn dl-btn--sm",
    onClick: onMarkUnwatched,
    title: "Mark as Unwatched"
  }, React.createElement(_Icons.WatchedIcon, {
    size: 13
  }), " Watched") : React.createElement("button", {
    className: "btn btn-ghost dl-btn--sm",
    onClick: onMarkWatched,
    title: "Mark as Watched"
  }, "\u2713 Mark Watched")), (dl.status === "error" || dl.status === "cancelled" || dl.status === "interrupted") && React.createElement("button", {
    className: "btn btn-secondary dl-btn--sm",
    onClick: () => window.androidBridge?.retryDownload?.(dl.id),
    title: "Retry Download"
  }, "\u21BB Retry"), canWatch && React.createElement("button", {
    className: "btn btn-primary dl-btn--sm-primary",
    onClick: handleWatch,
    title: savedSecs > 0 ? `Resume at ${secsToHms(savedSecs)}` : "Watch"
  }, React.createElement(_Icons.PlayIcon, null), " ", savedSecs > 0 ? "Resume" : "Watch"), dl.filePath && React.createElement("button", {
    className: "btn btn-ghost dl-btn--sm-icon",
    onClick: onShowFolder,
    title: "Show in folder"
  }, React.createElement(_Icons.FolderIcon, null)), onDelete && React.createElement("button", {
    className: "icon-btn",
    onClick: onDelete,
    title: "Delete"
  }, React.createElement(_Icons.TrashIcon, null)), onOpenLog && dl.logPath && dl.status === "error" && React.createElement("button", {
    className: "btn btn-ghost dl-btn--sm",
    onClick: onOpenLog,
    title: "Open error log",
    style: {
      color: "var(--red)",
      fontSize: 11
    }
  }, "View Log"))));
});
},
"./pages/HomePage": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = HomePage;
var _react = _interopRequireWildcard(require("react"));
var _MediaCard = _interopRequireDefault(require("../components/MediaCard"));
var _HeroBanner = _interopRequireDefault(require("../components/HeroBanner"));
var _api = require("../utils/api");
var _Icons = require("../components/Icons");
var _useRatings = require("../utils/useRatings");
var _ageRating = require("../utils/ageRating");
var _homeLayout = require("../utils/homeLayout");
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function (nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function getRecentHistoryItems(history, count = 5) {
  if (!history || history.length === 0) return [];
  const thirtyDaysAgo = Date.now() - 30 * 24 * 60 * 60 * 1000;
  const recent = history.filter(h => h.watchedAt && h.watchedAt > thirtyDaysAgo).sort((a, b) => b.watchedAt - a.watchedAt);
  const seen = new Set();
  const unique = [];
  for (const item of recent) {
    const key = `${item.media_type || "movie"}_${item.id}`;
    if (seen.has(key)) continue;
    seen.add(key);
    unique.push(item);
    if (unique.length >= count) break;
  }
  return unique;
}
function HomePage({
  trending,
  trendingTV,
  loading,
  onSelect,
  progress,
  inProgress,
  offline,
  onRetry,
  watched,
  onMarkWatched,
  onMarkUnwatched,
  history,
  apiKey
}) {
  const [recommendedItems, setRecommendedItems] = (0, _react.useState)([]);
  const [topRatedItems, setTopRatedItems] = (0, _react.useState)([]);
  const [layout, setLayout] = (0, _react.useState)(() => (0, _homeLayout.loadHomeLayout)());
  const [viewMode, setViewMode] = (0, _react.useState)(() => (0, _homeLayout.loadHomeViewMode)());
  (0, _react.useEffect)(() => {
    const onLayout = () => setLayout((0, _homeLayout.loadHomeLayout)());
    const onView = () => setViewMode((0, _homeLayout.loadHomeViewMode)());
    window.addEventListener("streambert:home-layout-changed", onLayout);
    window.addEventListener("streambert:home-view-changed", onView);
    return () => {
      window.removeEventListener("streambert:home-layout-changed", onLayout);
      window.removeEventListener("streambert:home-view-changed", onView);
    };
  }, []);
  const {
    order: rowOrder,
    visible: rowVisible
  } = layout;
  const allItems = (0, _react.useMemo)(() => [...inProgress, ...trending.map(i => ({
    ...i,
    media_type: "movie"
  })), ...trendingTV.map(i => ({
    ...i,
    media_type: "tv"
  })), ...recommendedItems, ...topRatedItems], [inProgress, trending, trendingTV, recommendedItems, topRatedItems]);
  const {
    ratingsMap,
    ageLimitSetting
  } = (0, _useRatings.useRatings)(allItems);
  const itemRestricted = (0, _react.useCallback)(item => (0, _ageRating.isRestricted)((0, _useRatings.getRatingForItem)(item, ratingsMap).minAge, ageLimitSetting), [ratingsMap, ageLimitSetting]);
  const enrichedRatingsMap = (0, _react.useMemo)(() => {
    const out = {};
    for (const [k, v] of Object.entries(ratingsMap)) {
      out[k] = {
        ...v,
        restricted: (0, _ageRating.isRestricted)(v.minAge, ageLimitSetting)
      };
    }
    return out;
  }, [ratingsMap, ageLimitSetting]);
  const filteredRecommendedItems = (0, _react.useMemo)(() => recommendedItems.filter(item => !itemRestricted(item)), [recommendedItems, itemRestricted]);
  (0, _react.useEffect)(() => {
    if (!apiKey || offline || !history || history.length === 0) return;
    const sources = getRecentHistoryItems(history, 5);
    if (sources.length === 0) return;
    const controller = new AbortController();
    const watchedIds = new Set((history || []).map(h => `${h.media_type || "movie"}_${h.id}`));
    const fetches = sources.map(source => {
      const type = source.media_type === "tv" ? "tv" : "movie";
      return (0, _api.tmdbFetch)(`/${type}/${source.id}/recommendations`, apiKey, {
        signal: controller.signal
      }).then(data => {
        const results = (data.results || []).map(i => ({
          ...i,
          media_type: type
        }));
        if (results.length > 0) return results;
        return (0, _api.tmdbFetch)(`/${type}/${source.id}/similar`, apiKey, {
          signal: controller.signal
        }).then(d => (d.results || []).map(i => ({
          ...i,
          media_type: type
        })));
      }).catch(() => []);
    });
    Promise.all(fetches).then(arrays => {
      const merged = [];
      const maxLen = Math.max(...arrays.map(a => a.length));
      for (let i = 0; i < maxLen; i++) {
        for (const arr of arrays) {
          if (arr[i]) merged.push(arr[i]);
        }
      }
      const seen = new Set();
      const deduped = merged.filter(item => {
        const key = `${item.media_type}_${item.id}`;
        if (seen.has(key) || watchedIds.has(key)) return false;
        seen.add(key);
        return true;
      });
      setRecommendedItems(deduped.slice(0, 20));
    }).catch(() => {});
    return () => controller.abort();
  }, [apiKey, offline, history?.length]);
  (0, _react.useEffect)(() => {
    if (!apiKey || offline) return;
    const controller = new AbortController();
    Promise.all([(0, _api.tmdbFetch)("/movie/top_rated?page=1", apiKey, {
      signal: controller.signal
    }), (0, _api.tmdbFetch)("/tv/top_rated?page=1", apiKey, {
      signal: controller.signal
    })]).then(([moviesData, tvData]) => {
      const movies = (moviesData.results || []).slice(0, 10).map(i => ({
        ...i,
        media_type: "movie"
      }));
      const tv = (tvData.results || []).slice(0, 10).map(i => ({
        ...i,
        media_type: "tv"
      }));
      const merged = [];
      const max = Math.max(movies.length, tv.length);
      for (let i = 0; i < max; i++) {
        if (movies[i]) merged.push(movies[i]);
        if (tv[i]) merged.push(tv[i]);
      }
      setTopRatedItems(merged);
    }).catch(() => {});
    return () => controller.abort();
  }, [apiKey, offline]);
  const trendingMovieItems = (0, _react.useMemo)(() => trending.slice(0, 16).map(i => ({
    ...i,
    media_type: "movie"
  })), [trending]);
  const trendingTVItems = (0, _react.useMemo)(() => trendingTV.slice(0, 16).map(i => ({
    ...i,
    media_type: "tv"
  })), [trendingTV]);
  const heroItems = (0, _react.useMemo)(() => trendingMovieItems.slice(0, 5), [trendingMovieItems]);
  const renderRow = (key, title, items, variant = "landscape") => {
    if (!items || items.length === 0) return null;
    return _react.default.createElement("section", {
      key: key,
      className: "tv-row-section"
    }, _react.default.createElement("div", {
      className: "tv-row-header"
    }, _react.default.createElement("h2", {
      className: "tv-row-title"
    }, title)), _react.default.createElement("div", {
      className: viewMode === "list" ? "cards-grid tv-cards-grid" : "scroll-row tv-scroll-row"
    }, items.map(item => {
      const type = item.media_type === "tv" ? "tv" : "movie";
      const rk = `${type}_${item.id}`;
      const rd = enrichedRatingsMap[rk] || {};
      const pk = item.media_type === "movie" ? `movie_${item.id}` : item.season != null && item.episode != null ? `tv_${item.id}_s${item.season}e${item.episode}` : null;
      return _react.default.createElement(_MediaCard.default, {
        key: `${type}_${item.id}_${item.season || ""}_${item.episode || ""}`,
        item: item,
        variant: variant,
        onClick: () => onSelect(item),
        progress: pk ? progress[pk] || 0 : 0,
        watched: watched,
        onMarkWatched: onMarkWatched,
        onMarkUnwatched: onMarkUnwatched,
        ageRating: rd.cert,
        restricted: rd.restricted
      });
    })));
  };
  const topPicksItems = filteredRecommendedItems.length > 0 ? filteredRecommendedItems : trendingMovieItems;
  return _react.default.createElement("div", {
    className: "tv-home fade-in"
  }, offline && _react.default.createElement("div", {
    className: "tv-offline-state"
  }, _react.default.createElement(_Icons.WifiOffIcon, {
    size: 48
  }), _react.default.createElement("div", {
    style: {
      fontSize: 20,
      fontWeight: 600,
      color: "var(--text)"
    }
  }, "No internet connection"), _react.default.createElement("div", {
    style: {
      fontSize: 14,
      color: "var(--text3)"
    }
  }, "Trending and search require an internet connection. Your downloads and library still work offline."), _react.default.createElement("button", {
    className: "btn btn-primary",
    onClick: onRetry
  }, "Retry")), !offline && loading && _react.default.createElement("div", {
    className: "loader"
  }, _react.default.createElement("div", {
    className: "spinner"
  })), !offline && !loading && heroItems.length > 0 && _react.default.createElement(_HeroBanner.default, {
    items: heroItems,
    onSelect: onSelect,
    ratingsMap: enrichedRatingsMap
  }), _react.default.createElement("div", {
    className: "tv-rows-container"
  }, rowOrder.map(id => {
    if (!rowVisible[id]) return null;
    if (id === "continue") {
      return renderRow("continue", "Continue watching", inProgress, "landscape");
    }
    if (id === "recommended") {
      return renderRow("recommended", "Top picks for you", topPicksItems, "landscape");
    }
    if (id === "trendingTV") {
      return renderRow("trendingTV", "Trending TV Shows", trendingTVItems, "landscape");
    }
    if (id === "trendingMovies") {
      return renderRow("trendingMovies", "New movies and shows", trendingMovieItems, "poster");
    }
    if (id === "topRated") {
      return renderRow("topRated", "Top Rated", topRatedItems, "poster");
    }
    return null;
  })));
}
},
"./pages/LibraryPage": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = LibraryPage;
var _react = _interopRequireWildcard(require("react"));
var _MediaCard = _interopRequireDefault(require("../components/MediaCard"));
var _api = require("../utils/api");
var _Icons = require("../components/Icons");
var _useRatings = require("../utils/useRatings");
var _ageRating = require("../utils/ageRating");
var _storage = require("../utils/storage");
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function (nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
function LibraryPage({
  history,
  inProgress,
  saved,
  progress,
  onSelect,
  watched,
  onMarkWatched,
  onMarkUnwatched,
  onRemoveHistory,
  downloads = [],
  onOpenExoPlayer
}) {
  const allItems = (0, _react.useMemo)(() => [...inProgress, ...saved], [inProgress, saved]);
  const {
    ratingsMap,
    ageLimitSetting
  } = (0, _useRatings.useRatings)(allItems);
  const [sort, setSort] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.LIBRARY_SORT) || "manual");
  (0, _react.useEffect)(() => {
    const handler = e => setSort(e.detail);
    window.addEventListener("streambert:library-sort-changed", handler);
    return () => window.removeEventListener("streambert:library-sort-changed", handler);
  }, []);
  const offlineDownloads = (0, _react.useMemo)(() => {
    return (downloads || []).filter(d => d && (d.status === "completed" || d.status === "local") && (d.outputPath || d.filePath || d.path));
  }, [downloads]);
  const playOfflineDownload = (0, _react.useCallback)(dl => {
    const fileUrl = dl.outputPath || dl.filePath || dl.path;
    if (!fileUrl) return;
    const pk = dl.mediaType === "tv" ? `tv_${dl.tmdbId || dl.mediaId}_s${dl.season || 1}e${dl.episode || 1}` : `movie_${dl.tmdbId || dl.mediaId}`;
    const startSec = _storage.storage.get("dlTime_" + pk) || 0;
    const payload = {
      url: fileUrl,
      title: dl.name || dl.title || "Offline Video",
      startTimeSec: startSec,
      subtitles: dl.subtitles || [],
      progressKey: pk,
      mediaType: dl.mediaType || "movie",
      subTextColor: _storage.storage.get("subtitleTextColor") || "#FFFFFF",
      subBgStyle: _storage.storage.get("subtitleBgStyle") || "dark",
      subFontSizeSp: Number(_storage.storage.get("subtitleFontSizeSp") || 22),
      preferredSubLang: _storage.storage.get(_storage.STORAGE_KEYS.SUBTITLE_LANG) || "ar"
    };
    if (window.AndroidBridge?.openExoPlayer) {
      window.AndroidBridge.openExoPlayer(JSON.stringify(payload));
    } else {
      onOpenExoPlayer?.(payload);
    }
  }, [onOpenExoPlayer]);
  const sortLabels = {
    manual: "Custom order",
    title: "A-Z",
    rating: "Top rated",
    year: "Newest first"
  };
  const getRating = (0, _react.useCallback)(item => (0, _useRatings.getRatingForItem)(item, ratingsMap), [ratingsMap]);
  const itemRestricted = (0, _react.useCallback)(item => (0, _ageRating.isRestricted)(getRating(item).minAge, ageLimitSetting), [getRating, ageLimitSetting]);
  return _react.default.createElement("div", {
    className: "fade-in"
  }, _react.default.createElement("div", {
    className: "library-header"
  }, _react.default.createElement("div", {
    className: "library-title"
  }, "My Library"), _react.default.createElement("div", {
    className: "library-sub"
  }, "Offline downloads, watch history, and saved titles")), offlineDownloads.length > 0 && _react.default.createElement("div", {
    className: "library-section"
  }, _react.default.createElement("div", {
    className: "library-section-title",
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, _react.default.createElement(_Icons.DownloadIcon, null), _react.default.createElement("span", null, "Downloaded \xB7 Watch Offline (", offlineDownloads.length, ")")), _react.default.createElement("div", {
    className: "offline-grid"
  }, offlineDownloads.map(dl => _react.default.createElement("button", {
    key: dl.id,
    className: "offline-card",
    onClick: () => playOfflineDownload(dl)
  }, _react.default.createElement("div", {
    className: "offline-card-poster"
  }, dl.posterPath ? _react.default.createElement("img", {
    src: (0, _api.imgUrl)(dl.posterPath, "w185"),
    alt: dl.name || dl.title
  }) : _react.default.createElement("div", {
    className: "offline-card-fallback"
  }, _react.default.createElement(_Icons.FilmIcon, null)), _react.default.createElement("div", {
    className: "offline-card-play"
  }, _react.default.createElement(_Icons.PlayIcon, null))), _react.default.createElement("div", {
    className: "offline-card-info"
  }, _react.default.createElement("div", {
    className: "offline-card-title"
  }, dl.name || dl.title), _react.default.createElement("div", {
    className: "offline-card-meta"
  }, dl.size || "Offline Ready", " \xB7 ", dl.mediaType === "tv" ? "Series" : "Movie")))))), inProgress.length > 0 && _react.default.createElement("div", {
    className: "library-section"
  }, _react.default.createElement("div", {
    className: "library-section-title"
  }, "Continue Watching"), _react.default.createElement("div", {
    className: "cards-grid"
  }, inProgress.map(item => {
    const pk = item.media_type === "movie" ? `movie_${item.id}` : `tv_${item.id}_s${item.season}e${item.episode}`;
    const r = getRating(item);
    const restr = itemRestricted(item);
    return _react.default.createElement(_MediaCard.default, {
      key: pk,
      item: item,
      onClick: () => onSelect(item),
      progress: progress[pk] || 0,
      watched: watched,
      onMarkWatched: onMarkWatched,
      onMarkUnwatched: onMarkUnwatched,
      ageRating: r.cert,
      restricted: restr
    });
  }))), saved.length > 0 && _react.default.createElement("div", {
    className: "library-section"
  }, _react.default.createElement("div", {
    className: "library-section-title"
  }, "Watchlist (", saved.length, ")", sort !== "manual" && _react.default.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: 400,
      color: "var(--text3)",
      marginLeft: 10
    }
  }, sortLabels[sort])), _react.default.createElement("div", {
    className: "cards-grid"
  }, saved.map(item => {
    const r = getRating(item);
    const restr = itemRestricted(item);
    return _react.default.createElement(_MediaCard.default, {
      key: `${item.media_type}_${item.id}`,
      item: item,
      onClick: () => onSelect(item),
      watched: watched,
      onMarkWatched: onMarkWatched,
      onMarkUnwatched: onMarkUnwatched,
      ageRating: r.cert,
      restricted: restr
    });
  }))), history.length > 0 && _react.default.createElement("div", {
    className: "library-section"
  }, _react.default.createElement("div", {
    className: "library-section-title"
  }, "Watch History"), _react.default.createElement("div", {
    className: "history-rows"
  }, history.map(item => {
    const pk = item.media_type === "movie" ? `movie_${item.id}` : `tv_${item.id}_s${item.season}e${item.episode}`;
    const isWatched = !!watched?.[pk];
    return _react.default.createElement("div", {
      key: `${pk}_${item.watchedAt}`,
      className: "history-row",
      onClick: () => onSelect(item)
    }, _react.default.createElement("div", {
      className: "history-thumb"
    }, item.poster_path && _react.default.createElement("img", {
      src: (0, _api.imgUrl)(item.poster_path, "w92"),
      alt: ""
    })), _react.default.createElement("div", {
      style: {
        flex: 1
      }
    }, _react.default.createElement("div", {
      style: {
        fontSize: 14,
        fontWeight: 500,
        display: "flex",
        alignItems: "center",
        gap: 6
      }
    }, item.title, isWatched && _react.default.createElement(_Icons.WatchedIcon, {
      size: 16
    })), _react.default.createElement("div", {
      style: {
        fontSize: 12,
        color: "var(--text3)"
      }
    }, item.media_type === "tv" && item.season != null && item.episode != null && _react.default.createElement(_react.default.Fragment, null, `S${item.season}E${item.episode}`, item.episodeName ? ` · ${item.episodeName}` : "", " · "), new Date(item.watchedAt).toLocaleDateString("en-US", {
      year: "numeric",
      month: "short",
      day: "numeric"
    }))), _react.default.createElement("span", {
      className: `search-result-type ${item.media_type === "tv" ? "type-tv" : "type-movie"}`
    }, item.media_type === "tv" ? "Series" : "Movie"), onRemoveHistory && _react.default.createElement("button", {
      className: "history-remove-btn",
      title: "Remove from history",
      onClick: e => {
        e.stopPropagation();
        onRemoveHistory(item);
      }
    }, "\u2715"));
  }))), offlineDownloads.length === 0 && history.length === 0 && saved.length === 0 && _react.default.createElement("div", {
    className: "empty-state"
  }, _react.default.createElement(_Icons.EyeIcon, null), _react.default.createElement("h3", null, "Nothing here yet"), _react.default.createElement("p", null, "Start watching or download a movie or series to watch offline.")));
}
},
"./pages/MoviePage": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = MoviePage;
var _react = require("react");
var _api = require("../utils/api");
var _Icons = require("../components/Icons");
var _DownloadModal = _interopRequireDefault(require("../components/DownloadModal"));
var _TrailerModal = _interopRequireDefault(require("../components/TrailerModal"));
var _BlockedStatsModal = _interopRequireDefault(require("../components/BlockedStatsModal"));
var _useBlockedStats = require("../utils/useBlockedStats");
var _MediaCard = _interopRequireDefault(require("../components/MediaCard"));
var _storage = require("../utils/storage");
var _ageRating = require("../utils/ageRating");
var _DownloadConfirmModal = _interopRequireDefault(require("../components/DownloadConfirmModal"));
var _useCredits = require("../utils/useCredits");
var _playerGamepadScript = require("../utils/playerGamepadScript");
var _useSourceId = require("../utils/useSourceId");
var _gamepadPlayerState = require("../utils/gamepadPlayerState");
var _HiAnimeLoader = _interopRequireDefault(require("../components/HiAnimeLoader"));
var _StreamPlayerFrame = _interopRequireDefault(require("../components/StreamPlayerFrame"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
function MoviePage({
  item,
  apiKey,
  playerSettings,
  onSave,
  isSaved,
  onHistory,
  progress,
  saveProgress,
  onBack,
  onSettings,
  onDownloadStarted,
  watched,
  onMarkWatched,
  onMarkUnwatched,
  downloads,
  onGoToDownloads,
  onSelect,
  onOpenExoPlayer
}) {
  const [details, setDetails] = (0, _react.useState)(null);
  const [playing, setPlaying] = (0, _react.useState)(false);
  const [showDownload, setShowDownload] = (0, _react.useState)(false);
  const [trailerKey, setTrailerKey] = (0, _react.useState)(null);
  const [showTrailer, setShowTrailer] = (0, _react.useState)(false);
  const [showDownloadConfirm, setShowDownloadConfirm] = (0, _react.useState)(false);
  const [pendingDownload, setPendingDownload] = (0, _react.useState)(false);
  const credits = (0, _useCredits.useCredits)("movie", item.id, apiKey);
  const [m3u8Url, setM3u8Url] = (0, _react.useState)(null);
  const m3u8FoundRef = (0, _react.useRef)(false);
  const autoExoLaunchedRef = (0, _react.useRef)(null);
  const pendingFailoverRef = (0, _react.useRef)(false);
  m3u8FoundRef.current = !!m3u8Url;
  const [interceptedSubs, setInterceptedSubs] = (0, _react.useState)([]);
  const [playerSource, setPlayerSource] = (0, _react.useState)(() => _storage.storage.get("playerSource") || _api.NON_ANIME_DEFAULT_SOURCE);
  const playerAccentColor = playerSettings?.accentColor ?? null;
  const playerSubLang = playerSettings?.subtitleLang ?? null;
  const progressViaFrames = (0, _react.useMemo)(() => (0, _api.sourceProgressViaFrames)(playerSource), [playerSource]);
  const [showSourceMenu, setShowSourceMenu] = (0, _react.useState)(false);
  const [dubMode, setDubMode] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.HIANIME_DUB_MODE) || "sub");
  const [anilistData, setAnilistData] = (0, _react.useState)(null);
  const [menuPos, setMenuPos] = (0, _react.useState)(null);
  const sourceRef = (0, _react.useRef)(null);
  const playerWrapRef = (0, _react.useRef)(null);
  const webviewRef = (0, _react.useRef)(null);
  const saveProgressRef = (0, _react.useRef)(saveProgress);
  saveProgressRef.current = saveProgress;
  const onMarkWatchedRef = (0, _react.useRef)(onMarkWatched);
  onMarkWatchedRef.current = onMarkWatched;
  const [resolvedPlayerUrl, setResolvedPlayerUrl] = (0, _react.useState)(null);
  const [resolvingUrl, setResolvingUrl] = (0, _react.useState)(false);
  const [resolveError, setResolveError] = (0, _react.useState)(null);
  const resolvingUrlRef = (0, _react.useRef)(false);
  const resolvedPlayerUrlRef = (0, _react.useRef)(null);
  const [collection, setCollection] = (0, _react.useState)(null);
  const [webviewLoading, setWebviewLoading] = (0, _react.useState)(false);
  const srcId = (0, _useSourceId.useSourceId)(playerSource, "movie", item.id, apiKey);
  (0, _react.useEffect)(() => {
    if (srcId.id && playing) setWebviewLoading(true);
  }, [srcId.id]);
  const [playerFullscreen, setPlayerFullscreen] = (0, _react.useState)(false);
  const togglePlayerFullscreen = (0, _react.useCallback)(forceState => {
    setPlayerFullscreen(prev => {
      const next = typeof forceState === "boolean" ? forceState : !prev;
      if (next) {
        document.documentElement.setAttribute("data-player-fullscreen", "1");
        try {
          window.AndroidBridge?.setImmersiveMode?.(true);
        } catch {}
      } else {
        document.documentElement.removeAttribute("data-player-fullscreen");
      }
      return next;
    });
  }, []);
  (0, _react.useEffect)(() => {
    window.__streambertExitFullscreen = () => {
      setPlaying(false);
      setPlayerFullscreen(false);
      document.documentElement.removeAttribute("data-player-fullscreen");
    };
    return () => {
      if (window.__streambertExitFullscreen) delete window.__streambertExitFullscreen;
      document.documentElement.removeAttribute("data-player-fullscreen");
    };
  }, [togglePlayerFullscreen]);
  const [pipOpen, setPipOpen] = (0, _react.useState)(false);
  const pipUrlRef = (0, _react.useRef)(null);
  const pipWebContentsIdRef = (0, _react.useRef)(null);
  const isAnime = (0, _react.useMemo)(() => (0, _api.isAnimeContent)(item, details), [item.id, details]);
  const playerDirectUrl = (0, _react.useMemo)(() => {
    if (isAnime && (0, _api.sourceSupportsAnime)(playerSource) && anilistData?.id) {
      const animeUrl = (0, _api.getAnimeSourceUrl)(playerSource, anilistData.id, 1, dubMode);
      if (animeUrl) return animeUrl;
    }
    return (0, _api.getSourceUrl)(playerSource, "movie", srcId.id, null, null, {}, playerAccentColor, playerSubLang);
  }, [isAnime, playerSource, anilistData, dubMode, srcId.id, playerAccentColor, playerSubLang]);
  const [downloaderFolder, setDownloaderFolder] = (0, _react.useState)(() => _storage.storage.get("downloaderFolder") || "");
  const {
    sessionTotal: blockedSession,
    alltimeTotal: blockedAlltime,
    showModal: showBlockedModal,
    setShowModal: setShowBlockedModal,
    getSessionDomains: getBlockedDomains
  } = (0, _useBlockedStats.useBlockedStats)(item.id);
  const [rating, setRating] = (0, _react.useState)({
    cert: null,
    minAge: null
  });
  const ageLimitSetting = (0, _react.useMemo)(() => (0, _ageRating.getAgeLimitSetting)(_storage.storage), []);
  const ratingCountry = (0, _react.useMemo)(() => (0, _ageRating.getRatingCountry)(_storage.storage), []);
  const restricted = (0, _ageRating.isRestricted)(rating.minAge, ageLimitSetting);
  const progressKey = `movie_${item.id}`;
  const pct = progress[progressKey] || 0;
  const isWatched = !!watched?.[progressKey];
  const hasProgress = pct > 0;
  const d = details || item;
  const title = d.title || d.name;
  const year = (d.release_date || "").slice(0, 4);
  const mediaName = `${title}${year ? " (" + year + ")" : ""}`;
  const {
    watchedSecs,
    totalSecs,
    displayPct,
    progressLabel
  } = (0, _react.useMemo)(() => {
    const watchedSecs = _storage.storage.get("dlTime_" + progressKey) || 0;
    const totalSecs = d?.runtime ? d.runtime * 60 : 0;
    const derivedPct = watchedSecs > 0 && totalSecs > 0 ? Math.floor(watchedSecs / totalSecs * 100) : 0;
    const displayPct = pct > 0 ? pct : derivedPct;
    const fmt = s => {
      const h = Math.floor(s / 3600);
      const m = Math.floor(s % 3600 / 60);
      const sec = Math.floor(s % 60);
      return h > 0 ? `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}` : `${m}:${String(sec).padStart(2, "0")}`;
    };
    const progressLabel = watchedSecs > 0 && totalSecs > 0 ? `${fmt(watchedSecs)} / ${fmt(totalSecs)}` : watchedSecs > 0 ? fmt(watchedSecs) : displayPct > 0 ? `${displayPct}%` : null;
    return {
      watchedSecs,
      totalSecs,
      displayPct,
      progressLabel
    };
  }, [progressKey, pct, d?.runtime]);
  const [watchedThreshold] = (0, _react.useState)(() => _storage.storage.get("watchedThreshold") ?? 20);
  const autoMarkedRef = (0, _react.useRef)(false);
  const autoPlayTriggeredRef = (0, _react.useRef)(null);
  const lastKnownTimeRef = (0, _react.useRef)(0);
  const seekBackCooldownRef = (0, _react.useRef)(0);
  (0, _react.useEffect)(() => {
    let mounted = true;
    (0, _api.tmdbFetch)(`/movie/${item.id}`, apiKey).then(d => {
      if (mounted) setDetails(d);
    }).catch(() => {
      if (mounted) setDetails(item);
    });
    return () => {
      mounted = false;
    };
  }, [item.id, apiKey]);
  (0, _react.useEffect)(() => {
    let mounted = true;
    (0, _ageRating.fetchMovieRating)(item.id, apiKey, ratingCountry).then(r => {
      if (mounted) setRating(r);
    });
    return () => {
      mounted = false;
    };
  }, [item.id, apiKey, ratingCountry]);
  (0, _react.useEffect)(() => {
    let mounted = true;
    (0, _api.tmdbFetch)(`/movie/${item.id}/videos`, apiKey).then(data => {
      if (!mounted) return;
      const videos = data.results || [];
      const trailer = videos.find(v => v.type === "Trailer" && v.site === "YouTube") || videos.find(v => v.site === "YouTube");
      if (trailer) setTrailerKey(trailer.key);
    }).catch(() => {});
    return () => {
      mounted = false;
    };
  }, [item.id, apiKey]);
  (0, _react.useEffect)(() => {
    setCollection(null);
    if (!details?.belongs_to_collection?.id) return;
    let mounted = true;
    (0, _api.tmdbFetch)(`/collection/${details.belongs_to_collection.id}`, apiKey).then(data => {
      if (!mounted) return;
      const parts = (data.parts || []).map(p => ({
        ...p,
        media_type: "movie"
      })).sort((a, b) => (a.release_date || "").localeCompare(b.release_date || ""));
      if (parts.length > 1) {
        setCollection({
          name: data.name,
          parts
        });
      }
    }).catch(() => {});
    return () => {
      mounted = false;
    };
  }, [details?.belongs_to_collection?.id, apiKey]);
  (0, _react.useEffect)(() => {
    setM3u8Url(null);
    setInterceptedSubs([]);
    setShowSourceMenu(false);
    setAnilistData(null);
    resolvedPlayerUrlRef.current = null;
    setResolvedPlayerUrl(null);
    resolvingUrlRef.current = false;
    setResolvingUrl(false);
    setResolveError(null);
    setWebviewLoading(true);
  }, [item.id, playerSource, dubMode]);
  (0, _react.useEffect)(() => {
    let mounted = true;
    if (isAnime) {
      (0, _api.fetchAnilistData)(item.title || item.name, "ANIME", item.id).then(data => {
        if (mounted && data) setAnilistData(data);
      });
      if (!(0, _api.sourceIsAnimeCapable)(playerSource)) {
        const saved = _storage.storage.get("playerSource");
        setPlayerSource((0, _api.sourceIsAnimeCapable)(saved) ? saved : _api.ANIME_DEFAULT_SOURCE);
      }
    } else {
      const currentSrc = _api.PLAYER_SOURCES.find(s => s.id === playerSource);
      if (currentSrc?.tag === "ANIME") {
        const saved = _storage.storage.get("playerSource");
        const savedSrc = _api.PLAYER_SOURCES.find(s => s.id === saved);
        setPlayerSource(savedSrc?.tag !== "ANIME" ? saved : _api.NON_ANIME_DEFAULT_SOURCE);
      }
    }
    return () => {
      mounted = false;
    };
  }, [item.id, isAnime]);
  (0, _react.useEffect)(() => {
    if (!playing) return;
    const epKey = `movie_${item.id}_${dubMode}`;
    if ((0, _api.sourceIsAsync)(playerSource)) {
      const cached = (0, _storage.getFailoverSource)(epKey);
      if (cached && cached !== playerSource) {
        setM3u8Url(null);
        setInterceptedSubs([]);
        resolvedPlayerUrlRef.current = null;
        setResolvedPlayerUrl(null);
        resolvingUrlRef.current = false;
        setResolvingUrl(false);
        setResolveError(null);
        setPlayerSource(cached);
        return;
      }
    }
    if (!(0, _api.sourceIsAsync)(playerSource)) return;
    if (resolvedPlayerUrlRef.current || resolvingUrlRef.current) return;
    resolvingUrlRef.current = true;
    setResolvingUrl(true);
    setResolveError(null);
    const startTime = _storage.storage.get("dlTime_" + progressKey) || 0;
    let mounted = true;
    window.electron.resolveHiAnime({
      title,
      seasonNumber: 1,
      episodeNumber: 1,
      isMovie: true,
      translationType: dubMode
    }).then(res => {
      if (!mounted) return;
      if (res?.ok && res.url) {
        (0, _storage.clearFailoverSource)(epKey);
        if (res.isDirectMp4 !== undefined) {
          window.electron.setPlayerVideo({
            url: res.url,
            referer: res.referer || "https://hianime.at/",
            subtitle: res.subtitle || null,
            startTime
          }).then(r => {
            if (!mounted) return;
            resolvedPlayerUrlRef.current = r.playerUrl;
            setResolvedPlayerUrl(r.playerUrl);
            setM3u8Url(res.url);
          }).catch(() => {
            if (mounted) setResolveError("Failed to start local player");
          });
        } else {
          resolvedPlayerUrlRef.current = res.url;
          setResolvedPlayerUrl(res.url);
        }
      } else {
        const next = (0, _api.getNextNonAsyncSource)(playerSource);
        if (next) {
          (0, _storage.setFailoverSource)(epKey, next);
          setM3u8Url(null);
          setInterceptedSubs([]);
          resolvedPlayerUrlRef.current = null;
          setResolvedPlayerUrl(null);
          setResolveError(null);
          setPlayerSource(next);
        } else {
          setResolveError(res?.error || "Movie not found on HiAnime");
        }
      }
    }).catch(e => {
      if (mounted) setResolveError(e.message || "Error");
    }).finally(() => {
      if (mounted) {
        resolvingUrlRef.current = false;
        setResolvingUrl(false);
      }
    });
    return () => {
      mounted = false;
    };
  }, [playing, playerSource, dubMode]);
  (0, _react.useEffect)(() => {
    if (!window.electron) return;
    const handler = window.electron.onM3u8Found(url => {
      setM3u8Url(prev => prev !== url ? url : prev);
    });
    return () => window.electron.offM3u8Found(handler);
  }, []);
  (0, _react.useEffect)(() => {
    if (!playing || m3u8Url) return;
    const switchNext = () => {
      if (m3u8FoundRef.current) return;
      const order = ["vidlink", "videasy", "vidsrccc", "vidsrcxyz", "vidsrcme", "vidsrcnet", "vidsrcin", "vidsrcpm", "vidsrc", "vidsrcicu", "vidfast", "vidnest", "vidlove", "autoembed", "embedsu", "smashy", "multiembed", "superembed", "twoembed", "moviesapi", "nontongo"];
      const idx = order.indexOf(playerSource);
      const nextSrc = order[(idx + 1) % order.length];
      try {
        if (webviewRef.current) webviewRef.current.src = "about:blank";
      } catch {}
      if (nextSrc && nextSrc !== playerSource) {
        setPlayerSource(nextSrc);
      }
    };
    const chHandler = window.electron?.onServerChallenge?.(() => switchNext());
    const t = setTimeout(switchNext, 4200);
    return () => {
      clearTimeout(t);
      if (chHandler) window.electron?.offServerChallenge?.(chHandler);
    };
  }, [playing, m3u8Url, playerSource]);
  (0, _react.useEffect)(() => {
    const h = window.electron?.onNeedNextServer?.(data => {
      const cur = data?.currentSource || playerSource;
      const order = ["vidlink", "videasy", "vidsrccc", "vidsrcxyz", "vidsrcme", "vidsrcnet", "vidsrcin", "vidsrcpm", "vidsrc", "vidsrcicu", "vidfast", "vidnest", "vidlove", "autoembed", "embedsu", "smashy", "multiembed", "superembed", "twoembed", "moviesapi", "nontongo"];
      const idx = order.indexOf(cur);
      const nextSrc = order[(idx + 1) % order.length];
      pendingFailoverRef.current = true;
      setM3u8Url(null);
      setPlaying(true);
      try {
        if (webviewRef.current) webviewRef.current.src = "about:blank";
      } catch {}
      if (nextSrc) setPlayerSource(nextSrc);
    });
    return () => {
      if (h) window.electron?.offNeedNextServer?.(h);
    };
  }, [playerSource]);
  (0, _react.useEffect)(() => {
    if (!playing || !m3u8Url) return;
    if (pendingDownload) {
      setPendingDownload(false);
      setPlaying(false);
      setShowDownload(true);
      return;
    }
    const launchKey = `movie_${item.id}_${playerSource}`;
    if (!pendingFailoverRef.current && autoExoLaunchedRef.current === launchKey) return;
    const timer = setTimeout(() => {
      autoExoLaunchedRef.current = launchKey;
      if (window.AndroidBridge?.openExoPlayer) {
        if (pendingFailoverRef.current) {
          pendingFailoverRef.current = false;
          window.AndroidBridge?.deliverNextServerStream?.(m3u8Url, playerSource);
          return;
        }
        const startSec = isWatched || pct >= 90 ? 0 : _storage.storage.get("dlTime_" + progressKey) || 0;
        const payload = {
          url: m3u8Url,
          title: mediaName || title,
          currentSource: playerSource,
          startTimeSec: startSec,
          subtitles: interceptedSubs,
          progressKey: progressKey,
          imdbId: item.imdb_id || item.id,
          mediaType: "movie",
          subTextColor: _storage.storage.get("subtitleTextColor") || "#FFFFFF",
          subBgStyle: _storage.storage.get("subtitleBgStyle") || "dark",
          subFontSizeSp: Number(_storage.storage.get("subtitleFontSizeSp") || 22),
          preferredSubLang: playerSubLang || "ar"
        };
        try {
          if (webviewRef.current) webviewRef.current.src = "about:blank";
        } catch {}
        window.AndroidBridge.openExoPlayer(JSON.stringify(payload));
        setPlaying(false);
        setPlayerFullscreen(false);
        document.documentElement.removeAttribute("data-player-fullscreen");
      }
    }, 300);
    return () => clearTimeout(timer);
  }, [playing, m3u8Url, item.id, playerSource, pendingDownload]);
  (0, _react.useEffect)(() => {
    if (!showSourceMenu) return;
    const close = () => setShowSourceMenu(false);
    window.addEventListener("scroll", close, {
      capture: true,
      passive: true
    });
    const handleClick = e => {
      if (sourceRef.current?.contains(e.target) || e.target.closest(".source-dropdown")) return;
      close();
    };
    document.addEventListener("mousedown", handleClick);
    return () => {
      window.removeEventListener("scroll", close, {
        capture: true
      });
      document.removeEventListener("mousedown", handleClick);
    };
  }, [showSourceMenu]);
  (0, _react.useEffect)(() => {
    if (!window.electron) return;
    const handler = window.electron.onSubtitleFound(({
      url,
      lang
    }) => {
      if (!url || !url.toLowerCase().includes(".vtt")) return;
      setInterceptedSubs(prev => {
        const filtered = prev.filter(s => s.lang !== lang);
        return [...filtered, {
          url,
          lang: lang || "unknown"
        }];
      });
    });
    return () => window.electron.offSubtitleFound(handler);
  }, []);
  (0, _react.useEffect)(() => {
    autoMarkedRef.current = false;
    lastKnownTimeRef.current = 0;
    seekBackCooldownRef.current = 0;
  }, [item.id, isWatched]);
  (0, _react.useEffect)(() => {
    if (playing) setWebviewLoading(true);
    try {
      window.AndroidBridge?.setImmersiveMode?.(!!playing);
    } catch {}
  }, [playing]);
  (0, _react.useLayoutEffect)(() => {
    if (playing) return;
    const wv = webviewRef.current;
    if (wv) {
      try {
        wv.src = "about:blank";
      } catch {}
    }
  }, [playing]);
  (0, _react.useEffect)(() => {
    return () => {
      window.electron?.playerStopped?.();
    };
  }, []);
  const [gamepadEnabled, setGamepadEnabled] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.GAMEPAD_ENABLED) !== false);
  (0, _react.useEffect)(() => {
    const handler = () => setGamepadEnabled(_storage.storage.get(_storage.STORAGE_KEYS.GAMEPAD_ENABLED) !== false);
    window.addEventListener("streambert:gamepad-settings-changed", handler);
    return () => window.removeEventListener("streambert:gamepad-settings-changed", handler);
  }, []);
  (0, _react.useEffect)(() => {
    (0, _gamepadPlayerState.setPlayerGamepadActive)(gamepadEnabled && playing);
    return () => (0, _gamepadPlayerState.setPlayerGamepadActive)(false);
  }, [playing, gamepadEnabled]);
  (0, _react.useEffect)(() => {
    const wv = webviewRef.current;
    if (!wv || !playing || !gamepadEnabled) return;
    const inject = () => {
      wv.executeJavaScript(_playerGamepadScript.GAMEPAD_PLAYER_SCRIPT).catch(() => {});
    };
    wv.addEventListener("dom-ready", inject);
    try {
      inject();
    } catch {}
    const exitPoll = setInterval(async () => {
      try {
        const requested = await wv.executeJavaScript(_playerGamepadScript.GAMEPAD_EXIT_CHECK_JS);
        if (requested) {
          wv.executeJavaScript(_playerGamepadScript.GAMEPAD_EXIT_RESET_JS).catch(() => {});
          setPlaying(false);
        }
      } catch {}
    }, 250);
    return () => {
      wv.removeEventListener("dom-ready", inject);
      clearInterval(exitPoll);
      try {
        wv.executeJavaScript(_playerGamepadScript.GAMEPAD_CLEANUP_JS);
      } catch {}
    };
  }, [playing, gamepadEnabled, playerSource]);
  (0, _react.useEffect)(() => {
    if (!playing) return;
    const wv = webviewRef.current;
    if (!wv) return;
    const done = () => {
      setWebviewLoading(false);
      playerWrapRef.current?.scrollIntoView({
        behavior: "auto",
        block: "center"
      });
      setTimeout(() => {
        if (!m3u8FoundRef.current) tapCenterOfPlayer();
      }, 1400);
      setTimeout(() => {
        if (!m3u8FoundRef.current) tapCenterOfPlayer();
      }, 2800);
    };
    wv.addEventListener("did-finish-load", done);
    wv.addEventListener("did-fail-load", done);
    return () => {
      wv.removeEventListener("did-finish-load", done);
      wv.removeEventListener("did-fail-load", done);
    };
  }, [playing, playerSource, item.id]);
  (0, _react.useEffect)(() => {
    if (!playing || !(0, _api.sourceSupportsProgress)(playerSource)) return;
    let interval = null;
    const timer = setTimeout(() => {
      interval = setInterval(async () => {
        try {
          const wv = webviewRef.current;
          if (!wv) return;
          let result;
          if (pipWebContentsIdRef.current != null && window.electron?.queryVideoProgress) {
            result = await window.electron.queryVideoProgress(pipWebContentsIdRef.current);
          } else if (progressViaFrames && window.electron?.queryVideoProgress) {
            result = await window.electron.queryVideoProgress(wv.getWebContentsId());
          } else {
            result = await wv.executeJavaScript(`
              (() => {
                const v = document.querySelector('video')
                if (!v || !v.duration || v.duration === Infinity || v.paused) return null
                // Re-attach seek tracker if video element was recreated (e.g. quality change)
                if (!v._seekTracked) {
                  v._seekTracked = true
                  v.addEventListener('seeked', () => {
                    v._lastUserSeek = Date.now()
                    v._lastUserSeekTo = v.currentTime
                  })
                }
                return {
                  currentTime: v.currentTime,
                  duration: v.duration,
                  recentUserSeek: v._lastUserSeek ? (Date.now() - v._lastUserSeek < 6000) : false,
                  lastUserSeekTo: v._lastUserSeekTo ?? null,
                }
              })()
            `);
          }
          if (result && result.duration > 0) {
            const ct = result.currentTime;
            const now = Date.now();
            if (!(0, _api.sourceSkipsResetGuard)(playerSource) && lastKnownTimeRef.current > 30 && ct <= 5 && !result.recentUserSeek) {
              if (now > seekBackCooldownRef.current) {
                const seekTo = lastKnownTimeRef.current;
                seekBackCooldownRef.current = now + 8000;
                try {
                  await wv.executeJavaScript(`
                    (() => {
                      const v = document.querySelector('video')
                      if (v) v.currentTime = ${seekTo}
                    })()
                  `);
                } catch {}
              }
              return;
            }
            if (result.recentUserSeek && result.lastUserSeekTo !== null) {
              lastKnownTimeRef.current = result.lastUserSeekTo;
            } else {
              lastKnownTimeRef.current = ct;
            }
            const p = Math.floor(ct / result.duration * 100);
            saveProgressRef.current(progressKey, Math.min(p, 100));
            _storage.storage.set("dlTime_" + progressKey, Math.floor(ct));
            const remaining = result.duration - ct;
            if (!autoMarkedRef.current && remaining <= watchedThreshold && remaining >= 0) {
              autoMarkedRef.current = true;
              onMarkWatchedRef.current?.(progressKey);
            }
          }
        } catch {}
      }, 5000);
    }, 3000);
    return () => {
      clearTimeout(timer);
      clearInterval(interval);
    };
  }, [playing, progressKey, watchedThreshold, playerSource, progressViaFrames]);
  const tapCenterOfPlayer = (0, _react.useCallback)(() => {
    try {
      const el = playerWrapRef.current;
      if (!el || !window.AndroidBridge?.tapPlayerCenter) return;
      const r = el.getBoundingClientRect();
      if (r.width <= 0 || r.height <= 0) return;
      const rx = (r.left + r.width / 2) / Math.max(1, window.innerWidth);
      const ry = (r.top + r.height / 2) / Math.max(1, window.innerHeight);
      if (ry > 0.05 && ry < 0.95) {
        window.AndroidBridge.tapPlayerCenter(rx, ry);
      }
    } catch {}
  }, []);
  const handlePlay = (0, _react.useCallback)(() => {
    autoExoLaunchedRef.current = null;
    setM3u8Url(null);
    setInterceptedSubs([]);
    setPlaying(true);
    onHistory({
      ...d,
      media_type: "movie"
    });
    setTimeout(() => {
      playerWrapRef.current?.scrollIntoView({
        behavior: "smooth",
        block: "center"
      });
    }, 100);
  }, [d, onHistory]);
  (0, _react.useEffect)(() => {
    if (!playing) return;
    if (!_api.NEEDS_INTERCEPT.includes(playerSource)) return;
    const enterH = window.electron?.onWebviewEnterFullscreen?.(() => {
      setPlayerFullscreen(true);
      document.documentElement.setAttribute("data-player-fullscreen", "1");
    });
    const leaveH = window.electron?.onWebviewLeaveFullscreen?.(() => {
      setPlayerFullscreen(false);
      document.documentElement.removeAttribute("data-player-fullscreen");
      if (document.fullscreenElement) document.exitFullscreen?.();
    });
    return () => {
      if (enterH) window.electron?.offWebviewEnterFullscreen?.(enterH);
      if (leaveH) window.electron?.offWebviewLeaveFullscreen?.(leaveH);
      document.documentElement.removeAttribute("data-player-fullscreen");
    };
  }, [playing, playerSource]);
  (0, _react.useEffect)(() => {
    if (!playing) return;
    const openH = window.electron?.onPipOpened?.(async () => {
      setPipOpen(true);
      pipWebContentsIdRef.current = (await window.electron.getPipWebContentsId?.()) ?? null;
    });
    const closeH = window.electron?.onPipClosed?.(() => {
      pipUrlRef.current = null;
      pipWebContentsIdRef.current = null;
      setPipOpen(false);
    });
    return () => {
      if (openH) window.electron?.offPipOpened?.(openH);
      if (closeH) window.electron?.offPipClosed?.(closeH);
    };
  }, [playing]);
  const handleSetDownloaderFolder = (0, _react.useCallback)(folder => {
    setDownloaderFolder(folder);
    _storage.storage.set("downloaderFolder", folder);
  }, []);
  const displayOverview = isAnime && anilistData?.description ? (0, _api.cleanAnilistDescription)(anilistData.description) : d.overview;
  const displayScore = isAnime && anilistData?.averageScore ? (anilistData.averageScore / 10).toFixed(1) : d.vote_average > 0 ? d.vote_average.toFixed(1) : null;
  const displayGenres = isAnime && anilistData?.genres?.length ? anilistData.genres.map((g, i) => ({
    id: i,
    name: g
  })) : d.genres || [];
  const isUnreleased = (0, _react.useMemo)(() => {
    if (!d.release_date) return false;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return new Date(d.release_date) > today;
  }, [d.release_date]);
  const movieDownload = (downloads || []).find(dl => dl.mediaType === "movie" && (dl.tmdbId === item.id || dl.mediaId === item.id) && (dl.status === "completed" || dl.status === "local" || dl.status === "downloading"));
  return React.createElement("div", {
    className: "fade-in"
  }, React.createElement("div", {
    className: "detail-hero"
  }, React.createElement("div", {
    className: "detail-bg",
    style: {
      backgroundImage: `url(${(0, _api.imgUrl)(d.backdrop_path, "w1280")})`
    }
  }), React.createElement("div", {
    className: "detail-gradient"
  }), React.createElement("div", {
    className: "detail-content"
  }, React.createElement("div", {
    className: "detail-poster",
    style: {
      position: "relative"
    }
  }, d.poster_path ? React.createElement("img", {
    src: (0, _api.imgUrl)(d.poster_path),
    alt: title,
    loading: "lazy"
  }) : React.createElement("div", {
    style: {
      width: "100%",
      height: "100%",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: "var(--text3)"
    }
  }, React.createElement(_Icons.FilmIcon, null)), isWatched && React.createElement("div", {
    className: "detail-watched-badge"
  }, React.createElement(_Icons.WatchedIcon, {
    size: 36
  }))), React.createElement("div", {
    className: "detail-info"
  }, React.createElement("div", {
    className: "detail-type"
  }, "Movie"), React.createElement("div", {
    className: "detail-title"
  }, title), React.createElement("div", {
    className: "genres"
  }, displayGenres.map(g => React.createElement("span", {
    key: g.id,
    className: "genre-tag"
  }, g.name))), React.createElement("div", {
    className: "detail-meta"
  }, displayScore && React.createElement("span", {
    className: "detail-rating"
  }, React.createElement(_Icons.StarIcon, null), " ", displayScore), year && React.createElement("span", null, year), d.runtime && React.createElement("span", null, d.runtime, " min"), d.original_language && React.createElement("span", null, d.original_language?.toUpperCase())), rating.cert && React.createElement("div", {
    className: `age-rating-pill${restricted ? " age-rating-pill--restricted" : ""}`
  }, restricted ? React.createElement(_Icons.RatingLockIcon, _Icons.AlertIcon, {
    size: 13
  }) : React.createElement(_Icons.RatingShieldIcon, {
    size: 13
  }), React.createElement("span", {
    className: "age-rating-pill-cert"
  }, rating.cert), restricted && React.createElement("span", {
    className: "age-rating-pill-label"
  }, "Inappropriate for your age setting")), React.createElement("p", {
    className: "detail-overview"
  }, displayOverview), !isWatched && displayPct > 0 && React.createElement("div", {
    className: "progress-bar-row",
    style: {
      marginBottom: 12
    }
  }, React.createElement("div", {
    className: "progress-bar-outer"
  }, React.createElement("div", {
    className: "progress-bar-fill",
    style: {
      width: `${Math.min(displayPct, 100)}%`
    }
  })), React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, progressLabel)), React.createElement("div", {
    className: "detail-actions"
  }, isUnreleased ? React.createElement("button", {
    className: "btn btn-primary btn-restricted",
    disabled: true,
    title: "This movie has not been released yet"
  }, React.createElement(_Icons.RatingLockIcon, {
    size: 14
  }), " Unreleased") : restricted ? React.createElement("button", {
    className: "btn btn-primary btn-restricted",
    disabled: true,
    title: "Inappropriate for your age rating setting"
  }, React.createElement(_Icons.RatingLockIcon, {
    size: 14
  }), " Restricted") : React.createElement("button", {
    className: "btn btn-primary",
    onClick: handlePlay
  }, React.createElement(_Icons.PlayIcon, null), " ", (() => {
    const savedSec = Number(_storage.storage.get("dlTime_" + progressKey) || 0);
    if (savedSec > 5 && !isWatched) {
      const h = Math.floor(savedSec / 3600);
      const m = Math.floor(savedSec % 3600 / 60);
      const s = Math.floor(savedSec % 60);
      const t = h > 0 ? `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}` : `${m}:${String(s).padStart(2, "0")}`;
      return `Continue ${t}`;
    }
    return playing ? "Loading..." : "Play";
  })()), trailerKey && (restricted ? React.createElement("button", {
    className: "btn btn-secondary btn-restricted",
    disabled: true,
    title: "Inappropriate for your age rating setting"
  }, React.createElement(_Icons.RatingLockIcon, {
    size: 14
  }), " Trailer") : React.createElement("button", {
    className: "btn btn-secondary",
    onClick: () => setShowTrailer(true)
  }, React.createElement(_Icons.TrailerIcon, null), " Trailer")), React.createElement("button", {
    className: "btn btn-secondary",
    onClick: () => movieDownload ? onGoToDownloads?.(movieDownload.id) : setShowDownloadConfirm(true)
  }, React.createElement(_Icons.DownloadIcon, null), " ", movieDownload ? movieDownload.status === "downloading" ? "Downloading…" : "Downloaded" : pendingDownload ? "Preparing…" : "Download"), React.createElement("button", {
    className: "btn btn-secondary",
    onClick: onSave
  }, isSaved ? React.createElement(_Icons.BookmarkFillIcon, null) : React.createElement(_Icons.BookmarkIcon, null), isSaved ? "Saved" : "Save"), React.createElement("button", {
    className: "btn btn-ghost",
    onClick: onBack
  }, React.createElement(_Icons.BackIcon, null), " Back"))))), playing && !restricted && !isUnreleased && React.createElement("div", {
    className: "section"
  }, React.createElement("div", {
    className: "player-wrap player-wrap--fullscreen player-wrap--silent-exo",
    ref: playerWrapRef
  }, webviewLoading && !resolveError && React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 10,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      background: "rgba(0,0,0,0.75)",
      pointerEvents: "none",
      gap: 14,
      borderRadius: "inherit"
    }
  }, (0, _api.sourceIsAsync)(playerSource) ? React.createElement(_HiAnimeLoader.default, {
    what: "movie",
    playerStarting: !resolvingUrl && !!resolvedPlayerUrl
  }) : React.createElement(React.Fragment, null, React.createElement("div", {
    className: "spinner"
  }), React.createElement("span", {
    style: {
      fontSize: 14,
      color: "var(--text2)"
    }
  }, `Loading ${_api.PLAYER_SOURCES.find(s => s.id === playerSource)?.label ?? "source"}…`))), (0, _api.sourceIsAsync)(playerSource) && resolveError && !resolvingUrl && React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 10,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      background: "rgba(0,0,0,0.85)",
      gap: 10,
      borderRadius: "inherit"
    }
  }, React.createElement("span", {
    style: {
      fontSize: 28
    }
  }, React.createElement(_Icons.AlertIcon, {
    size: 28
  })), React.createElement("span", {
    style: {
      fontSize: 14,
      color: "var(--text2)"
    }
  }, "Movie not found on HiAnime"), React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, resolveError), React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, "Try a different source, or switch sub/dub.")), srcId.error && React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 11,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      background: "rgba(0,0,0,0.85)",
      gap: 10,
      borderRadius: "inherit"
    }
  }, React.createElement("span", {
    style: {
      fontSize: 28
    }
  }, React.createElement(_Icons.AlertIcon, {
    size: 28
  })), React.createElement("span", {
    style: {
      fontSize: 14,
      color: "var(--text2)"
    }
  }, "Could not resolve the ", srcId.idLabel, " for this title"), React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, srcId.error, ". Try a different source.")), pipOpen && React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 20,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      background: "rgba(0,0,0,0.92)",
      gap: 16,
      borderRadius: "inherit"
    }
  }, React.createElement(_Icons.PopOutIcon, {
    size: 36
  }), React.createElement("span", {
    style: {
      fontSize: 15,
      color: "var(--text1)",
      fontWeight: 600
    }
  }, "Playing in pop-out window"), React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text2)",
      textAlign: "center",
      maxWidth: 260
    }
  }, "Closing the pop-out will reload the player here."), React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => window.electron?.closePipWindow?.(),
    style: {
      marginTop: 4
    }
  }, "Close pop-out & return")), React.createElement(_StreamPlayerFrame.default, {
    ref: webviewRef,
    key: (0, _api.sourceUsesCleanUa)(playerSource) ? "ua-clean" : "ua-default",
    useragent: (0, _api.sourceUsesCleanUa)(playerSource) ? _api.CLEAN_USER_AGENT : undefined,
    src: pipOpen ? "about:blank" : (0, _api.sourceIsAsync)(playerSource) ? resolvedPlayerUrl || "about:blank" : playerDirectUrl || "about:blank",
    partition: "persist:player",
    allowpopups: "false",
    sandbox: "allow-scripts allow-same-origin allow-forms",
    style: {
      position: "absolute",
      inset: 0,
      width: "100%",
      height: "100%",
      border: "none",
      visibility: (0, _api.sourceIsAsync)(playerSource) && !resolvedPlayerUrl ? "hidden" : "visible"
    }
  }), React.createElement("div", {
    className: "player-overlay-group"
  }, React.createElement("button", {
    ref: sourceRef,
    className: "player-overlay-btn",
    onClick: () => {
      const rect = sourceRef.current?.getBoundingClientRect();
      if (rect) setMenuPos({
        top: rect.bottom + 6,
        left: rect.left
      });
      setShowSourceMenu(v => !v);
    },
    title: "Change source"
  }, React.createElement(_Icons.SourceIcon, null), _api.PLAYER_SOURCES.find(s => s.id === playerSource)?.label ?? "Source"), ((0, _api.sourceIsAsync)(playerSource) || isAnime && (0, _api.sourceSupportsAnime)(playerSource)) && React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => {
      const next = dubMode === "sub" ? "dub" : "sub";
      setDubMode(next);
      _storage.storage.set(_storage.STORAGE_KEYS.HIANIME_DUB_MODE, next);
      setM3u8Url(null);
      setInterceptedSubs([]);
      resolvedPlayerUrlRef.current = null;
      setResolvedPlayerUrl(null);
      resolvingUrlRef.current = false;
      setResolvingUrl(false);
      setResolveError(null);
    },
    title: "Toggle Sub/Dub"
  }, dubMode === "sub" ? "SUB" : "DUB"), React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => {
      setShowSourceMenu(false);
      setShowBlockedModal(true);
    },
    title: "Blocked ads & trackers"
  }, React.createElement(_Icons.ShieldBlockIcon, null), blockedSession > 0 && React.createElement("span", {
    className: "player-blocked-badge"
  }, blockedSession)), m3u8Url && React.createElement("button", {
    className: "player-overlay-btn",
    style: {
      background: "rgba(229,9,20,0.88)",
      borderColor: "var(--red)"
    },
    onClick: () => {
      const pk = typeof progressKey !== "undefined" ? progressKey : currentProgressKey;
      const startSec = isWatched || pct >= 90 ? 0 : _storage.storage.get("dlTime_" + pk) || 0;
      const payload = {
        url: m3u8Url,
        title: mediaName || title,
        currentSource: playerSource,
        startTimeSec: startSec,
        subtitles: interceptedSubs,
        progressKey: typeof progressKey !== "undefined" ? progressKey : currentProgressKey,
        imdbId: item.imdb_id || item.id,
        mediaType: "movie",
        subTextColor: _storage.storage.get("subtitleTextColor") || "#FFFFFF",
        subBgStyle: _storage.storage.get("subtitleBgStyle") || "dark",
        subFontSizeSp: Number(_storage.storage.get("subtitleFontSizeSp") || 22),
        preferredSubLang: playerSubLang || "ar"
      };
      if (window.AndroidBridge?.openExoPlayer) {
        window.AndroidBridge.openExoPlayer(JSON.stringify(payload));
        setPlaying(false);
        setPlayerFullscreen(false);
        document.documentElement.removeAttribute("data-player-fullscreen");
      } else {
        onOpenExoPlayer?.(payload);
      }
    },
    title: "Play stream in Native Media3 ExoPlayer"
  }, "\u25B6 ExoPlayer"), React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => tapCenterOfPlayer(),
    title: "Play / Pause"
  }, "\u23EF"), React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => {
      setPlaying(false);
      setPlayerFullscreen(false);
      document.documentElement.removeAttribute("data-player-fullscreen");
    },
    title: "Exit Player"
  }, "\u2715 Exit"), React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => {
      if (pipOpen) {
        window.electron?.closePipWindow?.();
        return;
      }
      const url = (0, _api.sourceIsAsync)(playerSource) ? resolvedPlayerUrl : playerDirectUrl;
      if (!url) return;
      pipUrlRef.current = url;
      window.electron?.openPipWindow?.(url, item.title, (0, _api.sourceUsesCleanUa)(playerSource) ? _api.CLEAN_USER_AGENT : null);
    },
    title: pipOpen ? "Close pop-out" : "Pop out player",
    disabled: !pipOpen && (webviewLoading || !!((0, _api.sourceIsAsync)(playerSource) && !resolvedPlayerUrl)),
    style: pipOpen ? {
      color: "var(--red)"
    } : undefined
  }, React.createElement(_Icons.PopOutIcon, null))), showSourceMenu && menuPos && React.createElement("div", {
    className: "source-dropdown source-dropdown--fixed",
    style: {
      top: menuPos.top,
      left: menuPos.left
    },
    onClick: e => e.stopPropagation()
  }, _api.PLAYER_SOURCES.map(src => React.createElement("button", {
    key: src.id,
    className: "source-dropdown__item" + (playerSource === src.id ? " source-dropdown__item--active" : ""),
    onClick: () => {
      setShowSourceMenu(false);
      if (src.id === playerSource) return;
      (0, _storage.clearFailoverSource)(`movie_${item.id}_${dubMode}`);
      setPlayerSource(src.id);
      _storage.storage.set(_storage.STORAGE_KEYS.PLAYER_SOURCE, src.id);
      setM3u8Url(null);
      setInterceptedSubs([]);
      resolvedPlayerUrlRef.current = null;
      setResolvedPlayerUrl(null);
      resolvingUrlRef.current = false;
      setResolvingUrl(false);
      setResolveError(null);
    }
  }, React.createElement("span", null, src.label), src.tag && React.createElement("span", {
    className: "source-dropdown__tag"
  }, src.tag), src.note && React.createElement("span", {
    className: "source-dropdown__note"
  }, src.note)))), React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => movieDownload ? onGoToDownloads?.(movieDownload.id) : (setShowSourceMenu(false), setShowDownload(true)),
    title: movieDownload ? movieDownload.status === "downloading" ? "Downloading… - view in Downloads" : "Already downloaded - view in Downloads" : "Download"
  }, movieDownload ? React.createElement("span", {
    className: "player-downloaded-icon",
    style: {
      color: movieDownload.status === "downloading" ? "var(--red)" : "#4caf50"
    }
  }, movieDownload.status === "downloading" ? "↓" : "✓") : React.createElement(_Icons.DownloadIcon, null), !movieDownload && m3u8Url && React.createElement("span", {
    className: "player-overlay-dot"
  }), !(0, _api.sourceSupportsProgress)(playerSource) && React.createElement("span", {
    className: "player-no-progress-hint",
    title: "No automatic progress tracking for this source"
  }, "\u26A0 no tracking"))), displayPct > 0 && React.createElement("div", {
    className: "progress-bar-row"
  }, React.createElement("div", {
    className: "progress-bar-outer"
  }, React.createElement("div", {
    className: "progress-bar-fill",
    style: {
      width: `${Math.min(displayPct, 100)}%`
    }
  })), React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, progressLabel))), collection && onSelect && React.createElement("div", {
    className: "section"
  }, React.createElement("div", {
    className: "section-title"
  }, collection.name), React.createElement("div", {
    className: "scroll-row"
  }, collection.parts.map(part => {
    const pk = `movie_${part.id}`;
    const isCurrent = part.id === item.id;
    return React.createElement(CollectionCard, {
      key: part.id,
      part: part,
      pk: pk,
      isCurrent: isCurrent,
      onSelect: onSelect,
      progress: progress[pk] || 0,
      watched: watched,
      onMarkWatched: onMarkWatched,
      onMarkUnwatched: onMarkUnwatched
    });
  }))), showTrailer && trailerKey && React.createElement(_TrailerModal.default, {
    trailerKey: trailerKey,
    title: title,
    onClose: () => setShowTrailer(false)
  }), showDownloadConfirm && React.createElement(_DownloadConfirmModal.default, {
    title: title,
    runtimeMin: d.runtime,
    episodeCount: 1,
    onCancel: () => setShowDownloadConfirm(false),
    onConfirm: () => {
      setShowDownloadConfirm(false);
      if (m3u8Url) {
        setShowDownload(true);
      } else {
        setPendingDownload(true);
        setM3u8Url(null);
        setPlaying(true);
      }
    }
  }), showBlockedModal && React.createElement(_BlockedStatsModal.default, {
    sessionDomains: getBlockedDomains(),
    sessionTotal: blockedSession,
    alltimeTotal: blockedAlltime,
    onClose: () => setShowBlockedModal(false)
  }), showDownload && React.createElement(_DownloadModal.default, {
    onClose: () => setShowDownload(false),
    m3u8Url: m3u8Url,
    subtitles: interceptedSubs,
    mediaName: mediaName,
    downloaderFolder: downloaderFolder,
    setDownloaderFolder: handleSetDownloaderFolder,
    onOpenSettings: onSettings,
    onDownloadStarted: onDownloadStarted,
    mediaId: item.id,
    mediaType: "movie",
    posterPath: d.poster_path,
    tmdbId: item.id
  }));
}
const CollectionCard = (0, _react.memo)(function CollectionCard({
  part,
  isCurrent,
  onSelect,
  progress,
  watched,
  onMarkWatched,
  onMarkUnwatched
}) {
  const handleClick = (0, _react.useCallback)(() => onSelect(part), [onSelect, part]);
  return React.createElement("div", {
    style: {
      opacity: isCurrent ? 0.5 : 1,
      pointerEvents: isCurrent ? "none" : "auto"
    }
  }, React.createElement(_MediaCard.default, {
    item: part,
    onClick: handleClick,
    progress: progress,
    watched: watched,
    onMarkWatched: onMarkWatched,
    onMarkUnwatched: onMarkUnwatched
  }));
});
},
"./pages/SettingsPage": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = SettingsPage;
var _react = require("react");
var _UpdateModal = _interopRequireDefault(require("../components/UpdateModal"));
var _storage = require("../utils/storage");
var _api = require("../utils/api");
var _appearance = require("../utils/appearance");
var _subtitles = require("../utils/subtitles");
var _TrailerModal = require("../components/TrailerModal");
var _ageRating = require("../utils/ageRating");
var _Icons = require("../components/Icons");
var _updates = require("../utils/updates");
var _homeLayout = require("../utils/homeLayout");
var _backup = require("../utils/backup");
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
function SettingsSelect({
  value,
  onChange,
  options,
  style
}) {
  const [open, setOpen] = (0, _react.useState)(false);
  const ref = (0, _react.useRef)(null);
  const selectedLabel = options.find(o => String(o.value) === String(value))?.label ?? value;
  (0, _react.useEffect)(() => {
    const handler = e => {
      if (ref.current && !ref.current.contains(e.target)) setOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);
  return React.createElement("div", {
    ref: ref,
    style: {
      position: "relative",
      display: "inline-block",
      ...style
    }
  }, React.createElement("button", {
    type: "button",
    onClick: () => setOpen(o => !o),
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 28,
      padding: "9px 14px",
      background: open ? "var(--surface3)" : "var(--surface2)",
      border: `1px solid ${open ? "var(--red)" : "var(--border)"}`,
      boxShadow: open ? "0 0 0 3px rgba(229,9,20,0.12)" : "none",
      borderRadius: 8,
      color: "var(--text)",
      fontFamily: "var(--font-body)",
      fontSize: 14,
      cursor: "pointer",
      whiteSpace: "nowrap",
      minWidth: 0,
      transition: "border-color 0.15s, background 0.15s, box-shadow 0.15s"
    },
    onMouseEnter: e => {
      if (!open) e.currentTarget.style.background = "var(--surface3)";
    },
    onMouseLeave: e => {
      if (!open) e.currentTarget.style.background = "var(--surface2)";
    }
  }, React.createElement("span", {
    style: {
      overflow: "hidden",
      textOverflow: "ellipsis"
    }
  }, selectedLabel), React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "var(--text3)",
    strokeWidth: "2.5",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      flexShrink: 0,
      transform: open ? "rotate(180deg)" : "rotate(0deg)",
      transition: "transform 0.2s"
    }
  }, React.createElement("polyline", {
    points: "6 9 12 15 18 9"
  }))), open && React.createElement("div", {
    className: "settings-select-menu",
    style: {
      position: "absolute",
      top: "calc(100% + 6px)",
      left: 0,
      zIndex: 999,
      background: "var(--surface3)",
      border: "1px solid var(--border)",
      borderRadius: 10,
      boxShadow: "0 12px 40px rgba(0,0,0,0.55)",
      minWidth: "100%",
      maxHeight: 280,
      overflowY: "auto",
      padding: "4px"
    }
  }, options.map(o => {
    const active = String(o.value) === String(value);
    return React.createElement("div", {
      key: o.value,
      className: "settings-select-option",
      role: "button",
      tabIndex: 0,
      onClick: e => {
        e.stopPropagation();
        onChange(o.value);
        setOpen(false);
      },
      onMouseDown: e => {
        e.stopPropagation();
        onChange(o.value);
        setOpen(false);
      },
      style: {
        padding: "8px 12px",
        fontSize: 14,
        borderRadius: 7,
        cursor: "pointer",
        color: active ? "var(--red)" : "var(--text)",
        background: active ? "rgba(229,9,20,0.10)" : "transparent",
        fontWeight: active ? 600 : 400,
        transition: "background 0.1s, color 0.1s",
        whiteSpace: "nowrap"
      },
      onMouseEnter: e => {
        if (!active) e.currentTarget.style.background = "rgba(255,255,255,0.06)";
      },
      onMouseLeave: e => {
        if (!active) e.currentTarget.style.background = "transparent";
      }
    }, o.label);
  })));
}
const AGE_LIMIT_OPTIONS = [{
  value: "",
  label: "No restriction"
}, {
  value: "0",
  label: "0 — All audiences (G / FSK 0)"
}, {
  value: "7",
  label: "7 — Family friendly (PG / FSK 6)"
}, {
  value: "12",
  label: "12 — Teens and up"
}, {
  value: "13",
  label: "13 — PG-13 and equivalent"
}, {
  value: "15",
  label: "15 — Older teens"
}, {
  value: "16",
  label: "16 — FSK 16 and equivalent"
}, {
  value: "17",
  label: "17 — R / 17+ and equivalent"
}, {
  value: "18",
  label: "18 — Adults only (NC-17 / FSK 18)"
}];
function ResetConfirmDialog({
  onConfirm,
  onCancel
}) {
  return React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      zIndex: 1000,
      background: "rgba(0,0,0,0.75)",
      backdropFilter: "blur(6px)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, React.createElement("div", {
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border)",
      borderRadius: 12,
      padding: "36px 40px",
      maxWidth: 460,
      width: "90%",
      boxShadow: "0 24px 64px rgba(0,0,0,0.6)"
    }
  }, React.createElement("div", {
    style: {
      width: 52,
      height: 52,
      borderRadius: "50%",
      background: "rgba(229,9,20,0.12)",
      border: "1px solid rgba(229,9,20,0.3)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      marginBottom: 20
    }
  }, React.createElement(_Icons.WarningIcon, {
    size: 24
  })), React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 26,
      letterSpacing: 1,
      marginBottom: 10
    }
  }, "RESET SINGULARITYTV?"), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text2)",
      lineHeight: 1.7,
      marginBottom: 28
    }
  }, "This will permanently delete all your settings, watch history, saved titles, progress data, and cached data. Your downloaded video files will", " ", React.createElement("span", {
    style: {
      color: "var(--text)",
      fontWeight: 600
    }
  }, "not"), " be deleted.", React.createElement("br", null), React.createElement("br", null), React.createElement("span", {
    style: {
      color: "var(--red)"
    }
  }, "This action cannot be undone.")), React.createElement("div", {
    style: {
      display: "flex",
      gap: 12
    }
  }, React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      flex: 1
    },
    onClick: onCancel
  }, "Cancel"), React.createElement("button", {
    className: "btn",
    style: {
      flex: 1,
      background: "var(--red)",
      color: "#fff",
      border: "none",
      fontWeight: 600
    },
    onClick: onConfirm
  }, "Yes, Reset Everything"))));
}
function ConfirmDialog({
  title,
  description,
  confirmLabel = "Confirm",
  onConfirm,
  onCancel
}) {
  return React.createElement("div", {
    style: {
      position: "fixed",
      inset: 0,
      zIndex: 1000,
      background: "rgba(0,0,0,0.75)",
      backdropFilter: "blur(6px)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, React.createElement("div", {
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border)",
      borderRadius: 12,
      padding: "36px 40px",
      maxWidth: 460,
      width: "90%",
      boxShadow: "0 24px 64px rgba(0,0,0,0.6)"
    }
  }, React.createElement("div", {
    style: {
      width: 52,
      height: 52,
      borderRadius: "50%",
      background: "rgba(229,9,20,0.12)",
      border: "1px solid rgba(229,9,20,0.3)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      marginBottom: 20
    }
  }, React.createElement(_Icons.WarningIcon, {
    size: 24
  })), React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 22,
      letterSpacing: 1,
      marginBottom: 10
    }
  }, title), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text2)",
      lineHeight: 1.7,
      marginBottom: 28
    }
  }, description, React.createElement("br", null), React.createElement("br", null), React.createElement("span", {
    style: {
      color: "var(--red)"
    }
  }, "This action cannot be undone.")), React.createElement("div", {
    style: {
      display: "flex",
      gap: 12
    }
  }, React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      flex: 1
    },
    onClick: onCancel
  }, "Cancel"), React.createElement("button", {
    className: "btn",
    style: {
      flex: 1,
      background: "var(--red)",
      color: "#fff",
      border: "none",
      fontWeight: 600
    },
    onClick: onConfirm
  }, confirmLabel))));
}
function Toggle({
  value,
  onChange,
  title
}) {
  return React.createElement("button", {
    onClick: () => onChange(!value),
    title: title,
    style: {
      background: value ? "var(--red)" : "var(--surface2)",
      border: "1px solid " + (value ? "var(--red)" : "var(--border)"),
      borderRadius: 20,
      width: 40,
      height: 22,
      cursor: "pointer",
      position: "relative",
      flexShrink: 0,
      transition: "background 0.2s, border-color 0.2s"
    }
  }, React.createElement("span", {
    style: {
      position: "absolute",
      top: 2,
      left: value ? 20 : 2,
      width: 16,
      height: 16,
      background: "#fff",
      borderRadius: "50%",
      transition: "left 0.2s",
      boxShadow: "0 1px 3px rgba(0,0,0,0.3)"
    }
  }));
}
function StatusBadge({
  status
}) {
  if (!status) return null;
  const isError = status.startsWith("✕");
  return React.createElement("div", {
    style: {
      marginTop: 10,
      fontSize: 13,
      fontWeight: 500,
      color: isError ? "var(--red)" : "#48c774"
    }
  }, status);
}
function CleanRow({
  title,
  description,
  buttonLabel,
  onAction,
  danger,
  sizeLabel
}) {
  const [busy, setBusy] = (0, _react.useState)(false);
  const [status, setStatus] = (0, _react.useState)(null);
  const [hovered, setHovered] = (0, _react.useState)(false);
  const handle = async () => {
    setBusy(true);
    setStatus(null);
    try {
      const result = await onAction();
      if (result?.cancelled) {
        return;
      }
      setStatus(result?.msg || "✓ Done");
      setTimeout(() => setStatus(null), 4000);
    } catch (e) {
      setStatus("✕ " + (e.message || "Something went wrong"));
      setTimeout(() => setStatus(null), 4000);
    } finally {
      setBusy(false);
    }
  };
  return React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      justifyContent: "space-between",
      gap: 24
    }
  }, React.createElement("div", {
    style: {
      flex: 1
    }
  }, React.createElement("div", {
    style: {
      fontSize: 15,
      fontWeight: 600,
      color: "var(--text)",
      marginBottom: 4,
      display: "flex",
      alignItems: "center",
      gap: 10
    }
  }, title, sizeLabel && React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: "var(--text2)",
      background: "var(--surface2)",
      border: "1px solid var(--border)",
      borderRadius: 6,
      padding: "3px 10px",
      letterSpacing: 0.2,
      fontVariantNumeric: "tabular-nums"
    }
  }, sizeLabel)), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      lineHeight: 1.6
    }
  }, description), React.createElement(StatusBadge, {
    status: status
  })), React.createElement("div", {
    style: {
      flexShrink: 0,
      paddingTop: 2
    }
  }, React.createElement("button", {
    className: "btn btn-ghost",
    disabled: busy,
    onClick: handle,
    onMouseEnter: () => setHovered(true),
    onMouseLeave: () => setHovered(false),
    style: danger ? {
      color: hovered ? "#fff" : "var(--red)",
      background: hovered ? "rgba(229,9,20,0.85)" : "transparent",
      borderColor: hovered ? "transparent" : "rgba(229,9,20,0.35)",
      opacity: busy ? 0.5 : 1,
      transition: "all 0.2s"
    } : {
      opacity: busy ? 0.5 : 1
    }
  }, busy ? "Working…" : buttonLabel)));
}
function VersionSection() {
  const [checking, setChecking] = (0, _react.useState)(false);
  const [result, setResult] = (0, _react.useState)(null);
  const [showUpdateModal, setShowUpdateModal] = (0, _react.useState)(false);
  const [autoCheck, setAutoCheck] = (0, _react.useState)(() => {
    const stored = _storage.storage.get(_storage.STORAGE_KEYS.AUTO_CHECK_UPDATES);
    return stored === null || stored === undefined ? true : !!stored;
  });
  const [autoSaved, setAutoSaved] = (0, _react.useState)(false);
  const [currentVersion, setCurrentVersion] = (0, _react.useState)("0.0.0");
  const [updateSource, setUpdateSource] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.UPDATE_SOURCE) || _updates.DEFAULT_UPDATE_SOURCE);
  (0, _react.useEffect)(() => {
    if (window.electron?.getAppVersion) {
      window.electron.getAppVersion().then(v => {
        setCurrentVersion(v);
      });
    }
  }, []);
  const runCheck = async () => {
    setChecking(true);
    setResult(null);
    try {
      const r = await (0, _updates.checkForUpdatesWithFallback)(updateSource);
      setResult(r);
    } catch (e) {
      setResult({
        error: e.message || `Could not reach ${_updates.UPDATE_SOURCES[updateSource]?.label || "the update server"}.`
      });
    } finally {
      setChecking(false);
    }
  };
  const changeSource = src => {
    setUpdateSource(src);
    _storage.storage.set(_storage.STORAGE_KEYS.UPDATE_SOURCE, src);
    setResult(null);
  };
  const toggleAuto = val => {
    setAutoCheck(val);
    _storage.storage.set(_storage.STORAGE_KEYS.AUTO_CHECK_UPDATES, val ? 1 : 0);
    setAutoSaved(true);
    setTimeout(() => setAutoSaved(false), 1800);
  };
  return React.createElement("div", {
    style: {
      marginBottom: 40
    }
  }, React.createElement("div", {
    className: "settings-section-title"
  }, "SingularityTV · By @ec1lz"), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 12,
      padding: "14px 16px",
      marginBottom: 18,
      background: "var(--surface2)",
      border: "1px solid var(--border)",
      borderRadius: 10
    }
  }, React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 700,
      color: "var(--text)"
    }
  }, "SingularityTV Official · @ec1lz"), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 2
    }
  }, "All rights reserved to Singularity (@ec1lz)")), React.createElement("button", {
    className: "btn btn-primary",
    onClick: () => window.electron?.openExternal("https://t.me/ec1lz")
  }, "Telegram @ec1lz ↗")), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 16,
      flexWrap: "wrap",
      marginBottom: 20
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10
    }
  }, React.createElement("span", {
    style: {
      fontSize: 13,
      color: "var(--text3)"
    }
  }, "Current version"), React.createElement("code", {
    style: {
      fontSize: 14,
      fontWeight: 700,
      color: "var(--text)",
      background: "var(--surface2)",
      border: "1px solid var(--border)",
      borderRadius: 6,
      padding: "4px 12px"
    }
  }, "v", currentVersion)), React.createElement("button", {
    className: "btn btn-ghost",
    disabled: checking,
    onClick: runCheck,
    style: {
      opacity: checking ? 0.6 : 1
    }
  }, checking ? "Checking…" : "Check for Updates"), React.createElement("div", {
    style: {
      display: "inline-flex",
      border: "1px solid var(--border)",
      borderRadius: 8,
      overflow: "hidden"
    }
  }, Object.values(_updates.UPDATE_SOURCES).map(src => React.createElement("button", {
    key: src.id,
    onClick: () => changeSource(src.id),
    disabled: checking,
    title: `Check for updates via ${src.label}`,
    style: {
      border: "none",
      padding: "6px 12px",
      fontSize: 12,
      fontWeight: 600,
      cursor: checking ? "not-allowed" : "pointer",
      background: updateSource === src.id ? "var(--red)" : "var(--surface2)",
      color: updateSource === src.id ? "#fff" : "var(--text3)"
    }
  }, src.label))), result && !result.error && result.hasUpdate && React.createElement("button", {
    onClick: () => setShowUpdateModal(true),
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      background: "rgba(229,9,20,0.12)",
      border: "1px solid rgba(229,9,20,0.4)",
      color: "var(--red)",
      borderRadius: 8,
      padding: "6px 14px",
      fontSize: 13,
      fontWeight: 600,
      cursor: "pointer",
      transition: "background 0.2s"
    },
    onMouseEnter: e => e.currentTarget.style.background = "rgba(229,9,20,0.22)",
    onMouseLeave: e => e.currentTarget.style.background = "rgba(229,9,20,0.12)"
  }, "\uD83C\uDF89 v", result.latest, " available. Install Update"), result?.usedFallback && React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, "(", _updates.UPDATE_SOURCES[result.fallbackFrom]?.label || result.fallbackFrom, " ", "unavailable, used ", result.sourceLabel, " instead)"), result && !result.error && !result.hasUpdate && React.createElement("span", {
    style: {
      fontSize: 13,
      color: "#48c774",
      fontWeight: 500
    }
  }, "\u2713 You're up to date"), result?.error && React.createElement("span", {
    style: {
      fontSize: 13,
      color: "var(--red)"
    }
  }, "\u2715 ", result.error)), showUpdateModal && result?.hasUpdate && React.createElement(_UpdateModal.default, {
    updateInfo: result,
    onClose: () => setShowUpdateModal(false)
  }), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      flexWrap: "wrap"
    }
  }, React.createElement(Toggle, {
    value: autoCheck,
    onChange: toggleAuto,
    title: autoCheck ? "Disable auto-check" : "Enable auto-check"
  }), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: "var(--text)"
    }
  }, "Check for updates on startup"), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 2
    }
  }, "Shows a notification banner if a new version is available. Turned on by default.")), autoSaved && React.createElement("span", {
    style: {
      fontSize: 12,
      color: "#48c774"
    }
  }, "\u2713 Saved")));
}
function HomeLayoutSection() {
  const [order, setOrder] = (0, _react.useState)(() => {
    const {
      order: o
    } = (0, _homeLayout.loadHomeLayout)();
    return o;
  });
  const [visible, setVisible] = (0, _react.useState)(() => {
    const {
      visible: v
    } = (0, _homeLayout.loadHomeLayout)();
    return v;
  });
  const [viewMode, setViewMode] = (0, _react.useState)(() => (0, _homeLayout.loadHomeViewMode)());
  const [saved, setSaved] = (0, _react.useState)(false);
  const dragItem = (0, _react.useRef)(null);
  const dragOver = (0, _react.useRef)(null);
  const handleDragStart = idx => {
    dragItem.current = idx;
  };
  const handleDragEnter = idx => {
    dragOver.current = idx;
  };
  const handleDragEnd = () => {
    const newOrder = [...order];
    const dragged = newOrder.splice(dragItem.current, 1)[0];
    newOrder.splice(dragOver.current, 0, dragged);
    dragItem.current = null;
    dragOver.current = null;
    setOrder(newOrder);
  };
  const toggleVisible = id => {
    setVisible(prev => ({
      ...prev,
      [id]: !prev[id]
    }));
  };
  const handleSave = () => {
    _storage.storage.set(_storage.STORAGE_KEYS.HOME_ROW_ORDER, order);
    _storage.storage.set(_storage.STORAGE_KEYS.HOME_ROW_VISIBLE, visible);
    (0, _homeLayout.saveHomeViewMode)(viewMode);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };
  const rowLabels = Object.fromEntries(_homeLayout.HOME_ROWS.map(r => [r.id, r.label]));
  return React.createElement("div", {
    style: {
      marginBottom: 40
    }
  }, React.createElement("div", {
    className: "settings-section-title"
  }, "Home Page Layout"), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      marginBottom: 16,
      lineHeight: 1.6
    }
  }, "Choose which rows appear on the Home page and drag to reorder them. The hero banner is always shown at the top."), React.createElement("div", {
    style: {
      marginBottom: 20
    }
  }, React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: "var(--text2)",
      marginBottom: 8,
      textTransform: "uppercase",
      letterSpacing: "0.05em"
    }
  }, "Row display style"), React.createElement("div", {
    style: {
      display: "flex",
      gap: 10
    }
  }, [{
    value: "carousel",
    label: "Carousel",
    desc: "Scrollable spotlight with featured poster"
  }, {
    value: "list",
    label: "⊞ Grid",
    desc: "Compact grid of all items"
  }].map(({
    value,
    label,
    desc
  }) => React.createElement("button", {
    key: value,
    onClick: () => setViewMode(value),
    style: {
      flex: 1,
      maxWidth: 220,
      padding: "10px 14px",
      borderRadius: 8,
      border: `2px solid ${viewMode === value ? "var(--red)" : "var(--border)"}`,
      background: viewMode === value ? "color-mix(in srgb, var(--red) 12%, var(--surface))" : "var(--surface)",
      color: viewMode === value ? "var(--text)" : "var(--text2)",
      cursor: "pointer",
      textAlign: "left",
      transition: "border-color 0.15s, background 0.15s"
    }
  }, React.createElement("div", {
    style: {
      fontWeight: 600,
      fontSize: 14
    }
  }, label), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 2
    }
  }, desc))))), React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 8,
      maxWidth: 480
    }
  }, order.map((id, idx) => React.createElement("div", {
    key: id,
    draggable: true,
    onDragStart: () => handleDragStart(idx),
    onDragEnter: () => handleDragEnter(idx),
    onDragEnd: handleDragEnd,
    onDragOver: e => e.preventDefault(),
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      background: "var(--surface)",
      border: "1px solid var(--border)",
      borderRadius: 8,
      padding: "10px 14px",
      cursor: "grab",
      opacity: visible[id] ? 1 : 0.45,
      transition: "opacity 0.2s",
      userSelect: "none"
    }
  }, React.createElement("span", {
    style: {
      color: "var(--text3)",
      fontSize: 16,
      lineHeight: 1,
      flexShrink: 0
    }
  }, "\u283F"), React.createElement("span", {
    style: {
      flex: 1,
      fontSize: 14,
      fontWeight: 500,
      color: "var(--text)"
    }
  }, rowLabels[id] || id), React.createElement(Toggle, {
    value: visible[id],
    onChange: () => toggleVisible(id),
    title: visible[id] ? "Hide row" : "Show row"
  })))), React.createElement("div", {
    style: {
      marginTop: 16,
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, React.createElement("button", {
    className: "btn btn-primary",
    onClick: handleSave
  }, "Save Layout"), saved && React.createElement("span", {
    style: {
      fontSize: 13,
      color: "#48c774"
    }
  }, "\u2713 Saved")));
}
const FREQUENCY_OPTIONS = [{
  value: "startup",
  label: "On App Start"
}, {
  value: "daily",
  label: "Daily"
}, {
  value: "weekly",
  label: "Weekly"
}, {
  value: "monthly",
  label: "Monthly"
}];
function ScheduledBackupSection() {
  const [enabled, setEnabled] = (0, _react.useState)(false);
  const [backupPath, setBackupPath] = (0, _react.useState)("");
  const [keepCount, setKeepCount] = (0, _react.useState)(5);
  const [frequency, setFrequency] = (0, _react.useState)("startup");
  const [saved, setSaved] = (0, _react.useState)(false);
  const [loading, setLoading] = (0, _react.useState)(true);
  (0, _react.useEffect)(() => {
    if (!_storage.isElectron) {
      setLoading(false);
      return;
    }
    window.electron.getScheduledBackupSettings().then(s => {
      if (s) {
        setEnabled(!!s.enabled);
        setBackupPath(s.path || "");
        setKeepCount(s.keepCount ?? 5);
        setFrequency(s.frequency || "startup");
      }
      setLoading(false);
    });
  }, []);
  const pickFolder = async () => {
    if (!_storage.isElectron) return;
    const folder = await window.electron.pickFolder();
    if (folder) setBackupPath(folder);
  };
  const handleSave = async () => {
    if (!_storage.isElectron) return;
    const settings = {
      enabled,
      path: backupPath,
      keepCount: Math.max(1, Math.min(99, Number(keepCount) || 5)),
      frequency,
      lastRun: null
    };
    const existing = await window.electron.getScheduledBackupSettings();
    if (existing?.lastRun) settings.lastRun = existing.lastRun;
    await window.electron.setScheduledBackupSettings(settings);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };
  if (!_storage.isElectron || loading) return null;
  return React.createElement("div", {
    style: {
      marginTop: 28,
      padding: "20px 22px",
      background: "var(--surface2)",
      border: "1px solid var(--border)",
      borderRadius: 10
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      marginBottom: enabled ? 20 : 0
    }
  }, React.createElement(Toggle, {
    value: enabled,
    onChange: setEnabled
  }), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 600,
      color: "var(--text)"
    }
  }, "Scheduled Backups"), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 2
    }
  }, "Automatically save a backup file on a schedule"))), enabled && React.createElement(React.Fragment, null, React.createElement("div", {
    style: {
      marginBottom: 14
    }
  }, React.createElement("div", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      color: "var(--text2)",
      marginBottom: 6
    }
  }, "Backup Folder"), React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      alignItems: "center"
    }
  }, React.createElement("input", {
    className: "apikey-input",
    style: {
      flex: 1,
      marginBottom: 0
    },
    placeholder: "/home/you/Backups",
    value: backupPath,
    onChange: e => setBackupPath(e.target.value)
  }), React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "7px 14px",
      fontSize: 13
    },
    onClick: pickFolder
  }, "Browse\u2026"))), React.createElement("div", {
    style: {
      display: "flex",
      gap: 16,
      flexWrap: "wrap",
      marginBottom: 16
    }
  }, React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 160
    }
  }, React.createElement("div", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      color: "var(--text2)",
      marginBottom: 6
    }
  }, "Frequency"), React.createElement(SettingsSelect, {
    value: frequency,
    onChange: v => setFrequency(v),
    options: FREQUENCY_OPTIONS,
    style: {
      width: "100%"
    }
  })), React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 120
    }
  }, React.createElement("div", {
    style: {
      fontSize: 12,
      fontWeight: 600,
      color: "var(--text2)",
      marginBottom: 6
    }
  }, "Keep Last N Backups"), React.createElement("input", {
    type: "number",
    min: 1,
    max: 99,
    className: "apikey-input",
    style: {
      width: "100%",
      marginBottom: 0
    },
    value: keepCount,
    onChange: e => setKeepCount(e.target.value)
  }))), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, React.createElement("button", {
    className: "btn btn-primary",
    onClick: handleSave
  }, "Save"), saved && React.createElement("span", {
    style: {
      fontSize: 13,
      color: "#48c774"
    }
  }, "\u2713 Saved"))), !enabled && React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "flex-end",
      marginTop: 0
    }
  }));
}
function BackupRestoreSection({
  onRestored
}) {
  const [restoreStatus, setRestoreStatus] = (0, _react.useState)(null);
  const handleExport = () => {
    const backup = {
      version: 1,
      exportedAt: new Date().toISOString(),
      data: (0, _backup.collectBackupData)()
    };
    const blob = new Blob([JSON.stringify(backup, null, 2)], {
      type: "application/json"
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `streambert-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
    try {
      navigator.clipboard?.writeText(JSON.stringify(backup));
    } catch {}
    setRestoreStatus("✓ Backup exported");
    setTimeout(() => setRestoreStatus(null), 3000);
  };
  const handleImport = e => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = ev => {
      try {
        const backup = JSON.parse(ev.target.result);
        if (!backup?.data) throw new Error("Invalid backup file, missing data field.");
        (0, _backup.restoreBackupData)(backup.data);
        setRestoreStatus("✓ Backup restored: reloading…");
        setTimeout(() => window.location.reload(), 1200);
        onRestored?.();
      } catch (err) {
        setRestoreStatus("✕ " + (err.message || "Could not read backup file."));
        setTimeout(() => setRestoreStatus(null), 4000);
      }
    };
    reader.readAsText(file);
    e.target.value = "";
  };
  return React.createElement("div", {
    style: {
      marginBottom: 40
    }
  }, React.createElement("div", {
    className: "settings-section-title"
  }, "Backup & Restore"), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      marginBottom: 20,
      lineHeight: 1.6
    }
  }, "Export your watchlist, watch history, progress, and all settings to a JSON file. Import it later to restore everything, useful before reinstalling or switching devices."), React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      flexWrap: "wrap",
      alignItems: "center"
    }
  }, React.createElement("button", {
    className: "btn btn-primary",
    onClick: handleExport
  }, "\u2B06 Export Backup"), React.createElement("label", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 8,
      padding: "9px 18px",
      background: "var(--surface2)",
      border: "1px solid var(--border)",
      borderRadius: 8,
      fontSize: 14,
      fontWeight: 600,
      color: "var(--text)",
      cursor: "pointer",
      transition: "background 0.15s"
    },
    onMouseEnter: e => e.currentTarget.style.background = "var(--surface)",
    onMouseLeave: e => e.currentTarget.style.background = "var(--surface2)"
  }, "\u2B07 Import Backup", React.createElement("input", {
    type: "file",
    accept: ".json,application/json",
    onChange: handleImport,
    style: {
      display: "none"
    }
  })), restoreStatus && React.createElement("span", {
    style: {
      fontSize: 13,
      fontWeight: 500,
      color: restoreStatus.startsWith("✕") ? "var(--red)" : "#48c774"
    }
  }, restoreStatus)), React.createElement(ScheduledBackupSection, null));
}
function AppearanceSection() {
  const [accent, setAccent] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.ACCENT_COLOR) || "red");
  const [fontSize, setFontSize] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.FONT_SIZE) || "normal");
  const [compact, setCompact] = (0, _react.useState)(() => !!_storage.storage.get(_storage.STORAGE_KEYS.COMPACT_MODE));
  const [noAnim, setNoAnim] = (0, _react.useState)(() => !!_storage.storage.get(_storage.STORAGE_KEYS.REDUCE_ANIMATIONS));
  const [gamepadEnabled, setGamepadEnabled] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.GAMEPAD_ENABLED) !== false);
  const [accentInPlayer, setAccentInPlayer] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.ACCENT_IN_PLAYER) !== false);
  const [theme, setTheme] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.THEME) || "dark");
  const [customVars, setCustomVars] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.CUSTOM_THEME_VARS) || {
    ..._appearance.DEFAULT_CUSTOM_VARS
  });
  const [showCustomEditor, setShowCustomEditor] = (0, _react.useState)(false);
  const [saved, setSaved] = (0, _react.useState)(false);
  const committedRef = (0, _react.useRef)({
    accent: _storage.storage.get(_storage.STORAGE_KEYS.ACCENT_COLOR) || "red",
    theme: _storage.storage.get(_storage.STORAGE_KEYS.THEME) || "dark",
    customVars: _storage.storage.get(_storage.STORAGE_KEYS.CUSTOM_THEME_VARS) || {
      ..._appearance.DEFAULT_CUSTOM_VARS
    }
  });
  const savedRef = (0, _react.useRef)(false);
  (0, _react.useEffect)(() => {
    return () => {
      if (!savedRef.current) {
        const {
          accent,
          theme,
          customVars
        } = committedRef.current;
        (0, _appearance.applyAccentColor)(accent);
        (0, _appearance.applyTheme)(theme, theme === "custom" ? customVars : null);
      }
    };
  }, []);
  const handleThemeSelect = id => {
    setTheme(id);
    if (id !== "custom") {
      (0, _appearance.applyTheme)(id);
    } else {
      (0, _appearance.applyTheme)("custom", customVars);
      setShowCustomEditor(true);
    }
  };
  const handleCustomVarChange = (prop, value) => {
    const next = {
      ...customVars,
      [prop]: value
    };
    setCustomVars(next);
    (0, _appearance.applyTheme)("custom", next);
  };
  const handleSave = () => {
    _storage.storage.set(_storage.STORAGE_KEYS.ACCENT_COLOR, accent);
    _storage.storage.set(_storage.STORAGE_KEYS.ACCENT_IN_PLAYER, accentInPlayer);
    _storage.storage.set(_storage.STORAGE_KEYS.FONT_SIZE, fontSize);
    _storage.storage.set(_storage.STORAGE_KEYS.COMPACT_MODE, compact ? 1 : 0);
    _storage.storage.set(_storage.STORAGE_KEYS.REDUCE_ANIMATIONS, noAnim ? 1 : 0);
    _storage.storage.set(_storage.STORAGE_KEYS.GAMEPAD_ENABLED, gamepadEnabled);
    window.dispatchEvent(new CustomEvent("streambert:gamepad-settings-changed"));
    _storage.storage.set(_storage.STORAGE_KEYS.THEME, theme);
    if (theme === "custom") {
      _storage.storage.set(_storage.STORAGE_KEYS.CUSTOM_THEME_VARS, customVars);
    }
    (0, _appearance.applyAccentColor)(accent);
    (0, _appearance.applyTheme)(theme, theme === "custom" ? customVars : null);
    const zoomMap = {
      sm: 0.85,
      normal: 1,
      lg: 1.15
    };
    const fz = zoomMap[fontSize] ?? 1;
    document.documentElement.style.zoom = String(fz);
    if (window.electron?.setZoomFactor) window.electron.setZoomFactor(fz);
    document.body.classList.toggle("compact-mode", compact);
    document.body.classList.toggle("no-anim", noAnim);
    savedRef.current = true;
    committedRef.current = {
      accent,
      theme,
      customVars
    };
    window.dispatchEvent(new CustomEvent("streambert:player-settings-changed"));
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };
  const CUSTOM_VAR_LABELS = {
    "--bg": "Background",
    "--surface": "Surface",
    "--surface2": "Surface 2",
    "--surface3": "Surface 3",
    "--border": "Border",
    "--text": "Text",
    "--text2": "Text 2",
    "--text3": "Text 3"
  };
  return React.createElement("div", {
    style: {
      marginBottom: 40
    }
  }, React.createElement("div", {
    className: "settings-section-title"
  }, "Appearance"), React.createElement("div", {
    style: {
      marginBottom: 24
    }
  }, React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: "var(--text2)",
      marginBottom: 10
    }
  }, "Theme"), React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      flexWrap: "wrap"
    }
  }, _appearance.THEME_PRESETS.map(t => React.createElement("button", {
    key: t.id,
    onClick: () => handleThemeSelect(t.id),
    title: t.description,
    style: {
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 6,
      padding: "10px 14px",
      borderRadius: "var(--radius)",
      background: theme === t.id ? "color-mix(in srgb, var(--red) 15%, var(--surface2))" : "var(--surface2)",
      border: theme === t.id ? "1.5px solid var(--red)" : "1.5px solid var(--border)",
      cursor: "pointer",
      transition: "border-color 0.15s, background 0.15s",
      minWidth: 70
    }
  }, React.createElement("div", {
    style: {
      width: 40,
      height: 28,
      borderRadius: 4,
      background: t.id === "custom" ? `linear-gradient(135deg, ${customVars["--bg"]} 50%, ${customVars["--surface2"]} 50%)` : t.vars ? `linear-gradient(135deg, ${t.vars["--bg"]} 50%, ${t.vars["--surface2"]} 50%)` : "var(--surface3)",
      border: "1px solid rgba(255,255,255,0.08)",
      flexShrink: 0
    }
  }), React.createElement("span", {
    style: {
      fontSize: 12,
      fontWeight: theme === t.id ? 600 : 400,
      color: theme === t.id ? "var(--text)" : "var(--text2)",
      whiteSpace: "nowrap"
    }
  }, t.label)))), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 8
    }
  }, _appearance.THEME_PRESETS.find(t => t.id === theme)?.description)), theme === "custom" && React.createElement("div", {
    style: {
      marginBottom: 24
    }
  }, React.createElement("button", {
    onClick: () => setShowCustomEditor(v => !v),
    className: "btn btn-ghost",
    style: {
      fontSize: 12,
      padding: "5px 12px",
      marginBottom: 12
    }
  }, showCustomEditor ? "▲ Hide" : "▼ Edit", " custom colours"), showCustomEditor && React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fill, minmax(180px, 1fr))",
      gap: 12,
      padding: 16,
      background: "var(--surface2)",
      borderRadius: "var(--radius)",
      border: "1px solid var(--border)"
    }
  }, Object.entries(CUSTOM_VAR_LABELS).map(([prop, label]) => React.createElement("div", {
    key: prop,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, React.createElement("input", {
    type: "color",
    value: customVars[prop] || "#000000",
    onChange: e => handleCustomVarChange(prop, e.target.value),
    style: {
      width: 32,
      height: 32,
      borderRadius: 4,
      border: "1px solid var(--border)",
      cursor: "pointer",
      background: "none",
      padding: 2,
      flexShrink: 0
    }
  }), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text)",
      fontWeight: 500
    }
  }, label), React.createElement("div", {
    style: {
      fontSize: 11,
      color: "var(--text3)",
      fontFamily: "monospace"
    }
  }, customVars[prop])))), React.createElement("div", {
    style: {
      gridColumn: "1 / -1",
      display: "flex",
      gap: 8,
      marginTop: 4
    }
  }, React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      fontSize: 12,
      padding: "5px 12px"
    },
    onClick: () => {
      setCustomVars({
        ..._appearance.DEFAULT_CUSTOM_VARS
      });
      (0, _appearance.applyTheme)("custom", _appearance.DEFAULT_CUSTOM_VARS);
    }
  }, "Reset to defaults")))), React.createElement("div", {
    style: {
      marginBottom: 24
    }
  }, React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: "var(--text2)",
      marginBottom: 10
    }
  }, "Accent Colour"), React.createElement("div", {
    style: {
      display: "flex",
      gap: 10,
      flexWrap: "wrap"
    }
  }, _appearance.ACCENT_PRESETS.map(p => React.createElement("button", {
    key: p.id,
    onClick: () => {
      setAccent(p.id);
      (0, _appearance.applyAccentColor)(p.id);
    },
    title: p.label,
    style: {
      width: 32,
      height: 32,
      borderRadius: "50%",
      background: p.color,
      border: accent === p.id ? `3px solid var(--text)` : "3px solid transparent",
      outline: accent === p.id ? `2px solid ${p.color}` : "none",
      outlineOffset: 2,
      cursor: "pointer",
      transition: "transform 0.15s",
      transform: accent === p.id ? "scale(1.15)" : "scale(1)",
      flexShrink: 0
    }
  }))), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 8
    }
  }, _appearance.ACCENT_PRESETS.find(p => p.id === accent)?.label, ", applied to buttons, highlights, and indicators."), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      marginTop: 14
    }
  }, React.createElement(Toggle, {
    value: accentInPlayer,
    onChange: setAccentInPlayer
  }), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: "var(--text)"
    }
  }, "Apply accent colour to streaming player"), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 2
    }
  }, "Passes the selected accent colour to the player source (Videasy, Vidking). VidSrc does not support colour theming.")))), React.createElement("div", {
    style: {
      marginBottom: 24
    }
  }, React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: "var(--text2)",
      marginBottom: 10
    }
  }, "Font Size"), React.createElement("div", {
    style: {
      display: "flex",
      gap: 8
    }
  }, [{
    id: "sm",
    label: "Small"
  }, {
    id: "normal",
    label: "Normal"
  }, {
    id: "lg",
    label: "Large"
  }].map(o => React.createElement("button", {
    key: o.id,
    onClick: () => setFontSize(o.id),
    className: fontSize === o.id ? "btn btn-primary" : "btn btn-ghost",
    style: {
      padding: "7px 18px",
      fontSize: o.id === "sm" ? 12 : o.id === "lg" ? 16 : 14
    }
  }, o.label)))), React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16,
      marginBottom: 24
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, React.createElement(Toggle, {
    value: compact,
    onChange: setCompact
  }), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: "var(--text)"
    }
  }, "Compact card grid"), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 2
    }
  }, "Shows more titles per row by reducing card size."))), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, React.createElement(Toggle, {
    value: noAnim,
    onChange: setNoAnim
  }), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: "var(--text)"
    }
  }, "Reduce animations"), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 2
    }
  }, "Disables transitions and hover effects throughout the app."))), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, React.createElement(Toggle, {
    value: localStorage.getItem("streambert_forceTvMode") === "1",
    onChange: v => {
      localStorage.setItem("streambert_forceTvMode", v ? "1" : "0");
      window.dispatchEvent(new CustomEvent("streambert:tv-mode-changed"));
    }
  }), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: "var(--text)"
    }
  }, "Android TV / 10-Foot UI Mode"), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 2
    }
  }, "Optimizes typography, poster sizes, overscan margins, and D-Pad focus rings for large TV screens."))), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, React.createElement(Toggle, {
    value: gamepadEnabled,
    onChange: setGamepadEnabled
  }), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: "var(--text)"
    }
  }, "Controller support"), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 2
    }
  }, "Navigate menus with a D-pad/stick and use A/B to select and go back. In the player: A play/pause, D-pad seek/volume, LB/RB skip \xB115s, Y fullscreen, B exit.")))), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, React.createElement("button", {
    className: "btn btn-primary",
    onClick: handleSave
  }, "Save"), saved && React.createElement("span", {
    style: {
      fontSize: 13,
      color: "#48c774"
    }
  }, "\u2713 Saved")));
}
function LibraryPrivacySection() {
  const [sort, setSort] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.LIBRARY_SORT) || "manual");
  const [historyEnabled, setHistoryEnabled] = (0, _react.useState)(() => {
    const v = _storage.storage.get(_storage.STORAGE_KEYS.HISTORY_ENABLED);
    return v === 0 || v === false ? false : true;
  });
  const [saved, setSaved] = (0, _react.useState)(false);
  const handleSave = () => {
    _storage.storage.set(_storage.STORAGE_KEYS.LIBRARY_SORT, sort);
    _storage.storage.set(_storage.STORAGE_KEYS.HISTORY_ENABLED, historyEnabled ? 1 : 0);
    window.dispatchEvent(new CustomEvent("streambert:library-sort-changed", {
      detail: sort
    }));
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };
  const SORT_OPTIONS = [{
    value: "manual",
    label: "Custom order"
  }, {
    value: "title",
    label: "Title A-Z"
  }, {
    value: "rating",
    label: "Top rated"
  }, {
    value: "year",
    label: "Newest first"
  }];
  return React.createElement("div", {
    style: {
      marginBottom: 40
    }
  }, React.createElement("div", {
    className: "settings-section-title"
  }, "Library & Privacy"), React.createElement("div", {
    style: {
      marginBottom: 24
    }
  }, React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: "var(--text2)",
      marginBottom: 8
    }
  }, "Watchlist sort order"), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      marginBottom: 12,
      lineHeight: 1.6
    }
  }, "How titles in your watchlist are sorted. \"Custom order\" keeps your drag-and-drop arrangement."), React.createElement(SettingsSelect, {
    value: sort,
    onChange: v => setSort(v),
    options: SORT_OPTIONS
  })), React.createElement("div", {
    style: {
      marginBottom: 24
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, React.createElement(Toggle, {
    value: historyEnabled,
    onChange: setHistoryEnabled
  }), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: "var(--text)"
    }
  }, "Record watch history"), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 2
    }
  }, "When off, nothing you watch will be added to history or \"Continue Watching\"."))), !historyEnabled && React.createElement("div", {
    style: {
      marginTop: 12,
      fontSize: 13,
      color: "var(--red)",
      background: "rgba(229,9,20,0.08)",
      border: "1px solid rgba(229,9,20,0.2)",
      borderRadius: 8,
      padding: "10px 14px"
    }
  }, "\u26A0 Watch history is disabled. Progress tracking and \"Continue Watching\" will not work.")), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, React.createElement("button", {
    className: "btn btn-primary",
    onClick: handleSave
  }, "Save"), saved && React.createElement("span", {
    style: {
      fontSize: 13,
      color: "#48c774"
    }
  }, "\u2713 Saved")));
}
function StartPageSection() {
  const [startPage, setStartPage] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.START_PAGE) || "home");
  const [saved, setSaved] = (0, _react.useState)(false);
  const handleSave = () => {
    _storage.storage.set(_storage.STORAGE_KEYS.START_PAGE, startPage);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };
  return React.createElement("div", {
    style: {
      marginBottom: 40
    }
  }, React.createElement("div", {
    className: "settings-section-title"
  }, "Start Page"), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      marginBottom: 16,
      lineHeight: 1.6
    }
  }, "Choose which page opens when you launch SingularityTV."), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      flexWrap: "wrap"
    }
  }, React.createElement(SettingsSelect, {
    value: startPage,
    onChange: v => setStartPage(v),
    options: [{
      value: "home",
      label: "Home"
    }, {
      value: "history",
      label: "Library / History"
    }, {
      value: "downloads",
      label: "⬇  Downloads"
    }]
  }), React.createElement("button", {
    className: "btn btn-primary",
    onClick: handleSave
  }, "Save"), saved && React.createElement("span", {
    style: {
      fontSize: 13,
      color: "#48c774"
    }
  }, "\u2713 Saved")));
}
const TMDB_LANGUAGES = [{
  value: "en-US",
  label: "English (en-US)"
}, {
  value: "de-DE",
  label: "Deutsch (de-DE)"
}, {
  value: "fr-FR",
  label: "Français (fr-FR)"
}, {
  value: "es-ES",
  label: "Español (es-ES)"
}, {
  value: "it-IT",
  label: "Italiano (it-IT)"
}, {
  value: "pt-BR",
  label: "Português (Brasil) (pt-BR)"
}, {
  value: "nl-NL",
  label: "Nederlands (nl-NL)"
}, {
  value: "pl-PL",
  label: "Polski (pl-PL)"
}, {
  value: "sv-SE",
  label: "Svenska (sv-SE)"
}, {
  value: "nb-NO",
  label: "Norsk (nb-NO)"
}, {
  value: "da-DK",
  label: "Dansk (da-DK)"
}, {
  value: "fi-FI",
  label: "Suomi (fi-FI)"
}, {
  value: "tr-TR",
  label: "Türkçe (tr-TR)"
}, {
  value: "ru-RU",
  label: "Русский (ru-RU)"
}, {
  value: "ja-JP",
  label: "日本語 (ja-JP)"
}, {
  value: "ko-KR",
  label: "한국어 (ko-KR)"
}, {
  value: "zh-CN",
  label: "中文 (简体) (zh-CN)"
}, {
  value: "ar-SA",
  label: "العربية (ar-SA)"
}];
function TmdbLanguageSection() {
  const [lang, setLang] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.TMDB_LANG) || "en-US");
  const [saved, setSaved] = (0, _react.useState)(false);
  const handleSave = () => {
    _storage.storage.set(_storage.STORAGE_KEYS.TMDB_LANG, lang);
    (0, _api.clearTmdbCache)();
    window.dispatchEvent(new CustomEvent("streambert:tmdb-lang-changed"));
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };
  return React.createElement("div", {
    style: {
      marginBottom: 40
    }
  }, React.createElement("div", {
    className: "settings-section-title"
  }, "Metadata Language"), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      marginBottom: 16,
      lineHeight: 1.6
    }
  }, "Language used when fetching titles, descriptions, and metadata from keyless providers (Cinemeta, TVMaze, AniList). Changing this clears the metadata cache so updated content loads immediately."), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      flexWrap: "wrap"
    }
  }, React.createElement(SettingsSelect, {
    value: lang,
    onChange: v => setLang(v),
    options: TMDB_LANGUAGES
  }), React.createElement("button", {
    className: "btn btn-primary",
    onClick: handleSave
  }, "Save"), saved && React.createElement("span", {
    style: {
      fontSize: 13,
      color: "#48c774"
    }
  }, "\u2713 Saved, cache cleared")));
}
function SubtitleSettingsSection() {
  const [enabled, setEnabled] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.SUBTITLE_ENABLED) !== 0 && _storage.storage.get(_storage.STORAGE_KEYS.SUBTITLE_ENABLED) !== "0");
  const [lang, setLang] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.SUBTITLE_LANG) || "en");
  const [subColor, setSubColor] = (0, _react.useState)(() => _storage.storage.get("subtitleTextColor") || "#FFFFFF");
  const [subBg, setSubBg] = (0, _react.useState)(() => _storage.storage.get("subtitleBgStyle") || "dark");
  const [subSize, setSubSize] = (0, _react.useState)(() => String(_storage.storage.get("subtitleFontSizeSp") || "22"));
  const [subdlApiKey, setSubdlApiKey] = (0, _react.useState)("");
  const [showSubdlKey, setShowSubdlKey] = (0, _react.useState)(false);
  const [wyzieApiKey, setWyzieApiKey] = (0, _react.useState)("");
  const [showWyzieKey, setShowWyzieKey] = (0, _react.useState)(false);
  const [wyzieCopied, setWyzieCopied] = (0, _react.useState)(false);
  const [wyzieClearConfirm, setWyzieClearConfirm] = (0, _react.useState)(false);
  const [saved, setSaved] = (0, _react.useState)(false);
  (0, _react.useEffect)(() => {
    _storage.secureStorage.get(_storage.STORAGE_KEYS.SUBDL_API_KEY).then(val => {
      if (val) setSubdlApiKey(val);
    });
    _storage.secureStorage.get(_storage.STORAGE_KEYS.WYZIE_API_KEY).then(val => {
      if (val) setWyzieApiKey(val);
    });
  }, []);
  const hasSubdlKey = subdlApiKey.trim().length > 0;
  const hasWyzieKey = wyzieApiKey.trim().length > 0;
  const handleWyzieCopy = () => {
    navigator.clipboard.writeText(wyzieApiKey.trim()).then(() => {
      setWyzieCopied(true);
      setTimeout(() => setWyzieCopied(false), 1500);
    });
  };
  const handleSave = () => {
    _storage.storage.set(_storage.STORAGE_KEYS.SUBTITLE_ENABLED, enabled ? 1 : 0);
    _storage.storage.set(_storage.STORAGE_KEYS.SUBTITLE_LANG, lang);
    _storage.storage.set("subtitleTextColor", subColor);
    _storage.storage.set("subtitleBgStyle", subBg);
    _storage.storage.set("subtitleFontSizeSp", Number(subSize));
    _storage.secureStorage.set(_storage.STORAGE_KEYS.SUBDL_API_KEY, subdlApiKey.trim());
    _storage.secureStorage.set(_storage.STORAGE_KEYS.WYZIE_API_KEY, wyzieApiKey.trim());
    window.dispatchEvent(new CustomEvent("streambert:player-settings-changed"));
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };
  return React.createElement("div", {
    style: {
      marginBottom: 40
    }
  }, React.createElement("div", {
    className: "settings-section-title"
  }, "Subtitle Downloads"), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      marginBottom: 20,
      lineHeight: 1.7
    }
  }, React.createElement("span", {
    style: {
      color: "var(--text)",
      fontWeight: 600
    }
  }, "Wyzie Subs"), " ", "is used by default and requires a free API key (no account needed). Optionally add a", " ", React.createElement("span", {
    style: {
      color: "var(--red)",
      cursor: "pointer",
      textDecoration: "underline"
    },
    onClick: () => window.electron?.openExternal("https://subdl.com/settings")
  }, "SubDL API key"), " ", "(free), to use SubDL as the primary source instead.", hasSubdlKey && React.createElement("span", {
    style: {
      display: "inline-block",
      marginLeft: 8,
      fontSize: 11,
      fontWeight: 700,
      padding: "1px 7px",
      borderRadius: 3,
      background: "rgba(229,9,20,0.15)",
      color: "#ff4d57",
      border: "1px solid rgba(229,9,20,0.35)"
    }
  }, "SubDL ACTIVE")), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      marginBottom: 20
    }
  }, React.createElement(Toggle, {
    value: enabled,
    onChange: setEnabled
  }), React.createElement("span", {
    style: {
      fontSize: 14,
      color: enabled ? "var(--text)" : "var(--text3)"
    }
  }, enabled ? "Auto-download subtitles when downloading videos" : "Subtitle download disabled")), enabled && React.createElement(React.Fragment, null, React.createElement("div", {
    style: {
      marginBottom: 16
    }
  }, React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginBottom: 6
    }
  }, "Default language"), React.createElement(SettingsSelect, {
    value: lang,
    onChange: v => setLang(v),
    options: _subtitles.SUBTITLE_LANGUAGES.map(l => ({
      value: l.code,
      label: l.label
    }))
  })), React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(160px, 1fr))",
      gap: 12,
      marginBottom: 16
    }
  }, React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginBottom: 6
    }
  }, "Subtitle Color"), React.createElement(SettingsSelect, {
    value: subColor,
    onChange: v => {
      setSubColor(v);
      _storage.storage.set("subtitleTextColor", v);
    },
    options: [{
      value: "#FFFFFF",
      label: "White"
    }, {
      value: "#FACC15",
      label: "Yellow"
    }, {
      value: "#38BDF8",
      label: "Cyan"
    }, {
      value: "#4ADE80",
      label: "Green"
    }]
  })), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginBottom: 6
    }
  }, "Subtitle Background"), React.createElement(SettingsSelect, {
    value: subBg,
    onChange: v => {
      setSubBg(v);
      _storage.storage.set("subtitleBgStyle", v);
    },
    options: [{
      value: "dark",
      label: "Dark Box"
    }, {
      value: "semi",
      label: "Semi-Transparent"
    }, {
      value: "none",
      label: "None (Shadow Only)"
    }]
  })), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginBottom: 6
    }
  }, "Subtitle Size"), React.createElement(SettingsSelect, {
    value: subSize,
    onChange: v => {
      setSubSize(v);
      _storage.storage.set("subtitleFontSizeSp", Number(v));
    },
    options: [{
      value: "16",
      label: "Small"
    }, {
      value: "22",
      label: "Normal"
    }, {
      value: "28",
      label: "Large"
    }, {
      value: "34",
      label: "TV XL"
    }]
  }))), React.createElement("div", {
    style: {
      marginBottom: 20
    }
  }, React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginBottom: 6
    }
  }, "Wyzie API key", " ", React.createElement("span", {
    style: {
      marginLeft: 8,
      fontSize: 10,
      fontWeight: 700,
      padding: "1px 5px",
      borderRadius: 3,
      background: hasWyzieKey ? "rgba(99,202,183,0.12)" : "rgba(255,180,80,0.12)",
      color: hasWyzieKey ? "#63cab7" : "#ffb450",
      border: `1px solid ${hasWyzieKey ? "rgba(99,202,183,0.25)" : "rgba(255,180,80,0.25)"}`
    }
  }, hasWyzieKey ? "SET" : "REQUIRED")), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginBottom: 8,
      lineHeight: 1.5
    }
  }, "Required for Wyzie Subs. Get a free key by following the tutorial.", " ", React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      display: "inline",
      padding: 0,
      fontSize: 12,
      color: "var(--red)",
      background: "none",
      border: "none",
      cursor: "pointer"
    },
    onClick: () => window.electron?.openExternal("https://t.me/ec1lz")
  }, "How to get a key \u2197")), React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      alignItems: "center",
      flexWrap: "wrap"
    }
  }, React.createElement("input", {
    className: "apikey-input",
    style: {
      flex: 1,
      maxWidth: 340,
      marginBottom: 0
    },
    type: showWyzieKey ? "text" : "password",
    placeholder: "wyzie-...",
    value: wyzieApiKey,
    onChange: e => setWyzieApiKey(e.target.value)
  }), React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "6px 12px",
      fontSize: 12
    },
    onClick: () => setShowWyzieKey(v => !v)
  }, showWyzieKey ? "Hide" : "Show"), hasWyzieKey && React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "6px 12px",
      fontSize: 12
    },
    onClick: handleWyzieCopy,
    title: "Copy key"
  }, wyzieCopied ? "Copied!" : "Copy"), hasWyzieKey && React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "6px 12px",
      fontSize: 12
    },
    onClick: () => window.electron?.openExternal(`https://store.wyzie.io/dashboard?key=${wyzieApiKey.trim()}`),
    title: "Open your wyzie dashboard"
  }, "Dashboard \u2197"))), React.createElement("div", {
    style: {
      marginBottom: 8
    }
  }, React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginBottom: 6
    }
  }, "SubDL API key", " ", React.createElement("span", {
    style: {
      color: "var(--text3)",
      cursor: "pointer",
      fontSize: 11
    },
    onClick: () => window.electron?.openExternal("https://subdl.com/settings")
  }, "(free, register at subdl.com \u2197)"), React.createElement("span", {
    style: {
      marginLeft: 8,
      fontSize: 10,
      fontWeight: 700,
      padding: "1px 5px",
      borderRadius: 3,
      background: "rgba(99,202,183,0.12)",
      color: "#63cab7",
      border: "1px solid rgba(99,202,183,0.25)"
    }
  }, "OPTIONAL")), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginBottom: 8,
      lineHeight: 1.5
    }
  }, "Leave empty to use", " ", React.createElement("strong", {
    style: {
      color: "var(--text)"
    }
  }, "Wyzie Subs"), " ", "(default, requires Wyzie API key above). Add a SubDL key to switch to SubDL as the primary source."), React.createElement("div", {
    style: {
      display: "flex",
      gap: 8,
      alignItems: "center"
    }
  }, React.createElement("input", {
    className: "apikey-input",
    style: {
      flex: 1,
      maxWidth: 400,
      marginBottom: 0
    },
    type: showSubdlKey ? "text" : "password",
    placeholder: "SubDL API key, leave empty to use Wyzie",
    value: subdlApiKey,
    onChange: e => setSubdlApiKey(e.target.value)
  }), React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "6px 12px",
      fontSize: 12
    },
    onClick: () => setShowSubdlKey(v => !v)
  }, showSubdlKey ? "Hide" : "Show"), subdlApiKey.trim() && React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "6px 12px",
      fontSize: 12,
      color: "var(--text3)"
    },
    onClick: () => setSubdlApiKey(""),
    title: "Clear key (revert to Wyzie)"
  }, "Clear")))), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      marginTop: 8
    }
  }, React.createElement("button", {
    className: "btn btn-primary",
    onClick: handleSave
  }, "Save"), saved && React.createElement("span", {
    style: {
      fontSize: 13,
      color: "#4caf50"
    }
  }, "\u2713 Saved")));
}
function NotificationsSection() {
  const [notifyDownload, setNotifyDownload] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.NOTIFY_DOWNLOAD_COMPLETE) !== false);
  const [notifyEpisode, setNotifyEpisode] = (0, _react.useState)(() => {
    const stored = _storage.storage.get(_storage.STORAGE_KEYS.NOTIFY_NEW_EPISODE);
    return stored === null || stored === undefined ? true : !!stored;
  });
  const [saved, setSaved] = (0, _react.useState)(false);
  const saveSettings = () => {
    _storage.storage.set(_storage.STORAGE_KEYS.NOTIFY_DOWNLOAD_COMPLETE, notifyDownload);
    _storage.storage.set(_storage.STORAGE_KEYS.NOTIFY_NEW_EPISODE, notifyEpisode);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };
  const ToggleRow = ({
    label,
    description,
    value,
    onChange
  }) => React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      gap: 14,
      padding: "16px 0",
      borderBottom: "1px solid var(--border)"
    }
  }, React.createElement(Toggle, {
    value: value,
    onChange: onChange
  }), React.createElement("div", {
    style: {
      flex: 1
    }
  }, React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: "var(--text)"
    }
  }, label), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 3,
      lineHeight: 1.5
    }
  }, description)));
  return React.createElement("div", {
    style: {
      marginBottom: 40
    }
  }, React.createElement("div", {
    className: "settings-section-title"
  }, "Desktop Notifications"), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      marginBottom: 16,
      lineHeight: 1.6
    }
  }, "Control which events trigger a desktop notification."), React.createElement("div", {
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border)",
      borderRadius: 10,
      padding: "0 16px",
      marginBottom: 20
    }
  }, React.createElement(ToggleRow, {
    label: "Notify when a download completes",
    description: "Shows a desktop notification when an item finishes downloading.",
    value: notifyDownload,
    onChange: setNotifyDownload
  }), React.createElement(ToggleRow, {
    label: "Notify about new episodes on startup",
    description: "On startup, checks every TV series you have saved for newly released episodes and notifies you if any aired since the last check.",
    value: notifyEpisode,
    onChange: setNotifyEpisode
  })), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, React.createElement("button", {
    className: "btn btn-primary",
    onClick: saveSettings
  }, "Save"), saved && React.createElement("span", {
    style: {
      fontSize: 13,
      color: "#48c774"
    }
  }, "\u2713 Saved")));
}
function DiscordRpcSection() {
  const [enabled, setEnabledState] = (0, _react.useState)(() => !!_storage.storage.get(_storage.STORAGE_KEYS.DISCORD_RPC_ENABLED));
  const [showCover, setShowCover] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.DISCORD_RPC_SHOW_COVER) !== false);
  const [showTimestamp, setShowTimestamp] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.DISCORD_RPC_SHOW_TIMESTAMP) !== false);
  const [showButton, setShowButton] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.DISCORD_RPC_SHOW_BUTTON) !== false);
  const [saved, setSaved] = (0, _react.useState)(false);
  const saveSettings = () => {
    _storage.storage.set(_storage.STORAGE_KEYS.DISCORD_RPC_ENABLED, enabled);
    _storage.storage.set(_storage.STORAGE_KEYS.DISCORD_RPC_SHOW_COVER, showCover);
    _storage.storage.set(_storage.STORAGE_KEYS.DISCORD_RPC_SHOW_TIMESTAMP, showTimestamp);
    _storage.storage.set(_storage.STORAGE_KEYS.DISCORD_RPC_SHOW_BUTTON, showButton);
    window.dispatchEvent(new CustomEvent("streambert:discord-rpc-settings-changed"));
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };
  const ToggleRow = ({
    label,
    description,
    value,
    onChange,
    disabled
  }) => React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      gap: 14,
      padding: "16px 0",
      borderBottom: "1px solid var(--border)",
      opacity: disabled ? 0.45 : 1,
      pointerEvents: disabled ? "none" : "auto"
    }
  }, React.createElement(Toggle, {
    value: value,
    onChange: onChange
  }), React.createElement("div", {
    style: {
      flex: 1
    }
  }, React.createElement("div", {
    style: {
      fontSize: 14,
      fontWeight: 500,
      color: "var(--text)"
    }
  }, label), React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginTop: 3,
      lineHeight: 1.5
    }
  }, description)));
  return React.createElement("div", {
    style: {
      marginBottom: 40
    }
  }, React.createElement("div", {
    className: "settings-section-title"
  }, "Discord Rich Presence"), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      marginBottom: 16,
      lineHeight: 1.6
    }
  }, "Shows what you're currently watching on your Discord profile (title + cover, or \"Idling\" when nothing is open). Off by default. Requires the Discord desktop client to be running."), React.createElement("div", {
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border)",
      borderRadius: 10,
      padding: "0 16px",
      marginBottom: 20
    }
  }, React.createElement(ToggleRow, {
    label: "Enable Discord Rich Presence",
    description: "Connects to your local Discord client and updates your status automatically.",
    value: enabled,
    onChange: setEnabledState
  }), React.createElement(ToggleRow, {
    label: "Show cover art",
    description: "Uses the movie/show poster as the large image. When off, only the SingularityTV icon is shown.",
    value: showCover,
    onChange: setShowCover,
    disabled: !enabled
  }), React.createElement(ToggleRow, {
    label: "Show elapsed time",
    description: "Displays how long you've been on the current title's page.",
    value: showTimestamp,
    onChange: setShowTimestamp,
    disabled: !enabled
  }), React.createElement(ToggleRow, {
    label: "Show Telegram @ec1lz button",
    description: "Adds a button linking to @ec1lz on Telegram.",
    value: showButton,
    onChange: setShowButton,
    disabled: !enabled
  })), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, React.createElement("button", {
    className: "btn btn-primary",
    onClick: saveSettings
  }, "Save"), saved && React.createElement("span", {
    style: {
      fontSize: 13,
      color: "#48c774"
    }
  }, "\u2713 Saved")));
}
function SectionGroupHeader({
  title,
  subtitle
}) {
  return React.createElement("div", {
    style: {
      marginBottom: 32,
      marginTop: 4
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 14,
      marginBottom: subtitle ? 6 : 0
    }
  }, React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 16,
      letterSpacing: 2,
      color: "var(--red)",
      textTransform: "uppercase",
      fontWeight: 700,
      whiteSpace: "nowrap"
    }
  }, title), React.createElement("div", {
    style: {
      flex: 1,
      height: 1,
      background: "rgba(229,9,20,0.18)"
    }
  })), subtitle && React.createElement("div", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      lineHeight: 1.5
    }
  }, subtitle));
}
function Divider() {
  return React.createElement("div", {
    style: {
      height: 1,
      background: "var(--border)",
      marginBottom: 40
    }
  });
}
const SUPPORTS_HIGHLIGHT = typeof CSS !== "undefined" && typeof CSS.highlights !== "undefined";
const SECTION_NAV = [{
  id: "updates",
  label: "Updates & API",
  icon: "↑",
  keywords: ["update", "version", "metadata", "api", "token", "key", "check", "startup", "auto", "app", "language", "metadata", "locale", "german", "french", "spanish"]
}, {
  id: "content",
  label: "Age Rating",
  icon: "🔞",
  keywords: ["age", "rating", "parental", "content", "country", "restriction", "pg", "fsk", "adults"]
}, {
  id: "subtitles",
  label: "Subtitles",
  icon: "CC",
  keywords: ["subtitle", "subdl", "wyzie", "language", "caption", "srt", "download", "cc"]
}, {
  id: "downloads",
  label: "Downloads",
  icon: "⬇",
  keywords: ["download", "folder", "path", "save", "video", "movies", "files"]
}, {
  id: "notifications",
  label: "Notifications",
  icon: "🔔",
  keywords: ["notification", "notify", "alert", "desktop", "episode", "download", "watchlist", "new episode", "release"]
}, {
  id: "interface",
  label: "Interface",
  icon: "✦",
  keywords: ["home", "layout", "start page", "appearance", "accent", "colour", "color", "font", "compact", "animation", "theme", "rows", "hero"]
}, {
  id: "library",
  label: "Library",
  icon: "📚",
  keywords: ["library", "watchlist", "sort", "history", "privacy", "watch history", "continue"]
}, {
  id: "backup",
  label: "Backup",
  icon: "💾",
  keywords: ["backup", "restore", "export", "import", "scheduled", "json", "backup file"]
}, {
  id: "storage",
  label: "Storage & Data",
  icon: "🗄",
  keywords: ["storage", "cache", "clear", "reset", "delete", "data", "wipe", "progress", "factory"]
}];
function SettingsTopBar({
  sectionRefs,
  contentRef
}) {
  const [searchOpen, setSearchOpen] = (0, _react.useState)(false);
  const [navOpen, setNavOpen] = (0, _react.useState)(false);
  const [query, setQuery] = (0, _react.useState)("");
  const [matchCount, setMatchCount] = (0, _react.useState)(0);
  const [currentMatch, setCurrentMatch] = (0, _react.useState)(0);
  const matchRanges = (0, _react.useRef)([]);
  const currentMatchRef = (0, _react.useRef)(0);
  const matchCountRef = (0, _react.useRef)(0);
  const inputRef = (0, _react.useRef)(null);
  const navRef = (0, _react.useRef)(null);
  const searchBarRef = (0, _react.useRef)(null);
  const debounceTimer = (0, _react.useRef)(null);
  const rafHandle = (0, _react.useRef)(null);
  const clearHighlights = () => {
    if (SUPPORTS_HIGHLIGHT) {
      CSS.highlights.delete("settings-search");
      CSS.highlights.delete("settings-search-active");
    }
    matchRanges.current = [];
    matchCountRef.current = 0;
    currentMatchRef.current = 0;
    setMatchCount(0);
    setCurrentMatch(0);
  };
  const scrollToRange = range => {
    if (!range) return;
    if (rafHandle.current) cancelAnimationFrame(rafHandle.current);
    rafHandle.current = requestAnimationFrame(() => {
      rafHandle.current = null;
      try {
        const el = range.startContainer.parentElement;
        if (el) el.scrollIntoView({
          behavior: "smooth",
          block: "center"
        });
      } catch (_) {}
    });
  };
  const setActiveMatch = idx => {
    const range = matchRanges.current[idx];
    if (!range) return;
    if (SUPPORTS_HIGHLIGHT) {
      CSS.highlights.set("settings-search-active", new Highlight(range));
    }
    scrollToRange(range);
    currentMatchRef.current = idx + 1;
    setCurrentMatch(idx + 1);
  };
  const runSearch = searchQuery => {
    clearHighlights();
    if (!contentRef?.current || !searchQuery.trim()) return;
    const str = searchQuery.toLowerCase();
    const ranges = [];
    const walker = document.createTreeWalker(contentRef.current, NodeFilter.SHOW_TEXT);
    let node;
    while (node = walker.nextNode()) {
      const text = node.textContent.toLowerCase();
      let idx = 0;
      while ((idx = text.indexOf(str, idx)) !== -1) {
        const range = new Range();
        range.setStart(node, idx);
        range.setEnd(node, idx + searchQuery.length);
        ranges.push(range);
        idx += str.length;
      }
    }
    matchRanges.current = ranges;
    matchCountRef.current = ranges.length;
    setMatchCount(ranges.length);
    if (ranges.length > 0) {
      if (SUPPORTS_HIGHLIGHT) {
        const hl = new Highlight();
        for (const r of ranges) hl.add(r);
        CSS.highlights.set("settings-search", hl);
      }
      setActiveMatch(0);
    }
  };
  const findMatches = searchQuery => {
    if (debounceTimer.current) clearTimeout(debounceTimer.current);
    debounceTimer.current = setTimeout(() => {
      debounceTimer.current = null;
      runSearch(searchQuery);
    }, 80);
  };
  const goNext = () => {
    const total = matchCountRef.current;
    if (total === 0) return;
    const next = currentMatchRef.current < total ? currentMatchRef.current : 0;
    setActiveMatch(next);
  };
  const goPrev = () => {
    const total = matchCountRef.current;
    if (total === 0) return;
    const prev = currentMatchRef.current > 1 ? currentMatchRef.current - 2 : total - 1;
    setActiveMatch(prev);
  };
  const closeSearch = () => {
    setSearchOpen(false);
    setQuery("");
    clearHighlights();
  };
  (0, _react.useEffect)(() => {
    if (searchOpen) {
      setTimeout(() => {
        inputRef.current?.focus();
        inputRef.current?.select();
      }, 30);
    }
  }, [searchOpen]);
  (0, _react.useEffect)(() => () => {
    clearHighlights();
    if (debounceTimer.current) clearTimeout(debounceTimer.current);
    if (rafHandle.current) cancelAnimationFrame(rafHandle.current);
  }, []);
  (0, _react.useEffect)(() => {
    const handler = e => {
      if (e.key === "Escape") {
        closeSearch();
        setNavOpen(false);
        return;
      }
      if ((e.metaKey || e.ctrlKey) && (e.key === "k" || e.key === "f")) {
        e.preventDefault();
        setSearchOpen(true);
        return;
      }
      if (e.key === "F3") {
        e.preventDefault();
        if (e.shiftKey) goPrev();else goNext();
        return;
      }
      if (searchOpen && e.key === "Enter") {
        e.preventDefault();
        if (e.shiftKey) goPrev();else goNext();
      }
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [searchOpen]);
  (0, _react.useEffect)(() => {
    if (!navOpen) return;
    const handler = e => {
      if (navRef.current && !navRef.current.contains(e.target)) setNavOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [navOpen]);
  (0, _react.useEffect)(() => {
    if (!searchOpen) return;
    const handler = e => {
      if (searchBarRef.current && !searchBarRef.current.contains(e.target)) {
        clearHighlights();
        setSearchOpen(false);
        setQuery("");
      }
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [searchOpen]);
  const scrollTo = id => {
    const el = sectionRefs[id]?.current;
    if (el) el.scrollIntoView({
      behavior: "smooth",
      block: "start"
    });
    setNavOpen(false);
  };
  const handleQueryChange = e => {
    const val = e.target.value;
    setQuery(val);
    findMatches(val);
  };
  const noMatch = query.trim().length > 0 && matchCount === 0;
  const hasQuery = query.trim().length > 0;
  const navBtnStyle = {
    background: "none",
    border: "none",
    cursor: "pointer",
    color: "var(--text2)",
    display: "flex",
    alignItems: "center",
    padding: "4px 5px",
    borderRadius: 5,
    transition: "background 0.1s",
    flexShrink: 0
  };
  return React.createElement("div", {
    style: {
      position: "sticky",
      top: 0,
      zIndex: 100,
      background: "var(--bg, #141414)",
      borderBottom: "1px solid var(--border)",
      padding: "0 48px",
      backdropFilter: "blur(12px)"
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      padding: "10px 0"
    }
  }, React.createElement("div", {
    style: {
      flex: 1,
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, searchOpen ? React.createElement("div", {
    ref: searchBarRef,
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      flex: 1,
      maxWidth: 540,
      background: "var(--surface2)",
      border: `1px solid ${noMatch ? "#ff3860" : "var(--red)"}`,
      borderRadius: 8,
      padding: "5px 8px 5px 12px",
      boxShadow: `0 0 0 3px ${noMatch ? "rgba(255,56,96,0.1)" : "rgba(229,9,20,0.1)"}`,
      transition: "border-color 0.15s, box-shadow 0.15s"
    }
  }, React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "var(--text3)",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: {
      flexShrink: 0
    }
  }, React.createElement("circle", {
    cx: "11",
    cy: "11",
    r: "8"
  }), React.createElement("line", {
    x1: "21",
    y1: "21",
    x2: "16.65",
    y2: "16.65"
  })), React.createElement("input", {
    ref: inputRef,
    value: query,
    onChange: handleQueryChange,
    placeholder: "Search on this page\u2026",
    style: {
      flex: 1,
      background: "transparent",
      border: "none",
      outline: "none",
      fontSize: 14,
      color: noMatch ? "#ff3860" : "var(--text)",
      fontFamily: "var(--font-body)",
      minWidth: 0
    }
  }), hasQuery && React.createElement("span", {
    style: {
      fontSize: 12,
      color: noMatch ? "#ff3860" : "var(--text3)",
      fontVariantNumeric: "tabular-nums",
      whiteSpace: "nowrap",
      padding: "0 8px",
      borderLeft: "1px solid var(--border)",
      borderRight: "1px solid var(--border)",
      margin: "0 2px",
      flexShrink: 0
    }
  }, noMatch ? "No results" : `${currentMatch} / ${matchCount}`), matchCount > 0 && React.createElement("button", {
    onClick: goPrev,
    title: "Previous match (Shift+Enter)",
    style: navBtnStyle,
    onMouseEnter: e => e.currentTarget.style.background = "rgba(255,255,255,0.08)",
    onMouseLeave: e => e.currentTarget.style.background = "none"
  }, React.createElement("svg", {
    width: "13",
    height: "13",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, React.createElement("polyline", {
    points: "18 15 12 9 6 15"
  }))), matchCount > 0 && React.createElement("button", {
    onClick: goNext,
    title: "Next match (Enter)",
    style: navBtnStyle,
    onMouseEnter: e => e.currentTarget.style.background = "rgba(255,255,255,0.08)",
    onMouseLeave: e => e.currentTarget.style.background = "none"
  }, React.createElement("svg", {
    width: "13",
    height: "13",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.5",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, React.createElement("polyline", {
    points: "6 9 12 15 18 9"
  }))), query && React.createElement("button", {
    onClick: () => {
      setQuery("");
      clearHighlights();
      inputRef.current?.focus();
    },
    title: "Clear search",
    style: {
      ...navBtnStyle,
      color: "var(--text3)"
    },
    onMouseEnter: e => e.currentTarget.style.background = "rgba(255,255,255,0.08)",
    onMouseLeave: e => e.currentTarget.style.background = "none"
  }, React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2.5",
    strokeLinecap: "round"
  }, React.createElement("line", {
    x1: "18",
    y1: "6",
    x2: "6",
    y2: "18"
  }), React.createElement("line", {
    x1: "6",
    y1: "6",
    x2: "18",
    y2: "18"
  }))), React.createElement("button", {
    onClick: closeSearch,
    title: "Close (Esc)",
    style: {
      background: "none",
      border: "none",
      cursor: "pointer",
      color: "var(--text3)",
      fontSize: 11,
      padding: "3px 7px",
      borderRadius: 4,
      fontFamily: "var(--font-body)",
      flexShrink: 0,
      letterSpacing: 0.3
    }
  }, "Esc")) : React.createElement("button", {
    onClick: () => setSearchOpen(true),
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      background: "var(--surface2)",
      border: "1px solid var(--border)",
      borderRadius: 8,
      padding: "6px 14px",
      fontSize: 13,
      color: "var(--text3)",
      cursor: "pointer",
      transition: "all 0.15s",
      fontFamily: "var(--font-body)"
    },
    onMouseEnter: e => e.currentTarget.style.background = "var(--surface3)",
    onMouseLeave: e => e.currentTarget.style.background = "var(--surface2)"
  }, React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, React.createElement("circle", {
    cx: "11",
    cy: "11",
    r: "8"
  }), React.createElement("line", {
    x1: "21",
    y1: "21",
    x2: "16.65",
    y2: "16.65"
  })), "Search settings\u2026", React.createElement("span", {
    style: {
      fontSize: 10,
      color: "var(--text3)",
      background: "var(--surface)",
      border: "1px solid var(--border)",
      borderRadius: 4,
      padding: "1px 6px",
      fontFamily: "monospace",
      letterSpacing: 0.5
    }
  }, "\u2318K"))), React.createElement("div", {
    ref: navRef,
    style: {
      position: "relative",
      flexShrink: 0
    }
  }, React.createElement("button", {
    onClick: () => setNavOpen(o => !o),
    style: {
      display: "flex",
      alignItems: "center",
      gap: 8,
      background: navOpen ? "var(--surface3)" : "var(--surface2)",
      border: `1px solid ${navOpen ? "var(--red)" : "var(--border)"}`,
      boxShadow: navOpen ? "0 0 0 3px rgba(229,9,20,0.1)" : "none",
      borderRadius: 8,
      padding: "6px 14px",
      fontSize: 13,
      color: "var(--text)",
      cursor: "pointer",
      transition: "all 0.15s",
      fontFamily: "var(--font-body)"
    }
  }, React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "2",
    strokeLinecap: "round",
    strokeLinejoin: "round"
  }, React.createElement("line", {
    x1: "8",
    y1: "6",
    x2: "21",
    y2: "6"
  }), React.createElement("line", {
    x1: "8",
    y1: "12",
    x2: "21",
    y2: "12"
  }), React.createElement("line", {
    x1: "8",
    y1: "18",
    x2: "21",
    y2: "18"
  }), React.createElement("circle", {
    cx: "3",
    cy: "6",
    r: "1",
    fill: "currentColor"
  }), React.createElement("circle", {
    cx: "3",
    cy: "12",
    r: "1",
    fill: "currentColor"
  }), React.createElement("circle", {
    cx: "3",
    cy: "18",
    r: "1",
    fill: "currentColor"
  })), "Jump to Section", React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "var(--text3)",
    strokeWidth: "2.5",
    strokeLinecap: "round",
    style: {
      transform: navOpen ? "rotate(180deg)" : "rotate(0deg)",
      transition: "transform 0.2s",
      flexShrink: 0
    }
  }, React.createElement("polyline", {
    points: "6 9 12 15 18 9"
  }))), navOpen && React.createElement("div", {
    style: {
      position: "absolute",
      top: "calc(100% + 6px)",
      right: 0,
      zIndex: 200,
      background: "var(--surface3)",
      border: "1px solid var(--border)",
      borderRadius: 12,
      boxShadow: "0 20px 60px rgba(0,0,0,0.55)",
      minWidth: 230,
      padding: 6
    }
  }, SECTION_NAV.map(s => React.createElement("button", {
    key: s.id,
    onMouseDown: () => scrollTo(s.id),
    style: {
      display: "flex",
      alignItems: "center",
      gap: 10,
      width: "100%",
      textAlign: "left",
      background: "transparent",
      border: "none",
      borderRadius: 8,
      padding: "9px 12px",
      fontSize: 13,
      color: "var(--text)",
      cursor: "pointer",
      transition: "background 0.1s",
      fontFamily: "var(--font-body)"
    },
    onMouseEnter: e => e.currentTarget.style.background = "rgba(255,255,255,0.07)",
    onMouseLeave: e => e.currentTarget.style.background = "transparent"
  }, React.createElement("span", {
    style: {
      width: 22,
      textAlign: "center",
      fontSize: 13,
      flexShrink: 0
    }
  }, s.icon), React.createElement("span", {
    style: {
      flex: 1
    }
  }, s.label), React.createElement("svg", {
    width: "12",
    height: "12",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "var(--text3)",
    strokeWidth: "2.5",
    strokeLinecap: "round"
  }, React.createElement("polyline", {
    points: "9 18 15 12 9 6"
  }))))))));
}
function SettingsPage({
  apiKey,
  onChangeApiKey,
  initialSection
}) {
  const [downloadPath, setDownloadPath] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.DOWNLOAD_PATH) || "");
  const [watchedThreshold, setWatchedThreshold] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.WATCHED_THRESHOLD) ?? 20);
  const [introSkipMode, setIntroSkipMode] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.INTRO_SKIP_MODE) || "off");
  const [autoplayNextEnabled, setAutoplayNextEnabled] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.AUTOPLAY_NEXT_ENABLED) ?? true);
  const [autoplayNextDuration, setAutoplayNextDuration] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.AUTOPLAY_NEXT_DURATION) ?? 5);
  const [autoplayNextLayout, setAutoplayNextLayout] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.AUTOPLAY_NEXT_LAYOUT) || "right");
  const [saved, setSaved] = (0, _react.useState)(false);
  const [showResetConfirm, setShowResetConfirm] = (0, _react.useState)(false);
  const [resetHovered, setResetHovered] = (0, _react.useState)(false);
  const [showProgressConfirm, setShowProgressConfirm] = (0, _react.useState)(false);
  const [showDeleteDlConfirm, setShowDeleteDlConfirm] = (0, _react.useState)(false);
  const secUpdates = (0, _react.useRef)(null);
  const secContent = (0, _react.useRef)(null);
  const secPlayback = (0, _react.useRef)(null);
  const secSubtitles = (0, _react.useRef)(null);
  const secDownloads = (0, _react.useRef)(null);
  const secNotifications = (0, _react.useRef)(null);
  const secDiscordRpc = (0, _react.useRef)(null);
  const secInterface = (0, _react.useRef)(null);
  const secLibrary = (0, _react.useRef)(null);
  const secBackup = (0, _react.useRef)(null);
  const secStorage = (0, _react.useRef)(null);
  const sectionRefs = {
    updates: secUpdates,
    content: secContent,
    playback: secPlayback,
    subtitles: secSubtitles,
    downloads: secDownloads,
    notifications: secNotifications,
    discordRpc: secDiscordRpc,
    interface: secInterface,
    library: secLibrary,
    backup: secBackup,
    storage: secStorage
  };
  const contentRef = (0, _react.useRef)(null);
  (0, _react.useEffect)(() => {
    if (!initialSection) return;
    const el = sectionRefs[initialSection]?.current;
    if (!el) return;
    const t = setTimeout(() => {
      el.scrollIntoView({
        behavior: "smooth",
        block: "start"
      });
    }, 120);
    return () => clearTimeout(t);
  }, []);
  const [ratingCountry, setRatingCountry] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.RATING_COUNTRY) || "US");
  const [ageLimit, setAgeLimit] = (0, _react.useState)(() => {
    const v = _storage.storage.get(_storage.STORAGE_KEYS.AGE_LIMIT);
    return v === null || v === undefined ? "" : String(v);
  });
  const [ageSaved, setAgeSaved] = (0, _react.useState)(false);
  const saveAgeSettings = () => {
    _storage.storage.set(_storage.STORAGE_KEYS.RATING_COUNTRY, ratingCountry);
    if (ageLimit === "" || ageLimit === null) {
      _storage.storage.remove(_storage.STORAGE_KEYS.AGE_LIMIT);
    } else {
      _storage.storage.set(_storage.STORAGE_KEYS.AGE_LIMIT, Number(ageLimit));
    }
    setAgeSaved(true);
    setTimeout(() => setAgeSaved(false), 2000);
  };
  const [invidiousBase, setInvidiousBase] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.INVIDIOUS_BASE) || _TrailerModal.DEFAULT_INVIDIOUS_BASE);
  const [invidiousStatus, setInvidiousStatus] = (0, _react.useState)(null);
  const [invidiousChecking, setInvidiousChecking] = (0, _react.useState)(false);
  const [invidiousSaved, setInvidiousSaved] = (0, _react.useState)(false);
  const checkInvidious = async baseUrl => {
    const clean = (baseUrl || "").trim().replace(/\/$/, "");
    if (!clean) {
      setInvidiousStatus({
        ok: false,
        msg: "Please enter a URL first."
      });
      return;
    }
    setInvidiousChecking(true);
    setInvidiousStatus(null);
    try {
      const url = `${clean}/api/v1/stats`;
      const res = await fetch(url, {
        signal: AbortSignal.timeout(6000)
      });
      if (res.ok) {
        setInvidiousStatus({
          ok: true,
          msg: "Instance reachable and responding."
        });
      } else {
        setInvidiousStatus({
          ok: false,
          msg: `Server responded with status ${res.status}.`
        });
      }
    } catch (e) {
      setInvidiousStatus({
        ok: false,
        msg: "Could not reach instance. Check the URL or try another."
      });
    } finally {
      setInvidiousChecking(false);
    }
  };
  const saveInvidiousBase = () => {
    const clean = (invidiousBase || "").trim().replace(/\/$/, "");
    _storage.storage.set(_storage.STORAGE_KEYS.INVIDIOUS_BASE, clean || _TrailerModal.DEFAULT_INVIDIOUS_BASE);
    setInvidiousBase(clean || _TrailerModal.DEFAULT_INVIDIOUS_BASE);
    setInvidiousSaved(true);
    setTimeout(() => setInvidiousSaved(false), 2000);
  };
  const [sizes, setSizes] = (0, _react.useState)({
    cache: null,
    downloads: null
  });
  (0, _react.useEffect)(() => {
    if (typeof window === "undefined" || !window.electron) {
      setSizes({
        cache: -1,
        downloads: -1
      });
      return;
    }
    (async () => {
      try {
        const [cacheRes, downloadsRes] = await Promise.all([window.electron.getCacheSize?.() ?? null, window.electron.getDownloadsSize?.() ?? null]);
        setSizes({
          cache: cacheRes?.bytes ?? -1,
          downloads: downloadsRes?.bytes ?? -1
        });
      } catch {
        setSizes({
          cache: -1,
          downloads: -1
        });
      }
    })();
  }, []);
  const pickFolder = async () => {
    if (!_storage.isElectron) return;
    const folder = await window.electron.pickFolder();
    if (folder) {
      setDownloadPath(folder);
      _storage.storage.set(_storage.STORAGE_KEYS.DOWNLOAD_PATH, folder);
      flash();
    }
  };
  const handleSavePath = () => {
    _storage.storage.set(_storage.STORAGE_KEYS.DOWNLOAD_PATH, downloadPath);
    flash();
  };
  const handleSaveThreshold = () => {
    const val = Math.max(1, Math.min(300, Number(watchedThreshold) || 20));
    setWatchedThreshold(val);
    _storage.storage.set(_storage.STORAGE_KEYS.WATCHED_THRESHOLD, val);
    flash();
  };
  const flash = () => {
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };
  const handleClearCache = async () => {
    await (0, _storage.clearAppCaches)();
    setSizes(prev => ({
      ...prev,
      cache: 0
    }));
    return {
      msg: "✓ Cache cleared successfully"
    };
  };
  const handleClearWatchProgress = async () => {
    _storage.storage.remove(_storage.STORAGE_KEYS.WATCH_PROGRESS);
    _storage.storage.remove(_storage.STORAGE_KEYS.HISTORY);
    _storage.storage.remove(_storage.STORAGE_KEYS.WATCHED);
    if (_storage.isElectron) await window.electron.clearWatchData();
    setTimeout(() => window.location.reload(), 800);
    return {
      msg: "✓ Watch data cleared"
    };
  };
  const handleDeleteAllDownloads = async () => {
    let msg = "✓ All downloads removed";
    setSizes(prev => ({
      ...prev,
      downloads: 0
    }));
    if (_storage.isElectron) {
      const res = await window.electron.deleteAllDownloads();
      if (res?.deleted != null) {
        msg = `✓ Removed ${res.deleted} file${res.deleted !== 1 ? "s" : ""}`;
        if (res.errors > 0) msg += ` (${res.errors} could not be deleted)`;
      }
    } else {
      _storage.storage.remove(_storage.STORAGE_KEYS.LOCAL_FILES);
    }
    return {
      msg
    };
  };
  const handleResetApp = async () => {
    setShowResetConfirm(false);
    if (_storage.isElectron) await window.electron.resetApp();
    _storage.storage.clearAll();
    for (const key of Object.keys(localStorage)) {
      if (key.startsWith("dlDur_")) localStorage.removeItem(key);
    }
    window.location.reload();
  };
  return React.createElement(React.Fragment, null, showProgressConfirm && React.createElement(ConfirmDialog, {
    title: "CLEAR WATCH PROGRESS?",
    description: "This will permanently delete all watch history, continue-watching progress, and watched/completed markings for all movies and series.",
    confirmLabel: "Yes, Clear Everything",
    onConfirm: async () => {
      setShowProgressConfirm(false);
      await handleClearWatchProgress();
      window.__progressConfirmResolve?.({
        msg: "✓ Watch data cleared"
      });
      window.__progressConfirmResolve = null;
    },
    onCancel: () => {
      setShowProgressConfirm(false);
      window.__progressConfirmResolve?.({
        cancelled: true
      });
      window.__progressConfirmResolve = null;
    }
  }), showDeleteDlConfirm && React.createElement(ConfirmDialog, {
    title: "DELETE ALL DOWNLOADS?",
    description: "This will permanently delete all video files downloaded through SingularityTV and remove them from the download list.",
    confirmLabel: "Yes, Delete All",
    onConfirm: async () => {
      setShowDeleteDlConfirm(false);
      const result = await handleDeleteAllDownloads();
      window.__deleteDlConfirmResolve?.(result);
      window.__deleteDlConfirmResolve = null;
    },
    onCancel: () => {
      setShowDeleteDlConfirm(false);
      window.__deleteDlConfirmResolve?.({
        cancelled: true
      });
      window.__deleteDlConfirmResolve = null;
    }
  }), showResetConfirm && React.createElement(ResetConfirmDialog, {
    onConfirm: handleResetApp,
    onCancel: () => setShowResetConfirm(false)
  }), React.createElement(SettingsTopBar, {
    sectionRefs: sectionRefs,
    contentRef: contentRef
  }), React.createElement("div", {
    ref: contentRef,
    className: "fade-in",
    style: {
      padding: "40px 48px 80px"
    }
  }, React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 48,
      letterSpacing: 1,
      marginBottom: 6
    }
  }, "SETTINGS"), React.createElement("div", {
    style: {
      color: "var(--text3)",
      fontSize: 14,
      marginBottom: 48
    }
  }, "SingularityTV · Developed by @ec1lz (t.me/ec1lz)"), React.createElement("div", {
    ref: secUpdates,
    style: {
      scrollMarginTop: 80
    }
  }, React.createElement(SectionGroupHeader, {
    title: "General",
    subtitle: "App version, updates, and metadata language preferences"
  }), React.createElement(VersionSection, null)), React.createElement("div", {
    ref: secContent,
    style: {
      scrollMarginTop: 80
    }
  }, React.createElement(SectionGroupHeader, {
    title: "Content",
    subtitle: "Parental controls and content filtering by age rating"
  }), React.createElement("div", {
    style: {
      marginBottom: 40
    }
  }, React.createElement("div", {
    className: "settings-section-title"
  }, "Age Rating & Parental Controls"), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      marginBottom: 20,
      lineHeight: 1.6
    }
  }, "Set a maximum age rating. Content rated above this age will still be visible but", " ", React.createElement("strong", {
    style: {
      color: "var(--text)"
    }
  }, "you won't be able to play it."), " ", "Set to ", React.createElement("em", null, "No restriction"), " to disable this feature entirely."), React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 16
    }
  }, React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: "var(--text2)",
      marginBottom: 8
    }
  }, "Rating Country"), React.createElement(SettingsSelect, {
    value: ratingCountry,
    onChange: v => setRatingCountry(v),
    options: _ageRating.RATING_COUNTRIES.map(c => ({
      value: c.code,
      label: c.label
    }))
  })), React.createElement("div", null, React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 600,
      color: "var(--text2)",
      marginBottom: 8
    }
  }, "Maximum Allowed Age Rating"), React.createElement(SettingsSelect, {
    value: ageLimit,
    onChange: v => setAgeLimit(v),
    options: AGE_LIMIT_OPTIONS
  })), React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, React.createElement("button", {
    className: "btn btn-primary",
    onClick: saveAgeSettings
  }, "Save"), ageSaved && React.createElement("span", {
    style: {
      fontSize: 13,
      color: "#48c774"
    }
  }, "\u2713 Saved"))))), React.createElement("div", {
    ref: secSubtitles,
    style: {
      scrollMarginTop: 80
    }
  }, React.createElement(SectionGroupHeader, {
    title: "Subtitles",
    subtitle: "Subtitle download source, preferred language, and API key"
  }), React.createElement(SubtitleSettingsSection, null)), React.createElement("div", {
    ref: secDownloads,
    style: {
      scrollMarginTop: 80
    }
  }, React.createElement(SectionGroupHeader, {
    title: "Downloads",
    subtitle: "Where downloaded video files are saved on disk"
  }), React.createElement("div", {
    style: {
      marginBottom: 40
    }
  }, React.createElement("div", {
    className: "settings-section-title"
  }, "Download Folder"), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      marginBottom: 16,
      lineHeight: 1.6
    }
  }, "Downloaded videos will be saved here. Make sure the folder exists and SingularityTV has write access to it."), React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      alignItems: "center",
      flexWrap: "wrap"
    }
  }, React.createElement("input", {
    className: "apikey-input",
    style: {
      flex: 1,
      minWidth: 260,
      marginBottom: 0
    },
    placeholder: "/home/you/Movies",
    value: downloadPath,
    onChange: e => setDownloadPath(e.target.value)
  }), _storage.isElectron && React.createElement("button", {
    className: "btn btn-secondary",
    onClick: pickFolder
  }, "Browse \u2026"), React.createElement("button", {
    className: "btn btn-primary",
    onClick: handleSavePath
  }, "Save")), saved && React.createElement("div", {
    style: {
      marginTop: 10,
      fontSize: 13,
      color: "#4caf50"
    }
  }, "\u2713 Saved"), !downloadPath && React.createElement("div", {
    style: {
      marginTop: 10,
      fontSize: 13,
      color: "var(--red)"
    }
  }, "\u26A0 No download folder set - videos cannot be downloaded until you set one."))), React.createElement("div", {
    ref: secNotifications,
    style: {
      scrollMarginTop: 80
    }
  }, React.createElement(SectionGroupHeader, {
    title: "Notifications",
    subtitle: "Desktop alerts for downloads and new episode releases"
  }), React.createElement(NotificationsSection, null)), React.createElement("div", {
    ref: secInterface,
    style: {
      scrollMarginTop: 80
    }
  }, React.createElement(SectionGroupHeader, {
    title: "Interface",
    subtitle: "Home layout, start page, appearance, and display options"
  }), React.createElement(HomeLayoutSection, null), React.createElement(Divider, null), React.createElement(StartPageSection, null), React.createElement(Divider, null), React.createElement(AppearanceSection, null)), React.createElement("div", {
    ref: secLibrary,
    style: {
      scrollMarginTop: 80
    }
  }, React.createElement(SectionGroupHeader, {
    title: "Library",
    subtitle: "Watchlist sort order and watch history preferences"
  }), React.createElement(LibraryPrivacySection, null)), React.createElement("div", {
    ref: secBackup,
    style: {
      scrollMarginTop: 80
    }
  }, React.createElement(SectionGroupHeader, {
    title: "Backup & Restore",
    subtitle: "Export your data or restore from a previous backup file"
  }), React.createElement(BackupRestoreSection, null)), React.createElement("div", {
    ref: secStorage,
    style: {
      scrollMarginTop: 80
    }
  }, React.createElement(SectionGroupHeader, {
    title: "Storage & Data",
    subtitle: "Clear cache, watch progress, downloads, or reset the entire app"
  }), React.createElement("div", {
    style: {
      background: "var(--surface)",
      border: "1px solid var(--border)",
      borderRadius: 10,
      overflow: "hidden"
    }
  }, React.createElement("div", {
    style: {
      padding: "22px 24px"
    }
  }, React.createElement(CleanRow, {
    title: "Install Location",
    description: "Opens the folder where SingularityTV is installed.",
    buttonLabel: "Open Folder",
    onAction: async () => {
      const p = await window.electron?.getInstallPath?.();
      if (p) window.electron.openPath(p);
    }
  })), React.createElement("div", {
    style: {
      height: 1,
      background: "var(--border)"
    }
  }), React.createElement("div", {
    style: {
      padding: "22px 24px"
    }
  }, React.createElement(CleanRow, {
    title: "Clear Cache",
    description: "Removes temporary browser cache, shader cache, and service worker data from all internal sessions (main, video player, trailer). Does not affect your personal data or settings.",
    buttonLabel: "Clear Cache",
    onAction: handleClearCache,
    sizeLabel: (0, _storage.formatBytes)(sizes.cache)
  })), React.createElement("div", {
    style: {
      height: 1,
      background: "var(--border)"
    }
  }), React.createElement("div", {
    style: {
      padding: "22px 24px"
    }
  }, React.createElement(CleanRow, {
    title: "Clear Watch Progress",
    description: "Resets all watch history, continue-watching progress, and watched / completed markings for movies and series. Also clears internal video player session data.",
    buttonLabel: "Clear Progress",
    onAction: () => new Promise(resolve => {
      setShowProgressConfirm(true);
      window.__progressConfirmResolve = resolve;
    }),
    danger: true
  })), React.createElement("div", {
    style: {
      height: 1,
      background: "var(--border)"
    }
  }), React.createElement("div", {
    style: {
      padding: "22px 24px"
    }
  }, React.createElement(CleanRow, {
    title: "Delete All Downloads",
    description: "Permanently deletes all video files that were downloaded through SingularityTV and removes them from the download list. Only files downloaded through the app will be deleted, nothing else in your folder is touched.",
    buttonLabel: "Delete All",
    onAction: () => new Promise(resolve => {
      setShowDeleteDlConfirm(true);
      window.__deleteDlConfirmResolve = resolve;
    }),
    sizeLabel: (0, _storage.formatBytes)(sizes.downloads),
    danger: true
  })), React.createElement("div", {
    style: {
      height: 1,
      background: "var(--border)"
    }
  }), React.createElement("div", {
    style: {
      padding: "22px 24px",
      background: "rgba(229,9,20,0.03)"
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "flex-start",
      justifyContent: "space-between",
      gap: 24
    }
  }, React.createElement("div", {
    style: {
      flex: 1
    }
  }, React.createElement("div", {
    style: {
      fontSize: 15,
      fontWeight: 600,
      color: "var(--text)",
      marginBottom: 4,
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, "Reset App", React.createElement("span", {
    style: {
      fontSize: 10,
      fontWeight: 700,
      letterSpacing: 1,
      color: "var(--red)",
      background: "rgba(229,9,20,0.12)",
      border: "1px solid rgba(229,9,20,0.25)",
      padding: "2px 7px",
      borderRadius: 4,
      textTransform: "uppercase"
    }
  }, "Irreversible")), React.createElement("div", {
    style: {
      fontSize: 13,
      color: "var(--text3)",
      lineHeight: 1.6
    }
  }, "Completely resets SingularityTV to factory defaults, clears all settings, API Token, saved library, watch history/progress, and all cached data. Your downloaded video files will not be touched.")), React.createElement("div", {
    style: {
      flexShrink: 0,
      paddingTop: 2
    }
  }, React.createElement("button", {
    className: "btn",
    onClick: () => setShowResetConfirm(true),
    onMouseEnter: () => setResetHovered(true),
    onMouseLeave: () => setResetHovered(false),
    style: {
      color: resetHovered ? "#fff" : "var(--red)",
      background: resetHovered ? "rgba(229,9,20,0.85)" : "rgba(229,9,20,0.08)",
      border: resetHovered ? "1px solid transparent" : "1px solid rgba(229,9,20,0.3)",
      transition: "all 0.2s"
    }
  }, "Reset App"))))))));
}
},
"./pages/TVPage": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = TVPage;
var _react = require("react");
var _episodeMappings = require("../utils/episodeMappings");
var _api = require("../utils/api");
var _Icons = require("../components/Icons");
var _DownloadModal = _interopRequireDefault(require("../components/DownloadModal"));
var _TrailerModal = _interopRequireDefault(require("../components/TrailerModal"));
var _BlockedStatsModal = _interopRequireDefault(require("../components/BlockedStatsModal"));
var _useBlockedStats = require("../utils/useBlockedStats");
var _storage = require("../utils/storage");
var _useAutoplay = require("../utils/useAutoplay");
var _aniSkip = require("../utils/aniSkip");
var _ageRating = require("../utils/ageRating");
var _DownloadConfirmModal = _interopRequireDefault(require("../components/DownloadConfirmModal"));
var _useCredits = require("../utils/useCredits");
var _playerGamepadScript = require("../utils/playerGamepadScript");
var _useSourceId = require("../utils/useSourceId");
var _gamepadPlayerState = require("../utils/gamepadPlayerState");
var _HiAnimeLoader = _interopRequireDefault(require("../components/HiAnimeLoader"));
var _StreamPlayerFrame = _interopRequireDefault(require("../components/StreamPlayerFrame"));
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }
function _makePartialCircle(pct) {
  const r = 5;
  const cx = 7;
  const cy = 7;
  const angle = pct / 100 * 2 * Math.PI - Math.PI / 2;
  const x = cx + r * Math.cos(angle);
  const y = cy + r * Math.sin(angle);
  const large = pct > 50 ? 1 : 0;
  return React.createElement("svg", {
    width: "14",
    height: "14",
    viewBox: "0 0 14 14",
    style: {
      display: "inline-block",
      verticalAlign: "middle",
      marginRight: 4,
      flexShrink: 0
    }
  }, React.createElement("circle", {
    cx: cx,
    cy: cy,
    r: r,
    fill: "none",
    stroke: "currentColor",
    strokeWidth: "1.5",
    opacity: "0.25"
  }), React.createElement("path", {
    d: `M ${cx} ${cy - r} A ${r} ${r} 0 ${large} 1 ${x.toFixed(3)} ${y.toFixed(3)} L ${cx} ${cy} Z`,
    fill: "currentColor",
    opacity: "0.9"
  }));
}
const _CIRCLE_25 = _makePartialCircle(25);
const _CIRCLE_50 = _makePartialCircle(50);
const _CIRCLE_75 = _makePartialCircle(75);
const _CIRCLE_MAP = {
  25: _CIRCLE_25,
  50: _CIRCLE_50,
  75: _CIRCLE_75
};
function PartialCircleIcon({
  pct
}) {
  return _CIRCLE_MAP[pct] ?? null;
}
function ContextMenu({
  x,
  y,
  isWatched,
  hasProgress,
  watchedLabel,
  unwatchedLabel,
  onMarkWatched,
  onMarkUnwatched,
  onMarkNotStarted,
  onClose
}) {
  const onCloseRef = (0, _react.useRef)(onClose);
  onCloseRef.current = onClose;
  (0, _react.useEffect)(() => {
    const close = () => onCloseRef.current();
    window.addEventListener("click", close);
    window.addEventListener("contextmenu", close);
    return () => {
      window.removeEventListener("click", close);
      window.removeEventListener("contextmenu", close);
    };
  }, []);
  return React.createElement("div", {
    className: "context-menu",
    style: {
      top: y,
      left: x
    },
    onClick: e => e.stopPropagation()
  }, isWatched ? React.createElement("button", {
    className: "context-menu-item",
    onClick: e => {
      e.stopPropagation();
      onMarkUnwatched();
      onCloseRef.current();
    }
  }, "\u21A9 ", unwatchedLabel) : React.createElement("button", {
    className: "context-menu-item",
    onClick: e => {
      e.stopPropagation();
      onMarkWatched();
      onCloseRef.current();
    }
  }, "\u2713 ", watchedLabel), onMarkNotStarted && !isWatched && hasProgress && React.createElement("button", {
    className: "context-menu-item",
    onClick: e => {
      e.stopPropagation();
      onMarkNotStarted();
      onCloseRef.current();
    }
  }, "\u2298 Mark as Not Started"));
}
function EpisodeDesc({
  overview,
  episodeName
}) {
  const [open, setOpen] = (0, _react.useState)(false);
  if (!overview) return React.createElement("div", {
    className: "episode-desc"
  });
  return React.createElement(React.Fragment, null, React.createElement("div", {
    className: "episode-desc-wrap"
  }, React.createElement("div", {
    className: "episode-desc"
  }, overview), React.createElement("button", {
    className: "episode-desc-toggle",
    onClick: e => {
      e.stopPropagation();
      setOpen(true);
    }
  }, "More")), open && React.createElement("div", {
    className: "ep-desc-overlay",
    onClick: e => {
      e.stopPropagation();
      setOpen(false);
    }
  }, React.createElement("div", {
    className: "ep-desc-popup",
    onClick: e => e.stopPropagation()
  }, episodeName && React.createElement("div", {
    className: "ep-desc-popup-title"
  }, episodeName), React.createElement("p", {
    className: "ep-desc-popup-text"
  }, overview), React.createElement("button", {
    className: "ep-desc-popup-close",
    onClick: () => setOpen(false)
  }, "Close"))));
}
const INJECT_SKIP_CONTROLS = `
(function() {
  if (window.__skipControlsInjected) return;
  var style = document.createElement('style');
  style.innerHTML =
    '*:focus, *:focus-visible {' +
    'outline: none !important;' +
    'box-shadow: none !important;' +
    '}' +
    'video:focus, video:focus-visible {' +
    'outline: none !important;' +
    'box-shadow: none !important;' +
    '}';
  document.head.appendChild(style);
  window.__skipControlsInjected = true;

  var BACK_SVG = '<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" style=\"width:26px;height:26px\"><polyline points=\"1 4 1 10 7 10\"/><path d=\"M3.51 15a9 9 0 1 0 .49-4.53\"/><text x=\"13.5\" y=\"15.5\" text-anchor=\"middle\" font-size=\"6.5\" fill=\"currentColor\" stroke=\"none\" font-weight=\"800\" font-family=\"system-ui,sans-serif\">15</text></svg>';
  var FWD_SVG  = '<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2.2\" stroke-linecap=\"round\" stroke-linejoin=\"round\" style=\"width:26px;height:26px\"><polyline points=\"23 4 23 10 17 10\"/><path d=\"M20.49 15a9 9 0 1 1-.49-4.53\"/><text x=\"10.5\" y=\"15.5\" text-anchor=\"middle\" font-size=\"6.5\" fill=\"currentColor\" stroke=\"none\" font-weight=\"800\" font-family=\"system-ui,sans-serif\">15</text></svg>';

  var wrap = document.createElement('div');
  wrap.id = '__skip-ui';
  wrap.style.cssText = [
    'position:fixed',
    'top:0','left:0','right:0','bottom:0',
    'pointer-events:none',
    'z-index:2147483647',
    'opacity:0',
    'transition:opacity 0.25s ease',
  ].join(';');

  function makeBtn(seconds, svg, label, side) {
    var btn = document.createElement('button');
    btn.innerHTML = svg + '<span style="font-size:11px;font-family:system-ui,sans-serif">' + label + '</span>';
    btn.setAttribute('tabindex', '-1');
    btn.title = label;
    btn.style.cssText = [
      'pointer-events:auto',
      'background:rgba(0,0,0,0.72)',
      'border:1px solid rgba(255,255,255,0.18)',
      'border-radius:8px',
      'color:white',
      'cursor:pointer',
      'padding:10px 18px',
      'display:flex',
      'align-items:center',
      'gap:7px',
      'backdrop-filter:blur(6px)',
      '-webkit-backdrop-filter:blur(6px)',
      'transition:background 0.15s',
      'font-size:12px',
    ].join(';');
    btn.style.position = 'absolute';
    btn.style.top = '50%';
    btn.style.transform = 'translateY(-50%)';

    if (side === 'left') {
      btn.style.left = '24px';
    } else {
      btn.style.right = '24px';
    }
    btn.onmouseenter = function() { btn.style.background = 'rgba(229,9,20,0.85)'; btn.style.borderColor = '#e5091466'; };
    btn.onmouseleave = function() { btn.style.background = 'rgba(0,0,0,0.72)'; btn.style.borderColor = 'rgba(255,255,255,0.18)'; };
    btn.onclick = function(e) {
      e.stopPropagation();
      var v = document.querySelector('video');
      if (v) v.currentTime = Math.max(0, Math.min(v.duration || 0, v.currentTime + seconds));
      show();
    };
    return btn;
  }

  wrap.appendChild(makeBtn(-15, BACK_SVG, '−15s', 'left'));
  wrap.appendChild(makeBtn(15,  FWD_SVG,  '+15s', 'right'));
  document.documentElement.appendChild(wrap);

  var idleTimer;
  function show() {
    wrap.style.opacity = '1';
    clearTimeout(idleTimer);
    idleTimer = setTimeout(function() { wrap.style.opacity = '0'; }, 2500);
  }
  document.addEventListener('mousemove', show, true);
  document.addEventListener('keydown', function(e) {
    const active = document.activeElement;

    // Keine Shortcuts wenn User tippt
    if (
      active &&
      active.matches('input, textarea, [contenteditable="true"]')
    ) {
      return;
    }

    // Key repeat blockieren (wenn Taste gehalten wird)
    if (e.repeat) return;

    const v = document.querySelector('video');
    if (!v) return;

    // Throttle (max 1 Aktion alle 250ms)
    const now = Date.now();
    if (window.__skipKeyCooldown && now < window.__skipKeyCooldown) return;
    window.__skipKeyCooldown = now + 250;

    if (e.code === 'Space') {
      e.preventDefault(); // verhindert Scrollen
      if (v.paused) v.play();
      else v.pause();
      show();
    }

    if (e.key === 'ArrowLeft') {
      v.currentTime = Math.max(0, v.currentTime - 10);
      show();
    }

    if (e.key === 'ArrowRight') {
      v.currentTime = Math.min(v.duration || 0, v.currentTime + 10);
      show();
    }
  }, true);
})();
`;
function parseAirDate(airDate) {
  if (!airDate) return null;
  const [y, m, d] = String(airDate).slice(0, 10).split("-").map(Number);
  if (!y || !m || !d) return null;
  return new Date(y, m - 1, d);
}
function startOfToday() {
  const t = new Date();
  t.setHours(0, 0, 0, 0);
  return t;
}
function isUnreleased(airDate) {
  const target = parseAirDate(airDate);
  return !!target && target > startOfToday();
}
function getDaysUntilRelease(airDate) {
  const target = parseAirDate(airDate);
  if (!target) return "";
  const days = Math.round((target - startOfToday()) / 86400000);
  if (days <= 0) return "Releasing today";
  if (days === 1) return "1 day left";
  return `${days} days left`;
}
function TVPage({
  item,
  apiKey,
  playerSettings,
  onSave,
  isSaved,
  onHistory,
  progress,
  saveProgress,
  onBack,
  onSettings,
  onDownloadStarted,
  watched,
  onMarkWatched,
  onMarkUnwatched,
  downloads,
  onGoToDownloads,
  onEpisodeChange,
  onOpenExoPlayer
}) {
  const [details, setDetails] = (0, _react.useState)(null);
  const [seasonData, setSeasonData] = (0, _react.useState)(null);
  const [failedSeasons, setFailedSeasons] = (0, _react.useState)(() => new Set());
  const [selectedSeason, setSelectedSeason] = (0, _react.useState)(() => item.season != null ? Number(item.season) : 1);
  const [selectedEp, setSelectedEp] = (0, _react.useState)(null);
  const [playing, setPlaying] = (0, _react.useState)(false);
  const [loading, setLoading] = (0, _react.useState)(true);
  const [loadingSeason, setLoadingSeason] = (0, _react.useState)(false);
  const [showDownload, setShowDownload] = (0, _react.useState)(false);
  const [trailerKey, setTrailerKey] = (0, _react.useState)(null);
  const [showTrailer, setShowTrailer] = (0, _react.useState)(false);
  const [downloadConfirm, setDownloadConfirm] = (0, _react.useState)(null);
  const [pendingEpDownload, setPendingEpDownload] = (0, _react.useState)(false);
  const credits = (0, _useCredits.useCredits)("tv", item.id, apiKey);
  const [m3u8Url, setM3u8Url] = (0, _react.useState)(null);
  const m3u8FoundRef = (0, _react.useRef)(false);
  const autoExoLaunchedRef = (0, _react.useRef)(null);
  const pendingFailoverRef = (0, _react.useRef)(false);
  m3u8FoundRef.current = !!m3u8Url;
  const [interceptedSubs, setInterceptedSubs] = (0, _react.useState)([]);
  const [playerSource, setPlayerSource] = (0, _react.useState)(() => _storage.storage.get("playerSource") || _api.NON_ANIME_DEFAULT_SOURCE);
  const playerAccentColor = playerSettings?.accentColor ?? null;
  const playerSubLang = playerSettings?.subtitleLang ?? null;
  const [showSourceMenu, setShowSourceMenu] = (0, _react.useState)(false);
  const isAsync = (0, _react.useMemo)(() => (0, _api.sourceIsAsync)(playerSource), [playerSource]);
  const supportsProgress = (0, _react.useMemo)(() => (0, _api.sourceSupportsProgress)(playerSource), [playerSource]);
  const progressViaFrames = (0, _react.useMemo)(() => (0, _api.sourceProgressViaFrames)(playerSource), [playerSource]);
  const [dubMode, setDubMode] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.HIANIME_DUB_MODE) || "sub");
  const [resolvedPlayerUrl, setResolvedPlayerUrl] = (0, _react.useState)(null);
  const [resolvingUrl, setResolvingUrl] = (0, _react.useState)(false);
  const [resolveError, setResolveError] = (0, _react.useState)(null);
  const resolvingUrlRef = (0, _react.useRef)(false);
  const resolvedPlayerUrlRef = (0, _react.useRef)(null);
  const [anilistData, setAnilistData] = (0, _react.useState)(null);
  const [anilistSeasons, setAnilistSeasons] = (0, _react.useState)(null);
  const [anilistLoading, setAnilistLoading] = (0, _react.useState)(false);
  const [episodeGroupData, setEpisodeGroupData] = (0, _react.useState)(null);
  const [episodeGroupMap, setEpisodeGroupMap] = (0, _react.useState)(null);
  const [webviewLoading, setWebviewLoading] = (0, _react.useState)(false);
  const srcId = (0, _useSourceId.useSourceId)(playerSource, "tv", item.id, apiKey);
  (0, _react.useEffect)(() => {
    if (srcId.id && playing) setWebviewLoading(true);
  }, [srcId.id]);
  const [playerFullscreen, setPlayerFullscreen] = (0, _react.useState)(false);
  const togglePlayerFullscreen = (0, _react.useCallback)(forceState => {
    setPlayerFullscreen(prev => {
      const next = typeof forceState === "boolean" ? forceState : !prev;
      if (next) {
        document.documentElement.setAttribute("data-player-fullscreen", "1");
        try {
          window.AndroidBridge?.setImmersiveMode?.(true);
        } catch {}
      } else {
        document.documentElement.removeAttribute("data-player-fullscreen");
      }
      return next;
    });
  }, []);
  (0, _react.useEffect)(() => {
    window.__streambertExitFullscreen = () => {
      setPlaying(false);
      setPlayerFullscreen(false);
      document.documentElement.removeAttribute("data-player-fullscreen");
    };
    return () => {
      if (window.__streambertExitFullscreen) delete window.__streambertExitFullscreen;
      document.documentElement.removeAttribute("data-player-fullscreen");
    };
  }, [togglePlayerFullscreen]);
  const [pipOpen, setPipOpen] = (0, _react.useState)(false);
  const pipUrlRef = (0, _react.useRef)(null);
  const pipWebContentsIdRef = (0, _react.useRef)(null);
  const [menuPos, setMenuPos] = (0, _react.useState)(null);
  const [skipTimings, setSkipTimings] = (0, _react.useState)(null);
  const [skipPrompt, setSkipPrompt] = (0, _react.useState)(null);
  const [introSkipMode] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.INTRO_SKIP_MODE) || "off");
  const sourceRef = (0, _react.useRef)(null);
  const playerWrapRef = (0, _react.useRef)(null);
  const webviewRef = (0, _react.useRef)(null);
  const saveProgressRef = (0, _react.useRef)(saveProgress);
  saveProgressRef.current = saveProgress;
  const onMarkWatchedRef = (0, _react.useRef)(onMarkWatched);
  onMarkWatchedRef.current = onMarkWatched;
  const watchedRef = (0, _react.useRef)(watched);
  watchedRef.current = watched;
  const isAnime = (0, _react.useMemo)(() => (0, _api.isAnimeContent)(item, details), [item.id, details]);
  const [downloaderFolder, setDownloaderFolder] = (0, _react.useState)(() => _storage.storage.get("downloaderFolder") || "");
  const [epMenu, setEpMenu] = (0, _react.useState)(null);
  const blockedResetKey = `${item.id}_s${selectedSeason}_e${selectedEp?.episode_number ?? 0}`;
  const {
    sessionTotal: blockedSession,
    alltimeTotal: blockedAlltime,
    showModal: showBlockedModal,
    setShowModal: setShowBlockedModal,
    getSessionDomains: getBlockedDomains
  } = (0, _useBlockedStats.useBlockedStats)(blockedResetKey);
  const [rating, setRating] = (0, _react.useState)({
    cert: null,
    minAge: null
  });
  const ageLimitSetting = (0, _react.useMemo)(() => (0, _ageRating.getAgeLimitSetting)(_storage.storage), []);
  const ratingCountry = (0, _react.useMemo)(() => (0, _ageRating.getRatingCountry)(_storage.storage), []);
  const restricted = (0, _ageRating.isRestricted)(rating.minAge, ageLimitSetting);
  const [seasonMenu, setSeasonMenu] = (0, _react.useState)(null);
  (0, _react.useEffect)(() => {
    if (!onEpisodeChange) return;
    if (!selectedEp) {
      onEpisodeChange(null);
      return;
    }
    onEpisodeChange({
      season: selectedSeason,
      episode: selectedEp.episode_number,
      episodeName: selectedEp.name || null
    });
  }, [onEpisodeChange, selectedSeason, selectedEp?.episode_number]);
  const resetAutoplayRef = (0, _react.useRef)(() => {});
  const triggerAutoplayRef = (0, _react.useRef)(() => {});
  const setCountdownStartedRef = (0, _react.useRef)(() => {});
  const localCountdownStartedRef = (0, _react.useRef)(false);
  const [watchedThreshold] = (0, _react.useState)(() => _storage.storage.get("watchedThreshold") ?? 20);
  const autoMarkedRef = (0, _react.useRef)(false);
  const lastKnownTimeRef = (0, _react.useRef)(0);
  const durationRef = (0, _react.useRef)(0);
  const seekBackCooldownRef = (0, _react.useRef)(0);
  (0, _react.useEffect)(() => {
    let mounted = true;
    setLoading(true);
    (0, _api.tmdbFetch)(`/tv/${item.id}`, apiKey).then(d => {
      if (!mounted) return;
      setDetails(d);
      if (item.season == null) {
        const validSeasons = (d.seasons || []).filter(s => s.season_number > 0);
        const incomplete = validSeasons.find(s => {
          const count = s.episode_count || 0;
          if (!count) return false;
          for (let i = 1; i <= count; i++) {
            if (!watchedRef.current?.[`tv_${item.id}_s${s.season_number}e${i}`]) return true;
          }
          return false;
        });
        const target = incomplete || validSeasons[0] || d.seasons?.[0];
        if (target) setSelectedSeason(target.season_number);
      }
    }).catch(() => {
      if (mounted) setDetails(item);
    }).finally(() => {
      if (mounted) setLoading(false);
    });
    return () => {
      mounted = false;
    };
  }, [item.id, apiKey]);
  (0, _react.useEffect)(() => {
    const groupId = _episodeMappings.EPISODE_GROUP_IDS[Number(item.id)];
    if (!groupId || !apiKey) {
      setEpisodeGroupData(null);
      setEpisodeGroupMap(null);
      return;
    }
    let mounted = true;
    (0, _api.fetchEpisodeGroup)(groupId, apiKey).then(data => {
      if (!mounted) return;
      setEpisodeGroupData(data);
      setEpisodeGroupMap((0, _episodeMappings.buildEpisodeGroupMap)(data));
    }).catch(() => {
      if (mounted) {
        setEpisodeGroupData(null);
        setEpisodeGroupMap(null);
      }
    });
    return () => {
      mounted = false;
    };
  }, [item.id, apiKey]);
  (0, _react.useEffect)(() => {
    let mounted = true;
    (0, _api.tmdbFetch)(`/tv/${item.id}/videos`, apiKey).then(data => {
      if (!mounted) return;
      const videos = data.results || [];
      const trailer = videos.find(v => v.type === "Trailer" && v.site === "YouTube") || videos.find(v => v.site === "YouTube");
      if (trailer) setTrailerKey(trailer.key);
    }).catch(() => {});
    return () => {
      mounted = false;
    };
  }, [item.id, apiKey]);
  (0, _react.useEffect)(() => {
    let mounted = true;
    (0, _ageRating.fetchTVRating)(item.id, apiKey, ratingCountry).then(r => {
      if (mounted) setRating(r);
    });
    return () => {
      mounted = false;
    };
  }, [item.id, apiKey, ratingCountry]);
  (0, _react.useEffect)(() => {
    if (!apiKey || !item.id) return;
    if (episodeGroupData) {
      setSelectedEp(null);
      setPlaying(false);
      setSeasonData(null);
      setLoadingSeason(false);
      return;
    }
    setLoadingSeason(true);
    setSelectedEp(null);
    setPlaying(false);
    setSeasonData(null);
    const tmdbSeasonToFetch = isAnime && anilistSeasons?.length > 0 && tmdbSeasons.length <= 1 ? 1 : selectedSeason;
    let mounted = true;
    (0, _api.tmdbFetch)(`/tv/${item.id}/season/${tmdbSeasonToFetch}`, apiKey).then(d => {
      if (mounted) setSeasonData(d);
    }).catch(() => {
      if (mounted) {
        setSeasonData(null);
        if (selectedSeason === 0) {
          setFailedSeasons(prev => new Set([...prev, selectedSeason]));
        }
      }
    }).finally(() => {
      if (mounted) setLoadingSeason(false);
    });
    return () => {
      mounted = false;
    };
  }, [item.id, selectedSeason, apiKey, anilistSeasons]);
  (0, _react.useEffect)(() => {
    setM3u8Url(null);
    setInterceptedSubs([]);
    setShowSourceMenu(false);
    resolvedPlayerUrlRef.current = null;
    setResolvedPlayerUrl(null);
    resolvingUrlRef.current = false;
    setResolvingUrl(false);
    setResolveError(null);
    setWebviewLoading(true);
  }, [item.id, selectedEp?.episode_number, selectedSeason, playerSource, dubMode]);
  (0, _react.useEffect)(() => {
    let mounted = true;
    setAnilistData(null);
    setAnilistSeasons(null);
    if (isAnime) {
      setAnilistLoading(true);
      (0, _api.fetchAnilistData)(item.name || item.title, "ANIME", item.id).then(data => {
        if (!mounted) return;
        if (data) {
          setAnilistData(data);
          const seasons = (0, _api.buildAnilistSeasons)(data);
          if (seasons?.length) setAnilistSeasons(seasons);
        }
        if (mounted) setAnilistLoading(false);
      }).catch(() => {
        if (mounted) setAnilistLoading(false);
      });
      if (!(0, _api.sourceIsAnimeCapable)(playerSource)) {
        const saved = _storage.storage.get("playerSource");
        setPlayerSource((0, _api.sourceIsAnimeCapable)(saved) ? saved : _api.ANIME_DEFAULT_SOURCE);
      }
    } else {
      setAnilistLoading(false);
      const currentSrc = _api.PLAYER_SOURCES.find(s => s.id === playerSource);
      if (currentSrc?.tag === "ANIME") {
        const saved = _storage.storage.get("playerSource");
        const savedSrc = _api.PLAYER_SOURCES.find(s => s.id === saved);
        setPlayerSource(savedSrc?.tag !== "ANIME" ? saved : _api.NON_ANIME_DEFAULT_SOURCE);
      }
    }
    return () => {
      mounted = false;
    };
  }, [item.id, isAnime]);
  (0, _react.useEffect)(() => {
    if ((0, _api.sourceIsMovieOnly)(playerSource)) {
      setPlayerSource(_api.NON_ANIME_DEFAULT_SOURCE);
    }
  }, [playerSource]);
  (0, _react.useEffect)(() => {
    if (!playing || !selectedEp) return;
    const epNum = selectedEp.episode_number;
    const epKey = `tv_${item.id}_s${selectedSeason}_e${epNum}_${dubMode}`;
    if (isAsync) {
      const cached = (0, _storage.getFailoverSource)(epKey);
      if (cached && cached !== playerSource) {
        setM3u8Url(null);
        setInterceptedSubs([]);
        resolvedPlayerUrlRef.current = null;
        setResolvedPlayerUrl(null);
        resolvingUrlRef.current = false;
        setResolvingUrl(false);
        setResolveError(null);
        setPlayerSource(cached);
        return;
      }
    }
    if (!isAsync) return;
    if (resolvedPlayerUrlRef.current || resolvingUrlRef.current) return;
    resolvingUrlRef.current = true;
    setResolvingUrl(true);
    setResolveError(null);
    const progressKey = `tv_${item.id}_s${selectedSeason}e${epNum}`;
    const startTime = _storage.storage.get("dlTime_" + progressKey) || 0;
    let mounted = true;
    window.electron.resolveHiAnime({
      title,
      seasonNumber: selectedSeason,
      episodeNumber: epNum,
      translationType: dubMode
    }).then(res => {
      if (!mounted) return;
      if (res?.ok && res.url) {
        (0, _storage.clearFailoverSource)(epKey);
        if (res.isDirectMp4 !== undefined) {
          window.electron.setPlayerVideo({
            url: res.url,
            referer: res.referer || "https://hianime.at/",
            subtitle: res.subtitle || null,
            startTime
          }).then(r => {
            if (!mounted) return;
            resolvedPlayerUrlRef.current = r.playerUrl;
            setResolvedPlayerUrl(r.playerUrl);
            setM3u8Url(res.url);
          }).catch(() => {
            if (mounted) setResolveError("Failed to start local player");
          });
        } else {
          resolvedPlayerUrlRef.current = res.url;
          setResolvedPlayerUrl(res.url);
        }
      } else {
        const next = (0, _api.getNextNonAsyncSource)(playerSource);
        if (next) {
          (0, _storage.setFailoverSource)(epKey, next);
          setM3u8Url(null);
          setInterceptedSubs([]);
          resolvedPlayerUrlRef.current = null;
          setResolvedPlayerUrl(null);
          setResolveError(null);
          setPlayerSource(next);
        } else {
          setResolveError(res?.error || "Episode not found on HiAnime");
        }
      }
    }).catch(e => {
      if (mounted) setResolveError(e.message || "Error");
    }).finally(() => {
      if (mounted) {
        resolvingUrlRef.current = false;
        setResolvingUrl(false);
      }
    });
    return () => {
      mounted = false;
    };
  }, [playing, selectedEp, playerSource, selectedSeason, dubMode]);
  (0, _react.useEffect)(() => {
    if (!window.electron) return;
    const handler = window.electron.onM3u8Found(url => {
      setM3u8Url(prev => prev !== url ? url : prev);
    });
    return () => window.electron.offM3u8Found(handler);
  }, []);
  (0, _react.useEffect)(() => {
    if (!playing || m3u8Url || !selectedEp) return;
    const switchNext = () => {
      if (m3u8FoundRef.current) return;
      const order = ["vidlink", "videasy", "vidsrccc", "vidsrcxyz", "vidsrcme", "vidsrcnet", "vidsrcin", "vidsrcpm", "vidsrc", "vidsrcicu", "vidfast", "vidnest", "vidlove", "autoembed", "embedsu", "smashy", "multiembed", "superembed", "twoembed", "moviesapi", "nontongo"];
      const idx = order.indexOf(playerSource);
      const nextSrc = order[(idx + 1) % order.length];
      try {
        if (webviewRef.current) webviewRef.current.src = "about:blank";
      } catch {}
      if (nextSrc && nextSrc !== playerSource) {
        setPlayerSource(nextSrc);
      }
    };
    const chHandler = window.electron?.onServerChallenge?.(() => switchNext());
    const t = setTimeout(switchNext, 4200);
    return () => {
      clearTimeout(t);
      if (chHandler) window.electron?.offServerChallenge?.(chHandler);
    };
  }, [playing, m3u8Url, selectedEp, playerSource]);
  (0, _react.useEffect)(() => {
    const h = window.electron?.onNeedNextServer?.(data => {
      const cur = data?.currentSource || playerSource;
      const order = ["vidlink", "videasy", "vidsrccc", "vidsrcxyz", "vidsrcme", "vidsrcnet", "vidsrcin", "vidsrcpm", "vidsrc", "vidsrcicu", "vidfast", "vidnest", "vidlove", "autoembed", "embedsu", "smashy", "multiembed", "superembed", "twoembed", "moviesapi", "nontongo"];
      const idx = order.indexOf(cur);
      const nextSrc = order[(idx + 1) % order.length];
      pendingFailoverRef.current = true;
      setM3u8Url(null);
      setPlaying(true);
      try {
        if (webviewRef.current) webviewRef.current.src = "about:blank";
      } catch {}
      if (nextSrc) setPlayerSource(nextSrc);
    });
    return () => {
      if (h) window.electron?.offNeedNextServer?.(h);
    };
  }, [playerSource]);
  (0, _react.useEffect)(() => {
    if (!playing || !m3u8Url || !selectedEp) return;
    const launchKey = `tv_${item.id}_s${selectedSeason}_e${selectedEp.episode_number}_${playerSource}`;
    if (!pendingFailoverRef.current && autoExoLaunchedRef.current === launchKey) return;
    const timer = setTimeout(() => {
      autoExoLaunchedRef.current = launchKey;
      if (window.AndroidBridge?.openExoPlayer) {
        if (pendingFailoverRef.current) {
          pendingFailoverRef.current = false;
          window.AndroidBridge?.deliverNextServerStream?.(m3u8Url, playerSource);
          return;
        }
        const epPct = progress?.[currentProgressKey] || 0;
        const epDone = !!watched?.[currentProgressKey] || epPct >= 90;
        const startSec = epDone ? 0 : _storage.storage.get("dlTime_" + currentProgressKey) || 0;
        const payload = {
          url: m3u8Url,
          title: mediaName || title,
          currentSource: playerSource,
          startTimeSec: startSec,
          subtitles: interceptedSubs,
          progressKey: currentProgressKey,
          imdbId: item.imdb_id || item.id,
          mediaType: "tv",
          season: selectedSeason,
          episode: selectedEp.episode_number,
          subTextColor: _storage.storage.get("subtitleTextColor") || "#FFFFFF",
          subBgStyle: _storage.storage.get("subtitleBgStyle") || "dark",
          subFontSizeSp: Number(_storage.storage.get("subtitleFontSizeSp") || 22),
          preferredSubLang: playerSubLang || "ar"
        };
        try {
          if (webviewRef.current) webviewRef.current.src = "about:blank";
        } catch {}
        window.AndroidBridge.openExoPlayer(JSON.stringify(payload));
        setPlaying(false);
        setPlayerFullscreen(false);
        document.documentElement.removeAttribute("data-player-fullscreen");
      }
    }, 300);
    return () => clearTimeout(timer);
  }, [playing, m3u8Url, selectedEp, item.id, selectedSeason, playerSource]);
  (0, _react.useEffect)(() => {
    if (!showSourceMenu) return;
    const close = () => setShowSourceMenu(false);
    window.addEventListener("scroll", close, {
      capture: true,
      passive: true
    });
    const handleClick = e => {
      if (sourceRef.current?.contains(e.target) || e.target.closest(".source-dropdown")) return;
      close();
    };
    document.addEventListener("mousedown", handleClick);
    return () => {
      window.removeEventListener("scroll", close, {
        capture: true
      });
      document.removeEventListener("mousedown", handleClick);
    };
  }, [showSourceMenu]);
  (0, _react.useEffect)(() => {
    if (!window.electron) return;
    const handler = window.electron.onSubtitleFound(({
      url,
      lang
    }) => {
      if (!url || !url.toLowerCase().includes(".vtt")) return;
      setInterceptedSubs(prev => {
        const filtered = prev.filter(s => s.lang !== lang);
        return [...filtered, {
          url,
          lang: lang || "unknown"
        }];
      });
    });
    return () => window.electron.offSubtitleFound(handler);
  }, []);
  const d = details || item;
  const title = d.name || d.title;
  const year = (d.first_air_date || "").slice(0, 4);
  const status = d.status;
  const tmdbSeasons = (0, _react.useMemo)(() => (d.seasons || []).filter(s => s.season_number > 0), [d.seasons]);
  const tmdbSeasonsWithSpecials = (0, _react.useMemo)(() => {
    if (isAnime) return tmdbSeasons;
    if (failedSeasons.has(0)) return tmdbSeasons;
    const specials = (d.seasons || []).filter(s => s.season_number === 0);
    return [...tmdbSeasons, ...specials];
  }, [d.seasons, tmdbSeasons, isAnime, failedSeasons]);
  const useAnilistSeasons = (0, _react.useMemo)(() => isAnime && anilistSeasons?.length > 0 && (tmdbSeasons.length <= 1 || anilistSeasons.length > tmdbSeasons.length), [isAnime, anilistSeasons, tmdbSeasons]);
  const episodeGroupSeasons = (0, _react.useMemo)(() => {
    if (!episodeGroupData?.groups) return null;
    return [...episodeGroupData.groups].sort((a, b) => a.order - b.order).map((g, i) => ({
      season_number: i + 1,
      name: g.name || `Season ${i + 1}`,
      episode_count: (g.episodes || []).length
    }));
  }, [episodeGroupData]);
  const seasons = (0, _react.useMemo)(() => {
    if (episodeGroupSeasons) return episodeGroupSeasons;
    if (useAnilistSeasons) return anilistSeasons.map(s => ({
      season_number: s.seasonNum,
      name: s.title || `Season ${s.seasonNum}`,
      episode_count: s.episodes || 0
    }));
    return tmdbSeasonsWithSpecials;
  }, [episodeGroupSeasons, useAnilistSeasons, anilistSeasons, tmdbSeasonsWithSpecials]);
  const episodeGroupCurrentEpisodes = (0, _react.useMemo)(() => {
    if (!episodeGroupData?.groups) return null;
    const sortedGroups = [...episodeGroupData.groups].sort((a, b) => a.order - b.order);
    const group = sortedGroups[selectedSeason - 1];
    if (!group) return null;
    return [...(group.episodes || [])].sort((a, b) => a.order - b.order).map((ep, i) => ({
      ...ep,
      episode_number: i + 1,
      _tmdbSeason: ep.season_number,
      _tmdbAbsolute: ep.episode_number
    }));
  }, [episodeGroupData, selectedSeason]);
  const getSeasonEpisodes = (0, _react.useCallback)(rawEpisodes => {
    if (!useAnilistSeasons || !rawEpisodes) return rawEpisodes;
    if (tmdbSeasons.length > 1) return rawEpisodes;
    let offset = 0;
    for (const s of anilistSeasons) {
      if (s.seasonNum < selectedSeason) offset += s.episodes || 0;
    }
    const count = anilistSeasons.find(s => s.seasonNum === selectedSeason)?.episodes || rawEpisodes.length;
    return rawEpisodes.slice(offset, offset + count).map((ep, i) => ({
      ...ep,
      episode_number: i + 1,
      _tmdbAbsolute: ep.episode_number
    }));
  }, [useAnilistSeasons, tmdbSeasons.length, anilistSeasons, selectedSeason]);
  const playerEp = (0, _react.useMemo)(() => {
    if (!selectedEp) return {
      season: selectedSeason,
      episode: undefined
    };
    const rawSeason = selectedEp._tmdbSeason ?? selectedSeason;
    const rawEpisode = selectedEp._tmdbAbsolute ?? selectedEp.episode_number;
    return (0, _episodeMappings.applyEpisodeMapping)(item.id, rawSeason, rawEpisode, episodeGroupMap);
  }, [selectedEp, selectedSeason, item.id, episodeGroupMap]);
  const playerDirectUrl = (0, _react.useMemo)(() => {
    if (isAnime && (0, _api.sourceSupportsAnime)(playerSource)) {
      if (anilistLoading) return null;
      const seasonEntry = anilistSeasons?.find(s => s.seasonNum === selectedSeason);
      const anilistId = seasonEntry?.id ?? (anilistData?.id || null);
      const animeUrl = (0, _api.getAnimeSourceUrl)(playerSource, anilistId, selectedEp?.episode_number, dubMode);
      if (animeUrl) return animeUrl;
    }
    return (0, _api.getSourceUrl)(playerSource, "tv", srcId.id, playerEp.season, playerEp.episode, {}, playerAccentColor, playerSubLang);
  }, [isAnime, playerSource, anilistLoading, anilistSeasons, anilistData, selectedSeason, selectedEp, dubMode, srcId.id, playerEp, playerAccentColor, playerSubLang]);
  const episodeGroupPending = (0, _react.useMemo)(() => !!_episodeMappings.EPISODE_GROUP_IDS[Number(item.id)] && !episodeGroupData, [item.id, episodeGroupData]);
  const currentSeasonEpisodes = (0, _react.useMemo)(() => {
    if (episodeGroupPending) return [];
    if (anilistLoading) return [];
    return episodeGroupCurrentEpisodes || getSeasonEpisodes(seasonData?.episodes) || [];
  }, [episodeGroupPending, anilistLoading, episodeGroupCurrentEpisodes, getSeasonEpisodes, seasonData]);
  const autoSelectKeyRef = (0, _react.useRef)(null);
  (0, _react.useEffect)(() => {
    if (!item.episode || currentSeasonEpisodes.length === 0) return;
    const key = `${item.id}_e${item.episode}`;
    if (autoSelectKeyRef.current === key) return;
    const target = Number(item.episode);
    const ep = currentSeasonEpisodes.find(e => e.episode_number === target);
    if (ep) {
      autoSelectKeyRef.current = key;
      setSelectedEp(ep);
    }
  }, [item.id, item.episode, currentSeasonEpisodes]);
  const downloadsByEpisodeKey = (0, _react.useMemo)(() => {
    const map = new Map();
    for (const dl of downloads || []) {
      if (dl.mediaType === "tv" && (dl.tmdbId === item.id || dl.mediaId === item.id) && (dl.status === "completed" || dl.status === "local" || dl.status === "downloading")) {
        map.set(`s${dl.season}e${dl.episode}`, dl);
      }
    }
    return map;
  }, [downloads, item.id]);
  const displaySeasonCount = (0, _react.useMemo)(() => anilistLoading ? null : seasons.length || d.number_of_seasons || 0, [anilistLoading, seasons, d.number_of_seasons]);
  const displayEpisodeCount = (0, _react.useMemo)(() => anilistLoading ? null : useAnilistSeasons ? anilistSeasons.reduce((sum, s) => sum + (s.episodes || 0), 0) : d.number_of_episodes || 0, [anilistLoading, useAnilistSeasons, anilistSeasons, d.number_of_episodes]);
  const displayOverview = (0, _react.useMemo)(() => anilistLoading ? null : isAnime && anilistData?.description ? (0, _api.cleanAnilistDescription)(anilistData.description) : d.overview, [anilistLoading, isAnime, anilistData?.description, d.overview]);
  const displayScore = (0, _react.useMemo)(() => anilistLoading ? null : isAnime && anilistData?.averageScore ? (anilistData.averageScore / 10).toFixed(1) : d.vote_average > 0 ? d.vote_average.toFixed(1) : null, [anilistLoading, isAnime, anilistData?.averageScore, d.vote_average]);
  const displayGenres = (0, _react.useMemo)(() => anilistLoading ? [] : isAnime && anilistData?.genres?.length ? anilistData.genres.map((g, i) => ({
    id: i,
    name: g
  })) : d.genres || [], [anilistLoading, isAnime, anilistData?.genres, d.genres]);
  const seasonWatchedMap = (0, _react.useMemo)(() => {
    const map = {};
    for (const s of seasons) {
      const num = s.season_number;
      const count = num === selectedSeason ? currentSeasonEpisodes.length || s.episode_count || 0 : s.episode_count || 0;
      if (!count) {
        map[num] = "none";
        continue;
      }
      let watchedCount = 0;
      for (let i = 1; i <= count; i++) {
        if (watched?.[`tv_${item.id}_s${num}e${i}`]) watchedCount++;
      }
      if (watchedCount === 0) {
        map[num] = "none";
      } else if (watchedCount === count) {
        map[num] = "all";
      } else {
        const pct = watchedCount / count;
        map[num] = pct < 0.375 ? "some25" : pct < 0.625 ? "some50" : "some75";
      }
    }
    return map;
  }, [seasons, selectedSeason, currentSeasonEpisodes, watched, item.id]);
  const isSeasonWatched = (0, _react.useCallback)(seasonNum => seasonWatchedMap[seasonNum] === "all", [seasonWatchedMap]);
  const markSeasonWatched = (0, _react.useCallback)(seasonNum => {
    const seasonInfo = seasons.find(s => s.season_number === seasonNum);
    const episodes = seasonNum === selectedSeason ? currentSeasonEpisodes : null;
    const count = episodes?.length || seasonInfo?.episode_count || 0;
    for (let i = 1; i <= count; i++) {
      if (episodes) {
        const ep = episodes.find(e => e.episode_number === i);
        if (ep && isUnreleased(ep.air_date)) continue;
      }
      onMarkWatched?.(`tv_${item.id}_s${seasonNum}e${i}`);
    }
  }, [seasons, selectedSeason, currentSeasonEpisodes, item.id, onMarkWatched]);
  const markSeasonUnwatched = (0, _react.useCallback)(seasonNum => {
    const seasonInfo = seasons.find(s => s.season_number === seasonNum);
    const episodes = seasonNum === selectedSeason ? currentSeasonEpisodes : null;
    const count = episodes?.length || seasonInfo?.episode_count || 0;
    for (let i = 1; i <= count; i++) {
      onMarkUnwatched?.(`tv_${item.id}_s${seasonNum}e${i}`);
    }
  }, [seasons, selectedSeason, currentSeasonEpisodes, item.id, onMarkUnwatched]);
  const currentProgressKey = selectedEp ? `tv_${item.id}_s${selectedSeason}e${selectedEp.episode_number}` : null;
  const currentEpDownload = selectedEp ? downloadsByEpisodeKey.get(`s${selectedSeason}e${selectedEp.episode_number}`) ?? null : null;
  (0, _react.useEffect)(() => {
    autoMarkedRef.current = false;
    lastKnownTimeRef.current = 0;
    seekBackCooldownRef.current = 0;
    durationRef.current = 0;
    localCountdownStartedRef.current = false;
    resetAutoplayRef.current?.();
  }, [currentProgressKey]);
  (0, _react.useEffect)(() => {
    if (playing) setWebviewLoading(true);
    try {
      window.AndroidBridge?.setImmersiveMode?.(!!playing);
    } catch {}
  }, [playing]);
  (0, _react.useLayoutEffect)(() => {
    if (playing) return;
    const wv = webviewRef.current;
    if (wv) {
      try {
        wv.src = "about:blank";
      } catch {}
    }
  }, [playing]);
  (0, _react.useEffect)(() => {
    return () => {
      window.electron?.playerStopped?.();
    };
  }, []);
  (0, _react.useEffect)(() => {
    if (!playing) return;
    const wv = webviewRef.current;
    if (!wv) return;
    const done = () => {
      setWebviewLoading(false);
      playerWrapRef.current?.scrollIntoView({
        behavior: "auto",
        block: "center"
      });
      setTimeout(() => {
        if (!m3u8FoundRef.current) tapCenterOfPlayer();
      }, 1400);
      setTimeout(() => {
        if (!m3u8FoundRef.current) tapCenterOfPlayer();
      }, 2800);
    };
    wv.addEventListener("did-finish-load", done);
    wv.addEventListener("did-fail-load", done);
    let attempts = 0;
    const pollDuration = !isAsync ? null : setInterval(async () => {
      if (durationRef.current > 0 || attempts++ > 30) {
        clearInterval(pollDuration);
        return;
      }
      try {
        const dur = await wv.executeJavaScript(`(() => { const v = document.querySelector('video'); return (v && v.duration > 0 && isFinite(v.duration)) ? v.duration : null; })()`);
        if (dur) {
          durationRef.current = dur;
          setSkipTimings(t => t ? {
            ...t
          } : t);
          clearInterval(pollDuration);
        }
      } catch {}
    }, 1000);
    return () => {
      wv.removeEventListener("did-finish-load", done);
      wv.removeEventListener("did-fail-load", done);
      clearInterval(pollDuration);
    };
  }, [playing, playerSource, isAsync, item.id, selectedEp?.episode_number]);
  (0, _react.useEffect)(() => {
    setSkipTimings(null);
    setSkipPrompt(null);
    if (introSkipMode === "off" || !isAsync || !isAnime) return;
    const anilistId = anilistData?.idMal;
    const epNum = selectedEp?.episode_number;
    if (!anilistId || !epNum) return;
    let cancelled = false;
    (0, _aniSkip.fetchAniSkipTimings)(anilistId, epNum).then(timings => {
      if (!cancelled) setSkipTimings(timings);
    });
    return () => {
      cancelled = true;
    };
  }, [anilistData?.idMal, selectedEp?.episode_number, playerSource, isAnime, introSkipMode]);
  const handleManualSkip = (0, _react.useCallback)(async () => {
    if (!skipPrompt || !skipTimings?.[skipPrompt]) return;
    const rawEnd = skipTimings[skipPrompt].endTime;
    const endTime = Number(rawEnd);
    if (!Number.isFinite(endTime)) return;
    const wv = webviewRef.current;
    if (!wv) return;
    try {
      await wv.executeJavaScript(`(() => { const v = document.querySelector('video'); if (v) v.currentTime = ${endTime}; })()`);
    } catch {}
    setSkipPrompt(null);
  }, [skipPrompt, skipTimings]);
  (0, _react.useEffect)(() => {
    if (!skipPrompt) return;
    const wv = webviewRef.current;
    if (!wv) return;
    const handler = e => {
      if (e.key === "Return" && e.type === "keyDown") {
        handleManualSkip();
      }
    };
    wv.addEventListener("before-input-event", handler);
    return () => wv.removeEventListener("before-input-event", handler);
  }, [skipPrompt, handleManualSkip]);
  (0, _react.useEffect)(() => {
    const aniSkipActive = introSkipMode !== "off" && playing && !!skipTimings && isAsync;
    if (!aniSkipActive) setSkipPrompt(null);
    if (!playing || !currentProgressKey) return;
    const TICK = aniSkipActive ? 1000 : 5000;
    let tickCount = 0;
    let interval = null;
    const timer = setTimeout(() => {
      interval = setInterval(async () => {
        try {
          const wv = webviewRef.current;
          if (!wv) return;
          let result;
          if (pipWebContentsIdRef.current != null && window.electron?.queryVideoProgress) {
            result = await window.electron.queryVideoProgress(pipWebContentsIdRef.current);
          } else if (progressViaFrames && window.electron?.queryVideoProgress) {
            result = await window.electron.queryVideoProgress(wv.getWebContentsId());
          } else {
            result = await wv.executeJavaScript(`
              (() => {
                const v = document.querySelector('video')
                if (!v || !v.duration || v.duration === Infinity || v.paused) return null
                // Re-attach seek tracker if video element was recreated (e.g. quality change)
                if (!v._seekTracked) {
                  v._seekTracked = true
                  v.addEventListener('seeked', () => {
                    v._lastUserSeek = Date.now()
                    v._lastUserSeekTo = v.currentTime
                  })
                }
                return {
                  currentTime: v.currentTime,
                  duration: v.duration,
                  recentUserSeek: v._lastUserSeek ? (Date.now() - v._lastUserSeek < 6000) : false,
                  lastUserSeekTo: v._lastUserSeekTo ?? null,
                }
              })()
            `);
          }
          if (aniSkipActive && result?.currentTime != null) {
            const ct = result.currentTime;
            const {
              intro,
              outro
            } = skipTimings;
            const inIntro = intro && ct >= intro.startTime && ct < intro.endTime - 1;
            const inOutro = outro && ct >= outro.startTime && ct < outro.endTime - 1;
            const activeSegment = inIntro ? "intro" : inOutro ? "outro" : null;
            if (!activeSegment) {
              setSkipPrompt(null);
            } else if (introSkipMode === "auto") {
              setSkipPrompt(null);
              const endTime = Number(skipTimings[activeSegment].endTime);
              if (Number.isFinite(endTime)) {
                try {
                  await wv.executeJavaScript(`(() => { const v = document.querySelector('video'); if (v) v.currentTime = ${endTime}; })()`);
                } catch {}
              }
            } else {
              setSkipPrompt(activeSegment);
            }
          }
          tickCount++;
          if (aniSkipActive && tickCount % 5 !== 0) return;
          if (result && result.duration > 0) {
            durationRef.current = result.duration;
            const ct = result.currentTime;
            const now = Date.now();
            if (!(0, _api.sourceSkipsResetGuard)(playerSource) && lastKnownTimeRef.current > 30 && ct <= 5 && !result.recentUserSeek) {
              if (now > seekBackCooldownRef.current) {
                const seekTo = lastKnownTimeRef.current;
                seekBackCooldownRef.current = now + 8000;
                try {
                  await wv.executeJavaScript(`
                    (() => {
                      const v = document.querySelector('video')
                      if (v) v.currentTime = ${seekTo}
                    })()
                  `);
                } catch {}
              }
              return;
            }
            if (result.recentUserSeek && result.lastUserSeekTo !== null) {
              lastKnownTimeRef.current = result.lastUserSeekTo;
            } else {
              lastKnownTimeRef.current = ct;
            }
            const p = Math.floor(ct / result.duration * 100);
            saveProgressRef.current(currentProgressKey, Math.min(p, 100));
            _storage.storage.set("dlTime_" + currentProgressKey, Math.floor(ct));
            const remaining = result.duration - ct;
            if (!autoMarkedRef.current && remaining <= watchedThreshold && remaining >= 0) {
              autoMarkedRef.current = true;
              onMarkWatchedRef.current?.(currentProgressKey);
            }
            if (remaining <= watchedThreshold && !localCountdownStartedRef.current) {
              localCountdownStartedRef.current = true;
              setCountdownStartedRef.current?.(true);
              triggerAutoplayRef.current?.();
            }
          }
        } catch {}
      }, TICK);
    }, 3000);
    return () => {
      clearTimeout(timer);
      clearInterval(interval);
      setSkipPrompt(null);
    };
  }, [playing, skipTimings, playerSource, introSkipMode, currentProgressKey, watchedThreshold, progressViaFrames]);
  const seekBy = (0, _react.useCallback)(async seconds => {
    try {
      const wv = webviewRef.current;
      if (!wv) return;
      await wv.executeJavaScript(`
        (() => {
          const v = document.querySelector('video');
          if (v) v.currentTime = Math.max(0, Math.min(v.duration || 0, v.currentTime + ${seconds}));
        })()
      `);
    } catch {}
  }, []);
  (0, _react.useEffect)(() => {
    const wv = webviewRef.current;
    if (!wv || !playing || !isAsync) return;
    const inject = () => {
      wv.executeJavaScript(INJECT_SKIP_CONTROLS).catch(() => {});
    };
    wv.addEventListener("dom-ready", inject);
    try {
      inject();
    } catch {}
    return () => {
      wv.removeEventListener("dom-ready", inject);
      try {
        wv.executeJavaScript(`
          (() => {
            const el = document.getElementById('__skip-ui');
            if (el) el.remove();
            window.__skipControlsInjected = false;
          })()
        `);
      } catch {}
    };
  }, [playing, playerSource]);
  const [gamepadEnabled, setGamepadEnabled] = (0, _react.useState)(() => _storage.storage.get(_storage.STORAGE_KEYS.GAMEPAD_ENABLED) !== false);
  (0, _react.useEffect)(() => {
    const handler = () => setGamepadEnabled(_storage.storage.get(_storage.STORAGE_KEYS.GAMEPAD_ENABLED) !== false);
    window.addEventListener("streambert:gamepad-settings-changed", handler);
    return () => window.removeEventListener("streambert:gamepad-settings-changed", handler);
  }, []);
  (0, _react.useEffect)(() => {
    (0, _gamepadPlayerState.setPlayerGamepadActive)(gamepadEnabled && playing);
    return () => (0, _gamepadPlayerState.setPlayerGamepadActive)(false);
  }, [playing, gamepadEnabled]);
  (0, _react.useEffect)(() => {
    const wv = webviewRef.current;
    if (!wv || !playing || !gamepadEnabled) return;
    const inject = () => {
      wv.executeJavaScript(_playerGamepadScript.GAMEPAD_PLAYER_SCRIPT).catch(() => {});
    };
    wv.addEventListener("dom-ready", inject);
    try {
      inject();
    } catch {}
    const exitPoll = setInterval(async () => {
      try {
        const requested = await wv.executeJavaScript(_playerGamepadScript.GAMEPAD_EXIT_CHECK_JS);
        if (requested) {
          wv.executeJavaScript(_playerGamepadScript.GAMEPAD_EXIT_RESET_JS).catch(() => {});
          setPlaying(false);
        }
      } catch {}
    }, 250);
    return () => {
      wv.removeEventListener("dom-ready", inject);
      clearInterval(exitPoll);
      try {
        wv.executeJavaScript(_playerGamepadScript.GAMEPAD_CLEANUP_JS);
      } catch {}
    };
  }, [playing, gamepadEnabled, playerSource]);
  const tapCenterOfPlayer = (0, _react.useCallback)(() => {
    try {
      const el = playerWrapRef.current;
      if (!el || !window.AndroidBridge?.tapPlayerCenter) return;
      const r = el.getBoundingClientRect();
      if (r.width <= 0 || r.height <= 0) return;
      const rx = (r.left + r.width / 2) / Math.max(1, window.innerWidth);
      const ry = (r.top + r.height / 2) / Math.max(1, window.innerHeight);
      if (ry > 0.05 && ry < 0.95) {
        window.AndroidBridge.tapPlayerCenter(rx, ry);
      }
    } catch {}
  }, []);
  const playEpisode = (0, _react.useCallback)(ep => {
    autoExoLaunchedRef.current = null;
    setM3u8Url(null);
    setInterceptedSubs([]);
    resolvedPlayerUrlRef.current = null;
    setResolvedPlayerUrl(null);
    resolvingUrlRef.current = false;
    setResolvingUrl(false);
    setResolveError(null);
    setSelectedEp(ep);
    setPlaying(true);
    setTimeout(() => {
      playerWrapRef.current?.scrollIntoView({
        behavior: "smooth",
        block: "center"
      });
    }, 100);
    onHistory({
      ...d,
      media_type: "tv",
      season: selectedSeason,
      episode: ep.episode_number,
      episodeName: ep.name
    });
  }, [d, selectedSeason, onHistory]);
  const nextEp = (0, _react.useMemo)(() => {
    if (!selectedEp || !currentSeasonEpisodes) return null;
    const idx = currentSeasonEpisodes.findIndex(e => e.episode_number === selectedEp.episode_number);
    if (idx >= 0 && idx < currentSeasonEpisodes.length - 1) {
      const candidate = currentSeasonEpisodes[idx + 1];
      return isUnreleased(candidate.air_date) ? null : candidate;
    }
    return null;
  }, [selectedEp, currentSeasonEpisodes]);
  const {
    autoplayCountdown,
    countdownStarted,
    setCountdownStarted,
    triggerAutoplay,
    cancelAutoplay,
    playNow,
    resetAutoplay
  } = (0, _useAutoplay.useAutoplay)({
    nextEp,
    playEpisode,
    restricted
  });
  (0, _react.useEffect)(() => {
    resetAutoplayRef.current = resetAutoplay;
    triggerAutoplayRef.current = triggerAutoplay;
    setCountdownStartedRef.current = setCountdownStarted;
  }, [resetAutoplay, triggerAutoplay, setCountdownStarted]);
  (0, _react.useEffect)(() => {
    localCountdownStartedRef.current = countdownStarted;
  }, [countdownStarted]);
  const autoplayNextLayout = _storage.storage.get(_storage.STORAGE_KEYS.AUTOPLAY_NEXT_LAYOUT) || "right";
  const handleSetDownloaderFolder = (0, _react.useCallback)(folder => {
    setDownloaderFolder(folder);
    _storage.storage.set("downloaderFolder", folder);
  }, []);
  (0, _react.useEffect)(() => {
    if (!playing) return;
    if (!_api.NEEDS_INTERCEPT.includes(playerSource)) return;
    const enterH = window.electron?.onWebviewEnterFullscreen?.(() => {
      setPlayerFullscreen(true);
      document.documentElement.setAttribute("data-player-fullscreen", "1");
    });
    const leaveH = window.electron?.onWebviewLeaveFullscreen?.(() => {
      setPlayerFullscreen(false);
      document.documentElement.removeAttribute("data-player-fullscreen");
      if (document.fullscreenElement) document.exitFullscreen?.();
    });
    return () => {
      if (enterH) window.electron?.offWebviewEnterFullscreen?.(enterH);
      if (leaveH) window.electron?.offWebviewLeaveFullscreen?.(leaveH);
      document.documentElement.removeAttribute("data-player-fullscreen");
    };
  }, [playing, playerSource]);
  (0, _react.useEffect)(() => {
    if (!playing) return;
    const openH = window.electron?.onPipOpened?.(async () => {
      setPipOpen(true);
      pipWebContentsIdRef.current = (await window.electron.getPipWebContentsId?.()) ?? null;
    });
    const closeH = window.electron?.onPipClosed?.(() => {
      pipUrlRef.current = null;
      pipWebContentsIdRef.current = null;
      setPipOpen(false);
    });
    return () => {
      if (openH) window.electron?.offPipOpened?.(openH);
      if (closeH) window.electron?.offPipClosed?.(closeH);
    };
  }, [playing]);
  const effectiveYear = year || (isAnime && anilistData?.startDate?.year ? String(anilistData.startDate.year) : "");
  const mediaName = selectedEp ? `${title}${effectiveYear ? ` (${effectiveYear})` : ""} S${String(selectedSeason).padStart(2, "0")} E${String(selectedEp.episode_number).padStart(2, "0")}` : title;
  const currentEpWatched = currentProgressKey ? !!watched?.[currentProgressKey] : false;
  return React.createElement("div", {
    className: "fade-in"
  }, loading && React.createElement("div", {
    className: "loader"
  }, React.createElement("div", {
    className: "spinner"
  })), !loading && React.createElement(React.Fragment, null, React.createElement("div", {
    className: "detail-hero"
  }, React.createElement("div", {
    className: "detail-bg",
    style: {
      backgroundImage: `url(${(0, _api.imgUrl)(d.backdrop_path, "w1280")})`
    }
  }), React.createElement("div", {
    className: "detail-gradient"
  }), React.createElement("div", {
    className: "detail-content"
  }, React.createElement("div", {
    className: "detail-poster"
  }, d.poster_path ? React.createElement("img", {
    src: (0, _api.imgUrl)(d.poster_path),
    alt: title,
    loading: "lazy"
  }) : React.createElement("div", {
    style: {
      width: "100%",
      height: "100%",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: "var(--text3)"
    }
  }, React.createElement(_Icons.TVIcon, null))), React.createElement("div", {
    className: "detail-info"
  }, React.createElement("div", {
    className: "detail-type"
  }, "Series"), React.createElement("div", {
    className: "detail-title"
  }, title), React.createElement("div", {
    className: "genres"
  }, displayGenres.map(g => React.createElement("span", {
    key: g.id,
    className: "genre-tag"
  }, g.name))), React.createElement("div", {
    className: "detail-meta"
  }, displayScore && React.createElement("span", {
    className: "detail-rating"
  }, React.createElement(_Icons.StarIcon, null), " ", displayScore), year && React.createElement("span", null, year), displaySeasonCount > 0 && React.createElement("span", null, displaySeasonCount, " Season", displaySeasonCount !== 1 ? "s" : ""), displayEpisodeCount > 0 && React.createElement("span", null, displayEpisodeCount, " Episode", displayEpisodeCount !== 1 ? "s" : ""), React.createElement("span", null, status)), rating.cert && React.createElement("div", {
    className: `age-rating-pill${restricted ? " age-rating-pill--restricted" : ""}`
  }, restricted ? React.createElement(_Icons.RatingLockIcon, _Icons.AlertIcon, {
    size: 13
  }) : React.createElement(_Icons.RatingShieldIcon, {
    size: 13
  }), React.createElement("span", {
    className: "age-rating-pill-cert"
  }, rating.cert), restricted && React.createElement("span", {
    className: "age-rating-pill-label"
  }, "Inappropriate for your age setting")), React.createElement("p", {
    className: "detail-overview"
  }, displayOverview), React.createElement("div", {
    className: "detail-actions"
  }, trailerKey && (restricted ? React.createElement("button", {
    className: "btn btn-secondary btn-restricted",
    disabled: true,
    title: "Inappropriate for your age rating setting"
  }, React.createElement(_Icons.RatingLockIcon, {
    size: 14
  }), " Trailer") : React.createElement("button", {
    className: "btn btn-secondary",
    onClick: () => setShowTrailer(true)
  }, React.createElement(_Icons.TrailerIcon, null), " Trailer")), React.createElement("button", {
    className: "btn btn-secondary",
    onClick: () => setDownloadConfirm({
      type: "season",
      season: selectedSeason,
      episodes: currentSeasonEpisodes
    })
  }, React.createElement(_Icons.DownloadIcon, null), " Download Season"), React.createElement("button", {
    className: "btn btn-secondary",
    onClick: onSave
  }, isSaved ? React.createElement(_Icons.BookmarkFillIcon, null) : React.createElement(_Icons.BookmarkIcon, null), isSaved ? "Saved" : "Save"), React.createElement("button", {
    className: "btn btn-ghost",
    onClick: onBack
  }, React.createElement(_Icons.BackIcon, null), " Back"))))), playing && selectedEp && React.createElement("div", {
    className: "section"
  }, React.createElement("div", {
    style: {
      marginBottom: 12,
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, React.createElement("span", {
    className: "tag tag-red"
  }, "Season ", selectedSeason, " \xB7 E", selectedEp.episode_number), React.createElement("span", {
    style: {
      fontSize: 14,
      fontWeight: 500
    }
  }, selectedEp.name), currentEpWatched ? React.createElement("button", {
    className: "btn btn-ghost watched-btn",
    style: {
      marginLeft: "auto"
    },
    onClick: () => onMarkUnwatched?.(currentProgressKey)
  }, React.createElement(_Icons.WatchedIcon, {
    size: 14
  }), " Watched") : React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      marginLeft: "auto"
    },
    onClick: () => onMarkWatched?.(currentProgressKey)
  }, "\u2713 Mark Watched")), React.createElement("div", {
    className: "player-wrap player-wrap--fullscreen player-wrap--silent-exo",
    ref: playerWrapRef
  }, webviewLoading && !resolveError && React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 10,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      background: "rgba(0,0,0,0.75)",
      pointerEvents: "none",
      gap: 14,
      borderRadius: "inherit"
    }
  }, (0, _api.sourceIsAsync)(playerSource) ? React.createElement(_HiAnimeLoader.default, {
    what: "episode",
    playerStarting: !resolvingUrl && !!resolvedPlayerUrl
  }) : React.createElement(React.Fragment, null, React.createElement("div", {
    className: "spinner"
  }), React.createElement("span", {
    style: {
      fontSize: 14,
      color: "var(--text2)"
    }
  }, `Loading ${_api.PLAYER_SOURCES.find(s => s.id === playerSource)?.label ?? "source"}…`))), isAsync && resolveError && !resolvingUrl && React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 10,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      background: "rgba(0,0,0,0.85)",
      gap: 10,
      borderRadius: "inherit"
    }
  }, React.createElement("span", {
    style: {
      fontSize: 28
    }
  }, React.createElement(_Icons.AlertIcon, {
    size: 28
  })), React.createElement("span", {
    style: {
      fontSize: 14,
      color: "var(--text2)"
    }
  }, "Episode not found on HiAnime"), React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, resolveError), React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, "Try a different source, or switch sub/dub.")), srcId.error && React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 11,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      background: "rgba(0,0,0,0.85)",
      gap: 10,
      borderRadius: "inherit"
    }
  }, React.createElement("span", {
    style: {
      fontSize: 28
    }
  }, React.createElement(_Icons.AlertIcon, {
    size: 28
  })), React.createElement("span", {
    style: {
      fontSize: 14,
      color: "var(--text2)"
    }
  }, "Could not resolve the ", srcId.idLabel, " for this title"), React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, srcId.error, ". Try a different source.")), pipOpen && React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 20,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      background: "rgba(0,0,0,0.92)",
      gap: 16,
      borderRadius: "inherit"
    }
  }, React.createElement(_Icons.PopOutIcon, {
    size: 36
  }), React.createElement("span", {
    style: {
      fontSize: 15,
      color: "var(--text1)",
      fontWeight: 600
    }
  }, "Playing in pop-out window"), React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text2)",
      textAlign: "center",
      maxWidth: 260
    }
  }, "Closing the pop-out will reload the player here."), React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => window.electron?.closePipWindow?.(),
    style: {
      marginTop: 4
    }
  }, "Close pop-out & return")), autoplayCountdown !== null && React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 30,
      display: "flex",
      justifyContent: autoplayNextLayout === "left" ? "flex-start" : "flex-end",
      background: "rgba(0,0,0,0.88)",
      borderRadius: "inherit",
      backdropFilter: "blur(6px)",
      animation: "fadeIn 0.4s ease"
    }
  }, React.createElement("div", {
    style: {
      width: "40%",
      minWidth: "320px",
      maxWidth: "480px",
      height: "100%",
      background: autoplayNextLayout === "left" ? "linear-gradient(90deg, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.85) 60%, rgba(0,0,0,0) 100%)" : "linear-gradient(270deg, rgba(0,0,0,0.95) 0%, rgba(0,0,0,0.85) 60%, rgba(0,0,0,0) 100%)",
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      padding: "40px",
      boxSizing: "border-box",
      textAlign: "left"
    }
  }, React.createElement("div", {
    style: {
      fontSize: "11px",
      fontWeight: "700",
      letterSpacing: "1.5px",
      textTransform: "uppercase",
      color: "var(--red)",
      marginBottom: "8px"
    }
  }, "Up Next"), React.createElement("div", {
    style: {
      width: "100%",
      aspectRatio: "16/9",
      borderRadius: "8px",
      overflow: "hidden",
      border: "1px solid rgba(255,255,255,0.1)",
      marginBottom: "18px",
      boxShadow: "0 8px 24px rgba(0,0,0,0.6)",
      background: "var(--surface3)",
      display: "flex",
      alignItems: "center",
      justifyContent: "center"
    }
  }, nextEp?.still_path ? React.createElement("img", {
    src: (0, _api.imgUrl)(nextEp.still_path, "w300"),
    alt: nextEp?.name,
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover"
    }
  }) : React.createElement("span", {
    style: {
      display: "inline-flex",
      width: 32,
      height: 32,
      color: "var(--text3)"
    }
  }, React.createElement(_Icons.PlayIcon, null))), React.createElement("div", {
    style: {
      fontSize: "13px",
      fontWeight: "600",
      color: "var(--text2)",
      marginBottom: "4px"
    }
  }, "Season ", selectedSeason, " \xB7 Episode", " ", nextEp?.episode_number), React.createElement("div", {
    style: {
      fontSize: "20px",
      fontWeight: "700",
      color: "white",
      marginBottom: "8px",
      lineHeight: "1.3",
      wordBreak: "break-word"
    }
  }, nextEp?.name), autoplayCountdown > 0 ? React.createElement("div", {
    style: {
      fontSize: "14px",
      color: "var(--text3)",
      marginBottom: "20px"
    }
  }, "Starting in", " ", React.createElement("span", {
    style: {
      color: "white",
      fontWeight: "600"
    }
  }, autoplayCountdown), "s...") : React.createElement("div", {
    style: {
      height: "20px",
      marginBottom: "20px"
    }
  }), React.createElement("div", {
    style: {
      display: "flex",
      gap: "12px",
      marginTop: "4px"
    }
  }, React.createElement("button", {
    className: "btn btn-primary",
    style: {
      padding: "10px 22px",
      fontSize: "14px",
      fontWeight: "600",
      background: "var(--red)",
      borderColor: "var(--red)",
      boxShadow: "var(--red-glow)"
    },
    onClick: playNow
  }, "Play Now"), React.createElement("button", {
    className: "btn btn-ghost",
    style: {
      padding: "10px 22px",
      fontSize: "14px",
      fontWeight: "600",
      background: "rgba(255,255,255,0.05)"
    },
    onClick: cancelAutoplay
  }, "Cancel")))), React.createElement(_StreamPlayerFrame.default, {
    ref: webviewRef,
    key: (0, _api.sourceUsesCleanUa)(playerSource) ? "ua-clean" : "ua-default",
    useragent: (0, _api.sourceUsesCleanUa)(playerSource) ? _api.CLEAN_USER_AGENT : undefined,
    src: pipOpen ? "about:blank" : isAsync ? resolvedPlayerUrl || "about:blank" : playerDirectUrl || "about:blank",
    partition: "persist:player",
    allowpopups: "false",
    sandbox: "allow-scripts allow-same-origin allow-forms",
    style: {
      position: "absolute",
      inset: 0,
      width: "100%",
      height: "100%",
      border: "none",
      outline: "none",
      boxShadow: "none",
      background: "black",
      visibility: isAsync && !resolvedPlayerUrl ? "hidden" : "visible"
    },
    tabIndex: -1
  }), React.createElement("div", {
    className: "player-overlay-group"
  }, React.createElement("button", {
    ref: sourceRef,
    className: "player-overlay-btn",
    onClick: () => {
      const rect = sourceRef.current?.getBoundingClientRect();
      if (rect) setMenuPos({
        top: rect.bottom + 6,
        left: rect.left
      });
      setShowSourceMenu(v => !v);
    },
    title: "Change source"
  }, React.createElement(_Icons.SourceIcon, null), _api.PLAYER_SOURCES.find(s => s.id === playerSource)?.label ?? "Source"), (isAsync || isAnime && (0, _api.sourceSupportsAnime)(playerSource)) && React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => {
      const next = dubMode === "sub" ? "dub" : "sub";
      setDubMode(next);
      _storage.storage.set(_storage.STORAGE_KEYS.HIANIME_DUB_MODE, next);
      setM3u8Url(null);
      setInterceptedSubs([]);
      resolvedPlayerUrlRef.current = null;
      setResolvedPlayerUrl(null);
      resolvingUrlRef.current = false;
      setResolvingUrl(false);
      setResolveError(null);
    },
    title: "Toggle Sub/Dub"
  }, dubMode === "sub" ? "SUB" : "DUB"), React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => {
      setShowSourceMenu(false);
      setShowBlockedModal(true);
    },
    title: "Blocked ads & trackers"
  }, React.createElement(_Icons.ShieldBlockIcon, null), blockedSession > 0 && React.createElement("span", {
    className: "player-blocked-badge"
  }, blockedSession)), m3u8Url && React.createElement("button", {
    className: "player-overlay-btn",
    style: {
      background: "rgba(229,9,20,0.88)",
      borderColor: "var(--red)"
    },
    onClick: () => {
      const pk = typeof progressKey !== "undefined" ? progressKey : currentProgressKey;
      const epPct = progress?.[pk] || 0;
      const epDone = !!watched?.[pk] || epPct >= 90;
      const startSec = epDone ? 0 : _storage.storage.get("dlTime_" + pk) || 0;
      const payload = {
        url: m3u8Url,
        title: mediaName || title,
        currentSource: playerSource,
        startTimeSec: startSec,
        subtitles: interceptedSubs,
        progressKey: typeof progressKey !== "undefined" ? progressKey : currentProgressKey,
        imdbId: item.imdb_id || item.id,
        mediaType: "tv",
        season: selectedSeason,
        episode: selectedEp?.episode_number || 1,
        subTextColor: _storage.storage.get("subtitleTextColor") || "#FFFFFF",
        subBgStyle: _storage.storage.get("subtitleBgStyle") || "dark",
        subFontSizeSp: Number(_storage.storage.get("subtitleFontSizeSp") || 22),
        preferredSubLang: playerSubLang || "ar"
      };
      if (window.AndroidBridge?.openExoPlayer) {
        window.AndroidBridge.openExoPlayer(JSON.stringify(payload));
        setPlaying(false);
        setPlayerFullscreen(false);
        document.documentElement.removeAttribute("data-player-fullscreen");
      } else {
        onOpenExoPlayer?.(payload);
      }
    },
    title: "Play stream in Native Media3 ExoPlayer"
  }, "\u25B6 ExoPlayer"), React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => tapCenterOfPlayer(),
    title: "Play / Pause"
  }, "\u23EF"), React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => {
      setPlaying(false);
      setPlayerFullscreen(false);
      document.documentElement.removeAttribute("data-player-fullscreen");
    },
    title: "Exit Player"
  }, "\u2715 Exit"), React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => {
      if (pipOpen) {
        window.electron?.closePipWindow?.();
        return;
      }
      const url = isAsync ? resolvedPlayerUrl : playerDirectUrl;
      if (!url) return;
      pipUrlRef.current = url;
      window.electron?.openPipWindow?.(url, item.name ?? item.title, (0, _api.sourceUsesCleanUa)(playerSource) ? _api.CLEAN_USER_AGENT : null);
    },
    title: pipOpen ? "Close pop-out" : "Pop out player",
    disabled: !pipOpen && (webviewLoading || !!(isAsync && !resolvedPlayerUrl)),
    style: pipOpen ? {
      color: "var(--red)"
    } : undefined
  }, React.createElement(_Icons.PopOutIcon, null))), showSourceMenu && menuPos && React.createElement("div", {
    className: "source-dropdown source-dropdown--fixed",
    style: {
      top: menuPos.top,
      left: menuPos.left
    },
    onClick: e => e.stopPropagation()
  }, _api.PLAYER_SOURCES.filter(src => !src.movieOnly).map(src => React.createElement("button", {
    key: src.id,
    className: "source-dropdown__item" + (playerSource === src.id ? " source-dropdown__item--active" : ""),
    onClick: () => {
      setShowSourceMenu(false);
      if (src.id === playerSource) return;
      if (selectedEp) {
        (0, _storage.clearFailoverSource)(`tv_${item.id}_s${selectedSeason}_e${selectedEp.episode_number}_${dubMode}`);
      }
      setPlayerSource(src.id);
      _storage.storage.set(_storage.STORAGE_KEYS.PLAYER_SOURCE, src.id);
      setM3u8Url(null);
      setInterceptedSubs([]);
      resolvedPlayerUrlRef.current = null;
      setResolvedPlayerUrl(null);
      resolvingUrlRef.current = false;
      setResolvingUrl(false);
      setResolveError(null);
    }
  }, React.createElement("span", null, src.label), src.tag && React.createElement("span", {
    className: "source-dropdown__tag"
  }, src.tag), src.note && React.createElement("span", {
    className: "source-dropdown__note"
  }, src.note)))), React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => currentEpDownload ? onGoToDownloads?.(currentEpDownload.id) : (setShowSourceMenu(false), setShowDownload(true)),
    title: currentEpDownload ? currentEpDownload.status === "downloading" ? "Downloading… - view in Downloads" : "Already downloaded - view in Downloads" : "Download"
  }, currentEpDownload ? React.createElement("span", {
    className: "player-downloaded-icon",
    style: {
      color: currentEpDownload.status === "downloading" ? "var(--red)" : "#4caf50"
    }
  }, currentEpDownload.status === "downloading" ? "↓" : "✓") : React.createElement(_Icons.DownloadIcon, null), !currentEpDownload && m3u8Url && React.createElement("span", {
    className: "player-overlay-dot"
  }), !supportsProgress && React.createElement("span", {
    className: "player-no-progress-hint",
    title: "No automatic progress tracking for this source"
  }, "\u26A0 no tracking")), skipPrompt && React.createElement("button", {
    onClick: handleManualSkip,
    style: {
      position: "absolute",
      bottom: 24,
      right: 24,
      zIndex: 50,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      gap: 1,
      background: "rgba(0,0,0,0.72)",
      border: "1px solid rgba(255,255,255,0.18)",
      borderRadius: 8,
      color: "white",
      cursor: "pointer",
      padding: "9px 18px",
      backdropFilter: "blur(6px)",
      WebkitBackdropFilter: "blur(6px)",
      transition: "background 0.15s, border-color 0.15s",
      fontFamily: "var(--font-body)",
      animation: "slideDown 0.2s ease"
    },
    onMouseEnter: e => {
      e.currentTarget.style.background = "rgba(229,9,20,0.85)";
      e.currentTarget.style.borderColor = "rgba(229,9,20,0.5)";
    },
    onMouseLeave: e => {
      e.currentTarget.style.background = "rgba(0,0,0,0.72)";
      e.currentTarget.style.borderColor = "rgba(255,255,255,0.18)";
    }
  }, React.createElement("span", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      letterSpacing: 1
    }
  }, "SKIP"), React.createElement("span", {
    style: {
      fontSize: 10,
      color: "rgba(255,255,255,0.7)",
      letterSpacing: 1
    }
  }, skipPrompt === "intro" ? "INTRO" : "OUTRO"))), currentProgressKey && (() => {
    const epPct = progress[currentProgressKey] || 0;
    const dur = durationRef.current;
    const hasMarkers = dur > 0 && (skipTimings?.intro || skipTimings?.outro);
    return epPct > 0 || hasMarkers ? React.createElement("div", {
      className: "progress-bar-row"
    }, React.createElement("div", {
      className: "progress-bar-outer",
      style: {
        position: "relative"
      }
    }, React.createElement("div", {
      className: "progress-bar-fill",
      style: {
        width: `${Math.min(epPct, 100)}%`
      }
    }), dur > 0 && skipTimings?.intro && React.createElement("div", {
      title: "Intro",
      style: {
        position: "absolute",
        top: 0,
        left: `${skipTimings.intro.startTime / dur * 100}%`,
        width: `${(skipTimings.intro.endTime - skipTimings.intro.startTime) / dur * 100}%`,
        height: "100%",
        background: "rgba(251,191,36,0.75)",
        borderRadius: 2,
        pointerEvents: "none"
      }
    }), dur > 0 && skipTimings?.outro && React.createElement("div", {
      title: "Outro",
      style: {
        position: "absolute",
        top: 0,
        left: `${skipTimings.outro.startTime / dur * 100}%`,
        width: `${(skipTimings.outro.endTime - skipTimings.outro.startTime) / dur * 100}%`,
        height: "100%",
        background: "rgba(251,191,36,0.75)",
        borderRadius: 2,
        pointerEvents: "none"
      }
    })), React.createElement("span", {
      style: {
        fontSize: 12,
        color: "var(--text3)"
      }
    }, epPct > 0 ? `${epPct.toFixed(0)}% watched` : "")) : null;
  })(), currentProgressKey && React.createElement("div", {
    className: "progress-mark-row"
  }, React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)",
      marginRight: 4
    }
  }, "Mark progress:"), [25, 50, 75, 100].map(p => React.createElement("button", {
    key: p,
    className: "btn btn-ghost",
    style: {
      padding: "5px 14px",
      fontSize: 12
    },
    onClick: () => saveProgress(currentProgressKey, p)
  }, p, "%")))), React.createElement("div", {
    className: "section"
  }, React.createElement("div", {
    className: "section-title"
  }, "Episodes"), seasons.length > 0 && React.createElement("div", {
    className: "season-selector"
  }, seasons.map(s => {
    const sw = seasonWatchedMap[s.season_number] ?? "none";
    return React.createElement("button", {
      key: s.season_number,
      className: `season-btn ${selectedSeason === s.season_number ? "active" : ""} ${sw === "all" ? "season-watched" : sw.startsWith("some") ? "season-partial" : ""}`,
      onClick: () => setSelectedSeason(s.season_number),
      onContextMenu: e => {
        e.preventDefault();
        e.stopPropagation();
        setSeasonMenu({
          x: e.clientX,
          y: e.clientY,
          seasonNum: s.season_number
        });
      },
      title: "Right-click to mark season as watched/unwatched"
    }, sw === "all" && React.createElement("span", {
      className: "season-watched-icon"
    }, "\u2713"), sw === "some25" && React.createElement(PartialCircleIcon, {
      pct: 25
    }), sw === "some50" && React.createElement(PartialCircleIcon, {
      pct: 50
    }), sw === "some75" && React.createElement(PartialCircleIcon, {
      pct: 75
    }), s.season_number === 0 ? "Specials" : `Season ${s.season_number}`);
  })), selectedSeason === 0 && !loadingSeason && React.createElement("div", {
    style: {
      margin: "8px 0",
      padding: "8px 12px",
      borderRadius: 8,
      background: "rgba(255,200,50,0.08)",
      border: "1px solid rgba(255,200,50,0.2)",
      fontSize: 12,
      color: "var(--text3)",
      display: "flex",
      alignItems: "center",
      gap: 8
    }
  }, React.createElement("span", null, React.createElement(_Icons.AlertIcon, {
    size: 28
  })), React.createElement("span", null, "Specials support varies by provider. If the wrong episode plays, try switching to a different source. But it can't be guaranteed that the correct Episode will be available.")), loadingSeason && React.createElement("div", {
    className: "loader"
  }, React.createElement("div", {
    className: "spinner"
  })), !loadingSeason && (seasonData?.episodes || episodeGroupCurrentEpisodes?.length) && React.createElement("div", {
    className: "episodes-grid"
  }, currentSeasonEpisodes.map(ep => {
    const pk = `tv_${item.id}_s${selectedSeason}e${ep.episode_number}`;
    return React.createElement(EpisodeCard, {
      key: ep.episode_number,
      ep: ep,
      itemId: item.id,
      selectedSeason: selectedSeason,
      epPct: progress[pk] || 0,
      epWatched: !!watched?.[pk],
      playing: playing,
      selectedEpNumber: selectedEp?.episode_number,
      downloadsByEpisodeKey: downloadsByEpisodeKey,
      restricted: restricted,
      onPlay: playEpisode,
      onContextMenu: setEpMenu,
      onGoToDownloads: onGoToDownloads
    });
  })))), showTrailer && trailerKey && React.createElement(_TrailerModal.default, {
    trailerKey: trailerKey,
    title: title,
    onClose: () => setShowTrailer(false)
  }), downloadConfirm && React.createElement(_DownloadConfirmModal.default, {
    title: downloadConfirm.type === "season" ? `${title} · Season ${downloadConfirm.season}` : `${title} · S${selectedSeason}E${downloadConfirm.ep.episode_number} ${downloadConfirm.ep.name || ""}`,
    runtimeMin: downloadConfirm.type === "season" ? d.episode_run_time?.[0] || 45 : downloadConfirm.ep.runtime || d.episode_run_time?.[0] || 45,
    episodeCount: downloadConfirm.type === "season" ? Math.max(1, (downloadConfirm.episodes || []).length) : 1,
    onCancel: () => setDownloadConfirm(null),
    onConfirm: () => {
      const target = downloadConfirm;
      setDownloadConfirm(null);
      const targetEp = target.type === "season" ? (target.episodes || [])[0] : target.ep;
      if (!targetEp) return;
      if (selectedEp?.episode_number === targetEp.episode_number && m3u8Url) {
        setShowDownload(true);
      } else {
        setPendingEpDownload(true);
        playEpisode(targetEp);
      }
    }
  }), epMenu && React.createElement(ContextMenu, {
    x: epMenu.x,
    y: epMenu.y,
    isWatched: !!watched?.[epMenu.pk],
    hasProgress: (progress?.[epMenu.pk] ?? 0) > 0,
    watchedLabel: "Mark as Watched",
    unwatchedLabel: "Mark as Unwatched",
    onMarkWatched: () => onMarkWatched?.(epMenu.pk),
    onMarkUnwatched: () => onMarkUnwatched?.(epMenu.pk),
    onMarkNotStarted: () => {
      onMarkUnwatched?.(epMenu.pk);
      saveProgress?.(epMenu.pk, 0);
      _storage.storage.set("dlTime_" + epMenu.pk, null);
    },
    onClose: () => setEpMenu(null)
  }), seasonMenu && React.createElement(ContextMenu, {
    x: seasonMenu.x,
    y: seasonMenu.y,
    isWatched: isSeasonWatched(seasonMenu.seasonNum),
    watchedLabel: "Mark Season as Watched",
    unwatchedLabel: "Mark Season as Unwatched",
    onMarkWatched: () => markSeasonWatched(seasonMenu.seasonNum),
    onMarkUnwatched: () => markSeasonUnwatched(seasonMenu.seasonNum),
    onClose: () => setSeasonMenu(null)
  }), showBlockedModal && React.createElement(_BlockedStatsModal.default, {
    sessionDomains: getBlockedDomains(),
    sessionTotal: blockedSession,
    alltimeTotal: blockedAlltime,
    onClose: () => setShowBlockedModal(false)
  }), showDownload && React.createElement(_DownloadModal.default, {
    onClose: () => setShowDownload(false),
    m3u8Url: m3u8Url,
    subtitles: interceptedSubs,
    mediaName: mediaName,
    downloaderFolder: downloaderFolder,
    setDownloaderFolder: handleSetDownloaderFolder,
    onOpenSettings: onSettings,
    onDownloadStarted: onDownloadStarted,
    mediaId: item.id,
    mediaType: "tv",
    season: selectedSeason,
    episode: selectedEp?.episode_number,
    posterPath: d.poster_path,
    tmdbId: item.id
  }));
}
const EpisodeCard = (0, _react.memo)(function EpisodeCard({
  ep,
  itemId,
  selectedSeason,
  epPct,
  epWatched,
  playing,
  selectedEpNumber,
  downloadsByEpisodeKey,
  restricted,
  onPlay,
  onContextMenu,
  onGoToDownloads,
  onDownloadEp
}) {
  const pk = `tv_${itemId}_s${selectedSeason}e${ep.episode_number}`;
  const isPlaying = playing && selectedEpNumber === ep.episode_number;
  const epUnreleased = isUnreleased(ep.air_date);
  const epDownload = downloadsByEpisodeKey.get(`s${selectedSeason}e${ep.episode_number}`) ?? null;
  return React.createElement("div", {
    className: `episode-card ${isPlaying ? "playing" : ""} ${epWatched ? "ep-watched" : ""} ${restricted ? "episode-card--restricted" : ""} ${epUnreleased ? "episode-card--unreleased" : ""}`,
    onClick: () => restricted || epUnreleased ? null : onPlay(ep),
    onContextMenu: e => {
      e.preventDefault();
      e.stopPropagation();
      if (!restricted && !epUnreleased) onContextMenu({
        x: e.clientX,
        y: e.clientY,
        pk
      });
    },
    style: epUnreleased ? {
      cursor: "default"
    } : undefined
  }, React.createElement("div", {
    className: "episode-thumb"
  }, ep.still_path ? React.createElement("img", {
    src: (0, _api.imgUrl)(ep.still_path, "w300"),
    alt: ep.name,
    loading: "lazy"
  }) : React.createElement("div", {
    style: {
      width: "100%",
      height: "100%",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: "var(--text3)"
    }
  }, React.createElement(_Icons.PlayIcon, null)), restricted ? React.createElement("div", {
    className: "episode-restricted-overlay"
  }, React.createElement(_Icons.RatingLockIcon, {
    size: 18
  }), React.createElement("span", null, "Inappropriate for your age")) : epUnreleased ? React.createElement("div", {
    className: "episode-restricted-overlay"
  }, React.createElement(_Icons.RatingLockIcon, {
    size: 18
  }), React.createElement("span", null, "Unreleased"), React.createElement("span", null, getDaysUntilRelease(ep.air_date))) : isPlaying ? React.createElement("div", {
    className: "episode-playing-badge"
  }, React.createElement("span", {
    className: "episode-playing-dot"
  }), "Playing") : React.createElement("div", {
    className: "episode-thumb-play"
  }, React.createElement(_Icons.PlayIcon, null))), React.createElement("div", {
    className: "episode-info"
  }, React.createElement("div", {
    className: "episode-num",
    style: {
      display: "flex",
      alignItems: "center",
      gap: 5
    }
  }, "E", ep.episode_number, epWatched && React.createElement(_Icons.WatchedIcon, {
    size: 14
  }), epDownload && React.createElement("span", {
    className: "ep-downloaded-badge",
    title: epDownload.status === "downloading" ? "Downloading… - click to view in Downloads" : "Downloaded - click to view in Downloads",
    style: {
      borderColor: epDownload.status === "downloading" ? "rgba(229,9,20,0.5)" : "rgba(72,199,116,0.5)",
      color: epDownload.status === "downloading" ? "var(--red)" : "#4caf50",
      background: epDownload.status === "downloading" ? "rgba(229,9,20,0.12)" : "rgba(72,199,116,0.18)"
    },
    onClick: e => {
      e.stopPropagation();
      onGoToDownloads?.(epDownload.id);
    }
  }, "\u2193")), React.createElement("div", {
    className: "episode-name"
  }, ep.name), React.createElement(EpisodeDesc, {
    overview: ep.overview,
    episodeName: ep.name
  }), !epWatched && epPct > 0 && React.createElement("div", {
    className: "episode-progress-bar"
  }, React.createElement("div", {
    className: "episode-progress-fill",
    style: {
      width: `${Math.min(epPct, 100)}%`
    }
  }))));
});
},
"./utils/ageRating": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.RATING_COUNTRIES = void 0;
exports.certToMinAge = certToMinAge;
exports.fetchMovieRating = fetchMovieRating;
exports.fetchTVRating = fetchTVRating;
exports.getAgeLimitSetting = getAgeLimitSetting;
exports.getRatingCountry = getRatingCountry;
exports.isRestricted = isRestricted;
var _api = require("./api");
const RATING_COUNTRIES = [{
  code: "US",
  label: "United States (MPAA / TV Parental)"
}, {
  code: "DE",
  label: "Germany (FSK)"
}, {
  code: "GB",
  label: "United Kingdom (BBFC)"
}, {
  code: "FR",
  label: "France (CNC)"
}, {
  code: "AU",
  label: "Australia (ACB)"
}, {
  code: "NZ",
  label: "New Zealand (OFLC)"
}, {
  code: "BR",
  label: "Brazil (DEJUS)"
}, {
  code: "CA",
  label: "Canada (CRTC)"
}, {
  code: "JP",
  label: "Japan (EIRIN)"
}];
exports.RATING_COUNTRIES = RATING_COUNTRIES;
const CERT_TO_AGE = {
  US: {
    g: 0,
    nr: 0,
    "not rated": 0,
    unrated: 0,
    "tv-y": 0,
    "tv-y7": 7,
    "tv-g": 0,
    pg: 7,
    "tv-pg": 7,
    "pg-13": 13,
    "tv-13": 13,
    "tv-14": 14,
    r: 17,
    "nc-17": 18,
    "tv-ma": 18,
    x: 18
  },
  DE: {
    "fsk 0": 0,
    0: 0,
    "fsk 6": 6,
    6: 6,
    "fsk 12": 12,
    12: 12,
    "fsk 16": 16,
    16: 16,
    "fsk 18": 18,
    18: 18,
    "ab 0": 0,
    "ab 6": 6,
    "ab 12": 12,
    "ab 16": 16,
    "ab 18": 18
  },
  GB: {
    u: 0,
    uc: 0,
    pg: 7,
    "12a": 12,
    12: 12,
    15: 15,
    18: 18,
    r18: 18
  },
  FR: {
    u: 0,
    g: 0,
    "tous publics": 0,
    10: 10,
    12: 12,
    16: 16,
    18: 18
  },
  AU: {
    g: 0,
    pg: 7,
    m: 15,
    ma: 15,
    "ma 15+": 15,
    "ma15+": 15,
    r: 18,
    "r 18+": 18,
    "r18+": 18,
    "x 18+": 18,
    "x18+": 18,
    rc: 18
  },
  NZ: {
    g: 0,
    pg: 7,
    m: 0,
    r13: 13,
    r15: 15,
    r16: 16,
    r18: 18,
    rp13: 13,
    rp16: 16
  },
  BR: {
    l: 0,
    livre: 0,
    10: 10,
    12: 12,
    14: 14,
    16: 16,
    18: 18
  },
  CA: {
    g: 0,
    pg: 7,
    "14a": 14,
    "18a": 18,
    r: 18,
    a: 18,
    "13+": 13,
    "16+": 16,
    "18+": 18
  },
  JP: {
    g: 0,
    pg12: 12,
    "pg-12": 12,
    r15: 15,
    "r-15": 15,
    r18: 18,
    "r-18": 18,
    "rz-18": 18
  }
};
function certToMinAge(cert, countryCode) {
  if (!cert || !cert.trim()) return null;
  const map = CERT_TO_AGE[countryCode] || CERT_TO_AGE["US"];
  const key = cert.trim().toLowerCase();
  if (key in map) return map[key];
  const stripped = key.replace(/\s+/g, "");
  for (const [k, v] of Object.entries(map)) {
    if (k.replace(/\s+/g, "") === stripped) return v;
  }
  return null;
}
function isRestricted(contentMinAge, ageLimitSetting) {
  if (ageLimitSetting === null || ageLimitSetting === undefined) return false;
  if (contentMinAge === null || contentMinAge === undefined) return false;
  return contentMinAge > ageLimitSetting;
}
async function fetchMovieRating(movieId, apiKey, countryCode) {
  try {
    const data = await (0, _api.tmdbFetch)(`/movie/${movieId}/release_dates`, apiKey);
    const results = data.results || [];
    const codesToTry = countryCode !== "US" ? [countryCode, "US"] : ["US"];
    for (const code of codesToTry) {
      const entry = results.find(r => r.iso_3166_1 === code);
      if (!entry) continue;
      const dates = entry.release_dates || [];
      const sorted = [...dates.filter(d => d.type === 3), ...dates.filter(d => d.type !== 3)];
      const certEntry = sorted.find(d => d.certification && d.certification.trim() !== "");
      if (certEntry) {
        const cert = certEntry.certification.trim();
        return {
          cert,
          minAge: certToMinAge(cert, code)
        };
      }
    }
    return {
      cert: null,
      minAge: null
    };
  } catch {
    return {
      cert: null,
      minAge: null
    };
  }
}
async function fetchTVRating(tvId, apiKey, countryCode) {
  try {
    const data = await (0, _api.tmdbFetch)(`/tv/${tvId}/content_ratings`, apiKey);
    const results = data.results || [];
    const codesToTry = countryCode !== "US" ? [countryCode, "US"] : ["US"];
    for (const code of codesToTry) {
      const entry = results.find(r => r.iso_3166_1 === code);
      if (entry?.rating && entry.rating.trim() !== "") {
        const cert = entry.rating.trim();
        return {
          cert,
          minAge: certToMinAge(cert, code)
        };
      }
    }
    return {
      cert: null,
      minAge: null
    };
  } catch {
    return {
      cert: null,
      minAge: null
    };
  }
}
function getAgeLimitSetting(storage) {
  const val = storage.get("ageLimit");
  if (val === null || val === undefined || val === "") return null;
  return Number(val);
}
function getRatingCountry(storage) {
  return storage.get("ratingCountry") || "US";
}
},
"./utils/androidBridge": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.androidBridge = void 0;
exports.emitNativeEvent = emitNativeEvent;
exports.isAndroidNative = isAndroidNative;
exports.isAndroidTvDevice = isAndroidTvDevice;
if (typeof window !== "undefined" && !window.AndroidBridge && window.webkit?.messageHandlers?.SingularityBridge) {
  const postIos = (method, args) => {
    try {
      window.webkit.messageHandlers.SingularityBridge.postMessage({
        method,
        args
      });
    } catch {}
  };
  window.AndroidBridge = {
    openExoPlayer: payloadJson => {
      postIos("openExoPlayer", [payloadJson]);
      return JSON.stringify({
        ok: true
      });
    },
    deliverNextServerStream: (url, sourceId) => {
      postIos("deliverNextServerStream", [url || "", sourceId || ""]);
    },
    setImmersiveMode: enabled => {
      postIos("setImmersiveMode", [!!enabled]);
    },
    isTvDevice: () => false,
    getDownloads: () => "[]",
    saveData: (k, v) => {
      try {
        localStorage.setItem("sb_" + k, v);
      } catch {}
    },
    loadData: k => {
      try {
        return localStorage.getItem("sb_" + k) || "";
      } catch {
        return "";
      }
    }
  };
}
const listeners = new Map();
function addEventListenerChannel(channel, cb) {
  if (!listeners.has(channel)) {
    listeners.set(channel, new Set());
  }
  listeners.get(channel).add(cb);
  return cb;
}
function removeEventListenerChannel(channel, cb) {
  const set = listeners.get(channel);
  if (set) set.delete(cb);
}
function emitNativeEvent(channel, payload) {
  try {
    window.dispatchEvent(new CustomEvent("streambert:" + channel, {
      detail: payload
    }));
  } catch {}
  const set = listeners.get(channel);
  if (!set) return;
  for (const cb of set) {
    try {
      cb(payload);
    } catch (e) {
      console.error(`[AndroidBridge] listener error on ${channel}:`, e);
    }
  }
}
if (typeof window !== "undefined") {
  window.__streambertDispatch = (channel, payload) => {
    let parsed = payload;
    if (typeof payload === "string") {
      try {
        parsed = JSON.parse(payload);
      } catch {
        parsed = payload;
      }
    }
    emitNativeEvent(channel, parsed);
  };
}
function getNative() {
  if (typeof window !== "undefined" && window.AndroidBridge) {
    return window.AndroidBridge;
  }
  return null;
}
function callNativeJson(method, ...args) {
  const native = getNative();
  if (!native || typeof native[method] !== "function") return null;
  try {
    const raw = native[method](...args);
    if (raw === undefined || raw === null || raw === "") return null;
    if (typeof raw === "string") {
      try {
        return JSON.parse(raw);
      } catch {
        return raw;
      }
    }
    return raw;
  } catch (e) {
    console.warn(`[AndroidBridge] ${method} failed:`, e);
    return null;
  }
}
function isAndroidNative() {
  return !!getNative();
}
function isAndroidTvDevice() {
  const native = getNative();
  if (native && typeof native.isTvDevice === "function") {
    try {
      return !!native.isTvDevice();
    } catch {}
  }
  if (typeof window !== "undefined") {
    const ua = (navigator.userAgent || "").toLowerCase();
    if (ua.includes("android tv") || ua.includes("aftm") || ua.includes("aftt") || ua.includes("aftb") || ua.includes("bravia") || ua.includes("shield") || ua.includes("leanback") || ua.includes("crkey") || ua.includes("googletv")) {
      return true;
    }
    if (localStorage.getItem("streambert_forceTvMode") === "1") {
      return true;
    }
  }
  return false;
}
const fallbackDownloadsKey = "streambert_android_downloads_v1";
function getFallbackDownloads() {
  try {
    return JSON.parse(localStorage.getItem(fallbackDownloadsKey) || "[]");
  } catch {
    return [];
  }
}
function saveFallbackDownloads(list) {
  try {
    localStorage.setItem(fallbackDownloadsKey, JSON.stringify(list));
  } catch {}
}
const androidBridge = {
  cleanUserAgent: typeof navigator !== "undefined" && navigator.userAgent || "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36",
  isNative: isAndroidNative,
  isTv: isAndroidTvDevice,
  onM3u8Found: cb => addEventListenerChannel("m3u8-found", cb),
  offM3u8Found: h => removeEventListenerChannel("m3u8-found", h),
  onSubtitleFound: cb => addEventListenerChannel("subtitle-found", cb),
  offSubtitleFound: h => removeEventListenerChannel("subtitle-found", h),
  onServerChallenge: cb => addEventListenerChannel("server-challenge-detected", cb),
  offServerChallenge: h => removeEventListenerChannel("server-challenge-detected", h),
  onNeedNextServer: cb => addEventListenerChannel("player-need-next-server", cb),
  offNeedNextServer: h => removeEventListenerChannel("player-need-next-server", h),
  onPreferredSourceUpdated: cb => addEventListenerChannel("preferred-source-updated", cb),
  offPreferredSourceUpdated: h => removeEventListenerChannel("preferred-source-updated", h),
  deliverNextServerStream: (url, sourceId) => callNative("deliverNextServerStream", String(url || ""), String(sourceId || "")),
  openNativePlayer: async (args = {}) => {
    const res = callNativeJson("openExoPlayer", JSON.stringify(args));
    if (res) return res;
    emitNativeEvent("open-inapp-exo-fallback", args);
    return {
      ok: true,
      mode: "inapp"
    };
  },
  onExoProgress: cb => addEventListenerChannel("exo-progress", cb),
  offExoProgress: h => removeEventListenerChannel("exo-progress", h),
  onExoEpisodeEnded: cb => addEventListenerChannel("exo-episode-ended", cb),
  offExoEpisodeEnded: h => removeEventListenerChannel("exo-episode-ended", h),
  openPipWindow: async (url, title, userAgent = null) => {
    const res = callNativeJson("enterPipMode", JSON.stringify({
      url,
      title,
      userAgent
    }));
    if (res) {
      emitNativeEvent("pip-window-opened", {});
      return res;
    }
    return {
      ok: false,
      reason: "pip-not-supported"
    };
  },
  closePipWindow: async () => {
    callNativeJson("exitPipMode");
    emitNativeEvent("pip-window-closed", {});
    return {
      ok: true
    };
  },
  getPipWebContentsId: async () => null,
  onPipOpened: cb => addEventListenerChannel("pip-window-opened", cb),
  offPipOpened: h => removeEventListenerChannel("pip-window-opened", h),
  onPipClosed: cb => addEventListenerChannel("pip-window-closed", cb),
  offPipClosed: h => removeEventListenerChannel("pip-window-closed", h),
  onDownloadProgress: cb => addEventListenerChannel("download-progress", cb),
  offDownloadProgress: h => removeEventListenerChannel("download-progress", h),
  checkDownloader: async _folder => {
    return {
      exists: true,
      token: "android-native-workmanager"
    };
  },
  runDownload: async args => {
    const res = callNativeJson("enqueueDownload", JSON.stringify(args));
    if (res && res.ok) return res;
    const id = "dl_" + Date.now() + "_" + Math.random().toString(36).slice(2, 7);
    const entry = {
      id,
      name: args.name || "Media Download",
      m3u8Url: args.m3u8Url,
      downloadPath: args.downloadPath || "/storage/emulated/0/Download/SingularityTV",
      filePath: `${args.downloadPath || "/storage/emulated/0/Download/SingularityTV"}/${(args.name || "video").replace(/[^a-zA-Z0-9._ -]/g, "")}.mp4`,
      status: "downloading",
      progress: 0,
      speed: "0 KB/s",
      eta: "Calculating…",
      size: "Pending",
      totalFragments: 0,
      completedFragments: 0,
      lastMessage: "Queued in Android WorkManager…",
      startedAt: Date.now(),
      completedAt: null,
      mediaId: args.mediaId || null,
      mediaType: args.mediaType || null,
      season: args.season ?? null,
      episode: args.episode ?? null,
      posterPath: args.posterPath || null,
      subtitles: Array.isArray(args.subtitles) ? args.subtitles : [],
      subtitlePaths: []
    };
    const list = [entry, ...getFallbackDownloads().filter(d => d.id !== id)];
    saveFallbackDownloads(list);
    return {
      ok: true,
      id
    };
  },
  pauseDownload: async id => {
    const res = callNativeJson("pauseDownload", String(id));
    if (res) return res;
    const list = getFallbackDownloads().map(d => d.id === id ? {
      ...d,
      status: "paused",
      speed: "0 B/s",
      lastMessage: "Paused"
    } : d);
    saveFallbackDownloads(list);
    emitNativeEvent("download-progress", {
      id,
      status: "paused",
      speed: "0 B/s",
      lastMessage: "Paused"
    });
    return {
      ok: true
    };
  },
  resumeDownload: async id => {
    const res = callNativeJson("resumeDownload", String(id));
    if (res) return res;
    const list = getFallbackDownloads().map(d => d.id === id ? {
      ...d,
      status: "downloading",
      lastMessage: "Resuming…"
    } : d);
    saveFallbackDownloads(list);
    emitNativeEvent("download-progress", {
      id,
      status: "downloading",
      lastMessage: "Resuming…"
    });
    return {
      ok: true
    };
  },
  cancelDownload: async id => {
    const res = callNativeJson("cancelDownload", String(id));
    if (res) return res;
    const list = getFallbackDownloads().map(d => d.id === id ? {
      ...d,
      status: "cancelled",
      speed: "",
      lastMessage: "Cancelled by user"
    } : d);
    saveFallbackDownloads(list);
    emitNativeEvent("download-progress", {
      id,
      status: "cancelled",
      speed: "",
      lastMessage: "Cancelled by user"
    });
    return {
      ok: true
    };
  },
  retryDownload: async id => {
    const res = callNativeJson("retryDownload", String(id));
    if (res) return res;
    const list = getFallbackDownloads().map(d => d.id === id ? {
      ...d,
      status: "downloading",
      progress: 0,
      lastMessage: "Retrying download…"
    } : d);
    saveFallbackDownloads(list);
    emitNativeEvent("download-progress", {
      id,
      status: "downloading",
      progress: 0,
      lastMessage: "Retrying download…"
    });
    return {
      ok: true
    };
  },
  getDownloads: async () => {
    const res = callNativeJson("getDownloads");
    if (Array.isArray(res)) return res;
    return getFallbackDownloads();
  },
  deleteDownload: async ({
    id,
    filePath
  }) => {
    const res = callNativeJson("deleteDownload", JSON.stringify({
      id,
      filePath
    }));
    if (res) return res;
    const list = getFallbackDownloads().filter(d => d.id !== id);
    saveFallbackDownloads(list);
    return {
      ok: true
    };
  },
  deleteAllDownloads: async () => {
    const res = callNativeJson("deleteAllDownloads");
    if (res) return res;
    const count = getFallbackDownloads().length;
    saveFallbackDownloads([]);
    return {
      ok: true,
      deleted: count,
      errors: 0
    };
  },
  getDownloadsSize: async () => {
    const res = callNativeJson("getDownloadsSize");
    if (res && typeof res.bytes === "number") return res;
    return {
      bytes: 0
    };
  },
  fileExists: async filePath => {
    const res = callNativeJson("fileExists", String(filePath || ""));
    if (typeof res === "boolean") return res;
    if (res && typeof res.exists === "boolean") return res.exists;
    return !!filePath;
  },
  scanDirectory: async folderPath => {
    const res = callNativeJson("scanDirectory", String(folderPath || ""));
    if (Array.isArray(res)) return res;
    return [];
  },
  pickFolder: async () => {
    const res = callNativeJson("pickFolder");
    if (res && typeof res.path === "string") return res.path;
    return "/storage/emulated/0/Download/SingularityTV";
  },
  showInFolder: async filePath => {
    callNativeJson("showInFolder", String(filePath || ""));
  },
  openExternal: async url => {
    const res = callNativeJson("openExternal", String(url || ""));
    if (!res && typeof window !== "undefined" && url) {
      window.open(url, "_blank", "noopener,noreferrer");
    }
  },
  openPath: async filePath => {
    const res = callNativeJson("openExoPlayer", JSON.stringify({
      url: filePath,
      title: (filePath || "").split("/").pop() || "Local Video",
      isLocal: true
    }));
    return res || {
      ok: true
    };
  },
  openPathAtTime: async (filePath, seconds, subtitlePaths) => {
    const res = callNativeJson("openExoPlayer", JSON.stringify({
      url: filePath,
      title: (filePath || "").split("/").pop() || "Local Video",
      startTimeSec: seconds || 0,
      subtitlePaths: subtitlePaths || [],
      isLocal: true
    }));
    return res || {
      ok: true
    };
  },
  openStreamExternal: async args => {
    const res = callNativeJson("openExoPlayer", JSON.stringify(args));
    if (res) return {
      ok: true,
      player: "ExoPlayer"
    };
    emitNativeEvent("open-inapp-exo-fallback", args);
    return {
      ok: true,
      player: "ExoPlayer"
    };
  },
  getInstallPath: async () => "/data/data/com.Singularity.streambert",
  getVideoDuration: async filePath => {
    const res = callNativeJson("getVideoDuration", String(filePath || ""));
    if (res && res.ok) return res;
    return {
      ok: false
    };
  },
  resolveHiAnime: async args => {
    const res = callNativeJson("resolveHiAnime", JSON.stringify(args));
    if (res) return res;
    return {
      ok: false,
      error: "Native HiAnime resolver requires Android runtime or fallback source"
    };
  },
  setPlayerVideo: async args => {
    const res = callNativeJson("setPlayerVideo", JSON.stringify(args));
    if (res && res.playerUrl) return res;
    return {
      playerUrl: args.url
    };
  },
  onHiAnimeProgress: cb => {
    const h = data => cb(typeof data === "string" ? data : data?.stage);
    addEventListenerChannel("hianime-progress", h);
    return () => removeEventListenerChannel("hianime-progress", h);
  },
  setImmersiveMode: enabled => {
    callNativeJson("setImmersiveMode", !!enabled);
  },
  searchSubtitles: async (args = {}) => {
    const scoreRelease = (name = "") => {
      const u = String(name).toUpperCase();
      let score = 0;
      if (/WEB[-_. ]?DL|WEBRIP|WEB[-_. ]?HDRIP|AMZN|NF|DSNP|ATVP|HMAX|PCOK/.test(u)) score += 50;
      if (/1080P|720P|X264|H264|H\.264/.test(u)) score += 20;
      if (/23\.976|23\.98|24FPS/.test(u)) score += 15;
      if (/BLURAY|BDRIP|BRRIP/.test(u)) score += 10;
      if (/EXTENDED|DIRECTORS[._ ]?CUT|UNRATED|THEATRICAL/.test(u)) score -= 45;
      if (/CAM|HDTS|TS|TC|WORKPRINT|25FPS/.test(u)) score -= 60;
      return score;
    };
    const decorateAndSort = list => {
      return list.map(item => {
        const syncScore = scoreRelease(item.release || item.file_name || "");
        const isWebSynced = syncScore >= 40;
        return {
          ...item,
          syncScore,
          release: isWebSynced && !String(item.release || "").includes("✓") ? `✓ WEB-Synced · ${item.release || item.file_name}` : item.release || item.file_name
        };
      }).sort((a, b) => b.syncScore - a.syncScore || (b.download_count || 0) - (a.download_count || 0));
    };
    const {
      mediaId,
      tmdbId,
      imdbId,
      mediaType,
      season,
      episode,
      languages,
      subdlApiKey,
      wyzieApiKey
    } = args;
    const lookupId = imdbId || tmdbId || mediaId;
    if (!lookupId) return {
      ok: false,
      error: "No media ID for subtitle lookup"
    };
    const errors = [];
    const collected = [];
    if (subdlApiKey) {
      try {
        const params = new URLSearchParams({
          api_key: subdlApiKey,
          type: mediaType === "tv" ? "tv" : "movie",
          subs_per_page: "30"
        });
        if (String(lookupId).startsWith("tt")) {
          params.set("imdb_id", String(lookupId));
        } else {
          params.set("tmdb_id", String(lookupId));
        }
        if (mediaType === "tv" && season != null) params.set("season_number", String(season));
        if (mediaType === "tv" && episode != null) params.set("episode_number", String(episode));
        if (languages) params.set("languages", languages.split("-")[0].toUpperCase());
        const res = await fetch(`https://api.subdl.com/api/v1/subtitles?${params}`);
        if (res.ok) {
          const data = await res.json();
          if (data.status && Array.isArray(data.subtitles)) {
            for (const s of data.subtitles) {
              collected.push({
                file_id: `subdl_${s.sd_id}_${encodeURIComponent(s.url)}`,
                file_name: s.name || s.release_name || "",
                language: (s.lang || "").toLowerCase(),
                release: s.release_name || s.name || "",
                uploader: s.author || "SubDL",
                download_count: s.downloads || 0,
                hearing_impaired: !!s.hi,
                ai_translated: false,
                via_subdl: true
              });
            }
          }
        }
      } catch (e) {
        errors.push(e.message);
      }
    }
    try {
      const params = new URLSearchParams({
        id: String(lookupId),
        format: "srt"
      });
      if (languages) params.set("language", languages.split("-")[0]);
      if (mediaType === "tv" && season != null) params.set("season", String(season));
      if (mediaType === "tv" && episode != null) params.set("episode", String(episode));
      if (wyzieApiKey) params.set("key", wyzieApiKey);
      const baseUrl = wyzieApiKey ? "https://sub.wyzie.io/search" : "https://subs.wyzie.ru/search";
      const res = await fetch(`${baseUrl}?${params}`);
      if (res.ok) {
        const data = await res.json();
        const items = (Array.isArray(data) ? data : []).filter(r => r.url);
        items.forEach((r, i) => {
          const rawUrl = r.url || "";
          const fullUrl = rawUrl.startsWith("http") ? rawUrl : `https://subs.wyzie.ru${rawUrl.startsWith("/") ? "" : "/"}${rawUrl}`;
          const displayName = r.display_name || r.name || r.release_name || r.fileName || `WEB-DL Subtitle #${i + 1}`;
          collected.push({
            file_id: `wyzie_${i}_${encodeURIComponent(fullUrl)}`,
            direct_url: fullUrl,
            file_name: displayName,
            language: r.language || languages || "en",
            release: displayName,
            uploader: "Wyzie",
            download_count: r.download_count || 100 - i,
            hearing_impaired: !!r.isHearingImpaired,
            ai_translated: !!r.isAiTranslated,
            via_wyzie: true
          });
        });
      }
    } catch (e) {
      errors.push(e.message);
    }
    if (String(lookupId).startsWith("tt")) {
      try {
        const osType = mediaType === "tv" ? "series" : "movie";
        const osTarget = mediaType === "tv" && season != null && episode != null ? `${lookupId}:${season}:${episode}` : String(lookupId);
        const res = await fetch(`https://opensubtitles-v3.strem.io/subtitles/${osType}/${encodeURIComponent(osTarget)}.json`);
        if (res.ok) {
          const data = await res.json();
          const subs = Array.isArray(data?.subtitles) ? data.subtitles : [];
          const wantLang = (languages || "en").split("-")[0].toLowerCase();
          subs.forEach((s, idx) => {
            if (!s.url) return;
            const sLang = String(s.lang || "").toLowerCase();
            if (wantLang && !sLang.startsWith(wantLang) && !(wantLang === "ar" && sLang === "ara") && !(wantLang === "en" && sLang === "eng")) {
              return;
            }
            collected.push({
              file_id: `wyzie_os_${idx}_${encodeURIComponent(s.url)}`,
              direct_url: s.url,
              file_name: `OpenSubtitles WEB-DL #${idx + 1} (${s.lang})`,
              language: wantLang,
              release: `WEB-DL 1080p Synced (${s.lang})`,
              uploader: "OpenSubtitles",
              download_count: 50,
              hearing_impaired: false,
              ai_translated: false,
              via_wyzie: true
            });
          });
        }
      } catch {}
    }
    if (collected.length > 0) {
      const sorted = decorateAndSort(collected);
      return {
        ok: true,
        results: sorted,
        via_wyzie: true
      };
    }
    return {
      ok: false,
      error: errors.join(" · ") || "No subtitles found for this language."
    };
  },
  getSubtitleUrl: async ({
    fileId
  }) => {
    const nativeRes = callNativeJson("getSubtitleUrl", String(fileId || ""));
    if (nativeRes && nativeRes.ok) return nativeRes;
    if (String(fileId).startsWith("wyzie_")) {
      const url = decodeURIComponent(String(fileId).split("_").slice(2).join("_"));
      return {
        ok: true,
        url,
        file_name: "",
        via_wyzie: true
      };
    }
    return {
      ok: false,
      error: "Unable to resolve subtitle URL"
    };
  },
  downloadSubtitlesForFile: async args => {
    const res = callNativeJson("downloadSubtitlesForFile", JSON.stringify(args));
    if (res) return res;
    return {
      ok: false,
      error: "Native storage required to write subtitle files"
    };
  },
  deleteSubtitleFile: async args => {
    const res = callNativeJson("deleteSubtitleFile", JSON.stringify(args));
    return res || {
      ok: true
    };
  },
  pruneSubtitlePaths: async ({
    downloadId
  }) => {
    const res = callNativeJson("pruneSubtitlePaths", String(downloadId || ""));
    return res || {
      ok: true,
      subtitlePaths: []
    };
  },
  getAppVersion: async () => {
    const v = callNativeJson("getAppVersion");
    return typeof v === "string" ? v : "2.7.0-android";
  },
  getPlatform: async () => {
    return isAndroidTvDevice() ? "android-tv" : "android";
  },
  setZoomFactor: factor => {
    try {
      document.documentElement.style.fontSize = `${Math.round((factor || 1) * 100)}%`;
    } catch {}
  },
  onConfirmClose: cb => addEventListenerChannel("confirm-close", cb),
  offConfirmClose: h => removeEventListenerChannel("confirm-close", h),
  respondClose: confirm => callNativeJson("respondClose", !!confirm),
  onWebviewEnterFullscreen: cb => addEventListenerChannel("webview-enter-fullscreen", cb),
  offWebviewEnterFullscreen: h => removeEventListenerChannel("webview-enter-fullscreen", h),
  onWebviewLeaveFullscreen: cb => addEventListenerChannel("webview-leave-fullscreen", cb),
  offWebviewLeaveFullscreen: h => removeEventListenerChannel("webview-leave-fullscreen", h),
  onBlockedUpdate: cb => addEventListenerChannel("blocked-stats-update", cb),
  offBlockedUpdate: h => removeEventListenerChannel("blocked-stats-update", h),
  getBlockStats: async () => {
    const res = callNativeJson("getBlockStats");
    if (res && typeof res.total === "number") return res;
    return {
      total: 0,
      domains: {}
    };
  },
  showNotification: async ({
    title,
    body,
    silent
  }) => {
    callNativeJson("showNotification", JSON.stringify({
      title,
      body,
      silent: !!silent
    }));
  },
  quitApp: async () => {
    callNativeJson("quitApp");
  },
  playerStopped: () => {
    callNativeJson("playerStopped");
  },
  getCacheSize: async () => {
    const res = callNativeJson("getCacheSize");
    return res && typeof res.bytes === "number" ? res : {
      bytes: 0
    };
  },
  clearAppCache: async () => {
    callNativeJson("clearAppCache");
    return {
      ok: true
    };
  },
  clearWatchData: async () => {
    callNativeJson("clearWatchData");
    return {
      ok: true
    };
  },
  resetApp: async () => {
    callNativeJson("resetApp");
    return {
      ok: true
    };
  },
  queryVideoProgress: async _id => {
    const res = callNativeJson("queryVideoProgress");
    return res || null;
  },
  secureGet: async key => {
    const res = callNativeJson("secureGet", String(key));
    if (res !== null && res !== undefined) {
      return typeof res === "object" ? res.value ?? null : String(res);
    }
    try {
      return localStorage.getItem(`streambert_sec_${key}`) || null;
    } catch {
      return null;
    }
  },
  secureSet: async (key, value) => {
    callNativeJson("secureSet", String(key), String(value ?? ""));
    try {
      if (!value) localStorage.removeItem(`streambert_sec_${key}`);else localStorage.setItem(`streambert_sec_${key}`, String(value));
    } catch {}
    return {
      ok: true
    };
  },
  getScheduledBackupSettings: async () => {
    const res = callNativeJson("getScheduledBackupSettings");
    if (res) return res;
    try {
      return JSON.parse(localStorage.getItem("streambert_sched_backup") || "null") || {
        enabled: false,
        path: "/storage/emulated/0/Download/SingularityTV/Backups",
        keepCount: 5,
        frequency: "startup",
        lastRun: null
      };
    } catch {
      return {
        enabled: false,
        path: "",
        keepCount: 5,
        frequency: "startup",
        lastRun: null
      };
    }
  },
  setScheduledBackupSettings: async settings => {
    callNativeJson("setScheduledBackupSettings", JSON.stringify(settings));
    try {
      localStorage.setItem("streambert_sched_backup", JSON.stringify(settings));
    } catch {}
    return {
      ok: true
    };
  },
  performScheduledBackup: async args => {
    const res = callNativeJson("performScheduledBackup", JSON.stringify(args));
    return res || {
      ok: true
    };
  },
  onScheduledBackupRequested: cb => addEventListenerChannel("scheduled-backup-requested", cb),
  offScheduledBackupRequested: h => removeEventListenerChannel("scheduled-backup-requested", h),
  detectUpdateFormat: async () => "apk",
  downloadAndInstallUpdate: async args => {
    const res = callNativeJson("downloadAndInstallUpdate", JSON.stringify(args));
    return res || {
      ok: false,
      error: "Use Android package installer for APK updates"
    };
  },
  cancelUpdate: async () => {
    callNativeJson("cancelUpdate");
  },
  onUpdateProgress: cb => addEventListenerChannel("update-progress", cb),
  offUpdateProgress: h => removeEventListenerChannel("update-progress", h),
  fetchReleaseImage: async ({
    url
  }) => url,
  discordRpcSetEnabled: async () => ({
    ok: true
  }),
  discordRpcUpdateActivity: async () => ({
    ok: true
  })
};
exports.androidBridge = androidBridge;
if (typeof window !== "undefined") {
  window.androidBridge = androidBridge;
  if (!window.electron) {
    window.electron = androidBridge;
  }
}
},
"./utils/aniSkip": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.clearAniSkipCache = clearAniSkipCache;
exports.fetchAniSkipTimings = fetchAniSkipTimings;
const ANISKIP_API = "https://api.aniskip.com/v2";
const CACHE_KEY = "streambert_aniskipCache";
const CACHE_TTL = 1000 * 60 * 60 * 24 * 7;
function getCache() {
  try {
    return JSON.parse(localStorage.getItem(CACHE_KEY) || "{}");
  } catch {
    return {};
  }
}
function setCache(cache) {
  try {
    localStorage.setItem(CACHE_KEY, JSON.stringify(cache));
  } catch {}
}
function clearAniSkipCache() {
  try {
    localStorage.removeItem(CACHE_KEY);
  } catch {}
}
async function fetchAniSkipTimings(malId, episodeNumber) {
  if (!malId || !episodeNumber) return null;
  const cacheKey = `${malId}_${episodeNumber}`;
  const cache = getCache();
  const hit = cache[cacheKey];
  if (hit && Date.now() < hit.expiresAt) return hit.data;
  try {
    const res = await fetch(`${ANISKIP_API}/skip-times/${malId}/${episodeNumber}` + `?types[]=op&types[]=ed&types[]=mixed-op&types[]=mixed-ed&episodeLength=0`);
    if (res.status === 404) {
      cache[cacheKey] = {
        data: null,
        expiresAt: Date.now() + CACHE_TTL
      };
      setCache(cache);
      return null;
    }
    if (!res.ok) return null;
    const data = await res.json();
    if (!data.found || !data.results?.length) {
      cache[cacheKey] = {
        data: null,
        expiresAt: Date.now() + CACHE_TTL
      };
      setCache(cache);
      return null;
    }
    const result = {};
    for (const entry of data.results) {
      const {
        skipType,
        interval
      } = entry;
      if (skipType === "op" || skipType === "mixed-op") {
        result.intro = {
          startTime: interval.startTime,
          endTime: interval.endTime
        };
      } else if (skipType === "ed" || skipType === "mixed-ed") {
        result.outro = {
          startTime: interval.startTime,
          endTime: interval.endTime
        };
      }
    }
    const timings = Object.keys(result).length > 0 ? result : null;
    cache[cacheKey] = {
      data: timings,
      expiresAt: Date.now() + CACHE_TTL
    };
    setCache(cache);
    return timings;
  } catch {
    return null;
  }
}
},
"./utils/api": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.cleanAnilistDescription = exports.buildAnilistSeasons = exports.PLAYER_SOURCES = exports.NON_ANIME_DEFAULT_SOURCE = exports.NEEDS_INTERCEPT = exports.FALLBACK_SERIES = exports.FALLBACK_MOVIES = exports.CLEAN_USER_AGENT = exports.ANIME_DEFAULT_SOURCE = void 0;
exports.clearMetadataCache = clearMetadataCache;
exports.fetchEpisodeGroup = exports.fetchAnilistData = exports.clearTmdbCache = void 0;
exports.fetchImdbId = fetchImdbId;
exports.fetchKinopoiskId = fetchKinopoiskId;
exports.fetchNumericId = fetchNumericId;
exports.isAnimeContent = exports.imgUrl = exports.getSourceUrl = exports.getNextNonAsyncSource = exports.getAnimeSourceUrl = void 0;
exports.registerIdMapping = registerIdMapping;
exports.tmdbFetch = exports.sourceUsesCleanUa = exports.sourceSupportsProgress = exports.sourceSupportsAnime = exports.sourceSkipsResetGuard = exports.sourceProgressViaFrames = exports.sourceNeedsKinopoisk = exports.sourceNeedsImdb = exports.sourceIsMovieOnly = exports.sourceIsAsync = exports.sourceIsAnimeCapable = exports.sourceIdType = exports.setApiErrorHandlers = void 0;
const CINEMETA_URLS = ["https://cinemeta-live.strem.io", "https://v3-cinemeta.strem.io"];
const TVMAZE_BASE = "https://api.tvmaze.com";
const ANILIST_API = "https://graphql.anilist.co";
const WIKIDATA_SPARQL = "https://query.wikidata.org/sparql";
try {
  if (typeof localStorage !== "undefined" && !localStorage.getItem("streambert_keyless_source_v2")) {
    localStorage.setItem("streambert_keyless_source_v2", "1");
    const cur = localStorage.getItem("streambert_playerSource");
    if (cur === '"vidrift"' || cur === "vidrift") {
      localStorage.setItem("streambert_playerSource", JSON.stringify("vidsrc"));
    }
  }
} catch {}
const imgUrl = (path, _size = "w500") => {
  if (!path || typeof path !== "string") return null;
  const trimmed = path.trim();
  if (!trimmed) return null;
  if (trimmed.startsWith("data:") || trimmed.startsWith("blob:") || trimmed.startsWith("file:")) {
    return trimmed;
  }
  if (trimmed.startsWith("https://")) return trimmed;
  if (trimmed.startsWith("http://")) {
    return "https://" + trimmed.slice("http://".length);
  }
  if (trimmed.startsWith("//")) return "https:" + trimmed;
  return null;
};
exports.imgUrl = imgUrl;
let _onUnreachable = null;
const setApiErrorHandlers = (_onAuth, onUnreachable) => {
  _onUnreachable = onUnreachable;
};
exports.setApiErrorHandlers = setApiErrorHandlers;
const _metaCache = new Map();
const META_CACHE_TTL = 15 * 60 * 1000;
function clearMetadataCache() {
  _metaCache.clear();
  try {
    localStorage.removeItem("streambert_trendingCache");
  } catch {}
}
const clearTmdbCache = clearMetadataCache;
exports.clearTmdbCache = clearTmdbCache;
const _idMap = new Map();
function registerIdMapping(ids = {}) {
  const {
    imdbId,
    numericId,
    anilistId,
    tvmazeId
  } = ids;
  const merged = {
    ...(imdbId ? _idMap.get(String(imdbId)) : null),
    ...(numericId ? _idMap.get(String(numericId)) : null),
    ...(imdbId ? {
      imdbId: String(imdbId)
    } : null),
    ...(numericId ? {
      numericId: String(numericId)
    } : null),
    ...(anilistId ? {
      anilistId: Number(anilistId)
    } : null),
    ...(tvmazeId ? {
      tvmazeId: Number(tvmazeId)
    } : null)
  };
  if (merged.imdbId) _idMap.set(String(merged.imdbId), merged);
  if (merged.numericId) _idMap.set(String(merged.numericId), merged);
  if (merged.anilistId) _idMap.set(`anilist:${merged.anilistId}`, merged);
  if (merged.imdbId && merged.numericId) {
    try {
      localStorage.setItem(`streambert_numid_${merged.imdbId}`, String(merged.numericId));
    } catch {}
  }
}
const FALLBACK_MOVIES = [{
  id: "tt0816692",
  imdb_id: "tt0816692",
  numeric_id: 157336,
  title: "Interstellar",
  media_type: "movie",
  release_date: "2014-11-05",
  runtime: 169,
  vote_average: 8.7,
  original_language: "en",
  certification: "PG-13",
  poster_path: "https://images.metahub.space/poster/medium/tt0816692/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt0816692/img",
  genres: [{
    id: "Adventure",
    name: "Adventure"
  }, {
    id: "Drama",
    name: "Drama"
  }, {
    id: "Sci-Fi",
    name: "Sci-Fi"
  }],
  overview: "When Earth becomes uninhabitable in the future, a farmer and ex-NASA pilot, Joseph Cooper, is tasked to pilot a spacecraft, along with a team of researchers, to find a new planet for humans."
}, {
  id: "tt15239678",
  imdb_id: "tt15239678",
  numeric_id: 693134,
  title: "Dune: Part Two",
  media_type: "movie",
  release_date: "2024-02-27",
  runtime: 166,
  vote_average: 8.5,
  original_language: "en",
  certification: "PG-13",
  poster_path: "https://images.metahub.space/poster/medium/tt15239678/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt15239678/img",
  genres: [{
    id: "Action",
    name: "Action"
  }, {
    id: "Adventure",
    name: "Adventure"
  }, {
    id: "Sci-Fi",
    name: "Sci-Fi"
  }],
  overview: "Paul Atreides unites with Chani and the Fremen while on a warpath of revenge against the conspirators who destroyed his family."
}, {
  id: "tt15398776",
  imdb_id: "tt15398776",
  numeric_id: 872585,
  title: "Oppenheimer",
  media_type: "movie",
  release_date: "2023-07-19",
  runtime: 180,
  vote_average: 8.3,
  original_language: "en",
  certification: "R",
  poster_path: "https://images.metahub.space/poster/medium/tt15398776/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt15398776/img",
  genres: [{
    id: "Biography",
    name: "Biography"
  }, {
    id: "Drama",
    name: "Drama"
  }, {
    id: "History",
    name: "History"
  }],
  overview: "The story of J. Robert Oppenheimer's role in the development of the atomic bomb during World War II."
}, {
  id: "tt0133093",
  imdb_id: "tt0133093",
  numeric_id: 603,
  title: "The Matrix",
  media_type: "movie",
  release_date: "1999-03-31",
  runtime: 136,
  vote_average: 8.7,
  original_language: "en",
  certification: "R",
  poster_path: "https://images.metahub.space/poster/medium/tt0133093/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt0133093/img",
  genres: [{
    id: "Action",
    name: "Action"
  }, {
    id: "Sci-Fi",
    name: "Sci-Fi"
  }],
  overview: "When a beautiful stranger leads computer hacker Neo to a forbidding underworld, he discovers the shocking truth—the life he knows is the elaborate deception of an evil cyber-intelligence."
}, {
  id: "tt1375666",
  imdb_id: "tt1375666",
  numeric_id: 27205,
  title: "Inception",
  media_type: "movie",
  release_date: "2010-07-16",
  runtime: 148,
  vote_average: 8.8,
  original_language: "en",
  certification: "PG-13",
  poster_path: "https://images.metahub.space/poster/medium/tt1375666/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt1375666/img",
  genres: [{
    id: "Action",
    name: "Action"
  }, {
    id: "Adventure",
    name: "Adventure"
  }, {
    id: "Sci-Fi",
    name: "Sci-Fi"
  }],
  overview: "A thief who steals corporate secrets through the use of dream-sharing technology is given the inverse task of planting an idea into the mind of a C.E.O."
}, {
  id: "tt0468569",
  imdb_id: "tt0468569",
  numeric_id: 155,
  title: "The Dark Knight",
  media_type: "movie",
  release_date: "2008-07-18",
  runtime: 152,
  vote_average: 9.0,
  original_language: "en",
  certification: "PG-13",
  poster_path: "https://images.metahub.space/poster/medium/tt0468569/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt0468569/img",
  genres: [{
    id: "Action",
    name: "Action"
  }, {
    id: "Crime",
    name: "Crime"
  }, {
    id: "Drama",
    name: "Drama"
  }],
  overview: "When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests of his ability to fight injustice."
}, {
  id: "tt4633694",
  imdb_id: "tt4633694",
  numeric_id: 324857,
  title: "Spider-Man: Into the Spider-Verse",
  media_type: "movie",
  release_date: "2018-12-14",
  runtime: 117,
  vote_average: 8.4,
  original_language: "en",
  certification: "PG",
  poster_path: "https://images.metahub.space/poster/medium/tt4633694/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt4633694/img",
  genres: [{
    id: "Animation",
    name: "Animation"
  }, {
    id: "Action",
    name: "Action"
  }, {
    id: "Adventure",
    name: "Adventure"
  }],
  overview: "Teen Miles Morales becomes the Spider-Man of his universe and must join with five spider-powered individuals from other dimensions to stop a threat for all realities."
}, {
  id: "tt5311514",
  imdb_id: "tt5311514",
  numeric_id: 372058,
  title: "Your Name.",
  media_type: "movie",
  release_date: "2016-08-26",
  runtime: 106,
  vote_average: 8.4,
  original_language: "ja",
  origin_country: ["JP"],
  genre_ids: [16],
  certification: "PG",
  poster_path: "https://images.metahub.space/poster/medium/tt5311514/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt5311514/img",
  genres: [{
    id: 16,
    name: "Animation"
  }, {
    id: "Drama",
    name: "Drama"
  }, {
    id: "Fantasy",
    name: "Fantasy"
  }],
  overview: "Two teenagers share a profound, magical connection upon discovering they are swapping bodies. Things manage to become even more complicated when the boy and girl decide to meet in person."
}];
exports.FALLBACK_MOVIES = FALLBACK_MOVIES;
const FALLBACK_SERIES = [{
  id: "tt0903747",
  imdb_id: "tt0903747",
  numeric_id: 1396,
  name: "Breaking Bad",
  title: "Breaking Bad",
  media_type: "tv",
  first_air_date: "2008-01-20",
  vote_average: 9.5,
  original_language: "en",
  certification: "TV-MA",
  status: "Ended",
  number_of_seasons: 5,
  number_of_episodes: 62,
  poster_path: "https://images.metahub.space/poster/medium/tt0903747/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt0903747/img",
  genres: [{
    id: "Crime",
    name: "Crime"
  }, {
    id: "Drama",
    name: "Drama"
  }, {
    id: "Thriller",
    name: "Thriller"
  }],
  overview: "A chemistry teacher diagnosed with inoperable lung cancer turns to manufacturing and selling methamphetamine with a former student in order to secure his family's future."
}, {
  id: "tt4574334",
  imdb_id: "tt4574334",
  numeric_id: 66732,
  name: "Stranger Things",
  title: "Stranger Things",
  media_type: "tv",
  first_air_date: "2016-07-15",
  vote_average: 8.7,
  original_language: "en",
  certification: "TV-14",
  status: "Returning Series",
  number_of_seasons: 4,
  number_of_episodes: 34,
  poster_path: "https://images.metahub.space/poster/medium/tt4574334/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt4574334/img",
  genres: [{
    id: "Drama",
    name: "Drama"
  }, {
    id: "Fantasy",
    name: "Fantasy"
  }, {
    id: "Horror",
    name: "Horror"
  }],
  overview: "When a young boy vanishes, a small town uncovers a mystery involving secret experiments, terrifying supernatural forces, and one strange little girl."
}, {
  id: "tt2560140",
  imdb_id: "tt2560140",
  numeric_id: 1429,
  name: "Attack on Titan",
  title: "Attack on Titan",
  media_type: "tv",
  first_air_date: "2013-04-07",
  vote_average: 9.1,
  original_language: "ja",
  origin_country: ["JP"],
  genre_ids: [16],
  certification: "TV-MA",
  status: "Ended",
  number_of_seasons: 4,
  number_of_episodes: 89,
  poster_path: "https://images.metahub.space/poster/medium/tt2560140/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt2560140/img",
  genres: [{
    id: 16,
    name: "Animation"
  }, {
    id: "Action",
    name: "Action"
  }, {
    id: "Adventure",
    name: "Adventure"
  }],
  overview: "After his hometown is destroyed and his mother is killed, young Eren Jaeger vows to cleanse the earth of the giant humanoid Titans that have brought humanity to the brink of extinction."
}, {
  id: "tt11126994",
  imdb_id: "tt11126994",
  numeric_id: 94605,
  name: "Arcane",
  title: "Arcane",
  media_type: "tv",
  first_air_date: "2021-11-06",
  vote_average: 9.0,
  original_language: "en",
  certification: "TV-14",
  status: "Ended",
  number_of_seasons: 2,
  number_of_episodes: 18,
  poster_path: "https://images.metahub.space/poster/medium/tt11126994/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt11126994/img",
  genres: [{
    id: 16,
    name: "Animation"
  }, {
    id: "Action",
    name: "Action"
  }, {
    id: "Sci-Fi",
    name: "Sci-Fi"
  }],
  overview: "Set in Utopian Piltover and the oppressed underground of Zaun, the story follows the origins of two iconic League Of Legends champions and the power that will tear them apart."
}, {
  id: "tt12343534",
  imdb_id: "tt12343534",
  numeric_id: 95479,
  name: "Jujutsu Kaisen",
  title: "Jujutsu Kaisen",
  media_type: "tv",
  first_air_date: "2020-10-03",
  vote_average: 8.6,
  original_language: "ja",
  origin_country: ["JP"],
  genre_ids: [16],
  certification: "TV-MA",
  status: "Returning Series",
  number_of_seasons: 2,
  number_of_episodes: 47,
  poster_path: "https://images.metahub.space/poster/medium/tt12343534/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt12343534/img",
  genres: [{
    id: 16,
    name: "Animation"
  }, {
    id: "Action",
    name: "Action"
  }, {
    id: "Fantasy",
    name: "Fantasy"
  }],
  overview: "A boy swallows a cursed talisman - the finger of a demon - and becomes cursed himself. He enters a shaman's school to be able to locate the demon's other body parts and thus exorcise himself."
}, {
  id: "tt0388629",
  imdb_id: "tt0388629",
  numeric_id: 37854,
  name: "One Piece",
  title: "One Piece",
  media_type: "tv",
  first_air_date: "1999-10-20",
  vote_average: 9.0,
  original_language: "ja",
  origin_country: ["JP"],
  genre_ids: [16],
  certification: "TV-14",
  status: "Returning Series",
  number_of_seasons: 22,
  number_of_episodes: 1122,
  poster_path: "https://images.metahub.space/poster/medium/tt0388629/img",
  backdrop_path: "https://images.metahub.space/background/medium/tt0388629/img",
  genres: [{
    id: 16,
    name: "Animation"
  }, {
    id: "Action",
    name: "Action"
  }, {
    id: "Adventure",
    name: "Adventure"
  }],
  overview: "Monkey D. Luffy sets off on an adventure with his pirate crew in hopes of finding the greatest treasure ever, known as the 'One Piece'."
}];
exports.FALLBACK_SERIES = FALLBACK_SERIES;
for (const m of [...FALLBACK_MOVIES, ...FALLBACK_SERIES]) {
  registerIdMapping({
    imdbId: m.imdb_id,
    numericId: m.numeric_id
  });
}
async function fetchJsonWithTimeout(url, options = {}, timeoutMs = 9000) {
  const controller = new AbortController();
  const tid = setTimeout(() => controller.abort(), timeoutMs);
  try {
    const res = await fetch(url, {
      ...options,
      signal: controller.signal
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return await res.json();
  } finally {
    clearTimeout(tid);
  }
}
async function fetchCinemeta(subpath) {
  let lastErr = null;
  for (const base of CINEMETA_URLS) {
    try {
      const json = await fetchJsonWithTimeout(`${base}${subpath}`, {}, 8000);
      if (json && (json.metas || json.meta)) return json;
    } catch (e) {
      lastErr = e;
    }
  }
  throw lastErr || new Error("Cinemeta unreachable");
}
function normalizeCinemetaItem(m, forcedType = null) {
  if (!m) return null;
  const mediaType = forcedType || (m.type === "series" || m.type === "tv" ? "tv" : "movie");
  const imdbId = m.imdb_id || (String(m.id || "").startsWith("tt") ? m.id : null);
  const numericId = m.moviedb_id || null;
  const canonicalId = imdbId || numericId || m.id;
  registerIdMapping({
    imdbId,
    numericId
  });
  const yearStr = String(m.releaseInfo || m.year || "").slice(0, 4);
  const releasedStr = m.released ? String(m.released).slice(0, 10) : yearStr ? `${yearStr}-01-01` : "";
  const genresRaw = Array.isArray(m.genres) ? m.genres : [];
  const genres = genresRaw.map((g, i) => typeof g === "string" ? {
    id: g === "Animation" ? 16 : g || i,
    name: g
  } : g);
  const isAnim = genresRaw.some(g => String(g?.name || g).toLowerCase().includes("animation") || String(g?.name || g).toLowerCase().includes("anime"));
  const countryStr = String(m.country || "").toUpperCase();
  const isJp = countryStr.includes("JAPAN") || countryStr.includes("JP") || m.original_language === "ja";
  const runtimeMatch = String(m.runtime || "").match(/(\d+)/);
  const runtimeMins = runtimeMatch ? parseInt(runtimeMatch[1], 10) : null;
  return {
    id: canonicalId,
    imdb_id: imdbId,
    moviedb_id: numericId,
    media_type: mediaType,
    title: mediaType === "movie" ? m.name || m.title : undefined,
    name: mediaType === "tv" ? m.name || m.title : undefined,
    overview: m.description || m.overview || "",
    poster_path: m.poster || (imdbId ? `https://images.metahub.space/poster/medium/${imdbId}/img` : null),
    backdrop_path: m.background || (imdbId ? `https://images.metahub.space/background/medium/${imdbId}/img` : m.poster || null),
    release_date: mediaType === "movie" ? releasedStr : undefined,
    first_air_date: mediaType === "tv" ? releasedStr : undefined,
    vote_average: m.imdbRating ? parseFloat(m.imdbRating) : 0,
    runtime: runtimeMins,
    genres,
    genre_ids: isAnim ? [16] : [],
    original_language: isJp ? "ja" : "en",
    origin_country: isJp ? ["JP"] : [],
    certification: m.certification || m.ageRating || null,
    status: m.status || "Released",
    _rawVideos: Array.isArray(m.videos) ? m.videos : null,
    _rawTrailers: Array.isArray(m.trailers) ? m.trailers : null,
    _rawCast: Array.isArray(m.cast) ? m.cast : [],
    _rawDirectors: Array.isArray(m.director) ? m.director : [],
    _rawWriters: Array.isArray(m.writer) ? m.writer : []
  };
}
function buildSeasonsFromVideos(videos = []) {
  const seasonMap = new Map();
  for (const v of videos) {
    const sNum = Number(v.season ?? v.season_number ?? 1);
    const epNum = Number(v.episode ?? v.number ?? v.episode_number ?? 1);
    if (!Number.isFinite(sNum) || sNum < 0) continue;
    if (!seasonMap.has(sNum)) seasonMap.set(sNum, []);
    seasonMap.get(sNum).push({
      id: v.id || `${sNum}_${epNum}`,
      episode_number: epNum,
      season_number: sNum,
      name: v.name || v.title || `Episode ${epNum}`,
      overview: v.overview || v.description || "",
      still_path: v.thumbnail || null,
      air_date: v.released ? String(v.released).slice(0, 10) : null
    });
  }
  const seasons = [...seasonMap.entries()].sort((a, b) => a[0] - b[0]).map(([sNum, eps]) => {
    eps.sort((a, b) => a.episode_number - b.episode_number);
    return {
      season_number: sNum,
      name: sNum === 0 ? "Specials" : `Season ${sNum}`,
      episode_count: eps.length,
      episodes: eps
    };
  });
  return seasons;
}
async function fetchTvMazeSeries(idOrImdb) {
  let show = null;
  const str = String(idOrImdb);
  if (str.startsWith("tt")) {
    show = await fetchJsonWithTimeout(`${TVMAZE_BASE}/lookup/shows?imdb=${encodeURIComponent(str)}`);
  } else if (str.startsWith("tvmaze:")) {
    const tvmId = str.split(":")[1];
    show = await fetchJsonWithTimeout(`${TVMAZE_BASE}/shows/${tvmId}`);
  }
  if (!show || !show.id) return null;
  const [episodes, cast] = await Promise.all([fetchJsonWithTimeout(`${TVMAZE_BASE}/shows/${show.id}/episodes?specials=1`).catch(() => []), fetchJsonWithTimeout(`${TVMAZE_BASE}/shows/${show.id}/cast`).catch(() => [])]);
  const stripHtml = s => String(s || "").replace(/<[^>]+>/g, "").trim();
  const mappedVideos = (episodes || []).map(ep => ({
    id: ep.id,
    season: ep.season,
    episode: ep.number || 1,
    name: ep.name || `Episode ${ep.number || 1}`,
    overview: stripHtml(ep.summary),
    thumbnail: ep.image?.original || ep.image?.medium || null,
    released: ep.airdate || null
  }));
  const seasons = buildSeasonsFromVideos(mappedVideos);
  const imdbId = show.externals?.imdb || (str.startsWith("tt") ? str : null);
  registerIdMapping({
    imdbId,
    tvmazeId: show.id
  });
  return {
    id: imdbId || `tvmaze:${show.id}`,
    imdb_id: imdbId,
    name: show.name,
    title: show.name,
    media_type: "tv",
    first_air_date: show.premiered || "",
    vote_average: show.rating?.average || 0,
    status: show.status || "Ended",
    original_language: show.language?.toLowerCase().startsWith("ja") ? "ja" : "en",
    origin_country: show.network?.country?.code ? [show.network.country.code] : [],
    poster_path: show.image?.original || show.image?.medium || null,
    backdrop_path: show.image?.original || show.image?.medium || null,
    overview: stripHtml(show.summary),
    genres: (show.genres || []).map(g => ({
      id: g === "Anime" ? 16 : g,
      name: g
    })),
    genre_ids: (show.genres || []).includes("Anime") ? [16] : [],
    seasons,
    number_of_seasons: seasons.filter(s => s.season_number > 0).length,
    number_of_episodes: mappedVideos.length,
    _seasonsByNumber: Object.fromEntries(seasons.map(s => [s.season_number, s])),
    _cast: (cast || []).map((c, idx) => ({
      id: c.person?.id || idx,
      name: c.person?.name || "Unknown",
      character: c.character?.name || "",
      profile_path: c.person?.image?.medium || c.person?.image?.original || null
    }))
  };
}
async function searchImdbSuggestions(query) {
  const q = String(query || "").trim();
  if (!q) return [];
  const slug = q.toLowerCase().replace(/\s+/g, "_").replace(/[^a-z0-9_]/g, "");
  if (!slug.replace(/_/g, "")) return [];
  const firstChar = slug[0];
  const data = await fetchJsonWithTimeout(`https://v3.sg.media-imdb.com/suggestion/${firstChar}/${encodeURIComponent(slug)}.json`, {}, 6000);
  const items = Array.isArray(data?.d) ? data.d : [];
  return items.filter(i => i.id && String(i.id).startsWith("tt")).map(i => {
    const qid = String(i.qid || i.q || "").toLowerCase();
    const isTv = qid.includes("tv") || qid.includes("series");
    return {
      id: i.id,
      imdb_id: i.id,
      media_type: isTv ? "tv" : "movie",
      title: !isTv ? i.l : undefined,
      name: isTv ? i.l : undefined,
      release_date: !isTv && i.y ? `${i.y}-01-01` : undefined,
      first_air_date: isTv && i.y ? `${i.y}-01-01` : undefined,
      poster_path: i.i?.imageUrl || `https://images.metahub.space/poster/medium/${i.id}/img`,
      backdrop_path: `https://images.metahub.space/background/medium/${i.id}/img`,
      vote_average: 0,
      overview: i.s ? `Starring: ${i.s}` : ""
    };
  });
}
async function searchArabicViaWikidata(query) {
  const q = String(query || "").trim();
  if (!q) return [];
  const collected = [];
  const seen = new Set();
  const pushItem = item => {
    if (!item || !item.id) return;
    const key = `${item.media_type}_${item.id}`;
    if (seen.has(key)) return;
    seen.add(key);
    collected.push(item);
  };
  try {
    const searchData = await fetchJsonWithTimeout(`https://www.wikidata.org/w/api.php?action=wbsearchentities&search=${encodeURIComponent(q)}&language=ar&uselang=ar&type=item&limit=10&format=json&origin=*`, {}, 5500);
    const hits = Array.isArray(searchData?.search) ? searchData.search : [];
    const qids = hits.map(h => h.id).filter(Boolean).slice(0, 10);
    if (qids.length > 0) {
      const entData = await fetchJsonWithTimeout(`https://www.wikidata.org/w/api.php?action=wbgetentities&ids=${qids.join("|")}&props=claims|labels&languages=ar|en&format=json&origin=*`, {}, 5500);
      const entities = entData?.entities || {};
      const enQueries = [];
      for (const qid of qids) {
        const ent = entities[qid];
        if (!ent) continue;
        const claims = ent.claims || {};
        const imdbVal = claims.P345?.[0]?.mainsnak?.datavalue?.value || "";
        const enLabel = ent.labels?.en?.value || "";
        const arLabel = ent.labels?.ar?.value || q;
        const p31Ids = (claims.P31 || []).map(c => c?.mainsnak?.datavalue?.value?.id).filter(Boolean);
        const isTv = p31Ids.includes("Q5398426") || p31Ids.includes("Q581714") || p31Ids.includes("Q15416");
        const isPerson = p31Ids.includes("Q5");
        if (imdbVal && imdbVal.startsWith("tt")) {
          pushItem({
            id: imdbVal,
            imdb_id: imdbVal,
            media_type: isTv ? "tv" : "movie",
            title: !isTv ? enLabel || arLabel : undefined,
            name: isTv ? enLabel || arLabel : undefined,
            poster_path: `https://images.metahub.space/poster/medium/${imdbVal}/img`,
            backdrop_path: `https://images.metahub.space/background/medium/${imdbVal}/img`,
            vote_average: 0,
            overview: arLabel && enLabel && arLabel !== enLabel ? arLabel : ""
          });
        } else if (enLabel && (isPerson || !imdbVal)) {
          enQueries.push(enLabel);
        }
      }
      if (enQueries.length > 0 && collected.length < 8) {
        const extra = await Promise.all(enQueries.slice(0, 2).map(eq => searchImdbSuggestions(eq).catch(() => [])));
        for (const list of extra) {
          for (const item of list) pushItem(item);
        }
      }
    }
  } catch {}
  if (collected.length < 6) {
    try {
      const tr = await fetchJsonWithTimeout(`https://translate.googleapis.com/translate_a/single?client=gtx&sl=ar&tl=en&dt=t&q=${encodeURIComponent(q)}`, {}, 4000);
      const enText = Array.isArray(tr?.[0]) ? tr[0].map(p => p?.[0] || "").join("").trim() : "";
      if (enText && /[a-zA-Z]/.test(enText)) {
        const [mList, sList, iList] = await Promise.all([fetchCinemeta(`/catalog/movie/top/search=${encodeURIComponent(enText)}.json`).then(d => (d.metas || []).map(m => normalizeCinemetaItem(m, "movie"))).catch(() => []), fetchCinemeta(`/catalog/series/top/search=${encodeURIComponent(enText)}.json`).then(d => (d.metas || []).map(m => normalizeCinemetaItem(m, "tv"))).catch(() => []), searchImdbSuggestions(enText).catch(() => [])]);
        for (const item of [...iList, ...mList, ...sList]) pushItem(item);
      }
    } catch {}
  }
  return collected;
}
async function resolveIdsViaWikidata(id, type = "movie") {
  const str = String(id || "").trim();
  if (!str) return null;
  const cached = _idMap.get(str);
  if (cached?.imdbId && cached?.numericId) return cached;
  const isImdb = str.startsWith("tt");
  const tmdbProp = type === "tv" ? "P4983" : "P4947";
  const query = isImdb ? `SELECT ?mId ?tvId ?kp WHERE { ?item wdt:P345 "${str}" . OPTIONAL { ?item wdt:P4947 ?mId . } OPTIONAL { ?item wdt:P4983 ?tvId . } OPTIONAL { ?item wdt:P2603 ?kp . } } LIMIT 1` : `SELECT ?imdb ?kp WHERE { ?item wdt:${tmdbProp} "${str}" . OPTIONAL { ?item wdt:P345 ?imdb . } OPTIONAL { ?item wdt:P2603 ?kp . } } LIMIT 1`;
  try {
    const data = await fetchJsonWithTimeout(`${WIKIDATA_SPARQL}?format=json&query=${encodeURIComponent(query)}`, {
      headers: {
        Accept: "application/sparql-results+json"
      }
    }, 6000);
    const row = data?.results?.bindings?.[0];
    if (!row) return cached || null;
    const imdbId = isImdb ? str : row.imdb?.value || null;
    const mVal = row.mId?.value || null;
    const tvVal = row.tvId?.value || null;
    const numericId = !isImdb ? str : type === "tv" ? tvVal || mVal : mVal || tvVal;
    const kpId = row.kp?.value || null;
    registerIdMapping({
      imdbId,
      numericId
    });
    return {
      imdbId,
      numericId,
      kpId
    };
  } catch {
    return cached || null;
  }
}
const tmdbFetch = async (path, _unusedApiKey = null) => {
  const cleanPath = String(path || "").split("?")[0];
  const cached = _metaCache.get(path);
  if (cached && Date.now() < cached.expiresAt) return cached.data;
  const storeCache = data => {
    _metaCache.set(path, {
      data,
      expiresAt: Date.now() + META_CACHE_TTL
    });
    return data;
  };
  try {
    if (cleanPath === "/trending/movie/week") {
      try {
        const data = await fetchCinemeta("/catalog/movie/top.json");
        const results = (data.metas || []).slice(0, 28).map(m => normalizeCinemetaItem(m, "movie")).filter(Boolean);
        if (results.length > 0) return storeCache({
          results
        });
      } catch {}
      return storeCache({
        results: FALLBACK_MOVIES
      });
    }
    if (cleanPath === "/trending/tv/week") {
      try {
        const data = await fetchCinemeta("/catalog/series/top.json");
        const results = (data.metas || []).slice(0, 28).map(m => normalizeCinemetaItem(m, "tv")).filter(Boolean);
        if (results.length > 0) return storeCache({
          results
        });
      } catch {}
      return storeCache({
        results: FALLBACK_SERIES
      });
    }
    if (cleanPath === "/movie/top_rated") {
      try {
        const data = await fetchCinemeta("/catalog/movie/imdbRating.json");
        const results = (data.metas || []).slice(0, 20).map(m => normalizeCinemetaItem(m, "movie")).filter(Boolean);
        if (results.length > 0) return storeCache({
          results
        });
      } catch {}
      return storeCache({
        results: [...FALLBACK_MOVIES].reverse()
      });
    }
    if (cleanPath === "/tv/top_rated") {
      try {
        const data = await fetchCinemeta("/catalog/series/imdbRating.json");
        const results = (data.metas || []).slice(0, 20).map(m => normalizeCinemetaItem(m, "tv")).filter(Boolean);
        if (results.length > 0) return storeCache({
          results
        });
      } catch {}
      return storeCache({
        results: [...FALLBACK_SERIES].reverse()
      });
    }
    if (cleanPath === "/search/multi") {
      const qParam = new URLSearchParams(path.split("?")[1] || "").get("query") || "";
      const q = qParam.trim();
      if (!q) return {
        results: []
      };
      if (/^tt\d+$/i.test(q)) {
        return {
          results: [{
            id: q.toLowerCase(),
            imdb_id: q.toLowerCase(),
            title: `IMDb Title (${q.toLowerCase()})`,
            media_type: "movie",
            poster_path: `https://images.metahub.space/poster/medium/${q.toLowerCase()}/img`
          }, {
            id: q.toLowerCase(),
            imdb_id: q.toLowerCase(),
            name: `IMDb Series (${q.toLowerCase()})`,
            media_type: "tv",
            poster_path: `https://images.metahub.space/poster/medium/${q.toLowerCase()}/img`
          }]
        };
      }
      const hasArabic = /[\u0600-\u06FF]/.test(q);
      const [arabicSearch, movieSearch, seriesSearch, imdbSearch] = await Promise.all([hasArabic ? searchArabicViaWikidata(q).catch(() => []) : Promise.resolve([]), hasArabic ? Promise.resolve([]) : fetchCinemeta(`/catalog/movie/top/search=${encodeURIComponent(q)}.json`).then(d => (d.metas || []).map(m => normalizeCinemetaItem(m, "movie"))).catch(() => []), hasArabic ? Promise.resolve([]) : fetchCinemeta(`/catalog/series/top/search=${encodeURIComponent(q)}.json`).then(d => (d.metas || []).map(m => normalizeCinemetaItem(m, "tv"))).catch(() => []), hasArabic ? Promise.resolve([]) : searchImdbSuggestions(q).catch(() => [])]);
      const merged = [];
      const seen = new Set();
      const maxLen = Math.max(arabicSearch.length, movieSearch.length, seriesSearch.length, imdbSearch.length);
      for (let i = 0; i < maxLen; i++) {
        for (const list of [arabicSearch, movieSearch, seriesSearch, imdbSearch]) {
          const item = list[i];
          if (!item) continue;
          const k = `${item.media_type}_${item.id}`;
          if (!seen.has(k)) {
            seen.add(k);
            merged.push(item);
          }
        }
      }
      if (merged.length === 0) {
        const ql = q.toLowerCase();
        const localHits = [...FALLBACK_MOVIES, ...FALLBACK_SERIES].filter(i => (i.title || i.name || "").toLowerCase().includes(ql));
        return storeCache({
          results: localHits
        });
      }
      return storeCache({
        results: merged.slice(0, 20)
      });
    }
    const movieMatch = cleanPath.match(/^\/movie\/([^/]+)(?:\/(.+))?$/);
    if (movieMatch) {
      let movieId = movieMatch[1];
      const subResource = movieMatch[2] || null;
      if (!String(movieId).startsWith("tt")) {
        const resolved = await resolveIdsViaWikidata(movieId, "movie");
        if (resolved?.imdbId) movieId = resolved.imdbId;
      }
      let metaItem = null;
      try {
        const raw = await fetchCinemeta(`/meta/movie/${encodeURIComponent(movieId)}.json`);
        if (raw?.meta) metaItem = normalizeCinemetaItem(raw.meta, "movie");
      } catch {}
      if (!metaItem) {
        metaItem = FALLBACK_MOVIES.find(m => String(m.id) === String(movieId) || String(m.numeric_id) === String(movieId)) || {
          id: movieId,
          imdb_id: String(movieId).startsWith("tt") ? movieId : null,
          title: String(movieId),
          media_type: "movie",
          genres: [],
          overview: "Metadata unavailable — stream playback remains active."
        };
      }
      if (!subResource) {
        return storeCache(metaItem);
      }
      if (subResource === "videos") {
        const trailers = (metaItem._rawTrailers || []).filter(t => t.source).map(t => ({
          key: t.source,
          site: "YouTube",
          type: t.type || "Trailer"
        }));
        return storeCache({
          results: trailers
        });
      }
      if (subResource === "credits") {
        const cast = (metaItem._rawCast || []).map((name, idx) => ({
          id: `cast_${idx}`,
          name: typeof name === "string" ? name : name?.name || "Cast",
          character: typeof name === "object" ? name.character || "" : "",
          profile_path: null
        }));
        const crew = [...(metaItem._rawDirectors || []).map((name, idx) => ({
          id: `dir_${idx}`,
          name,
          job: "Director"
        })), ...(metaItem._rawWriters || []).map((name, idx) => ({
          id: `wri_${idx}`,
          name,
          job: "Writer"
        }))];
        return storeCache({
          cast,
          crew
        });
      }
      if (subResource === "release_dates") {
        const cert = metaItem.certification || "PG-13";
        return storeCache({
          results: [{
            iso_3166_1: "US",
            release_dates: [{
              certification: cert,
              type: 3
            }]
          }]
        });
      }
      if (subResource === "recommendations" || subResource === "similar") {
        return storeCache({
          results: FALLBACK_MOVIES.filter(m => m.id !== metaItem.id).slice(0, 6)
        });
      }
      if (subResource === "external_ids") {
        const resolved = await resolveIdsViaWikidata(movieId, "movie");
        return storeCache({
          imdb_id: metaItem.imdb_id || resolved?.imdbId || (String(movieId).startsWith("tt") ? movieId : null)
        });
      }
    }
    const tvSeasonMatch = cleanPath.match(/^\/tv\/([^/]+)\/season\/(\d+)$/);
    if (tvSeasonMatch) {
      const tvId = tvSeasonMatch[1];
      const seasonNum = parseInt(tvSeasonMatch[2], 10);
      const series = await tmdbFetch(`/tv/${tvId}`);
      const seasonObj = series?._seasonsByNumber?.[seasonNum] || (series?.seasons || []).find(s => s.season_number === seasonNum);
      if (seasonObj && Array.isArray(seasonObj.episodes)) {
        return storeCache({
          season_number: seasonNum,
          name: seasonObj.name || `Season ${seasonNum}`,
          episodes: seasonObj.episodes
        });
      }
      const fallbackCount = seasonObj?.episode_count || 12;
      const fallbackEpisodes = Array.from({
        length: fallbackCount
      }, (_, idx) => ({
        id: `${tvId}_s${seasonNum}_e${idx + 1}`,
        episode_number: idx + 1,
        season_number: seasonNum,
        name: `Episode ${idx + 1}`,
        overview: "",
        still_path: series?.backdrop_path || series?.poster_path || null,
        air_date: series?.first_air_date || "2020-01-01"
      }));
      return storeCache({
        season_number: seasonNum,
        name: `Season ${seasonNum}`,
        episodes: fallbackEpisodes
      });
    }
    const tvMatch = cleanPath.match(/^\/tv\/([^/]+)(?:\/(.+))?$/);
    if (tvMatch) {
      let tvId = tvMatch[1];
      const subResource = tvMatch[2] || null;
      if (!String(tvId).startsWith("tt") && !String(tvId).startsWith("tvmaze:")) {
        const resolved = await resolveIdsViaWikidata(tvId, "tv");
        if (resolved?.imdbId) tvId = resolved.imdbId;
      }
      let seriesItem = null;
      try {
        const raw = await fetchCinemeta(`/meta/series/${encodeURIComponent(tvId)}.json`);
        if (raw?.meta) {
          const norm = normalizeCinemetaItem(raw.meta, "tv");
          const seasons = buildSeasonsFromVideos(norm._rawVideos || []);
          const validSeasons = seasons.filter(s => s.season_number > 0);
          seriesItem = {
            ...norm,
            seasons: seasons.length > 0 ? seasons : [{
              season_number: 1,
              name: "Season 1",
              episode_count: 12
            }],
            number_of_seasons: validSeasons.length || 1,
            number_of_episodes: (norm._rawVideos || []).length || 12,
            _seasonsByNumber: Object.fromEntries(seasons.map(s => [s.season_number, s]))
          };
        }
      } catch {}
      if (!seriesItem || !seriesItem.seasons || seriesItem.seasons.length === 0) {
        const tvm = await fetchTvMazeSeries(tvId).catch(() => null);
        if (tvm) seriesItem = tvm;
      }
      if (!seriesItem) {
        const fb = FALLBACK_SERIES.find(s => String(s.id) === String(tvId) || String(s.numeric_id) === String(tvId));
        seriesItem = fb ? {
          ...fb,
          seasons: Array.from({
            length: fb.number_of_seasons || 1
          }, (_, idx) => ({
            season_number: idx + 1,
            name: `Season ${idx + 1}`,
            episode_count: 12
          }))
        } : {
          id: tvId,
          imdb_id: String(tvId).startsWith("tt") ? tvId : null,
          name: String(tvId),
          title: String(tvId),
          media_type: "tv",
          seasons: [{
            season_number: 1,
            name: "Season 1",
            episode_count: 12
          }],
          number_of_seasons: 1,
          number_of_episodes: 12,
          genres: [],
          overview: "Metadata unavailable — stream playback remains active."
        };
      }
      if (!subResource) {
        return storeCache(seriesItem);
      }
      if (subResource === "videos") {
        const trailers = (seriesItem._rawTrailers || []).filter(t => t.source).map(t => ({
          key: t.source,
          site: "YouTube",
          type: t.type || "Trailer"
        }));
        return storeCache({
          results: trailers
        });
      }
      if (subResource === "aggregate_credits" || subResource === "credits") {
        if (seriesItem._cast) {
          return storeCache({
            cast: seriesItem._cast,
            crew: []
          });
        }
        const cast = (seriesItem._rawCast || []).map((name, idx) => ({
          id: `cast_${idx}`,
          name: typeof name === "string" ? name : name?.name || "Cast",
          roles: [{
            character: typeof name === "object" ? name.character || "" : ""
          }],
          profile_path: null
        }));
        const crew = (seriesItem._rawDirectors || []).map((name, idx) => ({
          id: `dir_${idx}`,
          name,
          jobs: [{
            job: "Director"
          }]
        }));
        return storeCache({
          cast,
          crew
        });
      }
      if (subResource === "content_ratings") {
        const rating = seriesItem.certification || "TV-14";
        return storeCache({
          results: [{
            iso_3166_1: "US",
            rating
          }]
        });
      }
      if (subResource === "recommendations" || subResource === "similar") {
        return storeCache({
          results: FALLBACK_SERIES.filter(s => s.id !== seriesItem.id).slice(0, 6)
        });
      }
      if (subResource === "external_ids") {
        const resolved = await resolveIdsViaWikidata(tvId, "tv");
        return storeCache({
          imdb_id: seriesItem.imdb_id || resolved?.imdbId || (String(tvId).startsWith("tt") ? tvId : null)
        });
      }
    }
    return {
      results: []
    };
  } catch (err) {
    _onUnreachable?.();
    throw err;
  }
};
exports.tmdbFetch = tmdbFetch;
const PLAYER_SOURCES = [{
  id: "vidlink",
  label: "VidLink",
  tag: null,
  note: "Multi-Audio ✓",
  supportsProgress: true,
  progressViaFrames: true,
  idType: "any",
  colorParam: null,
  langParam: null,
  params: {
    autoplay: "true"
  },
  movieUrl: id => `https://vidlink.pro/movie/${id}`,
  tvUrl: (id, season, ep) => `https://vidlink.pro/tv/${id}/${season}/${ep}`
}, {
  id: "videasy",
  label: "VidEasy",
  tag: null,
  note: "Multi-Dub ✓",
  supportsProgress: true,
  progressViaFrames: true,
  idType: "any",
  colorParam: null,
  langParam: null,
  params: {},
  movieUrl: id => `https://player.videasy.net/movie/${id}`,
  tvUrl: (id, season, ep) => `https://player.videasy.net/tv/${id}/${season}/${ep}`
}, {
  id: "vidsrccc",
  label: "VidSrc.cc",
  tag: null,
  note: "Fast ✓",
  supportsProgress: true,
  progressViaFrames: true,
  idType: "any",
  colorParam: null,
  langParam: null,
  params: {
    autoPlay: "true"
  },
  movieUrl: id => `https://vidsrc.cc/v2/embed/movie/${id}`,
  tvUrl: (id, season, ep) => `https://vidsrc.cc/v2/embed/tv/${id}/${season}/${ep}`
}, {
  id: "embedsu",
  label: "Embed.su",
  tag: null,
  note: "Multi-Audio ✓",
  supportsProgress: true,
  progressViaFrames: true,
  idType: "any",
  colorParam: null,
  langParam: null,
  params: {},
  movieUrl: id => `https://embed.su/embed/movie/${id}`,
  tvUrl: (id, season, ep) => `https://embed.su/embed/tv/${id}/${season}/${ep}`
}, {
  id: "smashy",
  label: "SmashyStream",
  tag: null,
  note: "Multi-Lang ✓",
  supportsProgress: true,
  progressViaFrames: true,
  idType: "any",
  colorParam: null,
  langParam: null,
  params: {},
  movieUrl: id => `https://player.smashy.stream/movie/${id}`,
  tvUrl: (id, season, ep) => `https://player.smashy.stream/tv/${id}?s=${season}&e=${ep}`
}, {
  id: "autoembed",
  label: "AutoEmbed",
  audioLangs: ["en", "ar", "es", "fr", "tr", "pt", "hi", "ja", "ko"],
  tag: null,
  note: "Multi Lang ✓",
  supportsProgress: true,
  progressViaFrames: true,
  idType: "any",
  colorParam: null,
  langParam: null,
  params: {
    server: "1"
  },
  movieUrl: id => `https://player.autoembed.cc/embed/movie/${id}`,
  tvUrl: (id, season, ep) => `https://player.autoembed.cc/embed/tv/${id}/${season}/${ep}`
}, {
  id: "vidsrcnet",
  label: "VidSrc Pro",
  tag: null,
  note: "Fast HD",
  supportsProgress: true,
  progressViaFrames: true,
  idType: "any",
  colorParam: null,
  langParam: null,
  params: {
    autoplay: "1"
  },
  movieUrl: id => `https://vidsrc.net/embed/movie/${id}`,
  tvUrl: (id, season, ep) => `https://vidsrc.net/embed/tv/${id}/${season}-${ep}`
}, {
  id: "vidsrc",
  label: "VidSrc",
  tag: null,
  note: "Multi-Server ✓",
  supportsProgress: true,
  progressViaFrames: true,
  idType: "any",
  colorParam: null,
  langParam: "ds_lang",
  params: {
    autoplay: "1"
  },
  movieUrl: id => `https://vsembed.su/embed/movie/${id}`,
  tvUrl: (id, season, ep) => `https://vsembed.su/embed/tv/${id}/${season}/${ep}`
}, {
  id: "vidsrcxyz",
  label: "VidSrc.xyz",
  tag: null,
  note: "IMDb Direct ✓",
  supportsProgress: true,
  progressViaFrames: true,
  idType: "imdb",
  colorParam: null,
  langParam: null,
  params: {},
  movieUrl: id => `https://vidsrc.xyz/embed/movie/${id}`,
  tvUrl: (id, season, ep) => `https://vidsrc.xyz/embed/tv/${id}/${season}-${ep}`
}, {
  id: "vidsrcme",
  label: "VidSrc.me",
  tag: null,
  note: "IMDb Direct ✓",
  supportsProgress: true,
  progressViaFrames: true,
  idType: "imdb",
  colorParam: null,
  langParam: null,
  params: {},
  movieUrl: id => `https://vidsrc.me/embed/movie?imdb=${id}`,
  tvUrl: (id, season, ep) => `https://vidsrc.me/embed/tv?imdb=${id}&season=${season}&episode=${ep}`
}, {
  id: "vidsrcin",
  label: "VidSrc.in",
  tag: null,
  note: "IMDb Direct ✓",
  supportsProgress: true,
  progressViaFrames: true,
  idType: "imdb",
  colorParam: null,
  langParam: null,
  params: {},
  movieUrl: id => `https://vidsrc.in/embed/movie/${id}`,
  tvUrl: (id, season, ep) => `https://vidsrc.in/embed/tv/${id}/${season}-${ep}`
}, {
  id: "vidsrcpm",
  label: "VidSrc.pm",
  tag: null,
  note: "IMDb Direct ✓",
  supportsProgress: true,
  progressViaFrames: true,
  idType: "imdb",
  colorParam: null,
  langParam: null,
  params: {},
  movieUrl: id => `https://vidsrc.pm/embed/movie/${id}`,
  tvUrl: (id, season, ep) => `https://vidsrc.pm/embed/tv/${id}/${season}-${ep}`
}, {
  id: "vidsrcicu",
  label: "VidSrc.icu",
  tag: null,
  note: "Fast ✓",
  supportsProgress: true,
  progressViaFrames: true,
  idType: "any",
  colorParam: null,
  langParam: null,
  params: {},
  movieUrl: id => `https://vidsrc.icu/embed/movie/${id}`,
  tvUrl: (id, season, ep) => `https://vidsrc.icu/embed/tv/${id}/${season}/${ep}`
}, {
  id: "superembed",
  label: "SuperEmbed Direct",
  tag: null,
  note: "IMDb Direct ✓",
  supportsProgress: true,
  progressViaFrames: true,
  idType: "imdb",
  colorParam: null,
  langParam: null,
  params: {},
  movieUrl: id => `https://multiembed.mov/directstream.php?video_id=${id}`,
  tvUrl: (id, season, ep) => `https://multiembed.mov/directstream.php?video_id=${id}&s=${season}&e=${ep}`
}, {
  id: "moviesapi",
  label: "MoviesAPI",
  tag: null,
  note: "Fast ✓",
  supportsProgress: true,
  progressViaFrames: true,
  idType: "any",
  colorParam: null,
  langParam: null,
  params: {},
  movieUrl: id => `https://moviesapi.club/movie/${id}`,
  tvUrl: (id, season, ep) => `https://moviesapi.club/tv/${id}-${season}-${ep}`
}, {
  id: "nontongo",
  label: "NontonGo",
  tag: null,
  note: "IMDb Direct ✓",
  supportsProgress: true,
  progressViaFrames: true,
  idType: "imdb",
  colorParam: null,
  langParam: null,
  params: {},
  movieUrl: id => `https://www.nontongo.win/embed/movie/${id}`,
  tvUrl: (id, season, ep) => `https://www.nontongo.win/embed/tv/${id}/${season}/${ep}`
}, {
  id: "multiembed",
  label: "MultiEmbed",
  tag: null,
  note: "SuperEmbed",
  supportsProgress: true,
  progressViaFrames: true,
  idType: "imdb",
  colorParam: null,
  langParam: null,
  params: {},
  movieUrl: id => `https://multiembed.mov/?video_id=${id}`,
  tvUrl: (id, season, ep) => `https://multiembed.mov/?video_id=${id}&s=${season}&e=${ep}`
}, {
  id: "twoembed",
  label: "2Embed",
  tag: null,
  note: "Direct IMDb",
  supportsProgress: true,
  progressViaFrames: true,
  idType: "any",
  colorParam: null,
  langParam: null,
  params: {},
  movieUrl: id => `https://www.2embed.cc/embed/${id}`,
  tvUrl: (id, season, ep) => `https://www.2embed.cc/embedtv/${id}&s=${season}&e=${ep}`
}, {
  id: "vidrift",
  label: "Vidrift",
  tag: null,
  note: "Multi Lang, Anime ✓",
  supportsProgress: true,
  idType: "numeric",
  colorParam: "brandColor",
  langParam: "sub",
  params: {
    title: "true",
    hide: "next,episodes,cast"
  },
  movieUrl: id => `https://embed.vidrift.net/embed/movie/${id}`,
  tvUrl: (id, season, ep) => `https://embed.vidrift.net/embed/tv/${id}/${season}/${ep}`
}, {
  id: "vidfast",
  label: "Vidfast",
  tag: null,
  note: null,
  supportsProgress: true,
  cleanUserAgent: true,
  idType: "numeric",
  colorParam: "theme",
  langParam: "sub",
  params: {
    autoPlay: "true",
    poster: "true",
    title: "true",
    pip: "hide"
  },
  movieUrl: id => `https://vidfast.vc/movie/${id}`,
  tvUrl: (id, season, ep) => `https://vidfast.vc/tv/${id}/${season}/${ep}`
}, {
  id: "vidlove",
  label: "Vidlove",
  tag: null,
  note: null,
  supportsProgress: true,
  idType: "numeric",
  colorParam: "primarycolor",
  params: {
    autoplay: "true",
    autonext: "false",
    tour: "true",
    showNextEpisode: "false",
    hideautonext: "true",
    hidenextbutton: "true"
  },
  movieUrl: id => `https://player.vidlove.cc/embed/movie/${id}`,
  tvUrl: (id, season, ep) => `https://player.vidlove.cc/embed/tv/${id}/${season}/${ep}`
}, {
  id: "aether",
  label: "Aether",
  tag: null,
  note: "Multi Lang",
  supportsProgress: true,
  idType: "numeric",
  colorParam: null,
  langParam: null,
  params: {},
  movieUrl: id => `https://aether.ist/media/tmdb-movie-${id}`,
  tvUrl: (id, season, ep) => `https://aether.ist/media/tmdb-tv-${id}/${season}/${ep}`
}, {
  id: "vidnest",
  label: "Vidnest",
  tag: null,
  note: "Anime ✓",
  supportsProgress: true,
  progressViaFrames: false,
  supportsAnime: true,
  idType: "numeric",
  colorParam: null,
  langParam: null,
  params: {},
  movieUrl: id => `https://vidnest.fun/movie/${id}`,
  tvUrl: (id, season, ep) => `https://vidnest.fun/tv/${id}/${season}/${ep}`,
  animeUrl: (anilistId, ep, lang) => `https://vidnest.fun/anime/${anilistId}/${ep}/${lang}`
}, {
  id: "devideosrc",
  label: "DeVideoSrc",
  tag: null,
  note: "🇩🇪",
  supportsProgress: true,
  progressViaFrames: true,
  skipResetGuard: true,
  idType: "imdb",
  colorParam: "color",
  colorWithHash: true,
  langParam: null,
  params: {
    autoplay: "1",
    muted: "0"
  },
  movieUrl: id => `https://devideosrc.co/custom/movie/${id}`,
  tvUrl: (id, season, ep) => `https://devideosrc.co/custom/serial/${id}/${season}/${ep}`
}, {
  id: "frembed",
  label: "Frembed",
  audioLangs: ["fr", "en"],
  tag: null,
  note: "🇫🇷",
  supportsProgress: true,
  progressViaFrames: true,
  skipResetGuard: true,
  idType: "numeric",
  colorParam: null,
  langParam: null,
  params: {},
  movieUrl: id => `https://frembed.uno/embed/movie/${id}`,
  tvUrl: (id, season, ep) => `https://frembed.uno/embed/serie/${id}?sa=${season}&epi=${ep}`
}, {
  id: "kinohub",
  label: "KinoHub",
  audioLangs: ["ru", "en"],
  tag: null,
  note: "🇷🇺",
  supportsProgress: true,
  progressViaFrames: true,
  idType: "kinopoisk",
  movieOnly: true,
  colorParam: null,
  langParam: null,
  params: {},
  movieUrl: id => `https://on.kinohub.vip/movie/${id}`
}, {
  id: "hianime",
  label: "HiAnime",
  tag: "ANIME",
  note: "Native ExoPlayer",
  supportsProgress: true,
  async: true,
  params: {},
  movieUrl: _id => "https://hianime.at",
  tvUrl: (_id, _season, _ep) => "https://hianime.at"
}];
exports.PLAYER_SOURCES = PLAYER_SOURCES;
const NEEDS_INTERCEPT = ["vidsrc", "autoembed", "vidsrcnet", "multiembed", "twoembed", "devideosrc", "frembed", "kinohub"];
exports.NEEDS_INTERCEPT = NEEDS_INTERCEPT;
const getSourceUrl = (sourceId, type, id, season, ep, extraParams = {}, accentColor = null, subtitleLang = null) => {
  let src = PLAYER_SOURCES.find(s => s.id === sourceId) ?? PLAYER_SOURCES[0];
  if (!id) return null;
  if (type !== "movie" && !src.tvUrl) return null;
  if (src.idType === "numeric" && String(id).startsWith("tt")) {
    src = PLAYER_SOURCES[0];
  }
  const baseUrl = type === "movie" ? src.movieUrl(id) : src.tvUrl(id, season, ep);
  const url = new URL(baseUrl);
  Object.entries(src.params || {}).forEach(([key, value]) => {
    url.searchParams.set(key, value);
  });
  if (accentColor && src.colorParam) {
    const hex = accentColor.replace(/^#/, "");
    url.searchParams.set(src.colorParam, src.colorWithHash ? `#${hex}` : hex);
  }
  if (subtitleLang && src.langParam) {
    url.searchParams.set(src.langParam, subtitleLang);
  }
  Object.entries(extraParams).forEach(([key, value]) => {
    if (value != null) {
      url.searchParams.set(key, value);
    }
  });
  return url.toString();
};
exports.getSourceUrl = getSourceUrl;
const CLEAN_USER_AGENT = typeof window !== "undefined" && window.electron?.cleanUserAgent || "";
exports.CLEAN_USER_AGENT = CLEAN_USER_AGENT;
const sourceUsesCleanUa = sourceId => PLAYER_SOURCES.find(s => s.id === sourceId)?.cleanUserAgent ?? false;
exports.sourceUsesCleanUa = sourceUsesCleanUa;
const sourceIdType = sourceId => PLAYER_SOURCES.find(s => s.id === sourceId)?.idType ?? "any";
exports.sourceIdType = sourceIdType;
const sourceNeedsImdb = sourceId => sourceIdType(sourceId) === "imdb";
exports.sourceNeedsImdb = sourceNeedsImdb;
const sourceNeedsKinopoisk = sourceId => sourceIdType(sourceId) === "kinopoisk";
exports.sourceNeedsKinopoisk = sourceNeedsKinopoisk;
const sourceIsMovieOnly = sourceId => PLAYER_SOURCES.find(s => s.id === sourceId)?.movieOnly ?? false;
exports.sourceIsMovieOnly = sourceIsMovieOnly;
async function fetchImdbId(type, mediaId) {
  const str = String(mediaId || "").trim();
  if (/^tt\d+$/i.test(str)) return str;
  const cached = _idMap.get(str);
  if (cached?.imdbId) return cached.imdbId;
  const resolved = await resolveIdsViaWikidata(str, type);
  if (resolved?.imdbId) return resolved.imdbId;
  throw new Error(`No IMDb ID found for ${type} ${mediaId}`);
}
async function fetchNumericId(type, mediaId) {
  const str = String(mediaId || "").trim();
  if (/^\d+$/.test(str)) return str;
  const cached = _idMap.get(str);
  if (cached?.numericId) return String(cached.numericId);
  try {
    const savedNum = localStorage.getItem(`streambert_numid_${str}`);
    if (savedNum && /^\d+$/.test(savedNum)) {
      registerIdMapping({
        imdbId: str,
        numericId: savedNum
      });
      return savedNum;
    }
  } catch {}
  if (typeof window !== "undefined" && window.AndroidBridge?.resolveNumericId) {
    try {
      const nativeNum = window.AndroidBridge.resolveNumericId(str, type === "tv" ? "tv" : "movie");
      if (nativeNum && /^\d+$/.test(String(nativeNum).trim())) {
        const cleanNum = String(nativeNum).trim();
        registerIdMapping({
          imdbId: str,
          numericId: cleanNum
        });
        return cleanNum;
      }
    } catch {}
  }
  try {
    const cType = type === "tv" ? "series" : "movie";
    const raw = await fetchCinemeta(`/meta/${cType}/${encodeURIComponent(str)}.json`);
    if (raw?.meta?.moviedb_id) {
      const numStr = String(raw.meta.moviedb_id);
      registerIdMapping({
        imdbId: str,
        numericId: numStr
      });
      return numStr;
    }
  } catch {}
  const resolved = await resolveIdsViaWikidata(str, type);
  if (resolved?.numericId) {
    return String(resolved.numericId);
  }
  return str;
}
async function fetchKinopoiskId(type, mediaId) {
  const str = String(mediaId || "").trim();
  const resolved = await resolveIdsViaWikidata(str, type);
  if (resolved?.kpId) return resolved.kpId;
  throw new Error(`No Kinopoisk ID found for ${type} ${mediaId}`);
}
const sourceSupportsProgress = sourceId => PLAYER_SOURCES.find(s => s.id === sourceId)?.supportsProgress ?? false;
exports.sourceSupportsProgress = sourceSupportsProgress;
const sourceProgressViaFrames = sourceId => PLAYER_SOURCES.find(s => s.id === sourceId)?.progressViaFrames ?? false;
exports.sourceProgressViaFrames = sourceProgressViaFrames;
const sourceSkipsResetGuard = sourceId => PLAYER_SOURCES.find(s => s.id === sourceId)?.skipResetGuard ?? false;
exports.sourceSkipsResetGuard = sourceSkipsResetGuard;
const sourceIsAsync = sourceId => PLAYER_SOURCES.find(s => s.id === sourceId)?.async ?? false;
exports.sourceIsAsync = sourceIsAsync;
const sourceSupportsAnime = sourceId => PLAYER_SOURCES.find(s => s.id === sourceId)?.supportsAnime ?? false;
exports.sourceSupportsAnime = sourceSupportsAnime;
const sourceIsAnimeCapable = sourceId => {
  const src = PLAYER_SOURCES.find(s => s.id === sourceId);
  return !!(src && (src.tag === "ANIME" || src.supportsAnime));
};
exports.sourceIsAnimeCapable = sourceIsAnimeCapable;
const getAnimeSourceUrl = (sourceId, anilistId, episode, dubMode = "sub", extraParams = {}) => {
  const src = PLAYER_SOURCES.find(s => s.id === sourceId);
  if (!src?.animeUrl || !anilistId || !episode) return null;
  const url = new URL(src.animeUrl(anilistId, episode, dubMode === "dub" ? "dub" : "sub"));
  Object.entries(src.params || {}).forEach(([k, v]) => url.searchParams.set(k, v));
  Object.entries(extraParams).forEach(([k, v]) => {
    if (v != null) url.searchParams.set(k, v);
  });
  return url.toString();
};
exports.getAnimeSourceUrl = getAnimeSourceUrl;
const getNextNonAsyncSource = currentId => {
  const nonAsync = PLAYER_SOURCES.filter(s => !s.async);
  if (nonAsync.length === 0) return null;
  const idx = nonAsync.findIndex(s => s.id === currentId);
  if (idx < 0) return nonAsync[0].id;
  return nonAsync[(idx + 1) % nonAsync.length].id;
};
exports.getNextNonAsyncSource = getNextNonAsyncSource;
const cleanAnilistDescription = desc => {
  if (!desc) return desc;
  let clean = desc.split("<").map((chunk, i) => i === 0 ? chunk : chunk.slice(chunk.indexOf(">") + 1)).join("").replace(/>/g, "");
  clean = clean.replace(/\(Source:[^)]*\)/gi, "");
  clean = clean.replace(/\bNote:[^\n]*/gi, "");
  clean = clean.replace(/[\s\n]+$/, "").trim();
  return clean;
};
exports.cleanAnilistDescription = cleanAnilistDescription;
const ANILIST_QUERY = `
query ($search: String, $type: MediaType) {
  Media(search: $search, type: $type, sort: SEARCH_MATCH) {
    id
    idMal
    title { romaji english native }
    description(asHtml: false)
    coverImage { extraLarge large }
    bannerImage
    genres
    averageScore
    episodes
    status
    season
    seasonYear
    studios(isMain: true) { nodes { name } }
    startDate { year month }
    relations {
      edges {
        relationType
        node {
          id
          type
          format
          title { romaji english }
          episodes
          startDate { year month }
          seasonYear
        }
      }
    }
  }
}`;
const ANILIST_CACHE_KEY = "streambert_anilistCache";
const ANILIST_CACHE_TTL = 1000 * 60 * 60 * 24 * 7;
let _anilistCache = null;
function getAnilistCache() {
  if (_anilistCache) return _anilistCache;
  try {
    const raw = localStorage.getItem(ANILIST_CACHE_KEY);
    _anilistCache = raw ? JSON.parse(raw) : {};
  } catch {
    _anilistCache = {};
  }
  const now = Date.now();
  for (const key of Object.keys(_anilistCache)) {
    if (now - _anilistCache[key].ts > ANILIST_CACHE_TTL) {
      delete _anilistCache[key];
    }
  }
  return _anilistCache;
}
let _anilistFlushTimer = null;
function flushAnilistCache() {
  if (_anilistFlushTimer) clearTimeout(_anilistFlushTimer);
  _anilistFlushTimer = setTimeout(() => {
    _anilistFlushTimer = null;
    try {
      localStorage.setItem(ANILIST_CACHE_KEY, JSON.stringify(_anilistCache));
    } catch {}
  }, 500);
}
const fetchAnilistData = async (title, type = "ANIME", mediaId = null) => {
  if (!title) return null;
  const cacheKey = mediaId ? `${type}__id_${mediaId}` : `${type}__${title.toLowerCase().trim()}`;
  const cache = getAnilistCache();
  const entry = cache[cacheKey];
  if (entry && Date.now() - entry.ts <= ANILIST_CACHE_TTL) {
    return entry.data;
  }
  try {
    const res = await fetch(ANILIST_API, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json"
      },
      body: JSON.stringify({
        query: ANILIST_QUERY,
        variables: {
          search: title,
          type
        }
      })
    });
    const json = await res.json();
    const data = json?.data?.Media || null;
    cache[cacheKey] = {
      data,
      ts: Date.now()
    };
    flushAnilistCache();
    return data;
  } catch {
    if (entry) return entry.data;
    return null;
  }
};
exports.fetchAnilistData = fetchAnilistData;
const buildAnilistSeasons = anilistData => {
  if (!anilistData) return null;
  const main = {
    id: anilistData.id,
    title: anilistData.title?.english || anilistData.title?.romaji || anilistData.title?.native,
    episodes: anilistData.episodes || null,
    year: anilistData.startDate?.year || anilistData.seasonYear || 9999,
    month: anilistData.startDate?.month || 0
  };
  const sequels = (anilistData.relations?.edges || []).filter(e => e.relationType === "SEQUEL" && e.node.type === "ANIME" && (e.node.format === "TV" || e.node.format === "TV_SHORT")).map(e => ({
    id: e.node.id,
    title: e.node.title?.english || e.node.title?.romaji,
    episodes: e.node.episodes || null,
    year: e.node.startDate?.year || e.node.seasonYear || 9999,
    month: e.node.startDate?.month || 0
  }));
  const all = [main, ...sequels].sort((a, b) => a.year !== b.year ? a.year - b.year : a.month - b.month);
  return all.map((s, i) => ({
    seasonNum: i + 1,
    ...s
  }));
};
exports.buildAnilistSeasons = buildAnilistSeasons;
const isAnimeContent = (item, details) => {
  const d = details || item;
  if (!d) return false;
  const lang = d.original_language;
  const countries = d.origin_country || [];
  const genreIds = d.genre_ids || (d.genres || []).map(g => g.id || g.name);
  const hasAnimation = genreIds.some(g => g === 16 || String(g).toLowerCase() === "animation" || String(g).toLowerCase() === "anime");
  return hasAnimation && (lang === "ja" || countries.includes("JP"));
};
exports.isAnimeContent = isAnimeContent;
const ANIME_DEFAULT_SOURCE = "hianime";
exports.ANIME_DEFAULT_SOURCE = ANIME_DEFAULT_SOURCE;
const NON_ANIME_DEFAULT_SOURCE = "vidlink";
exports.NON_ANIME_DEFAULT_SOURCE = NON_ANIME_DEFAULT_SOURCE;
const fetchEpisodeGroup = async _groupId => {
  return null;
};
exports.fetchEpisodeGroup = fetchEpisodeGroup;
},
"./utils/appearance": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.THEME_PRESETS = exports.DEFAULT_CUSTOM_VARS = exports.ACCENT_PRESETS = void 0;
exports.applyAccentColor = applyAccentColor;
exports.applyTheme = applyTheme;
const ACCENT_PRESETS = [{
  id: "red",
  label: "Red",
  color: "#e50914",
  color2: "#ff1a24",
  dim: "rgba(229,9,20,0.15)",
  glow: "0 0 30px rgba(229,9,20,0.3)"
}, {
  id: "blue",
  label: "Blue",
  color: "#2563eb",
  color2: "#3b82f6",
  dim: "rgba(37,99,235,0.18)",
  glow: "0 0 30px rgba(37,99,235,0.35)"
}, {
  id: "purple",
  label: "Purple",
  color: "#7c3aed",
  color2: "#8b5cf6",
  dim: "rgba(124,58,237,0.15)",
  glow: "0 0 30px rgba(124,58,237,0.3)"
}, {
  id: "green",
  label: "Green",
  color: "#059669",
  color2: "#10b981",
  dim: "rgba(5,150,105,0.15)",
  glow: "0 0 30px rgba(5,150,105,0.3)"
}, {
  id: "orange",
  label: "Orange",
  color: "#d97706",
  color2: "#f59e0b",
  dim: "rgba(217,119,6,0.15)",
  glow: "0 0 30px rgba(217,119,6,0.3)"
}, {
  id: "pink",
  label: "Pink",
  color: "#db2777",
  color2: "#ec4899",
  dim: "rgba(219,39,119,0.15)",
  glow: "0 0 30px rgba(219,39,119,0.3)"
}];
exports.ACCENT_PRESETS = ACCENT_PRESETS;
function applyAccentColor(presetId) {
  const preset = ACCENT_PRESETS.find(p => p.id === presetId) ?? ACCENT_PRESETS[0];
  const root = document.documentElement;
  root.style.setProperty("--red", preset.color);
  root.style.setProperty("--red2", preset.color2);
  root.style.setProperty("--red-dim", preset.dim);
  root.style.setProperty("--red-glow", preset.glow);
}
const THEME_PRESETS = [{
  id: "dark",
  label: "Dark",
  description: "Default dark theme",
  vars: {
    "--bg": "#0a0a0a",
    "--surface": "#111111",
    "--surface2": "#1a1a1a",
    "--surface3": "#222222",
    "--border": "#2a2a2a",
    "--text": "#f0f0f0",
    "--text2": "#c0c0c0",
    "--text3": "#909090"
  }
}, {
  id: "amoled",
  label: "AMOLED",
  description: "Very black :) (for OLED displays)",
  vars: {
    "--bg": "#000000",
    "--surface": "#080808",
    "--surface2": "#111111",
    "--surface3": "#181818",
    "--border": "#1f1f1f",
    "--text": "#ffffff",
    "--text2": "#cccccc",
    "--text3": "#888888"
  }
}, {
  id: "mocha",
  label: "Mocha",
  description: "Warm dark brown tones",
  vars: {
    "--bg": "#0e0b09",
    "--surface": "#1a1410",
    "--surface2": "#231c16",
    "--surface3": "#2e251d",
    "--border": "#3a2e24",
    "--text": "#f0e8df",
    "--text2": "#c4b09a",
    "--text3": "#8a7060"
  }
}, {
  id: "slate",
  label: "Slate",
  description: "Cool blue-grey tones",
  vars: {
    "--bg": "#0d1117",
    "--surface": "#161b22",
    "--surface2": "#1f2937",
    "--surface3": "#273344",
    "--border": "#30363d",
    "--text": "#e6edf3",
    "--text2": "#8b949e",
    "--text3": "#6e7681"
  }
}, {
  id: "light",
  label: "Light",
  description: "Very white (basic light theme)",
  vars: {
    "--bg": "#ebebed",
    "--surface": "#f8f8fa",
    "--surface2": "#eeeef0",
    "--surface3": "#e2e2e5",
    "--border": "#c8c8cc",
    "--text": "#111113",
    "--text2": "#3a3a40",
    "--text3": "#6b6b74"
  }
}, {
  id: "custom",
  label: "Custom",
  description: "Your own colours",
  vars: null
}];
exports.THEME_PRESETS = THEME_PRESETS;
const DEFAULT_CUSTOM_VARS = {
  "--bg": "#0a0a0a",
  "--surface": "#111111",
  "--surface2": "#1a1a1a",
  "--surface3": "#222222",
  "--border": "#2a2a2a",
  "--text": "#f0f0f0",
  "--text2": "#c0c0c0",
  "--text3": "#909090"
};
exports.DEFAULT_CUSTOM_VARS = DEFAULT_CUSTOM_VARS;
function applyTheme(themeId, customVars = null) {
  const preset = THEME_PRESETS.find(t => t.id === themeId) ?? THEME_PRESETS[0];
  const vars = themeId === "custom" ? customVars ?? DEFAULT_CUSTOM_VARS : preset.vars;
  const root = document.documentElement;
  for (const [prop, value] of Object.entries(vars)) {
    root.style.setProperty(prop, value);
  }
}
},
"./utils/backup": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.BACKUP_KEYS = void 0;
exports.collectBackupData = collectBackupData;
exports.restoreBackupData = restoreBackupData;
const PREFIX = "streambert_";
const BACKUP_KEYS = ["saved", "savedOrder", "history", "progress", "watched", "homeRowOrder", "homeRowVisible", "homeViewMode", "startPage", "playerSource", "hianimeDubMode", "introSkipMode", "ageLimit", "ratingCountry", "watchedThreshold", "autoplayNextEnabled", "autoplayNextDuration", "autoplayNextLayout", "subtitleDownload", "subtitleLang", "downloadPath", "downloaderFolder", "invidiousBase", "autoCheckUpdates", "searchHistory", "accentColor", "fontSize", "compactMode", "reduceAnimations", "librarySort", "historyEnabled", "tmdbLang", "notifyDownloadComplete", "notifyNewEpisode", "episodeReleaseCache"];
exports.BACKUP_KEYS = BACKUP_KEYS;
function collectBackupData() {
  const data = {};
  for (const key of BACKUP_KEYS) {
    try {
      const raw = localStorage.getItem(PREFIX + key);
      if (raw !== null) data[key] = JSON.parse(raw);
    } catch {}
  }
  return data;
}
function restoreBackupData(data) {
  if (!data || typeof data !== "object") throw new Error("Invalid backup data");
  for (const key of BACKUP_KEYS) {
    if (data[key] !== undefined && data[key] !== null) {
      localStorage.setItem(PREFIX + key, JSON.stringify(data[key]));
    }
  }
}
},
"./utils/discordPresence": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.applyDiscordRpcEnabled = applyDiscordRpcEnabled;
exports.clearActivity = clearActivity;
exports.readDiscordRpcSettings = readDiscordRpcSettings;
exports.sendIdleActivity = sendIdleActivity;
exports.sendWatchingActivity = sendWatchingActivity;
var _storage = require("./storage");
const APP_ICON_URL = "https://t.me/ec1lz";
const GITHUB_URL = "https://t.me/ec1lz";
function readDiscordRpcSettings() {
  return {
    enabled: !!_storage.storage.get(_storage.STORAGE_KEYS.DISCORD_RPC_ENABLED),
    showCover: _storage.storage.get(_storage.STORAGE_KEYS.DISCORD_RPC_SHOW_COVER) !== false,
    showTimestamp: _storage.storage.get(_storage.STORAGE_KEYS.DISCORD_RPC_SHOW_TIMESTAMP) !== false,
    showButton: _storage.storage.get(_storage.STORAGE_KEYS.DISCORD_RPC_SHOW_BUTTON) !== false
  };
}
function applyDiscordRpcEnabled(enabled) {
  if (!_storage.isElectron || !window.electron?.discordRpcSetEnabled) return;
  window.electron.discordRpcSetEnabled(!!enabled);
}
function baseAssets(posterUrl, settings) {
  const assets = {};
  if (settings.showCover && posterUrl) {
    assets.large_image = posterUrl;
    assets.small_image = APP_ICON_URL;
    assets.small_text = "SingularityTV";
  } else {
    assets.large_image = APP_ICON_URL;
  }
  return assets;
}
function buttons(settings) {
  return settings.showButton ? [{
    label: "Watch media for free",
    url: GITHUB_URL
  }] : undefined;
}
function sendWatchingActivity(info, settings) {
  if (!_storage.isElectron || !window.electron?.discordRpcUpdateActivity) return;
  if (!settings.enabled) return;
  const activity = {
    type: 3,
    details: info.title?.slice(0, 128) || "SingularityTV",
    state: (info.subtitle || "SingularityTV").slice(0, 128),
    assets: {
      ...baseAssets(info.posterUrl, settings),
      large_text: info.title?.slice(0, 128) || "SingularityTV"
    }
  };
  if (settings.showTimestamp && info.startedAt) {
    activity.timestamps = {
      start: info.startedAt
    };
  }
  const btns = buttons(settings);
  if (btns) activity.buttons = btns;
  window.electron.discordRpcUpdateActivity(activity);
}
function sendIdleActivity(settings) {
  if (!_storage.isElectron || !window.electron?.discordRpcUpdateActivity) return;
  if (!settings.enabled) return;
  const activity = {
    type: 3,
    details: "Idling",
    assets: {
      large_image: APP_ICON_URL,
      large_text: "SingularityTV"
    }
  };
  const btns = buttons(settings);
  if (btns) activity.buttons = btns;
  window.electron.discordRpcUpdateActivity(activity);
}
function clearActivity() {
  if (!_storage.isElectron || !window.electron?.discordRpcUpdateActivity) return;
  window.electron.discordRpcUpdateActivity(null);
}
},
"./utils/episodeMappings": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.EPISODE_GROUP_IDS = void 0;
exports.applyEpisodeMapping = applyEpisodeMapping;
exports.buildEpisodeGroupMap = buildEpisodeGroupMap;
const EPISODE_GROUP_IDS = {};
exports.EPISODE_GROUP_IDS = EPISODE_GROUP_IDS;
function applyEpisodeMapping(_seriesId, season, episode, groupMap) {
  if (!groupMap) return {
    season,
    episode
  };
  const mapped = groupMap.get(`${season}_${episode}`);
  if (!mapped) return {
    season,
    episode
  };
  return mapped;
}
function buildEpisodeGroupMap(groupData) {
  const map = new Map();
  if (!groupData?.groups) return map;
  const sortedGroups = [...groupData.groups].sort((a, b) => a.order - b.order);
  sortedGroups.forEach((group, groupIndex) => {
    const sourceSeason = groupIndex + 1;
    const sortedEpisodes = [...(group.episodes || [])].sort((a, b) => a.order - b.order);
    sortedEpisodes.forEach((ep, epIndex) => {
      map.set(`${ep.season_number}_${ep.episode_number}`, {
        season: sourceSeason,
        episode: epIndex + 1
      });
    });
  });
  return map;
}
},
"./utils/gamepad": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.BTN = void 0;
exports.startGamepadLoop = startGamepadLoop;
exports.useGamepadLoop = useGamepadLoop;
var _react = require("react");
const BTN = {
  A: 0,
  B: 1,
  X: 2,
  Y: 3,
  LB: 4,
  RB: 5,
  LT: 6,
  RT: 7,
  BACK: 8,
  START: 9,
  LS: 10,
  RS: 11,
  UP: 12,
  DOWN: 13,
  LEFT: 14,
  RIGHT: 15,
  HOME: 16
};
exports.BTN = BTN;
const AXIS_DEADZONE = 0.45;
const DIR_REPEAT_DELAY = 420;
const DIR_REPEAT_RATE = 140;
function readFirstPad() {
  const pads = navigator.getGamepads ? navigator.getGamepads() : [];
  for (const p of pads) if (p && p.connected !== false) return p;
  return null;
}
function startGamepadLoop(handlers, isActive) {
  const {
    onButtonDown,
    onButtonUp,
    onDirection,
    onConnectionChange
  } = handlers;
  let raf = null;
  let prevButtons = [];
  let wasConnected = false;
  let dirState = null;
  const markConnected = v => {
    if (wasConnected === v) return;
    wasConnected = v;
    onConnectionChange?.(v);
  };
  const tick = () => {
    raf = requestAnimationFrame(tick);
    const pad = readFirstPad();
    if (!pad) {
      markConnected(false);
      prevButtons = [];
      dirState = null;
      return;
    }
    markConnected(true);
    const active = isActive ? isActive() : true;
    for (let i = 0; i < pad.buttons.length; i++) {
      const b = pad.buttons[i];
      const pressed = !!b?.pressed || (b?.value || 0) > 0.5;
      const wasPressed = !!prevButtons[i];
      if (active && pressed && !wasPressed) onButtonDown?.(i);
      if (active && !pressed && wasPressed) onButtonUp?.(i);
      prevButtons[i] = pressed;
    }
    const lx = pad.axes[0] || 0;
    const ly = pad.axes[1] || 0;
    let dir = null;
    if (pad.buttons[BTN.UP]?.pressed || ly < -AXIS_DEADZONE) dir = "up";else if (pad.buttons[BTN.DOWN]?.pressed || ly > AXIS_DEADZONE) dir = "down";else if (pad.buttons[BTN.LEFT]?.pressed || lx < -AXIS_DEADZONE) dir = "left";else if (pad.buttons[BTN.RIGHT]?.pressed || lx > AXIS_DEADZONE) dir = "right";
    const now = performance.now();
    if (dir) {
      if (!dirState || dirState.dir !== dir) {
        dirState = {
          dir,
          next: now + DIR_REPEAT_DELAY
        };
        if (active) onDirection?.(dir);
      } else if (now >= dirState.next) {
        dirState.next = now + DIR_REPEAT_RATE;
        if (active) onDirection?.(dir);
      }
    } else {
      dirState = null;
    }
  };
  raf = requestAnimationFrame(tick);
  return function stop() {
    if (raf) cancelAnimationFrame(raf);
  };
}
function useGamepadLoop(handlers, isActive, enabled = true) {
  const handlersRef = (0, _react.useRef)(handlers);
  handlersRef.current = handlers;
  const isActiveRef = (0, _react.useRef)(isActive);
  isActiveRef.current = isActive;
  (0, _react.useEffect)(() => {
    if (!enabled) return;
    const stop = startGamepadLoop({
      onButtonDown: i => handlersRef.current.onButtonDown?.(i),
      onButtonUp: i => handlersRef.current.onButtonUp?.(i),
      onDirection: d => handlersRef.current.onDirection?.(d),
      onConnectionChange: c => handlersRef.current.onConnectionChange?.(c)
    }, () => isActiveRef.current ? isActiveRef.current() : true);
    return stop;
  }, [enabled]);
}
},
"./utils/gamepadPlayerState": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.isPlayerGamepadActive = isPlayerGamepadActive;
exports.setPlayerGamepadActive = setPlayerGamepadActive;
let active = false;
function setPlayerGamepadActive(value) {
  active = !!value;
}
function isPlayerGamepadActive() {
  return active;
}
},
"./utils/gamepadSpatialNav": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.clearGamepadFocus = clearGamepadFocus;
exports.confirmGamepadFocus = confirmGamepadFocus;
exports.dismissActiveOverlay = dismissActiveOverlay;
exports.ensureInitialFocus = ensureInitialFocus;
exports.getGamepadFocus = getGamepadFocus;
exports.handleGamepadPageScroll = handleGamepadPageScroll;
exports.moveGamepadFocus = moveGamepadFocus;
exports.setGamepadFocus = setGamepadFocus;
const FOCUSABLE_SELECTOR = [".topnav-btn", ".hero-action-btn", ".hero-dot", ".nf-player-btn", ".nf-progress", ".nf-key", ".nf-trending-chip", ".nf-result-card", ".card", ".episode-card", ".season-btn", ".settings-select-option", ".source-dropdown__item", ".search-result", ".offline-card", ".ep-dl-btn", ".history-remove-btn", ".context-menu-item", "button:not(:disabled)", "a[href]", "input:not([disabled])", "select:not([disabled])", "textarea:not([disabled])", '[role="button"]:not([aria-disabled="true"])', '[tabindex]:not([tabindex="-1"])'].join(",");
const FOCUS_CLASS = "gamepad-focused";
let currentEl = null;
let touchClearInstalled = false;
let activeScrollRaf = 0;
function smoothScrollContainer(container, targetTop) {
  if (!container) return;
  if (activeScrollRaf) {
    cancelAnimationFrame(activeScrollRaf);
    activeScrollRaf = 0;
  }
  const startTop = container.scrollTop;
  const maxTop = Math.max(0, container.scrollHeight - container.clientHeight);
  const clamped = Math.max(0, Math.min(maxTop, targetTop));
  const delta = clamped - startTop;
  if (Math.abs(delta) < 2) {
    container.scrollTop = clamped;
    return;
  }
  const duration = 220;
  const startTime = performance.now();
  const step = now => {
    const t = Math.min(1, (now - startTime) / duration);
    const eased = 1 - Math.pow(1 - t, 3);
    container.scrollTop = startTop + delta * eased;
    if (t < 1) {
      activeScrollRaf = requestAnimationFrame(step);
    } else {
      activeScrollRaf = 0;
    }
  };
  activeScrollRaf = requestAnimationFrame(step);
}
function scrollElementSmoothly(el) {
  if (!el) return;
  const hRow = el.closest(".tv-scroll-row, .cards-row, .episodes-row");
  if (hRow) {
    const rowRect = hRow.getBoundingClientRect();
    const elRect = el.getBoundingClientRect();
    const pad = 28;
    if (elRect.left < rowRect.left + pad) {
      hRow.scrollTo({
        left: Math.max(0, hRow.scrollLeft - (rowRect.left + pad - elRect.left)),
        behavior: "smooth"
      });
    } else if (elRect.right > rowRect.right - pad) {
      hRow.scrollTo({
        left: hRow.scrollLeft + (elRect.right - (rowRect.right - pad)),
        behavior: "smooth"
      });
    }
  }
  if (el.closest(".topnav")) return;
  const mainEl = el.closest(".main");
  if (mainEl) {
    const mainRect = mainEl.getBoundingClientRect();
    const elRect = el.getBoundingClientRect();
    const topSafe = mainRect.top + 86;
    const bottomSafe = mainRect.bottom - 36;
    if (elRect.top < topSafe) {
      smoothScrollContainer(mainEl, mainEl.scrollTop - (topSafe - elRect.top));
    } else if (elRect.bottom > bottomSafe) {
      smoothScrollContainer(mainEl, mainEl.scrollTop + (elRect.bottom - bottomSafe));
    }
    return;
  }
  const scrollBox = el.closest(".nf-results-grid, .nf-search-left, .modal, .settings-content");
  if (scrollBox) {
    const boxRect = scrollBox.getBoundingClientRect();
    const elRect = el.getBoundingClientRect();
    const pad = 16;
    if (elRect.top < boxRect.top + pad) {
      smoothScrollContainer(scrollBox, scrollBox.scrollTop - (boxRect.top + pad - elRect.top));
    } else if (elRect.bottom > boxRect.bottom - pad) {
      smoothScrollContainer(scrollBox, scrollBox.scrollTop + (elRect.bottom - (boxRect.bottom - pad)));
    }
    return;
  }
  el.scrollIntoView?.({
    block: "nearest",
    inline: "nearest",
    behavior: "smooth"
  });
}
function installTouchClear() {
  if (touchClearInstalled || typeof window === "undefined") return;
  touchClearInstalled = true;
  window.addEventListener("touchstart", () => {
    if (currentEl) {
      currentEl.classList.remove(FOCUS_CLASS);
      currentEl = null;
    }
  }, {
    passive: true
  });
}
function isVisibleFast(el) {
  if (!el || !(el instanceof HTMLElement)) return false;
  if (el.offsetWidth < 8 || el.offsetHeight < 8) return false;
  if (el.closest("[data-gamepad-ignore]")) return false;
  return true;
}
function isModalRoot(el) {
  if (!(el instanceof HTMLElement)) return false;
  if (el.offsetWidth < window.innerWidth * 0.5 || el.offsetHeight < window.innerHeight * 0.5) return false;
  return getComputedStyle(el).position === "fixed";
}
function getScopeRoot() {
  const nfPlayer = document.querySelector(".nf-player-overlay");
  if (nfPlayer && isVisibleFast(nfPlayer)) return nfPlayer;
  const overlays = Array.from(document.querySelectorAll(".modal-overlay, .blocked-modal-overlay, .ep-desc-overlay, .context-menu, .source-dropdown, .settings-select-menu")).filter(el => isVisibleFast(el));
  if (overlays.length > 0) return overlays[overlays.length - 1];
  const modals = Array.from(document.querySelectorAll('[class*="overlay"]')).filter(el => isVisibleFast(el) && isModalRoot(el));
  if (modals.length > 0) return modals[modals.length - 1];
  return document;
}
function getCandidates() {
  installTouchClear();
  const root = getScopeRoot();
  const nodes = root.querySelectorAll(FOCUSABLE_SELECTOR);
  const seen = new Set();
  const out = [];
  for (const el of nodes) {
    if (!isVisibleFast(el) || seen.has(el)) continue;
    const rect = el.getBoundingClientRect();
    if (rect.width < 8 || rect.height < 8) continue;
    seen.add(el);
    out.push({
      el,
      rect
    });
  }
  return out;
}
function clearHighlight() {
  if (currentEl) {
    currentEl.classList.remove(FOCUS_CLASS);
  }
  document.querySelectorAll("." + FOCUS_CLASS).forEach(el => {
    if (el !== currentEl) el.classList.remove(FOCUS_CLASS);
  });
}
function setGamepadFocus(el, {
  scroll = true
} = {}) {
  installTouchClear();
  currentEl = el || null;
  clearHighlight();
  if (!currentEl) return;
  currentEl.classList.add(FOCUS_CLASS);
  const tag = (currentEl.tagName || "").toUpperCase();
  if (tag !== "INPUT" && tag !== "TEXTAREA") {
    try {
      currentEl.focus?.({
        preventScroll: true
      });
    } catch {}
  }
  if (scroll) {
    scrollElementSmoothly(currentEl);
  }
}
function getGamepadFocus() {
  return currentEl && document.contains(currentEl) && isVisibleFast(currentEl) ? currentEl : null;
}
function clearGamepadFocus() {
  currentEl = null;
  clearHighlight();
}
function confirmGamepadFocus() {
  const el = getGamepadFocus();
  if (!el) return false;
  if (el.classList.contains("player-wrap")) {
    try {
      const r = el.getBoundingClientRect();
      const rx = (r.left + r.width / 2) / Math.max(1, window.innerWidth);
      const ry = (r.top + r.height / 2) / Math.max(1, window.innerHeight);
      if (window.AndroidBridge?.tapPlayerCenter && ry > 0.05 && ry < 0.95) {
        window.AndroidBridge.tapPlayerCenter(rx, ry);
        return true;
      }
    } catch {}
  }
  const tag = (el.tagName || "").toUpperCase();
  if (tag === "INPUT" || tag === "TEXTAREA") {
    el.focus?.();
  }
  el.click();
  return true;
}
function dismissActiveOverlay() {
  const root = getScopeRoot();
  if (root === document) return false;
  const closeBtn = root.querySelector('[data-gamepad-close], [aria-label="Close" i], .modal-close, .close-btn, .blocked-modal-close, .ep-desc-popup-close');
  if (closeBtn instanceof HTMLElement) {
    closeBtn.click();
    return true;
  }
  if (root.classList.contains("settings-select-menu")) {
    document.dispatchEvent(new MouseEvent("mousedown", {
      bubbles: true
    }));
    return true;
  }
  if (root instanceof HTMLElement) {
    root.click();
    return true;
  }
  return false;
}
function pickInitial(candidates) {
  if (candidates.length === 0) return null;
  const mainHit = candidates.find(({
    el
  }) => el.closest(".nf-player-main-controls, .nf-keyboard-grid, .hero-actions, .detail-actions, .tv-scroll-row, .cards-grid"));
  if (mainHit) return mainHit.el;
  let best = null;
  let bestScore = Infinity;
  for (const {
    el,
    rect
  } of candidates) {
    if (el.closest(".topnav")) continue;
    const score = Math.max(0, rect.top) * 2 + Math.max(0, rect.left);
    if (score < bestScore) {
      bestScore = score;
      best = el;
    }
  }
  return best || candidates[0].el;
}
function handleGamepadPageScroll(direction) {
  const mainEl = document.querySelector(".main");
  if (!mainEl) {
    moveGamepadFocus(direction);
    return;
  }
  if (direction === "up") {
    if (mainEl.scrollTop > 8) {
      smoothScrollContainer(mainEl, Math.max(0, mainEl.scrollTop - Math.round(mainEl.clientHeight * 0.5)));
      return;
    }
    const candidates = getCandidates().filter(({
      el
    }) => el.closest(".topnav"));
    if (candidates.length > 0) {
      const activeTop = candidates.find(({
        el
      }) => el.classList.contains("active")) || candidates[0];
      setGamepadFocus(activeTop.el, {
        scroll: false
      });
    }
    return;
  }
  smoothScrollContainer(mainEl, mainEl.scrollTop + Math.round(mainEl.clientHeight * 0.5));
}
function moveGamepadFocus(direction) {
  const candidates = getCandidates();
  if (candidates.length === 0) return;
  const from = getGamepadFocus();
  const fromEntry = from ? candidates.find(c => c.el === from) : null;
  if (!fromEntry) {
    setGamepadFocus(pickInitial(candidates));
    return;
  }
  const fromRect = fromEntry.rect;
  const fromCx = fromRect.left + fromRect.width / 2;
  const fromCy = fromRect.top + fromRect.height / 2;
  const fromInTopnav = Boolean(from.closest(".topnav"));
  let best = null;
  let bestScore = Infinity;
  if (direction === "left" || direction === "right") {
    const dir = direction === "right" ? 1 : -1;
    const sameRowTolerance = Math.max(fromRect.height * 0.75, 24);
    for (const {
      el,
      rect: r
    } of candidates) {
      if (el === from) continue;
      if (fromInTopnav && !el.closest(".topnav")) continue;
      const cx = r.left + r.width / 2;
      const cy = r.top + r.height / 2;
      const dx = (cx - fromCx) * dir;
      if (dx <= 4) continue;
      const dy = Math.abs(cy - fromCy);
      if (dy > sameRowTolerance) continue;
      const score = dx + dy * 2;
      if (score < bestScore) {
        bestScore = score;
        best = el;
      }
    }
  } else {
    const dir = direction === "down" ? 1 : -1;
    const minRowStep = Math.max(fromRect.height * 0.45, 14);
    for (const {
      el,
      rect: r
    } of candidates) {
      if (el === from) continue;
      if (direction === "up" && !fromInTopnav && el.closest(".topnav")) continue;
      const cx = r.left + r.width / 2;
      const cy = r.top + r.height / 2;
      const dy = (cy - fromCy) * dir;
      if (dy <= minRowStep) continue;
      const dx = Math.abs(cx - fromCx);
      const horizontalOverlap = Math.max(0, Math.min(fromRect.right, r.right) - Math.max(fromRect.left, r.left));
      const overlapBonus = horizontalOverlap > 0 ? -120 : 0;
      const score = dy * 2.2 + dx + overlapBonus;
      if (score < bestScore) {
        bestScore = score;
        best = el;
      }
    }
    if (!best && direction === "up" && !fromInTopnav) {
      const mainEl = document.querySelector(".main");
      if (mainEl && mainEl.scrollTop > 8) {
        smoothScrollContainer(mainEl, Math.max(0, mainEl.scrollTop - Math.round(mainEl.clientHeight * 0.45)));
        return;
      }
      const topBtns = candidates.filter(({
        el
      }) => el.closest(".topnav"));
      if (topBtns.length > 0) {
        let closestTop = topBtns[0].el;
        let minDx = Infinity;
        for (const {
          el,
          rect: r
        } of topBtns) {
          const cx = r.left + r.width / 2;
          const dx = Math.abs(cx - fromCx);
          if (dx < minDx) {
            minDx = dx;
            closestTop = el;
          }
        }
        setGamepadFocus(closestTop, {
          scroll: false
        });
      }
      return;
    }
  }
  if (best) setGamepadFocus(best);
}
function ensureInitialFocus() {
  if (getGamepadFocus()) return;
  setGamepadFocus(pickInitial(getCandidates()));
}
},
"./utils/homeLayout": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.HOME_ROWS = void 0;
exports.loadHomeLayout = loadHomeLayout;
exports.loadHomeViewMode = loadHomeViewMode;
exports.loadStartPage = loadStartPage;
exports.saveHomeLayout = saveHomeLayout;
exports.saveHomeViewMode = saveHomeViewMode;
var _storage = require("./storage");
const HOME_ROWS = [{
  id: "continue",
  label: "Continue Watching"
}, {
  id: "recommended",
  label: "Recommended for You"
}, {
  id: "trendingMovies",
  label: "Trending Movies"
}, {
  id: "trendingTV",
  label: "Trending Series"
}, {
  id: "topRated",
  label: "Top Rated"
}];
exports.HOME_ROWS = HOME_ROWS;
const DEFAULT_ROW_ORDER = HOME_ROWS.map(r => r.id);
const DEFAULT_ROW_VISIBLE = Object.fromEntries(HOME_ROWS.map(r => [r.id, true]));
function loadHomeLayout() {
  const savedOrder = _storage.storage.get("homeRowOrder");
  const savedVisible = _storage.storage.get("homeRowVisible");
  const knownIds = new Set(HOME_ROWS.map(r => r.id));
  const order = savedOrder ? [...savedOrder.filter(id => knownIds.has(id)), ...DEFAULT_ROW_ORDER.filter(id => !savedOrder.includes(id))] : DEFAULT_ROW_ORDER;
  const visible = savedVisible ? {
    ...DEFAULT_ROW_VISIBLE,
    ...savedVisible
  } : DEFAULT_ROW_VISIBLE;
  return {
    order,
    visible
  };
}
function saveHomeLayout(order, visible) {
  _storage.storage.set("homeRowOrder", order);
  _storage.storage.set("homeRowVisible", visible);
}
function loadHomeViewMode() {
  return _storage.storage.get("homeViewMode") || "carousel";
}
function saveHomeViewMode(mode) {
  _storage.storage.set("homeViewMode", mode);
}
function loadStartPage() {
  return _storage.storage.get("startPage") || "home";
}
},
"./utils/liveTouch": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.initLiveTouch = initLiveTouch;
const TOUCH_SELECTOR = ["button", ".card", ".topnav-btn", ".hero-action-btn", ".hero-dot", ".episode-card", ".season-btn", ".search-result", ".nf-key", ".nf-trending-chip", ".nf-player-btn", ".btn", '[role="button"]'].join(",");
let activeTouchEl = null;
let clearTimer = null;
let installed = false;
function clearTouch() {
  if (clearTimer) {
    clearTimeout(clearTimer);
    clearTimer = null;
  }
  if (activeTouchEl) {
    activeTouchEl.classList.remove("touch-active");
    activeTouchEl = null;
  }
}
function initLiveTouch() {
  if (installed || typeof window === "undefined") return;
  installed = true;
  const onStart = e => {
    if (e.type === "pointerdown" && e.pointerType === "mouse") return;
    const target = e.target instanceof Element ? e.target.closest(TOUCH_SELECTOR) : null;
    clearTouch();
    if (target && !target.hasAttribute("disabled")) {
      activeTouchEl = target;
      activeTouchEl.classList.add("touch-active");
    }
  };
  const onEndSoon = () => {
    if (clearTimer) clearTimeout(clearTimer);
    clearTimer = setTimeout(clearTouch, 90);
  };
  window.addEventListener("pointerdown", onStart, {
    passive: true,
    capture: true
  });
  window.addEventListener("pointerup", clearTouch, {
    passive: true,
    capture: true
  });
  window.addEventListener("pointercancel", clearTouch, {
    passive: true,
    capture: true
  });
  window.addEventListener("touchstart", onStart, {
    passive: true,
    capture: true
  });
  window.addEventListener("touchend", clearTouch, {
    passive: true,
    capture: true
  });
  window.addEventListener("touchcancel", clearTouch, {
    passive: true,
    capture: true
  });
  window.addEventListener("click", onEndSoon, {
    passive: true,
    capture: true
  });
  window.addEventListener("scroll", clearTouch, {
    passive: true,
    capture: true
  });
  window.addEventListener("blur", clearTouch, {
    passive: true
  });
  document.addEventListener("visibilitychange", clearTouch, {
    passive: true
  });
}
},
"./utils/playerGamepadScript": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.GAMEPAD_PLAYER_SCRIPT = exports.GAMEPAD_EXIT_RESET_JS = exports.GAMEPAD_EXIT_CHECK_JS = exports.GAMEPAD_CLEANUP_JS = void 0;
const GAMEPAD_PLAYER_SCRIPT = `
(function() {
  if (window.__gamepadControlsInjected) return;
  window.__gamepadControlsInjected = true;

  var BTN = { A:0,B:1,X:2,Y:3,LB:4,RB:5,LT:6,RT:7,BACK:8,START:9,LS:10,RS:11,UP:12,DOWN:13,LEFT:14,RIGHT:15 };
  var DEADZONE = 0.45;
  var REPEAT_DELAY = 420, REPEAT_RATE = 140;

  var toastEl = null;
  function toast(msg) {
    if (!toastEl) {
      toastEl = document.createElement('div');
      toastEl.style.cssText = [
        'position:fixed','bottom:24px','left:50%','transform:translateX(-50%)',
        'background:rgba(0,0,0,0.78)','color:#fff','padding:8px 16px','border-radius:8px',
        'font:600 12px system-ui,sans-serif','z-index:2147483647','pointer-events:none',
        'opacity:0','transition:opacity .2s',
      ].join(';');
      document.documentElement.appendChild(toastEl);
    }
    toastEl.textContent = msg;
    toastEl.style.opacity = '1';
    clearTimeout(toastEl._t);
    toastEl._t = setTimeout(function() { toastEl.style.opacity = '0'; }, 900);
  }

  function getVideo() { return document.querySelector('video'); }

  function seek(delta) {
    var v = getVideo(); if (!v) return;
    v.currentTime = Math.max(0, Math.min(v.duration || 1e9, v.currentTime + delta));
    toast((delta > 0 ? 'Skip +' : 'Skip -') + Math.abs(delta) + 's');
  }
  function togglePlay() {
    var v = getVideo(); if (!v) return;
    if (v.paused) { v.play(); toast('Play'); } else { v.pause(); toast('Pause'); }
  }
  function changeVolume(delta) {
    var v = getVideo(); if (!v) return;
    v.muted = false;
    v.volume = Math.max(0, Math.min(1, v.volume + delta));
    toast('Volume ' + Math.round(v.volume * 100) + '%');
  }
  function toggleFullscreen() {
    var v = getVideo();
    if (document.fullscreenElement) {
      document.exitFullscreen().catch(function() {});
    } else if (v && v.requestFullscreen) {
      v.requestFullscreen().catch(function() {});
    }
  }

  var prevButtons = [];
  var dirState = null;
  var raf = null;

  function onButtonDown(i) {
    if (i === BTN.A) togglePlay();
    else if (i === BTN.Y) toggleFullscreen();
    else if (i === BTN.LB) seek(-15);
    else if (i === BTN.RB) seek(15);
    else if (i === BTN.B) {
      if (document.fullscreenElement) {
        document.exitFullscreen().catch(function() {});
      } else {
        window.__gamepadExitRequested = true;
      }
    }
  }
  function onDirection(dir) {
    if (dir === 'left') seek(-10);
    else if (dir === 'right') seek(10);
    else if (dir === 'up') changeVolume(0.1);
    else if (dir === 'down') changeVolume(-0.1);
  }

  function tick() {
    raf = requestAnimationFrame(tick);
    var pads = navigator.getGamepads ? navigator.getGamepads() : [];
    var pad = null;
    for (var i = 0; i < pads.length; i++) { if (pads[i]) { pad = pads[i]; break; } }
    if (!pad) { prevButtons = []; dirState = null; return; }

    for (var bi = 0; bi < pad.buttons.length; bi++) {
      var b = pad.buttons[bi];
      var pressed = !!(b && (b.pressed || b.value > 0.5));
      var wasPressed = !!prevButtons[bi];
      if (pressed && !wasPressed) onButtonDown(bi);
      prevButtons[bi] = pressed;
    }

    var lx = pad.axes[0] || 0, ly = pad.axes[1] || 0;
    var dir = null;
    if ((pad.buttons[BTN.UP] && pad.buttons[BTN.UP].pressed) || ly < -DEADZONE) dir = 'up';
    else if ((pad.buttons[BTN.DOWN] && pad.buttons[BTN.DOWN].pressed) || ly > DEADZONE) dir = 'down';
    else if ((pad.buttons[BTN.LEFT] && pad.buttons[BTN.LEFT].pressed) || lx < -DEADZONE) dir = 'left';
    else if ((pad.buttons[BTN.RIGHT] && pad.buttons[BTN.RIGHT].pressed) || lx > DEADZONE) dir = 'right';

    var now = performance.now();
    if (dir) {
      if (!dirState || dirState.dir !== dir) {
        dirState = { dir: dir, next: now + REPEAT_DELAY };
        onDirection(dir);
      } else if (now >= dirState.next) {
        dirState.next = now + REPEAT_RATE;
        onDirection(dir);
      }
    } else {
      dirState = null;
    }
  }

  raf = requestAnimationFrame(tick);

  window.__gamepadControlsCleanup = function() {
    if (raf) cancelAnimationFrame(raf);
    window.__gamepadControlsInjected = false;
    if (toastEl && toastEl.parentNode) toastEl.parentNode.removeChild(toastEl);
    toastEl = null;
  };
})();
`;
exports.GAMEPAD_PLAYER_SCRIPT = GAMEPAD_PLAYER_SCRIPT;
const GAMEPAD_EXIT_CHECK_JS = "(() => window.__gamepadExitRequested === true)()";
exports.GAMEPAD_EXIT_CHECK_JS = GAMEPAD_EXIT_CHECK_JS;
const GAMEPAD_EXIT_RESET_JS = "(() => { window.__gamepadExitRequested = false; })()";
exports.GAMEPAD_EXIT_RESET_JS = GAMEPAD_EXIT_RESET_JS;
const GAMEPAD_CLEANUP_JS = "(() => { if (window.__gamepadControlsCleanup) window.__gamepadControlsCleanup(); })()";
exports.GAMEPAD_CLEANUP_JS = GAMEPAD_CLEANUP_JS;
},
"./utils/storage": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.STORAGE_KEYS = void 0;
exports.clearAppCaches = clearAppCaches;
exports.clearFailoverSource = void 0;
exports.formatBytes = formatBytes;
exports.storage = exports.setFailoverSource = exports.secureStorage = exports.isElectron = exports.getFailoverSource = exports.getApiKey = void 0;
var _androidBridge = require("./androidBridge");
const PREFIX = "streambert_";
if (typeof window !== "undefined" && window.AndroidBridge?.getAllPreferencesJson) {
  try {
    const rawMap = window.AndroidBridge.getAllPreferencesJson();
    if (rawMap) {
      const parsed = JSON.parse(rawMap);
      for (const [k, v] of Object.entries(parsed)) {
        if (v !== null && v !== undefined) {
          localStorage.setItem(PREFIX + k, v);
        }
      }
    }
  } catch (e) {
    console.warn("[storage] Room hydration warning:", e);
  }
}
const storage = {
  get(key) {
    try {
      let raw = localStorage.getItem(PREFIX + key);
      if (!raw && typeof window !== "undefined" && window.AndroidBridge?.getPreference) {
        raw = window.AndroidBridge.getPreference(key);
        if (raw) localStorage.setItem(PREFIX + key, raw);
      }
      if (!raw && key === "hianimeDubMode") {
        raw = localStorage.getItem(PREFIX + "allmangaDubMode");
      }
      const value = raw ? JSON.parse(raw) : null;
      if (key === "playerSource" && value === "allmanga") return "hianime";
      return value;
    } catch {
      return null;
    }
  },
  set(key, value) {
    try {
      const serialized = JSON.stringify(value);
      localStorage.setItem(PREFIX + key, serialized);
      if (typeof window !== "undefined" && window.AndroidBridge?.setPreference) {
        window.AndroidBridge.setPreference(key, serialized);
      }
    } catch {}
  },
  remove(key) {
    try {
      localStorage.removeItem(PREFIX + key);
      if (typeof window !== "undefined" && window.AndroidBridge?.removePreference) {
        window.AndroidBridge.removePreference(key);
      }
    } catch {}
  },
  clearAll() {
    try {
      Object.keys(localStorage).filter(k => k.startsWith(PREFIX)).forEach(k => localStorage.removeItem(k));
      if (typeof window !== "undefined" && window.AndroidBridge?.clearPreferences) {
        window.AndroidBridge.clearPreferences();
      }
    } catch {}
  }
};
exports.storage = storage;
const STORAGE_KEYS = {
  UPDATE_SOURCE: "updateSource",
  PLAYER_SOURCE: "playerSource",
  HIANIME_DUB_MODE: "hianimeDubMode",
  WATCH_PROGRESS: "progress",
  WATCHED: "watched",
  HISTORY: "history",
  SAVED: "saved",
  SAVED_ORDER: "savedOrder",
  LOCAL_FILES: "localFiles",
  DOWNLOAD_PATH: "downloadPath",
  DOWNLOADER_FOLDER: "downloaderFolder",
  START_PAGE: "startPage",
  AGE_LIMIT: "ageLimit",
  RATING_COUNTRY: "ratingCountry",
  WATCHED_THRESHOLD: "watchedThreshold",
  HOME_ROW_ORDER: "homeRowOrder",
  HOME_ROW_VISIBLE: "homeRowVisible",
  HOME_VIEW_MODE: "homeViewMode",
  AUTO_CHECK_UPDATES: "autoCheckUpdates",
  INVIDIOUS_BASE: "invidiousBase",
  SUBTITLE_ENABLED: "subtitleDownload",
  SUBTITLE_LANG: "subtitleLang",
  SUBTITLE_DELAY_MS: "subtitleDelayMs",
  SUBTITLE_FONT_SCALE: "subtitleFontScale",
  SUBTITLE_POSITION: "subtitlePosition",
  SUBDL_API_KEY: "subdlApiKey",
  WYZIE_API_KEY: "wyzieApiKey",
  ACCENT_COLOR: "accentColor",
  ACCENT_IN_PLAYER: "accentInPlayer",
  THEME: "theme",
  CUSTOM_THEME_VARS: "customThemeVars",
  FONT_SIZE: "fontSize",
  COMPACT_MODE: "compactMode",
  REDUCE_ANIMATIONS: "reduceAnimations",
  LIBRARY_SORT: "librarySort",
  HISTORY_ENABLED: "historyEnabled",
  NOTIFY_DOWNLOAD_COMPLETE: "notifyDownloadComplete",
  NOTIFY_NEW_EPISODE: "notifyNewEpisode",
  TMDB_LANG: "tmdbLang",
  INTRO_SKIP_MODE: "introSkipMode",
  AUTOPLAY_NEXT_ENABLED: "autoplayNextEnabled",
  AUTOPLAY_NEXT_DURATION: "autoplayNextDuration",
  AUTOPLAY_NEXT_LAYOUT: "autoplayNextLayout",
  DL_SORT_BY: "dlSortBy",
  DL_SORT_DIR: "dlSortDir",
  DL_SHOW_UNTRACKED: "dlShowUntracked",
  EPISODE_RELEASE_CACHE: "episodeReleaseCache",
  SOURCE_FAILOVER_CACHE: "sourceFailoverCache",
  DISCORD_RPC_ENABLED: "discordRpcEnabled",
  DISCORD_RPC_SHOW_COVER: "discordRpcShowCover",
  DISCORD_RPC_SHOW_TIMESTAMP: "discordRpcShowTimestamp",
  DISCORD_RPC_SHOW_BUTTON: "discordRpcShowButton",
  GAMEPAD_ENABLED: "gamepadEnabled",
  FORCE_TV_MODE: "forceTvMode",
  PREFER_NATIVE_EXOPLAYER: "preferNativeExoPlayer"
};
exports.STORAGE_KEYS = STORAGE_KEYS;
const getApiKey = () => "KEYLESS_ANDROID_MODE";
exports.getApiKey = getApiKey;
const FAILOVER_CACHE_MAX = 200;
const getFailoverSource = epKey => {
  const cache = storage.get(STORAGE_KEYS.SOURCE_FAILOVER_CACHE) || {};
  return cache[epKey]?.sourceId || null;
};
exports.getFailoverSource = getFailoverSource;
const setFailoverSource = (epKey, sourceId) => {
  const cache = storage.get(STORAGE_KEYS.SOURCE_FAILOVER_CACHE) || {};
  const keys = Object.keys(cache);
  if (keys.length >= FAILOVER_CACHE_MAX) {
    const evict = keys.slice(0, keys.length - FAILOVER_CACHE_MAX + 1);
    evict.forEach(k => delete cache[k]);
  }
  cache[epKey] = {
    sourceId,
    ts: Date.now()
  };
  storage.set(STORAGE_KEYS.SOURCE_FAILOVER_CACHE, cache);
};
exports.setFailoverSource = setFailoverSource;
const clearFailoverSource = epKey => {
  const cache = storage.get(STORAGE_KEYS.SOURCE_FAILOVER_CACHE) || {};
  if (cache[epKey] !== undefined) {
    delete cache[epKey];
    storage.set(STORAGE_KEYS.SOURCE_FAILOVER_CACHE, cache);
  }
};
exports.clearFailoverSource = clearFailoverSource;
const isElectron = true;
exports.isElectron = isElectron;
function formatBytes(bytes) {
  if (bytes === null || bytes === undefined) return "…";
  if (bytes === -1) return null;
  if (bytes === 0) return "0 B";
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
  if (bytes < 1024 * 1024 * 1024) return (bytes / (1024 * 1024)).toFixed(1) + " MB";
  return (bytes / (1024 * 1024 * 1024)).toFixed(2) + " GB";
}
const secureStorage = {
  async get(key) {
    return _androidBridge.androidBridge.secureGet(key);
  },
  async set(key, value) {
    return _androidBridge.androidBridge.secureSet(key, value ?? "");
  }
};
exports.secureStorage = secureStorage;
async function clearAppCaches() {
  try {
    await _androidBridge.androidBridge.clearAppCache();
  } catch {}
  localStorage.removeItem("streambert_anilistCache");
  localStorage.removeItem("streambert_episodeGroupCache");
  localStorage.removeItem("streambert_aniskipCache");
  for (const key of Object.keys(localStorage)) {
    if (key.startsWith("dlDur_")) localStorage.removeItem(key);
  }
}
},
"./utils/subtitles": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.SUBTITLE_LANGUAGES = exports.LANG_LABEL = void 0;
exports.sourceBadgeLabel = sourceBadgeLabel;
exports.sourceBadgeStyle = sourceBadgeStyle;
const SUBTITLE_LANGUAGES = [{
  code: "en",
  label: "English"
}, {
  code: "de",
  label: "German"
}, {
  code: "fr",
  label: "French"
}, {
  code: "es",
  label: "Spanish"
}, {
  code: "it",
  label: "Italian"
}, {
  code: "pt",
  label: "Portuguese"
}, {
  code: "nl",
  label: "Dutch"
}, {
  code: "pl",
  label: "Polish"
}, {
  code: "ru",
  label: "Russian"
}, {
  code: "ja",
  label: "Japanese"
}, {
  code: "ko",
  label: "Korean"
}, {
  code: "zh-CN",
  label: "Chinese"
}, {
  code: "ar",
  label: "Arabic"
}, {
  code: "tr",
  label: "Turkish"
}, {
  code: "sv",
  label: "Swedish"
}, {
  code: "da",
  label: "Danish"
}, {
  code: "cs",
  label: "Czech"
}, {
  code: "hu",
  label: "Hungarian"
}];
exports.SUBTITLE_LANGUAGES = SUBTITLE_LANGUAGES;
const LANG_LABEL = Object.fromEntries(SUBTITLE_LANGUAGES.map(l => [l.code, l.label]));
exports.LANG_LABEL = LANG_LABEL;
function sourceBadgeStyle(sub) {
  const isSubDL = sub.via_subdl;
  return {
    fontSize: 9,
    fontWeight: 700,
    padding: "1px 5px",
    borderRadius: 3,
    background: isSubDL ? "rgba(229,9,20,0.15)" : "rgba(180,130,255,0.15)",
    color: isSubDL ? "#ff4d57" : "#b482ff",
    border: `1px solid ${isSubDL ? "rgba(229,9,20,0.35)" : "rgba(180,130,255,0.3)"}`,
    textTransform: "uppercase",
    flexShrink: 0
  };
}
function sourceBadgeLabel(sub) {
  if (sub.via_subdl) return "SubDL";
  return "Wyzie";
}
},
"./utils/updates": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.UPDATE_SOURCES = exports.TELEGRAM_URL = exports.TELEGRAM_HANDLE = exports.DEFAULT_UPDATE_SOURCE = void 0;
exports.checkForUpdates = checkForUpdates;
exports.checkForUpdatesWithFallback = checkForUpdatesWithFallback;
const TELEGRAM_HANDLE = "ec1lz";
exports.TELEGRAM_HANDLE = TELEGRAM_HANDLE;
const TELEGRAM_URL = "https://t.me/ec1lz";
exports.TELEGRAM_URL = TELEGRAM_URL;
const UPDATE_SOURCES = {
  telegram: {
    id: "telegram",
    label: "Telegram @ec1lz",
    apiUrl: "https://t.me/ec1lz",
    headers: {},
    fallbackUrl: "https://t.me/ec1lz"
  }
};
exports.UPDATE_SOURCES = UPDATE_SOURCES;
const DEFAULT_UPDATE_SOURCE = "telegram";
exports.DEFAULT_UPDATE_SOURCE = DEFAULT_UPDATE_SOURCE;
async function checkForUpdates() {
  return {
    hasUpdate: false,
    current: "2.7.0",
    latest: "2.7.0",
    url: "https://t.me/ec1lz",
    sourceLabel: "Telegram @ec1lz"
  };
}
async function checkForUpdatesWithFallback() {
  return checkForUpdates();
}
},
"./utils/useAutoplay": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useAutoplay = useAutoplay;
var _react = require("react");
var _storage = require("./storage");
const _todayForEpisodes = (() => {
  const d = new Date();
  d.setHours(0, 0, 0, 0);
  return d;
})();
function useAutoplay({
  nextEp,
  playEpisode,
  restricted
}) {
  const [autoplayCountdown, setAutoplayCountdown] = (0, _react.useState)(null);
  const countdownIntervalRef = (0, _react.useRef)(null);
  const countdownStartedRef = (0, _react.useRef)(false);
  const nextEpRef = (0, _react.useRef)(nextEp);
  (0, _react.useEffect)(() => {
    nextEpRef.current = nextEp;
  }, [nextEp]);
  const playEpisodeRef = (0, _react.useRef)(playEpisode);
  (0, _react.useEffect)(() => {
    playEpisodeRef.current = playEpisode;
  }, [playEpisode]);
  const cancelAutoplay = (0, _react.useCallback)(() => {
    if (countdownIntervalRef.current) {
      clearInterval(countdownIntervalRef.current);
      countdownIntervalRef.current = null;
    }
    setAutoplayCountdown(null);
  }, []);
  const triggerAutoplay = (0, _react.useCallback)(() => {
    const isEnabled = _storage.storage.get(_storage.STORAGE_KEYS.AUTOPLAY_NEXT_ENABLED) ?? true;
    if (!isEnabled) return;
    const currentNextEp = nextEpRef.current;
    if (!currentNextEp) return;
    const epUnreleased = currentNextEp.air_date ? new Date(currentNextEp.air_date) > _todayForEpisodes : false;
    if (restricted || epUnreleased) return;
    const duration = _storage.storage.get(_storage.STORAGE_KEYS.AUTOPLAY_NEXT_DURATION) ?? 5;
    cancelAutoplay();
    if (duration === 0) {
      setAutoplayCountdown(0);
    } else {
      setAutoplayCountdown(duration);
      countdownIntervalRef.current = setInterval(() => {
        setAutoplayCountdown(prev => {
          if (prev <= 1) {
            clearInterval(countdownIntervalRef.current);
            countdownIntervalRef.current = null;
            if (playEpisodeRef.current && nextEpRef.current) {
              playEpisodeRef.current(nextEpRef.current);
            }
            return null;
          }
          return prev - 1;
        });
      }, 1000);
    }
  }, [restricted, cancelAutoplay]);
  const playNow = (0, _react.useCallback)(() => {
    cancelAutoplay();
    if (playEpisodeRef.current && nextEpRef.current) {
      playEpisodeRef.current(nextEpRef.current);
    }
  }, [cancelAutoplay]);
  const resetAutoplay = (0, _react.useCallback)(() => {
    cancelAutoplay();
    countdownStartedRef.current = false;
  }, [cancelAutoplay]);
  (0, _react.useEffect)(() => {
    return () => {
      if (countdownIntervalRef.current) {
        clearInterval(countdownIntervalRef.current);
      }
    };
  }, []);
  return {
    autoplayCountdown,
    countdownStarted: countdownStartedRef.current,
    setCountdownStarted: val => {
      countdownStartedRef.current = val;
    },
    triggerAutoplay,
    cancelAutoplay,
    playNow,
    resetAutoplay
  };
}
},
"./utils/useBlockedStats": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useBlockedStats = useBlockedStats;
var _react = require("react");
function useBlockedStats(resetKey) {
  const [sessionTotal, setSessionTotal] = (0, _react.useState)(0);
  const sessionDomainsRef = (0, _react.useRef)({});
  const [alltimeTotal, setAlltimeTotal] = (0, _react.useState)(0);
  const [showModal, setShowModal] = (0, _react.useState)(false);
  (0, _react.useEffect)(() => {
    if (!window.electron?.getBlockStats) return;
    let mounted = true;
    window.electron.getBlockStats().then(stats => {
      if (mounted && stats) setAlltimeTotal(stats.total || 0);
    });
    return () => {
      mounted = false;
    };
  }, []);
  (0, _react.useEffect)(() => {
    setSessionTotal(0);
    sessionDomainsRef.current = {};
  }, [resetKey]);
  (0, _react.useEffect)(() => {
    if (!window.electron?.onBlockedUpdate) return;
    const handler = window.electron.onBlockedUpdate(data => {
      if (!data) return;
      setAlltimeTotal(prev => prev + (data.total || 0));
      setSessionTotal(prev => prev + (data.total || 0));
      const map = sessionDomainsRef.current;
      for (const [domain, count] of Object.entries(data.domains || {})) {
        map[domain] = (map[domain] || 0) + count;
      }
    });
    return () => {
      if (window.electron?.offBlockedUpdate) window.electron.offBlockedUpdate(handler);
    };
  }, []);
  const getSessionDomains = (0, _react.useCallback)(() => Object.entries(sessionDomainsRef.current).sort((a, b) => b[1] - a[1]), []);
  return {
    sessionTotal,
    alltimeTotal,
    showModal,
    setShowModal,
    getSessionDomains
  };
}
},
"./utils/useCredits": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useCredits = useCredits;
var _react = require("react");
var _api = require("./api");
const EMPTY = {
  cast: [],
  crew: []
};
function useCredits(type, id, apiKey) {
  const [credits, setCredits] = (0, _react.useState)(EMPTY);
  (0, _react.useEffect)(() => {
    let mounted = true;
    setCredits(EMPTY);
    const path = type === "tv" ? `/tv/${id}/aggregate_credits` : `/movie/${id}/credits`;
    (0, _api.tmdbFetch)(path, apiKey).then(data => {
      if (!mounted) return;
      setCredits({
        cast: data?.cast || [],
        crew: data?.crew || []
      });
    }).catch(() => {
      if (mounted) setCredits(EMPTY);
    });
    return () => {
      mounted = false;
    };
  }, [type, id, apiKey]);
  return credits;
}
},
"./utils/useGamepadNav": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useGamepadNav = useGamepadNav;
var _react = require("react");
var _gamepad = require("./gamepad");
var _gamepadSpatialNav = require("./gamepadSpatialNav");
var _gamepadPlayerState = require("./gamepadPlayerState");
var _androidBridge = require("./androidBridge");
function useGamepadNav({
  enabled,
  onBack,
  onOpenSearch
}) {
  const [connected, setConnected] = (0, _react.useState)(false);
  const lastNavTimeRef = (0, _react.useRef)(0);
  const onBackRef = (0, _react.useRef)(onBack);
  onBackRef.current = onBack;
  const onOpenSearchRef = (0, _react.useRef)(onOpenSearch);
  onOpenSearchRef.current = onOpenSearch;
  const runGuarded = fn => {
    const now = performance.now();
    if (now - lastNavTimeRef.current < 105) return;
    lastNavTimeRef.current = now;
    fn();
  };
  (0, _gamepad.useGamepadLoop)({
    onConnectionChange: setConnected,
    onDirection: dir => {
      runGuarded(() => {
        (0, _gamepadSpatialNav.ensureInitialFocus)();
        (0, _gamepadSpatialNav.moveGamepadFocus)(dir);
      });
    },
    onButtonDown: i => {
      runGuarded(() => {
        if (i === _gamepad.BTN.A) {
          (0, _gamepadSpatialNav.ensureInitialFocus)();
          (0, _gamepadSpatialNav.confirmGamepadFocus)();
        } else if (i === _gamepad.BTN.B) {
          if (!(0, _gamepadSpatialNav.dismissActiveOverlay)()) onBackRef.current?.();
        } else if (i === _gamepad.BTN.START) {
          onOpenSearchRef.current?.();
        }
      });
    }
  }, () => !(0, _gamepadPlayerState.isPlayerGamepadActive)(), enabled);
  (0, _react.useEffect)(() => {
    if (!enabled) return;
    if ((0, _androidBridge.isAndroidTvDevice)()) {
      setTimeout(() => (0, _gamepadSpatialNav.ensureInitialFocus)(), 180);
    }
    const handleKeyDown = e => {
      const isDirectionKey = e.key === "ArrowUp" || e.key === "ArrowDown" || e.key === "ArrowLeft" || e.key === "ArrowRight" || e.key === "PageUp" || e.key === "PageDown" || e.keyCode === 19 || e.keyCode === 20 || e.keyCode === 21 || e.keyCode === 22 || e.keyCode === 33 || e.keyCode === 34;
      if (e.repeat && !isDirectionKey) return;
      const active = document.activeElement;
      const tag = (active?.tagName || "").toUpperCase();
      const isTextInput = tag === "INPUT" || tag === "TEXTAREA" || active?.isContentEditable;
      if (e.key === "PageUp" || e.keyCode === 33) {
        e.preventDefault();
        runGuarded(() => {
          (0, _gamepadSpatialNav.ensureInitialFocus)();
          (0, _gamepadSpatialNav.handleGamepadPageScroll)("up");
        });
        return;
      }
      if (e.key === "PageDown" || e.keyCode === 34) {
        e.preventDefault();
        runGuarded(() => {
          (0, _gamepadSpatialNav.ensureInitialFocus)();
          (0, _gamepadSpatialNav.handleGamepadPageScroll)("down");
        });
        return;
      }
      if (e.key === "ArrowUp" || e.keyCode === 19) {
        e.preventDefault();
        runGuarded(() => {
          (0, _gamepadSpatialNav.ensureInitialFocus)();
          (0, _gamepadSpatialNav.moveGamepadFocus)("up");
        });
        return;
      }
      if (e.key === "ArrowDown" || e.keyCode === 20) {
        e.preventDefault();
        runGuarded(() => {
          (0, _gamepadSpatialNav.ensureInitialFocus)();
          (0, _gamepadSpatialNav.moveGamepadFocus)("down");
        });
        return;
      }
      if (e.key === "ArrowLeft" || e.keyCode === 21) {
        if (isTextInput) return;
        e.preventDefault();
        runGuarded(() => {
          (0, _gamepadSpatialNav.ensureInitialFocus)();
          (0, _gamepadSpatialNav.moveGamepadFocus)("left");
        });
        return;
      }
      if (e.key === "ArrowRight" || e.keyCode === 22) {
        if (isTextInput) return;
        e.preventDefault();
        runGuarded(() => {
          (0, _gamepadSpatialNav.ensureInitialFocus)();
          (0, _gamepadSpatialNav.moveGamepadFocus)("right");
        });
        return;
      }
      if (e.key === "Enter" || e.key === " " || e.keyCode === 23 || e.keyCode === 66) {
        if (isTextInput && e.key !== "Enter") return;
        if (isTextInput && tag === "INPUT") return;
        e.preventDefault();
        runGuarded(() => {
          (0, _gamepadSpatialNav.ensureInitialFocus)();
          (0, _gamepadSpatialNav.confirmGamepadFocus)();
        });
        return;
      }
      if (e.key === "Escape" || e.key === "GoBack" || e.key === "BrowserBack" || e.keyCode === 4 || !isTextInput && e.key === "Backspace") {
        e.preventDefault();
        runGuarded(() => {
          if (!(0, _gamepadSpatialNav.dismissActiveOverlay)()) {
            onBackRef.current?.();
          }
        });
        return;
      }
      if (e.key === "ContextMenu" || e.key === "F2" || e.keyCode === 82) {
        e.preventDefault();
        runGuarded(() => {
          onOpenSearchRef.current?.();
        });
      }
    };
    const handleNativeDpad = ev => {
      const action = ev.detail?.action;
      if (!action) return;
      runGuarded(() => {
        if (action === "page_up") {
          (0, _gamepadSpatialNav.ensureInitialFocus)();
          (0, _gamepadSpatialNav.handleGamepadPageScroll)("up");
        } else if (action === "page_down") {
          (0, _gamepadSpatialNav.ensureInitialFocus)();
          (0, _gamepadSpatialNav.handleGamepadPageScroll)("down");
        } else if (["up", "down", "left", "right"].includes(action)) {
          (0, _gamepadSpatialNav.ensureInitialFocus)();
          (0, _gamepadSpatialNav.moveGamepadFocus)(action);
        } else if (action === "select" || action === "center") {
          (0, _gamepadSpatialNav.ensureInitialFocus)();
          (0, _gamepadSpatialNav.confirmGamepadFocus)();
        } else if (action === "back") {
          if (!(0, _gamepadSpatialNav.dismissActiveOverlay)()) onBackRef.current?.();
        } else if (action === "menu") {
          onOpenSearchRef.current?.();
        }
      });
    };
    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("streambert:dpad", handleNativeDpad);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("streambert:dpad", handleNativeDpad);
    };
  }, [enabled]);
  (0, _react.useEffect)(() => {
    if (!enabled) {
      (0, _gamepadSpatialNav.clearGamepadFocus)();
      setConnected(false);
    }
  }, [enabled]);
  return {
    connected
  };
}
},
"./utils/useRatings": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.getRatingForItem = getRatingForItem;
exports.useRatings = useRatings;
var _react = require("react");
var _ageRating = require("./ageRating");
var _storage = require("./storage");
const CACHE_KEY = "ratingsCache";
const CACHE_TTL = 1000 * 60 * 60 * 24 * 7;
function readCache() {
  try {
    return _storage.storage.get(CACHE_KEY) || {};
  } catch {
    return {};
  }
}
function writeCache(cache) {
  try {
    _storage.storage.set(CACHE_KEY, cache);
  } catch {}
}
function evictStale(cache) {
  const now = Date.now();
  for (const key of Object.keys(cache)) {
    if (now - cache[key].ts > CACHE_TTL) {
      delete cache[key];
    }
  }
  return cache;
}
function useRatings(items) {
  const [ratingsMap, setRatingsMap] = (0, _react.useState)({});
  const [ageLimitSetting] = (0, _react.useState)(() => (0, _ageRating.getAgeLimitSetting)(_storage.storage));
  const [ratingCountry] = (0, _react.useState)(() => (0, _ageRating.getRatingCountry)(_storage.storage));
  const itemsKey = (0, _react.useMemo)(() => {
    if (!items?.length) return "";
    return items.map(i => `${i.media_type === "tv" ? "tv" : "movie"}_${i.id}`).sort().join(",");
  }, [items]);
  (0, _react.useEffect)(() => {
    if (!itemsKey) return;
    const cache = evictStale(readCache());
    let cacheModified = false;
    const initial = {};
    const missing = [];
    for (const item of items) {
      const type = item.media_type === "tv" ? "tv" : "movie";
      const mapKey = `${type}_${item.id}`;
      const cacheKey = `${type}_${item.id}_${ratingCountry}`;
      if (item.certification) {
        const minAge = (0, _ageRating.certToMinAge)(item.certification, ratingCountry);
        initial[mapKey] = {
          cert: item.certification,
          minAge
        };
        continue;
      }
      const entry = cache[cacheKey];
      const isValid = entry && Date.now() - entry.ts <= CACHE_TTL;
      if (isValid) {
        initial[mapKey] = {
          cert: entry.cert,
          minAge: entry.minAge
        };
      } else {
        missing.push(item);
      }
    }
    if (Object.keys(initial).length) {
      setRatingsMap(prev => ({
        ...prev,
        ...initial
      }));
    }
    if (!missing.length || ageLimitSetting === null) return;
    let cancelled = false;
    (async () => {
      for (let i = 0; i < Math.min(missing.length, 8); i++) {
        if (cancelled) break;
        const item = missing[i];
        const type = item.media_type === "tv" ? "tv" : "movie";
        const mapKey = `${type}_${item.id}`;
        const cacheKey = `${type}_${item.id}_${ratingCountry}`;
        try {
          const result = type === "tv" ? await (0, _ageRating.fetchTVRating)(item.id, null, ratingCountry) : await (0, _ageRating.fetchMovieRating)(item.id, null, ratingCountry);
          if (!cancelled) {
            cache[cacheKey] = {
              cert: result.cert,
              minAge: result.minAge,
              ts: Date.now()
            };
            cacheModified = true;
            setRatingsMap(prev => ({
              ...prev,
              [mapKey]: result
            }));
          }
        } catch {}
      }
      if (cacheModified && !cancelled) writeCache(cache);
    })();
    return () => {
      cancelled = true;
    };
  }, [itemsKey, ratingCountry, ageLimitSetting]);
  return {
    ratingsMap,
    ageLimitSetting,
    ratingCountry
  };
}
function getRatingForItem(item, ratingsMap) {
  if (!item) return {
    cert: null,
    minAge: null
  };
  const type = item.media_type === "tv" ? "tv" : "movie";
  return ratingsMap[`${type}_${item.id}`] || {
    cert: item.certification || null,
    minAge: item.certification ? (0, _ageRating.certToMinAge)(item.certification, "US") : null
  };
}
},
"./utils/useSourceId": function(module, exports, require) {
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.useSourceId = useSourceId;
var _react = require("react");
var _api = require("./api");
const LABELS = {
  imdb: "IMDb ID",
  numeric: "Provider ID",
  kinopoisk: "Kinopoisk ID"
};
function useSourceId(sourceId, type, mediaId) {
  const idType = (0, _api.sourceIdType)(sourceId);
  const strId = String(mediaId || "");
  const needsConversion = idType === "imdb" && !strId.startsWith("tt") || idType === "numeric" && strId.startsWith("tt") || idType === "kinopoisk";
  const [state, setState] = (0, _react.useState)({
    key: null,
    id: null,
    error: null
  });
  const key = needsConversion ? `${idType}:${type}:${mediaId}` : null;
  (0, _react.useEffect)(() => {
    if (!key) return;
    let cancelled = false;
    const resolve = idType === "kinopoisk" ? _api.fetchKinopoiskId : idType === "numeric" ? _api.fetchNumericId : _api.fetchImdbId;
    resolve(type, mediaId).then(id => !cancelled && setState({
      key,
      id,
      error: null
    })).catch(e => !cancelled && setState({
      key,
      id: null,
      error: e.message
    }));
    return () => {
      cancelled = true;
    };
  }, [key, idType, type, mediaId]);
  const idLabel = LABELS[idType] ?? "ID";
  if (!needsConversion) {
    return {
      id: mediaId,
      loading: false,
      error: null,
      idLabel
    };
  }
  if (state.key !== key) return {
    id: null,
    loading: true,
    error: null,
    idLabel
  };
  return {
    id: state.id,
    loading: !state.id && !state.error,
    error: state.error,
    idLabel
  };
}
}
  };

  const moduleCache = {};

  function resolvePath(fromId, req) {
    if (req === "react") return "react";
    if (req === "react-dom/client" || req === "react-dom") return "react-dom/client";
    if (req.endsWith(".css")) return "noop-css";
    if (!req.startsWith(".")) return req;
    const fromParts = fromId.split("/").slice(0, -1);
    const reqParts = req.replace(/\.(jsx|js)$/, "").split("/");
    for (const part of reqParts) {
      if (part === "." || part === "") continue;
      if (part === "..") fromParts.pop();
      else fromParts.push(part);
    }
    return "./" + fromParts.filter((p) => p !== ".").join("/");
  }

  function requireModule(fromId, req) {
    const resolved = resolvePath(fromId, req);
    if (resolved === "react") return Object.assign({ default: React }, React);
    if (resolved === "react-dom/client") return Object.assign({ default: ReactDOMClient }, ReactDOMClient);
    if (resolved === "noop-css") return {};
    if (moduleCache[resolved]) return moduleCache[resolved].exports;
    const factory = moduleFactories[resolved];
    if (!factory) {
      throw new Error("Module not found: " + resolved + " (from " + fromId + ")");
    }
    const mod = { exports: {} };
    moduleCache[resolved] = mod;
    const localRequire = (childReq) => requireModule(resolved, childReq);
    factory(mod, mod.exports, localRequire);
    return mod.exports;
  }

  requireModule("./main", "./main");
})();
