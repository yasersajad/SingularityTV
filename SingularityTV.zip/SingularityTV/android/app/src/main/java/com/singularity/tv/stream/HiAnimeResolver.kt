package com.singularity.tv.stream

import android.util.Base64
import com.singularity.tv.StreambertApp
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder
import kotlin.experimental.xor

object HiAnimeResolver {

    private const val BASE_URL = "https://hianime.at"
    private const val USER_AGENT =
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    private val OBFUSCATION_KEY = "otaku-embed-v1".toByteArray(Charsets.UTF_8)
    private const val SERVER_NAME = "ZokoAnime"

    data class StreamResult(
        val ok: Boolean,
        val url: String? = null,
        val referer: String? = null,
        val subtitle: String? = null,
        val malId: Int? = null,
        val matchedTitle: String? = null,
        val error: String? = null
    )

    private fun httpGet(url: String, referer: String? = null): String {
        val reqBuilder = Request.Builder()
            .url(url)
            .header("User-Agent", USER_AGENT)
            .header("Accept", "*/*")
            .header("Accept-Language", "en-US,en;q=0.9")
        if (!referer.isNullOrBlank()) {
            reqBuilder.header("Referer", referer)
        }
        StreambertApp.instance.okHttpClient.newCall(reqBuilder.build()).execute().use { res ->
            val body = res.body?.string() ?: ""
            if (Regex("""<title>\s*Just a moment""", RegexOption.IGNORE_CASE).containsMatchIn(body)) {
                throw IllegalStateException("Blocked by Cloudflare (HiAnime)")
            }
            if (!res.isSuccessful) {
                throw IllegalStateException("HTTP ${res.code} from $url")
            }
            return body
        }
    }

    fun deobfuscateBlob(blob: String): String {
        val decoded = Base64.decode(blob, Base64.DEFAULT)
        val out = ByteArray(decoded.size)
        for (i in decoded.indices) {
            out[i] = decoded[i] xor OBFUSCATION_KEY[i % OBFUSCATION_KEY.size]
        }
        return String(out, Charsets.UTF_8)
    }

    private fun unwrapApiHtml(raw: String): String {
        var text = raw
        try {
            val json = JSONObject(raw)
            val sb = StringBuilder()
            val keys = json.keys()
            while (keys.hasNext()) {
                val k = keys.next()
                val v = json.optString(k, "")
                if (v.isNotEmpty()) sb.append(v).append("\n")
            }
            if (sb.isNotEmpty()) text = sb.toString()
        } catch (_: Exception) {}
        return text.replace("\\\"", "\"").replace("\\/", "/").replace("\\", "")
    }

    private fun getAttr(tag: String, attr: String): String? {
        val m = Regex("""$attr="([^"]*)"""").find(tag)
        return m?.groupValues?.getOrNull(1)
    }

    private fun searchShows(query: String): List<Pair<String, String>> {
        val q = URLEncoder.encode(query, "UTF-8")
        val html = httpGet("$BASE_URL/search?keyword=$q")
        val main = html.substringBefore("""id="main-sidebar"""")
        val out = mutableListOf<Pair<String, String>>()
        val h3Regex = Regex("""<h3 class="film-name">([\s\S]*?)</h3>""")
        for (match in h3Regex.findAll(main)) {
            val inner = match.groupValues[1]
            val aMatch = Regex("""<a\s+([^>]*)>""").find(inner) ?: continue
            val attrs = aMatch.groupValues[1]
            val href = getAttr(attrs, "href") ?: continue
            val title = getAttr(attrs, "title") ?: continue
            val slug = href.substringBefore("?").trimEnd('/').substringAfterLast('/')
            if (slug.isNotEmpty()) {
                out.add(slug to title)
            }
        }
        return out
    }

    private fun fetchEpisodes(showSlug: String): List<Pair<String, String>> {
        val numericId = showSlug.substringAfterLast('-')
        if (!numericId.all { it.isDigit() }) throw IllegalArgumentException("Invalid show ID")
        val raw = httpGet("$BASE_URL/api/theme/episode/list/$numericId", "$BASE_URL/")
        val html = unwrapApiHtml(raw)
        val out = mutableListOf<Pair<String, String>>()
        for (chunk in html.split("ep-item").drop(1)) {
            val epNum = getAttr(chunk, "data-number") ?: continue
            val epId = getAttr(chunk, "data-id") ?: continue
            if (!chunk.contains("/watch/$showSlug?ep=")) continue
            out.add(epId to epNum)
        }
        return out
    }

    private fun resolveEpisodeStream(epId: String, mode: String): StreamResult {
        val raw = httpGet("$BASE_URL/api/theme/episode/servers?episodeId=$epId", "$BASE_URL/")
        val html = unwrapApiHtml(raw)
        var hash: String? = null
        for (chunk in html.split("server-item").drop(1)) {
            if (getAttr(chunk, "data-type") == mode && getAttr(chunk, "data-server-name") == SERVER_NAME) {
                hash = getAttr(chunk, "data-hash")
                if (!hash.isNullOrBlank()) break
            }
        }
        if (hash.isNullOrBlank()) {
            return StreamResult(ok = false, error = "No $SERVER_NAME server for $mode")
        }
        val embedUrl = String(Base64.decode(hash, Base64.DEFAULT), Charsets.UTF_8).trim()
        val referer = embedUrl.replace(Regex("^(https?://[^/]*).*$"), "$1/")
        val malId = Regex("""/mal/(\d+)/""").find(embedUrl)?.groupValues?.getOrNull(1)?.toIntOrNull()

        val embedHtml = httpGet(embedUrl, "$BASE_URL/")
        val blob = Regex("""window\.__P="([^"]*)"""").find(embedHtml)?.groupValues?.getOrNull(1)
            ?: return StreamResult(ok = false, error = "Embed configuration not found")

        val jsonText = deobfuscateBlob(blob)
        val m3u8Match = Regex(""""src"\s*:\s*"([^"]*\.m3u8[^"]*)"""").find(jsonText)
        val masterUrl = m3u8Match?.groupValues?.getOrNull(1)?.replace("\\/", "/")
            ?: return StreamResult(ok = false, error = "No m3u8 source found in embed config")

        var subtitleUrl: String? = null
        try {
            val cfg = JSONObject(jsonText)
            val subs = cfg.optJSONArray("subtitles")
            if (subs != null) {
                for (i in 0 until subs.length()) {
                    val item = subs.optJSONObject(i) ?: continue
                    if (item.optBoolean("default", false)) {
                        subtitleUrl = item.optString("src").takeIf { it.isNotEmpty() }
                        break
                    }
                }
            }
        } catch (_: Exception) {}

        return StreamResult(
            ok = true,
            url = masterUrl,
            referer = referer,
            subtitle = subtitleUrl,
            malId = malId
        )
    }

    fun resolve(
        title: String,
        seasonNumber: Int,
        episodeNumber: Int,
        isMovie: Boolean,
        translationType: String,
        onStage: (String) -> Unit
    ): StreamResult {
        return try {
            onStage("search")
            val candidates = listOf(
                if (seasonNumber > 1 && !isMovie) "$title Season $seasonNumber" else title,
                title
            ).distinct()

            var matchedShow: Pair<String, String>? = null
            for (cand in candidates) {
                val hits = searchShows(cand)
                if (hits.isNotEmpty()) {
                    matchedShow = hits.first()
                    break
                }
            }
            val show = matchedShow ?: return StreamResult(ok = false, error = "No results for $title")

            onStage("episodes")
            val episodes = fetchEpisodes(show.first)
            if (episodes.isEmpty()) {
                return StreamResult(ok = false, error = "No episodes found for ${show.second}")
            }
            val wanted = if (isMovie) "1" else episodeNumber.toString()
            val ep = episodes.find { it.second == wanted } ?: if (isMovie) episodes.first() else null
            if (ep == null) {
                return StreamResult(ok = false, error = "Episode $wanted not found")
            }

            onStage("stream")
            val mode = if (translationType == "dub") "dub" else "sub"
            val stream = resolveEpisodeStream(ep.first, mode)
            stream.copy(matchedTitle = show.second)
        } catch (e: Exception) {
            StreamResult(ok = false, error = e.message ?: "Resolution error")
        }
    }
}
