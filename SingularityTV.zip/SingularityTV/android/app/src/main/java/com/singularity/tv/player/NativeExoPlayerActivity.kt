package com.singularity.tv.player

import android.app.PictureInPictureParams
import android.content.Intent
import android.content.Context
import android.content.res.Configuration
import android.media.AudioManager
import android.view.MotionEvent
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.ClipDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Rational
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import com.singularity.tv.StreambertApp
import com.singularity.tv.data.PlaybackProgressEntity
import com.singularity.tv.webview.AdBlockerInterceptor
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.concurrent.thread

data class PlayerSubTrack(
    val label: String,
    val lang: String,
    val urlOrPath: String,
    val score: Int = 0
)

data class ParsedSubCue(
    val startMs: Long,
    val endMs: Long,
    val text: String
)

private class VectorIconDrawable(
    private val kind: String,
    private val tintColor: Int = Color.WHITE
) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = tintColor
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        val cx = b.centerX().toFloat()
        val cy = b.centerY().toFloat()
        val s = minOf(w, h)

        when (kind) {
            "back" -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = s * 0.09f
                val path = Path().apply {
                    moveTo(cx + s * 0.24f, cy)
                    lineTo(cx - s * 0.24f, cy)
                    moveTo(cx - s * 0.04f, cy - s * 0.2f)
                    lineTo(cx - s * 0.24f, cy)
                    lineTo(cx - s * 0.04f, cy + s * 0.2f)
                }
                canvas.drawPath(path, paint)
            }
            "play" -> {
                paint.style = Paint.Style.FILL
                val path = Path().apply {
                    moveTo(cx - s * 0.16f, cy - s * 0.24f)
                    lineTo(cx + s * 0.26f, cy)
                    lineTo(cx - s * 0.16f, cy + s * 0.24f)
                    close()
                }
                canvas.drawPath(path, paint)
            }
            "pause" -> {
                paint.style = Paint.Style.FILL
                val barW = s * 0.12f
                val barH = s * 0.44f
                val gap = s * 0.09f
                canvas.drawRoundRect(
                    RectF(cx - gap - barW, cy - barH / 2f, cx - gap, cy + barH / 2f),
                    barW * 0.35f,
                    barW * 0.35f,
                    paint
                )
                canvas.drawRoundRect(
                    RectF(cx + gap, cy - barH / 2f, cx + gap + barW, cy + barH / 2f),
                    barW * 0.35f,
                    barW * 0.35f,
                    paint
                )
            }
            "rew10", "fwd10" -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = s * 0.075f
                val r = s * 0.29f
                val oval = RectF(cx - r, cy - r, cx + r, cy + r)
                val topY = cy - r
                val aw = s * 0.11f
                val ah = s * 0.09f
                if (kind == "rew10") {
                    canvas.drawArc(oval, -90f, 275f, false, paint)
                    val arrow = Path().apply {
                        moveTo(cx + aw, topY - ah)
                        lineTo(cx - aw * 0.35f, topY)
                        lineTo(cx + aw, topY + ah)
                    }
                    canvas.drawPath(arrow, paint)
                } else {
                    canvas.drawArc(oval, -90f, -275f, false, paint)
                    val arrow = Path().apply {
                        moveTo(cx - aw, topY - ah)
                        lineTo(cx + aw * 0.35f, topY)
                        lineTo(cx - aw, topY + ah)
                    }
                    canvas.drawPath(arrow, paint)
                }
                paint.style = Paint.Style.FILL
                paint.textAlign = Paint.Align.CENTER
                paint.textSize = s * 0.23f
                paint.typeface = Typeface.DEFAULT_BOLD
                val fm = paint.fontMetrics
                val ty = cy - (fm.ascent + fm.descent) / 2f + s * 0.02f
                canvas.drawText("10", cx, ty, paint)
            }
        }
    }

    override fun setAlpha(alpha: Int) {
        paint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        paint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}


private class VerticalGestureMeterView(
    context: Context,
    private val isBrightness: Boolean
) : View(context) {
    private var level: Float = 0.5f
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(95, 255, 255, 255)
        setShadowLayer(4f, 0f, 2f, Color.argb(160, 0, 0, 0))
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = if (isBrightness) Color.rgb(250, 204, 21) else Color.rgb(229, 9, 20)
        setShadowLayer(6f, 0f, 2f, Color.argb(160, 0, 0, 0))
    }
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        setShadowLayer(5f, 0f, 2f, Color.argb(180, 0, 0, 0))
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setShadowLayer(5f, 0f, 2f, Color.argb(190, 0, 0, 0))
    }

    fun setLevel(value: Float) {
        level = value.coerceIn(0f, 1f)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f

        val iconCy = w * 0.62f
        val iconS = w * 0.46f
        if (isBrightness) {
            iconPaint.style = Paint.Style.FILL
            val coreR = iconS * (0.20f + 0.10f * level)
            canvas.drawCircle(cx, iconCy, coreR, iconPaint)
            iconPaint.style = Paint.Style.STROKE
            iconPaint.strokeWidth = w * 0.055f
            val rayInner = coreR + iconS * 0.12f
            val rayOuter = rayInner + iconS * (0.06f + 0.18f * level)
            val rotOffset = level * 45f
            for (i in 0 until 8) {
                val angle = Math.toRadians((i * 45f + rotOffset).toDouble())
                val sx = cx + (rayInner * Math.cos(angle)).toFloat()
                val sy = iconCy + (rayInner * Math.sin(angle)).toFloat()
                val ex = cx + (rayOuter * Math.cos(angle)).toFloat()
                val ey = iconCy + (rayOuter * Math.sin(angle)).toFloat()
                canvas.drawLine(sx, sy, ex, ey, iconPaint)
            }
        } else {
            iconPaint.style = Paint.Style.FILL
            val spk = Path().apply {
                moveTo(cx - iconS * 0.28f, iconCy - iconS * 0.14f)
                lineTo(cx - iconS * 0.10f, iconCy - iconS * 0.14f)
                lineTo(cx + iconS * 0.08f, iconCy - iconS * 0.30f)
                lineTo(cx + iconS * 0.08f, iconCy + iconS * 0.30f)
                lineTo(cx - iconS * 0.10f, iconCy + iconS * 0.14f)
                lineTo(cx - iconS * 0.28f, iconCy + iconS * 0.14f)
                close()
            }
            canvas.drawPath(spk, iconPaint)
            iconPaint.style = Paint.Style.STROKE
            iconPaint.strokeWidth = w * 0.055f
            if (level <= 0.01f) {
                val xOff = iconS * 0.18f
                canvas.drawLine(cx + xOff, iconCy - iconS * 0.12f, cx + xOff + iconS * 0.18f, iconCy + iconS * 0.12f, iconPaint)
                canvas.drawLine(cx + xOff + iconS * 0.18f, iconCy - iconS * 0.12f, cx + xOff, iconCy + iconS * 0.12f, iconPaint)
            } else {
                val waves = if (level > 0.66f) 3 else if (level > 0.33f) 2 else 1
                for (i in 1..waves) {
                    val wr = iconS * (0.14f * i)
                    val oval = RectF(cx + iconS * 0.05f - wr * 0.3f, iconCy - wr, cx + iconS * 0.05f + wr, iconCy + wr)
                    canvas.drawArc(oval, -45f, 90f, false, iconPaint)
                }
            }
        }

        val barW = w * 0.18f
        val barTop = iconCy + iconS * 0.72f
        val barBottom = h - w * 0.68f
        val barLeft = cx - barW / 2f
        val barRight = cx + barW / 2f
        val barRadius = barW / 2f
        canvas.drawRoundRect(RectF(barLeft, barTop, barRight, barBottom), barRadius, barRadius, trackPaint)

        val fillH = (barBottom - barTop) * level
        if (fillH > 1f) {
            canvas.drawRoundRect(
                RectF(barLeft, barBottom - fillH, barRight, barBottom),
                barRadius,
                barRadius,
                fillPaint
            )
        }

        textPaint.textSize = w * 0.24f
        canvas.drawText("${(level * 100).toInt()}%", cx, h - w * 0.24f, textPaint)
    }
}

class NativeExoPlayerActivity : AppCompatActivity() {

    private var exoPlayer: ExoPlayer? = null
    private var playerView: PlayerView? = null
    private var resolverWebView: WebView? = null
    private var captchaCardContainer: LinearLayout? = null
    private var captchaCursorView: View? = null
    private var isCaptchaCardVisible: Boolean = false
    private var isCaptchaDragMode: Boolean = false
    private var captchaDragDownTime: Long = 0L
    private var captchaTitleTv: TextView? = null
    private var captchaCursorX: Float = 0.5f
    private var captchaCursorY: Float = 0.5f
    private var rootFrameLayout: FrameLayout? = null
    private var activeResolverEmbedUrl: String = ""
    private var controllerOverlay: FrameLayout? = null
    private var subBtn: Button? = null
    private var titleView: TextView? = null
    private var serverBadgeView: TextView? = null
    private var switchServerBtn: Button? = null
    private val verifiedServers = java.util.concurrent.ConcurrentHashMap<String, Pair<String, String>>()
    private val probedFailedServers = java.util.Collections.synchronizedSet(HashSet<String>())
    private val probeQueue = java.util.ArrayDeque<String>()
    private val probeWebViews = mutableListOf<WebView>()
    private val probeSlotSources = mutableMapOf<WebView, String>()
    private val probeTimeoutRunnables = mutableMapOf<WebView, Runnable>()
    private var isProbingActive: Boolean = false
    private var subtitleOverlayView: TextView? = null
    private var playPauseBtn: ImageButton? = null
    private var seekBar: SeekBar? = null
    private var durationView: TextView? = null
    private var currentPosView: TextView? = null
    private var isScrubbing: Boolean = false
    private var isControllerVisible: Boolean = true
    private var brightnessMeter: VerticalGestureMeterView? = null
    private var volumeMeter: VerticalGestureMeterView? = null
    private var leftSeekBadge: TextView? = null
    private var rightSeekBadge: TextView? = null
    private var currentBrightness: Float = 0.65f
    private var accumSeekLeftSec: Int = 0
    private var accumSeekRightSec: Int = 0
    private var gestureActiveMode: Int = 0
    private var gestureDownTimeMs: Long = 0L
    private var gestureStartX: Float = 0f
    private var gestureStartY: Float = 0f
    private var gestureStartVal: Float = 0f
    private var lastTapTimeMs: Long = 0L
    private var lastTapSide: Int = 0
    private var activeSeekSide: Int = 0
    private var lastSeekEventTimeMs: Long = 0L
    private var audioManager: AudioManager? = null

    private var streamUrl: String = ""
    private var streamTitle: String = "SingularityTV"
    private var progressKey: String? = null
    private var startTimeSec: Long = 0L
    private var currentSpeed: Float = 1.0f
    private var retryCount: Int = 0
    private var serverFailoverAttempts: Int = 0
    private var isSwitchingServer: Boolean = false
    private var currentSource: String = "vidlink"
    private var rawPayload: JSONObject = JSONObject()

    private var imdbId: String = ""
    private var mediaType: String = "movie"
    private var seasonNum: Int = 1
    private var episodeNum: Int = 1
    private var preferredLang: String = "ar"
    private var activeQualityTag: String = ""

    private val availableSubs = CopyOnWriteArrayList<PlayerSubTrack>()
    private val activeParsedCues = CopyOnWriteArrayList<ParsedSubCue>()
    private var activeSubIndex: Int = -1
    private var subDelayMs: Long = 0L
    private var subTextSizeSp: Float = 22f
    private var subTextColorHex: String = "#FFFFFF"
    private var subBgStyleMode: String = "dark"

    private val mainHandler = Handler(Looper.getMainLooper())

    private val hideMetersRunnable = Runnable {
        brightnessMeter?.let { m ->
            m.animate().cancel()
            if (m.visibility == View.VISIBLE) {
                m.animate().alpha(0f).setDuration(200).withEndAction {
                    m.visibility = View.GONE
                }.start()
            }
        }
        volumeMeter?.let { m ->
            m.animate().cancel()
            if (m.visibility == View.VISIBLE) {
                m.animate().alpha(0f).setDuration(200).withEndAction {
                    m.visibility = View.GONE
                }.start()
            }
        }
    }

    private val singleTapToggleRunnable = Runnable {
        if (isControllerVisible) {
            setControllerVisible(false)
        } else {
            showControllerTemporarily()
        }
    }

    private val hideLeftSeekRunnable = Runnable {
        accumSeekLeftSec = 0
        if (activeSeekSide == -1) activeSeekSide = 0
        leftSeekBadge?.let { b ->
            b.animate().cancel()
            b.animate().alpha(0f).scaleX(0.88f).scaleY(0.88f).setDuration(180).withEndAction {
                b.visibility = View.GONE
                b.alpha = 0f
            }.start()
        }
    }

    private val hideRightSeekRunnable = Runnable {
        accumSeekRightSec = 0
        if (activeSeekSide == 1) activeSeekSide = 0
        rightSeekBadge?.let { b ->
            b.animate().cancel()
            b.animate().alpha(0f).scaleX(0.88f).scaleY(0.88f).setDuration(180).withEndAction {
                b.visibility = View.GONE
                b.alpha = 0f
            }.start()
        }
    }

    private val serverOrder = listOf(
        "vidlink", "videasy", "vidsrccc", "vidsrcxyz", "vidsrcme",
        "vidsrcnet", "vidsrcin", "vidsrcpm", "vidsrc", "vidsrcicu",
        "vidfast", "vidnest", "vidlove", "autoembed", "embedsu",
        "smashy", "multiembed", "superembed", "rivestream", "moviesapi", "nontongo"
    )
    private var pendingNextSource: String = ""

    private val recentlyUpdatedSources = setOf(
        "rivestream", "vidsrcxyz", "vidsrcme", "vidsrcin",
        "vidsrcpm", "vidsrcicu", "moviesapi", "nontongo"
    )
    private val serverCatalogVersion = "v274"

    private fun serverStatusKey(sourceId: String): String {
        val pk = progressKey ?: (if (imdbId.isNotEmpty()) imdbId else streamTitle)
        return "srv_status_${pk}_$sourceId"
    }

    private fun recordServerStatus(sourceId: String, status: String) {
        if (sourceId.isBlank()) return
        try {
            val prefs = getSharedPreferences("singularity_server_status", Context.MODE_PRIVATE)
            prefs.edit()
                .putString(serverStatusKey(sourceId), status)
                .putString(serverStatusKey(sourceId) + "_ver", serverCatalogVersion)
                .apply()
        } catch (_: Throwable) {}
    }

    private fun getServerStatus(sourceId: String): String {
        return try {
            val prefs = getSharedPreferences("singularity_server_status", Context.MODE_PRIVATE)
            val st = prefs.getString(serverStatusKey(sourceId), "unknown") ?: "unknown"
            val ver = prefs.getString(serverStatusKey(sourceId) + "_ver", "") ?: ""
            when (st) {
                "working" -> "working"
                "failed" -> if (ver != serverCatalogVersion) { if (recentlyUpdatedSources.contains(sourceId)) "updated" else "unknown" } else "failed"
                else -> if (recentlyUpdatedSources.contains(sourceId)) "updated" else "unknown"
            }
        } catch (_: Throwable) {
            if (recentlyUpdatedSources.contains(sourceId)) "updated" else "unknown"
        }
    }

    private fun startResolvingInitialSource() {
        isSwitchingServer = true
        serverFailoverAttempts = 0
        pendingNextSource = currentSource
        serverBadgeView?.text = currentSource
        Toast.makeText(this, "Connecting to $currentSource...", Toast.LENGTH_SHORT).show()
        val embedUrl = buildEmbedUrlForSource(currentSource)
        activeResolverEmbedUrl = embedUrl
        mainHandler.removeCallbacks(failoverWatchdogRunnable)
        mainHandler.postDelayed(failoverWatchdogRunnable, 7500L)
        if (embedUrl.isNotEmpty() && resolverWebView != null) {
            try {
                val parsed = Uri.parse(embedUrl)
                val originRef = "${parsed.scheme}://${parsed.host}/"
                resolverWebView?.stopLoading()
                resolverWebView?.loadUrl(embedUrl, mapOf("Referer" to originRef))
            } catch (_: Throwable) {}
        }
    }

    private fun showCaptchaCard(sourceId: String) {
        val root = rootFrameLayout ?: return
        val wv = resolverWebView ?: return
        isCaptchaCardVisible = true
        mainHandler.removeCallbacks(failoverWatchdogRunnable)
        if (captchaCardContainer == null) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(12))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(16).toFloat()
                    setColor(Color.argb(245, 16, 20, 30))
                    setStroke(dp(1), Color.argb(55, 255, 255, 255))
                }
                layoutParams = FrameLayout.LayoutParams(dp(380), dp(340), Gravity.CENTER)
            }
            val hdr = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(4), 0, dp(4), dp(8))
            }
            val titleTv = TextView(this).apply {
                text = "Verify $sourceId · Hold OK to Slide"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                typeface = Typeface.DEFAULT_BOLD
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            captchaTitleTv = titleTv
            val skipBtn = Button(this).apply {
                text = "Skip ✕"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(10).toFloat()
                    setColor(Color.argb(45, 255, 255, 255))
                }
                setOnClickListener {
                    hideCaptchaCard()
                    recordServerStatus(sourceId, "failed")
                    isSwitchingServer = false
                    currentSource = sourceId
                    triggerNextServerFailover()
                }
            }
            hdr.addView(titleTv)
            hdr.addView(skipBtn)
            card.addView(hdr)

            val wvWrap = FrameLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            }
            val cursor = View(this).apply {
                layoutParams = FrameLayout.LayoutParams(dp(18), dp(18))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.argb(210, 229, 9, 20))
                    setStroke(dp(2), Color.WHITE)
                }
            }
            captchaCursorView = cursor
            card.addView(wvWrap)
            captchaCardContainer = card
            root.addView(card)
            wvWrap.addView(cursor)
        }
        val card = captchaCardContainer ?: return
        val wvWrap = card.getChildAt(1) as? FrameLayout ?: return
        (wv.parent as? ViewGroup)?.removeView(wv)
        wv.layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        wv.alpha = 1f
        wv.isClickable = true
        wv.isFocusable = true
        wvWrap.addView(wv, 0)
        card.visibility = View.VISIBLE
        card.bringToFront()
        updateCaptchaCursorPosition(wvWrap)
    }

    private fun updateCaptchaCursorPosition(wrap: FrameLayout) {
        val cursor = captchaCursorView ?: return
        val w = (wrap.width - dp(18)).coerceAtLeast(1)
        val h = (wrap.height - dp(18)).coerceAtLeast(1)
        cursor.translationX = captchaCursorX * w
        cursor.translationY = captchaCursorY * h
    }

    private fun hideCaptchaCard() {
        if (!isCaptchaCardVisible) return
        isCaptchaCardVisible = false
        isCaptchaDragMode = false
        captchaCardContainer?.visibility = View.GONE
        val root = rootFrameLayout ?: return
        val wv = resolverWebView ?: return
        (wv.parent as? ViewGroup)?.removeView(wv)
        wv.layoutParams = FrameLayout.LayoutParams(dp(200), dp(120), Gravity.BOTTOM or Gravity.START)
        wv.alpha = 0.01f
        wv.isClickable = false
        wv.isFocusable = false
        root.addView(wv, 0)
    }

    private fun resolveTmdbIdIfNeeded() {
        if (tmdbId.isNotEmpty() || !imdbId.startsWith("tt")) return
        thread(start = true) {
            try {
                val prop = if (mediaType.equals("tv", ignoreCase = true)) "P4983" else "P4947"
                val sparql = "SELECT ?tid WHERE { ?item wdt:P345 \"$imdbId\" . ?item wdt:$prop ?tid . } LIMIT 1"
                val req = Request.Builder()
                    .url("https://query.wikidata.org/sparql?format=json&query=" + URLEncoder.encode(sparql, "UTF-8"))
                    .header("Accept", "application/sparql-results+json")
                    .build()
                StreambertApp.instance.okHttpClient.newCall(req).execute().use { res ->
                    if (res.isSuccessful) {
                        val root = JSONObject(res.body?.string() ?: "{}")
                        val bindings = root.optJSONObject("results")?.optJSONArray("bindings")
                        val valStr = bindings?.optJSONObject(0)?.optJSONObject("tid")?.optString("value", "") ?: ""
                        if (valStr.isNotEmpty()) {
                            tmdbId = valStr
                        }
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    private fun buildEmbedUrlForSource(sourceId: String): String {
        val im = imdbId.ifEmpty { rawPayload.optString("imdbId", "") }.trim()
        val tm = tmdbId.ifEmpty { im }.trim()
        if (im.isEmpty() && tm.isEmpty()) return ""
        val isTv = mediaType.equals("tv", ignoreCase = true)
        val s = seasonNum.coerceAtLeast(1)
        val e = episodeNum.coerceAtLeast(1)
        return when (sourceId) {
            "vidsrcmeru" -> if (isTv) "https://vidsrcme.ru/embed/tv?imdb=$im&season=$s&episode=$e&autoplay=1" else "https://vidsrcme.ru/embed/movie?imdb=$im&autoplay=1"
            "vidsrcto" -> if (isTv) "https://vidsrc.to/embed/tv/$im/$s/$e" else "https://vidsrc.to/embed/movie/$im"
            "vidlink" -> if (isTv) "https://vidlink.pro/tv/$tm/$s/$e?autoplay=true" else "https://vidlink.pro/movie/$tm?autoplay=true"
            "videasy" -> if (isTv) "https://player.videasy.net/tv/$tm/$s/$e" else "https://player.videasy.net/movie/$tm"
            "vidsrccc" -> if (isTv) "https://vidsrc.cc/v2/embed/tv/$tm/$s/$e?autoPlay=true" else "https://vidsrc.cc/v2/embed/movie/$tm?autoPlay=true"
            "vidsrcxyz" -> if (isTv) "https://vidsrc.xyz/embed/tv/$im/$s-$e" else "https://vidsrc.xyz/embed/movie/$im"
            "vidsrcnet" -> if (isTv) "https://vidsrc.net/embed/tv/$im/$s-$e?autoplay=1" else "https://vidsrc.net/embed/movie/$im?autoplay=1"
            "vidsrcin" -> if (isTv) "https://vidsrc.in/embed/tv/$im/$s-$e" else "https://vidsrc.in/embed/movie/$im"
            "vidsrc" -> if (isTv) "https://vsembed.su/embed/tv/$im/$s/$e?autoplay=1" else "https://vsembed.su/embed/movie/$im?autoplay=1"
            "vidsrcicu" -> if (isTv) "https://vidsrc.icu/embed/tv/$im/$s/$e" else "https://vidsrc.icu/embed/movie/$im"
            "vidfast" -> if (isTv) "https://vidfast.pro/tv/$tm/$s/$e?autoPlay=true" else "https://vidfast.pro/movie/$tm?autoPlay=true"
            "vidnest" -> if (isTv) "https://vidnest.fun/tv/$tm/$s/$e" else "https://vidnest.fun/movie/$tm"
            "autoembed" -> if (isTv) "https://player.autoembed.cc/embed/tv/$tm/$s/$e?server=1" else "https://player.autoembed.cc/embed/movie/$tm?server=1"
            "embedsu" -> if (isTv) "https://embed.su/embed/tv/$tm/$s/$e" else "https://embed.su/embed/movie/$tm"
            "smashy" -> if (isTv) "https://player.smashy.stream/tv/$im?s=$s&e=$e" else "https://player.smashy.stream/movie/$im"
            "multiembed" -> if (isTv) "https://multiembed.mov/?video_id=$im&s=$s&e=$e" else "https://multiembed.mov/?video_id=$im"
            "superembed" -> if (isTv) "https://multiembed.mov/directstream.php?video_id=$im&s=$s&e=$e" else "https://multiembed.mov/directstream.php?video_id=$im"
            "rivestream" -> if (isTv) "https://rivestream.org/embed?type=tv&id=$tm&season=$s&episode=$e" else "https://rivestream.org/embed?type=movie&id=$tm"
            "moviesapi" -> if (isTv) "https://moviesapi.club/tv/$tm-$s-$e" else "https://moviesapi.club/movie/$tm"
            else -> if (isTv) "https://vidsrcme.ru/embed/tv?imdb=$im&season=$s&episode=$e" else "https://vidsrcme.ru/embed/movie?imdb=$im"
        }
    }

    private fun getDefaultRefererForSource(sourceId: String): String {
        val u = buildEmbedUrlForSource(sourceId)
        if (u.startsWith("http")) {
            try {
                val parsed = Uri.parse(u)
                return "${parsed.scheme}://${parsed.host}/"
            } catch (_: Throwable) {}
        }
        return "https://vidlink.pro/"
    }

    private val playbackReadyWatchdogRunnable = Runnable {
        val p = exoPlayer
        if (!isFinishing && !isDestroyed && p != null && p.playbackState != Player.STATE_READY && !streamUrl.startsWith("/")) {
            isSwitchingServer = false
            triggerNextServerFailover()
        }
    }

    private val failoverWatchdogRunnable = Runnable {
        if (isSwitchingServer && !isFinishing && !isDestroyed) {
            isSwitchingServer = false
            if (pendingNextSource.isNotEmpty()) {
                currentSource = pendingNextSource
            }
            triggerNextServerFailover()
        }
    }

    private fun applyResolvedStream(newUrl: String, newSource: String, refererFallback: String) {
        if (isFinishing || isDestroyed || newUrl.isBlank()) return
        if (newUrl == streamUrl && exoPlayer?.playbackState == Player.STATE_READY) return
        mainHandler.removeCallbacks(failoverWatchdogRunnable)
        mainHandler.removeCallbacks(playbackReadyWatchdogRunnable)
        isSwitchingServer = false
        hideCaptchaCard()
        try {
            resolverWebView?.loadUrl("about:blank")
        } catch (_: Throwable) {}
        val curPosSec = ((exoPlayer?.currentPosition ?: 0L) / 1000L).coerceAtLeast(startTimeSec)
        streamUrl = newUrl
        currentSource = newSource
        startTimeSec = curPosSec
        retryCount = 0
        rawPayload.put("url", newUrl)
        rawPayload.put("currentSource", newSource)
        if (refererFallback.isNotEmpty()) {
            rawPayload.put("referer", refererFallback)
        }
        initializeExoPlayer(rawPayload)
    }

    private fun updateSwitchServerButtonText() {
        val readyCount = verifiedServers.keys.count { it != currentSource }
        switchServerBtn?.text = if (readyCount > 0) "Switch Server ($readyCount)" else "Switch Server"
    }

    private fun bestVerifiedServer(excluding: String): Triple<String, String, String>? {
        val curIdx = serverOrder.indexOf(excluding)
        data class Cand(val idx: Int, val src: String, val url: String, val ref: String, val isHls: Boolean)
        val cands = mutableListOf<Cand>()
        for ((src, pair) in verifiedServers) {
            if (src == excluding) continue
            val idx = serverOrder.indexOf(src).let { if (it >= 0) it else 999 }
            val l = pair.first.lowercase()
            val isHls = l.contains(".m3u8") || l.contains(".mpd")
            cands.add(Cand(idx, src, pair.first, pair.second, isHls))
        }
        if (cands.isEmpty()) return null
        cands.sortWith(Comparator { a, b ->
            if (a.isHls != b.isHls) return@Comparator if (a.isHls) -1 else 1
            val aAfter = if (a.idx > curIdx) 0 else 1
            val bAfter = if (b.idx > curIdx) 0 else 1
            if (aAfter != bAfter) return@Comparator aAfter - bAfter
            a.idx - b.idx
        })
        val pick = cands[0]
        return Triple(pick.src, pick.url, pick.ref)
    }

    private fun handleSwitchServer() {
        showControllerTemporarily()
        val best = bestVerifiedServer(currentSource)
        if (best != null) {
            Toast.makeText(this, "Switched to ${best.first}", Toast.LENGTH_SHORT).show()
            applyResolvedStream(best.second, best.first, best.third)
            updateSwitchServerButtonText()
            return
        }
        Toast.makeText(this, "Scanning servers...", Toast.LENGTH_SHORT).show()
        isSwitchingServer = false
        triggerNextServerFailover()
    }

    private fun startBackgroundServerProbing() {
        if (isProbingActive || isFinishing || isDestroyed || streamUrl.startsWith("/")) return
        val root = rootFrameLayout ?: return
        isProbingActive = true
        probeQueue.clear()
        for (src in serverOrder) {
            if (src != currentSource && !probedFailedServers.contains(src) && !verifiedServers.containsKey(src)) {
                probeQueue.addLast(src)
            }
        }
        if (probeQueue.isEmpty()) return
        val slotCount = minOf(2, probeQueue.size)
        for (i in 0 until slotCount) {
            val pwv = WebView(this).apply {
                layoutParams = FrameLayout.LayoutParams(1, 1, Gravity.BOTTOM or Gravity.START)
                alpha = 0.01f
                isClickable = false
                isFocusable = false
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    mediaPlaybackRequiresUserGesture = true
                    loadsImagesAutomatically = false
                    userAgentString = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
                }
                try {
                    CookieManager.getInstance().setAcceptCookie(true)
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                } catch (_: Throwable) {}
                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                        val u = request?.url?.toString() ?: return null
                        val lower = u.lowercase()
                        val isBadClip = listOf("promo", "teaser", "preroll", "ad_", "/ads/", "banner", "adult", "xxx", "porn", "sex", "nsfw", "trailer", "preview", "bumper").any { lower.contains(it) }
                        val isVideo = !isBadClip && (lower.contains(".m3u8") || lower.contains(".mpd") || lower.contains("master.txt") || lower.contains("playlist.txt") || lower.contains("/hls/") || (lower.contains(".mp4") && !lower.contains("favicon") && !lower.contains("preview") && !lower.contains("trailer") && !lower.contains("logo") && !lower.contains("preroll") && !lower.contains("blank")))
                        if (isVideo) {
                            val hdrs = HashMap<String, String>(request.requestHeaders ?: emptyMap())
                            AdBlockerInterceptor.streamHeadersMap[u] = hdrs
                            mainHandler.post {
                                val src = probeSlotSources[this@apply] ?: return@post
                                val ref = getDefaultRefererForSource(src)
                                verifiedServers[src] = Pair(u, ref)
                                updateSwitchServerButtonText()
                                if (isSwitchingServer && streamUrl.isBlank()) {
                                    applyResolvedStream(u, src, ref)
                                }
                                advanceProbeSlot(this@apply)
                            }
                        } else if (AdBlockerInterceptor.isBlockedUrl(u)) {
                            return AdBlockerInterceptor.createEmptyResponse()
                        }
                        return super.shouldInterceptRequest(view, request)
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        super.onPageFinished(view, url)
                        if (view == null || url == null || url.startsWith("about:")) return
                        val probeJs = "(function(){try{var t=(document.title||'')+' '+(document.body?document.body.innerText.slice(0,500):'');var l=t.toLowerCase();if(l.indexOf('no sources')!==-1||l.indexOf('try again later')!==-1||l.indexOf('404 not found')!==-1||l.indexOf('502 bad gateway')!==-1||l.indexOf('media not found')!==-1||l.indexOf('video not found')!==-1||l.indexOf('not available')!==-1){return 'DEAD';}if(l.indexOf('just a moment')!==-1||l.indexOf('verify you are human')!==-1||l.indexOf('security check')!==-1||!!document.querySelector('iframe[src*=turnstile],iframe[src*=challenge],iframe[src*=captcha],.cf-turnstile,.g-recaptcha,.h-captcha')){return 'CHALLENGE';}document.querySelectorAll('video').forEach(function(v){v.muted=true;try{v.pause();}catch(e){}});document.querySelectorAll('#pl_but,.play,.btn-play,[class*=play],button').forEach(function(b){try{b.click();}catch(e){}});}catch(e){}return '';})()"
                        view.evaluateJavascript(probeJs) { res ->
                            if (res != null && res.contains("DEAD")) {
                                val src = probeSlotSources[view]
                                if (src != null) probedFailedServers.add(src)
                                advanceProbeSlot(view)
                            } else if (res != null && res.contains("CHALLENGE")) {
                                advanceProbeSlot(view)
                            }
                        }
                    }
                }
            }
            probeWebViews.add(pwv)
            root.addView(pwv, 0)
            advanceProbeSlot(pwv)
        }
    }

    private fun advanceProbeSlot(pwv: WebView) {
        probeTimeoutRunnables.remove(pwv)?.let { mainHandler.removeCallbacks(it) }
        probeSlotSources.remove(pwv)
        try { pwv.stopLoading() } catch (_: Throwable) {}
        while (probeQueue.isNotEmpty() && !isFinishing && !isDestroyed) {
            val nextSrc = probeQueue.removeFirst()
            if (nextSrc == currentSource || probedFailedServers.contains(nextSrc) || verifiedServers.containsKey(nextSrc)) continue
            val embed = buildEmbedUrlForSource(nextSrc)
            if (embed.isEmpty()) continue
            probeSlotSources[pwv] = nextSrc
            try {
                val parsed = Uri.parse(embed)
                val originRef = "${parsed.scheme}://${parsed.host}/"
                pwv.loadUrl(embed, mapOf("Referer" to originRef))
            } catch (_: Throwable) {
                probedFailedServers.add(nextSrc)
                continue
            }
            val timeoutRun = Runnable {
                val failedSrc = probeSlotSources[pwv]
                if (failedSrc != null) probedFailedServers.add(failedSrc)
                advanceProbeSlot(pwv)
            }
            probeTimeoutRunnables[pwv] = timeoutRun
            mainHandler.postDelayed(timeoutRun, 6500L)
            return
        }
        try { pwv.loadUrl("about:blank") } catch (_: Throwable) {}
    }

    private fun stopBackgroundServerProbing() {
        isProbingActive = false
        probeQueue.clear()
        for (r in probeTimeoutRunnables.values) mainHandler.removeCallbacks(r)
        probeTimeoutRunnables.clear()
        probeSlotSources.clear()
        for (pwv in probeWebViews) {
            try {
                pwv.stopLoading()
                (pwv.parent as? ViewGroup)?.removeView(pwv)
                pwv.destroy()
            } catch (_: Throwable) {}
        }
        probeWebViews.clear()
    }

    private fun triggerNextServerFailover() {
        if (isFinishing || isDestroyed || streamUrl.startsWith("/") || isSwitchingServer) return
        val best = bestVerifiedServer(currentSource)
        if (best != null) {
            applyResolvedStream(best.second, best.first, best.third)
            updateSwitchServerButtonText()
            return
        }
        if (serverFailoverAttempts >= serverOrder.size) {
            Toast.makeText(
                this@NativeExoPlayerActivity,
                "All servers tried — tap Switch Server to retry",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        isSwitchingServer = true
        serverFailoverAttempts++
        val resumeSec = ((exoPlayer?.currentPosition ?: 0L) / 1000L).coerceAtLeast(startTimeSec)
        startTimeSec = resumeSec
        val idx = serverOrder.indexOf(currentSource)
        var nextExpected = serverOrder[(idx + 1) % serverOrder.size]
        for (step in 1..serverOrder.size) {
            val cand = serverOrder[(idx + step) % serverOrder.size]
            if (!probedFailedServers.contains(cand)) {
                nextExpected = cand
                break
            }
        }
        pendingNextSource = nextExpected
        serverBadgeView?.text = nextExpected
        val embedUrl = buildEmbedUrlForSource(nextExpected)
        activeResolverEmbedUrl = embedUrl
        Toast.makeText(
            this@NativeExoPlayerActivity,
            "Switching to $nextExpected...",
            Toast.LENGTH_SHORT
        ).show()
        mainHandler.removeCallbacks(failoverWatchdogRunnable)
        mainHandler.removeCallbacks(playbackReadyWatchdogRunnable)
        mainHandler.postDelayed(failoverWatchdogRunnable, 7500L)

        if (embedUrl.isNotEmpty() && resolverWebView != null) {
            try {
                val parsed = Uri.parse(embedUrl)
                val originRef = "${parsed.scheme}://${parsed.host}/"
                resolverWebView?.stopLoading()
                resolverWebView?.loadUrl(embedUrl, mapOf("Referer" to originRef))
            } catch (_: Throwable) {}
        }

        val requestedFrom = currentSource
        onNeedNextServer?.invoke(requestedFrom, resumeSec) { newUrl, newSource ->
            runOnUiThread {
                if (!newUrl.isNullOrEmpty() && isSwitchingServer) {
                    applyResolvedStream(
                        newUrl,
                        if (!newSource.isNullOrEmpty()) newSource else nextExpected,
                        getDefaultRefererForSource(nextExpected)
                    )
                }
            }
        }
    }

    private val hideControllerRunnable = Runnable {
        if (exoPlayer?.isPlaying == true && !isScrubbing) {
            setControllerVisible(false)
        }
    }

    private val progressRunnable = object : Runnable {
        override fun run() {
            saveCurrentProgress()
            mainHandler.postDelayed(this, 5000L)
        }
    }

    private val uiTickRunnable = object : Runnable {
        override fun run() {
            updateTimeAndSeekBar()
            mainHandler.postDelayed(this, 250L)
        }
    }

    private val subtitleTickRunnable = object : Runnable {
        override fun run() {
            updateLiveSubtitleOverlay()
            mainHandler.postDelayed(this, 120L)
        }
    }

    private fun dp(v: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            v.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                window.decorView.defaultFocusHighlightEnabled = false
            }

            val root = FrameLayout(this).apply {
                clipChildren = false
                clipToPadding = false
                setBackgroundColor(Color.BLACK)
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    defaultFocusHighlightEnabled = false
                }
            }

            val pv = PlayerView(this).apply {
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                useController = false
                keepScreenOn = true
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    defaultFocusHighlightEnabled = false
                }

            }
            val resWv = WebView(this).apply {
                layoutParams = FrameLayout.LayoutParams(dp(200), dp(120), Gravity.BOTTOM or Gravity.START)
                alpha = 0.01f
                isClickable = false
                isFocusable = false
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    mediaPlaybackRequiresUserGesture = true
                    loadsImagesAutomatically = false
                    userAgentString = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
                }
                try {
                    CookieManager.getInstance().setAcceptCookie(true)
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                } catch (_: Throwable) {}
                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(
                        view: WebView?,
                        request: WebResourceRequest?
                    ): WebResourceResponse? {
                        val u = request?.url?.toString() ?: return null
                        val lower = u.lowercase()
                        val isChallenge = lower.contains("challenges.cloudflare.com") || lower.contains("recaptcha/api") || lower.contains("hcaptcha.com/1/api") || lower.contains("turnstile/v0/api") || lower.contains("arkoselabs.com")
                        if (isChallenge) {
                            mainHandler.post {
                                if (isSwitchingServer) {
                                    mainHandler.removeCallbacks(failoverWatchdogRunnable)
                                    if (!isCaptchaCardVisible) {
                                        showCaptchaCard(pendingNextSource.ifEmpty { currentSource })
                                    }
                                }
                            }
                            return super.shouldInterceptRequest(view, request)
                        }
                        val isBadClip = listOf("promo", "teaser", "preroll", "ad_", "/ads/", "banner", "adult", "xxx", "porn", "sex", "nsfw", "trailer", "preview", "bumper").any { lower.contains(it) }
                        val isVideo = !isBadClip && (lower.contains(".m3u8") || lower.contains(".mpd") || lower.contains("master.txt") || lower.contains("playlist.txt") || lower.contains("/hls/") || (lower.contains(".mp4") && !lower.contains("favicon") && !lower.contains("preview") && !lower.contains("trailer") && !lower.contains("logo") && !lower.contains("preroll") && !lower.contains("blank")))
                        if (isVideo) {
                            val hdrs = HashMap<String, String>(request.requestHeaders ?: emptyMap())
                            val hasRef = hdrs.keys.any { it.equals("referer", ignoreCase = true) }
                            if (!hasRef && activeResolverEmbedUrl.isNotEmpty()) {
                                hdrs["Referer"] = activeResolverEmbedUrl
                            }
                            AdBlockerInterceptor.streamHeadersMap[u] = hdrs
                            val srcTag = pendingNextSource.ifEmpty { currentSource }
                            val refUrl = activeResolverEmbedUrl
                            mainHandler.post {
                                applyResolvedStream(u, srcTag, refUrl)
                            }
                        } else if (AdBlockerInterceptor.isBlockedUrl(u)) {
                            return AdBlockerInterceptor.createEmptyResponse()
                        }
                        return super.shouldInterceptRequest(view, request)
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        super.onPageFinished(view, url)
                        if (view == null || url == null || url.startsWith("about:")) return
                        val clickJs = "(function(){try{var t=(document.title||'')+' '+(document.body?document.body.innerText.slice(0,500):'');var l=t.toLowerCase();if(l.indexOf('no sources')!==-1||l.indexOf('try again later')!==-1||l.indexOf('404 not found')!==-1||l.indexOf('502 bad gateway')!==-1||l.indexOf('media not found')!==-1||l.indexOf('video not found')!==-1||l.indexOf('not available')!==-1){return 'DEAD';}var w=!!document.querySelector('iframe[src*=challenges\\.cloudflare\\.com],iframe[src*=turnstile],iframe[src*=challenge],iframe[src*=captcha],iframe[src*=recaptcha],iframe[src*=hcaptcha],.cf-turnstile,.g-recaptcha,.h-captcha,#cf-turnstile-response,#cf-challenge-running,[id*=turnstile],[class*=turnstile],[class*=geetest]');if(w||l.indexOf('just a moment')!==-1||l.indexOf('verify you are human')!==-1||l.indexOf('security check')!==-1||l.indexOf('are you a robot')!==-1){return 'CHALLENGE';}var clickAll=function(){document.querySelectorAll('video').forEach(function(v){v.muted=true;try{v.play();}catch(e){}});document.querySelectorAll('#pl_but,.play,.btn-play,[class*=play],button').forEach(function(b){try{b.click();}catch(e){}});};clickAll();setTimeout(clickAll,700);setTimeout(clickAll,1600);}catch(e){}return '';})()"
                        view.evaluateJavascript(clickJs) { res ->
                            if (res != null && res.contains("CHALLENGE") && isSwitchingServer && !isCaptchaCardVisible) {
                                mainHandler.removeCallbacks(failoverWatchdogRunnable)
                                showCaptchaCard(pendingNextSource.ifEmpty { currentSource })
                            } else if (res != null && res.contains("DEAD") && isSwitchingServer) {
                                mainHandler.removeCallbacks(failoverWatchdogRunnable)
                                failoverWatchdogRunnable.run()
                            }
                        }
                    }
                }
            }
            rootFrameLayout = root
            resolverWebView = resWv
            root.addView(resWv)

            playerView = pv
            applySubtitleStyle()
            root.addView(pv)

            val subOverlay = TextView(this).apply {
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, subTextSizeSp)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(28, 12, 28, 12)
                setShadowLayer(6f, 0f, 2f, Color.BLACK)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 14f
                    setColor(Color.argb(190, 0, 0, 0))
                }
                visibility = View.GONE
                val lp = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                )
                lp.setMargins(48, 0, 48, dp(32))
                layoutParams = lp
            }
            subtitleOverlayView = subOverlay
            root.addView(subOverlay)

            val overlay = FrameLayout(this).apply {
                clipChildren = false
                clipToPadding = false
                isClickable = false
                isFocusable = false
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            }
            controllerOverlay = overlay

            val topBar = LinearLayout(this).apply {
                clipChildren = false
                clipToPadding = false
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(28), dp(22), dp(28), dp(28))
                background = GradientDrawable(
                    GradientDrawable.Orientation.TOP_BOTTOM,
                    intArrayOf(Color.argb(150, 0, 0, 0), Color.TRANSPARENT)
                )
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP
                )
            }

            val backBtn = makeCircleVectorButton("back", 44) {
                saveCurrentProgress()
                finish()
            }

            val tvTitle = TextView(this).apply {
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(12), 0, dp(16), 0)
                maxLines = 1
                setShadowLayer(4f, 0f, 1f, Color.argb(180, 0, 0, 0))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            titleView = tvTitle

            val srvBadge = TextView(this).apply {
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(12), dp(5), dp(12), dp(5))
                isClickable = false
                isFocusable = false
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(12).toFloat()
                    setColor(Color.argb(55, 255, 255, 255))
                }
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
            serverBadgeView = srvBadge
            tvTitle.layoutParams = LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
            ).apply {
                marginStart = dp(12)
                marginEnd = dp(12)
            }
            val swBtn = Button(this).apply {
                text = "Switch Server"
                isAllCaps = false
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(12), dp(5), dp(12), dp(5))
                minHeight = 0
                minimumHeight = 0
                minWidth = 0
                minimumWidth = 0
                isFocusable = true
                isClickable = true
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(12).toFloat()
                    setColor(Color.argb(215, 229, 9, 20))
                }
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    marginEnd = dp(8)
                }
                setOnClickListener { handleSwitchServer() }
            }
            switchServerBtn = swBtn
            topBar.addView(backBtn)
            topBar.addView(tvTitle)
            topBar.addView(swBtn)
            topBar.addView(srvBadge)
            overlay.addView(topBar)

            val centerControls = LinearLayout(this).apply {
                clipChildren = false
                clipToPadding = false
                setPadding(dp(18), dp(18), dp(18), dp(18))
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER
                )
            }

            val rewBtn = makeCircleVectorButton("rew10", 58) {
                exoPlayer?.let { p ->
                    p.seekTo((p.currentPosition - 10_000L).coerceAtLeast(0L))
                }
                showControllerTemporarily()
            }

            val ppBtn = makeCircleVectorButton("pause", 72) {
                exoPlayer?.let { p ->
                    if (p.isPlaying) p.pause() else p.play()
                }
                showControllerTemporarily()
            }
            playPauseBtn = ppBtn

            val fwdBtn = makeCircleVectorButton("fwd10", 58) {
                exoPlayer?.let { p ->
                    p.seekTo((p.currentPosition + 10_000L).coerceAtMost(p.duration.coerceAtLeast(0L)))
                }
                showControllerTemporarily()
            }

            (rewBtn.layoutParams as LinearLayout.LayoutParams).setMargins(0, 0, dp(30), 0)
            (fwdBtn.layoutParams as LinearLayout.LayoutParams).setMargins(dp(30), 0, 0, 0)

            centerControls.addView(rewBtn)
            centerControls.addView(ppBtn)
            centerControls.addView(fwdBtn)
            overlay.addView(centerControls)

            val bottomContainer = LinearLayout(this).apply {
                clipChildren = false
                clipToPadding = false
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(72), dp(28), dp(72), dp(22))
                background = GradientDrawable(
                    GradientDrawable.Orientation.BOTTOM_TOP,
                    intArrayOf(Color.argb(175, 0, 0, 0), Color.TRANSPARENT)
                )
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM
                )
            }

            val seekRow = LinearLayout(this).apply {
                clipChildren = false
                clipToPadding = false
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    setMargins(dp(56), 0, dp(56), dp(10))
                }
            }

            val posText = TextView(this).apply {
                text = "0:00"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(0, 0, dp(14), 0)
            }
            currentPosView = posText

            val sb = SeekBar(this).apply {
                max = 1000
                progress = 0
                splitTrack = false
                isFocusable = true
                isFocusableInTouchMode = false
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    defaultFocusHighlightEnabled = false
                }
                progressDrawable = createNetflixSeekBarDrawable(false)
                thumb = ColorDrawable(Color.TRANSPARENT)
                thumbOffset = 0
                setPadding(0, dp(10), 0, dp(10))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnFocusChangeListener { v, hasFocus ->
                    progressDrawable = createNetflixSeekBarDrawable(hasFocus)
                    v.animate()
                        .scaleY(if (hasFocus) 1.55f else 1.0f)
                        .setDuration(140)
                        .setInterpolator(DecelerateInterpolator())
                        .start()
                    showControllerTemporarily()
                }
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) {
                        if (fromUser) {
                            val dur = exoPlayer?.duration ?: 0L
                            if (dur > 0) {
                                val target = (dur * value) / 1000L
                                currentPosView?.text = formatTimeMs(target)
                            }
                        }
                    }

                    override fun onStartTrackingTouch(bar: SeekBar?) {
                        isScrubbing = true
                        mainHandler.removeCallbacks(hideControllerRunnable)
        mainHandler.removeCallbacks(hideMetersRunnable)
        mainHandler.removeCallbacks(hideLeftSeekRunnable)
        mainHandler.removeCallbacks(hideRightSeekRunnable)
                    }

                    override fun onStopTrackingTouch(bar: SeekBar?) {
                        isScrubbing = false
                        val dur = exoPlayer?.duration ?: 0L
                        if (dur > 0 && bar != null) {
                            exoPlayer?.seekTo((dur * bar.progress) / 1000L)
                        }
                        showControllerTemporarily()
                    }
                })
            }
            seekBar = sb

            val durText = TextView(this).apply {
                text = "0:00"
                setTextColor(Color.argb(215, 226, 232, 240))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(14), 0, 0, 0)
            }
            durationView = durText

            seekRow.addView(posText)
            seekRow.addView(sb)
            seekRow.addView(durText)
            bottomContainer.addView(seekRow)

            val actionsRow = LinearLayout(this).apply {
                clipChildren = false
                clipToPadding = false
                setPadding(dp(12), dp(8), dp(12), dp(8))
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }

            val sBtn = makeSecondaryButton("Subtitles") {
                showSubtitlesMenuDialog()
            }
            subBtn = sBtn

            val qualityBtn = makeSecondaryButton("Quality") {
                showQualityDialog()
            }
            val speedBtn = makeSecondaryButton("1.0x") { btn ->
                showSpeedDialog(btn as Button)
            }
            val pipBtn = makeSecondaryButton("PiP") {
                enterPipIfSupported()
            }

            val syncBtn = makeSecondaryButton("Sync 0.0s") {
                showSubtitleDelayDialog()
            }
            actionsRow.addView(sBtn)
            actionsRow.addView(syncBtn)
            actionsRow.addView(qualityBtn)
            actionsRow.addView(speedBtn)
            actionsRow.addView(pipBtn)
            bottomContainer.addView(actionsRow)

            overlay.addView(bottomContainer)
            root.addView(overlay)

            audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val lpBright = window.attributes
            if (lpBright.screenBrightness >= 0f) {
                currentBrightness = lpBright.screenBrightness
            }

            val bMeter = VerticalGestureMeterView(this, true).apply {
                visibility = View.GONE
                alpha = 0f
                val lp = FrameLayout.LayoutParams(dp(52), dp(210), Gravity.START or Gravity.CENTER_VERTICAL)
                lp.setMargins(dp(34), 0, 0, 0)
                layoutParams = lp
            }
            brightnessMeter = bMeter
            root.addView(bMeter)

            val vMeter = VerticalGestureMeterView(this, false).apply {
                visibility = View.GONE
                alpha = 0f
                val lp = FrameLayout.LayoutParams(dp(52), dp(210), Gravity.END or Gravity.CENTER_VERTICAL)
                lp.setMargins(0, 0, dp(34), 0)
                layoutParams = lp
            }
            volumeMeter = vMeter
            root.addView(vMeter)

            val lSeek = TextView(this).apply {
                visibility = View.GONE
                alpha = 0f
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(dp(24), dp(14), dp(24), dp(14))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(40).toFloat()
                    setColor(Color.argb(145, 0, 0, 0))
                }
                val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.START or Gravity.CENTER_VERTICAL)
                lp.setMargins(dp(95), 0, 0, 0)
                layoutParams = lp
            }
            leftSeekBadge = lSeek
            root.addView(lSeek)

            val rSeek = TextView(this).apply {
                visibility = View.GONE
                alpha = 0f
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(dp(24), dp(14), dp(24), dp(14))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(40).toFloat()
                    setColor(Color.argb(145, 0, 0, 0))
                }
                val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END or Gravity.CENTER_VERTICAL)
                lp.setMargins(0, 0, dp(95), 0)
                layoutParams = lp
            }
            rightSeekBadge = rSeek
            root.addView(rSeek)

            val triggerSeekStep: (Int) -> Unit = { side ->
                val player = exoPlayer
                if (player != null) {
                    val dur = player.duration
                    val nowMs = SystemClock.elapsedRealtime()
                    activeSeekSide = side
                    lastSeekEventTimeMs = nowMs
                    if (side < 0) {
                        val target = (player.currentPosition - 10_000L).coerceAtLeast(0L)
                        player.seekTo(target)
                        accumSeekLeftSec += 10
                        mainHandler.removeCallbacks(hideLeftSeekRunnable)
                        lSeek.animate().cancel()
                        lSeek.text = "« -${accumSeekLeftSec}s"
                        lSeek.visibility = View.VISIBLE
                        lSeek.alpha = 1f
                        lSeek.scaleX = 0.9f
                        lSeek.scaleY = 0.9f
                        lSeek.animate().scaleX(1.06f).scaleY(1.06f).setDuration(110).withEndAction {
                            lSeek.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
                        }.start()
                        mainHandler.postDelayed(hideLeftSeekRunnable, 750L)
                    } else {
                        val rawNext = player.currentPosition + 10_000L
                        val target = if (dur > 0L) rawNext.coerceAtMost(dur) else rawNext
                        player.seekTo(target)
                        accumSeekRightSec += 10
                        mainHandler.removeCallbacks(hideRightSeekRunnable)
                        rSeek.animate().cancel()
                        rSeek.text = "+${accumSeekRightSec}s »"
                        rSeek.visibility = View.VISIBLE
                        rSeek.alpha = 1f
                        rSeek.scaleX = 0.9f
                        rSeek.scaleY = 0.9f
                        rSeek.animate().scaleX(1.06f).scaleY(1.06f).setDuration(110).withEndAction {
                            rSeek.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
                        }.start()
                        mainHandler.postDelayed(hideRightSeekRunnable, 750L)
                    }
                    updateTimeAndSeekBar()
                }
            }

            pv.setOnTouchListener { _, event ->
                val w = root.width.toFloat().coerceAtLeast(1f)
                val h = root.height.toFloat().coerceAtLeast(1f)
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        gestureActiveMode = 0
                        gestureDownTimeMs = SystemClock.elapsedRealtime()
                        gestureStartX = event.x
                        gestureStartY = event.y
                        gestureStartVal = if (event.x < w * 0.5f) {
                            currentBrightness
                        } else {
                            val am = audioManager
                            if (am != null) {
                                val maxV = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                                am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxV.toFloat()
                            } else 0.5f
                        }
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.x - gestureStartX
                        val dy = gestureStartY - event.y
                        val inVerticalSafeZone = gestureStartY >= h * 0.14f && gestureStartY <= h * 0.84f
                        val inLeftStrip = gestureStartX >= dp(20).toFloat() && gestureStartX <= w * 0.24f
                        val inRightStrip = gestureStartX >= w * 0.76f && gestureStartX <= w - dp(20).toFloat()
                        if (gestureActiveMode == 0 && event.pointerCount == 1 && inVerticalSafeZone && (inLeftStrip || inRightStrip) && kotlin.math.abs(dy) > dp(20) && kotlin.math.abs(dy) > kotlin.math.abs(dx) * 1.3f) {
                            gestureActiveMode = if (inLeftStrip) 1 else 2
                        }
                        if (gestureActiveMode != 0) {
                            val delta = dy / (h * 0.6f)
                            val nextVal = (gestureStartVal + delta).coerceIn(0f, 1f)
                            mainHandler.removeCallbacks(hideMetersRunnable)
                            if (gestureActiveMode == 1) {
                                currentBrightness = nextVal.coerceAtLeast(0.04f)
                                val wlp = window.attributes
                                wlp.screenBrightness = currentBrightness
                                window.attributes = wlp
                                bMeter.setLevel(currentBrightness)
                                bMeter.animate().cancel()
                                bMeter.alpha = 1f
                                bMeter.visibility = View.VISIBLE
                            } else {
                                val am = audioManager
                                if (am != null) {
                                    val maxV = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                                    val targetV = kotlin.math.round(nextVal * maxV).toInt().coerceIn(0, maxV)
                                    am.setStreamVolume(AudioManager.STREAM_MUSIC, targetV, 0)
                                    vMeter.setLevel(targetV.toFloat() / maxV.toFloat())
                                } else {
                                    vMeter.setLevel(nextVal)
                                }
                                vMeter.animate().cancel()
                                vMeter.alpha = 1f
                                vMeter.visibility = View.VISIBLE
                            }
                            mainHandler.postDelayed(hideMetersRunnable, 900L)
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (gestureActiveMode != 0) {
                            gestureActiveMode = 0
                            mainHandler.removeCallbacks(hideMetersRunnable)
                            mainHandler.postDelayed(hideMetersRunnable, 900L)
                            return@setOnTouchListener true
                        }
                        val moveDist = kotlin.math.hypot((event.x - gestureStartX).toDouble(), (event.y - gestureStartY).toDouble())
                        val nowMs = SystemClock.elapsedRealtime()
                        if (moveDist < dp(18) && (nowMs - gestureDownTimeMs) < 320L) {
                            val tapSide = when {
                                event.x < w * 0.35f -> -1
                                event.x > w * 0.65f -> 1
                                else -> 0
                            }
                            if (tapSide != 0 && activeSeekSide == tapSide && (nowMs - lastSeekEventTimeMs) < 850L) {
                                mainHandler.removeCallbacks(singleTapToggleRunnable)
                                triggerSeekStep(tapSide)
                            } else if (tapSide != 0 && tapSide == lastTapSide && (nowMs - lastTapTimeMs) < 320L) {
                                mainHandler.removeCallbacks(singleTapToggleRunnable)
                                lastTapTimeMs = 0L
                                triggerSeekStep(tapSide)
                            } else if (tapSide == 0) {
                                mainHandler.removeCallbacks(singleTapToggleRunnable)
                                lastTapTimeMs = 0L
                                lastTapSide = 0
                                singleTapToggleRunnable.run()
                            } else {
                                lastTapTimeMs = nowMs
                                lastTapSide = tapSide
                                mainHandler.removeCallbacks(singleTapToggleRunnable)
                                mainHandler.postDelayed(singleTapToggleRunnable, 270L)
                            }
                        }
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        if (gestureActiveMode != 0) {
                            gestureActiveMode = 0
                            mainHandler.removeCallbacks(hideMetersRunnable)
                            mainHandler.postDelayed(hideMetersRunnable, 900L)
                        }
                    }
                }
                true
            }
            setContentView(root)
            enableImmersiveFullscreen()
            showControllerTemporarily()
            ppBtn.post { ppBtn.requestFocus() }

            parseIntentAndStart(intent)
        } catch (t: Throwable) {
            Toast.makeText(this, "Player initialization error: ${t.localizedMessage}", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun createNetflixSeekBarDrawable(focused: Boolean): LayerDrawable {
        val radius = dp(6).toFloat()
        val h = if (focused) dp(7) else dp(5)
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radius
            setColor(if (focused) Color.argb(120, 255, 255, 255) else Color.argb(72, 255, 255, 255))
            if (focused) {
                setStroke(dp(1), Color.argb(210, 255, 255, 255))
            }
            setSize(-1, h)
        }
        val prog = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radius
            setColor(if (focused) Color.rgb(255, 30, 42) else Color.rgb(229, 9, 20))
            setSize(-1, h)
        }
        val clip = ClipDrawable(prog, Gravity.START, ClipDrawable.HORIZONTAL)
        return LayerDrawable(arrayOf(bg, clip)).apply {
            setId(0, android.R.id.background)
            setId(1, android.R.id.progress)
        }
    }

    private fun createCircleBg(focused: Boolean): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            if (focused) {
                setColor(Color.argb(65, 255, 255, 255))
                setStroke(dp(2), Color.WHITE)
            } else {
                setColor(Color.TRANSPARENT)
            }
        }
    }

    private fun makeCircleVectorButton(iconKind: String, sizeDp: Int, onClick: (View) -> Unit): ImageButton {
        val px = dp(sizeDp)
        return ImageButton(this).apply {
            setImageDrawable(VectorIconDrawable(iconKind, Color.WHITE))
            scaleType = ImageView.ScaleType.FIT_CENTER
            background = createCircleBg(false)
            val pad = dp((sizeDp * 0.22f).toInt())
            setPadding(pad, pad, pad, pad)
            layoutParams = LinearLayout.LayoutParams(px, px)
            isFocusable = true
            isFocusableInTouchMode = false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                defaultFocusHighlightEnabled = false
            }
            setOnFocusChangeListener { v, hasFocus ->
                v.background = createCircleBg(hasFocus)
                v.animate()
                    .scaleX(if (hasFocus) 1.14f else 1.0f)
                    .scaleY(if (hasFocus) 1.14f else 1.0f)
                    .setDuration(140)
                    .setInterpolator(DecelerateInterpolator())
                    .start()
                if (hasFocus) showControllerTemporarily()
            }
            setOnClickListener(onClick)
        }
    }

    private fun createSecondaryBg(focused: Boolean): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(20).toFloat()
            if (focused) {
                setColor(Color.argb(58, 255, 255, 255))
                setStroke(dp(2), Color.WHITE)
            } else {
                setColor(Color.TRANSPARENT)
            }
        }
    }

    private fun makeSecondaryButton(label: String, onClick: (View) -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(Color.argb(235, 240, 240, 240))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            typeface = Typeface.DEFAULT_BOLD
            background = createSecondaryBg(false)
            setPadding(dp(16), dp(7), dp(16), dp(7))
            minWidth = 0
            minimumWidth = 0
            minHeight = 0
            minimumHeight = 0
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(dp(6), 0, dp(6), 0)
            }
            isFocusable = true
            isFocusableInTouchMode = false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                defaultFocusHighlightEnabled = false
            }
            setOnFocusChangeListener { v, hasFocus ->
                v.background = createSecondaryBg(hasFocus)
                v.animate()
                    .scaleX(if (hasFocus) 1.08f else 1.0f)
                    .scaleY(if (hasFocus) 1.08f else 1.0f)
                    .setDuration(140)
                    .setInterpolator(DecelerateInterpolator())
                    .start()
                if (hasFocus) showControllerTemporarily()
            }
            setOnClickListener(onClick)
        }
    }

    private fun setControllerVisible(visible: Boolean) {
        isControllerVisible = visible
        val overlay = controllerOverlay ?: return
        if (visible) {
            if (overlay.visibility != View.VISIBLE) {
                overlay.alpha = 0f
                overlay.visibility = View.VISIBLE
                overlay.animate().alpha(1f).setDuration(180).start()
            }
        } else {
            mainHandler.removeCallbacks(hideControllerRunnable)
            if (overlay.visibility == View.VISIBLE) {
                overlay.animate().alpha(0f).setDuration(180).withEndAction {
                    if (!isControllerVisible) overlay.visibility = View.GONE
                }.start()
            }
        }
    }

    private fun showControllerTemporarily() {
        setControllerVisible(true)
        mainHandler.removeCallbacks(hideControllerRunnable)
        mainHandler.removeCallbacks(hideLeftSeekRunnable)
        mainHandler.removeCallbacks(hideRightSeekRunnable)
        if (exoPlayer?.isPlaying == true) {
            mainHandler.postDelayed(hideControllerRunnable, 4000L)
        }
    }

    private fun formatTimeMs(ms: Long): String {
        val totalSec = (ms / 1000L).coerceAtLeast(0L)
        val h = totalSec / 3600L
        val m = (totalSec % 3600L) / 60L
        val s = totalSec % 60L
        return if (h > 0) {
            String.format("%d:%02d:%02d", h, m, s)
        } else {
            String.format("%d:%02d", m, s)
        }
    }

    private fun updateTimeAndSeekBar() {
        val player = exoPlayer ?: return
        val dur = player.duration.coerceAtLeast(0L)
        val pos = player.currentPosition.coerceAtLeast(0L)
        val minValidMs = if (mediaType.equals("tv", ignoreCase = true)) 240_000L else 900_000L
        if (!streamUrl.startsWith("/") && dur in 1L until minValidMs) {
            player.pause()
            recordServerStatus(currentSource, "failed")
            Toast.makeText(this, "Short/fake clip on $currentSource — switching...", Toast.LENGTH_SHORT).show()
            if (!isSwitchingServer) {
                triggerNextServerFailover()
            }
            return
        }
        if (!isSwitchingServer && !streamUrl.startsWith("/") && dur >= minValidMs && (pos > 500L || player.isPlaying)) {
            if (getServerStatus(currentSource) != "working") {
                recordServerStatus(currentSource, "working")
            }
        }
        playPauseBtn?.setImageDrawable(VectorIconDrawable(if (player.isPlaying) "pause" else "play", Color.WHITE))
        if (!isScrubbing) {
            currentPosView?.text = formatTimeMs(pos)
            durationView?.text = if (dur > 0) formatTimeMs(dur) else "0:00"
            if (dur > 0) {
                seekBar?.progress = ((pos * 1000L) / dur).toInt().coerceIn(0, 1000)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        try {
            val rawJson = intent.getStringExtra(EXTRA_PAYLOAD_JSON) ?: return
            val obj = JSONObject(rawJson)
            val newUrl = obj.optString("url", "")
            if (newUrl.isBlank()) return
            if (newUrl == streamUrl && exoPlayer != null) {
                return
            }
            val resumeSec = (exoPlayer?.currentPosition ?: 0L) / 1000L
            if (resumeSec > 5L && obj.optLong("startTimeSec", 0L) <= 0L) {
                obj.put("startTimeSec", resumeSec)
                intent.putExtra(EXTRA_PAYLOAD_JSON, obj.toString())
            }
            parseIntentAndStart(intent)
        } catch (_: Throwable) {}
    }

    private fun applySubtitleStyle() {
        try {
            val fgColor = try { Color.parseColor(subTextColorHex) } catch (_: Throwable) { Color.WHITE }
            val bgColor = when (subBgStyleMode) {
                "none" -> Color.TRANSPARENT
                "semi" -> Color.argb(115, 0, 0, 0)
                else -> Color.argb(200, 0, 0, 0)
            }
            playerView?.subtitleView?.apply {
                setStyle(
                    CaptionStyleCompat(
                        fgColor,
                        bgColor,
                        Color.TRANSPARENT,
                        CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW,
                        Color.BLACK,
                        Typeface.DEFAULT_BOLD
                    )
                )
                setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, subTextSizeSp)
                setBottomPaddingFraction(0.045f)
            }
            subtitleOverlayView?.apply {
                setTextColor(fgColor)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, subTextSizeSp)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 14f
                    setColor(bgColor)
                }
            }
        } catch (_: Throwable) {}
    }

    private fun parseIntentAndStart(intent: Intent?) {
        val rawJson = intent?.getStringExtra(EXTRA_PAYLOAD_JSON) ?: "{}"
        val obj = try {
            JSONObject(rawJson)
        } catch (_: Throwable) {
            JSONObject()
        }
        rawPayload = obj

        streamUrl = obj.optString("url", "")
        streamTitle = obj.optString("title", "SingularityTV")
        progressKey = obj.optString("progressKey").takeIf { it.isNotEmpty() }
        startTimeSec = obj.optLong("startTimeSec", 0L)
        imdbId = obj.optString("imdbId", "")
        mediaType = obj.optString("mediaType", "movie")
        seasonNum = obj.optInt("season", 1)
        episodeNum = obj.optInt("episode", 1)
        preferredLang = obj.optString("preferredSubLang", "ar").ifBlank { "ar" }.substringBefore("-").lowercase()
        subTextColorHex = obj.optString("subTextColor", "#FFFFFF").ifBlank { "#FFFFFF" }
        subBgStyleMode = obj.optString("subBgStyle", "dark").ifBlank { "dark" }
        subTextSizeSp = obj.optDouble("subFontSizeSp", 22.0).toFloat().coerceIn(14f, 42f)
        applySubtitleStyle()
        titleView?.text = streamTitle
        serverBadgeView?.text = currentSource

        if (streamUrl.isBlank()) {
            currentSource = obj.optString("currentSource").ifEmpty { "vidsrcmeru" }
            serverBadgeView?.text = currentSource
            startResolvingInitialSource()
            fetchOnlineSubtitlesInBackground()
            mainHandler.postDelayed({ startBackgroundServerProbing() }, 400L)
            return
        }

        availableSubs.clear()
        activeParsedCues.clear()
        activeSubIndex = -1

        val subsArray = obj.optJSONArray("subtitles") ?: obj.optJSONArray("subtitlePaths") ?: JSONArray()
        for (i in 0 until subsArray.length()) {
            val sObj = subsArray.optJSONObject(i) ?: continue
            val u = sObj.optString("url").ifEmpty { sObj.optString("path") }
            if (u.isBlank()) continue
            val lang = normalizeLangCode(sObj.optString("lang", "en"))
            val label = sObj.optString("label").ifBlank { "Stream · ${lang.uppercase()}" }
            availableSubs.add(PlayerSubTrack(label, lang, u, 120))
        }
        if (availableSubs.isNotEmpty()) {
            selectBestSubtitleForLanguage(preferredLang, silent = true)
        }

        initializeExoPlayer(obj)
        fetchOnlineSubtitlesInBackground()
    }

    private fun normalizeLangCode(raw: String): String {
        val c = raw.trim().lowercase().substringBefore("-").substringBefore("_")
        return when (c) {
            "ara", "arabic" -> "ar"
            "eng", "english" -> "en"
            "fre", "fra", "french" -> "fr"
            "spa", "spanish" -> "es"
            "ger", "deu", "german" -> "de"
            "tur", "turkish" -> "tr"
            "por", "portuguese" -> "pt"
            "ita", "italian" -> "it"
            "rus", "russian" -> "ru"
            "jpn", "japanese" -> "ja"
            "kor", "korean" -> "ko"
            "chi", "zho", "chinese" -> "zh"
            "hin", "hindi" -> "hi"
            "ind", "indonesian" -> "id"
            "dut", "nld", "dutch" -> "nl"
            "pol", "polish" -> "pl"
            "swe", "swedish" -> "sv"
            "gre", "ell", "greek" -> "el"
            "per", "fas", "persian" -> "fa"
            "heb", "hebrew" -> "he"
            else -> if (c.length >= 2) c.take(2) else "en"
        }
    }

    private fun langDisplayName(code: String): String {
        return try {
            val loc = Locale(code)
            val name = loc.getDisplayLanguage(Locale.ENGLISH)
            if (name.isNotBlank() && !name.equals(code, ignoreCase = true)) {
                "$name (${code.uppercase()})"
            } else {
                code.uppercase()
            }
        } catch (_: Throwable) {
            code.uppercase()
        }
    }

    private fun scoreTrackForCurrentStream(track: PlayerSubTrack): Int {
        var s = track.score
        val u = track.label.uppercase()
        if (activeQualityTag.isNotEmpty() && u.contains(activeQualityTag)) {
            s += 35
        }
        if (streamUrl.contains("vidsrc", ignoreCase = true) || streamUrl.contains("m3u8", ignoreCase = true)) {
            if (Regex("WEB[-_. ]?DL|WEBRIP|NF|AMZN|DSNP|ATVP|HMAX").containsMatchIn(u)) {
                s += 40
            }
        }
        return s
    }

    private fun selectBestSubtitleForLanguage(langCode: String, silent: Boolean = false): Boolean {
        val norm = normalizeLangCode(langCode)
        val matches = availableSubs.mapIndexedNotNull { idx, t ->
            if (t.lang == norm) idx to scoreTrackForCurrentStream(t) else null
        }.sortedByDescending { it.second }

        if (matches.isEmpty()) {
            if (!silent) {
                offerServerSwitchForLanguage(norm)
            }
            return false
        }

        val bestIdx = matches.first().first
        activeSubIndex = bestIdx
        preferredLang = norm
        subBtn?.text = "Subtitles (${availableSubs.size})"
        loadSubtitleCuesAsync(bestIdx)
        if (!silent) {
            Toast.makeText(
                this,
                "Auto-synced ${langDisplayName(norm)}: ${availableSubs[bestIdx].label}",
                Toast.LENGTH_SHORT
            ).show()
        }
        return true
    }

    private fun offerServerSwitchForLanguage(langCode: String) {
        AlertDialog.Builder(this)
            .setTitle("No ${langDisplayName(langCode)} Subtitle on This Server")
            .setMessage("Would you like to switch to another streaming server and load a matching ${langDisplayName(langCode)} subtitle?")
            .setPositiveButton("Switch Server") { _, _ ->
                saveCurrentProgress()
                ExoProgressBus.serverSwitchListener?.invoke(langCode)
                finish()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun mergeFetchedTracks(batch: List<PlayerSubTrack>) {
        if (batch.isEmpty()) return
        runOnUiThread {
            if (isDestroyed) return@runOnUiThread
            val existingUrls = availableSubs.map { it.urlOrPath }.toHashSet()
            val fresh = batch.filter { it.urlOrPath !in existingUrls }.sortedByDescending { it.score }
            if (fresh.isEmpty()) return@runOnUiThread
            val wasEmpty = activeSubIndex == -1
            availableSubs.addAll(fresh)
            subBtn?.text = "Subtitles (${availableSubs.size})"
            if (wasEmpty) {
                if (!selectBestSubtitleForLanguage(preferredLang, silent = true)) {
                    selectBestSubtitleForLanguage("ar", silent = true) || selectBestSubtitleForLanguage("en", silent = true)
                }
            }
        }
    }

    private fun queryWyzieLanguage(qLang: String): List<PlayerSubTrack> {
        val list = mutableListOf<PlayerSubTrack>()
        try {
            val qs = StringBuilder("id=${URLEncoder.encode(imdbId, "UTF-8")}&format=srt")
            if (qLang.isNotEmpty()) {
                qs.append("&language=").append(URLEncoder.encode(qLang, "UTF-8"))
            }
            if (mediaType == "tv") {
                qs.append("&season=").append(seasonNum).append("&episode=").append(episodeNum)
            }
            val req = Request.Builder()
                .url("https://subs.wyzie.ru/search?$qs")
                .header("User-Agent", "SingularityTV/2.7.3")
                .build()
            StreambertApp.instance.okHttpClient.newCall(req).execute().use { res ->
                if (res.isSuccessful) {
                    val body = res.body?.string()?.trim() ?: "[]"
                    if (body.startsWith("[")) {
                        val arr = JSONArray(body)
                        val limit = if (qLang.isEmpty()) 60 else 20
                        for (i in 0 until minOf(arr.length(), limit)) {
                            val item = arr.optJSONObject(i) ?: continue
                            val rawUrl = item.optString("url")
                            if (rawUrl.isBlank()) continue
                            val fullUrl = if (rawUrl.startsWith("http")) rawUrl else "https://subs.wyzie.ru$rawUrl"
                            val rawItemLang = item.optString("language")
                                .ifBlank { item.optString("lang") }
                                .ifBlank { item.optString("iso639") }
                                .ifBlank { qLang.ifEmpty { "en" } }
                            val lang = normalizeLangCode(rawItemLang)
                            val rel = item.optString("display_name")
                                .ifBlank { item.optString("release_name") }
                                .ifBlank { "Wyzie ${lang.uppercase()} #${i + 1}" }
                            val sc = scoreReleaseName(rel) + if (lang == preferredLang || lang == "ar") 35 else 0
                            list.add(PlayerSubTrack("${lang.uppercase()} · $rel", lang, fullUrl, sc))
                        }
                    }
                }
            }
        } catch (_: Throwable) {}
        return list
    }

    private fun fetchOnlineSubtitlesInBackground() {
        if (!imdbId.startsWith("tt")) return
        val priorityLangs = listOf(preferredLang.substringBefore("-"), "ar", "en").distinct()
        for (lang in priorityLangs) {
            thread(start = true) {
                mergeFetchedTracks(queryWyzieLanguage(lang))
            }
        }

        thread(start = true) {
            val osList = mutableListOf<PlayerSubTrack>()
            try {
                val osType = if (mediaType == "tv") "series" else "movie"
                val osTarget = if (mediaType == "tv") "$imdbId:$seasonNum:$episodeNum" else imdbId
                val req = Request.Builder()
                    .url("https://opensubtitles-v3.strem.io/subtitles/$osType/${URLEncoder.encode(osTarget, "UTF-8")}.json")
                    .header("User-Agent", "SingularityTV/2.7.3")
                    .build()
                StreambertApp.instance.okHttpClient.newCall(req).execute().use { res ->
                    if (res.isSuccessful) {
                        val root = JSONObject(res.body?.string() ?: "{}")
                        val subs = root.optJSONArray("subtitles") ?: JSONArray()
                        for (i in 0 until minOf(subs.length(), 100)) {
                            val s = subs.optJSONObject(i) ?: continue
                            val u = s.optString("url")
                            val rawLang = s.optString("lang").ifBlank { "en" }
                            if (u.isBlank()) continue
                            val normLang = normalizeLangCode(rawLang)
                            val bonus = if (normLang == "ar" || normLang == preferredLang) 35 else 0
                            osList.add(PlayerSubTrack("${normLang.uppercase()} · OpenSubtitles", normLang, u, 65 + bonus))
                        }
                    }
                }
            } catch (_: Throwable) {}
            mergeFetchedTracks(osList)
        }

        val extraLangs = listOf("fr", "es", "de", "tr", "pt", "it", "ru", "ja", "ko", "hi", "id", "zh", "nl", "pl", "sv", "th", "vi", "fa", "")
        for (lang in extraLangs) {
            thread(start = true) {
                mergeFetchedTracks(queryWyzieLanguage(lang))
            }
        }
    }

    private fun scoreReleaseName(name: String): Int {
        val u = name.uppercase()
        var score = 0
        if (Regex("WEB[-_. ]?DL|WEBRIP|AMZN|NF|DSNP|ATVP|HMAX").containsMatchIn(u)) score += 55
        if (Regex("1080P|720P|X264|H264").containsMatchIn(u)) score += 20
        if (Regex("EXTENDED|DIRECTORS|UNRATED|CAM|TS").containsMatchIn(u)) score -= 50
        return score
    }

    private fun buildPlayerMediaItem(url: String): MediaItem {
        val uri = if (url.startsWith("/")) Uri.fromFile(File(url)) else Uri.parse(url)
        val builder = MediaItem.Builder().setUri(uri)
        val lower = url.lowercase()
        if (lower.contains(".m3u8") || lower.contains("master.txt") || lower.contains("playlist.txt") || lower.contains("/hls/")) {
            builder.setMimeType(MimeTypes.APPLICATION_M3U8)
        } else if (lower.contains(".mpd")) {
            builder.setMimeType(MimeTypes.APPLICATION_MPD)
        }
        return builder.build()
    }

    private fun initializeExoPlayer(payload: JSONObject) {
        try {
            exoPlayer?.release()
            exoPlayer = null

            currentSource = payload.optString("currentSource").ifEmpty { currentSource.ifEmpty { "vidlink" } }
            val capturedHeaders = AdBlockerInterceptor.streamHeadersMap[streamUrl] ?: emptyMap()
            fun findHeader(name: String): String? {
                for ((k, v) in capturedHeaders) {
                    if (k.equals(name, ignoreCase = true) && v.isNotBlank()) return v
                }
                return null
            }
            val referer = findHeader("Referer")
                ?: payload.optString("referer").takeIf { it.isNotEmpty() }
                ?: getDefaultRefererForSource(currentSource)
            val origin = findHeader("Origin") ?: if (referer.startsWith("http")) {
                try {
                    val u = Uri.parse(referer)
                    "${u.scheme}://${u.host}"
                } catch (_: Throwable) { "" }
            } else ""
            val userAgent = findHeader("User-Agent")
                ?: payload.optString("userAgent").takeIf { it.isNotEmpty() }
                ?: "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
            val cookieStr = try {
                CookieManager.getInstance().getCookie(streamUrl) ?: ""
            } catch (_: Throwable) { "" }

            val httpFactory = OkHttpDataSource.Factory(StreambertApp.instance.okHttpClient)
                .setUserAgent(userAgent)
                .apply {
                    val headers = mutableMapOf<String, String>()
                    if (referer.isNotEmpty()) headers["Referer"] = referer
                    if (origin.isNotEmpty()) headers["Origin"] = origin
                    if (cookieStr.isNotEmpty()) headers["Cookie"] = cookieStr
                    headers["Accept"] = "*/*"
                    setDefaultRequestProperties(headers)
                }

            val dataSourceFactory = DefaultDataSource.Factory(this, httpFactory)
            val loadControl = DefaultLoadControl.Builder()
                .setBufferDurationsMs(15_000, 60_000, 2_500, 5_000)
                .build()

            val player = ExoPlayer.Builder(this)
                .setMediaSourceFactory(DefaultMediaSourceFactory(dataSourceFactory))
                .setLoadControl(loadControl)
                .setHandleAudioBecomingNoisy(true)
                .setAudioAttributes(
                    androidx.media3.common.AudioAttributes.Builder()
                        .setUsage(C.USAGE_MEDIA)
                        .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                        .build(),
                    true
                )
                .build()

            player.setMediaItem(buildPlayerMediaItem(streamUrl))

            if (startTimeSec > 0) {
                player.seekTo(startTimeSec * 1000L)
            }

            player.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    updateTimeAndSeekBar()
                    if (!isPlaying) {
                        setControllerVisible(true)
                    } else {
                        showControllerTemporarily()
                    }
                }

                override fun onPlayerError(error: PlaybackException) {
                    mainHandler.removeCallbacks(playbackReadyWatchdogRunnable)
                    if (retryCount < 1) {
                        retryCount++
                        player.prepare()
                        player.play()
                    } else if (!streamUrl.startsWith("/") && serverFailoverAttempts < serverOrder.size) {
                        recordServerStatus(currentSource, "failed")
                        isSwitchingServer = false
                        triggerNextServerFailover()
                    } else {
                        Toast.makeText(
                            this@NativeExoPlayerActivity,
                            "Playback error: ${error.errorCodeName}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }

                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_READY) {
                        val minValidMs = if (mediaType.equals("tv", ignoreCase = true)) 240_000L else 900_000L
                        if (!streamUrl.startsWith("/") && player.duration > 0L && player.duration < minValidMs) {
                            recordServerStatus(currentSource, "failed")
                            Toast.makeText(this@NativeExoPlayerActivity, "Invalid/short clip on $currentSource — switching...", Toast.LENGTH_SHORT).show()
                            isSwitchingServer = false
                            triggerNextServerFailover()
                            return
                        }
                        mainHandler.removeCallbacks(playbackReadyWatchdogRunnable)
                        mainHandler.removeCallbacks(failoverWatchdogRunnable)
                        isSwitchingServer = false
                        retryCount = 0
                        serverFailoverAttempts = 0
                        recordServerStatus(currentSource, "working")
                        if (currentSource.isNotBlank()) {
                            try {
                                getSharedPreferences("singularity_prefs", Context.MODE_PRIVATE)
                                    .edit().putString("last_working_source", currentSource).apply()
                            } catch (_: Throwable) {}
                            ExoProgressBus.preferredSourceListener?.invoke(currentSource)
                        }
                        if (startTimeSec > 0L && player.duration > 0L && startTimeSec * 1000L >= player.duration - 15_000L) {
                            startTimeSec = 0L
                            player.seekTo(0L)
                        }
                        updateTimeAndSeekBar()
                    } else if (playbackState == Player.STATE_ENDED) {
                        mainHandler.removeCallbacks(playbackReadyWatchdogRunnable)
                        saveCurrentProgress(forceCompleted = true)
                        finish()
                    }
                }
            })

            player.prepare()
            player.playWhenReady = true

            playerView?.player = player
            exoPlayer = player
            if (!streamUrl.startsWith("/")) {
                mainHandler.removeCallbacks(playbackReadyWatchdogRunnable)
                mainHandler.postDelayed(playbackReadyWatchdogRunnable, 9000L)
            }

            mainHandler.removeCallbacks(progressRunnable)
            mainHandler.postDelayed(progressRunnable, 5000L)
            mainHandler.removeCallbacks(uiTickRunnable)
            mainHandler.post(uiTickRunnable)
            mainHandler.removeCallbacks(subtitleTickRunnable)
            mainHandler.post(subtitleTickRunnable)
        } catch (t: Throwable) {
            Toast.makeText(this, "Stream error: ${t.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadSubtitleCuesAsync(subIndex: Int) {
        if (subIndex < 0 || subIndex >= availableSubs.size) {
            activeParsedCues.clear()
            runOnUiThread {
                subtitleOverlayView?.visibility = View.GONE
            }
            return
        }
        val track = availableSubs[subIndex]
        thread(start = true) {
            try {
                val rawText = if (track.urlOrPath.startsWith("/")) {
                    File(track.urlOrPath).readText(Charsets.UTF_8)
                } else {
                    val req = Request.Builder()
                        .url(track.urlOrPath)
                        .header("User-Agent", "Mozilla/5.0 (Linux; Android 14)SingularityTV/2.7.3")
                        .build()
                    StreambertApp.instance.okHttpClient.newCall(req).execute().use { res ->
                        res.body?.string() ?: ""
                    }
                }
                val parsed = parseSrtOrVtt(rawText)
                activeParsedCues.clear()
                activeParsedCues.addAll(parsed)
                runOnUiThread {
                    if (!isDestroyed) {
                        updateLiveSubtitleOverlay()
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    private fun parseSrtOrVtt(raw: String): List<ParsedSubCue> {
        if (raw.isBlank()) return emptyList()
        val clean = raw.replace("\uFEFF", "").replace("\r\n", "\n").replace("\r", "\n")
        val blocks = clean.split(Regex("\n\\s*\n"))
        val list = ArrayList<ParsedSubCue>(blocks.size)
        val arrowRegex = Regex("""(\d{1,2}:)?(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d{1,2}:)?(\d{2}):(\d{2})[,.](\d{1,3})""")
        val htmlTagRegex = Regex("""<[^>]*>""")

        for (block in blocks) {
            val lines = block.lines().map { it.trim() }.filter { it.isNotEmpty() }
            if (lines.isEmpty() || lines[0].startsWith("WEBVTT")) continue
            var matchLineIdx = -1
            var matchResult: MatchResult? = null
            for (i in lines.indices) {
                val m = arrowRegex.find(lines[i])
                if (m != null) {
                    matchLineIdx = i
                    matchResult = m
                    break
                }
            }
            if (matchLineIdx == -1 || matchResult == null) continue
            val g = matchResult.groupValues
            val startH = g[1].trimEnd(':').toLongOrNull() ?: 0L
            val startM = g[2].toLongOrNull() ?: 0L
            val startS = g[3].toLongOrNull() ?: 0L
            val startMs = g[4].padEnd(3, '0').take(3).toLongOrNull() ?: 0L
            val endH = g[5].trimEnd(':').toLongOrNull() ?: 0L
            val endM = g[6].toLongOrNull() ?: 0L
            val endS = g[7].toLongOrNull() ?: 0L
            val endMs = g[8].padEnd(3, '0').take(3).toLongOrNull() ?: 0L

            val startTotal = (startH * 3600L + startM * 60L + startS) * 1000L + startMs
            val endTotal = (endH * 3600L + endM * 60L + endS) * 1000L + endMs
            val textLines = lines.subList(matchLineIdx + 1, lines.size)
            val text = textLines.joinToString("\n").replace(htmlTagRegex, "").trim()
            if (text.isNotEmpty() && endTotal > startTotal) {
                list.add(ParsedSubCue(startTotal, endTotal, text))
            }
        }
        return list
    }

    private fun updateLiveSubtitleOverlay() {
        val overlay = subtitleOverlayView ?: return
        val player = exoPlayer
        if (player == null || activeSubIndex < 0 || activeParsedCues.isEmpty()) {
            if (overlay.visibility != View.GONE) overlay.visibility = View.GONE
            return
        }
        val posMs = player.currentPosition - subDelayMs
        val hit = activeParsedCues.firstOrNull { posMs >= it.startMs && posMs <= it.endMs }
        if (hit != null && hit.text.isNotEmpty()) {
            if (overlay.text.toString() != hit.text) {
                overlay.text = hit.text
            }
            if (overlay.visibility != View.VISIBLE) {
                overlay.visibility = View.VISIBLE
            }
        } else {
            if (overlay.visibility != View.GONE) {
                overlay.visibility = View.GONE
            }
        }
    }

    private fun createDialogItemBg(focused: Boolean): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(10).toFloat()
            if (focused) {
                setColor(Color.argb(65, 255, 255, 255))
                setStroke(dp(2), Color.WHITE)
            } else {
                setColor(Color.argb(18, 255, 255, 255))
            }
        }
    }

    private fun showStyledMenuDialog(title: String, items: Array<String>, onSelect: (Int) -> Unit) {
        val dlg = android.app.Dialog(this)
        dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(16).toFloat()
                setColor(Color.rgb(18, 22, 32))
                setStroke(dp(1), Color.argb(45, 255, 255, 255))
            }
        }

        val titleTv = TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(6), 0, dp(6), dp(12))
        }
        card.addView(titleTv)

        val scroll = android.widget.ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            clipChildren = false
            clipToPadding = false
            layoutParams = LinearLayout.LayoutParams(
                dp(420),
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                val maxH = (resources.displayMetrics.heightPixels * 0.62f).toInt()
                if (items.size > 7) height = maxH
            }
        }

        val listBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }

        var firstRow: TextView? = null
        items.forEachIndexed { idx, label ->
            val row = TextView(this).apply {
                text = label
                setTextColor(Color.argb(235, 240, 244, 248))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(16), dp(12), dp(16), dp(12))
                background = createDialogItemBg(false)
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    setMargins(0, dp(3), 0, dp(3))
                }
                isFocusable = true
                isFocusableInTouchMode = false
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    defaultFocusHighlightEnabled = false
                }
                setOnFocusChangeListener { v, hasFocus ->
                    v.background = createDialogItemBg(hasFocus)
                    (v as TextView).setTextColor(if (hasFocus) Color.WHITE else Color.argb(220, 226, 232, 240))
                    v.animate()
                        .scaleX(if (hasFocus) 1.02f else 1.0f)
                        .scaleY(if (hasFocus) 1.02f else 1.0f)
                        .setDuration(110)
                        .start()
                }
                setOnClickListener {
                    dlg.dismiss()
                    onSelect(idx)
                }
            }
            if (idx == 0) firstRow = row
            listBox.addView(row)
        }

        scroll.addView(listBox)
        card.addView(scroll)
        dlg.setContentView(card)
        dlg.show()
        firstRow?.post { firstRow?.requestFocus() }
    }

    private fun showSubtitlesMenuDialog() {
        val langCount = availableSubs.map { it.lang }.distinct().size
        val options = arrayOf(
            "Select Language ($langCount languages)",
            "Choose Subtitle Track (${availableSubs.size} found)",
            "Turn Subtitles Off"
        )
        showStyledMenuDialog("Subtitles", options) { which ->
            when (which) {
                0 -> showLanguagePickerDialog()
                1 -> showSubtitleTrackPicker()
                2 -> {
                    activeSubIndex = -1
                    activeParsedCues.clear()
                    subtitleOverlayView?.visibility = View.GONE
                    Toast.makeText(this, "Subtitles turned off", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun showSubtitleDelayDialog() {
        val steps = longArrayOf(-2000L, -1000L, -500L, -200L, 0L, 200L, 500L, 1000L, 2000L)
        val labels = arrayOf(
            "-2.0s (Earlier)",
            "-1.0s (Earlier)",
            "-0.5s (Earlier)",
            "-0.2s (Earlier)",
            "Reset to 0.0s",
            "+0.2s (Later)",
            "+0.5s (Later)",
            "+1.0s (Later)",
            "+2.0s (Later)"
        )
        showStyledMenuDialog("Adjust Subtitle Sync (${subDelayMs / 1000.0}s)", labels) { which ->
            subDelayMs = if (steps[which] == 0L) 0L else subDelayMs + steps[which]
            updateLiveSubtitleOverlay()
            Toast.makeText(this, "Subtitle Sync: ${subDelayMs / 1000.0}s", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showLanguagePickerDialog() {
        val grouped = availableSubs.groupBy { it.lang }
        if (grouped.isEmpty()) {
            Toast.makeText(this, "Searching subtitles across all languages…", Toast.LENGTH_SHORT).show()
            fetchOnlineSubtitlesInBackground()
            return
        }
        val codes = grouped.keys.sortedWith(compareByDescending<String> { it == preferredLang }.thenBy { langDisplayName(it) })
        val labels = codes.map { code ->
            val mark = if (code == preferredLang && activeSubIndex >= 0) "● " else ""
            "$mark${langDisplayName(code)} (${grouped[code]?.size ?: 0})"
        }.toTypedArray()

        showStyledMenuDialog("Select Subtitle Language", labels) { which ->
            selectBestSubtitleForLanguage(codes[which], silent = false)
        }
    }

    private fun simpleLangName(code: String): String {
        return when (code.lowercase()) {
            "ar" -> "Arabic"
            "en" -> "English"
            "ko" -> "Korea"
            "ja" -> "Japanese"
            "fr" -> "French"
            "es" -> "Spanish"
            "de" -> "German"
            "tr" -> "Turkish"
            "pt" -> "Portuguese"
            "it" -> "Italian"
            "ru" -> "Russian"
            "hi" -> "Hindi"
            "id" -> "Indonesian"
            "zh" -> "Chinese"
            "nl" -> "Dutch"
            "pl" -> "Polish"
            "sv" -> "Swedish"
            "th" -> "Thai"
            "vi" -> "Vietnamese"
            "fa" -> "Persian"
            else -> code.uppercase()
        }
    }

    private fun showSubtitleTrackPicker() {
        if (availableSubs.isEmpty()) {
            Toast.makeText(this, "Searching online subtitles… try again in a moment", Toast.LENGTH_SHORT).show()
            fetchOnlineSubtitlesInBackground()
            return
        }
        val counts = mutableMapOf<String, Int>()
        val recLangs = mutableSetOf<String>()
        val labels = availableSubs.mapIndexed { idx, tr ->
            val num = (counts[tr.lang] ?: 0) + 1
            counts[tr.lang] = num
            val isRec = tr.score >= 85 && !recLangs.contains(tr.lang)
            if (isRec) recLangs.add(tr.lang)
            val mark = if (idx == activeSubIndex) "● " else ""
            val tag = if (isRec) " · Recommend" else ""
            "$mark${simpleLangName(tr.lang)} sub $num$tag"
        }.toTypedArray()
        showStyledMenuDialog("Select Subtitle Track", labels) { which ->
            activeSubIndex = which
            preferredLang = availableSubs[which].lang
            loadSubtitleCuesAsync(which)
            Toast.makeText(this, "Loaded: ${availableSubs[which].label}", Toast.LENGTH_SHORT).show()
        }
    }



    private fun showQualityDialog() {
        val player = exoPlayer ?: return
        val videoGroup = player.currentTracks.groups.firstOrNull { it.type == C.TRACK_TYPE_VIDEO }
        if (videoGroup == null) {
            Toast.makeText(this, "Auto Quality Active", Toast.LENGTH_SHORT).show()
            return
        }
        val items = mutableListOf<Pair<String, Int>>()
        items.add("Auto (Adaptive)" to -1)
        for (i in 0 until videoGroup.length) {
            val fmt = videoGroup.getTrackFormat(i)
            if (fmt.height > 0) {
                items.add("${fmt.height}p (${fmt.width}x${fmt.height})" to i)
            }
        }
        val labels = items.map { it.first }.distinct().toTypedArray()
        showStyledMenuDialog("Video Quality", labels) { which ->
            val chosen = items.firstOrNull { it.first == labels[which] } ?: return@showStyledMenuDialog
            if (chosen.second == -1) {
                activeQualityTag = ""
                player.trackSelectionParameters = player.trackSelectionParameters
                    .buildUpon()
                    .clearOverridesOfType(C.TRACK_TYPE_VIDEO)
                    .build()
            } else {
                val fmt = videoGroup.getTrackFormat(chosen.second)
                activeQualityTag = if (fmt.height > 0) "${fmt.height}P" else ""
                player.trackSelectionParameters = player.trackSelectionParameters
                    .buildUpon()
                    .setOverrideForType(TrackSelectionOverride(videoGroup.mediaTrackGroup, listOf(chosen.second)))
                    .build()
            }
            if (activeSubIndex >= 0) {
                selectBestSubtitleForLanguage(preferredLang, silent = true)
            }
        }
    }

    private fun showSpeedDialog(speedBtn: Button) {
        val speeds = floatArrayOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
        val labels = speeds.map { "${it}x" }.toTypedArray()
        showStyledMenuDialog("Playback Speed", labels) { which ->
            currentSpeed = speeds[which]
            exoPlayer?.setPlaybackSpeed(currentSpeed)
            speedBtn.text = "${currentSpeed}x"
        }
    }

    private fun enterPipIfSupported() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val params = PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
                enterPictureInPictureMode(params)
            } catch (_: Throwable) {}
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (isInPictureInPictureMode) {
            setControllerVisible(false)
        } else {
            showControllerTemporarily()
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            if (isCaptchaCardVisible) {
                val wv = resolverWebView
                val wrap = (captchaCardContainer?.getChildAt(1) as? FrameLayout)
                if (wv != null && wrap != null) {
                    val step = if (isCaptchaDragMode) 0.03f else 0.06f
                    val emitMoveIfDragging = {
                        if (isCaptchaDragMode) {
                            val tx = captchaCursorX * wv.width
                            val ty = captchaCursorY * wv.height
                            val nowT = android.os.SystemClock.uptimeMillis()
                            wv.dispatchTouchEvent(MotionEvent.obtain(captchaDragDownTime, nowT, MotionEvent.ACTION_MOVE, tx, ty, 0))
                        }
                    }
                    when (event.keyCode) {
                        KeyEvent.KEYCODE_DPAD_LEFT -> {
                            captchaCursorX = (captchaCursorX - step).coerceIn(0f, 1f)
                            updateCaptchaCursorPosition(wrap)
                            emitMoveIfDragging()
                            return true
                        }
                        KeyEvent.KEYCODE_DPAD_RIGHT -> {
                            captchaCursorX = (captchaCursorX + step).coerceIn(0f, 1f)
                            updateCaptchaCursorPosition(wrap)
                            emitMoveIfDragging()
                            return true
                        }
                        KeyEvent.KEYCODE_DPAD_UP -> {
                            captchaCursorY = (captchaCursorY - step).coerceIn(0f, 1f)
                            updateCaptchaCursorPosition(wrap)
                            emitMoveIfDragging()
                            return true
                        }
                        KeyEvent.KEYCODE_DPAD_DOWN -> {
                            captchaCursorY = (captchaCursorY + step).coerceIn(0f, 1f)
                            updateCaptchaCursorPosition(wrap)
                            emitMoveIfDragging()
                            return true
                        }
                        KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                            val tx = captchaCursorX * wv.width
                            val ty = captchaCursorY * wv.height
                            val nowT = android.os.SystemClock.uptimeMillis()
                            if (event.repeatCount == 2) {
                                isCaptchaDragMode = true
                                captchaDragDownTime = nowT
                                (captchaCursorView?.background as? GradientDrawable)?.setColor(Color.rgb(250, 204, 21))
                                captchaTitleTv?.text = "SLIDE MODE (◀ ▶ then OK)"
                                wv.dispatchTouchEvent(MotionEvent.obtain(captchaDragDownTime, nowT, MotionEvent.ACTION_DOWN, tx, ty, 0))
                                return true
                            }
                            if (event.repeatCount == 0) {
                                if (isCaptchaDragMode) {
                                    isCaptchaDragMode = false
                                    (captchaCursorView?.background as? GradientDrawable)?.setColor(Color.argb(210, 229, 9, 20))
                                    captchaTitleTv?.text = "Verify · Hold OK to Slide"
                                    wv.dispatchTouchEvent(MotionEvent.obtain(captchaDragDownTime, nowT, MotionEvent.ACTION_UP, tx, ty, 0))
                                } else {
                                    wv.dispatchTouchEvent(MotionEvent.obtain(nowT, nowT, MotionEvent.ACTION_DOWN, tx, ty, 0))
                                    wv.dispatchTouchEvent(MotionEvent.obtain(nowT, nowT + 40, MotionEvent.ACTION_UP, tx, ty, 0))
                                }
                            }
                            return true
                        }
                        KeyEvent.KEYCODE_BACK -> {
                            hideCaptchaCard()
                            return true
                        }
                    }
                }
            }
            val player = exoPlayer
            when (event.keyCode) {
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                    if (player != null) {
                        if (player.isPlaying) player.pause() else player.play()
                        showControllerTemporarily()
                        return true
                    }
                }
                KeyEvent.KEYCODE_DPAD_CENTER,
                KeyEvent.KEYCODE_ENTER -> {
                    if (!isControllerVisible && player != null) {
                        if (player.isPlaying) player.pause() else player.play()
                        showControllerTemporarily()
                        playPauseBtn?.requestFocus()
                        return true
                    }
                    showControllerTemporarily()
                }
                KeyEvent.KEYCODE_DPAD_LEFT,
                KeyEvent.KEYCODE_MEDIA_REWIND -> {
                    if (!isControllerVisible && player != null) {
                        player.seekTo((player.currentPosition - 10_000L).coerceAtLeast(0L))
                        showControllerTemporarily()
                        return true
                    }
                    if (seekBar?.hasFocus() == true && player != null) {
                        player.seekTo((player.currentPosition - 10_000L).coerceAtLeast(0L))
                        updateTimeAndSeekBar()
                        showControllerTemporarily()
                        return true
                    }
                    showControllerTemporarily()
                }
                KeyEvent.KEYCODE_DPAD_RIGHT,
                KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                    if (!isControllerVisible && player != null) {
                        player.seekTo((player.currentPosition + 10_000L).coerceAtMost(player.duration.coerceAtLeast(0L)))
                        showControllerTemporarily()
                        return true
                    }
                    if (seekBar?.hasFocus() == true && player != null) {
                        player.seekTo((player.currentPosition + 10_000L).coerceAtMost(player.duration.coerceAtLeast(0L)))
                        updateTimeAndSeekBar()
                        showControllerTemporarily()
                        return true
                    }
                    showControllerTemporarily()
                }
                KeyEvent.KEYCODE_DPAD_UP,
                KeyEvent.KEYCODE_DPAD_DOWN -> {
                    if (!isControllerVisible) {
                        showControllerTemporarily()
                        playPauseBtn?.requestFocus()
                        return true
                    }
                    showControllerTemporarily()
                }
                KeyEvent.KEYCODE_BACK -> {
                    saveCurrentProgress()
                    finish()
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun saveCurrentProgress(forceCompleted: Boolean = false) {
        try {
            val player = exoPlayer ?: return
            val key = progressKey ?: return
            val durMs = player.duration
            val posMs = player.currentPosition - subDelayMs
            if (durMs <= 0) return

            val posSec = posMs / 1000L
            val durSec = durMs / 1000L
            val pct = if (forceCompleted) 100 else ((posMs * 100L) / durMs).toInt().coerceIn(0, 100)
            val isWatched = forceCompleted || (durSec - posSec <= 20L)

            StreambertApp.instance.database.playbackProgressDao().upsertSync(
                PlaybackProgressEntity(
                    progressKey = key,
                    percent = pct,
                    positionSec = posSec,
                    durationSec = durSec,
                    watched = isWatched
                )
            )
            ExoProgressBus.listener?.invoke(key, pct, posSec, durSec, isWatched)
        } catch (_: Throwable) {}
    }

    private fun enableImmersiveFullscreen() {
        try {
            WindowCompat.setDecorFitsSystemWindows(window, false)
            WindowInsetsControllerCompat(window, window.decorView).let { controller ->
                controller.hide(WindowInsetsCompat.Type.systemBars())
                controller.systemBarsBehavior =
                    WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } catch (_: Throwable) {}
    }

    override fun onStop() {
        super.onStop()
        saveCurrentProgress()
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N || !isInPictureInPictureMode) {
            exoPlayer?.pause()
        }
    }

    override fun onDestroy() {
        isPlayerActive = false
        stopBackgroundServerProbing()
        mainHandler.removeCallbacks(failoverWatchdogRunnable)
        mainHandler.removeCallbacks(playbackReadyWatchdogRunnable)
        try {
            resolverWebView?.stopLoading()
            resolverWebView?.destroy()
        } catch (_: Throwable) {}
        resolverWebView = null
        mainHandler.removeCallbacks(hideControllerRunnable)
        mainHandler.removeCallbacks(hideMetersRunnable)
        mainHandler.removeCallbacks(hideLeftSeekRunnable)
        mainHandler.removeCallbacks(hideRightSeekRunnable)
        mainHandler.removeCallbacks(progressRunnable)
        mainHandler.removeCallbacks(uiTickRunnable)
        mainHandler.removeCallbacks(subtitleTickRunnable)
        try {
            exoPlayer?.release()
        } catch (_: Throwable) {}
        exoPlayer = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_PAYLOAD_JSON = "extra_payload_json"
        @Volatile var isPlayerActive: Boolean = false
        var onNeedNextServer: ((String, Long, (String?, String?) -> Unit) -> Unit)? = null
    }
}

object ExoProgressBus {
    var listener: ((String, Int, Long, Long, Boolean) -> Unit)? = null
    var serverSwitchListener: ((String) -> Unit)? = null
    var preferredSourceListener: ((String) -> Unit)? = null
}
