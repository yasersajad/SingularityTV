package com.singularity.tv.player

import android.app.PictureInPictureParams
import android.content.Intent
import android.content.Context
import android.content.res.Configuration
import android.media.AudioManager
import android.view.MotionEvent
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.ClipDrawable
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Rational
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.CaptionStyleCompat
import androidx.media3.ui.PlayerView
import com.singularity.tv.StreambertApp
import com.singularity.tv.data.PlaybackProgressEntity
import com.singularity.tv.webview.AdBlockerInterceptor
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.CopyOnWriteArrayList
import kotlin.concurrent.thread

data class PlayerSubTrack(
    val label: String,
    val lang: String,
    val urlOrPath: String,
    val score: Int = 0
)

data class ParsedSubCue(
    val startMs: Long,
    val endMs: Long,
    val text: String
)

private class VectorIconDrawable(
    private val kind: String,
    private val tintColor: Int = Color.WHITE
) : Drawable() {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = tintColor
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }

    override fun draw(canvas: Canvas) {
        val b = bounds
        val w = b.width().toFloat()
        val h = b.height().toFloat()
        val cx = b.centerX().toFloat()
        val cy = b.centerY().toFloat()
        val s = minOf(w, h)

        when (kind) {
            "back" -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = s * 0.09f
                val path = Path().apply {
                    moveTo(cx + s * 0.24f, cy)
                    lineTo(cx - s * 0.24f, cy)
                    moveTo(cx - s * 0.04f, cy - s * 0.2f)
                    lineTo(cx - s * 0.24f, cy)
                    lineTo(cx - s * 0.04f, cy + s * 0.2f)
                }
                canvas.drawPath(path, paint)
            }
            "play" -> {
                paint.style = Paint.Style.FILL
                val path = Path().apply {
                    moveTo(cx - s * 0.16f, cy - s * 0.24f)
                    lineTo(cx + s * 0.26f, cy)
                    lineTo(cx - s * 0.16f, cy + s * 0.24f)
                    close()
                }
                canvas.drawPath(path, paint)
            }
            "pause" -> {
                paint.style = Paint.Style.FILL
                val barW = s * 0.12f
                val barH = s * 0.44f
                val gap = s * 0.09f
                canvas.drawRoundRect(
                    RectF(cx - gap - barW, cy - barH / 2f, cx - gap, cy + barH / 2f),
                    barW * 0.35f,
                    barW * 0.35f,
                    paint
                )
                canvas.drawRoundRect(
                    RectF(cx + gap, cy - barH / 2f, cx + gap + barW, cy + barH / 2f),
                    barW * 0.35f,
                    barW * 0.35f,
                    paint
                )
            }
            "rew10", "fwd10" -> {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = s * 0.075f
                val r = s * 0.29f
                val oval = RectF(cx - r, cy - r, cx + r, cy + r)
                val topY = cy - r
                val aw = s * 0.11f
                val ah = s * 0.09f
                if (kind == "rew10") {
                    canvas.drawArc(oval, -90f, 275f, false, paint)
                    val arrow = Path().apply {
                        moveTo(cx + aw, topY - ah)
                        lineTo(cx - aw * 0.35f, topY)
                        lineTo(cx + aw, topY + ah)
                    }
                    canvas.drawPath(arrow, paint)
                } else {
                    canvas.drawArc(oval, -90f, -275f, false, paint)
                    val arrow = Path().apply {
                        moveTo(cx - aw, topY - ah)
                        lineTo(cx + aw * 0.35f, topY)
                        lineTo(cx - aw, topY + ah)
                    }
                    canvas.drawPath(arrow, paint)
                }
                paint.style = Paint.Style.FILL
                paint.textAlign = Paint.Align.CENTER
                paint.textSize = s * 0.23f
                paint.typeface = Typeface.DEFAULT_BOLD
                val fm = paint.fontMetrics
                val ty = cy - (fm.ascent + fm.descent) / 2f + s * 0.02f
                canvas.drawText("10", cx, ty, paint)
            }
        }
    }

    override fun setAlpha(alpha: Int) {
        paint.alpha = alpha
    }

    override fun setColorFilter(colorFilter: ColorFilter?) {
        paint.colorFilter = colorFilter
    }

    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}


private class VerticalGestureMeterView(
    context: Context,
    private val isBrightness: Boolean
) : View(context) {
    private var level: Float = 0.5f
    private val trackPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(95, 255, 255, 255)
        setShadowLayer(4f, 0f, 2f, Color.argb(160, 0, 0, 0))
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = if (isBrightness) Color.rgb(250, 204, 21) else Color.rgb(229, 9, 20)
        setShadowLayer(6f, 0f, 2f, Color.argb(160, 0, 0, 0))
    }
    private val iconPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        setShadowLayer(5f, 0f, 2f, Color.argb(180, 0, 0, 0))
    }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setShadowLayer(5f, 0f, 2f, Color.argb(190, 0, 0, 0))
    }

    fun setLevel(value: Float) {
        level = value.coerceIn(0f, 1f)
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f

        val iconCy = w * 0.62f
        val iconS = w * 0.46f
        if (isBrightness) {
            iconPaint.style = Paint.Style.FILL
            val coreR = iconS * (0.20f + 0.10f * level)
            canvas.drawCircle(cx, iconCy, coreR, iconPaint)
            iconPaint.style = Paint.Style.STROKE
            iconPaint.strokeWidth = w * 0.055f
            val rayInner = coreR + iconS * 0.12f
            val rayOuter = rayInner + iconS * (0.06f + 0.18f * level)
            val rotOffset = level * 45f
            for (i in 0 until 8) {
                val angle = Math.toRadians((i * 45f + rotOffset).toDouble())
                val sx = cx + (rayInner * Math.cos(angle)).toFloat()
                val sy = iconCy + (rayInner * Math.sin(angle)).toFloat()
                val ex = cx + (rayOuter * Math.cos(angle)).toFloat()
                val ey = iconCy + (rayOuter * Math.sin(angle)).toFloat()
                canvas.drawLine(sx, sy, ex, ey, iconPaint)
            }
        } else {
            iconPaint.style = Paint.Style.FILL
            val spk = Path().apply {
                moveTo(cx - iconS * 0.28f, iconCy - iconS * 0.14f)
                lineTo(cx - iconS * 0.10f, iconCy - iconS * 0.14f)
                lineTo(cx + iconS * 0.08f, iconCy - iconS * 0.30f)
                lineTo(cx + iconS * 0.08f, iconCy + iconS * 0.30f)
                lineTo(cx - iconS * 0.10f, iconCy + iconS * 0.14f)
                lineTo(cx - iconS * 0.28f, iconCy + iconS * 0.14f)
                close()
            }
            canvas.drawPath(spk, iconPaint)
            iconPaint.style = Paint.Style.STROKE
            iconPaint.strokeWidth = w * 0.055f
            if (level <= 0.01f) {
                val xOff = iconS * 0.18f
                canvas.drawLine(cx + xOff, iconCy - iconS * 0.12f, cx + xOff + iconS * 0.18f, iconCy + iconS * 0.12f, iconPaint)
                canvas.drawLine(cx + xOff + iconS * 0.18f, iconCy - iconS * 0.12f, cx + xOff, iconCy + iconS * 0.12f, iconPaint)
            } else {
                val waves = if (level > 0.66f) 3 else if (level > 0.33f) 2 else 1
                for (i in 1..waves) {
                    val wr = iconS * (0.14f * i)
                    val oval = RectF(cx + iconS * 0.05f - wr * 0.3f, iconCy - wr, cx + iconS * 0.05f + wr, iconCy + wr)
                    canvas.drawArc(oval, -45f, 90f, false, iconPaint)
                }
            }
        }

        val barW = w * 0.18f
        val barTop = iconCy + iconS * 0.72f
        val barBottom = h - w * 0.68f
        val barLeft = cx - barW / 2f
        val barRight = cx + barW / 2f
        val barRadius = barW / 2f
        canvas.drawRoundRect(RectF(barLeft, barTop, barRight, barBottom), barRadius, barRadius, trackPaint)

        val fillH = (barBottom - barTop) * level
        if (fillH > 1f) {
            canvas.drawRoundRect(
                RectF(barLeft, barBottom - fillH, barRight, barBottom),
                barRadius,
                barRadius,
                fillPaint
            )
        }

        textPaint.textSize = w * 0.24f
        canvas.drawText("${(level * 100).toInt()}%", cx, h - w * 0.24f, textPaint)
    }
}

class NativeExoPlayerActivity : AppCompatActivity() {

    private var exoPlayer: ExoPlayer? = null
    private var playerView: PlayerView? = null
    private var resolverWebView: WebView? = null
    private var captchaCardContainer: LinearLayout? = null
    private var captchaCursorView: View? = null
    private var isCaptchaCardVisible: Boolean = false
    private var isCaptchaDragMode: Boolean = false
    private var captchaDragDownTime: Long = 0L
    private var captchaTitleTv: TextView? = null
    private var captchaCursorX: Float = 0.5f
    private var captchaCursorY: Float = 0.5f
    private var isCaptchaCursorActive = true
    private var captchaReloadBtn: Button? = null
    private var bottomActionsRow: LinearLayout? = null
    private var rootFrameLayout: FrameLayout? = null
    private var activeResolverEmbedUrl: String = ""
    private var controllerOverlay: FrameLayout? = null
    private var subBtn: Button? = null
    private var titleView: TextView? = null
    private var serverBadgeView: TextView? = null
    private val multiEmbedSubServers = mutableListOf<Pair<String, String>>()
    private var switchServerBtn: Button? = null
    private var seriesTitleStr: String = ""
    private var totalEpisodesInSeason: Int = 0
    private var introStartSec: Double = -1.0
    private var introEndSec: Double = -1.0
    private var recapStartSec: Double = -1.0
    private var recapEndSec: Double = -1.0
    private var outroStartSec: Double = -1.0
    private var activeSkipTargetSec: Double = -1.0
    private var nextEpDismissed: Boolean = false
    private var nextEpCountdownSec: Int = 10
    private var skipSegmentBtn: Button? = null
    private var nextEpCard: LinearLayout? = null
    private var nextEpTitleTv: TextView? = null
    private var nextEpCountdownTv: TextView? = null
    private val verifiedServers = java.util.concurrent.ConcurrentHashMap<String, Pair<String, String>>()
    private val probedFailedServers = java.util.Collections.synchronizedSet(HashSet<String>())
    private val probeQueue = java.util.ArrayDeque<String>()
    private val probeWebViews = mutableListOf<WebView>()
    private val probeSlotSources = mutableMapOf<WebView, String>()
    private val probeTimeoutRunnables = mutableMapOf<WebView, Runnable>()
    private var isProbingActive: Boolean = false
    private var subtitleOverlayView: TextView? = null
    private var playPauseBtn: ImageButton? = null
    private var seekBar: SeekBar? = null
    private var durationView: TextView? = null
    private var currentPosView: TextView? = null
    private var isScrubbing: Boolean = false
    private var isControllerVisible: Boolean = true
    private var brightnessMeter: VerticalGestureMeterView? = null
    private var volumeMeter: VerticalGestureMeterView? = null
    private var leftSeekBadge: TextView? = null
    private var rightSeekBadge: TextView? = null
    private var currentBrightness: Float = 0.65f
    private var accumSeekLeftSec: Int = 0
    private var accumSeekRightSec: Int = 0
    private var gestureActiveMode: Int = 0
    private var gestureDownTimeMs: Long = 0L
    private var gestureStartX: Float = 0f
    private var gestureStartY: Float = 0f
    private var gestureStartVal: Float = 0f
    private var lastTapTimeMs: Long = 0L
    private var lastTapSide: Int = 0
    private var activeSeekSide: Int = 0
    private var lastSeekEventTimeMs: Long = 0L
    private var audioManager: AudioManager? = null

    private var streamUrl: String = ""
    private var streamTitle: String = "SingularityTV"
    private var progressKey: String? = null
    private var startTimeSec: Long = 0L
    private var currentSpeed: Float = 1.0f
    private var retryCount: Int = 0
    private var serverFailoverAttempts: Int = 0
    private var isSwitchingServer: Boolean = false
    private var currentSource: String = "hnembed"
    private var rawPayload: JSONObject = JSONObject()

    private var imdbId: String = ""
    private var tmdbId: String = ""
    private var mediaType: String = "movie"
    private var seasonNum: Int = 1
    private var episodeNum: Int = 1
    private var preferredLang: String = "ar"
    private var activeQualityTag: String = ""

    private val availableSubs = CopyOnWriteArrayList<PlayerSubTrack>()
    private val activeParsedCues = CopyOnWriteArrayList<ParsedSubCue>()
    private var activeSubIndex: Int = -1
    private var subDelayMs: Long = 0L
    private var subTextSizeSp: Float = 22f
    private var subTextColorHex: String = "#FFFFFF"
    private var subBgStyleMode: String = "dark"

    private val mainHandler = Handler(Looper.getMainLooper())

    private val hideMetersRunnable = Runnable {
        brightnessMeter?.let { m ->
            m.animate().cancel()
            if (m.visibility == View.VISIBLE) {
                m.animate().alpha(0f).setDuration(200).withEndAction {
                    m.visibility = View.GONE
                }.start()
            }
        }
        volumeMeter?.let { m ->
            m.animate().cancel()
            if (m.visibility == View.VISIBLE) {
                m.animate().alpha(0f).setDuration(200).withEndAction {
                    m.visibility = View.GONE
                }.start()
            }
        }
    }

    private val singleTapToggleRunnable = Runnable {
        if (isControllerVisible) {
            setControllerVisible(false)
        } else {
            showControllerTemporarily()
        }
    }

    private val hideLeftSeekRunnable = Runnable {
        accumSeekLeftSec = 0
        if (activeSeekSide == -1) activeSeekSide = 0
        leftSeekBadge?.let { b ->
            b.animate().cancel()
            b.animate().alpha(0f).scaleX(0.88f).scaleY(0.88f).setDuration(180).withEndAction {
                b.visibility = View.GONE
                b.alpha = 0f
            }.start()
        }
    }

    private val hideRightSeekRunnable = Runnable {
        accumSeekRightSec = 0
        if (activeSeekSide == 1) activeSeekSide = 0
        rightSeekBadge?.let { b ->
            b.animate().cancel()
            b.animate().alpha(0f).scaleX(0.88f).scaleY(0.88f).setDuration(180).withEndAction {
                b.visibility = View.GONE
                b.alpha = 0f
            }.start()
        }
    }

    private val serverOrder = listOf("hnembed")
    private val streamIsHlsMap = HashMap<String, Boolean>()
    private val streamRefererMap = HashMap<String, String>()
    private var pendingNextSource: String = ""

    private val recentlyUpdatedSources = setOf(
        "rivestream", "vidsrcxyz", "vidsrcme", "vidsrcin",
        "vidsrcpm", "vidsrcicu", "moviesapi", "nontongo"
    )
    private val serverCatalogVersion = "v274"

    private fun serverStatusKey(sourceId: String): String {
        val pk = progressKey ?: (if (imdbId.isNotEmpty()) imdbId else streamTitle)
        return "srv_status_${pk}_$sourceId"
    }

    private fun recordServerStatus(sourceId: String, status: String) {
        if (sourceId.isBlank()) return
        try {
            val prefs = getSharedPreferences("singularity_server_status", Context.MODE_PRIVATE)
            prefs.edit()
                .putString(serverStatusKey(sourceId), status)
                .putString(serverStatusKey(sourceId) + "_ver", serverCatalogVersion)
                .apply()
        } catch (_: Throwable) {}
    }

    private fun getServerStatus(sourceId: String): String {
        return try {
            val prefs = getSharedPreferences("singularity_server_status", Context.MODE_PRIVATE)
            val st = prefs.getString(serverStatusKey(sourceId), "unknown") ?: "unknown"
            val ver = prefs.getString(serverStatusKey(sourceId) + "_ver", "") ?: ""
            when (st) {
                "working" -> "working"
                "failed" -> if (ver != serverCatalogVersion) { if (recentlyUpdatedSources.contains(sourceId)) "updated" else "unknown" } else "failed"
                else -> if (recentlyUpdatedSources.contains(sourceId)) "updated" else "unknown"
            }
        } catch (_: Throwable) {
            if (recentlyUpdatedSources.contains(sourceId)) "updated" else "unknown"
        }
    }

    private fun startResolvingInitialSource() {
        isSwitchingServer = true
        serverFailoverAttempts = 0
        pendingNextSource = currentSource
        serverBadgeView?.text = currentSource
        Toast.makeText(this, "Connecting to $currentSource...", Toast.LENGTH_SHORT).show()
        val embedUrl = buildEmbedUrlForSource(currentSource)
        activeResolverEmbedUrl = embedUrl
        mainHandler.removeCallbacks(failoverWatchdogRunnable)
        mainHandler.postDelayed({
            if (isSwitchingServer && !isCaptchaCardVisible && streamUrl.isBlank() && !isFinishing && !isDestroyed) {
                showCaptchaCard("hnembed")
            }
        }, 10000L)
        if (embedUrl.isNotEmpty() && resolverWebView != null) {
            try {
                val parsed = Uri.parse(embedUrl)
                val originRef = "${parsed.scheme}://${parsed.host}/"
                resolverWebView?.stopLoading()
                resolverWebView?.loadUrl(embedUrl, mapOf("Referer" to originRef))
            } catch (_: Throwable) {}
        }
    }

    private fun showCaptchaCard(sourceId: String) {
        val root = rootFrameLayout ?: return
        val wv = resolverWebView ?: return
        isCaptchaCardVisible = true
        mainHandler.removeCallbacks(failoverWatchdogRunnable)
        if (captchaCardContainer == null) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(10), dp(12), dp(12))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(16).toFloat()
                    setColor(Color.argb(245, 16, 20, 30))
                    setStroke(dp(1), Color.argb(55, 255, 255, 255))
                }
                layoutParams = FrameLayout.LayoutParams(minOf(resources.displayMetrics.widthPixels - dp(24), dp(350)), minOf(resources.displayMetrics.heightPixels - dp(36), dp(280)), Gravity.CENTER)
            }
            val hdr = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(4), 0, dp(4), dp(8))
            }
            val titleTv = TextView(this).apply {
                text = "HnEmbed · Verify & Select Server"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                typeface = Typeface.DEFAULT_BOLD
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            captchaTitleTv = titleTv
            val skipBtn = Button(this).apply {
                text = "↻ Reload"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                isFocusable = true
                isClickable = true
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) defaultFocusHighlightEnabled = false
                fun makeReloadBg(focused: Boolean) = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(10).toFloat()
                    setColor(if (focused) Color.argb(95, 255, 255, 255) else Color.argb(45, 255, 255, 255))
                    if (focused) setStroke(dp(2), Color.WHITE)
                }
                background = makeReloadBg(false)
                setOnFocusChangeListener { v, hasFocus ->
                    v.background = makeReloadBg(hasFocus)
                    v.animate().scaleX(if (hasFocus) 1.08f else 1f).scaleY(if (hasFocus) 1.08f else 1f).setDuration(120).start()
                }
                setOnClickListener {
                    mainHandler.removeCallbacks(failoverWatchdogRunnable)
                    currentSource = "hnembed"
                    pendingNextSource = "hnembed"
                    isSwitchingServer = true
                    val embedUrl = buildEmbedUrlForSource("hnembed")
                    activeResolverEmbedUrl = embedUrl
                    if (embedUrl.isNotEmpty()) {
                        try {
                            val parsed = Uri.parse(embedUrl)
                            val originRef = "${parsed.scheme}://${parsed.host}/"
                            resolverWebView?.stopLoading()
                            resolverWebView?.loadUrl(embedUrl, mapOf("Referer" to originRef))
                        } catch (_: Throwable) {}
                    }
                    Toast.makeText(this@NativeExoPlayerActivity, "Reloading HnEmbed...", Toast.LENGTH_SHORT).show()
                }
            }
            captchaReloadBtn = skipBtn
            hdr.addView(titleTv)
            hdr.addView(skipBtn)
            card.addView(hdr)

            val wvWrap = FrameLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
            }
            val cursor = View(this).apply {
                layoutParams = FrameLayout.LayoutParams(dp(18), dp(18))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(Color.argb(210, 229, 9, 20))
                    setStroke(dp(2), Color.WHITE)
                }
            }
            captchaCursorView = cursor
            card.addView(wvWrap)
            captchaCardContainer = card
            root.addView(card)
            wvWrap.addView(cursor)
        }
        val card = captchaCardContainer ?: return
        val wvWrap = card.getChildAt(1) as? FrameLayout ?: return
        (wv.parent as? ViewGroup)?.removeView(wv)
        wv.layoutParams = FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        wv.alpha = 1f
        wv.isClickable = true
        wv.isFocusable = true
        wv.settings.loadsImagesAutomatically = true
        wvWrap.addView(wv, 0)
        isCaptchaCursorActive = true
        captchaCursorView?.alpha = 1.0f
        card.visibility = View.VISIBLE
        card.bringToFront()
        updateCaptchaCursorPosition(wvWrap)
    }

    private fun updateCaptchaCursorPosition(wrap: FrameLayout) {
        val cursor = captchaCursorView ?: return
        val w = (wrap.width - dp(18)).coerceAtLeast(1)
        val h = (wrap.height - dp(18)).coerceAtLeast(1)
        cursor.translationX = captchaCursorX * w
        cursor.translationY = captchaCursorY * h
    }

    private fun hideCaptchaCard() {
        if (!isCaptchaCardVisible) return
        isCaptchaCardVisible = false
        isCaptchaDragMode = false
        captchaCardContainer?.visibility = View.GONE
        val root = rootFrameLayout ?: return
        val wv = resolverWebView ?: return
        (wv.parent as? ViewGroup)?.removeView(wv)
        wv.layoutParams = FrameLayout.LayoutParams(dp(200), dp(120), Gravity.BOTTOM or Gravity.START)
        wv.alpha = 0.01f
        wv.isClickable = false
        wv.isFocusable = false
        root.addView(wv, 0)
    }

    private fun resolveTmdbIdIfNeeded() {
        if (tmdbId.isNotEmpty() || !imdbId.startsWith("tt")) return
        thread(start = true) {
            try {
                val prop = if (mediaType.equals("tv", ignoreCase = true)) "P4983" else "P4947"
                val sparql = "SELECT ?tid WHERE { ?item wdt:P345 \"$imdbId\" . ?item wdt:$prop ?tid . } LIMIT 1"
                val req = Request.Builder()
                    .url("https://query.wikidata.org/sparql?format=json&query=" + URLEncoder.encode(sparql, "UTF-8"))
                    .header("Accept", "application/sparql-results+json")
                    .build()
                StreambertApp.instance.okHttpClient.newCall(req).execute().use { res ->
                    if (res.isSuccessful) {
                        val root = JSONObject(res.body?.string() ?: "{}")
                        val bindings = root.optJSONObject("results")?.optJSONArray("bindings")
                        val valStr = bindings?.optJSONObject(0)?.optJSONObject("tid")?.optString("value", "") ?: ""
                        if (valStr.isNotEmpty()) {
                            tmdbId = valStr
                        }
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    private fun buildEmbedUrlForSource(sourceId: String): String {
        val im = imdbId.ifEmpty { rawPayload.optString("imdbId", "") }.trim()
        val tm = tmdbId.ifEmpty { im }.trim()
        if (im.isEmpty() && tm.isEmpty()) return ""
        val isTv = mediaType.equals("tv", ignoreCase = true)
        val s = seasonNum.coerceAtLeast(1)
        val e = episodeNum.coerceAtLeast(1)
        return when (sourceId) {
            "singularity" -> if (isTv) "https://proxy.garageband.rocks/embed/tv/$im/$s/$e" else "https://proxy.garageband.rocks/embed/movie/$im"
            "vidsrcmeru" -> if (isTv) "https://vidsrcme.ru/embed/tv?imdb=$im&season=$s&episode=$e&autoplay=1" else "https://vidsrcme.ru/embed/movie?imdb=$im&autoplay=1"
            "vidsrcto" -> if (isTv) "https://vidsrc.to/embed/tv/$im/$s/$e" else "https://vidsrc.to/embed/movie/$im"
            "vidlink" -> if (isTv) "https://vidlink.pro/tv/$tm/$s/$e?autoplay=true" else "https://vidlink.pro/movie/$tm?autoplay=true"
            "videasy" -> if (isTv) "https://player.videasy.net/tv/$tm/$s/$e" else "https://player.videasy.net/movie/$tm"
            "vidsrccc" -> if (isTv) "https://vidsrc.cc/v2/embed/tv/$tm/$s/$e?autoPlay=true" else "https://vidsrc.cc/v2/embed/movie/$tm?autoPlay=true"
            "vidsrcxyz" -> if (isTv) "https://vidsrc.xyz/embed/tv/$im/$s-$e" else "https://vidsrc.xyz/embed/movie/$im"
            "vidsrcnet" -> if (isTv) "https://vidsrc.net/embed/tv/$im/$s-$e?autoplay=1" else "https://vidsrc.net/embed/movie/$im?autoplay=1"
            "vidsrcin" -> if (isTv) "https://vidsrc.in/embed/tv/$im/$s-$e" else "https://vidsrc.in/embed/movie/$im"
            "vidsrc" -> if (isTv) "https://vsembed.su/embed/tv/$im/$s/$e?autoplay=1" else "https://vsembed.su/embed/movie/$im?autoplay=1"
            "vidsrcicu" -> if (isTv) "https://vidsrc.icu/embed/tv/$im/$s/$e" else "https://vidsrc.icu/embed/movie/$im"
            "vidfast" -> if (isTv) "https://vidfast.pro/tv/$tm/$s/$e?autoPlay=true" else "https://vidfast.pro/movie/$tm?autoPlay=true"
            "vidnest" -> if (isTv) "https://vidnest.fun/tv/$tm/$s/$e" else "https://vidnest.fun/movie/$tm"
            "autoembed" -> if (isTv) "https://player.autoembed.cc/embed/tv/$tm/$s/$e?server=1" else "https://player.autoembed.cc/embed/movie/$tm?server=1"
            "embedsu" -> if (isTv) "https://embed.su/embed/tv/$tm/$s/$e" else "https://embed.su/embed/movie/$tm"
            "smashy" -> if (isTv) "https://player.smashy.stream/tv/$im?s=$s&e=$e" else "https://player.smashy.stream/movie/$im"
            "hnembed" -> if (isTv) "https://hnembed.cc/embed/tv/${im.ifEmpty { tm }}/$s/$e" else "https://hnembed.cc/embed/movie/${im.ifEmpty { tm }}"
            "superembed" -> if (isTv) "https://multiembed.mov/directstream.php?video_id=$im&s=$s&e=$e" else "https://multiembed.mov/directstream.php?video_id=$im"
            "rivestream" -> if (isTv) "https://rivestream.org/embed?type=tv&id=$tm&season=$s&episode=$e" else "https://rivestream.org/embed?type=movie&id=$tm"
            "moviesapi" -> if (isTv) "https://moviesapi.club/tv/$tm-$s-$e" else "https://moviesapi.club/movie/$tm"
            "vidsrcpro" -> if (isTv) "https://vidsrc.pro/embed/tv/$tm/$s/$e" else "https://vidsrc.pro/embed/movie/$tm"
            "vidsrcvip" -> if (isTv) "https://vidsrc.vip/embed/tv/$tm/$s/$e" else "https://vidsrc.vip/embed/movie/$tm"
            "vidsrcrip" -> if (isTv) "https://vidsrc.rip/embed/tv/$tm/$s/$e" else "https://vidsrc.rip/embed/movie/$tm"
            "111movies" -> if (isTv) "https://111movies.com/tv/$tm/$s/$e" else "https://111movies.com/movie/$tm"
            "vidjoy" -> if (isTv) "https://vidjoy.pro/embed/tv/$tm/$s/$e" else "https://vidjoy.pro/embed/movie/$tm"
            "2embed" -> if (isTv) "https://www.2embed.cc/embedtv/$im&s=$s&e=$e" else "https://www.2embed.cc/embed/$im"
            "embed2" -> if (isTv) "https://www.2embed.stream/embed/tv/$im/$s/$e" else "https://www.2embed.stream/embed/movie/$im"
            "nontongo" -> if (isTv) "https://www.NontonGo.win/embed/tv?id=$im&s=$s&e=$e" else "https://www.NontonGo.win/embed/movie?id=$im"
            else -> if (isTv) "https://vidsrcme.ru/embed/tv?imdb=$im&season=$s&episode=$e" else "https://vidsrcme.ru/embed/movie?imdb=$im"
        }
    }

    private fun getDefaultRefererForSource(sourceId: String): String {
        val u = buildEmbedUrlForSource(sourceId)
        if (u.startsWith("http")) {
            try {
                val parsed = Uri.parse(u)
                return "${parsed.scheme}://${parsed.host}/"
            } catch (_: Throwable) {}
        }
        return "https://vidlink.pro/"
    }

    private val playbackReadyWatchdogRunnable = Runnable {
        val p = exoPlayer
        if (!isFinishing && !isDestroyed && p != null && p.playbackState != Player.STATE_READY && !streamUrl.startsWith("/")) {
            isSwitchingServer = false
            triggerNextServerFailover()
        }
    }

    private val failoverWatchdogRunnable = Runnable {
        if (isSwitchingServer && !isFinishing && !isDestroyed) {
            isSwitchingServer = false
            if (pendingNextSource.isNotEmpty()) {
                currentSource = pendingNextSource
            }
            triggerNextServerFailover()
        }
    }

    private fun applyResolvedStream(newUrl: String, newSource: String, refererFallback: String) {
        if (isFinishing || isDestroyed || newUrl.isBlank()) return
        if (newUrl == streamUrl && exoPlayer?.playbackState == Player.STATE_READY) return
        mainHandler.removeCallbacks(failoverWatchdogRunnable)
        mainHandler.removeCallbacks(playbackReadyWatchdogRunnable)
        isSwitchingServer = false
        hideCaptchaCard()
        try {
            resolverWebView?.loadUrl("about:blank")
        } catch (_: Throwable) {}
        val curPosSec = ((exoPlayer?.currentPosition ?: 0L) / 1000L).coerceAtLeast(startTimeSec)
        streamUrl = newUrl
        currentSource = newSource
        startTimeSec = curPosSec
        retryCount = 0
        rawPayload.put("url", newUrl)
        rawPayload.put("currentSource", newSource)
        if (refererFallback.isNotEmpty()) {
            rawPayload.put("referer", refererFallback)
        }
        initializeExoPlayer(rawPayload)
    }

    private fun updateSwitchServerButtonText() {
        val readyCount = verifiedServers.keys.count { it != currentSource }
        switchServerBtn?.text = if (readyCount > 0) "Switch Server ($readyCount)" else "Switch Server"
    }

    private fun bestVerifiedServer(excluding: String): Triple<String, String, String>? {
        val curIdx = serverOrder.indexOf(excluding)
        data class Cand(val idx: Int, val src: String, val url: String, val ref: String, val isHls: Boolean)
        val cands = mutableListOf<Cand>()
        for ((src, pair) in verifiedServers) {
            if (src == excluding) continue
            val idx = serverOrder.indexOf(src).let { if (it >= 0) it else 999 }
            val l = pair.first.lowercase()
            val isHls = l.contains(".m3u8") || l.contains(".mpd")
            cands.add(Cand(idx, src, pair.first, pair.second, isHls))
        }
        if (cands.isEmpty()) return null
        cands.sortWith(Comparator { a, b ->
            if (a.isHls != b.isHls) return@Comparator if (a.isHls) -1 else 1
            val aAfter = if (a.idx > curIdx) 0 else 1
            val bAfter = if (b.idx > curIdx) 0 else 1
            if (aAfter != bAfter) return@Comparator aAfter - bAfter
            a.idx - b.idx
        })
        val pick = cands[0]
        return Triple(pick.src, pick.url, pick.ref)
    }

    private fun handleSwitchServer() {
        showControllerTemporarily()
        val items = mutableListOf<String>()
        for (s in multiEmbedSubServers) items.add(s.first)
        items.add("Open HnEmbed Window")
        items.add("Reload HnEmbed")
        showStyledMenuDialog("HnEmbed Servers", items.toTypedArray()) { idx ->
            if (idx < multiEmbedSubServers.size) {
                val chosen = multiEmbedSubServers[idx]
                isSwitchingServer = true
                currentSource = "hnembed"
                pendingNextSource = "hnembed"
                resolverWebView?.evaluateJavascript("(function(){var el=document.querySelector('[data-s-idx=\"${chosen.second}\"]');if(el)el.click();})();", null)
                showCaptchaCard("hnembed")
                Toast.makeText(this, "Selected ${chosen.first}", Toast.LENGTH_SHORT).show()
            } else if (idx == multiEmbedSubServers.size) {
                isSwitchingServer = true
                currentSource = "hnembed"
                pendingNextSource = "hnembed"
                val curUrl = resolverWebView?.url ?: ""
                if (curUrl.isEmpty() || curUrl == "about:blank") {
                    val embedUrl = buildEmbedUrlForSource("hnembed")
                    activeResolverEmbedUrl = embedUrl
                    if (embedUrl.isNotEmpty()) {
                        try {
                            val parsed = Uri.parse(embedUrl)
                            resolverWebView?.loadUrl(embedUrl, mapOf("Referer" to "${parsed.scheme}://${parsed.host}/"))
                        } catch (_: Throwable) {}
                    }
                }
                showCaptchaCard("hnembed")
            } else {
                isSwitchingServer = true
                currentSource = "hnembed"
                pendingNextSource = "hnembed"
                val embedUrl = buildEmbedUrlForSource("hnembed")
                activeResolverEmbedUrl = embedUrl
                if (embedUrl.isNotEmpty()) {
                    try {
                        val parsed = Uri.parse(embedUrl)
                        resolverWebView?.stopLoading()
                        resolverWebView?.loadUrl(embedUrl, mapOf("Referer" to "${parsed.scheme}://${parsed.host}/"))
                    } catch (_: Throwable) {}
                }
                showCaptchaCard("hnembed")
            }
        }
    }

    private fun startBackgroundServerProbing() {
        if (isProbingActive || isFinishing || isDestroyed || streamUrl.startsWith("/")) return
        val root = rootFrameLayout ?: return
        isProbingActive = true
        probeQueue.clear()
        for (src in serverOrder) {
            if (src != currentSource && !probedFailedServers.contains(src) && !verifiedServers.containsKey(src)) {
                probeQueue.addLast(src)
            }
        }
        if (probeQueue.isEmpty()) return
        val slotCount = minOf(2, probeQueue.size)
        for (i in 0 until slotCount) {
            val pwv = WebView(this).apply {
                layoutParams = FrameLayout.LayoutParams(1, 1, Gravity.BOTTOM or Gravity.START)
                alpha = 0.01f
                isClickable = false
                isFocusable = false
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    mediaPlaybackRequiresUserGesture = true
                    loadsImagesAutomatically = false
                    javaScriptCanOpenWindowsAutomatically = false
                    setSupportMultipleWindows(false)
                    userAgentString = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
                }
                webChromeClient = object : android.webkit.WebChromeClient() {
                    override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean = false
                }
                try {
                    CookieManager.getInstance().setAcceptCookie(true)
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                } catch (_: Throwable) {}
                webViewClient = object : WebViewClient() {
                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                        val u = request?.url?.toString() ?: return false
                        val lower = u.lowercase()
                        if (AdBlockerInterceptor.isBlockedUrl(u) || lower.contains("/vast") || lower.contains("vmap") || lower.contains("preroll") || lower.contains("popunder") || lower.contains("chatmate") || lower.contains("chaturbate") || lower.contains("stripchat")) {
                            return true
                        }
                        if (request.isForMainFrame && !lower.contains("hnembed") && !lower.contains("streamingnow") && !lower.contains("cloudflare") && !lower.contains("recaptcha") && !lower.contains("hcaptcha") && !lower.contains("google") && !lower.contains("dood") && !lower.contains("lulu") && !lower.contains("voe") && !lower.contains("filemoon") && !lower.contains("streamwish") && !lower.contains("vidhide") && !lower.contains("mixdrop")) {
                            return true
                        }
                        return false
                    }
                    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                        val u = request?.url?.toString() ?: return null
                        val lower = u.lowercase()
                        val isBadClip = listOf("promo", "teaser", "preroll", "/ad_", "_ad_", "/ads/", "banner", "trailer", "preview", "bumper", "doubleclick", "vast", "vmap").any { lower.contains(it) }
                        val hasRangeHeader = request.requestHeaders?.keys?.any { it.equals("Range", ignoreCase = true) } == true
                        val isSecFetchVideo = request.requestHeaders?.entries?.any { it.key.equals("Sec-Fetch-Dest", ignoreCase = true) && it.value.equals("video", ignoreCase = true) } == true
                        val isNonMediaAsset = listOf(".js", ".css", ".png", ".jpg", ".jpeg", ".webp", ".gif", ".svg", ".woff", ".ttf", ".vtt", ".srt", ".ts", ".m4s", ".aac", ".html", ".json").any { lower.substringBefore("?").endsWith(it) }
                        val isHlsUrl = lower.contains(".m3u8") || lower.contains(".m3u") || lower.contains("master.txt") || lower.contains("playlist.txt") || lower.contains("/hls/") || lower.contains("/hls2/") || lower.contains("/manifest") || lower.contains("type=hls")
                        val isVideo = !isBadClip && !isNonMediaAsset && (isSecFetchVideo || isHlsUrl || lower.contains(".mpd") || lower.contains("mime=video") || lower.contains("videoplayback") || lower.contains("googleusercontent.com") || lower.contains("googlevideo.com") || lower.contains(".webm") || lower.contains(".mkv") || (lower.contains(".mp4") && !lower.contains("favicon") && !lower.contains("logo") && !lower.contains("blank")) || hasRangeHeader)
                        if (isVideo) {
                            val hdrs = HashMap<String, String>(request.requestHeaders ?: emptyMap())
                            AdBlockerInterceptor.streamHeadersMap[u] = hdrs
                            if (isHlsUrl) streamIsHlsMap[u] = true
                            val reqRef = hdrs.entries.firstOrNull { it.key.equals("referer", ignoreCase = true) }?.value ?: activeResolverEmbedUrl
                            if (reqRef.isNotEmpty()) streamRefererMap[u] = reqRef
                            mainHandler.post {
                                val src = probeSlotSources[this@apply] ?: return@post
                                if (probedFailedServers.contains(src)) return@post
                                val ref = getDefaultRefererForSource(src)
                                verifiedServers[src] = Pair(u, ref)
                                updateSwitchServerButtonText()
                                if (isSwitchingServer && streamUrl.isBlank()) {
                                    applyResolvedStream(u, src, ref)
                                }
                                advanceProbeSlot(this@apply)
                            }
                        } else if (AdBlockerInterceptor.isBlockedUrl(u)) {
                            return AdBlockerInterceptor.createEmptyResponse()
                        }
                        return super.shouldInterceptRequest(view, request)
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        super.onPageFinished(view, url)
                        if (view == null || url == null || url.startsWith("about:")) return
                        val probeJs = "(function(){try{var t=(document.title||'')+' '+(document.body?document.body.innerText.slice(0,500):'');var l=t.toLowerCase();if(l.indexOf('no sources')!==-1||l.indexOf('try again later')!==-1||l.indexOf('404 not found')!==-1||l.indexOf('502 bad gateway')!==-1||l.indexOf('media not found')!==-1||l.indexOf('video not found')!==-1||l.indexOf('not available')!==-1){return 'DEAD';}if(l.indexOf('just a moment')!==-1||l.indexOf('verify you are human')!==-1||l.indexOf('security check')!==-1||!!document.querySelector('iframe[src*=turnstile],iframe[src*=challenge],iframe[src*=captcha],.cf-turnstile,.g-recaptcha,.h-captcha')){return 'CHALLENGE';}document.querySelectorAll('video').forEach(function(v){v.muted=true;try{v.pause();}catch(e){}});document.querySelectorAll('#pl_but,.play,.btn-play,[class*=play],button').forEach(function(b){try{b.click();}catch(e){}});}catch(e){}return '';})()"
                        view.evaluateJavascript(probeJs) { res ->
                            if (res != null && res.contains("DEAD")) {
                                val src = probeSlotSources[view]
                                if (src != null) probedFailedServers.add(src)
                                advanceProbeSlot(view)
                            } else if (res != null && res.contains("CHALLENGE")) {
                                advanceProbeSlot(view)
                            }
                        }
                    }
                }
            }
            probeWebViews.add(pwv)
            root.addView(pwv, 0)
            advanceProbeSlot(pwv)
        }
    }

    private fun advanceProbeSlot(pwv: WebView) {
        probeTimeoutRunnables.remove(pwv)?.let { mainHandler.removeCallbacks(it) }
        probeSlotSources.remove(pwv)
        try { pwv.stopLoading() } catch (_: Throwable) {}
        while (probeQueue.isNotEmpty() && !isFinishing && !isDestroyed) {
            val nextSrc = probeQueue.removeFirst()
            if (nextSrc == currentSource || probedFailedServers.contains(nextSrc) || verifiedServers.containsKey(nextSrc)) continue
            val embed = buildEmbedUrlForSource(nextSrc)
            if (embed.isEmpty()) continue
            probeSlotSources[pwv] = nextSrc
            try {
                val parsed = Uri.parse(embed)
                val originRef = "${parsed.scheme}://${parsed.host}/"
                pwv.loadUrl(embed, mapOf("Referer" to originRef))
            } catch (_: Throwable) {
                probedFailedServers.add(nextSrc)
                continue
            }
            val timeoutRun = Runnable {
                val failedSrc = probeSlotSources[pwv]
                if (failedSrc != null) probedFailedServers.add(failedSrc)
                advanceProbeSlot(pwv)
            }
            probeTimeoutRunnables[pwv] = timeoutRun
            mainHandler.postDelayed(timeoutRun, 6500L)
            return
        }
        try { pwv.loadUrl("about:blank") } catch (_: Throwable) {}
    }

    private fun stopBackgroundServerProbing() {
        isProbingActive = false
        probeQueue.clear()
        for (r in probeTimeoutRunnables.values) mainHandler.removeCallbacks(r)
        probeTimeoutRunnables.clear()
        probeSlotSources.clear()
        for (pwv in probeWebViews) {
            try {
                pwv.stopLoading()
                (pwv.parent as? ViewGroup)?.removeView(pwv)
                pwv.destroy()
            } catch (_: Throwable) {}
        }
        probeWebViews.clear()
    }

    private fun triggerNextServerFailover() {
        if (isFinishing || isDestroyed || streamUrl.startsWith("/") || isSwitchingServer) return
        val best = bestVerifiedServer(currentSource)
        if (best != null) {
            applyResolvedStream(best.second, best.first, best.third)
            updateSwitchServerButtonText()
            return
        }
        if (serverOrder.size == 1 && serverOrder.firstOrNull() == "hnembed") {
            isSwitchingServer = true
            currentSource = "hnembed"
            pendingNextSource = "hnembed"
            val curUrl = resolverWebView?.url ?: ""
            if (curUrl.isEmpty() || curUrl == "about:blank") {
                val embedUrl = buildEmbedUrlForSource("hnembed")
                activeResolverEmbedUrl = embedUrl
                if (embedUrl.isNotEmpty()) {
                    try {
                        val parsed = Uri.parse(embedUrl)
                        resolverWebView?.loadUrl(embedUrl, mapOf("Referer" to "${parsed.scheme}://${parsed.host}/"))
                    } catch (_: Throwable) {}
                }
            }
            Toast.makeText(this@NativeExoPlayerActivity, "Pick another server from Servers ▾", Toast.LENGTH_SHORT).show()
            showCaptchaCard("hnembed")
            return
        }
        if (serverFailoverAttempts >= serverOrder.size) {
            Toast.makeText(
                this@NativeExoPlayerActivity,
                "All servers tried — tap Switch Server to retry",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        isSwitchingServer = true
        serverFailoverAttempts++
        val resumeSec = ((exoPlayer?.currentPosition ?: 0L) / 1000L).coerceAtLeast(startTimeSec)
        startTimeSec = resumeSec
        val idx = serverOrder.indexOf(currentSource)
        var nextExpected = serverOrder[(idx + 1) % serverOrder.size]
        for (step in 1..serverOrder.size) {
            val cand = serverOrder[(idx + step) % serverOrder.size]
            if (!probedFailedServers.contains(cand)) {
                nextExpected = cand
                break
            }
        }
        pendingNextSource = nextExpected
        serverBadgeView?.text = nextExpected
        val embedUrl = buildEmbedUrlForSource(nextExpected)
        activeResolverEmbedUrl = embedUrl
        Toast.makeText(
            this@NativeExoPlayerActivity,
            "Switching to $nextExpected...",
            Toast.LENGTH_SHORT
        ).show()
        mainHandler.removeCallbacks(failoverWatchdogRunnable)
        mainHandler.removeCallbacks(playbackReadyWatchdogRunnable)
        mainHandler.postDelayed(failoverWatchdogRunnable, 7500L)

        if (embedUrl.isNotEmpty() && resolverWebView != null) {
            try {
                val parsed = Uri.parse(embedUrl)
                val originRef = "${parsed.scheme}://${parsed.host}/"
                resolverWebView?.stopLoading()
                resolverWebView?.loadUrl(embedUrl, mapOf("Referer" to originRef))
            } catch (_: Throwable) {}
        }

        val requestedFrom = currentSource
        onNeedNextServer?.invoke(requestedFrom, resumeSec) { newUrl, newSource ->
            runOnUiThread {
                if (!newUrl.isNullOrEmpty() && isSwitchingServer) {
                    applyResolvedStream(
                        newUrl,
                        if (!newSource.isNullOrEmpty()) newSource else nextExpected,
                        getDefaultRefererForSource(nextExpected)
                    )
                }
            }
        }
    }

    private val hideControllerRunnable = Runnable {
        if (exoPlayer?.isPlaying == true && !isScrubbing) {
            setControllerVisible(false)
        }
    }

    private val progressRunnable = object : Runnable {
        override fun run() {
            saveCurrentProgress()
            mainHandler.postDelayed(this, 5000L)
        }
    }

    private val uiTickRunnable = object : Runnable {
        override fun run() {
            updateTimeAndSeekBar()
            updateSkipAndNextEpisodeUi()
            mainHandler.postDelayed(this, 250L)
        }
    }

    private val subtitleTickRunnable = object : Runnable {
        override fun run() {
            updateLiveSubtitleOverlay()
            mainHandler.postDelayed(this, 120L)
        }
    }

    private fun dp(v: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            v.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                window.decorView.defaultFocusHighlightEnabled = false
            }

            val root = FrameLayout(this).apply {
                clipChildren = false
                clipToPadding = false
                setBackgroundColor(Color.BLACK)
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    defaultFocusHighlightEnabled = false
                }
            }

            val pv = PlayerView(this).apply {
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                useController = false
                keepScreenOn = true
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    defaultFocusHighlightEnabled = false
                }

            }
            val resWv = WebView(this).apply {
                try {
                    if (androidx.webkit.WebViewFeature.isFeatureSupported(androidx.webkit.WebViewFeature.DOCUMENT_START_SCRIPT)) {
                        val docStartJs = "(function(){try{if(window.__sSniff)return;window.__sSniff=1;try{window.open=function(){return null;};}catch(e){}var postS=function(u,h,fv){if(!u||typeof u!=='string'||u.indexOf('blob:')===0||u.indexOf('data:')===0)return;try{u=new URL(u,location.href).href;}catch(e){}if(u.indexOf('http')!==0)return;var l=u.toLowerCase();if((l.indexOf('.ts')!==-1||l.indexOf('.m4s')!==-1)&&l.indexOf('.m3u8')===-1)return;var isH=!!h||l.indexOf('.m3u8')!==-1||l.indexOf('.m3u')!==-1||l.indexOf('master.txt')!==-1||l.indexOf('playlist.txt')!==-1||l.indexOf('/hls/')!==-1||l.indexOf('/hls2/')!==-1||l.indexOf('type=hls')!==-1;if(fv||isH||l.indexOf('.mpd')!==-1||l.indexOf('.mp4')!==-1||l.indexOf('.webm')!==-1||l.indexOf('.mkv')!==-1||l.indexOf('videoplayback')!==-1||l.indexOf('googleusercontent.com')!==-1||l.indexOf('mime=video')!==-1){try{AndroidSniffer.onStream(u,location.href,isH);}catch(e){}}};if(window.URL&&URL.createObjectURL){var oc=URL.createObjectURL;URL.createObjectURL=function(obj){try{if(obj&&typeof obj.size==='number'&&obj.size>16&&obj.size<512000&&typeof obj.text==='function'){obj.text().then(function(tx){if(tx&&tx.trim().indexOf('#EXTM3U')===0)AndroidSniffer.onInlineM3u8(tx,location.href);}).catch(function(){});}}catch(e){}return oc.apply(this,arguments);};}if(window.fetch){var of=window.fetch;window.fetch=function(i){var u=typeof i==='string'?i:(i&&i.url);postS(u,false,false);return of.apply(this,arguments).then(function(r){try{var ct=(r&&r.headers&&r.headers.get('content-type')||'').toLowerCase();var ru=r.url||u;var isH=ct.indexOf('mpegurl')!==-1;if(isH||ct.indexOf('video/mp4')!==-1||ct.indexOf('video/webm')!==-1){postS(ru,isH,true);}else if(ru){var cl=ru.split('?')[0].toLowerCase();if(!cl.endsWith('.css')&&!cl.endsWith('.svg')&&!cl.endsWith('.ico')&&!cl.endsWith('.woff2')){r.clone().text().then(function(tx){if(tx&&tx.slice(0,64).trim().indexOf('#EXTM3U')===0)postS(ru,true,true);}).catch(function(){});}}}catch(e){}return r;});};}if(window.XMLHttpRequest){var oo=XMLHttpRequest.prototype.open;var os=XMLHttpRequest.prototype.send;XMLHttpRequest.prototype.open=function(m,u){this._su=u;postS(u,false,false);return oo.apply(this,arguments);};XMLHttpRequest.prototype.send=function(){this.addEventListener('readystatechange',function(){if(this.readyState===4&&this.status>=200&&this.status<400){try{var ct=(this.getResponseHeader('content-type')||'').toLowerCase();var ru=this.responseURL||this._su;var isH=ct.indexOf('mpegurl')!==-1;var bh=!isH&&(this.responseType===''||this.responseType==='text')&&typeof this.responseText==='string'&&this.responseText.slice(0,64).trim().indexOf('#EXTM3U')===0;if(isH||bh||ct.indexOf('video/mp4')!==-1||ct.indexOf('video/webm')!==-1){postS(ru,isH||bh,true);}}catch(e){}}});return os.apply(this,arguments);};}setInterval(function(){try{document.querySelectorAll('video').forEach(function(v){var isF=(isFinite(v.duration)&&v.duration>=60)||(!v.paused&&v.currentTime>0.2);if(v.src)postS(v.src,false,isF);if(v.currentSrc)postS(v.currentSrc,false,isF);});}catch(e){}},1200);}catch(e){}})();"
                        androidx.webkit.WebViewCompat.addDocumentStartJavaScript(this, docStartJs, setOf("*"))
                    }
                } catch (_: Throwable) {}
                addJavascriptInterface(object {
                    @android.webkit.JavascriptInterface
                    fun onServers(json: String) {
                        try {
                            val arr = JSONArray(json)
                            val parsed = mutableListOf<Pair<String, String>>()
                            for (i in 0 until arr.length()) {
                                val o = arr.optJSONObject(i) ?: continue
                                val n = o.optString("name").trim()
                                val ix = o.optString("idx").trim()
                                if (n.isNotEmpty() && ix.isNotEmpty()) parsed.add(Pair(n, ix))
                            }
                            if (parsed.isNotEmpty()) {
                                mainHandler.post {
                                    multiEmbedSubServers.clear()
                                    multiEmbedSubServers.addAll(parsed)
                                    switchServerBtn?.text = "Servers (${parsed.size}) ▾"
                                }
                            }
                        } catch (_: Throwable) {}
                    }
                    @android.webkit.JavascriptInterface
                    fun onInlineM3u8(m3u8: String, ref: String) {
                        if (m3u8.isBlank()) return
                        try {
                            val f = File(cacheDir, "inline_playlist.m3u8")
                            f.writeText(m3u8)
                            val localPath = f.absolutePath
                            streamIsHlsMap[localPath] = true
                            if (ref.isNotBlank()) streamRefererMap[localPath] = ref
                            val srcTag = pendingNextSource.ifEmpty { currentSource }
                            mainHandler.post {
                                if (isSwitchingServer || isCaptchaCardVisible || streamUrl.isBlank()) {
                                    applyResolvedStream(localPath, srcTag, ref.ifBlank { activeResolverEmbedUrl })
                                }
                            }
                        } catch (_: Throwable) {}
                    }
                    @android.webkit.JavascriptInterface
                    fun onStream(u: String, ref: String, isHls: Boolean) {
                        if (u.isBlank() || !u.startsWith("http")) return
                        val l = u.lowercase()
                        val bad = listOf("promo", "teaser", "preroll", "ad_", "/ads/", "banner", "trailer", "preview", "bumper", "doubleclick", "vast", "vmap").any { l.contains(it) }
                        if (bad) return
                        if (isHls) streamIsHlsMap[u] = true
                        if (ref.isNotBlank()) streamRefererMap[u] = ref
                        val srcTag = pendingNextSource.ifEmpty { currentSource }
                        mainHandler.post {
                            if (isSwitchingServer || isCaptchaCardVisible || streamUrl.isBlank()) {
                                applyResolvedStream(u, srcTag, ref.ifBlank { activeResolverEmbedUrl })
                            }
                        }
                    }
                }, "AndroidSniffer")
                layoutParams = FrameLayout.LayoutParams(dp(200), dp(120), Gravity.BOTTOM or Gravity.START)
                alpha = 0.01f
                isClickable = false
                isFocusable = false
                settings.apply {
                    javaScriptEnabled = true
                    domStorageEnabled = true
                    mediaPlaybackRequiresUserGesture = true
                    loadsImagesAutomatically = false
                    javaScriptCanOpenWindowsAutomatically = false
                    setSupportMultipleWindows(false)
                    userAgentString = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
                }
                webChromeClient = object : android.webkit.WebChromeClient() {
                    override fun onCreateWindow(view: WebView?, isDialog: Boolean, isUserGesture: Boolean, resultMsg: android.os.Message?): Boolean = false
                }
                try {
                    CookieManager.getInstance().setAcceptCookie(true)
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                } catch (_: Throwable) {}
                webViewClient = object : WebViewClient() {
                    override fun shouldInterceptRequest(
                        view: WebView?,
                        request: WebResourceRequest?
                    ): WebResourceResponse? {
                        val u = request?.url?.toString() ?: return null
                        val lower = u.lowercase()
                        val isChallenge = lower.contains("challenges.cloudflare.com") || lower.contains("recaptcha/api") || lower.contains("hcaptcha.com/1/api") || lower.contains("turnstile/v0/api") || lower.contains("arkoselabs.com")
                        if (isChallenge) {
                            mainHandler.post {
                                if (isSwitchingServer) {
                                    mainHandler.removeCallbacks(failoverWatchdogRunnable)
                                    if (!isCaptchaCardVisible) {
                                        showCaptchaCard(pendingNextSource.ifEmpty { currentSource })
                                    }
                                }
                            }
                            return super.shouldInterceptRequest(view, request)
                        }
                        val isBadClip = listOf("promo", "teaser", "preroll", "ad_", "/ads/", "banner", "trailer", "preview", "bumper", "doubleclick", "vast", "vmap").any { lower.contains(it) }
                        val isHlsUrl = lower.contains(".m3u8") || lower.contains("master.txt") || lower.contains("playlist.txt") || lower.contains("/hls/") || lower.contains("/hls2/") || lower.contains("type=hls")
                        val isVideo = !isBadClip && (isHlsUrl || lower.contains(".mpd") || lower.contains("mime=video") || lower.contains("videoplayback") || lower.contains("googleusercontent.com") || lower.contains("googlevideo.com") || lower.contains(".webm") || lower.contains(".mkv") || (lower.contains(".mp4") && !lower.contains("favicon") && !lower.contains("preview") && !lower.contains("trailer") && !lower.contains("logo") && !lower.contains("preroll") && !lower.contains("blank")))
                        if (isVideo) {
                            val hdrs = HashMap<String, String>(request.requestHeaders ?: emptyMap())
                            val hasRef = hdrs.keys.any { it.equals("referer", ignoreCase = true) }
                            if (!hasRef && activeResolverEmbedUrl.isNotEmpty()) {
                                hdrs["Referer"] = activeResolverEmbedUrl
                            }
                            AdBlockerInterceptor.streamHeadersMap[u] = hdrs
                            if (isHlsUrl) streamIsHlsMap[u] = true
                            val reqRef = hdrs.entries.firstOrNull { it.key.equals("referer", ignoreCase = true) }?.value ?: activeResolverEmbedUrl
                            if (reqRef.isNotEmpty()) streamRefererMap[u] = reqRef
                            val srcTag = pendingNextSource.ifEmpty { currentSource }
                            val refUrl = activeResolverEmbedUrl
                            mainHandler.post {
                                if (isSwitchingServer || streamUrl.isBlank()) {
                                    applyResolvedStream(u, srcTag, refUrl)
                                }
                            }
                        } else if (AdBlockerInterceptor.isBlockedUrl(u)) {
                            return AdBlockerInterceptor.createEmptyResponse()
                        }
                        return super.shouldInterceptRequest(view, request)
                    }

                    override fun onPageFinished(view: WebView?, url: String?) {
                        super.onPageFinished(view, url)
                        if (view == null || url == null || url.startsWith("about:")) return
                        val clickJs = "(function(){try{if(!window.__sSniff){window.__sSniff=1;try{window.open=function(){return null;};}catch(e){}var postS=function(u,h,fv){if(!u||typeof u!=='string'||u.indexOf('blob:')===0||u.indexOf('data:')===0)return;try{u=new URL(u,location.href).href;}catch(e){}if(u.indexOf('http')!==0)return;var l=u.toLowerCase();if((l.indexOf('.ts')!==-1||l.indexOf('.m4s')!==-1)&&l.indexOf('.m3u8')===-1)return;var isH=!!h||l.indexOf('.m3u8')!==-1||l.indexOf('master.txt')!==-1||l.indexOf('playlist.txt')!==-1||l.indexOf('/hls/')!==-1||l.indexOf('/hls2/')!==-1||l.indexOf('type=hls')!==-1;if(fv||isH||l.indexOf('.mpd')!==-1||l.indexOf('.mp4')!==-1||l.indexOf('.webm')!==-1||l.indexOf('.mkv')!==-1||l.indexOf('videoplayback')!==-1||l.indexOf('googleusercontent.com')!==-1||l.indexOf('mime=video')!==-1){try{AndroidSniffer.onStream(u,location.href,isH);}catch(e){}}};if(window.URL&&URL.createObjectURL){var oc=URL.createObjectURL;URL.createObjectURL=function(obj){try{if(obj&&typeof obj.size==='number'&&obj.size>16&&obj.size<512000&&typeof obj.text==='function'){obj.text().then(function(tx){if(tx&&tx.trim().indexOf('#EXTM3U')===0)AndroidSniffer.onInlineM3u8(tx,location.href);}).catch(function(){});}}catch(e){}return oc.apply(this,arguments);};}if(window.fetch){var of=window.fetch;window.fetch=function(i){var u=typeof i==='string'?i:(i&&i.url);postS(u,false,false);return of.apply(this,arguments).then(function(r){try{var ct=(r&&r.headers&&r.headers.get('content-type')||'').toLowerCase();var ru=r.url||u;var isH=ct.indexOf('mpegurl')!==-1;if(isH||ct.indexOf('video/mp4')!==-1||ct.indexOf('video/webm')!==-1){postS(ru,isH,true);}else if(ru){var cl=ru.split('?')[0].toLowerCase();if(!cl.endsWith('.css')&&!cl.endsWith('.svg')&&!cl.endsWith('.ico')&&!cl.endsWith('.woff2')){r.clone().text().then(function(tx){if(tx&&tx.slice(0,64).trim().indexOf('#EXTM3U')===0)postS(ru,true,true);}).catch(function(){});}}}catch(e){}return r;});};}if(window.XMLHttpRequest){var oo=XMLHttpRequest.prototype.open;var os=XMLHttpRequest.prototype.send;XMLHttpRequest.prototype.open=function(m,u){this._su=u;postS(u,false,false);return oo.apply(this,arguments);};XMLHttpRequest.prototype.send=function(){this.addEventListener('readystatechange',function(){if(this.readyState===4&&this.status>=200&&this.status<400){try{var ct=(this.getResponseHeader('content-type')||'').toLowerCase();var ru=this.responseURL||this._su;var isH=ct.indexOf('mpegurl')!==-1;var bh=!isH&&(this.responseType===''||this.responseType==='text')&&typeof this.responseText==='string'&&this.responseText.slice(0,64).trim().indexOf('#EXTM3U')===0;if(isH||bh||ct.indexOf('video/mp4')!==-1||ct.indexOf('video/webm')!==-1){postS(ru,isH||bh,true);}}catch(e){}}});return os.apply(this,arguments);};}}var t=(document.title||'')+' '+(document.body?document.body.innerText.slice(0,500):'');var l=t.toLowerCase();if(l.indexOf('no sources')!==-1||l.indexOf('404 not found')!==-1||l.indexOf('502 bad gateway')!==-1||l.indexOf('media not found')!==-1||l.indexOf('video not found')!==-1){return 'DEAD';}var w=!!document.querySelector('iframe[src*=challenges\\.cloudflare\\.com],iframe[src*=turnstile],iframe[src*=challenge],iframe[src*=captcha],iframe[src*=recaptcha],iframe[src*=hcaptcha],.cf-turnstile,.g-recaptcha,.h-captcha,#cf-turnstile-response,#cf-challenge-running,[id*=turnstile],[class*=turnstile],[class*=geetest]');if(w||l.indexOf('just a moment')!==-1||l.indexOf('verify you are human')!==-1||l.indexOf('security check')!==-1||l.indexOf('are you a robot')!==-1){return 'CHALLENGE';}try{var sl=[];var sn={};var cs=document.querySelectorAll('.servers li,.servers a,.servers button,.servers div,[class*=server] li,[class*=server] a,[class*=server] button,[class*=server] div,[data-server],[data-id],[data-hash]');var sx=0;cs.forEach(function(el){var lb=(el.innerText||el.textContent||'').replace(/\\s+/g,' ').trim();if(!lb||lb.length>60||lb.toLowerCase()==='servers'||lb.toLowerCase()==='server'||lb.toLowerCase().indexOf('go to website')!==-1)return;if(sn[lb])return;sn[lb]=1;var ky='s'+(sx++);el.setAttribute('data-s-idx',ky);sl.push({name:lb,idx:ky});});if(sl.length>0)AndroidSniffer.onServers(JSON.stringify(sl));}catch(e){}document.querySelectorAll('button,div,span,a').forEach(function(el){var tx=(el.innerText||'').trim().toLowerCase();if(tx==='skip ad'||tx==='skip ads'){try{el.click();}catch(e){}}});if(typeof window.jwplayer==='function'){try{var jw=window.jwplayer();var it=jw&&jw.getPlaylistItem&&jw.getPlaylistItem();if(it){if(it.file)postS(it.file,it.file.indexOf('.m3u8')!==-1||it.type==='hls',true);if(Array.isArray(it.sources))it.sources.forEach(function(s){if(s&&s.file)postS(s.file,s.file.indexOf('.m3u8')!==-1||s.type==='hls',true);});}}catch(e){}}var clickP=function(){document.querySelectorAll('#pl_but,.play,.btn-play,.vjs-big-play-button,.jw-icon-display').forEach(function(b){try{b.click();}catch(e){}});};clickP();setTimeout(clickP,650);var scanV=function(){document.querySelectorAll('video').forEach(function(v){var isP=v.videoHeight>0&&v.videoWidth>0&&v.videoHeight>v.videoWidth*0.95;var isS=isFinite(v.duration)&&v.duration>0&&v.duration<120;if(isP||isS){v.muted=true;try{v.style.display='none';if(isFinite(v.duration)&&v.duration>1&&v.currentTime<v.duration-0.2)v.currentTime=v.duration-0.05;document.querySelectorAll('div,a,button').forEach(function(el){var tx=(el.innerText||'').trim().toLowerCase();if(tx==='skip ad'||tx==='skip ads'){try{el.click();}catch(e){}}else if(tx==='go to website'||tx.indexOf('install ')===0){try{el.style.display='none';}catch(e){}}});}catch(e){}return;}var isF=(isFinite(v.duration)&&v.duration>=60)||(!v.paused&&v.currentTime>0.2);if(v.src)postS(v.src,false,isF);if(v.currentSrc)postS(v.currentSrc,false,isF);if(isF){try{document.querySelectorAll('a[download],a[href*=\".mp4\"],a[href*=\".m3u8\"]').forEach(function(a){if(a.href)postS(a.href,a.href.indexOf('.m3u8')!==-1,true);});if(window.player&&typeof window.player.api==='function'){var pf=window.player.api('file');if(pf&&typeof pf==='string')postS(pf,pf.indexOf('.m3u8')!==-1,true);}}catch(e){}}});};scanV();setTimeout(scanV,900);setTimeout(scanV,2000);}catch(e){}return '';})()"
                        view.evaluateJavascript(clickJs) { res ->
                            if (res != null && res.contains("CHALLENGE") && isSwitchingServer && !isCaptchaCardVisible) {
                                mainHandler.removeCallbacks(failoverWatchdogRunnable)
                                showCaptchaCard(pendingNextSource.ifEmpty { currentSource })
                            } else if (res != null && res.contains("DEAD") && isSwitchingServer) {
                                mainHandler.removeCallbacks(failoverWatchdogRunnable)
                                failoverWatchdogRunnable.run()
                            }
                        }
                    }
                }
            }
            rootFrameLayout = root
            resolverWebView = resWv
            root.addView(resWv)

            playerView = pv
            applySubtitleStyle()
            root.addView(pv)

            val skBtn = Button(this).apply {
                text = "Skip Intro"
                isAllCaps = false
                setTextColor(Color.BLACK)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(16), dp(8), dp(16), dp(8))
                isFocusable = true
                isClickable = true
                visibility = View.GONE
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(8).toFloat()
                    setColor(Color.argb(240, 255, 255, 255))
                }
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM or Gravity.END
                ).apply {
                    marginEnd = dp(24)
                    bottomMargin = dp(92)
                }
                setOnClickListener { handleSkipSegmentClick() }
            }
            skipSegmentBtn = skBtn
            root.addView(skBtn)

            val nCard = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(14), dp(12), dp(14), dp(12))
                visibility = View.GONE
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(12).toFloat()
                    setColor(Color.argb(242, 14, 16, 22))
                    setStroke(dp(1), Color.argb(60, 255, 255, 255))
                }
                layoutParams = FrameLayout.LayoutParams(
                    dp(268),
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM or Gravity.END
                ).apply {
                    marginEnd = dp(24)
                    bottomMargin = dp(92)
                }
            }
            val nTag = TextView(this).apply {
                text = "NEXT EPISODE"
                setTextColor(Color.rgb(229, 9, 20))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                typeface = Typeface.DEFAULT_BOLD
            }
            val nTitle = TextView(this).apply {
                text = "Next Episode"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(0, dp(4), 0, dp(2))
            }
            nextEpTitleTv = nTitle
            val nCount = TextView(this).apply {
                text = "Starting in 10s..."
                setTextColor(Color.argb(190, 255, 255, 255))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setPadding(0, 0, 0, dp(10))
            }
            nextEpCountdownTv = nCount
            val nBtnRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
            }
            val nPlayBtn = Button(this).apply {
                text = "Play Next"
                isAllCaps = false
                setTextColor(Color.BLACK)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(12), dp(6), dp(12), dp(6))
                minHeight = 0
                minimumHeight = 0
                isFocusable = true
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(6).toFloat()
                    setColor(Color.WHITE)
                }
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = dp(8) }
                setOnClickListener { playNextEpisodeInPlayer() }
            }
            val nDismissBtn = Button(this).apply {
                text = "Watch Credits"
                isAllCaps = false
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setPadding(dp(10), dp(6), dp(10), dp(6))
                minHeight = 0
                minimumHeight = 0
                isFocusable = true
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(6).toFloat()
                    setColor(Color.argb(40, 255, 255, 255))
                }
                setOnClickListener { dismissNextEpisodeCard() }
            }
            nBtnRow.addView(nPlayBtn)
            nBtnRow.addView(nDismissBtn)
            nCard.addView(nTag)
            nCard.addView(nTitle)
            nCard.addView(nCount)
            nCard.addView(nBtnRow)
            nextEpCard = nCard
            root.addView(nCard)

            val subOverlay = TextView(this).apply {
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, subTextSizeSp)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(28, 12, 28, 12)
                setShadowLayer(6f, 0f, 2f, Color.BLACK)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 14f
                    setColor(Color.argb(190, 0, 0, 0))
                }
                visibility = View.GONE
                val lp = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
                )
                lp.setMargins(48, 0, 48, dp(32))
                layoutParams = lp
            }
            subtitleOverlayView = subOverlay
            root.addView(subOverlay)

            val overlay = FrameLayout(this).apply {
                clipChildren = false
                clipToPadding = false
                isClickable = false
                isFocusable = false
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
            }
            controllerOverlay = overlay

            val topBar = LinearLayout(this).apply {
                clipChildren = false
                clipToPadding = false
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(28), dp(22), dp(28), dp(28))
                background = GradientDrawable(
                    GradientDrawable.Orientation.TOP_BOTTOM,
                    intArrayOf(Color.argb(150, 0, 0, 0), Color.TRANSPARENT)
                )
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP
                )
            }

            val backBtn = makeCircleVectorButton("back", 44) {
                saveCurrentProgress()
                finish()
            }

            val tvTitle = TextView(this).apply {
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(12), 0, dp(16), 0)
                maxLines = 1
                setShadowLayer(4f, 0f, 1f, Color.argb(180, 0, 0, 0))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            }
            titleView = tvTitle

            val srvBadge = TextView(this).apply {
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(12), dp(5), dp(12), dp(5))
                isClickable = false
                isFocusable = false
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(12).toFloat()
                    setColor(Color.argb(55, 255, 255, 255))
                }
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }
            serverBadgeView = srvBadge
            tvTitle.layoutParams = LinearLayout.LayoutParams(
                0,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                1f
            ).apply {
                marginStart = dp(12)
                marginEnd = dp(12)
            }
            val swBtn = Button(this).apply {
                text = "Servers ▾"
                isAllCaps = false
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(12), dp(5), dp(12), dp(5))
                minHeight = 0
                minimumHeight = 0
                minWidth = 0
                minimumWidth = 0
                isFocusable = true
                isClickable = true
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) defaultFocusHighlightEnabled = false
                fun makeSrvBg(focused: Boolean) = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(12).toFloat()
                    setColor(if (focused) Color.rgb(255, 30, 45) else Color.argb(215, 229, 9, 20))
                    if (focused) setStroke(dp(2), Color.WHITE)
                }
                background = makeSrvBg(false)
                setOnFocusChangeListener { v, hasFocus ->
                    v.background = makeSrvBg(hasFocus)
                    v.animate().scaleX(if (hasFocus) 1.08f else 1f).scaleY(if (hasFocus) 1.08f else 1f).setDuration(120).start()
                    if (hasFocus) showControllerTemporarily()
                }
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    marginEnd = dp(8)
                }
                setOnClickListener { handleSwitchServer() }
            }
            switchServerBtn = swBtn
            topBar.addView(backBtn)
            topBar.addView(tvTitle)
            topBar.addView(swBtn)
            topBar.addView(srvBadge)
            overlay.addView(topBar)

            val centerControls = LinearLayout(this).apply {
                clipChildren = false
                clipToPadding = false
                setPadding(dp(18), dp(18), dp(18), dp(18))
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.CENTER
                )
            }

            val rewBtn = makeCircleVectorButton("rew10", 58) {
                exoPlayer?.let { p ->
                    p.seekTo((p.currentPosition - 10_000L).coerceAtLeast(0L))
                }
                showControllerTemporarily()
            }

            val ppBtn = makeCircleVectorButton("pause", 72) {
                exoPlayer?.let { p ->
                    if (p.isPlaying) p.pause() else p.play()
                }
                showControllerTemporarily()
            }
            playPauseBtn = ppBtn

            val fwdBtn = makeCircleVectorButton("fwd10", 58) {
                exoPlayer?.let { p ->
                    p.seekTo((p.currentPosition + 10_000L).coerceAtMost(p.duration.coerceAtLeast(0L)))
                }
                showControllerTemporarily()
            }

            (rewBtn.layoutParams as LinearLayout.LayoutParams).setMargins(0, 0, dp(30), 0)
            (fwdBtn.layoutParams as LinearLayout.LayoutParams).setMargins(dp(30), 0, 0, 0)

            centerControls.addView(rewBtn)
            centerControls.addView(ppBtn)
            centerControls.addView(fwdBtn)
            overlay.addView(centerControls)

            val bottomContainer = LinearLayout(this).apply {
                clipChildren = false
                clipToPadding = false
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                setPadding(dp(72), dp(28), dp(72), dp(22))
                background = GradientDrawable(
                    GradientDrawable.Orientation.BOTTOM_TOP,
                    intArrayOf(Color.argb(175, 0, 0, 0), Color.TRANSPARENT)
                )
                layoutParams = FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM
                )
            }

            val seekRow = LinearLayout(this).apply {
                clipChildren = false
                clipToPadding = false
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    setMargins(dp(56), 0, dp(56), dp(10))
                }
            }

            val posText = TextView(this).apply {
                text = "0:00"
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(0, 0, dp(14), 0)
            }
            currentPosView = posText

            val sb = SeekBar(this).apply {
                max = 1000
                progress = 0
                splitTrack = false
                isFocusable = true
                isFocusableInTouchMode = false
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    defaultFocusHighlightEnabled = false
                }
                progressDrawable = createNetflixSeekBarDrawable(false)
                thumb = ColorDrawable(Color.TRANSPARENT)
                thumbOffset = 0
                setPadding(0, dp(10), 0, dp(10))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnFocusChangeListener { v, hasFocus ->
                    progressDrawable = createNetflixSeekBarDrawable(hasFocus)
                    v.animate()
                        .scaleY(if (hasFocus) 1.55f else 1.0f)
                        .setDuration(140)
                        .setInterpolator(DecelerateInterpolator())
                        .start()
                    showControllerTemporarily()
                }
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(bar: SeekBar?, value: Int, fromUser: Boolean) {
                        if (fromUser) {
                            val dur = exoPlayer?.duration ?: 0L
                            if (dur > 0) {
                                val target = (dur * value) / 1000L
                                currentPosView?.text = formatTimeMs(target)
                            }
                        }
                    }

                    override fun onStartTrackingTouch(bar: SeekBar?) {
                        isScrubbing = true
                        mainHandler.removeCallbacks(hideControllerRunnable)
        mainHandler.removeCallbacks(hideMetersRunnable)
        mainHandler.removeCallbacks(hideLeftSeekRunnable)
        mainHandler.removeCallbacks(hideRightSeekRunnable)
                    }

                    override fun onStopTrackingTouch(bar: SeekBar?) {
                        isScrubbing = false
                        val dur = exoPlayer?.duration ?: 0L
                        if (dur > 0 && bar != null) {
                            exoPlayer?.seekTo((dur * bar.progress) / 1000L)
                        }
                        showControllerTemporarily()
                    }
                })
            }
            seekBar = sb

            val durText = TextView(this).apply {
                text = "0:00"
                setTextColor(Color.argb(215, 226, 232, 240))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(14), 0, 0, 0)
            }
            durationView = durText

            seekRow.addView(posText)
            seekRow.addView(sb)
            seekRow.addView(durText)
            bottomContainer.addView(seekRow)

            val actionsRow = LinearLayout(this).apply {
                clipChildren = false
                clipToPadding = false
                setPadding(dp(12), dp(8), dp(12), dp(8))
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }

            val sBtn = makeSecondaryButton("Subtitles") {
                showSubtitlesMenuDialog()
            }
            subBtn = sBtn

            val qualityBtn = makeSecondaryButton("Quality") {
                showQualityDialog()
            }
            val speedBtn = makeSecondaryButton("1.0x") { btn ->
                showSpeedDialog(btn as Button)
            }
            val pipBtn = makeSecondaryButton("PiP") {
                enterPipIfSupported()
            }

            val syncBtn = makeSecondaryButton("Sync 0.0s") {
                showSubtitleDelayDialog()
            }
            actionsRow.addView(sBtn)
            actionsRow.addView(syncBtn)
            actionsRow.addView(qualityBtn)
            actionsRow.addView(speedBtn)
            actionsRow.addView(pipBtn)
            bottomActionsRow = actionsRow
            bottomContainer.addView(actionsRow)

            overlay.addView(bottomContainer)
            root.addView(overlay)

            audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val lpBright = window.attributes
            if (lpBright.screenBrightness >= 0f) {
                currentBrightness = lpBright.screenBrightness
            }

            val bMeter = VerticalGestureMeterView(this, true).apply {
                visibility = View.GONE
                alpha = 0f
                val lp = FrameLayout.LayoutParams(dp(52), dp(210), Gravity.START or Gravity.CENTER_VERTICAL)
                lp.setMargins(dp(34), 0, 0, 0)
                layoutParams = lp
            }
            brightnessMeter = bMeter
            root.addView(bMeter)

            val vMeter = VerticalGestureMeterView(this, false).apply {
                visibility = View.GONE
                alpha = 0f
                val lp = FrameLayout.LayoutParams(dp(52), dp(210), Gravity.END or Gravity.CENTER_VERTICAL)
                lp.setMargins(0, 0, dp(34), 0)
                layoutParams = lp
            }
            volumeMeter = vMeter
            root.addView(vMeter)

            val lSeek = TextView(this).apply {
                visibility = View.GONE
                alpha = 0f
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(dp(24), dp(14), dp(24), dp(14))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(40).toFloat()
                    setColor(Color.argb(145, 0, 0, 0))
                }
                val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.START or Gravity.CENTER_VERTICAL)
                lp.setMargins(dp(95), 0, 0, 0)
                layoutParams = lp
            }
            leftSeekBadge = lSeek
            root.addView(lSeek)

            val rSeek = TextView(this).apply {
                visibility = View.GONE
                alpha = 0f
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER
                setPadding(dp(24), dp(14), dp(24), dp(14))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(40).toFloat()
                    setColor(Color.argb(145, 0, 0, 0))
                }
                val lp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.END or Gravity.CENTER_VERTICAL)
                lp.setMargins(0, 0, dp(95), 0)
                layoutParams = lp
            }
            rightSeekBadge = rSeek
            root.addView(rSeek)

            val triggerSeekStep: (Int) -> Unit = { side ->
                val player = exoPlayer
                if (player != null) {
                    val dur = player.duration
                    val nowMs = SystemClock.elapsedRealtime()
                    activeSeekSide = side
                    lastSeekEventTimeMs = nowMs
                    if (side < 0) {
                        val target = (player.currentPosition - 10_000L).coerceAtLeast(0L)
                        player.seekTo(target)
                        accumSeekLeftSec += 10
                        mainHandler.removeCallbacks(hideLeftSeekRunnable)
                        lSeek.animate().cancel()
                        lSeek.text = "« -${accumSeekLeftSec}s"
                        lSeek.visibility = View.VISIBLE
                        lSeek.alpha = 1f
                        lSeek.scaleX = 0.9f
                        lSeek.scaleY = 0.9f
                        lSeek.animate().scaleX(1.06f).scaleY(1.06f).setDuration(110).withEndAction {
                            lSeek.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
                        }.start()
                        mainHandler.postDelayed(hideLeftSeekRunnable, 750L)
                    } else {
                        val rawNext = player.currentPosition + 10_000L
                        val target = if (dur > 0L) rawNext.coerceAtMost(dur) else rawNext
                        player.seekTo(target)
                        accumSeekRightSec += 10
                        mainHandler.removeCallbacks(hideRightSeekRunnable)
                        rSeek.animate().cancel()
                        rSeek.text = "+${accumSeekRightSec}s »"
                        rSeek.visibility = View.VISIBLE
                        rSeek.alpha = 1f
                        rSeek.scaleX = 0.9f
                        rSeek.scaleY = 0.9f
                        rSeek.animate().scaleX(1.06f).scaleY(1.06f).setDuration(110).withEndAction {
                            rSeek.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
                        }.start()
                        mainHandler.postDelayed(hideRightSeekRunnable, 750L)
                    }
                    updateTimeAndSeekBar()
                }
            }

            pv.setOnTouchListener { _, event ->
                val w = root.width.toFloat().coerceAtLeast(1f)
                val h = root.height.toFloat().coerceAtLeast(1f)
                when (event.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        gestureActiveMode = 0
                        gestureDownTimeMs = SystemClock.elapsedRealtime()
                        gestureStartX = event.x
                        gestureStartY = event.y
                        gestureStartVal = if (event.x < w * 0.5f) {
                            currentBrightness
                        } else {
                            val am = audioManager
                            if (am != null) {
                                val maxV = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                                am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / maxV.toFloat()
                            } else 0.5f
                        }
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = event.x - gestureStartX
                        val dy = gestureStartY - event.y
                        val inVerticalSafeZone = gestureStartY >= h * 0.14f && gestureStartY <= h * 0.84f
                        val inLeftStrip = gestureStartX >= dp(20).toFloat() && gestureStartX <= w * 0.24f
                        val inRightStrip = gestureStartX >= w * 0.76f && gestureStartX <= w - dp(20).toFloat()
                        if (gestureActiveMode == 0 && event.pointerCount == 1 && inVerticalSafeZone && (inLeftStrip || inRightStrip) && kotlin.math.abs(dy) > dp(20) && kotlin.math.abs(dy) > kotlin.math.abs(dx) * 1.3f) {
                            gestureActiveMode = if (inLeftStrip) 1 else 2
                        }
                        if (gestureActiveMode != 0) {
                            val delta = dy / (h * 0.6f)
                            val nextVal = (gestureStartVal + delta).coerceIn(0f, 1f)
                            mainHandler.removeCallbacks(hideMetersRunnable)
                            if (gestureActiveMode == 1) {
                                currentBrightness = nextVal.coerceAtLeast(0.04f)
                                val wlp = window.attributes
                                wlp.screenBrightness = currentBrightness
                                window.attributes = wlp
                                bMeter.setLevel(currentBrightness)
                                bMeter.animate().cancel()
                                bMeter.alpha = 1f
                                bMeter.visibility = View.VISIBLE
                            } else {
                                val am = audioManager
                                if (am != null) {
                                    val maxV = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                                    val targetV = kotlin.math.round(nextVal * maxV).toInt().coerceIn(0, maxV)
                                    am.setStreamVolume(AudioManager.STREAM_MUSIC, targetV, 0)
                                    vMeter.setLevel(targetV.toFloat() / maxV.toFloat())
                                } else {
                                    vMeter.setLevel(nextVal)
                                }
                                vMeter.animate().cancel()
                                vMeter.alpha = 1f
                                vMeter.visibility = View.VISIBLE
                            }
                            mainHandler.postDelayed(hideMetersRunnable, 900L)
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (gestureActiveMode != 0) {
                            gestureActiveMode = 0
                            mainHandler.removeCallbacks(hideMetersRunnable)
                            mainHandler.postDelayed(hideMetersRunnable, 900L)
                            return@setOnTouchListener true
                        }
                        val moveDist = kotlin.math.hypot((event.x - gestureStartX).toDouble(), (event.y - gestureStartY).toDouble())
                        val nowMs = SystemClock.elapsedRealtime()
                        if (moveDist < dp(18) && (nowMs - gestureDownTimeMs) < 320L) {
                            val tapSide = when {
                                event.x < w * 0.35f -> -1
                                event.x > w * 0.65f -> 1
                                else -> 0
                            }
                            if (tapSide != 0 && activeSeekSide == tapSide && (nowMs - lastSeekEventTimeMs) < 850L) {
                                mainHandler.removeCallbacks(singleTapToggleRunnable)
                                triggerSeekStep(tapSide)
                            } else if (tapSide != 0 && tapSide == lastTapSide && (nowMs - lastTapTimeMs) < 320L) {
                                mainHandler.removeCallbacks(singleTapToggleRunnable)
                                lastTapTimeMs = 0L
                                triggerSeekStep(tapSide)
                            } else if (tapSide == 0) {
                                mainHandler.removeCallbacks(singleTapToggleRunnable)
                                lastTapTimeMs = 0L
                                lastTapSide = 0
                                singleTapToggleRunnable.run()
                            } else {
                                lastTapTimeMs = nowMs
                                lastTapSide = tapSide
                                mainHandler.removeCallbacks(singleTapToggleRunnable)
                                mainHandler.postDelayed(singleTapToggleRunnable, 270L)
                            }
                        }
                    }
                    MotionEvent.ACTION_CANCEL -> {
                        if (gestureActiveMode != 0) {
                            gestureActiveMode = 0
                            mainHandler.removeCallbacks(hideMetersRunnable)
                            mainHandler.postDelayed(hideMetersRunnable, 900L)
                        }
                    }
                }
                true
            }
            setContentView(root)
            enableImmersiveFullscreen()
            showControllerTemporarily()
            ppBtn.post { ppBtn.requestFocus() }

            parseIntentAndStart(intent)
        } catch (t: Throwable) {
            Toast.makeText(this, "Player initialization error: ${t.localizedMessage}", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun createNetflixSeekBarDrawable(focused: Boolean): LayerDrawable {
        val radius = dp(6).toFloat()
        val h = if (focused) dp(7) else dp(5)
        val bg = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radius
            setColor(if (focused) Color.argb(120, 255, 255, 255) else Color.argb(72, 255, 255, 255))
            if (focused) {
                setStroke(dp(1), Color.argb(210, 255, 255, 255))
            }
            setSize(-1, h)
        }
        val prog = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = radius
            setColor(if (focused) Color.rgb(255, 30, 42) else Color.rgb(229, 9, 20))
            setSize(-1, h)
        }
        val clip = ClipDrawable(prog, Gravity.START, ClipDrawable.HORIZONTAL)
        return LayerDrawable(arrayOf(bg, clip)).apply {
            setId(0, android.R.id.background)
            setId(1, android.R.id.progress)
        }
    }

    private fun createCircleBg(focused: Boolean): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            if (focused) {
                setColor(Color.argb(65, 255, 255, 255))
                setStroke(dp(2), Color.WHITE)
            } else {
                setColor(Color.TRANSPARENT)
            }
        }
    }

    private fun makeCircleVectorButton(iconKind: String, sizeDp: Int, onClick: (View) -> Unit): ImageButton {
        val px = dp(sizeDp)
        return ImageButton(this).apply {
            setImageDrawable(VectorIconDrawable(iconKind, Color.WHITE))
            scaleType = ImageView.ScaleType.FIT_CENTER
            background = createCircleBg(false)
            val pad = dp((sizeDp * 0.22f).toInt())
            setPadding(pad, pad, pad, pad)
            layoutParams = LinearLayout.LayoutParams(px, px)
            isFocusable = true
            isFocusableInTouchMode = false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                defaultFocusHighlightEnabled = false
            }
            setOnFocusChangeListener { v, hasFocus ->
                v.background = createCircleBg(hasFocus)
                v.animate()
                    .scaleX(if (hasFocus) 1.14f else 1.0f)
                    .scaleY(if (hasFocus) 1.14f else 1.0f)
                    .setDuration(140)
                    .setInterpolator(DecelerateInterpolator())
                    .start()
                if (hasFocus) showControllerTemporarily()
            }
            setOnClickListener(onClick)
        }
    }

    private fun createSecondaryBg(focused: Boolean): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(20).toFloat()
            if (focused) {
                setColor(Color.argb(95, 255, 255, 255))
                setStroke(dp(2), Color.WHITE)
            } else {
                setColor(Color.argb(28, 255, 255, 255))
                setStroke(dp(1), Color.argb(40, 255, 255, 255))
            }
        }
    }

    private fun makeSecondaryButton(label: String, onClick: (View) -> Unit): Button {
        return Button(this).apply {
            text = label
            isAllCaps = false
            setTextColor(Color.argb(235, 240, 240, 240))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12.5f)
            typeface = Typeface.DEFAULT_BOLD
            background = createSecondaryBg(false)
            setPadding(dp(16), dp(7), dp(16), dp(7))
            minWidth = 0
            minimumWidth = 0
            minHeight = 0
            minimumHeight = 0
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                setMargins(dp(6), 0, dp(6), 0)
            }
            isFocusable = true
            isFocusableInTouchMode = false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                defaultFocusHighlightEnabled = false
            }
            setOnFocusChangeListener { v, hasFocus ->
                v.background = createSecondaryBg(hasFocus)
                v.animate()
                    .scaleX(if (hasFocus) 1.08f else 1.0f)
                    .scaleY(if (hasFocus) 1.08f else 1.0f)
                    .setDuration(140)
                    .setInterpolator(DecelerateInterpolator())
                    .start()
                if (hasFocus) showControllerTemporarily()
            }
            setOnClickListener(onClick)
        }
    }

    private fun setControllerVisible(visible: Boolean) {
        isControllerVisible = visible
        val overlay = controllerOverlay ?: return
        if (visible) {
            if (overlay.visibility != View.VISIBLE) {
                overlay.alpha = 0f
                overlay.visibility = View.VISIBLE
                overlay.animate().alpha(1f).setDuration(180).start()
            }
        } else {
            mainHandler.removeCallbacks(hideControllerRunnable)
            if (overlay.visibility == View.VISIBLE) {
                overlay.animate().alpha(0f).setDuration(180).withEndAction {
                    if (!isControllerVisible) overlay.visibility = View.GONE
                }.start()
            }
        }
    }

    private fun showControllerTemporarily() {
        setControllerVisible(true)
        mainHandler.removeCallbacks(hideControllerRunnable)
        mainHandler.removeCallbacks(hideLeftSeekRunnable)
        mainHandler.removeCallbacks(hideRightSeekRunnable)
        if (exoPlayer?.isPlaying == true) {
            mainHandler.postDelayed(hideControllerRunnable, 4000L)
        }
    }

    private fun formatTimeMs(ms: Long): String {
        val totalSec = (ms / 1000L).coerceAtLeast(0L)
        val h = totalSec / 3600L
        val m = (totalSec % 3600L) / 60L
        val s = totalSec % 60L
        return if (h > 0) {
            String.format("%d:%02d:%02d", h, m, s)
        } else {
            String.format("%d:%02d", m, s)
        }
    }

    private fun updateTimeAndSeekBar() {
        val player = exoPlayer ?: return
        val dur = player.duration.coerceAtLeast(0L)
        val pos = player.currentPosition.coerceAtLeast(0L)
        val minValidMs = if (mediaType.equals("tv", ignoreCase = true)) 60_000L else 180_000L
        if (!streamUrl.startsWith("/") && dur in 1L until minValidMs) {
            player.pause()
            recordServerStatus(currentSource, "failed")
            Toast.makeText(this, "Short/fake clip on $currentSource — switching...", Toast.LENGTH_SHORT).show()
            if (!isSwitchingServer) {
                triggerNextServerFailover()
            }
            return
        }
        if (!isSwitchingServer && !streamUrl.startsWith("/") && dur >= minValidMs && (pos > 500L || player.isPlaying)) {
            if (getServerStatus(currentSource) != "working") {
                recordServerStatus(currentSource, "working")
            }
        }
        playPauseBtn?.setImageDrawable(VectorIconDrawable(if (player.isPlaying) "pause" else "play", Color.WHITE))
        if (!isScrubbing) {
            currentPosView?.text = formatTimeMs(pos)
            durationView?.text = if (dur > 0) formatTimeMs(dur) else "0:00"
            if (dur > 0) {
                seekBar?.progress = ((pos * 1000L) / dur).toInt().coerceIn(0, 1000)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        try {
            val rawJson = intent.getStringExtra(EXTRA_PAYLOAD_JSON) ?: return
            val obj = JSONObject(rawJson)
            val newUrl = obj.optString("url", "")
            if (newUrl.isBlank()) return
            if (newUrl == streamUrl && exoPlayer != null) {
                return
            }
            val resumeSec = (exoPlayer?.currentPosition ?: 0L) / 1000L
            if (resumeSec > 5L && obj.optLong("startTimeSec", 0L) <= 0L) {
                obj.put("startTimeSec", resumeSec)
                intent.putExtra(EXTRA_PAYLOAD_JSON, obj.toString())
            }
            parseIntentAndStart(intent)
        } catch (_: Throwable) {}
    }

    private fun applySubtitleStyle() {
        try {
            val fgColor = try { Color.parseColor(subTextColorHex) } catch (_: Throwable) { Color.WHITE }
            val bgColor = when (subBgStyleMode) {
                "none" -> Color.TRANSPARENT
                "semi" -> Color.argb(115, 0, 0, 0)
                else -> Color.argb(200, 0, 0, 0)
            }
            playerView?.subtitleView?.apply {
                setStyle(
                    CaptionStyleCompat(
                        fgColor,
                        bgColor,
                        Color.TRANSPARENT,
                        CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW,
                        Color.BLACK,
                        Typeface.DEFAULT_BOLD
                    )
                )
                setFixedTextSize(TypedValue.COMPLEX_UNIT_SP, subTextSizeSp)
                setBottomPaddingFraction(0.045f)
            }
            subtitleOverlayView?.apply {
                setTextColor(fgColor)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, subTextSizeSp)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = 14f
                    setColor(bgColor)
                }
            }
        } catch (_: Throwable) {}
    }

    private fun parseIntentAndStart(intent: Intent?) {
        val rawJson = intent?.getStringExtra(EXTRA_PAYLOAD_JSON) ?: "{}"
        val obj = try {
            JSONObject(rawJson)
        } catch (_: Throwable) {
            JSONObject()
        }
        rawPayload = obj

        streamUrl = obj.optString("url", "")
        streamTitle = obj.optString("title", "SingularityTV")
        progressKey = obj.optString("progressKey").takeIf { it.isNotEmpty() }
        startTimeSec = obj.optLong("startTimeSec", 0L)
        imdbId = obj.optString("imdbId", "")
        mediaType = obj.optString("mediaType", "movie")
        seasonNum = obj.optInt("season", 1)
        episodeNum = obj.optInt("episode", 1)
        seriesTitleStr = obj.optString("seriesTitle", "").ifEmpty { streamTitle.substringBefore(" · S") }
        totalEpisodesInSeason = obj.optInt("totalEpisodes", 0)
        preferredLang = obj.optString("preferredSubLang", "ar").ifBlank { "ar" }.substringBefore("-").lowercase()
        subTextColorHex = obj.optString("subTextColor", "#FFFFFF").ifBlank { "#FFFFFF" }
        subBgStyleMode = obj.optString("subBgStyle", "dark").ifBlank { "dark" }
        subTextSizeSp = obj.optDouble("subFontSizeSp", 22.0).toFloat().coerceIn(14f, 42f)
        applySubtitleStyle()
        titleView?.text = streamTitle
        serverBadgeView?.text = currentSource

        if (streamUrl.isBlank()) {
            currentSource = "hnembed"
            serverBadgeView?.text = currentSource
            startResolvingInitialSource()
            fetchOnlineSubtitlesInBackground()
            fetchSkipSegmentsInBackground()
            mainHandler.postDelayed({ startBackgroundServerProbing() }, 400L)
            return
        }

        availableSubs.clear()
        activeParsedCues.clear()
        activeSubIndex = -1

        val subsArray = obj.optJSONArray("subtitles") ?: obj.optJSONArray("subtitlePaths") ?: JSONArray()
        for (i in 0 until subsArray.length()) {
            val sObj = subsArray.optJSONObject(i) ?: continue
            val u = sObj.optString("url").ifEmpty { sObj.optString("path") }
            if (u.isBlank()) continue
            val lang = normalizeLangCode(sObj.optString("lang", "en"))
            val label = sObj.optString("label").ifBlank { "Stream · ${lang.uppercase()}" }
            availableSubs.add(PlayerSubTrack(label, lang, u, 120))
        }
        if (availableSubs.isNotEmpty()) {
            selectBestSubtitleForLanguage(preferredLang, silent = true)
        }

        initializeExoPlayer(obj)
        fetchOnlineSubtitlesInBackground()
    }

    private fun normalizeLangCode(raw: String): String {
        val full = raw.trim().lowercase().replace("_", "-")
        if (full == "pt-br" || full == "pob" || full == "pb" || full == "portuguese (brazil)") return "pt-br"
        val c = full.substringBefore("-")
        return when (c) {
            "ara", "arabic", "ar" -> "ar"
            "eng", "english", "en" -> "en"
            "fre", "fra", "french", "fr" -> "fr"
            "spa", "spanish", "es" -> "es"
            "ger", "deu", "german", "de" -> "de"
            "tur", "turkish", "tr" -> "tr"
            "por", "portuguese", "pt" -> "pt"
            "pob", "pb" -> "pt-br"
            "ita", "italian", "it" -> "it"
            "rus", "russian", "ru" -> "ru"
            "jpn", "japanese", "ja" -> "ja"
            "kor", "korean", "ko" -> "ko"
            "chi", "zho", "chinese", "zh", "zht", "zhs" -> "zh"
            "hin", "hindi", "hi" -> "hi"
            "ind", "indonesian", "id" -> "id"
            "dut", "nld", "dutch", "nl" -> "nl"
            "pol", "polish", "pl" -> "pl"
            "swe", "swedish", "sv" -> "sv"
            "gre", "ell", "greek", "el" -> "el"
            "per", "fas", "persian", "fa" -> "fa"
            "heb", "hebrew", "he", "iw" -> "he"
            "tha", "thai", "th" -> "th"
            "vie", "vietnamese", "vi" -> "vi"
            "bos", "bosnian", "bs" -> "bs"
            "bul", "bulgarian", "bg" -> "bg"
            "hrv", "scr", "croatian", "hr" -> "hr"
            "srp", "scc", "serbian", "sr" -> "sr"
            "ces", "cze", "czech", "cs" -> "cs"
            "slk", "slo", "slovak", "sk" -> "sk"
            "ron", "rum", "romanian", "ro" -> "ro"
            "ukr", "ukrainian", "uk" -> "uk"
            "hun", "hungarian", "hu" -> "hu"
            "fin", "finnish", "fi" -> "fi"
            "dan", "danish", "da" -> "da"
            "nor", "nob", "nno", "norwegian", "no" -> "no"
            "slv", "slovenian", "sl" -> "sl"
            "alb", "sqi", "albanian", "sq" -> "sq"
            "mac", "mkd", "macedonian", "mk" -> "mk"
            "est", "estonian", "et" -> "et"
            "lav", "latvian", "lv" -> "lv"
            "lit", "lithuanian", "lt" -> "lt"
            "may", "msa", "malay", "ms" -> "ms"
            "ben", "bengali", "bn" -> "bn"
            "urd", "urdu", "ur" -> "ur"
            "tam", "tamil", "ta" -> "ta"
            "tel", "telugu", "te" -> "te"
            "cat", "catalan", "ca" -> "ca"
            "baq", "eus", "basque", "eu" -> "eu"
            "glg", "galician", "gl" -> "gl"
            "ice", "isl", "icelandic", "is" -> "is"
            "geo", "kat", "georgian", "ka" -> "ka"
            "arm", "hye", "armenian", "hy" -> "hy"
            "aze", "azerbaijani", "az" -> "az"
            "kaz", "kazakh", "kk" -> "kk"
            "uzb", "uzbek", "uz" -> "uz"
            "tgl", "tagalog", "tl" -> "tl"
            "fil", "filipino" -> "fil"
            "swa", "swahili", "sw" -> "sw"
            "afr", "afrikaans", "af" -> "af"
            "mal", "malayalam", "ml" -> "ml"
            "mar", "marathi", "mr" -> "mr"
            "kan", "kannada", "kn" -> "kn"
            "pan", "punjabi", "pa" -> "pa"
            "sin", "sinhala", "si" -> "si"
            "bur", "mya", "burmese", "my" -> "my"
            "khm", "khmer", "km" -> "km"
            "lao", "la" -> "lo"
            "mon", "mongolian", "mn" -> "mn"
            "nep", "nepali", "ne" -> "ne"
            "amh", "amharic", "am" -> "am"
            "kur", "kurdish", "ku" -> "ku"
            "pus", "pashto", "ps" -> "ps"
            "epo", "esperanto", "eo" -> "eo"
            "gle", "irish", "ga" -> "ga"
            "wel", "cym", "welsh", "cy" -> "cy"
            "mlt", "maltese", "mt" -> "mt"
            "bel", "belarusian", "be" -> "be"
            else -> if (c.isNotEmpty()) c else "en"
        }
    }

    private fun langDisplayName(code: String): String {
        val norm = normalizeLangCode(code)
        return when (norm) {
            "ar" -> "Arabic"
            "en" -> "English"
            "ko" -> "Korean"
            "ja" -> "Japanese"
            "fr" -> "French"
            "es" -> "Spanish"
            "de" -> "German"
            "tr" -> "Turkish"
            "pt" -> "Portuguese"
            "pt-br" -> "Portuguese (Brazil)"
            "it" -> "Italian"
            "ru" -> "Russian"
            "hi" -> "Hindi"
            "id" -> "Indonesian"
            "zh" -> "Chinese"
            "nl" -> "Dutch"
            "pl" -> "Polish"
            "sv" -> "Swedish"
            "th" -> "Thai"
            "vi" -> "Vietnamese"
            "fa" -> "Persian"
            "bs" -> "Bosnian"
            "bg" -> "Bulgarian"
            "hr" -> "Croatian"
            "sr" -> "Serbian"
            "cs" -> "Czech"
            "sk" -> "Slovak"
            "ro" -> "Romanian"
            "el" -> "Greek"
            "he" -> "Hebrew"
            "uk" -> "Ukrainian"
            "hu" -> "Hungarian"
            "fi" -> "Finnish"
            "da" -> "Danish"
            "no" -> "Norwegian"
            "sl" -> "Slovenian"
            "sq" -> "Albanian"
            "mk" -> "Macedonian"
            "et" -> "Estonian"
            "lv" -> "Latvian"
            "lt" -> "Lithuanian"
            "ms" -> "Malay"
            "bn" -> "Bengali"
            "ur" -> "Urdu"
            "ta" -> "Tamil"
            "te" -> "Telugu"
            "ca" -> "Catalan"
            "eu" -> "Basque"
            "gl" -> "Galician"
            "is" -> "Icelandic"
            "ka" -> "Georgian"
            "hy" -> "Armenian"
            "az" -> "Azerbaijani"
            "kk" -> "Kazakh"
            "uz" -> "Uzbek"
            "tl" -> "Tagalog"
            "fil" -> "Filipino"
            "sw" -> "Swahili"
            "af" -> "Afrikaans"
            "ml" -> "Malayalam"
            "mr" -> "Marathi"
            "kn" -> "Kannada"
            "pa" -> "Punjabi"
            "si" -> "Sinhala"
            "my" -> "Burmese"
            "km" -> "Khmer"
            "lo" -> "Lao"
            "mn" -> "Mongolian"
            "ne" -> "Nepali"
            "am" -> "Amharic"
            "ku" -> "Kurdish"
            "ps" -> "Pashto"
            "eo" -> "Esperanto"
            "ga" -> "Irish"
            "cy" -> "Welsh"
            "mt" -> "Maltese"
            "be" -> "Belarusian"
            else -> try {
                val loc = Locale.forLanguageTag(norm)
                val name = loc.getDisplayLanguage(Locale.ENGLISH)
                if (name.isNotBlank() && !name.equals(norm, ignoreCase = true) && !name.equals("und", ignoreCase = true)) {
                    name.replaceFirstChar { it.uppercase() }
                } else {
                    norm.uppercase()
                }
            } catch (_: Throwable) {
                norm.uppercase()
            }
        }
    }

    private fun scoreTrackForCurrentStream(track: PlayerSubTrack): Int {
        var s = track.score
        val u = track.label.uppercase()
        if (activeQualityTag.isNotEmpty() && u.contains(activeQualityTag)) {
            s += 35
        }
        if (streamUrl.contains("vidsrc", ignoreCase = true) || streamUrl.contains("m3u8", ignoreCase = true)) {
            if (Regex("WEB[-_. ]?DL|WEBRIP|NF|AMZN|DSNP|ATVP|HMAX").containsMatchIn(u)) {
                s += 40
            }
        }
        return s
    }

    private fun selectBestSubtitleForLanguage(langCode: String, silent: Boolean = false): Boolean {
        val norm = normalizeLangCode(langCode)
        val matches = availableSubs.mapIndexedNotNull { idx, t ->
            if (t.lang == norm) idx to scoreTrackForCurrentStream(t) else null
        }.sortedByDescending { it.second }

        if (matches.isEmpty()) {
            if (!silent) {
                offerServerSwitchForLanguage(norm)
            }
            return false
        }

        val bestIdx = matches.first().first
        activeSubIndex = bestIdx
        preferredLang = norm
        subBtn?.text = "Subtitles (${availableSubs.size})"
        loadSubtitleCuesAsync(bestIdx)
        if (!silent) {
            Toast.makeText(
                this,
                "Auto-synced ${langDisplayName(norm)}: ${availableSubs[bestIdx].label}",
                Toast.LENGTH_SHORT
            ).show()
        }
        return true
    }

    private fun offerServerSwitchForLanguage(langCode: String) {
        AlertDialog.Builder(this)
            .setTitle("No ${langDisplayName(langCode)} Subtitle on This Server")
            .setMessage("Would you like to switch to another streaming server and load a matching ${langDisplayName(langCode)} subtitle?")
            .setPositiveButton("Switch Server") { _, _ ->
                saveCurrentProgress()
                ExoProgressBus.serverSwitchListener?.invoke(langCode)
                finish()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun mergeFetchedTracks(batch: List<PlayerSubTrack>) {
        if (batch.isEmpty()) return
        runOnUiThread {
            if (isDestroyed) return@runOnUiThread
            val existingUrls = availableSubs.map { it.urlOrPath }.toHashSet()
            val fresh = batch.filter { it.urlOrPath !in existingUrls }.sortedByDescending { it.score }
            if (fresh.isEmpty()) return@runOnUiThread
            val wasEmpty = activeSubIndex == -1
            availableSubs.addAll(fresh)
            subBtn?.text = "Subtitles (${availableSubs.size})"
            if (wasEmpty) {
                if (!selectBestSubtitleForLanguage(preferredLang, silent = true)) {
                    selectBestSubtitleForLanguage("ar", silent = true) || selectBestSubtitleForLanguage("en", silent = true)
                }
            }
        }
    }

    private fun queryWyzieLanguage(qLang: String): List<PlayerSubTrack> {
        val list = mutableListOf<PlayerSubTrack>()
        try {
            val qs = StringBuilder("id=${URLEncoder.encode(imdbId, "UTF-8")}&format=srt")
            if (qLang.isNotEmpty()) {
                qs.append("&language=").append(URLEncoder.encode(qLang, "UTF-8"))
            }
            if (mediaType == "tv") {
                qs.append("&season=").append(seasonNum).append("&episode=").append(episodeNum)
            }
            val req = Request.Builder()
                .url("https://subs.wyzie.ru/search?$qs")
                .header("User-Agent", "SingularityTV/2.7.3")
                .build()
            StreambertApp.instance.okHttpClient.newCall(req).execute().use { res ->
                if (res.isSuccessful) {
                    val body = res.body?.string()?.trim() ?: "[]"
                    if (body.startsWith("[")) {
                        val arr = JSONArray(body)
                        for (i in 0 until arr.length()) {
                            val item = arr.optJSONObject(i) ?: continue
                            val rawUrl = item.optString("url")
                            if (rawUrl.isBlank()) continue
                            val fullUrl = if (rawUrl.startsWith("http")) rawUrl else "https://subs.wyzie.ru$rawUrl"
                            val rawItemLang = item.optString("language")
                                .ifBlank { item.optString("lang") }
                                .ifBlank { item.optString("iso639") }
                                .ifBlank { qLang.ifEmpty { "en" } }
                            val lang = normalizeLangCode(rawItemLang)
                            val rel = item.optString("display_name")
                                .ifBlank { item.optString("release_name") }
                                .ifBlank { "Wyzie ${langDisplayName(lang)} #${i + 1}" }
                            if (!isSubtitleMatchingCurrentEpisode(rel)) continue
                            val sc = scoreReleaseName(rel) + if (lang == preferredLang || lang == "ar") 35 else 0
                            list.add(PlayerSubTrack("${langDisplayName(lang)} · $rel", lang, fullUrl, sc))
                        }
                    }
                }
            }
        } catch (_: Throwable) {}
        return list
    }

    private fun isSubtitleMatchingCurrentEpisode(
        relName: String,
        seasonField: String = "",
        episodeField: String = "",
        kindField: String = "",
        requireExplicitOnTv: Boolean = false
    ): Boolean {
        val isTv = mediaType.equals("tv", ignoreCase = true)
        val sInt = seasonField.trim().toIntOrNull() ?: 0
        val eInt = episodeField.trim().toIntOrNull() ?: 0
        val kTrim = kindField.trim().lowercase()
        val hasExactFields = isTv && sInt > 0 && eInt > 0
        if (isTv) {
            if (sInt > 0 && sInt != seasonNum) return false
            if (eInt > 0 && eInt != episodeNum) return false
        } else {
            if (kTrim == "episode") return false
            if (sInt > 0 || eInt > 0) return false
        }
        val l = relName.lowercase()
        if (l.isBlank()) return if (isTv) (hasExactFields || !requireExplicitOnTv) else true
        val epRegex = Regex("(?:s(\\d{1,2})[\\s._-]*e(\\d{1,2})|\\b(\\d{1,2})x(\\d{1,2})\\b)")
        val matches = epRegex.findAll(l).toList()
        if (matches.isNotEmpty()) {
            if (!isTv) return false
            var foundMatch = false
            for (m in matches) {
                val sStr = m.groupValues[1].ifEmpty { m.groupValues[3] }
                val eStr = m.groupValues[2].ifEmpty { m.groupValues[4] }
                val sVal = sStr.toIntOrNull()
                val eVal = eStr.toIntOrNull()
                if (sVal == seasonNum && eVal == episodeNum) {
                    foundMatch = true
                    break
                }
            }
            return foundMatch
        }
        if (isTv) {
            if (l.contains("complete") || l.contains("season pack") || l.contains("full season")) {
                return false
            }
            val epOnly = Regex("(?:\\bepisode[\\s._-]*(\\d{1,2})\\b|\\bep[\\s._-]*(\\d{1,2})\\b|\\be(\\d{1,2})\\b)")
            val epMatches = epOnly.findAll(l).toList()
            if (epMatches.isNotEmpty()) {
                var foundEp = false
                for (m in epMatches) {
                    val eStr = m.groupValues[1].ifEmpty { m.groupValues[2].ifEmpty { m.groupValues[3] } }
                    if (eStr.toIntOrNull() == episodeNum) {
                        foundEp = true
                        break
                    }
                }
                return foundEp
            }
            if (requireExplicitOnTv && !hasExactFields) return false
        }
        return true
    }

    private fun fetchOnlineSubtitlesInBackground() {
        if (!imdbId.startsWith("tt")) return
        val osType = if (mediaType == "tv") "series" else "movie"
        val osTarget = if (mediaType == "tv") "$imdbId:$seasonNum:$episodeNum" else imdbId
        val stremioUrls = listOf(
            "https://opensubtitles-v3.strem.io/subtitles/$osType/${URLEncoder.encode(osTarget, "UTF-8")}.json"
        )
        for (stUrl in stremioUrls) {
            thread(start = true) {
                val osList = mutableListOf<PlayerSubTrack>()
                try {
                    val req = Request.Builder()
                        .url(stUrl)
                        .header("User-Agent", "SingularityTV/2.7.3")
                        .build()
                    StreambertApp.instance.okHttpClient.newCall(req).execute().use { res ->
                        if (res.isSuccessful) {
                            val root = JSONObject(res.body?.string() ?: "{}")
                            val subs = root.optJSONArray("subtitles") ?: JSONArray()
                            val perLangCount = HashMap<String, Int>()
                            for (i in 0 until minOf(subs.length(), 300)) {
                                val s = subs.optJSONObject(i) ?: continue
                                val u = s.optString("url")
                                val rawLang = s.optString("lang").ifBlank { "en" }
                                if (u.isBlank()) continue
                                val relHint = listOf(
                                    s.optString("SubFileName"),
                                    s.optString("title"),
                                    s.optString("name"),
                                    s.optString("release"),
                                    s.optString("id"),
                                    u
                                ).filter { it.isNotBlank() }.joinToString(" ")
                                if (!isSubtitleMatchingCurrentEpisode(relHint)) continue
                                val normLang = normalizeLangCode(rawLang)
                                val cnt = (perLangCount[normLang] ?: 0) + 1
                                perLangCount[normLang] = cnt
                                val bonus = if (normLang == "ar" || normLang == preferredLang) 35 else 0
                                osList.add(PlayerSubTrack("${langDisplayName(normLang)} · OpenSubtitles #$cnt", normLang, u, 75 + bonus))
                            }
                        }
                    }
                } catch (_: Throwable) {}
                mergeFetchedTracks(osList)
            }
        }

        val numericImdb = imdbId.removePrefix("tt")
        if (numericImdb.isNotEmpty()) {
            val worldLangs = listOf("ara", "eng", "spa", "fre", "ger", "tur", "por", "ita", "rus", "jpn", "kor", "hin", "all")
            for (wLang in worldLangs) {
                thread(start = true) {
                    val restList = mutableListOf<PlayerSubTrack>()
                    try {
                        val restUrl = if (mediaType == "tv") {
                            "https://rest.opensubtitles.org/search/episode-$episodeNum/imdbid-$numericImdb/season-$seasonNum/sublanguageid-$wLang"
                        } else {
                            "https://rest.opensubtitles.org/search/imdbid-$numericImdb/sublanguageid-$wLang"
                        }
                        val req = Request.Builder()
                            .url(restUrl)
                            .header("X-User-Agent", "TemporaryUserAgent")
                            .header("User-Agent", "TemporaryUserAgent")
                            .build()
                        StreambertApp.instance.okHttpClient.newCall(req).execute().use { res ->
                            if (res.isSuccessful) {
                                val body = res.body?.string()?.trim() ?: "[]"
                                if (body.startsWith("[")) {
                                    val arr = JSONArray(body)
                                    val perLang = HashMap<String, Int>()
                                    for (i in 0 until minOf(arr.length(), 60)) {
                                        val item = arr.optJSONObject(i) ?: continue
                                        val rawDl = item.optString("SubDownloadLink")
                                        if (rawDl.isBlank()) continue
                                        val dlUrl = rawDl.replace(".gz", "")
                                        val iso = item.optString("ISO639").ifBlank { item.optString("SubLanguageID").ifBlank { "en" } }
                                        val normLang = normalizeLangCode(iso)
                                        val rel = item.optString("MovieReleaseName").ifBlank { item.optString("SubFileName").ifBlank { "" } }
                                        val cleanNum = numericImdb.trimStart('0')
                                        val itemImdb = item.optString("IDMovieImdb").removePrefix("tt").trim().trimStart('0')
                                        val parentImdb = item.optString("SeriesIMDBParent").removePrefix("tt").trim().trimStart('0')
                                        val isTv = mediaType.equals("tv", ignoreCase = true)
                                        if (!isTv && itemImdb.isNotEmpty() && itemImdb != cleanNum) continue
                                        if (isTv && parentImdb.isNotEmpty() && parentImdb != cleanNum) continue
                                        val sField = item.optString("SeriesSeason")
                                        val eField = item.optString("SeriesEpisode")
                                        val kField = item.optString("MovieKind")
                                        if (!isSubtitleMatchingCurrentEpisode(rel, sField, eField, kField, requireExplicitOnTv = true)) continue
                                        val cnt = (perLang[normLang] ?: 0) + 1
                                        perLang[normLang] = cnt
                                        val displayRel = rel.ifBlank { "OS #$cnt" }
                                        val sc = scoreReleaseName(displayRel) + if (normLang == "ar" || normLang == preferredLang) 35 else 0
                                        restList.add(PlayerSubTrack("${langDisplayName(normLang)} · $displayRel", normLang, dlUrl, sc + 20))
                                    }
                                }
                            }
                        }
                    } catch (_: Throwable) {}
                    mergeFetchedTracks(restList)
                }
            }
        }
    }

    private fun scoreReleaseName(name: String): Int {
        val u = name.uppercase()
        var score = 0
        if (Regex("WEB[-_. ]?DL|WEBRIP|AMZN|NF|DSNP|ATVP|HMAX").containsMatchIn(u)) score += 55
        if (Regex("1080P|720P|X264|H264").containsMatchIn(u)) score += 20
        if (Regex("EXTENDED|DIRECTORS|UNRATED|CAM|TS").containsMatchIn(u)) score -= 50
        return score
    }

    private fun buildPlayerMediaItem(url: String): MediaItem {
        val uri = if (url.startsWith("/")) Uri.fromFile(File(url)) else Uri.parse(url)
        val builder = MediaItem.Builder().setUri(uri)
        val lower = url.lowercase()
        if (streamIsHlsMap[url] == true || lower.contains(".m3u8") || lower.contains("master.txt") || lower.contains("playlist.txt") || lower.contains("/hls/") || lower.contains("/hls2/") || lower.contains("type=hls")) {
            builder.setMimeType(MimeTypes.APPLICATION_M3U8)
        } else if (lower.contains(".mpd")) {
            builder.setMimeType(MimeTypes.APPLICATION_MPD)
        }
        return builder.build()
    }

    private fun initializeExoPlayer(payload: JSONObject) {
        try {
            exoPlayer?.release()
            exoPlayer = null

            currentSource = "hnembed"
            val capturedHeaders = AdBlockerInterceptor.streamHeadersMap[streamUrl] ?: emptyMap()
            fun findHeader(name: String): String? {
                for ((k, v) in capturedHeaders) {
                    if (k.equals(name, ignoreCase = true) && v.isNotBlank()) return v
                }
                return null
            }
            val lowerStream = streamUrl.lowercase()
            val stripRef = retryCount >= 1 || lowerStream.contains("googlevideo") || lowerStream.contains("googleusercontent")
            val referer = if (stripRef) "" else (findHeader("Referer")
                ?: streamRefererMap[streamUrl]?.takeIf { it.isNotEmpty() }
                ?: payload.optString("referer").takeIf { it.isNotEmpty() }
                ?: getDefaultRefererForSource(currentSource))
            val origin = if (stripRef) "" else (findHeader("Origin") ?: "")
            val userAgent = findHeader("User-Agent")
                ?: payload.optString("userAgent").takeIf { it.isNotEmpty() }
                ?: "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
            val cookieStr = try {
                CookieManager.getInstance().getCookie(streamUrl) ?: ""
            } catch (_: Throwable) { "" }

            val httpFactory = OkHttpDataSource.Factory(StreambertApp.instance.okHttpClient)
                .setUserAgent(userAgent)
                .apply {
                    val headers = mutableMapOf<String, String>()
                    if (referer.isNotEmpty()) headers["Referer"] = referer
                    if (origin.isNotEmpty()) headers["Origin"] = origin
                    if (cookieStr.isNotEmpty()) headers["Cookie"] = cookieStr
                    headers["Accept"] = "*/*"
                    setDefaultRequestProperties(headers)
                }

            val dataSourceFactory = DefaultDataSource.Factory(this, httpFactory)
            val loadControl = DefaultLoadControl.Builder()
                .setBufferDurationsMs(15_000, 60_000, 2_500, 5_000)
                .build()

            val player = ExoPlayer.Builder(this)
                .setMediaSourceFactory(DefaultMediaSourceFactory(dataSourceFactory))
                .setLoadControl(loadControl)
                .setHandleAudioBecomingNoisy(true)
                .setAudioAttributes(
                    androidx.media3.common.AudioAttributes.Builder()
                        .setUsage(C.USAGE_MEDIA)
                        .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                        .build(),
                    true
                )
                .build()

            player.setMediaItem(buildPlayerMediaItem(streamUrl))

            if (startTimeSec > 0) {
                player.seekTo(startTimeSec * 1000L)
            }

            player.addListener(object : Player.Listener {
                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    updateTimeAndSeekBar()
                    if (!isPlaying) {
                        setControllerVisible(true)
                    } else {
                        showControllerTemporarily()
                    }
                }

                override fun onPlayerError(error: PlaybackException) {
                    mainHandler.removeCallbacks(playbackReadyWatchdogRunnable)
                    if (retryCount < 1) {
                        retryCount++
                        initializeExoPlayer(JSONObject().put("currentSource", currentSource))
                    } else if (!streamUrl.startsWith("/")) {
                        verifiedServers.remove(currentSource)
                        probedFailedServers.add(currentSource)
                        updateSwitchServerButtonText()
                        recordServerStatus(currentSource, "failed")
                        isSwitchingServer = false
                        triggerNextServerFailover()
                    } else {
                        Toast.makeText(
                            this@NativeExoPlayerActivity,
                            "Playback error: ${error.errorCodeName}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }

                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_READY) {
                        val minValidMs = if (mediaType.equals("tv", ignoreCase = true)) 60_000L else 180_000L
                        val vs = player.videoSize
                        val isPortraitAd = vs.width > 0 && vs.height > 0 && vs.height > vs.width * 0.95
                        if (!streamUrl.startsWith("/") && (isPortraitAd || (player.duration > 0L && player.duration < minValidMs))) {
                            player.pause()
                            playerView?.alpha = 0f
                            streamUrl = ""
                            isSwitchingServer = true
                            Toast.makeText(this@NativeExoPlayerActivity, "Blocked ad clip", Toast.LENGTH_SHORT).show()
                            showCaptchaCard("hnembed")
                            return
                        }
                        playerView?.alpha = 1f
                        mainHandler.removeCallbacks(playbackReadyWatchdogRunnable)
                        mainHandler.removeCallbacks(failoverWatchdogRunnable)
                        isSwitchingServer = false
                        retryCount = 0
                        serverFailoverAttempts = 0
                        recordServerStatus(currentSource, "working")
                        if (player.duration > 60_000L) {
                            fetchSkipSegmentsInBackground(player.duration)
                        }
                        if (currentSource.isNotBlank()) {
                            try {
                                getSharedPreferences("singularity_prefs", Context.MODE_PRIVATE)
                                    .edit().putString("last_working_source", currentSource).apply()
                            } catch (_: Throwable) {}
                            ExoProgressBus.preferredSourceListener?.invoke(currentSource)
                        }
                        if (startTimeSec > 0L && player.duration > 0L && startTimeSec * 1000L >= player.duration - 15_000L) {
                            startTimeSec = 0L
                            player.seekTo(0L)
                        }
                        updateTimeAndSeekBar()
                    } else if (playbackState == Player.STATE_ENDED) {
                        mainHandler.removeCallbacks(playbackReadyWatchdogRunnable)
                        saveCurrentProgress(forceCompleted = true)
                        finish()
                    }
                }
            })

            player.prepare()
            player.playWhenReady = true

            playerView?.alpha = if (streamUrl.startsWith("/")) 1f else 0f
            playerView?.player = player
            exoPlayer = player
            if (!streamUrl.startsWith("/")) {
                mainHandler.removeCallbacks(playbackReadyWatchdogRunnable)
                mainHandler.postDelayed(playbackReadyWatchdogRunnable, 9000L)
            }

            mainHandler.removeCallbacks(progressRunnable)
            mainHandler.postDelayed(progressRunnable, 5000L)
            mainHandler.removeCallbacks(uiTickRunnable)
            mainHandler.post(uiTickRunnable)
            mainHandler.removeCallbacks(subtitleTickRunnable)
            mainHandler.post(subtitleTickRunnable)
        } catch (t: Throwable) {
            Toast.makeText(this, "Stream error: ${t.localizedMessage}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadSubtitleCuesAsync(subIndex: Int) {
        if (subIndex < 0 || subIndex >= availableSubs.size) {
            activeParsedCues.clear()
            runOnUiThread {
                subtitleOverlayView?.visibility = View.GONE
            }
            return
        }
        val track = availableSubs[subIndex]
        thread(start = true) {
            try {
                val rawText = if (track.urlOrPath.startsWith("/")) {
                    File(track.urlOrPath).readText(Charsets.UTF_8)
                } else {
                    val req = Request.Builder()
                        .url(track.urlOrPath)
                        .header("User-Agent", "Mozilla/5.0 (Linux; Android 14)SingularityTV/2.7.3")
                        .build()
                    StreambertApp.instance.okHttpClient.newCall(req).execute().use { res ->
                        res.body?.string() ?: ""
                    }
                }
                val parsed = parseSrtOrVtt(rawText)
                activeParsedCues.clear()
                activeParsedCues.addAll(parsed)
                runOnUiThread {
                    if (!isDestroyed) {
                        autoDetectSegmentsFromStreamAndCues()
                        updateLiveSubtitleOverlay()
                    }
                }
            } catch (_: Throwable) {}
        }
    }

    private fun parseSrtOrVtt(raw: String): List<ParsedSubCue> {
        if (raw.isBlank()) return emptyList()
        val clean = raw.replace("\uFEFF", "").replace("\r\n", "\n").replace("\r", "\n")
        val blocks = clean.split(Regex("\n\\s*\n"))
        val list = ArrayList<ParsedSubCue>(blocks.size)
        val arrowRegex = Regex("""(\d{1,2}:)?(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d{1,2}:)?(\d{2}):(\d{2})[,.](\d{1,3})""")
        val htmlTagRegex = Regex("""<[^>]*>""")

        for (block in blocks) {
            val lines = block.lines().map { it.trim() }.filter { it.isNotEmpty() }
            if (lines.isEmpty() || lines[0].startsWith("WEBVTT")) continue
            var matchLineIdx = -1
            var matchResult: MatchResult? = null
            for (i in lines.indices) {
                val m = arrowRegex.find(lines[i])
                if (m != null) {
                    matchLineIdx = i
                    matchResult = m
                    break
                }
            }
            if (matchLineIdx == -1 || matchResult == null) continue
            val g = matchResult.groupValues
            val startH = g[1].trimEnd(':').toLongOrNull() ?: 0L
            val startM = g[2].toLongOrNull() ?: 0L
            val startS = g[3].toLongOrNull() ?: 0L
            val startMs = g[4].padEnd(3, '0').take(3).toLongOrNull() ?: 0L
            val endH = g[5].trimEnd(':').toLongOrNull() ?: 0L
            val endM = g[6].toLongOrNull() ?: 0L
            val endS = g[7].toLongOrNull() ?: 0L
            val endMs = g[8].padEnd(3, '0').take(3).toLongOrNull() ?: 0L

            val startTotal = (startH * 3600L + startM * 60L + startS) * 1000L + startMs
            val endTotal = (endH * 3600L + endM * 60L + endS) * 1000L + endMs
            val textLines = lines.subList(matchLineIdx + 1, lines.size)
            val text = textLines.joinToString("\n").replace(htmlTagRegex, "").trim()
            if (text.isNotEmpty() && endTotal > startTotal) {
                list.add(ParsedSubCue(startTotal, endTotal, text))
            }
        }
        return list
    }

    private fun updateLiveSubtitleOverlay() {
        val overlay = subtitleOverlayView ?: return
        val player = exoPlayer
        if (player == null || activeSubIndex < 0 || activeParsedCues.isEmpty()) {
            if (overlay.visibility != View.GONE) overlay.visibility = View.GONE
            return
        }
        val posMs = player.currentPosition - subDelayMs
        val hit = activeParsedCues.firstOrNull { posMs >= it.startMs && posMs <= it.endMs }
        if (hit != null && hit.text.isNotEmpty()) {
            if (overlay.text.toString() != hit.text) {
                overlay.text = hit.text
            }
            if (overlay.visibility != View.VISIBLE) {
                overlay.visibility = View.VISIBLE
            }
        } else {
            if (overlay.visibility != View.GONE) {
                overlay.visibility = View.GONE
            }
        }
    }

    private fun createDialogItemBg(focused: Boolean): GradientDrawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(10).toFloat()
            if (focused) {
                setColor(Color.argb(65, 255, 255, 255))
                setStroke(dp(2), Color.WHITE)
            } else {
                setColor(Color.argb(18, 255, 255, 255))
            }
        }
    }

    private fun showStyledMenuDialog(title: String, items: Array<String>, onSelect: (Int) -> Unit) {
        val dlg = android.app.Dialog(this)
        dlg.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE)
        dlg.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
            setPadding(dp(20), dp(18), dp(20), dp(18))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dp(16).toFloat()
                setColor(Color.rgb(18, 22, 32))
                setStroke(dp(1), Color.argb(45, 255, 255, 255))
            }
        }

        val titleTv = TextView(this).apply {
            text = title
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(6), 0, dp(6), dp(12))
        }
        card.addView(titleTv)

        val scroll = android.widget.ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            clipChildren = false
            clipToPadding = false
            layoutParams = LinearLayout.LayoutParams(
                dp(420),
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                val maxH = (resources.displayMetrics.heightPixels * 0.62f).toInt()
                if (items.size > 7) height = maxH
            }
        }

        val listBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            clipChildren = false
            clipToPadding = false
            setPadding(dp(4), dp(4), dp(4), dp(4))
        }

        var firstRow: TextView? = null
        items.forEachIndexed { idx, label ->
            val row = TextView(this).apply {
                text = label
                setTextColor(Color.argb(235, 240, 244, 248))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                typeface = Typeface.DEFAULT_BOLD
                setPadding(dp(16), dp(12), dp(16), dp(12))
                background = createDialogItemBg(false)
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    setMargins(0, dp(3), 0, dp(3))
                }
                isFocusable = true
                isFocusableInTouchMode = false
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    defaultFocusHighlightEnabled = false
                }
                setOnFocusChangeListener { v, hasFocus ->
                    v.background = createDialogItemBg(hasFocus)
                    (v as TextView).setTextColor(if (hasFocus) Color.WHITE else Color.argb(220, 226, 232, 240))
                    v.animate()
                        .scaleX(if (hasFocus) 1.02f else 1.0f)
                        .scaleY(if (hasFocus) 1.02f else 1.0f)
                        .setDuration(110)
                        .start()
                }
                setOnClickListener {
                    dlg.dismiss()
                    onSelect(idx)
                }
            }
            if (idx == 0) firstRow = row
            listBox.addView(row)
        }

        scroll.addView(listBox)
        card.addView(scroll)
        dlg.setContentView(card)
        dlg.show()
        firstRow?.post { firstRow?.requestFocus() }
    }

    private fun showSubtitlesMenuDialog() {
        val langCount = availableSubs.map { it.lang }.distinct().size
        val options = arrayOf(
            "Select Language ($langCount languages)",
            "Choose Subtitle Track (${availableSubs.size} found)",
            "Turn Subtitles Off"
        )
        showStyledMenuDialog("Subtitles", options) { which ->
            when (which) {
                0 -> showLanguagePickerDialog()
                1 -> showSubtitleTrackPicker()
                2 -> {
                    activeSubIndex = -1
                    activeParsedCues.clear()
                    subtitleOverlayView?.visibility = View.GONE
                    Toast.makeText(this, "Subtitles turned off", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun showSubtitleDelayDialog() {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(10))
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }
        val earlierTv = TextView(this).apply {
            text = "Earlier"
            setTextColor(Color.LTGRAY)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setPadding(0, 0, dp(8), 0)
        }
        val valTv = TextView(this).apply {
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(12), 0, dp(12), 0)
        }
        fun refreshText() {
            val sec = subDelayMs / 1000.0
            val sign = if (subDelayMs > 0L) "+" else ""
            valTv.text = String.format(java.util.Locale.US, "%s%.1fs", sign, sec)
            updateLiveSubtitleOverlay()
        }
        refreshText()
        var holdRunnable: Runnable? = null
        fun makeStepBtn(label: String, deltaMs: Long): Button {
            return Button(this).apply {
                text = label
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
                typeface = Typeface.DEFAULT_BOLD
                background = createSecondaryBg(false)
                layoutParams = LinearLayout.LayoutParams(dp(48), dp(42))
                setOnClickListener {
                    subDelayMs += deltaMs
                    refreshText()
                }
                setOnTouchListener { _, ev ->
                    when (ev.action) {
                        MotionEvent.ACTION_DOWN -> {
                            holdRunnable?.let { mainHandler.removeCallbacks(it) }
                            val r = object : Runnable {
                                override fun run() {
                                    subDelayMs += deltaMs
                                    refreshText()
                                    mainHandler.postDelayed(this, 70L)
                                }
                            }
                            holdRunnable = r
                            mainHandler.postDelayed(r, 260L)
                        }
                        MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                            holdRunnable?.let { mainHandler.removeCallbacks(it) }
                            holdRunnable = null
                        }
                    }
                    false
                }
            }
        }
        val minusBtn = makeStepBtn("−", -100L)
        val plusBtn = makeStepBtn("+", 100L)
        val laterTv = TextView(this).apply {
            text = "Later"
            setTextColor(Color.LTGRAY)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            setPadding(dp(8), 0, 0, 0)
        }
        row.addView(earlierTv)
        row.addView(minusBtn)
        row.addView(valTv)
        row.addView(plusBtn)
        row.addView(laterTv)
        wrap.addView(row)

        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle("Subtitle Sync")
            .setView(wrap)
            .setNeutralButton("Reset 0.0") { _, _ ->
                subDelayMs = 0L
                updateLiveSubtitleOverlay()
            }
            .setPositiveButton("Done", null)
            .show()
            .apply {
                setOnDismissListener {
                    holdRunnable?.let { mainHandler.removeCallbacks(it) }
                }
            }
    }

    private fun showLanguagePickerDialog() {
        val grouped = availableSubs.groupBy { it.lang }
        if (grouped.isEmpty()) {
            Toast.makeText(this, "Searching subtitles across all languages…", Toast.LENGTH_SHORT).show()
            fetchOnlineSubtitlesInBackground()
            return
        }
        val codes = grouped.keys.sortedWith(compareByDescending<String> { it == preferredLang }.thenBy { langDisplayName(it) })
        val labels = codes.map { code ->
            val mark = if (code == preferredLang && activeSubIndex >= 0) "● " else ""
            "$mark${langDisplayName(code)} (${grouped[code]?.size ?: 0})"
        }.toTypedArray()

        showStyledMenuDialog("Select Subtitle Language", labels) { which ->
            selectBestSubtitleForLanguage(codes[which], silent = false)
        }
    }

    private fun simpleLangName(code: String): String {
        return langDisplayName(code)
    }

    private fun showSubtitleTrackPicker() {
        if (availableSubs.isEmpty()) {
            Toast.makeText(this, "Searching online subtitles… try again in a moment", Toast.LENGTH_SHORT).show()
            fetchOnlineSubtitlesInBackground()
            return
        }
        val counts = mutableMapOf<String, Int>()
        val recLangs = mutableSetOf<String>()
        val labels = availableSubs.mapIndexed { idx, tr ->
            val num = (counts[tr.lang] ?: 0) + 1
            counts[tr.lang] = num
            val isRec = tr.score >= 85 && !recLangs.contains(tr.lang)
            if (isRec) recLangs.add(tr.lang)
            val mark = if (idx == activeSubIndex) "● " else ""
            val tag = ""
            "$mark${simpleLangName(tr.lang)} sub $num$tag"
        }.toTypedArray()
        showStyledMenuDialog("Select Subtitle Track", labels) { which ->
            activeSubIndex = which
            preferredLang = availableSubs[which].lang
            loadSubtitleCuesAsync(which)
            Toast.makeText(this, "Loaded: ${availableSubs[which].label}", Toast.LENGTH_SHORT).show()
        }
    }



    private fun showQualityDialog() {
        val player = exoPlayer ?: return
        val videoGroup = player.currentTracks.groups.firstOrNull { it.type == C.TRACK_TYPE_VIDEO }
        if (videoGroup == null) {
            Toast.makeText(this, "Auto Quality Active", Toast.LENGTH_SHORT).show()
            return
        }
        val items = mutableListOf<Pair<String, Int>>()
        items.add("Auto (Adaptive)" to -1)
        for (i in 0 until videoGroup.length) {
            val fmt = videoGroup.getTrackFormat(i)
            if (fmt.height > 0) {
                items.add("${fmt.height}p (${fmt.width}x${fmt.height})" to i)
            }
        }
        val labels = items.map { it.first }.distinct().toTypedArray()
        showStyledMenuDialog("Video Quality", labels) { which ->
            val chosen = items.firstOrNull { it.first == labels[which] } ?: return@showStyledMenuDialog
            if (chosen.second == -1) {
                activeQualityTag = ""
                player.trackSelectionParameters = player.trackSelectionParameters
                    .buildUpon()
                    .clearOverridesOfType(C.TRACK_TYPE_VIDEO)
                    .build()
            } else {
                val fmt = videoGroup.getTrackFormat(chosen.second)
                activeQualityTag = if (fmt.height > 0) "${fmt.height}P" else ""
                player.trackSelectionParameters = player.trackSelectionParameters
                    .buildUpon()
                    .setOverrideForType(TrackSelectionOverride(videoGroup.mediaTrackGroup, listOf(chosen.second)))
                    .build()
            }
            if (activeSubIndex >= 0) {
                selectBestSubtitleForLanguage(preferredLang, silent = true)
            }
        }
    }

    private fun showSpeedDialog(speedBtn: Button) {
        val speeds = floatArrayOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
        val labels = speeds.map { "${it}x" }.toTypedArray()
        showStyledMenuDialog("Playback Speed", labels) { which ->
            currentSpeed = speeds[which]
            exoPlayer?.setPlaybackSpeed(currentSpeed)
            speedBtn.text = "${currentSpeed}x"
        }
    }

    private fun enterPipIfSupported() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            try {
                val params = PictureInPictureParams.Builder()
                    .setAspectRatio(Rational(16, 9))
                    .build()
                enterPictureInPictureMode(params)
            } catch (_: Throwable) {}
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        if (isInPictureInPictureMode) {
            setControllerVisible(false)
        } else {
            showControllerTemporarily()
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            if (isCaptchaCardVisible) {
                val wv = resolverWebView
                val wrap = (captchaCardContainer?.getChildAt(1) as? FrameLayout)
                if (wv != null && wrap != null) {
                    if (isCaptchaCursorActive) {
                        val step = if (isCaptchaDragMode) 0.03f else 0.06f
                        val emitMoveIfDragging = {
                            if (isCaptchaDragMode) {
                                val tx = captchaCursorX * wv.width
                                val ty = captchaCursorY * wv.height
                                val nowT = android.os.SystemClock.uptimeMillis()
                                wv.dispatchTouchEvent(MotionEvent.obtain(captchaDragDownTime, nowT, MotionEvent.ACTION_MOVE, tx, ty, 0))
                            }
                        }
                        when (event.keyCode) {
                            KeyEvent.KEYCODE_DPAD_LEFT -> {
                                captchaCursorX = (captchaCursorX - step).coerceIn(0f, 1f)
                                updateCaptchaCursorPosition(wrap)
                                emitMoveIfDragging()
                                return true
                            }
                            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                                captchaCursorX = (captchaCursorX + step).coerceIn(0f, 1f)
                                updateCaptchaCursorPosition(wrap)
                                emitMoveIfDragging()
                                return true
                            }
                            KeyEvent.KEYCODE_DPAD_UP -> {
                                if (!isCaptchaDragMode && captchaCursorY <= 0.06f) {
                                    isCaptchaCursorActive = false
                                    captchaCursorView?.alpha = 0.25f
                                    showControllerTemporarily()
                                    if (captchaCursorX >= 0.55f) {
                                        captchaReloadBtn?.requestFocus()
                                    } else {
                                        switchServerBtn?.requestFocus()
                                    }
                                    return true
                                }
                                captchaCursorY = (captchaCursorY - step).coerceIn(0f, 1f)
                                updateCaptchaCursorPosition(wrap)
                                emitMoveIfDragging()
                                return true
                            }
                            KeyEvent.KEYCODE_DPAD_DOWN -> {
                                if (!isCaptchaDragMode && captchaCursorY >= 0.94f) {
                                    isCaptchaCursorActive = false
                                    captchaCursorView?.alpha = 0.25f
                                    showControllerTemporarily()
                                    subBtn?.requestFocus()
                                    return true
                                }
                                captchaCursorY = (captchaCursorY + step).coerceIn(0f, 1f)
                                updateCaptchaCursorPosition(wrap)
                                emitMoveIfDragging()
                                return true
                            }
                            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER -> {
                                val tx = captchaCursorX * wv.width
                                val ty = captchaCursorY * wv.height
                                val nowT = android.os.SystemClock.uptimeMillis()
                                if (event.repeatCount == 2) {
                                    isCaptchaDragMode = true
                                    captchaDragDownTime = nowT
                                    (captchaCursorView?.background as? GradientDrawable)?.setColor(Color.rgb(250, 204, 21))
                                    captchaTitleTv?.text = "SLIDE MODE (Left/Right then OK)"
                                    wv.dispatchTouchEvent(MotionEvent.obtain(captchaDragDownTime, nowT, MotionEvent.ACTION_DOWN, tx, ty, 0))
                                    return true
                                }
                                if (event.repeatCount == 0) {
                                    if (isCaptchaDragMode) {
                                        isCaptchaDragMode = false
                                        (captchaCursorView?.background as? GradientDrawable)?.setColor(Color.argb(210, 229, 9, 20))
                                        captchaTitleTv?.text = "Verify · Hold OK to Slide"
                                        wv.dispatchTouchEvent(MotionEvent.obtain(captchaDragDownTime, nowT, MotionEvent.ACTION_UP, tx, ty, 0))
                                    } else {
                                        wv.dispatchTouchEvent(MotionEvent.obtain(nowT, nowT, MotionEvent.ACTION_DOWN, tx, ty, 0))
                                        wv.dispatchTouchEvent(MotionEvent.obtain(nowT, nowT + 40, MotionEvent.ACTION_UP, tx, ty, 0))
                                    }
                                }
                                return true
                            }
                            KeyEvent.KEYCODE_BACK -> {
                                hideCaptchaCard()
                                return true
                            }
                        }
                    } else {
                        when (event.keyCode) {
                            KeyEvent.KEYCODE_DPAD_UP -> {
                                val focused = currentFocus
                                val inBottomRow = focused != null && (focused == seekBar || focused.parent == bottomActionsRow)
                                if (inBottomRow) {
                                    isCaptchaCursorActive = true
                                    captchaCursorView?.alpha = 1.0f
                                    captchaCursorY = 0.88f
                                    updateCaptchaCursorPosition(wrap)
                                    return true
                                }
                            }
                            KeyEvent.KEYCODE_DPAD_DOWN -> {
                                val focused = currentFocus
                                if (focused == captchaReloadBtn || focused == switchServerBtn) {
                                    isCaptchaCursorActive = true
                                    captchaCursorView?.alpha = 1.0f
                                    captchaCursorY = 0.12f
                                    updateCaptchaCursorPosition(wrap)
                                    return true
                                }
                            }
                            KeyEvent.KEYCODE_BACK -> {
                                hideCaptchaCard()
                                return true
                            }
                        }
                    }
                }
            }
            val player = exoPlayer
            when (event.keyCode) {
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> {
                    if (player != null) {
                        if (player.isPlaying) player.pause() else player.play()
                        showControllerTemporarily()
                        return true
                    }
                }
                KeyEvent.KEYCODE_DPAD_CENTER,
                KeyEvent.KEYCODE_ENTER -> {
                    if (!isControllerVisible && player != null) {
                        if (player.isPlaying) player.pause() else player.play()
                        showControllerTemporarily()
                        playPauseBtn?.requestFocus()
                        return true
                    }
                    showControllerTemporarily()
                }
                KeyEvent.KEYCODE_DPAD_LEFT,
                KeyEvent.KEYCODE_MEDIA_REWIND -> {
                    if (!isControllerVisible && player != null) {
                        player.seekTo((player.currentPosition - 10_000L).coerceAtLeast(0L))
                        showControllerTemporarily()
                        return true
                    }
                    if (seekBar?.hasFocus() == true && player != null) {
                        player.seekTo((player.currentPosition - 10_000L).coerceAtLeast(0L))
                        updateTimeAndSeekBar()
                        showControllerTemporarily()
                        return true
                    }
                    showControllerTemporarily()
                }
                KeyEvent.KEYCODE_DPAD_RIGHT,
                KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> {
                    if (!isControllerVisible && player != null) {
                        player.seekTo((player.currentPosition + 10_000L).coerceAtMost(player.duration.coerceAtLeast(0L)))
                        showControllerTemporarily()
                        return true
                    }
                    if (seekBar?.hasFocus() == true && player != null) {
                        player.seekTo((player.currentPosition + 10_000L).coerceAtMost(player.duration.coerceAtLeast(0L)))
                        updateTimeAndSeekBar()
                        showControllerTemporarily()
                        return true
                    }
                    showControllerTemporarily()
                }
                KeyEvent.KEYCODE_DPAD_UP,
                KeyEvent.KEYCODE_DPAD_DOWN -> {
                    if (!isControllerVisible) {
                        showControllerTemporarily()
                        playPauseBtn?.requestFocus()
                        return true
                    }
                    showControllerTemporarily()
                }
                KeyEvent.KEYCODE_BACK -> {
                    saveCurrentProgress()
                    finish()
                    return true
                }
            }
        }
        return super.dispatchKeyEvent(event)
    }

    private fun saveCurrentProgress(forceCompleted: Boolean = false) {
        try {
            val player = exoPlayer ?: return
            val key = progressKey ?: return
            val durMs = player.duration
            val posMs = player.currentPosition.coerceAtLeast(0L)
            if (durMs <= 0) return

            val posSec = posMs / 1000L
            val durSec = durMs / 1000L
            val rawPct = ((posMs * 100L) / durMs).toInt().coerceIn(0, 100)
            val pct = if (forceCompleted) 100 else if (posSec >= 10L && rawPct == 0) 1 else rawPct
            val isWatched = forceCompleted || pct >= 92 || (durSec - posSec <= 45L)

            StreambertApp.instance.database.playbackProgressDao().upsertSync(
                PlaybackProgressEntity(
                    progressKey = key,
                    percent = pct,
                    positionSec = posSec,
                    durationSec = durSec,
                    watched = isWatched
                )
            )
            ExoProgressBus.listener?.invoke(key, pct, posSec, durSec, isWatched)
        } catch (_: Throwable) {}
    }

    private fun enableImmersiveFullscreen() {
        try {
            WindowCompat.setDecorFitsSystemWindows(window, false)
            WindowInsetsControllerCompat(window, window.decorView).let { controller ->
                controller.hide(WindowInsetsCompat.Type.systemBars())
                controller.systemBarsBehavior =
                    WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } catch (_: Throwable) {}
    }

    override fun onPause() {
        super.onPause()
        if (isFinishing || Build.VERSION.SDK_INT < Build.VERSION_CODES.N || !isInPictureInPictureMode) {
            exoPlayer?.playWhenReady = false
            exoPlayer?.pause()
            try {
                resolverWebView?.evaluateJavascript("try{document.querySelectorAll('video,audio').forEach(function(v){v.pause();v.muted=true;});}catch(e){}", null)
            } catch (_: Throwable) {}
        }
    }

    override fun onStop() {
        super.onStop()
        saveCurrentProgress()
        if (isFinishing) {
            forceShutdownPlayer()
        } else if (Build.VERSION.SDK_INT < Build.VERSION_CODES.N || !isInPictureInPictureMode) {
            exoPlayer?.playWhenReady = false
            exoPlayer?.pause()
            try {
                resolverWebView?.evaluateJavascript("try{document.querySelectorAll('video,audio').forEach(function(v){v.pause();v.muted=true;});}catch(e){}", null)
            } catch (_: Throwable) {}
        }
    }

    override fun finish() {
        saveCurrentProgress()
        forceShutdownPlayer()
        super.finish()
    }

    fun forceShutdownPlayer() {
        isPlayerActive = false
        if (activeInstance === this) activeInstance = null
        stopBackgroundServerProbing()
        mainHandler.removeCallbacks(nextEpCountdownRunnable)
        mainHandler.removeCallbacks(failoverWatchdogRunnable)
        mainHandler.removeCallbacks(playbackReadyWatchdogRunnable)
        mainHandler.removeCallbacks(hideControllerRunnable)
        mainHandler.removeCallbacks(hideMetersRunnable)
        mainHandler.removeCallbacks(hideLeftSeekRunnable)
        mainHandler.removeCallbacks(hideRightSeekRunnable)
        mainHandler.removeCallbacks(progressRunnable)
        mainHandler.removeCallbacks(uiTickRunnable)
        mainHandler.removeCallbacks(subtitleTickRunnable)
        try {
            resolverWebView?.evaluateJavascript("try{document.querySelectorAll('video,audio').forEach(function(v){v.pause();v.muted=true;v.removeAttribute('src');v.load();});}catch(e){}", null)
            resolverWebView?.stopLoading()
            resolverWebView?.loadUrl("about:blank")
            resolverWebView?.onPause()
            resolverWebView?.destroy()
        } catch (_: Throwable) {}
        resolverWebView = null
        try {
            exoPlayer?.playWhenReady = false
            exoPlayer?.pause()
            exoPlayer?.stop()
            exoPlayer?.release()
        } catch (_: Throwable) {}
        exoPlayer = null
    }

    override fun onDestroy() {
        forceShutdownPlayer()
        super.onDestroy()
    }


    private val nextEpCountdownRunnable = object : Runnable {
        override fun run() {
            if (isFinishing || isDestroyed || nextEpDismissed || nextEpCard?.visibility != View.VISIBLE) return
            nextEpCountdownSec--
            if (nextEpCountdownSec <= 0) {
                playNextEpisodeInPlayer()
            } else {
                nextEpCountdownTv?.text = "Starting in ${nextEpCountdownSec}s..."
                mainHandler.postDelayed(this, 1000L)
            }
        }
    }

    private fun handleSkipSegmentClick() {
        val p = exoPlayer ?: return
        if (activeSkipTargetSec > 0) {
            p.seekTo((activeSkipTargetSec * 1000.0).toLong())
            skipSegmentBtn?.visibility = View.GONE
            activeSkipTargetSec = -1.0
        }
    }

    private fun dismissNextEpisodeCard() {
        nextEpDismissed = true
        mainHandler.removeCallbacks(nextEpCountdownRunnable)
        nextEpCard?.visibility = View.GONE
    }

    private fun playNextEpisodeInPlayer() {
        mainHandler.removeCallbacks(nextEpCountdownRunnable)
        nextEpCard?.visibility = View.GONE
        saveCurrentProgress(forceCompleted = true)
        stopBackgroundServerProbing()
        verifiedServers.clear()
        probedFailedServers.clear()
        availableSubs.clear()
        activeParsedCues.clear()
        activeSubIndex = -1
        subtitleOverlayView?.visibility = View.GONE
        episodeNum += 1
        val idKey = imdbId.ifEmpty { tmdbId }
        progressKey = "tv_${idKey}_s${seasonNum}e${episodeNum}"
        streamTitle = "$seriesTitleStr · S${seasonNum}E${episodeNum}"
        titleView?.text = streamTitle
        startTimeSec = 0L
        streamUrl = ""
        introStartSec = -1.0
        introEndSec = -1.0
        recapStartSec = -1.0
        recapEndSec = -1.0
        outroStartSec = -1.0
        nextEpDismissed = false
        updateSwitchServerButtonText()
        try {
            exoPlayer?.pause()
            exoPlayer?.stop()
            exoPlayer?.clearMediaItems()
            exoPlayer?.seekTo(0L)
        } catch (_: Throwable) {}
        startResolvingInitialSource()
        fetchOnlineSubtitlesInBackground()
        fetchSkipSegmentsInBackground()
        mainHandler.postDelayed({ startBackgroundServerProbing() }, 400L)
    }

    private fun autoDetectSegmentsFromStreamAndCues() {
        val cues = activeParsedCues.toList()
        if (cues.isEmpty()) return
        val durMs = exoPlayer?.duration ?: 0L
        val validDur = if (durMs > 60000L) durMs / 1000.0 else 0.0

        fun isMetaOrMusicCue(text: String): Boolean {
            val l = text.lowercase()
            if (l.contains("♪") || l.contains("♫") || l.contains("[music") || l.contains("(music") || l.contains("theme song")) return true
            if (l.contains("directed by") || l.contains("produced by") || l.contains("starring") || l.contains("written by") || l.contains("executive producer") || l.contains("created by") || l.contains("based on")) return true
            if (l.contains("synced by") || l.contains("translated by") || l.contains("subtitles by") || l.contains("opensubtitles") || l.contains("osdb.link")) return true
            return false
        }

        val spoken = cues.filter { !isMetaOrMusicCue(it.text) && it.text.trim().isNotEmpty() }
        val firstSpoken = spoken.firstOrNull() ?: return
        val firstStartSec = firstSpoken.startMs / 1000.0
        val openingLimit = if (validDur > 0.0) minOf(validDur * 0.45, 720.0) else 720.0

        data class GapCand(val st: Double, val en: Double, val score: Int)
        val gapCands = mutableListOf<GapCand>()

        val isTv = mediaType.equals("tv", ignoreCase = true)
        if (firstStartSec in 25.0..210.0) {
            val musicBefore = cues.filter { (it.endMs / 1000.0) <= firstStartSec + 1.0 && isMetaOrMusicCue(it.text) }
            if (isTv && firstStartSec >= 32.0 || musicBefore.isNotEmpty()) {
                val bonus = if (musicBefore.isEmpty()) 0 else 45
                val startAt = (musicBefore.firstOrNull()?.startMs ?: 2000L) / 1000.0
                gapCands.add(GapCand(maxOf(1.5, startAt), maxOf(startAt + 8.0, firstStartSec - 0.8), 55 + bonus))
            }
        }

        if (isTv) {
            for (i in 0 until (spoken.size - 1)) {
                val cur = spoken[i]
                val nxt = spoken[i + 1]
                val curEndSec = cur.endMs / 1000.0
                val nxtStartSec = nxt.startMs / 1000.0
                if (curEndSec > openingLimit) break
                val gap = nxtStartSec - curEndSec
                if (gap in 28.0..135.0) {
                    val musicInGap = cues.filter { (it.startMs / 1000.0) >= curEndSec - 1.0 && (it.endMs / 1000.0) <= nxtStartSec + 1.0 && isMetaOrMusicCue(it.text) }
                    var sc = 45
                    if (gap in 32.0..98.0) sc += 25
                    if (musicInGap.isNotEmpty()) sc += 50
                    gapCands.add(GapCand(curEndSec + 0.5, nxtStartSec - 0.8, sc))
                }
            }
        }

        if (introEndSec > introStartSec && introStartSec >= 0.0) {
            val extDur = introEndSec - introStartSec
            val conflictingSpoken = spoken.count { (it.startMs / 1000.0) >= introStartSec + 5.0 && (it.endMs / 1000.0) <= introEndSec - 5.0 }
            val bestSync = gapCands.minByOrNull { kotlin.math.abs(it.st - introStartSec) + kotlin.math.abs((it.en - it.st) - extDur) }
            if (bestSync != null && kotlin.math.abs(bestSync.st - introStartSec) <= 45.0 && kotlin.math.abs((bestSync.en - bestSync.st) - extDur) <= 25.0) {
                introStartSec = bestSync.st
                introEndSec = bestSync.en
            } else if (conflictingSpoken >= 2) {
                val bestAuto = gapCands.maxByOrNull { it.score }
                if (bestAuto != null) {
                    introStartSec = bestAuto.st
                    introEndSec = bestAuto.en
                } else {
                    introStartSec = -1.0
                    introEndSec = -1.0
                }
            }
        } else {
            val bestAuto = gapCands.maxByOrNull { it.score }
            if (bestAuto != null) {
                introStartSec = bestAuto.st
                introEndSec = bestAuto.en
            }
        }

        if (validDur > 180.0) {
            val lastSpoken = spoken.lastOrNull()
            if (lastSpoken != null) {
                val lastEndSec = lastSpoken.endMs / 1000.0
                val rem = validDur - lastEndSec
                if (outroStartSec > 0.0) {
                    val spokenAfterOutro = spoken.count { (it.startMs / 1000.0) >= outroStartSec + 6.0 }
                    if (spokenAfterOutro >= 3) {
                        outroStartSec = if (rem in 25.0..300.0 && lastEndSec >= validDur * 0.78) lastEndSec + 1.5 else -1.0
                    }
                } else if (rem in 25.0..300.0 && lastEndSec >= validDur * 0.78) {
                    outroStartSec = lastEndSec + 1.5
                }
            }
        }
    }

    private fun fetchSkipSegmentsInBackground(durationMs: Long = 0L) {
        if (durationMs == 0L) {
            introStartSec = -1.0
            introEndSec = -1.0
            recapStartSec = -1.0
            recapEndSec = -1.0
            outroStartSec = -1.0
        }
        val rawIm = imdbId.trim()
        val tm = tmdbId.trim()
        val isTv = mediaType.equals("tv", ignoreCase = true)
        val sNum = seasonNum
        val eNum = episodeNum
        val durSec = if (durationMs > 0L) durationMs / 1000.0 else ((exoPlayer?.duration ?: 0L) / 1000.0)

        thread(start = true) {
            var im = rawIm
            if (!im.startsWith("tt") && tm.isNotEmpty() && tm.all { it.isDigit() }) {
                try {
                    val prop = if (isTv) "P4983" else "P4947"
                    val sparql = "SELECT ?imdb WHERE { ?item wdt:$prop \"$tm\" . ?item wdt:P345 ?imdb . } LIMIT 1"
                    val wu = "https://query.wikidata.org/sparql?format=json&query=" + java.net.URLEncoder.encode(sparql, "UTF-8")
                    val wReq = Request.Builder().url(wu).header("Accept", "application/sparql-results+json").build()
                    StreambertApp.instance.okHttpClient.newCall(wReq).execute().use { res ->
                        if (res.isSuccessful) {
                            val bindings = JSONObject(res.body?.string() ?: "{}").optJSONObject("results")?.optJSONArray("bindings")
                            val valStr = bindings?.optJSONObject(0)?.optJSONObject("imdb")?.optString("value", "") ?: ""
                            if (valStr.startsWith("tt")) im = valStr
                        }
                    }
                } catch (_: Throwable) {}
            }

            val lock = Any()
            val introCands = mutableListOf<Triple<Double, Double, Int>>()
            val recapCands = mutableListOf<Triple<Double, Double, Int>>()
            val outroCands = mutableListOf<Pair<Double, Int>>()

            fun addIntro(st: Double, en: Double, w: Int) {
                if (st >= 0.0 && en > st + 5.0 && (en - st) <= 240.0 && (durSec <= 0.0 || st < maxOf(durSec * 0.45, 720.0))) {
                    synchronized(lock) { introCands.add(Triple(st, en, w)) }
                }
            }
            fun addRecap(st: Double, en: Double, w: Int) {
                if (st >= 0.0 && en > st + 5.0 && st < 150.0 && (durSec <= 0.0 || en < durSec * 0.25)) {
                    synchronized(lock) { recapCands.add(Triple(st, en, w)) }
                }
            }
            fun addOutro(st: Double, w: Int) {
                if (st <= 30.0 || durSec <= 180.0) return
                val rem = durSec - st
                if (rem < 12.0 || rem > 240.0 || st < durSec * 0.80) return
                synchronized(lock) { outroCands.add(Pair(st, w)) }
            }

            val latch = java.util.concurrent.CountDownLatch(7)

            thread(start = true) {
                try {
                    val qp = mutableListOf<String>()
                    if (im.startsWith("tt")) qp.add("imdb_id=$im")
                    else if (tm.isNotEmpty() && tm.all { it.isDigit() }) qp.add("tmdb_id=$tm")
                    if (isTv) { qp.add("season=$sNum"); qp.add("episode=$eNum") }
                    if (durationMs > 30_000L) qp.add("duration_ms=$durationMs")
                    if (qp.isNotEmpty()) {
                        val req = Request.Builder().url("https://api.theintrodb.org/v3/media?" + qp.joinToString("&")).header("User-Agent", "SingularityTV/1.0.0").build()
                        StreambertApp.instance.okHttpClient.newCall(req).execute().use { res ->
                            if (res.isSuccessful) {
                                val obj = JSONObject(res.body?.string() ?: "{}")
                                obj.optJSONArray("intro")?.optJSONObject(0)?.let { addIntro(it.optDouble("start_ms", 0.0) / 1000.0, it.optDouble("end_ms", -1.0) / 1000.0, 6) }
                                obj.optJSONArray("recap")?.optJSONObject(0)?.let { addRecap(it.optDouble("start_ms", 0.0) / 1000.0, it.optDouble("end_ms", -1.0) / 1000.0, 6) }
                                obj.optJSONArray("credits")?.optJSONObject(0)?.let { addOutro(it.optDouble("start_ms", -1.0) / 1000.0, 6) }
                            }
                        }
                    }
                } catch (_: Throwable) {} finally { latch.countDown() }
            }

            thread(start = true) {
                try {
                    if (im.startsWith("tt")) {
                        val epStr = if (isTv) "season=$sNum&episode=$eNum" else "is_movie=true"
                        val req2 = Request.Builder().url("https://api.introdb.app/segments?imdb_id=$im&$epStr").header("User-Agent", "SingularityTV/1.0.0").build()
                        StreambertApp.instance.okHttpClient.newCall(req2).execute().use { res ->
                            if (res.isSuccessful) {
                                val obj = JSONObject(res.body?.string() ?: "{}")
                                obj.optJSONObject("intro")?.let { seg ->
                                    addIntro(seg.optDouble("start_ms", seg.optDouble("start_sec", 0.0) * 1000.0) / 1000.0, seg.optDouble("end_ms", seg.optDouble("end_sec", 0.0) * 1000.0) / 1000.0, 5)
                                }
                                obj.optJSONObject("recap")?.let { seg ->
                                    addRecap(seg.optDouble("start_ms", seg.optDouble("start_sec", 0.0) * 1000.0) / 1000.0, seg.optDouble("end_ms", seg.optDouble("end_sec", 0.0) * 1000.0) / 1000.0, 5)
                                }
                                (obj.optJSONObject("outro") ?: obj.optJSONObject("credits"))?.let { seg ->
                                    addOutro(seg.optDouble("start_ms", seg.optDouble("start_sec", 0.0) * 1000.0) / 1000.0, 5)
                                }
                            }
                        }
                    }
                } catch (_: Throwable) {} finally { latch.countDown() }
            }

            thread(start = true) {
                try {
                    if (im.startsWith("tt") && isTv) {
                        val req2b = Request.Builder().url("https://api.introdb.app/intro?imdb_id=$im&season=$sNum&episode=$eNum").header("User-Agent", "SingularityTV/1.0.0").build()
                        StreambertApp.instance.okHttpClient.newCall(req2b).execute().use { res ->
                            if (res.isSuccessful) {
                                val obj = JSONObject(res.body?.string() ?: "{}")
                                addIntro(obj.optDouble("start_ms", obj.optDouble("start_sec", 0.0) * 1000.0) / 1000.0, obj.optDouble("end_ms", obj.optDouble("end_sec", 0.0) * 1000.0) / 1000.0, 4)
                            }
                        }
                    }
                } catch (_: Throwable) {} finally { latch.countDown() }
            }

            for (skipBase in listOf("https://api.skipdb.tv/v1/segments", "https://api.skipdb.tv/api/segments")) {
                thread(start = true) {
                    try {
                        if (im.startsWith("tt") || (tm.isNotEmpty() && tm.all { it.isDigit() })) {
                            val sp = mutableListOf<String>()
                            if (im.startsWith("tt")) sp.add("imdb_id=$im") else sp.add("tmdb_id=$tm")
                            if (isTv) { sp.add("season=$sNum"); sp.add("episode=$eNum") }
                            if (durationMs > 30_000L) sp.add("duration_ms=$durationMs")
                            val req3 = Request.Builder().url("$skipBase?" + sp.joinToString("&")).header("User-Agent", "SingularityTV/1.0.0").build()
                            StreambertApp.instance.okHttpClient.newCall(req3).execute().use { res ->
                                if (res.isSuccessful) {
                                    val obj = JSONObject(res.body?.string() ?: "{}")
                                    val arr = obj.optJSONArray("segments") ?: obj.optJSONArray("results") ?: obj.optJSONArray("data") ?: JSONArray()
                                    for (i in 0 until arr.length()) {
                                        val seg = arr.optJSONObject(i) ?: continue
                                        val tp = seg.optString("type", seg.optString("segment", "")).lowercase()
                                        val st = seg.optDouble("start_ms", seg.optDouble("start", 0.0) * 1000.0) / 1000.0
                                        val en = seg.optDouble("end_ms", seg.optDouble("end", 0.0) * 1000.0) / 1000.0
                                        if (tp.contains("intro") || tp == "op") addIntro(st, en, 4)
                                        else if (tp.contains("recap")) addRecap(st, en, 4)
                                        else if (tp.contains("credit") || tp.contains("outro") || tp == "ed") addOutro(st, 4)
                                    }
                                }
                            }
                        }
                    } catch (_: Throwable) {} finally { latch.countDown() }
                }
            }

            thread(start = true) {
                try {
                    if (im.startsWith("tt")) {
                        val ihUrl = if (isTv) "https://api.introhater.com/skip-times?imdb_id=$im&season=$sNum&episode=$eNum" else "https://api.introhater.com/skip-times?imdb_id=$im"
                        val req4 = Request.Builder().url(ihUrl).header("User-Agent", "SingularityTV/1.0.0").build()
                        StreambertApp.instance.okHttpClient.newCall(req4).execute().use { res ->
                            if (res.isSuccessful) {
                                val obj = JSONObject(res.body?.string() ?: "{}")
                                val arr = obj.optJSONArray("results") ?: obj.optJSONArray("segments") ?: JSONArray()
                                for (i in 0 until arr.length()) {
                                    val seg = arr.optJSONObject(i) ?: continue
                                    val tp = seg.optString("skipType", seg.optString("type", "")).lowercase()
                                    val iv = seg.optJSONObject("interval") ?: continue
                                    val st = iv.optDouble("startTime", -1.0)
                                    val en = iv.optDouble("endTime", -1.0)
                                    if (tp == "op" || tp.contains("intro")) addIntro(st, en, 3)
                                    else if (tp == "recap") addRecap(st, en, 3)
                                    else if (tp == "ed" || tp.contains("outro") || tp.contains("credit")) addOutro(st, 3)
                                }
                            }
                        }
                    }
                } catch (_: Throwable) {} finally { latch.countDown() }
            }

            thread(start = true) {
                try {
                    if (im.startsWith("tt")) {
                        val armReq = Request.Builder().url("https://arm.haglund.dev/api/v2/ids?source=imdb&id=$im").build()
                        StreambertApp.instance.okHttpClient.newCall(armReq).execute().use { res ->
                            if (res.isSuccessful) {
                                val malId = JSONObject(res.body?.string() ?: "{}").optInt("myanimelist", 0)
                                if (malId > 0) {
                                    val epLen = if (durSec > 60.0) durSec.toInt() else 0
                                    val aniReq = Request.Builder().url("https://api.aniskip.com/v2/skip-times/$malId/${if (isTv) eNum else 1}?types[]=op&types[]=ed&types[]=recap&episodeLength=$epLen").build()
                                    StreambertApp.instance.okHttpClient.newCall(aniReq).execute().use { r2 ->
                                        if (r2.isSuccessful) {
                                            val arr = JSONObject(r2.body?.string() ?: "{}").optJSONArray("results") ?: JSONArray()
                                            for (i in 0 until arr.length()) {
                                                val seg = arr.optJSONObject(i) ?: continue
                                                val tp = seg.optString("skipType", "").lowercase()
                                                val iv = seg.optJSONObject("interval") ?: continue
                                                val st = iv.optDouble("startTime", -1.0)
                                                val en = iv.optDouble("endTime", -1.0)
                                                if (tp == "op") addIntro(st, en, 4)
                                                else if (tp == "recap") addRecap(st, en, 4)
                                                else if (tp == "ed") addOutro(st, 4)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                } catch (_: Throwable) {} finally { latch.countDown() }
            }

            try { latch.await(7000L, java.util.concurrent.TimeUnit.MILLISECONDS) } catch (_: Throwable) {}

            fun pickBestSpan(cands: List<Triple<Double, Double, Int>>): Pair<Double, Double>? {
                if (cands.isEmpty()) return null
                var bestScore = -1
                var bestCenter = cands[0]
                for (c in cands) {
                    var score = 0
                    for (o in cands) {
                        if (kotlin.math.abs(c.first - o.first) <= 3.5 && kotlin.math.abs(c.second - o.second) <= 3.5) {
                            score += o.third
                        }
                    }
                    if (score > bestScore) {
                        bestScore = score
                        bestCenter = c
                    }
                }
                var sumSt = 0.0
                var sumEn = 0.0
                var totalW = 0.0
                var count = 0
                var maxW = 0
                for (o in cands) {
                    if (kotlin.math.abs(bestCenter.first - o.first) <= 3.5 && kotlin.math.abs(bestCenter.second - o.second) <= 3.5) {
                        val w = o.third.toDouble()
                        sumSt += o.first * w
                        sumEn += o.second * w
                        totalW += w
                        count++
                        if (o.third > maxW) maxW = o.third
                    }
                }
                if (count < 2 && maxW < 6) return null
                return if (totalW > 0.0) Pair(sumSt / totalW, sumEn / totalW) else Pair(bestCenter.first, bestCenter.second)
            }

            fun pickBestOutro(cands: List<Pair<Double, Int>>): Double? {
                if (cands.isEmpty()) return null
                var bestScore = -1
                var bestCenter = cands[0]
                for (c in cands) {
                    var score = 0
                    for (o in cands) {
                        if (kotlin.math.abs(c.first - o.first) <= 4.0) score += o.second
                    }
                    if (score > bestScore) {
                        bestScore = score
                        bestCenter = c
                    }
                }
                var sumSt = 0.0
                var totalW = 0.0
                for (o in cands) {
                    if (kotlin.math.abs(bestCenter.first - o.first) <= 4.0) {
                        val w = o.second.toDouble()
                        sumSt += o.first * w
                        totalW += w
                    }
                }
                return if (totalW > 0.0) sumSt / totalW else bestCenter.first
            }

            val bestIntro = synchronized(lock) { pickBestSpan(introCands) }
            val bestRecap = synchronized(lock) { pickBestSpan(recapCands) }
            val bestOutro = synchronized(lock) { pickBestOutro(outroCands) }

            mainHandler.post {
                if (isFinishing || isDestroyed) return@post
                bestIntro?.let { introStartSec = it.first; introEndSec = it.second }
                bestRecap?.let { recapStartSec = it.first; recapEndSec = it.second }
                bestOutro?.let { outroStartSec = it }
                autoDetectSegmentsFromStreamAndCues()
            }
        }
    }

    private fun updateSkipAndNextEpisodeUi() {
        val p = exoPlayer ?: return
        val cur = p.currentPosition / 1000.0
        val dur = p.duration / 1000.0
        if (cur < 0) return

        skipSegmentBtn?.visibility = View.GONE
        activeSkipTargetSec = -1.0

        val card = nextEpCard ?: return
        if (mediaType.equals("tv", ignoreCase = true) && !nextEpDismissed && dur > 180.0) {
            val hasMore = totalEpisodesInSeason <= 0 || episodeNum < totalEpisodesInSeason
            if (hasMore) {
                val validOutro = outroStartSec > 60.0 && (dur - outroStartSec) in 12.0..240.0 && outroStartSec >= dur * 0.80
                val triggerSec = if (validOutro) outroStartSec else maxOf(dur * 0.94, dur - 45.0)
                if (cur >= triggerSec && cur < dur) {
                    if (card.visibility != View.VISIBLE) {
                        nextEpTitleTv?.text = "$seriesTitleStr · S${seasonNum}E${episodeNum + 1}"
                        nextEpCountdownSec = 10
                        nextEpCountdownTv?.text = "Starting in 10s..."
                        card.visibility = View.VISIBLE
                        card.bringToFront()
                        mainHandler.removeCallbacks(nextEpCountdownRunnable)
                        mainHandler.postDelayed(nextEpCountdownRunnable, 1000L)
                    }
                } else if (card.visibility == View.VISIBLE) {
                    mainHandler.removeCallbacks(nextEpCountdownRunnable)
                    card.visibility = View.GONE
                }
            }
        }
    }

    companion object {
        const val EXTRA_PAYLOAD_JSON = "extra_payload_json"
        @Volatile var isPlayerActive: Boolean = false
        @Volatile var activeInstance: NativeExoPlayerActivity? = null
        var onNeedNextServer: ((String, Long, (String?, String?) -> Unit) -> Unit)? = null

        fun forceCloseIfOpen() {
            val inst = activeInstance
            if (inst != null) {
                try {
                    inst.runOnUiThread {
                        inst.forceShutdownPlayer()
                        if (!inst.isFinishing && !inst.isDestroyed) {
                            inst.finish()
                        }
                    }
                } catch (_: Throwable) {}
            }
            isPlayerActive = false
            activeInstance = null
        }
    }
}

object ExoProgressBus {
    var listener: ((String, Int, Long, Long, Boolean) -> Unit)? = null
    var serverSwitchListener: ((String) -> Unit)? = null
    var preferredSourceListener: ((String) -> Unit)? = null
}
