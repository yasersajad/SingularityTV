package com.singularity.tv

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.singularity.tv.data.StreambertDatabase
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

class StreambertApp : Application() {

    val database: StreambertDatabase by lazy {
        StreambertDatabase.getInstance(this)
    }

    val okHttpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    override fun onCreate() {
        super.onCreate()
        instance = this
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java) ?: return
            val dlChannel = NotificationChannel(
                CHANNEL_DOWNLOADS,
                getString(R.string.download_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.download_channel_desc)
            }
            val epChannel = NotificationChannel(
                CHANNEL_EPISODES,
                getString(R.string.episode_channel_name),
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = getString(R.string.episode_channel_desc)
            }
            nm.createNotificationChannel(dlChannel)
            nm.createNotificationChannel(epChannel)
        }
    }

    companion object {
        const val CHANNEL_DOWNLOADS = "streambert_downloads"
        const val CHANNEL_EPISODES = "streambert_episodes"

        @Volatile
        lateinit var instance: StreambertApp
            private set
    }
}
