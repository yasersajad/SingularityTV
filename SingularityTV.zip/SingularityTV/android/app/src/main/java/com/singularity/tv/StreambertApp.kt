package com.singularity.tv

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.res.Configuration
import android.os.Build
import java.util.Locale
import com.singularity.tv.data.StreambertDatabase
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

class StreambertApp : Application() {

    val database: StreambertDatabase by lazy {
        StreambertDatabase.getInstance(this)
    }

    val okHttpClient: OkHttpClient by lazy {
        val webCookieJar = object : okhttp3.CookieJar {
            override fun saveFromResponse(url: okhttp3.HttpUrl, cookies: List<okhttp3.Cookie>) {
                try {
                    val cm = android.webkit.CookieManager.getInstance()
                    val urlStr = url.toString()
                    for (c in cookies) {
                        cm.setCookie(urlStr, c.toString())
                    }
                } catch (_: Throwable) {}
            }

            override fun loadForRequest(url: okhttp3.HttpUrl): List<okhttp3.Cookie> {
                val out = mutableListOf<okhttp3.Cookie>()
                try {
                    val raw = android.webkit.CookieManager.getInstance().getCookie(url.toString()) ?: return out
                    for (part in raw.split(";")) {
                        val trimmed = part.trim()
                        if (trimmed.isEmpty()) continue
                        okhttp3.Cookie.parse(url, trimmed)?.let { out.add(it) }
                    }
                } catch (_: Throwable) {}
                return out
            }
        }
        OkHttpClient.Builder()
            .cookieJar(webCookieJar)
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .build()
    }

    override fun attachBaseContext(base: Context) {
        Locale.setDefault(Locale.US)
        val cfg = Configuration(base.resources.configuration)
        cfg.setLocale(Locale.US)
        cfg.setLayoutDirection(Locale.US)
        super.attachBaseContext(base.createConfigurationContext(cfg))
    }

    override fun onCreate() {
        Locale.setDefault(Locale.US)
        super.onCreate()
        instance = this
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java) ?: return
            val dlChannel = NotificationChannel(
                CHANNEL_DOWNLOADS,
                getString(R.string.download_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.download_channel_desc)
            }
            val epChannel = NotificationChannel(
                CHANNEL_EPISODES,
                getString(R.string.episode_channel_name),
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = getString(R.string.episode_channel_desc)
            }
            nm.createNotificationChannel(dlChannel)
            nm.createNotificationChannel(epChannel)
        }
    }

    companion object {
        const val CHANNEL_DOWNLOADS = "streambert_downloads"
        const val CHANNEL_EPISODES = "streambert_episodes"

        @Volatile
        lateinit var instance: StreambertApp
            private set
    }
}
