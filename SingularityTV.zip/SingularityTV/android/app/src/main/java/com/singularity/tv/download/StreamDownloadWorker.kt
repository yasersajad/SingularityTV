package com.singularity.tv.download

import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import com.singularity.tv.StreambertApp
import com.singularity.tv.data.DownloadEntity
import com.singularity.tv.subtitle.SubtitleManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.URI

class StreamDownloadWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        val downloadId = inputData.getString(KEY_DOWNLOAD_ID) ?: return@withContext Result.failure()
        val dao = StreambertApp.instance.database.downloadDao()
        val entry = dao.getByIdSync(downloadId) ?: return@withContext Result.failure()

        setForegroundSafe(downloadId, entry.name, 0)

        try {
            val outDir = File(entry.downloadPath).apply { mkdirs() }
            val safeName = entry.name.replace(Regex("[<>:\\\"/\\\\\\\\|?*]"), "").trim().ifEmpty { "video_$downloadId" }
            val isHls = entry.m3u8Url.lowercase().contains(".m3u8")
            val ext = if (isHls) ".ts" else ".mp4"
            val destFile = File(outDir, "$safeName$ext")

            val success = if (isHls) {
                downloadHlsStream(entry, destFile)
            } else {
                downloadProgressiveStream(entry, destFile)
            }

            if (isStopped) {
                return@withContext Result.retry()
            }

            if (!success) {
                updateEntry(downloadId) {
                    it.copy(
                        status = "error",
                        completedAt = System.currentTimeMillis(),
                        lastMessage = "Download failed — tap Retry"
                    )
                }
                return@withContext Result.failure()
            }

            val savedSubs = JSONArray()
            try {
                val subsArr = JSONArray(entry.subtitlesJson)
                for (i in 0 until subsArr.length()) {
                    val subObj = subsArr.optJSONObject(i) ?: continue
                    val subUrl = subObj.optString("url")
                    val lang = subObj.optString("lang", "en").replace(Regex("[^a-zA-Z0-9_-]"), "")
                    if (subUrl.isNotEmpty()) {
                        val subFile = File(outDir, "$safeName.$lang.srt")
                        if (SubtitleManager.downloadSubtitleToFile(subUrl, subFile)) {
                            savedSubs.put(JSONObject().apply {
                                put("lang", lang)
                                put("path", subFile.absolutePath)
                                put("file_id", subObj.optString("file_id"))
                            })
                        }
                    }
                }
            } catch (_: Exception) {}

            val fileSizeStr = formatFileSize(destFile.length())
            updateEntry(downloadId) {
                it.copy(
                    status = "completed",
                    progress = 100,
                    filePath = destFile.absolutePath,
                    size = fileSizeStr,
                    speed = "",
                    eta = "",
                    completedAt = System.currentTimeMillis(),
                    lastMessage = "Completed ($fileSizeStr)",
                    subtitlePathsJson = savedSubs.toString()
                )
            }
            Result.success()
        } catch (e: Exception) {
            updateEntry(downloadId) {
                it.copy(
                    status = if (isStopped) "paused" else "error",
                    lastMessage = e.message ?: "Download interrupted"
                )
            }
            Result.failure()
        }
    }

    private suspend fun downloadHlsStream(entry: DownloadEntity, destFile: File): Boolean {
        val playlistText = fetchText(entry.m3u8Url, entry) ?: return false
        val mediaPlaylistUrl = resolveVariantUrl(entry.m3u8Url, playlistText)
        val mediaText = if (mediaPlaylistUrl == entry.m3u8Url) playlistText else (fetchText(mediaPlaylistUrl, entry) ?: return false)

        val segments = mediaText.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("#") }
            .map { resolveRelativeUrl(mediaPlaylistUrl, it) }
            .toList()

        if (segments.isEmpty()) return false
        val total = segments.size
        var downloadedBytes = 0L
        val startTime = System.currentTimeMillis()

        FileOutputStream(destFile, false).use { fos ->
            for ((index, segUrl) in segments.withIndex()) {
                if (isStopped) return false
                val req = buildRequest(segUrl, entry)
                StreambertApp.instance.okHttpClient.newCall(req).execute().use { res ->
                    if (!res.isSuccessful) return false
                    val bytes = res.body?.bytes() ?: return false
                    fos.write(bytes)
                    downloadedBytes += bytes.size
                }
                val currentFrag = index + 1
                val pct = ((currentFrag.toDouble() / total.toDouble()) * 100.0).toInt().coerceIn(0, 99)
                val elapsedSec = ((System.currentTimeMillis() - startTime) / 1000.0).coerceAtLeast(0.5)
                val bytesPerSec = (downloadedBytes / elapsedSec).toLong()
                val remainingFrags = total - currentFrag
                val secPerFrag = elapsedSec / currentFrag
                val etaSec = (remainingFrags * secPerFrag).toLong()

                if (currentFrag == 1 || currentFrag % 3 == 0 || currentFrag == total) {
                    setForegroundSafe(entry.id, entry.name, pct)
                    updateEntry(entry.id) {
                        it.copy(
                            progress = pct,
                            totalFragments = total,
                            completedFragments = currentFrag,
                            size = formatFileSize(downloadedBytes),
                            speed = "${formatFileSize(bytesPerSec)}/s",
                            eta = formatEta(etaSec),
                            lastMessage = "Fragment $currentFrag / $total"
                        )
                    }
                }
            }
        }
        return true
    }

    private suspend fun downloadProgressiveStream(entry: DownloadEntity, destFile: File): Boolean {
        val existingBytes = if (destFile.exists()) destFile.length() else 0L
        val reqBuilder = buildRequest(entry.m3u8Url, entry).newBuilder()
        if (existingBytes > 0) {
            reqBuilder.header("Range", "bytes=$existingBytes-")
        }
        StreambertApp.instance.okHttpClient.newCall(reqBuilder.build()).execute().use { res ->
            if (!res.isSuccessful && res.code != 206) return false
            val body = res.body ?: return false
            val totalBytes = (body.contentLength().takeIf { it > 0 } ?: 0L) + existingBytes
            var written = existingBytes
            val startTime = System.currentTimeMillis()

            FileOutputStream(destFile, res.code == 206).use { fos ->
                val buf = ByteArray(32 * 1024)
                val stream = body.byteStream()
                var read: Int
                var lastReport = 0L
                while (stream.read(buf).also { read = it } != -1) {
                    if (isStopped) return false
                    fos.write(buf, 0, read)
                    written += read
                    val now = System.currentTimeMillis()
                    if (now - lastReport >= 500) {
                        lastReport = now
                        val pct = if (totalBytes > 0) ((written * 100) / totalBytes).toInt().coerceIn(0, 99) else 50
                        val elapsedSec = ((now - startTime) / 1000.0).coerceAtLeast(0.5)
                        val speedBps = ((written - existingBytes) / elapsedSec).toLong()
                        val etaSec = if (speedBps > 0 && totalBytes > written) (totalBytes - written) / speedBps else 0L
                        setForegroundSafe(entry.id, entry.name, pct)
                        updateEntry(entry.id) {
                            it.copy(
                                progress = pct,
                                size = formatFileSize(written),
                                speed = "${formatFileSize(speedBps)}/s",
                                eta = formatEta(etaSec),
                                lastMessage = "Downloading… $pct%"
                            )
                        }
                    }
                }
            }
        }
        return true
    }

    private fun fetchText(url: String, entry: DownloadEntity): String? {
        return try {
            StreambertApp.instance.okHttpClient.newCall(buildRequest(url, entry)).execute().use { res ->
                if (res.isSuccessful) res.body?.string() else null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun buildRequest(url: String, entry: DownloadEntity): Request {
        val b = Request.Builder()
            .url(url)
            .header(
                "User-Agent",
                entry.userAgentHeader ?: "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124.0.0.0 Safari/537.36"
            )
        if (!entry.refererHeader.isNullOrBlank()) {
            b.header("Referer", entry.refererHeader)
        }
        return b.build()
    }

    private fun resolveVariantUrl(masterUrl: String, text: String): String {
        val lines = text.lines().map { it.trim() }
        var bestBandwidth = -1L
        var bestUri: String? = null
        for (i in lines.indices) {
            val line = lines[i]
            if (line.startsWith("#EXT-X-STREAM-INF", ignoreCase = true)) {
                val bw = Regex("""BANDWIDTH=(\d+)""").find(line)?.groupValues?.getOrNull(1)?.toLongOrNull() ?: 0L
                val nextUri = lines.drop(i + 1).firstOrNull { it.isNotEmpty() && !it.startsWith("#") }
                if (nextUri != null && bw >= bestBandwidth) {
                    bestBandwidth = bw
                    bestUri = resolveRelativeUrl(masterUrl, nextUri)
                }
            }
        }
        return bestUri ?: masterUrl
    }

    private fun resolveRelativeUrl(baseUrl: String, relative: String): String {
        return try {
            if (relative.startsWith("http://") || relative.startsWith("https://")) relative
            else URI(baseUrl).resolve(relative).toString()
        } catch (_: Exception) {
            relative
        }
    }

    private fun updateEntry(id: String, transform: (DownloadEntity) -> DownloadEntity) {
        val dao = StreambertApp.instance.database.downloadDao()
        val current = dao.getByIdSync(id) ?: return
        val updated = transform(current)
        dao.upsertSync(updated)
        DownloadEventBus.emitProgress(updated)
    }

    private suspend fun setForegroundSafe(id: String, title: String, progress: Int) {
        try {
            val notification = NotificationCompat.Builder(applicationContext, StreambertApp.CHANNEL_DOWNLOADS)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle(title)
                .setContentText("Downloading… $progress%")
                .setProgress(100, progress, false)
                .setOngoing(true)
                .build()
            val fgInfo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ForegroundInfo(id.hashCode(), notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            } else {
                ForegroundInfo(id.hashCode(), notification)
            }
            setForeground(fgInfo)
        } catch (_: Exception) {}
    }

    private fun formatFileSize(bytes: Long): String {
        return when {
            bytes >= 1_073_741_824L -> String.format("%.2f GB", bytes / 1_073_741_824.0)
            bytes >= 1_048_576L -> String.format("%.1f MB", bytes / 1_048_576.0)
            bytes >= 1024L -> String.format("%.1f KB", bytes / 1024.0)
            else -> "$bytes B"
        }
    }

    private fun formatEta(seconds: Long): String {
        if (seconds <= 0) return ""
        val m = seconds / 60
        val s = seconds % 60
        return if (m > 0) "${m}m ${s}s left" else "${s}s left"
    }

    companion object {
        const val KEY_DOWNLOAD_ID = "download_id"
    }
}

object DownloadEventBus {
    var listener: ((DownloadEntity) -> Unit)? = null
    fun emitProgress(entity: DownloadEntity) {
        listener?.invoke(entity)
    }
}
