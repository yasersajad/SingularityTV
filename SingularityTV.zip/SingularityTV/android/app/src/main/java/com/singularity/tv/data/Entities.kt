package com.singularity.tv.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "preferences")
data class PreferenceEntity(
    @PrimaryKey val key: String,
    val valueJson: String,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "watchlist")
data class WatchlistEntity(
    @PrimaryKey val compositeId: String,
    val mediaId: String,
    val mediaType: String,
    val title: String,
    val posterPath: String?,
    val voteAverage: Double?,
    val year: String?,
    val sortOrder: Int = 0,
    val savedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "watch_history")
data class WatchHistoryEntity(
    @PrimaryKey val historyKey: String,
    val mediaId: String,
    val mediaType: String,
    val title: String,
    val posterPath: String?,
    val season: Int?,
    val episode: Int?,
    val episodeName: String?,
    val watchedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "playback_progress")
data class PlaybackProgressEntity(
    @PrimaryKey val progressKey: String,
    val percent: Int,
    val positionSec: Long,
    val durationSec: Long,
    val watched: Boolean,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey val id: String,
    val name: String,
    val m3u8Url: String,
    val downloadPath: String,
    val filePath: String?,
    val status: String,
    val progress: Int,
    val speed: String,
    val eta: String,
    val size: String,
    val totalFragments: Int,
    val completedFragments: Int,
    val lastMessage: String,
    val startedAt: Long,
    val completedAt: Long?,
    val mediaId: String?,
    val mediaType: String?,
    val season: Int?,
    val episode: Int?,
    val posterPath: String?,
    val subtitlesJson: String,
    val subtitlePathsJson: String,
    val refererHeader: String? = null,
    val userAgentHeader: String? = null
)

@Entity(tableName = "blocked_domains")
data class BlockedDomainEntity(
    @PrimaryKey val domain: String,
    val count: Long
)
