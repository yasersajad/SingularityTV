package com.singularity.tv

class TvMainActivity : MainActivity() {
    override val forceTvMode: Boolean = true
}
