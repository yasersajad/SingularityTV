package com.singularity.tv.subtitle

import android.net.Uri
import com.singularity.tv.StreambertApp
import okhttp3.Request
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.zip.ZipInputStream

object SubtitleManager {

    private const val ZIP_MAX_OUTPUT_BYTES = 10 * 1024 * 1024
    private val ALLOWED_EXTS = setOf("srt", "vtt", "ass", "ssa")

    fun extractSubtitleLang(url: String): String {
        try {
            val uri = Uri.parse(url)
            for (param in listOf("lang", "language", "locale", "sub", "l")) {
                val v = uri.getQueryParameter(param)
                if (!v.isNullOrBlank() && v.length in 2..20) {
                    return v.lowercase()
                }
            }
            val filename = uri.lastPathSegment ?: ""
            val m = Regex("[._-]([a-z]{2,3})[._-]?(vtt|srt|ass)?$", RegexOption.IGNORE_CASE).find(filename)
            if (m != null) return m.groupValues[1].lowercase()
        } catch (_: Exception) {}
        return "unknown"
    }

    fun extractFirstSubtitleFromZip(zipBytes: ByteArray): Pair<String, ByteArray>? {
        ZipInputStream(ByteArrayInputStream(zipBytes)).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                if (!entry.isDirectory) {
                    val baseName = File(entry.name).name
                    val ext = baseName.substringAfterLast('.', "").lowercase()
                    if (ext in ALLOWED_EXTS) {
                        val bos = ByteArrayOutputStream()
                        val buf = ByteArray(8192)
                        var total = 0
                        var read: Int
                        while (zis.read(buf).also { read = it } != -1) {
                            total += read
                            if (total > ZIP_MAX_OUTPUT_BYTES) break
                            bos.write(buf, 0, read)
                        }
                        if (total in 1..ZIP_MAX_OUTPUT_BYTES) {
                            return baseName to bos.toByteArray()
                        }
                    }
                }
                entry = zis.nextEntry
            }
        }
        return null
    }

    fun downloadSubtitleToFile(url: String, destFile: File): Boolean {
        return try {
            val req = Request.Builder()
                .url(url)
                .header("User-Agent", "SingularityTV-Android/2.7.0")
                .build()
            StreambertApp.instance.okHttpClient.newCall(req).execute().use { res ->
                if (!res.isSuccessful) return false
                val bytes = res.body?.bytes() ?: return false
                destFile.parentFile?.mkdirs()
                if (url.lowercase().contains(".zip") || (bytes.size > 4 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4B.toByte())) {
                    val extracted = extractFirstSubtitleFromZip(bytes) ?: return false
                    destFile.writeBytes(extracted.second)
                } else {
                    destFile.writeBytes(bytes)
                }
                true
            }
        } catch (_: Exception) {
            false
        }
    }
}
