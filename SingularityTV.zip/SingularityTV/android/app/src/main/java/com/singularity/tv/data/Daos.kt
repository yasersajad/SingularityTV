package com.singularity.tv.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface PreferenceDao {
    @Query("SELECT * FROM preferences")
    fun getAllSync(): List<PreferenceEntity>

    @Query("SELECT valueJson FROM preferences WHERE `key` = :key LIMIT 1")
    fun getValueSync(key: String): String?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun upsertSync(entity: PreferenceEntity)

    @Query("DELETE FROM preferences WHERE `key` = :key")
    fun deleteSync(key: String)

    @Query("DELETE FROM preferences")
    fun clearAllSync()
}

@Dao
interface DownloadDao {
    @Query("SELECT * FROM downloads ORDER BY COALESCE(completedAt, startedAt) DESC")
    fun getAllSync(): List<DownloadEntity>

    @Query("SELECT * FROM downloads WHERE id = :id LIMIT 1")
    fun getByIdSync(id: String): DownloadEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun upsertSync(entity: DownloadEntity)

    @Query("DELETE FROM downloads WHERE id = :id")
    fun deleteByIdSync(id: String)

    @Query("DELETE FROM downloads")
    fun deleteAllSync()
}

@Dao
interface PlaybackProgressDao {
    @Query("SELECT * FROM playback_progress WHERE progressKey = :key LIMIT 1")
    fun getByKeySync(key: String): PlaybackProgressEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun upsertSync(entity: PlaybackProgressEntity)

    @Query("DELETE FROM playback_progress")
    fun clearAllSync()
}

@Dao
interface BlockedDomainDao {
    @Query("SELECT * FROM blocked_domains")
    fun getAllSync(): List<BlockedDomainEntity>

    @Query("SELECT COALESCE(SUM(count), 0) FROM blocked_domains")
    fun getTotalBlockedSync(): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun upsertSync(entity: BlockedDomainEntity)
}
