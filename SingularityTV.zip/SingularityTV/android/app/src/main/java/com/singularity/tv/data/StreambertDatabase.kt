package com.singularity.tv.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        PreferenceEntity::class,
        WatchlistEntity::class,
        WatchHistoryEntity::class,
        PlaybackProgressEntity::class,
        DownloadEntity::class,
        BlockedDomainEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class StreambertDatabase : RoomDatabase() {
    abstract fun preferenceDao(): PreferenceDao
    abstract fun downloadDao(): DownloadDao
    abstract fun playbackProgressDao(): PlaybackProgressDao
    abstract fun blockedDomainDao(): BlockedDomainDao

    companion object {
        @Volatile
        private var INSTANCE: StreambertDatabase? = null

        fun getInstance(context: Context): StreambertDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    StreambertDatabase::class.java,
                    "streambert_room.db"
                )
                    .allowMainThreadQueries()
                    .fallbackToDestructiveMigration()
                    .build()
                    .also { INSTANCE = it }
            }
        }
    }
}
