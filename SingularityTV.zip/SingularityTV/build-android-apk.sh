#!/usr/bin/env bash
# ==============================================================================
# Streambert Android v2.7.0 — Universal APK Build Script
# Supports Linux, macOS, Windows (Git Bash / WSL), and AndroidIDE / Termux
# ==============================================================================
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ANDROID_DIR="$ROOT_DIR/android"
OUT_DIR="$ROOT_DIR/output"

echo "========================================================"
echo " Streambert Android v2.7.0 — Complete Build Pipeline"
echo "========================================================"

# 1. Compile Web UI Assets into android/app/src/main/assets/public/
if command -v node >/dev/null 2>&1; then
  if [ -d "$ROOT_DIR/node_modules" ] && [ -f "$ROOT_DIR/node_modules/.bin/vite" ]; then
    echo "[1/3] Building React bundle via Vite..."
    (cd "$ROOT_DIR" && npm run build)
    mkdir -p "$ANDROID_DIR/app/src/main/assets/public"
    cp -r "$ROOT_DIR/dist/"* "$ANDROID_DIR/app/src/main/assets/public/"
  elif [ -f "$ROOT_DIR/scripts/build-android-assets.js" ] && [ -d "/usr/share/nodejs/@babel/core" ]; then
    echo "[1/3] Building React bundle via scripts/build-android-assets.js..."
    node "$ROOT_DIR/scripts/build-android-assets.js"
  else
    echo "[1/3] Using pre-compiled assets in android/app/src/main/assets/public/..."
  fi
fi

# 2. Detect JDK 17+
if [ -z "${JAVA_HOME:-}" ]; then
  for candidate in \
    "/usr/lib/jvm/java-17-openjdk-amd64" \
    "/usr/lib/jvm/java-17-openjdk-arm64" \
    "/usr/lib/jvm/default-java" \
    "$HOME/android-sdk/jdk-17" \
    "/data/data/com.itsaky.androidide/files/usr/opt/openjdk"; do
    if [ -d "$candidate" ]; then
      export JAVA_HOME="$candidate"
      export PATH="$JAVA_HOME/bin:$PATH"
      break
    fi
  done
fi

# 3. Detect Android SDK
if [ -z "${ANDROID_HOME:-}" ] && [ -z "${ANDROID_SDK_ROOT:-}" ]; then
  for sdk_cand in \
    "$HOME/Android/Sdk" \
    "$HOME/android-sdk" \
    "/opt/android-sdk" \
    "/usr/lib/android-sdk" \
    "$HOME/Library/Android/sdk" \
    "/data/data/com.itsaky.androidide/files/home/android-sdk"; do
    if [ -d "$sdk_cand" ]; then
      export ANDROID_HOME="$sdk_cand"
      export ANDROID_SDK_ROOT="$sdk_cand"
      break
    fi
  done
fi

if [ -z "${ANDROID_HOME:-}" ] && [ -z "${ANDROID_SDK_ROOT:-}" ]; then
  echo "[!] ERROR: Android SDK (ANDROID_HOME / ANDROID_SDK_ROOT) was not found on this machine."
  echo "    Set ANDROID_HOME=/path/to/android-sdk or open the 'android/' directory in Android Studio."
  exit 1
fi

echo "sdk.dir=${ANDROID_HOME:-$ANDROID_SDK_ROOT}" > "$ANDROID_DIR/local.properties"

# Detect native AAPT2 override on ARM64 / Termux / AndroidIDE
GRADLE_EXTRA_ARGS=()
if [ "$(uname -m)" = "aarch64" ]; then
  for aapt2_bin in \
    "/data/data/com.itsaky.androidide/files/home/android-sdk/build-tools/"*/aapt2 \
    "$(command -v aapt2 2>/dev/null || true)"; do
    if [ -n "$aapt2_bin" ] && [ -x "$aapt2_bin" ]; then
      GRADLE_EXTRA_ARGS+=("-Pandroid.aapt2FromMavenOverride=$aapt2_bin")
      break
    fi
  done
fi

# 4. Run Gradle APK Build
cd "$ANDROID_DIR"
if [ -x "./gradlew" ]; then
  GRADLE_CMD="./gradlew"
elif command -v gradle >/dev/null 2>&1; then
  GRADLE_CMD="gradle"
else
  echo "[!] ERROR: Neither ./gradlew nor system 'gradle' binary found."
  exit 1
fi

echo "[2/3] Compiling Mobile, Android TV, and Universal APKs..."
"$GRADLE_CMD" assembleUniversalDebug assembleMobileDebug assembleTvDebug assembleUniversalRelease "${GRADLE_EXTRA_ARGS[@]}"

mkdir -p "$OUT_DIR"
find "$ANDROID_DIR/app/build/outputs/apk" -name "*.apk" -exec cp -f {} "$OUT_DIR/" \;

echo "[3/3] Build complete! Generated APKs in $OUT_DIR:"
ls -lh "$OUT_DIR"/*.apk
