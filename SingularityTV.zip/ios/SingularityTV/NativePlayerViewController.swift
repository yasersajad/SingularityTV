import UIKit
import CoreFoundation
import AVFoundation
import AVKit
import MediaPlayer
import WebKit

private struct IosSubCue {
    let startSec: Double
    let endSec: Double
    let text: String
}

private struct IosSubTrack {
    let lang: String
    let url: String
    let score: Int
    let syncMatch: Bool
}

class NativePlayerViewController: UIViewController, WKScriptMessageHandler, WKNavigationDelegate, WKUIDelegate, AVPictureInPictureControllerDelegate, AVPlayerItemLegibleOutputPushDelegate, AVAssetResourceLoaderDelegate {
    private let payloadJson: String
    var onProgressUpdate: ((String, Int, Int, Int, Bool) -> Void)?
    var onPreferredSource: ((String) -> Void)?
    var onBlockedAd: ((String) -> Void)?

    private var player: AVPlayer?
    private var playerLayer: AVPlayerLayer?
    private var pipController: AVPictureInPictureController?
    private var timeObserver: Any?
    private var itemStatusObserver: NSKeyValueObservation?

    private var streamUrl: String = ""
    private var streamTitle: String = "SingularityTV"
    private var progressKey: String = ""
    private var startTimeSec: Double = 0
    private var imdbId: String = ""
    private var tmdbId: String = ""
    private var mediaType: String = "movie"
    private var seasonNum: Int = 1
    private var episodeNum: Int = 1
    private var preferredLang: String = "ar"
    private var currentSource: String = "multiembed"
    private var currentSpeed: Float = 1.0
    private var subDelaySec: Double = 0.0
    private var lastProgressSaveTime: TimeInterval = 0

    private let serverOrder = ["multiembed"]
    private var failoverAttempts: Int = 0
    private var isSwitchingServer: Bool = false
    private var isCaptchaVisible: Bool = false
    private var adRuleList: WKContentRuleList?
    private var isManualPick: Bool = false
    private let captchaCardView = UIView()
    private let syncCardView = UIView()
    private let syncValueLabel = UILabel()
    private let syncCenterLabel = UILabel()
    private var syncRepeatTimer: Timer?
    private var multiEmbedSubServers: [(name: String, idx: String)] = []
    private var captchaTitleLabel = UILabel()
    private var pendingNextSource: String = ""
    private var activeReferer: String = ""
    private var streamIsHls: Bool = false
    private var inlineM3u8Text: String = ""
    private var activeStreamHeaders: [String: String] = [:]
    private let resourceLoaderQueue = DispatchQueue(label: "com.singularity.tv.hlsloader")
    private var activeReleaseHint: String = ""
    private var rawActiveCues: [IosSubCue] = []
    private var activeSubIsStreamNative: Bool = false
    private var usingNativeHlsSubtitle: Bool = false
    private var hlsLegibleOptions: [(lang: String, title: String, option: AVMediaSelectionOption)] = []
    private var resolverWebView: WKWebView?
    private var failoverTimer: Timer?
    private var verifiedServers: [String: (url: String, referer: String)] = [:]
    private var probedFailedServers: Set<String> = []
    private var failedStreamUrls: Set<String> = []
    private var headerRetryStage: Int = 0
    private var probeQueue: [String] = []
    private var probeWebViews: [WKWebView] = []
    private var probeSlotSources: [ObjectIdentifier: String] = [:]
    private var probeTimers: [ObjectIdentifier: Timer] = [:]
    private var isProbingActive: Bool = false
    private var seriesTitle: String = ""
    private var totalEpisodesInSeason: Int = 0
    private var introStartSec: Double = -1
    private var introEndSec: Double = -1
    private var recapStartSec: Double = -1
    private var recapEndSec: Double = -1
    private var outroStartSec: Double = -1
    private var activeSkipTargetSec: Double = -1
    private var nextEpDismissed: Bool = false
    private var nextEpCountdownSec: Int = 10
    private var nextEpTimer: Timer?
    private let skipSegmentButton = UIButton(type: .system)
    private let nextEpCardView = UIView()
    private let nextEpTitleLabel = UILabel()
    private let nextEpCountdownLabel = UILabel()

    private var availableSubs: [IosSubTrack] = []
    private var activeCues: [IosSubCue] = []
    private var activeSubIndex: Int = -1

    private let videoContainer = UIView()
    private let overlayView = UIView()
    private let subtitleLabel = UILabel()
    private let titleLabel = UILabel()
    private let serverBadgeButton = UIButton(type: .system)
    private let switchServerButton = UIButton(type: .system)
    private let recentlyUpdatedSources: Set<String> = ["vidsrcmeru", "vidsrcto", "vidlink", "vidsrccc", "vidfast", "rivestream", "vidsrcxyz", "moviesapi"]
    private let serverCatalogVersion = "v275"
    private let playPauseButton = UIButton(type: .system)
    private let seekSlider = UISlider()
    private let currentPosLabel = UILabel()
    private let durationLabel = UILabel()
    private let subButton = UIButton(type: .system)
    private let syncButton = UIButton(type: .system)
    private let speedButton = UIButton(type: .system)
    private let pipButton = UIButton(type: .system)
    private let leftSeekBadge = UILabel()
    private let rightSeekBadge = UILabel()
    private let statusToastLabel = UILabel()

    private var isControllerVisible = true
    private var isScrubbing = false
    private var hideControllerWorkItem: DispatchWorkItem?
    private var singleTapWorkItem: DispatchWorkItem?
    private var hideLeftSeekWorkItem: DispatchWorkItem?
    private var hideRightSeekWorkItem: DispatchWorkItem?
    private var accumLeftSeek = 0
    private var accumRightSeek = 0
    private var lastTapTime: TimeInterval = 0
    private var lastTapSide = 0
    private var activeSeekSide = 0
    private var lastSeekEventTime: TimeInterval = 0

    private var gestureMode = 0
    private var gestureStartPoint = CGPoint.zero
    private var gestureStartVal: CGFloat = 0.5
    private let hiddenVolumeView = MPVolumeView(frame: CGRect(x: -1000, y: -1000, width: 100, height: 40))

    private let brightnessHudView = UIView()
    private let brightnessTrackView = UIView()
    private let brightnessFillView = UIView()
    private var brightnessFillHeightConstraint: NSLayoutConstraint?
    private let brightnessPctLabel = UILabel()
    private let volumeHudView = UIView()
    private let volumeTrackView = UIView()
    private let volumeFillView = UIView()
    private var volumeFillHeightConstraint: NSLayoutConstraint?
    private let volumePctLabel = UILabel()
    private var hideHudWorkItem: DispatchWorkItem?

    init(payloadJson: String) {
        self.payloadJson = payloadJson
        super.init(nibName: nil, bundle: nil)
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    override var prefersStatusBarHidden: Bool { true }
    override var prefersHomeIndicatorAutoHidden: Bool { true }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask { .landscape }

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black
        view.addSubview(hiddenVolumeView)
        setupUi()
        setupResolverWebView()
        parsePayloadAndPlay()
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        playerLayer?.frame = videoContainer.bounds
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        saveProgress(forceCompleted: false)
        failoverTimer?.invalidate()
        player?.pause()
    }


    @objc private func handleSkipSegment() {
        guard let p = player, activeSkipTargetSec > 0 else { return }
        p.seek(to: CMTime(seconds: activeSkipTargetSec, preferredTimescale: 600))
        skipSegmentButton.isHidden = true
        activeSkipTargetSec = -1
    }

    @objc private func dismissNextEpisodeCard() {
        nextEpDismissed = true
        nextEpTimer?.invalidate()
        nextEpTimer = nil
        nextEpCardView.isHidden = true
    }

    @objc private func playNextEpisodeInPlayer() {
        nextEpTimer?.invalidate()
        nextEpTimer = nil
        nextEpCardView.isHidden = true
        saveProgress(forceCompleted: true)
        stopBackgroundServerProbing()
        nextEpTimer?.invalidate()
        verifiedServers.removeAll()
        probedFailedServers.removeAll()
        availableSubs.removeAll()
        activeCues.removeAll()
        activeSubIndex = -1
        subtitleLabel.isHidden = true
        episodeNum += 1
        let idKey = imdbId.isEmpty ? tmdbId : imdbId
        progressKey = "tv_\(idKey)_s\(seasonNum)e\(episodeNum)"
        streamTitle = "\(seriesTitle) · S\(seasonNum)E\(episodeNum)"
        titleLabel.text = streamTitle
        startTimeSec = 0
        streamUrl = ""
        introStartSec = -1
        introEndSec = -1
        recapStartSec = -1
        recapEndSec = -1
        outroStartSec = -1
        nextEpDismissed = false
        updateSwitchServerButtonTitle()
        if let obs = timeObserver {
            player?.removeTimeObserver(obs)
            timeObserver = nil
        }
        itemStatusObserver?.invalidate()
        itemStatusObserver = nil
        player?.pause()
        player?.replaceCurrentItem(with: nil)
        player = nil
        playerLayer?.player = nil
        startResolvingInitialSource()
        fetchSubtitlesInBackground()
        fetchSkipSegmentsInBackground()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { [weak self] in
            self?.startBackgroundServerProbing()
        }
    }

    private func fetchSkipSegmentsInBackground(durationMs: Int = 0) {
        if durationMs == 0 {
            introStartSec = -1
            introEndSec = -1
            recapStartSec = -1
            recapEndSec = -1
            outroStartSec = -1
        }
        let rawIm = imdbId.trimmingCharacters(in: .whitespacesAndNewlines)
        let tm = tmdbId.trimmingCharacters(in: .whitespacesAndNewlines)
        let isTv = mediaType.lowercased() == "tv"
        let s = seasonNum
        let e = episodeNum
        let durSec = durationMs > 0 ? Double(durationMs) / 1000.0 : (player?.currentItem.map { CMTimeGetSeconds($0.duration) } ?? 0)

        DispatchQueue.global(qos: .utility).async { [weak self] in
            var im = rawIm
            if !im.hasPrefix("tt") && !tm.isEmpty && tm.allSatisfy({ $0.isNumber }) {
                let prop = isTv ? "P4983" : "P4947"
                let sparql = "SELECT ?imdb WHERE { ?item wdt:\(prop) \"\(tm)\" . ?item wdt:P345 ?imdb . } LIMIT 1"
                if let enc = sparql.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
                   let wu = URL(string: "https://query.wikidata.org/sparql?format=json&query=\(enc)") {
                    let wGroup = DispatchGroup()
                    wGroup.enter()
                    var wReq = URLRequest(url: wu, timeoutInterval: 3.5)
                    wReq.setValue("application/sparql-results+json", forHTTPHeaderField: "Accept")
                    URLSession.shared.dataTask(with: wReq) { wd, _, _ in
                        if let wd = wd,
                           let wj = try? JSONSerialization.jsonObject(with: wd) as? [String: Any],
                           let res = wj["results"] as? [String: Any],
                           let binds = res["bindings"] as? [[String: Any]],
                           let first = binds.first,
                           let imdbObj = first["imdb"] as? [String: Any],
                           let val = imdbObj["value"] as? String, val.hasPrefix("tt") {
                            im = val
                        }
                        wGroup.leave()
                    }.resume()
                    _ = wGroup.wait(timeout: .now() + 3.8)
                }
            }

            let lock = NSLock()
            var introCands: [(start: Double, end: Double, weight: Int)] = []
            var recapCands: [(start: Double, end: Double, weight: Int)] = []
            var outroCands: [(start: Double, weight: Int)] = []
            let group = DispatchGroup()

            func addIntro(_ st: Double, _ en: Double, _ w: Int) {
                guard st >= 0, en > st + 5, (en - st) <= 210, (durSec <= 0 || st < durSec * 0.35) else { return }
                lock.lock(); introCands.append((st, en, w)); lock.unlock()
            }
            func addRecap(_ st: Double, _ en: Double, _ w: Int) {
                guard st >= 0, en > st + 5, st < 150, (durSec <= 0 || en < durSec * 0.25) else { return }
                lock.lock(); recapCands.append((st, en, w)); lock.unlock()
            }
            func addOutro(_ st: Double, _ w: Int) {
                guard st > 30, durSec > 180 else { return }
                let rem = durSec - st
                guard rem >= 12.0 && rem <= 240.0 && st >= durSec * 0.80 else { return }
                lock.lock(); outroCands.append((st, w)); lock.unlock()
            }

            var qParts: [String] = []
            if im.hasPrefix("tt") { qParts.append("imdb_id=\(im)") }
            else if !tm.isEmpty && tm.allSatisfy({ $0.isNumber }) { qParts.append("tmdb_id=\(tm)") }
            if isTv { qParts.append("season=\(s)"); qParts.append("episode=\(e)") }
            if durationMs > 30000 { qParts.append("duration_ms=\(durationMs)") }
            if !qParts.isEmpty, let u1 = URL(string: "https://api.theintrodb.org/v3/media?" + qParts.joined(separator: "&")) {
                group.enter()
                var req1 = URLRequest(url: u1, timeoutInterval: 5.5)
                req1.setValue("SingularityTV/1.0.0", forHTTPHeaderField: "User-Agent")
                URLSession.shared.dataTask(with: req1) { data, _, _ in
                    if let d = data, let json = try? JSONSerialization.jsonObject(with: d) as? [String: Any] {
                        if let arr = json["intro"] as? [[String: Any]], let first = arr.first, let endMs = (first["end_ms"] as? NSNumber)?.doubleValue {
                            addIntro(((first["start_ms"] as? NSNumber)?.doubleValue ?? 0) / 1000.0, endMs / 1000.0, 6)
                        }
                        if let arr = json["recap"] as? [[String: Any]], let first = arr.first, let endMs = (first["end_ms"] as? NSNumber)?.doubleValue {
                            addRecap(((first["start_ms"] as? NSNumber)?.doubleValue ?? 0) / 1000.0, endMs / 1000.0, 6)
                        }
                        if let arr = json["credits"] as? [[String: Any]], let first = arr.first, let stMs = (first["start_ms"] as? NSNumber)?.doubleValue {
                            addOutro(stMs / 1000.0, 6)
                        }
                    }
                    group.leave()
                }.resume()
            }

            if im.hasPrefix("tt") {
                let epStr = isTv ? "season=\(s)&episode=\(e)" : "is_movie=true"
                if let u2 = URL(string: "https://api.introdb.app/segments?imdb_id=\(im)&\(epStr)") {
                    group.enter()
                    var req2 = URLRequest(url: u2, timeoutInterval: 5.5)
                    req2.setValue("SingularityTV/1.0.0", forHTTPHeaderField: "User-Agent")
                    URLSession.shared.dataTask(with: req2) { data, _, _ in
                        if let d = data, let json = try? JSONSerialization.jsonObject(with: d) as? [String: Any] {
                            if let seg = json["intro"] as? [String: Any] {
                                let st = ((seg["start_ms"] as? NSNumber)?.doubleValue ?? ((seg["start_sec"] as? NSNumber)?.doubleValue ?? 0) * 1000.0) / 1000.0
                                let en = ((seg["end_ms"] as? NSNumber)?.doubleValue ?? ((seg["end_sec"] as? NSNumber)?.doubleValue ?? 0) * 1000.0) / 1000.0
                                addIntro(st, en, 5)
                            }
                            if let seg = json["recap"] as? [String: Any] {
                                let st = ((seg["start_ms"] as? NSNumber)?.doubleValue ?? ((seg["start_sec"] as? NSNumber)?.doubleValue ?? 0) * 1000.0) / 1000.0
                                let en = ((seg["end_ms"] as? NSNumber)?.doubleValue ?? ((seg["end_sec"] as? NSNumber)?.doubleValue ?? 0) * 1000.0) / 1000.0
                                addRecap(st, en, 5)
                            }
                            if let seg = (json["outro"] as? [String: Any]) ?? (json["credits"] as? [String: Any]) {
                                let st = ((seg["start_ms"] as? NSNumber)?.doubleValue ?? ((seg["start_sec"] as? NSNumber)?.doubleValue ?? 0) * 1000.0) / 1000.0
                                addOutro(st, 5)
                            }
                        }
                        group.leave()
                    }.resume()
                }
                if isTv, let u2b = URL(string: "https://api.introdb.app/intro?imdb_id=\(im)&season=\(s)&episode=\(e)") {
                    group.enter()
                    var req2b = URLRequest(url: u2b, timeoutInterval: 5.0)
                    req2b.setValue("SingularityTV/1.0.0", forHTTPHeaderField: "User-Agent")
                    URLSession.shared.dataTask(with: req2b) { data, _, _ in
                        if let d = data, let json = try? JSONSerialization.jsonObject(with: d) as? [String: Any] {
                            let st = ((json["start_ms"] as? NSNumber)?.doubleValue ?? ((json["start_sec"] as? NSNumber)?.doubleValue ?? 0) * 1000.0) / 1000.0
                            let en = ((json["end_ms"] as? NSNumber)?.doubleValue ?? ((json["end_sec"] as? NSNumber)?.doubleValue ?? 0) * 1000.0) / 1000.0
                            addIntro(st, en, 4)
                        }
                        group.leave()
                    }.resume()
                }
            }

            if im.hasPrefix("tt") || (!tm.isEmpty && tm.allSatisfy({ $0.isNumber })) {
                var sParts: [String] = []
                if im.hasPrefix("tt") { sParts.append("imdb_id=\(im)") } else { sParts.append("tmdb_id=\(tm)") }
                if isTv { sParts.append("season=\(s)"); sParts.append("episode=\(e)") }
                if durationMs > 30000 { sParts.append("duration_ms=\(durationMs)") }
                let qStr = sParts.joined(separator: "&")
                for base in ["https://api.skipdb.tv/v1/segments", "https://api.skipdb.tv/api/segments"] {
                    if let u3 = URL(string: "\(base)?\(qStr)") {
                        group.enter()
                        var req3 = URLRequest(url: u3, timeoutInterval: 5.5)
                        req3.setValue("SingularityTV/1.0.0", forHTTPHeaderField: "User-Agent")
                        URLSession.shared.dataTask(with: req3) { data, _, _ in
                            if let d = data, let json = try? JSONSerialization.jsonObject(with: d) as? [String: Any] {
                                let arr = (json["segments"] as? [[String: Any]]) ?? (json["results"] as? [[String: Any]]) ?? (json["data"] as? [[String: Any]]) ?? []
                                for seg in arr {
                                    let tp = (seg["type"] as? String ?? seg["segment"] as? String ?? "").lowercased()
                                    let st = ((seg["start_ms"] as? NSNumber)?.doubleValue ?? ((seg["start"] as? NSNumber)?.doubleValue ?? 0) * 1000.0) / 1000.0
                                    let en = ((seg["end_ms"] as? NSNumber)?.doubleValue ?? ((seg["end"] as? NSNumber)?.doubleValue ?? 0) * 1000.0) / 1000.0
                                    if tp.contains("intro") || tp == "op" { addIntro(st, en, 4) }
                                    else if tp.contains("recap") { addRecap(st, en, 4) }
                                    else if tp.contains("credit") || tp.contains("outro") || tp == "ed" { addOutro(st, 4) }
                                }
                            }
                            group.leave()
                        }.resume()
                    }
                }
            }

            if im.hasPrefix("tt") {
                let ihUrlStr = isTv
                    ? "https://api.introhater.com/skip-times?imdb_id=\(im)&season=\(s)&episode=\(e)"
                    : "https://api.introhater.com/skip-times?imdb_id=\(im)"
                if let u4 = URL(string: ihUrlStr) {
                    group.enter()
                    var req4 = URLRequest(url: u4, timeoutInterval: 5.5)
                    req4.setValue("SingularityTV/1.0.0", forHTTPHeaderField: "User-Agent")
                    URLSession.shared.dataTask(with: req4) { data, _, _ in
                        if let d = data, let json = try? JSONSerialization.jsonObject(with: d) as? [String: Any] {
                            let arr = (json["results"] as? [[String: Any]]) ?? (json["segments"] as? [[String: Any]]) ?? []
                            for seg in arr {
                                let tp = (seg["skipType"] as? String ?? seg["type"] as? String ?? "").lowercased()
                                if let iv = seg["interval"] as? [String: Any],
                                   let st = (iv["startTime"] as? NSNumber)?.doubleValue,
                                   let en = (iv["endTime"] as? NSNumber)?.doubleValue {
                                    if tp == "op" || tp.contains("intro") { addIntro(st, en, 3) }
                                    else if tp == "recap" { addRecap(st, en, 3) }
                                    else if tp == "ed" || tp.contains("outro") || tp.contains("credit") { addOutro(st, 3) }
                                }
                            }
                        }
                        group.leave()
                    }.resume()
                }
            }

            if im.hasPrefix("tt"), let armUrl = URL(string: "https://arm.haglund.dev/api/v2/ids?source=imdb&id=\(im)") {
                group.enter()
                URLSession.shared.dataTask(with: URLRequest(url: armUrl, timeoutInterval: 4.5)) { data, _, _ in
                    let epLen = durSec > 60 ? Int(durSec) : 0
                    if let d = data, let armJson = try? JSONSerialization.jsonObject(with: d) as? [String: Any],
                       let malId = (armJson["myanimelist"] as? NSNumber)?.intValue, malId > 0,
                       let aniUrl = URL(string: "https://api.aniskip.com/v2/skip-times/\(malId)/\(isTv ? e : 1)?types[]=op&types[]=ed&types[]=recap&episodeLength=\(epLen)") {
                        URLSession.shared.dataTask(with: URLRequest(url: aniUrl, timeoutInterval: 4.5)) { d2, _, _ in
                            if let d2 = d2, let aniJson = try? JSONSerialization.jsonObject(with: d2) as? [String: Any],
                               let arr = aniJson["results"] as? [[String: Any]] {
                                for seg in arr {
                                    let tp = (seg["skipType"] as? String ?? "").lowercased()
                                    if let iv = seg["interval"] as? [String: Any],
                                       let st = (iv["startTime"] as? NSNumber)?.doubleValue,
                                       let en = (iv["endTime"] as? NSNumber)?.doubleValue {
                                        if tp == "op" { addIntro(st, en, 4) }
                                        else if tp == "recap" { addRecap(st, en, 4) }
                                        else if tp == "ed" { addOutro(st, 4) }
                                    }
                                }
                            }
                            group.leave()
                        }.resume()
                    } else {
                        group.leave()
                    }
                }.resume()
            }

            _ = group.wait(timeout: .now() + 7.0)

            func pickBestSpan(_ cands: [(start: Double, end: Double, weight: Int)]) -> (Double, Double)? {
                if cands.isEmpty { return nil }
                var bestScore = -1
                var bestCenter = cands[0]
                for c in cands {
                    var clusterScore = 0
                    for o in cands {
                        if abs(c.start - o.start) <= 3.5 && abs(c.end - o.end) <= 3.5 {
                            clusterScore += o.weight
                        }
                    }
                    if clusterScore > bestScore {
                        bestScore = clusterScore
                        bestCenter = c
                    }
                }
                var sumSt = 0.0
                var sumEn = 0.0
                var totalW = 0.0
                for o in cands {
                    if abs(bestCenter.start - o.start) <= 3.5 && abs(bestCenter.end - o.end) <= 3.5 {
                        let w = Double(o.weight)
                        sumSt += o.start * w
                        sumEn += o.end * w
                        totalW += w
                    }
                }
                if totalW > 0 { return (sumSt / totalW, sumEn / totalW) }
                return (bestCenter.start, bestCenter.end)
            }

            func pickBestOutro(_ cands: [(start: Double, weight: Int)]) -> Double? {
                if cands.isEmpty { return nil }
                var bestScore = -1
                var bestCenter = cands[0]
                for c in cands {
                    var clusterScore = 0
                    for o in cands {
                        if abs(c.start - o.start) <= 4.0 {
                            clusterScore += o.weight
                        }
                    }
                    if clusterScore > bestScore {
                        bestScore = clusterScore
                        bestCenter = c
                    }
                }
                var sumSt = 0.0
                var totalW = 0.0
                for o in cands {
                    if abs(bestCenter.start - o.start) <= 4.0 {
                        let w = Double(o.weight)
                        sumSt += o.start * w
                        totalW += w
                    }
                }
                if totalW > 0 { return sumSt / totalW }
                return bestCenter.start
            }

            let bestIntro = pickBestSpan(introCands)
            let bestRecap = pickBestSpan(recapCands)
            let bestOutro = pickBestOutro(outroCands)

            DispatchQueue.main.async {
                guard let self = self else { return }
                if let i = bestIntro {
                    self.introStartSec = i.0
                    self.introEndSec = i.1
                }
                if let r = bestRecap {
                    self.recapStartSec = r.0
                    self.recapEndSec = r.1
                }
                if let o = bestOutro {
                    self.outroStartSec = o
                }
            }
        }
    }

    private func updateSkipAndNextEpisodeUi() {
        guard let p = player, let item = p.currentItem else { return }
        let cur = CMTimeGetSeconds(p.currentTime())
        let dur = CMTimeGetSeconds(item.duration)
        if !cur.isFinite || cur < 0 { return }

        if recapEndSec > recapStartSec && cur >= recapStartSec && cur < recapEndSec - 1.0 {
            activeSkipTargetSec = recapEndSec
            skipSegmentButton.setImage(UIImage(systemName: "forward.end.fill"), for: .normal)
            skipSegmentButton.tintColor = .black
            skipSegmentButton.setTitle(" Skip Recap", for: .normal)
            skipSegmentButton.isHidden = false
        } else if introEndSec > introStartSec && cur >= introStartSec && cur < introEndSec - 1.0 {
            activeSkipTargetSec = introEndSec
            skipSegmentButton.setImage(UIImage(systemName: "forward.end.fill"), for: .normal)
            skipSegmentButton.tintColor = .black
            skipSegmentButton.setTitle(" Skip Intro", for: .normal)
            skipSegmentButton.isHidden = false
        } else if mediaType.lowercased() == "movie" && outroStartSec > 60 && dur.isFinite && dur > outroStartSec + 10 && cur >= outroStartSec && cur < dur - 5 {
            activeSkipTargetSec = dur - 2
            skipSegmentButton.setImage(UIImage(systemName: "forward.end.fill"), for: .normal)
            skipSegmentButton.tintColor = .black
            skipSegmentButton.setTitle(" Skip Credits", for: .normal)
            skipSegmentButton.isHidden = false
        } else {
            skipSegmentButton.isHidden = true
            activeSkipTargetSec = -1
        }

        if mediaType.lowercased() == "tv" && !nextEpDismissed && dur.isFinite && dur > 180 {
            let hasMoreEpisodes = totalEpisodesInSeason <= 0 || episodeNum < totalEpisodesInSeason
            if hasMoreEpisodes {
                let validOutro = outroStartSec > 60 && (dur - outroStartSec) >= 12.0 && (dur - outroStartSec) <= 240.0 && outroStartSec >= dur * 0.80
                let triggerSec = validOutro ? outroStartSec : max(dur * 0.94, dur - 45.0)
                if cur >= triggerSec && cur < dur {
                    if nextEpCardView.isHidden {
                        nextEpTitleLabel.text = "\(seriesTitle) · S\(seasonNum)E\(episodeNum + 1)"
                        nextEpCountdownSec = 10
                        nextEpCountdownLabel.text = "Starting in 10s..."
                        nextEpCardView.isHidden = false
                        nextEpTimer?.invalidate()
                        nextEpTimer = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] t in
                            guard let self = self else { t.invalidate(); return }
                            if self.nextEpDismissed || self.nextEpCardView.isHidden { t.invalidate(); return }
                            self.nextEpCountdownSec -= 1
                            if self.nextEpCountdownSec <= 0 {
                                t.invalidate()
                                self.playNextEpisodeInPlayer()
                            } else {
                                self.nextEpCountdownLabel.text = "Starting in \(self.nextEpCountdownSec)s..."
                            }
                        }
                    }
                } else if !nextEpCardView.isHidden {
                    nextEpTimer?.invalidate()
                    nextEpTimer = nil
                    nextEpCardView.isHidden = true
                }
            }
        }
    }

    deinit {
        stopBackgroundServerProbing()
        nextEpTimer?.invalidate()
        if let obs = timeObserver {
            player?.removeTimeObserver(obs)
        }
        itemStatusObserver?.invalidate()
        failoverTimer?.invalidate()
    }

    private func setupUi() {
        videoContainer.frame = view.bounds
        videoContainer.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        videoContainer.backgroundColor = .black
        view.addSubview(videoContainer)

        subtitleLabel.translatesAutoresizingMaskIntoConstraints = false
        subtitleLabel.textColor = .white
        subtitleLabel.font = .boldSystemFont(ofSize: 20)
        subtitleLabel.textAlignment = .center
        subtitleLabel.numberOfLines = 0
        subtitleLabel.layer.shadowColor = UIColor.black.cgColor
        subtitleLabel.layer.shadowRadius = 4
        subtitleLabel.layer.shadowOpacity = 0.95
        subtitleLabel.layer.shadowOffset = CGSize(width: 0, height: 1)
        subtitleLabel.isHidden = true
        overlayView.frame = view.bounds
        overlayView.autoresizingMask = [.flexibleWidth, .flexibleHeight]
        overlayView.backgroundColor = UIColor.black.withAlphaComponent(0.32)
        view.addSubview(overlayView)
        view.addSubview(subtitleLabel)

        let backBtn = UIButton(type: .system)
        backBtn.translatesAutoresizingMaskIntoConstraints = false
        backBtn.setImage(UIImage(systemName: "chevron.backward"), for: .normal)
        backBtn.tintColor = .white
        backBtn.addTarget(self, action: #selector(handleBack), for: .touchUpInside)

        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.textColor = .white
        titleLabel.font = .boldSystemFont(ofSize: 17)
        titleLabel.lineBreakMode = .byTruncatingTail

        serverBadgeButton.translatesAutoresizingMaskIntoConstraints = false
        serverBadgeButton.setTitleColor(.white, for: .normal)
        serverBadgeButton.titleLabel?.font = .systemFont(ofSize: 12, weight: .semibold)
        serverBadgeButton.backgroundColor = UIColor.white.withAlphaComponent(0.16)
        serverBadgeButton.layer.cornerRadius = 11
        serverBadgeButton.layer.masksToBounds = true
        serverBadgeButton.contentEdgeInsets = UIEdgeInsets(top: 4, left: 10, bottom: 4, right: 10)
        serverBadgeButton.setContentCompressionResistancePriority(.required, for: .horizontal)
        serverBadgeButton.setContentHuggingPriority(.required, for: .horizontal)
        serverBadgeButton.isUserInteractionEnabled = false

        switchServerButton.translatesAutoresizingMaskIntoConstraints = false
        switchServerButton.setTitle("Servers ▾", for: .normal)
        switchServerButton.isHidden = false
        switchServerButton.setTitleColor(.white, for: .normal)
        switchServerButton.titleLabel?.font = .systemFont(ofSize: 12, weight: .semibold)
        switchServerButton.backgroundColor = UIColor(red: 229/255, green: 9/255, blue: 20/255, alpha: 0.85)
        switchServerButton.layer.cornerRadius = 11
        switchServerButton.layer.masksToBounds = true
        switchServerButton.contentEdgeInsets = UIEdgeInsets(top: 4, left: 10, bottom: 4, right: 10)
        switchServerButton.setContentCompressionResistancePriority(.required, for: .horizontal)
        switchServerButton.setContentHuggingPriority(.required, for: .horizontal)
        switchServerButton.addTarget(self, action: #selector(handleSwitchServer), for: .touchUpInside)

        overlayView.addSubview(backBtn)
        overlayView.addSubview(titleLabel)
        overlayView.addSubview(switchServerButton)
        overlayView.addSubview(serverBadgeButton)

        let rewBtn = UIButton(type: .system)
        rewBtn.translatesAutoresizingMaskIntoConstraints = false
        rewBtn.setImage(UIImage(systemName: "gobackward.10"), for: .normal)
        rewBtn.tintColor = .white
        rewBtn.setPreferredSymbolConfiguration(UIImage.SymbolConfiguration(pointSize: 26, weight: .semibold), forImageIn: .normal)
        rewBtn.addTarget(self, action: #selector(handleRewind10), for: .touchUpInside)

        playPauseButton.translatesAutoresizingMaskIntoConstraints = false
        playPauseButton.setImage(UIImage(systemName: "pause.fill"), for: .normal)
        playPauseButton.tintColor = .white
        playPauseButton.backgroundColor = UIColor.white.withAlphaComponent(0.16)
        playPauseButton.layer.cornerRadius = 32
        playPauseButton.setPreferredSymbolConfiguration(UIImage.SymbolConfiguration(pointSize: 28, weight: .bold), forImageIn: .normal)
        playPauseButton.addTarget(self, action: #selector(handlePlayPause), for: .touchUpInside)

        let fwdBtn = UIButton(type: .system)
        fwdBtn.translatesAutoresizingMaskIntoConstraints = false
        fwdBtn.setImage(UIImage(systemName: "goforward.10"), for: .normal)
        fwdBtn.tintColor = .white
        fwdBtn.setPreferredSymbolConfiguration(UIImage.SymbolConfiguration(pointSize: 26, weight: .semibold), forImageIn: .normal)
        fwdBtn.addTarget(self, action: #selector(handleForward10), for: .touchUpInside)

        overlayView.addSubview(rewBtn)
        overlayView.addSubview(playPauseButton)
        overlayView.addSubview(fwdBtn)

        currentPosLabel.translatesAutoresizingMaskIntoConstraints = false
        currentPosLabel.textColor = .white
        currentPosLabel.font = .monospacedDigitSystemFont(ofSize: 12, weight: .semibold)
        currentPosLabel.text = "0:00"

        durationLabel.translatesAutoresizingMaskIntoConstraints = false
        durationLabel.textColor = UIColor.white.withAlphaComponent(0.8)
        durationLabel.font = .monospacedDigitSystemFont(ofSize: 12, weight: .semibold)
        durationLabel.text = "0:00"

        seekSlider.translatesAutoresizingMaskIntoConstraints = false
        seekSlider.minimumTrackTintColor = UIColor(red: 229/255, green: 9/255, blue: 20/255, alpha: 1)
        seekSlider.maximumTrackTintColor = UIColor.white.withAlphaComponent(0.3)
        seekSlider.addTarget(self, action: #selector(onSliderStart), for: .touchDown)
        seekSlider.addTarget(self, action: #selector(onSliderChanged), for: .valueChanged)
        seekSlider.addTarget(self, action: #selector(onSliderEnd), for: [.touchUpInside, .touchUpOutside, .touchCancel])

        overlayView.addSubview(currentPosLabel)
        overlayView.addSubview(seekSlider)
        overlayView.addSubview(durationLabel)

        subButton.translatesAutoresizingMaskIntoConstraints = false
        subButton.setTitle("Subtitles", for: .normal)
        subButton.setTitleColor(.white, for: .normal)
        subButton.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
        subButton.addTarget(self, action: #selector(openSubtitleMenu), for: .touchUpInside)

        speedButton.translatesAutoresizingMaskIntoConstraints = false
        speedButton.setTitle("1.0x", for: .normal)
        speedButton.setTitleColor(.white, for: .normal)
        speedButton.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
        speedButton.addTarget(self, action: #selector(openSpeedMenu), for: .touchUpInside)

        pipButton.translatesAutoresizingMaskIntoConstraints = false
        pipButton.setTitle("PiP", for: .normal)
        pipButton.setTitleColor(.white, for: .normal)
        pipButton.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
        pipButton.addTarget(self, action: #selector(togglePip), for: .touchUpInside)

        syncButton.translatesAutoresizingMaskIntoConstraints = false
        syncButton.setTitle("Sync 0.0s", for: .normal)
        syncButton.setTitleColor(.white, for: .normal)
        syncButton.titleLabel?.font = .systemFont(ofSize: 13, weight: .semibold)
        syncButton.addTarget(self, action: #selector(openSyncMenu), for: .touchUpInside)

        syncButton.isHidden = false
        let actionsStack = UIStackView(arrangedSubviews: [subButton, syncButton, speedButton, pipButton])
        actionsStack.translatesAutoresizingMaskIntoConstraints = false
        actionsStack.axis = .horizontal
        actionsStack.spacing = 24
        overlayView.addSubview(actionsStack)

        setupSeekBadges()
        setupGestureHuds()

        statusToastLabel.translatesAutoresizingMaskIntoConstraints = false
        statusToastLabel.backgroundColor = UIColor.black.withAlphaComponent(0.75)
        statusToastLabel.textColor = .white
        statusToastLabel.font = .systemFont(ofSize: 13, weight: .semibold)
        statusToastLabel.textAlignment = .center
        statusToastLabel.layer.cornerRadius = 14
        statusToastLabel.layer.masksToBounds = true
        statusToastLabel.isHidden = true
        view.addSubview(statusToastLabel)

        skipSegmentButton.translatesAutoresizingMaskIntoConstraints = false
        skipSegmentButton.setTitle("Skip Intro", for: .normal)
        skipSegmentButton.setTitleColor(.black, for: .normal)
        skipSegmentButton.titleLabel?.font = .boldSystemFont(ofSize: 14)
        skipSegmentButton.backgroundColor = UIColor.white.withAlphaComponent(0.94)
        skipSegmentButton.layer.cornerRadius = 8
        skipSegmentButton.contentEdgeInsets = UIEdgeInsets(top: 9, left: 18, bottom: 9, right: 18)
        skipSegmentButton.isHidden = true
        skipSegmentButton.addTarget(self, action: #selector(handleSkipSegment), for: .touchUpInside)
        view.addSubview(skipSegmentButton)

        nextEpCardView.translatesAutoresizingMaskIntoConstraints = false
        nextEpCardView.backgroundColor = UIColor(red: 14/255, green: 16/255, blue: 22/255, alpha: 0.94)
        nextEpCardView.layer.cornerRadius = 12
        nextEpCardView.layer.borderWidth = 1
        nextEpCardView.layer.borderColor = UIColor.white.withAlphaComponent(0.22).cgColor
        nextEpCardView.isHidden = true

        let nextTag = UILabel()
        nextTag.translatesAutoresizingMaskIntoConstraints = false
        nextTag.text = "NEXT EPISODE"
        nextTag.textColor = UIColor(red: 229/255, green: 9/255, blue: 20/255, alpha: 1)
        nextTag.font = .systemFont(ofSize: 11, weight: .heavy)

        nextEpTitleLabel.translatesAutoresizingMaskIntoConstraints = false
        nextEpTitleLabel.textColor = .white
        nextEpTitleLabel.font = .boldSystemFont(ofSize: 15)
        nextEpTitleLabel.text = "Next Episode"

        nextEpCountdownLabel.translatesAutoresizingMaskIntoConstraints = false
        nextEpCountdownLabel.textColor = UIColor.white.withAlphaComponent(0.75)
        nextEpCountdownLabel.font = .systemFont(ofSize: 12, weight: .medium)
        nextEpCountdownLabel.text = "Starting in 10s..."

        let playNextBtn = UIButton(type: .system)
        playNextBtn.translatesAutoresizingMaskIntoConstraints = false
        playNextBtn.setImage(UIImage(systemName: "play.fill"), for: .normal)
        playNextBtn.tintColor = .black
        playNextBtn.setTitle(" Play Next", for: .normal)
        playNextBtn.setTitleColor(.black, for: .normal)
        playNextBtn.titleLabel?.font = .boldSystemFont(ofSize: 13)
        playNextBtn.backgroundColor = .white
        playNextBtn.layer.cornerRadius = 6
        playNextBtn.contentEdgeInsets = UIEdgeInsets(top: 7, left: 14, bottom: 7, right: 14)
        playNextBtn.addTarget(self, action: #selector(playNextEpisodeInPlayer), for: .touchUpInside)

        let dismissNextBtn = UIButton(type: .system)
        dismissNextBtn.translatesAutoresizingMaskIntoConstraints = false
        dismissNextBtn.setTitle("Watch Credits", for: .normal)
        dismissNextBtn.setTitleColor(.white, for: .normal)
        dismissNextBtn.titleLabel?.font = .systemFont(ofSize: 12, weight: .semibold)
        dismissNextBtn.backgroundColor = UIColor.white.withAlphaComponent(0.14)
        dismissNextBtn.layer.cornerRadius = 6
        dismissNextBtn.contentEdgeInsets = UIEdgeInsets(top: 7, left: 12, bottom: 7, right: 12)
        dismissNextBtn.addTarget(self, action: #selector(dismissNextEpisodeCard), for: .touchUpInside)

        nextEpCardView.addSubview(nextTag)
        nextEpCardView.addSubview(nextEpTitleLabel)
        nextEpCardView.addSubview(nextEpCountdownLabel)
        nextEpCardView.addSubview(playNextBtn)
        nextEpCardView.addSubview(dismissNextBtn)
        view.addSubview(nextEpCardView)

        NSLayoutConstraint.activate([
            skipSegmentButton.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -24),
            skipSegmentButton.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -92),

            nextEpCardView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -24),
            nextEpCardView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -92),
            nextEpCardView.widthAnchor.constraint(equalToConstant: 268),

            nextTag.topAnchor.constraint(equalTo: nextEpCardView.topAnchor, constant: 12),
            nextTag.leadingAnchor.constraint(equalTo: nextEpCardView.leadingAnchor, constant: 14),

            nextEpTitleLabel.topAnchor.constraint(equalTo: nextTag.bottomAnchor, constant: 4),
            nextEpTitleLabel.leadingAnchor.constraint(equalTo: nextEpCardView.leadingAnchor, constant: 14),
            nextEpTitleLabel.trailingAnchor.constraint(equalTo: nextEpCardView.trailingAnchor, constant: -14),

            nextEpCountdownLabel.topAnchor.constraint(equalTo: nextEpTitleLabel.bottomAnchor, constant: 3),
            nextEpCountdownLabel.leadingAnchor.constraint(equalTo: nextEpCardView.leadingAnchor, constant: 14),

            playNextBtn.topAnchor.constraint(equalTo: nextEpCountdownLabel.bottomAnchor, constant: 10),
            playNextBtn.leadingAnchor.constraint(equalTo: nextEpCardView.leadingAnchor, constant: 14),
            playNextBtn.bottomAnchor.constraint(equalTo: nextEpCardView.bottomAnchor, constant: -12),

            dismissNextBtn.centerYAnchor.constraint(equalTo: playNextBtn.centerYAnchor),
            dismissNextBtn.leadingAnchor.constraint(equalTo: playNextBtn.trailingAnchor, constant: 8)
        ])

        NSLayoutConstraint.activate([
            backBtn.topAnchor.constraint(equalTo: overlayView.safeAreaLayoutGuide.topAnchor, constant: 12),
            backBtn.leadingAnchor.constraint(equalTo: overlayView.safeAreaLayoutGuide.leadingAnchor, constant: 18),
            backBtn.widthAnchor.constraint(equalToConstant: 40),
            backBtn.heightAnchor.constraint(equalToConstant: 40),

            titleLabel.centerYAnchor.constraint(equalTo: backBtn.centerYAnchor),
            titleLabel.leadingAnchor.constraint(equalTo: backBtn.trailingAnchor, constant: 10),
            serverBadgeButton.centerYAnchor.constraint(equalTo: backBtn.centerYAnchor),
            serverBadgeButton.trailingAnchor.constraint(equalTo: overlayView.safeAreaLayoutGuide.trailingAnchor, constant: -18),
            serverBadgeButton.heightAnchor.constraint(equalToConstant: 26),

            switchServerButton.centerYAnchor.constraint(equalTo: backBtn.centerYAnchor),
            switchServerButton.trailingAnchor.constraint(equalTo: serverBadgeButton.leadingAnchor, constant: -8),
            switchServerButton.heightAnchor.constraint(equalToConstant: 26),

            titleLabel.trailingAnchor.constraint(lessThanOrEqualTo: switchServerButton.leadingAnchor, constant: -10),

            playPauseButton.centerXAnchor.constraint(equalTo: overlayView.centerXAnchor),
            playPauseButton.centerYAnchor.constraint(equalTo: overlayView.centerYAnchor),
            playPauseButton.widthAnchor.constraint(equalToConstant: 64),
            playPauseButton.heightAnchor.constraint(equalToConstant: 64),

            rewBtn.centerYAnchor.constraint(equalTo: playPauseButton.centerYAnchor),
            rewBtn.trailingAnchor.constraint(equalTo: playPauseButton.leadingAnchor, constant: -42),

            fwdBtn.centerYAnchor.constraint(equalTo: playPauseButton.centerYAnchor),
            fwdBtn.leadingAnchor.constraint(equalTo: playPauseButton.trailingAnchor, constant: 42),

            actionsStack.bottomAnchor.constraint(equalTo: overlayView.safeAreaLayoutGuide.bottomAnchor, constant: -10),
            actionsStack.centerXAnchor.constraint(equalTo: overlayView.centerXAnchor),

            currentPosLabel.leadingAnchor.constraint(equalTo: overlayView.safeAreaLayoutGuide.leadingAnchor, constant: 22),
            currentPosLabel.bottomAnchor.constraint(equalTo: actionsStack.topAnchor, constant: -14),

            durationLabel.trailingAnchor.constraint(equalTo: overlayView.safeAreaLayoutGuide.trailingAnchor, constant: -22),
            durationLabel.centerYAnchor.constraint(equalTo: currentPosLabel.centerYAnchor),

            seekSlider.leadingAnchor.constraint(equalTo: currentPosLabel.trailingAnchor, constant: 12),
            seekSlider.trailingAnchor.constraint(equalTo: durationLabel.leadingAnchor, constant: -12),
            seekSlider.centerYAnchor.constraint(equalTo: currentPosLabel.centerYAnchor),

            subtitleLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            subtitleLabel.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -62),
            subtitleLabel.widthAnchor.constraint(lessThanOrEqualTo: view.widthAnchor, multiplier: 0.85),

            statusToastLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            statusToastLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
            statusToastLabel.heightAnchor.constraint(equalToConstant: 30),
            statusToastLabel.widthAnchor.constraint(greaterThanOrEqualToConstant: 160)
        ])
    }

    private func setupSeekBadges() {
        for (badge, isLeft) in [(leftSeekBadge, true), (rightSeekBadge, false)] {
            badge.translatesAutoresizingMaskIntoConstraints = false
            badge.textColor = .white
            badge.font = .boldSystemFont(ofSize: 17)
            badge.textAlignment = .center
            badge.backgroundColor = UIColor.black.withAlphaComponent(0.55)
            badge.layer.cornerRadius = 20
            badge.layer.masksToBounds = true
            badge.isHidden = true
            view.addSubview(badge)
            NSLayoutConstraint.activate([
                badge.centerYAnchor.constraint(equalTo: view.centerYAnchor),
                badge.widthAnchor.constraint(equalToConstant: 105),
                badge.heightAnchor.constraint(equalToConstant: 42),
                isLeft
                    ? badge.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 60)
                    : badge.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -60)
            ])
        }
    }

    private func setupGestureHuds() {
        func configureHud(container: UIView, track: UIView, fill: UIView, label: UILabel, iconName: String, fillColor: UIColor, isLeft: Bool) -> NSLayoutConstraint {
            container.translatesAutoresizingMaskIntoConstraints = false
            container.isHidden = true
            view.addSubview(container)

            let icon = UIImageView(image: UIImage(systemName: iconName))
            icon.translatesAutoresizingMaskIntoConstraints = false
            icon.tintColor = .white
            icon.contentMode = .scaleAspectFit

            track.translatesAutoresizingMaskIntoConstraints = false
            track.backgroundColor = UIColor.white.withAlphaComponent(0.32)
            track.layer.cornerRadius = 3
            track.clipsToBounds = true

            fill.translatesAutoresizingMaskIntoConstraints = false
            fill.backgroundColor = fillColor
            fill.layer.cornerRadius = 3
            track.addSubview(fill)

            label.translatesAutoresizingMaskIntoConstraints = false
            label.textColor = .white
            label.font = .boldSystemFont(ofSize: 11)
            label.textAlignment = .center

            container.addSubview(icon)
            container.addSubview(track)
            container.addSubview(label)

            let heightConstraint = fill.heightAnchor.constraint(equalToConstant: 64)
            NSLayoutConstraint.activate([
                container.centerYAnchor.constraint(equalTo: view.centerYAnchor),
                container.widthAnchor.constraint(equalToConstant: 42),
                container.heightAnchor.constraint(equalToConstant: 180),
                isLeft
                    ? container.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 22)
                    : container.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -22),

                icon.topAnchor.constraint(equalTo: container.topAnchor),
                icon.centerXAnchor.constraint(equalTo: container.centerXAnchor),
                icon.widthAnchor.constraint(equalToConstant: 20),
                icon.heightAnchor.constraint(equalToConstant: 20),

                label.bottomAnchor.constraint(equalTo: container.bottomAnchor),
                label.centerXAnchor.constraint(equalTo: container.centerXAnchor),

                track.topAnchor.constraint(equalTo: icon.bottomAnchor, constant: 8),
                track.bottomAnchor.constraint(equalTo: label.topAnchor, constant: -8),
                track.centerXAnchor.constraint(equalTo: container.centerXAnchor),
                track.widthAnchor.constraint(equalToConstant: 6),

                fill.leadingAnchor.constraint(equalTo: track.leadingAnchor),
                fill.trailingAnchor.constraint(equalTo: track.trailingAnchor),
                fill.bottomAnchor.constraint(equalTo: track.bottomAnchor),
                heightConstraint
            ])
            return heightConstraint
        }

        brightnessFillHeightConstraint = configureHud(
            container: brightnessHudView,
            track: brightnessTrackView,
            fill: brightnessFillView,
            label: brightnessPctLabel,
            iconName: "sun.max.fill",
            fillColor: UIColor(red: 250/255, green: 204/255, blue: 21/255, alpha: 1),
            isLeft: true
        )
        volumeFillHeightConstraint = configureHud(
            container: volumeHudView,
            track: volumeTrackView,
            fill: volumeFillView,
            label: volumePctLabel,
            iconName: "speaker.wave.2.fill",
            fillColor: UIColor(red: 229/255, green: 9/255, blue: 20/255, alpha: 1),
            isLeft: false
        )
    }

    private func setupResolverWebView() {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = WKWebsiteDataStore.default()
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.preferences.javaScriptCanOpenWindowsAutomatically = false
        let ucc = WKUserContentController()
        ucc.add(self, name: "PlayerSniffer")
        let snifferJs = """
        (function(){
          var hn = (location.hostname || '').toLowerCase();
          if (/cloudflare\\.com|recaptcha\\.net|hcaptcha\\.com|arkoselabs\\.com|geetest\\.com/.test(hn) || (hn.indexOf('google.com') !== -1 && location.pathname.indexOf('/recaptcha') !== -1)) {
            try { window.webkit.messageHandlers.PlayerSniffer.postMessage({ kind: 'challenge', url: location.href }); } catch(e) {}
            return;
          }
          window.__sUserPlayed = false;
          window.__sPendingStream = null;
          window.__sPendingInline = null;
          function postAd(u) {
            try { window.webkit.messageHandlers.PlayerSniffer.postMessage({ kind: 'ad_blocked', url: u || location.href }); } catch(e) {}
          }
          function flushPendingStream() {
            if (!window.__sUserPlayed) return;
            if (window.__sPendingInline) {
              try { window.webkit.messageHandlers.PlayerSniffer.postMessage(window.__sPendingInline); } catch(e) {}
              window.__sPendingInline = null;
              return;
            }
            if (window.__sPendingStream) {
              try { window.webkit.messageHandlers.PlayerSniffer.postMessage(window.__sPendingStream); } catch(e) {}
              window.__sPendingStream = null;
            }
          }
          function isInnerPlayerReady() {
            if (window !== window.top) return true;
            if (document.querySelector('[class*="server"], .servers')) return true;
            var vids = document.querySelectorAll('video');
            for (var i = 0; i < vids.length; i++) {
              if (isFinite(vids[i].duration) && vids[i].duration >= 60) return true;
            }
            var bt = (document.body && document.body.innerText || '').toLowerCase();
            return bt.indexOf('servers') !== -1;
          }
          document.addEventListener('click', function(ev) {
            if (!isInnerPlayerReady()) return;
            var hasVideo = !!document.querySelector('video, .jwplayer, .plyr, .video-js');
            if (!hasVideo) return;
            var t = ev && ev.target;
            var txt = (t && (t.innerText || t.textContent) || '').trim().toLowerCase();
            if (txt.indexOf('server') !== -1 || txt.indexOf('verify') !== -1 || txt.indexOf('robot') !== -1) {
              window.__sUserPlayed = false;
              window.__sPendingStream = null;
              window.__sPendingInline = null;
              return;
            }
            window.__sUserPlayed = true;
            setTimeout(flushPendingStream, 120);
          }, true);
          try {
            var origPlay = HTMLMediaElement.prototype.play;
            HTMLMediaElement.prototype.play = function() {
              var isAd = (this.videoHeight > 0 && this.videoWidth > 0 && this.videoHeight > this.videoWidth * 0.95) || (isFinite(this.duration) && this.duration > 0 && this.duration < 60);
              if (!isAd && isInnerPlayerReady()) {
                window.__sUserPlayed = true;
                if (this.currentSrc) post(this.currentSrc, false, isFinite(this.duration) && this.duration >= 60);
                else if (this.src) post(this.src, false, isFinite(this.duration) && this.duration >= 60);
                flushPendingStream();
              }
              return origPlay.apply(this, arguments);
            };
          } catch(e) {}
          try {
            window.open = function(u) { postAd(u || location.href); return null; };
          } catch(e) {}

          function post(u, isHlsHint, forceVideo) {
            if (!u || typeof u !== 'string') return;
            if (u.indexOf('blob:') === 0 || u.indexOf('data:') === 0) return;
            try { u = new URL(u, location.href).href; } catch(e) {}
            if (u.indexOf('http') !== 0) return;
            var l = u.toLowerCase();
            if ((l.indexOf('.ts') !== -1 || l.indexOf('.m4s') !== -1) && l.indexOf('.m3u8') === -1) return;
            if (l.indexOf('.vtt') !== -1 || l.indexOf('.srt') !== -1) {
              try { window.webkit.messageHandlers.PlayerSniffer.postMessage({ kind: 'sub', url: u, ref: location.href }); } catch(e) {}
              return;
            }
            if (/vast|vmap|preroll|doubleclick|exoclick|exosrv|juicyads|trafficjunky|popads|popcash|adsterra|propellerads|monetag|tsyndicate|realsrv|magsrv|hilltopads|admaven|clickadu|galaksion|ero-advertising/i.test(l)) {
              postAd(u);
              return;
            }
            var hlsMatch = !!isHlsHint || l.indexOf('.m3u8') !== -1 || l.indexOf('master.txt') !== -1 || l.indexOf('playlist.txt') !== -1 || l.indexOf('/hls/') !== -1 || l.indexOf('/hls2/') !== -1 || l.indexOf('type=hls') !== -1;
            var videoMatch = !!forceVideo || hlsMatch || l.indexOf('.mpd') !== -1 || l.indexOf('.webm') !== -1 || l.indexOf('.mkv') !== -1 || l.indexOf('videoplayback') !== -1 || l.indexOf('googleusercontent.com') !== -1 || (l.indexOf('.mp4') !== -1 && l.indexOf('preview') === -1 && l.indexOf('trailer') === -1) || l.indexOf('mime=video') !== -1;
            if (videoMatch) {
              var hint = (document.title || '') + ' ' + location.href;
              var payload = { kind: 'stream', url: u, ref: location.href, hint: hint, isHls: hlsMatch };
              if (window.__sUserPlayed) {
                try { window.webkit.messageHandlers.PlayerSniffer.postMessage(payload); } catch(e) {}
              } else {
                window.__sPendingStream = payload;
              }
            }
          }
          if (window.URL && URL.createObjectURL) {
            var oCreateObj = URL.createObjectURL;
            URL.createObjectURL = function(obj) {
              try {
                if (obj && typeof obj.size === 'number' && obj.size > 16 && obj.size < 512000 && typeof obj.text === 'function') {
                  obj.text().then(function(txt) {
                    if (txt && txt.replace(String.fromCharCode(0xFEFF), '').trim().indexOf('#EXTM3U') === 0) {
                      var payload = { kind: 'm3u8_inline', url: location.href, m3u8: txt, ref: location.href, hint: (document.title || '') + ' ' + location.href };
                      if (window.__sUserPlayed) {
                        window.webkit.messageHandlers.PlayerSniffer.postMessage(payload);
                      } else {
                        window.__sPendingInline = payload;
                      }
                    }
                  }).catch(function(){});
                }
              } catch(e) {}
              return oCreateObj.apply(this, arguments);
            };
          }
          if (window.fetch) {
            var of = window.fetch;
            window.fetch = function(i) {
              var u = typeof i === 'string' ? i : (i && i.url);
              try { post(u, false, false); } catch(e) {}
              return of.apply(this, arguments).then(function(res) {
                try {
                  var ct = (res && res.headers && res.headers.get('content-type') || '').toLowerCase();
                  var ru = (res && res.url) || u;
                  var isH = ct.indexOf('mpegurl') !== -1;
                  if (isH || ct.indexOf('video/mp4') !== -1 || ct.indexOf('video/webm') !== -1 || ct.indexOf('dash+xml') !== -1) {
                    if (ru && typeof ru === 'string' && ru.indexOf('http') === 0) {
                      post(ru, isH, true);
                    }
                  } else if (ru && typeof ru === 'string' && ru.indexOf('http') === 0 && !/\\.(css|svg|woff2?|ico)(\\?|$)/i.test(ru)) {
                    res.clone().text().then(function(txt) {
                      if (txt && txt.slice(0, 64).replace(String.fromCharCode(0xFEFF), '').trim().indexOf('#EXTM3U') === 0) {
                        post(ru, true, true);
                      }
                    }).catch(function(){});
                  }
                } catch(e) {}
                return res;
              });
            };
          }
          if (window.XMLHttpRequest) {
            var oo = XMLHttpRequest.prototype.open;
            var os = XMLHttpRequest.prototype.send;
            XMLHttpRequest.prototype.open = function(m, u) {
              this._sUrl = u;
              try { post(u, false, false); } catch(e) {}
              return oo.apply(this, arguments);
            };
            XMLHttpRequest.prototype.send = function() {
              try {
                this.addEventListener('readystatechange', function() {
                  if (this.readyState === 4 && this.status >= 200 && this.status < 400) {
                    try {
                      var ct = (this.getResponseHeader('content-type') || '').toLowerCase();
                      var ru = this.responseURL || this._sUrl;
                      var isH = ct.indexOf('mpegurl') !== -1;
                      var bodyHls = false;
                      if (!isH && (this.responseType === '' || this.responseType === 'text') && typeof this.responseText === 'string') {
                        var head = this.responseText.slice(0, 64).trim();
                        if (head.indexOf('#EXTM3U') === 0) bodyHls = true;
                      } else if (!isH && this.responseType === 'arraybuffer' && this.response && this.response.byteLength >= 7) {
                        var arr = new Uint8Array(this.response, 0, Math.min(32, this.response.byteLength));
                        var s = '';
                        for (var k = 0; k < arr.length; k++) s += String.fromCharCode(arr[k]);
                        if (s.trim().indexOf('#EXTM3U') === 0) bodyHls = true;
                      } else if (!isH && this.responseType === 'blob' && this.response && this.response.size < 512000 && typeof this.response.text === 'function') {
                        this.response.text().then(function(bt) {
                          if (bt && bt.slice(0, 64).trim().indexOf('#EXTM3U') === 0 && ru && ru.indexOf('http') === 0) {
                            post(ru, true, true);
                          }
                        }).catch(function(){});
                      }
                      if (isH || bodyHls || ct.indexOf('video/mp4') !== -1 || ct.indexOf('video/webm') !== -1 || ct.indexOf('dash+xml') !== -1) {
                        if (ru && typeof ru === 'string' && ru.indexOf('http') === 0) {
                          post(ru, isH || bodyHls, true);
                        }
                      }
                    } catch(e) {}
                  }
                });
              } catch(e) {}
              return os.apply(this, arguments);
            };
          }
          try {
            var desc = Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, 'src');
            if (desc && desc.set) {
              var origSet = desc.set;
              Object.defineProperty(HTMLMediaElement.prototype, 'src', {
                set: function(v) { try { post(v, false, false); } catch(e) {} return origSet.call(this, v); },
                get: desc.get,
                configurable: true
              });
            }
            var origSetAttr = Element.prototype.setAttribute;
            Element.prototype.setAttribute = function(k, v) {
              if ((k === 'src' || k === 'SRC') && (this.tagName === 'VIDEO' || this.tagName === 'SOURCE')) {
                try { post(v, false, false); } catch(e) {}
              }
              return origSetAttr.apply(this, arguments);
            };
          } catch(e) {}
          try {
            new PerformanceObserver(function(list){ list.getEntries().forEach(function(e){ post(e.name, false, false); }); }).observe({ entryTypes: ['resource'] });
          } catch(e) {}
          function scanAndClick() {
            try {
              var txt = ((document.title || '') + ' ' + (document.body ? document.body.innerText.slice(0, 500) : '')).toLowerCase();
              if (txt.indexOf('no sources') !== -1 || txt.indexOf('404 not found') !== -1 || txt.indexOf('502 bad gateway') !== -1 || txt.indexOf('media not found') !== -1 || txt.indexOf('video not found') !== -1) {
                window.webkit.messageHandlers.PlayerSniffer.postMessage({ kind: 'dead', url: location.href });
                return;
              }
              var hasWidget = !!document.querySelector('iframe[src*="challenges.cloudflare.com"], iframe[src*="turnstile"], iframe[src*="challenge"], iframe[src*="captcha"], iframe[src*="recaptcha"], iframe[src*="hcaptcha"], .cf-turnstile, .g-recaptcha, .h-captcha, #cf-turnstile-response, #cf-challenge-running, [id*="turnstile"], [class*="turnstile"], [class*="geetest"]');
              if (hasWidget || txt.indexOf('just a moment') !== -1 || txt.indexOf('verify you are human') !== -1 || txt.indexOf('security check') !== -1 || txt.indexOf('are you a robot') !== -1) {
                window.webkit.messageHandlers.PlayerSniffer.postMessage({ kind: 'challenge', url: location.href });
                return;
              }
              document.querySelectorAll('button, div, span, a').forEach(function(el) {
                var t = (el.innerText || '').trim().toLowerCase();
                if (t === 'skip ad' || t === 'skip ads') {
                  postAd(location.href);
                  try { el.click(); } catch(e) {}
                }
              });
              if (typeof window.jwplayer === 'function') {
                try {
                  var jw = window.jwplayer();
                  var item = jw && jw.getPlaylistItem && jw.getPlaylistItem();
                  if (item) {
                    if (item.file) post(item.file, item.file.indexOf('.m3u8') !== -1 || item.type === 'hls', true);
                    if (Array.isArray(item.sources)) {
                      item.sources.forEach(function(s) {
                        if (s && s.file) post(s.file, s.file.indexOf('.m3u8') !== -1 || s.type === 'hls', true);
                      });
                    }
                  }
                } catch(e) {}
              }
              try {
                var srvList = [];
                var seenSrv = {};
                var cands = document.querySelectorAll('.servers li, .servers a, .servers button, .servers div, [class*="server"] li, [class*="server"] a, [class*="server"] button, [class*="server"] div, [data-server], [data-id], [data-hash]');
                var sIdx = 0;
                cands.forEach(function(el) {
                  var label = (el.innerText || el.textContent || '').replace(/\\s+/g, ' ').trim();
                  if (!label || label.length > 60 || /^servers?$/i.test(label) || /go to website/i.test(label)) return;
                  if (seenSrv[label]) return;
                  seenSrv[label] = 1;
                  var key = 's' + (sIdx++);
                  el.setAttribute('data-s-idx', key);
                  srvList.push({ name: label, idx: key });
                });
                if (srvList.length > 0) {
                  window.webkit.messageHandlers.PlayerSniffer.postMessage({ kind: 'servers_list', url: location.href, servers: srvList });
                }
              } catch(e) {}
              document.querySelectorAll('video').forEach(function(v) {
                v.setAttribute('playsinline', '');
                v.setAttribute('webkit-playsinline', '');
                var isPortraitAd = v.videoHeight > 0 && v.videoWidth > 0 && v.videoHeight > v.videoWidth * 0.95;
                var isShortAd = isFinite(v.duration) && v.duration > 0 && v.duration < 60;
                if (isPortraitAd || isShortAd) {
                  v.muted = true;
                  try {
                    v.style.display = 'none';
                    v.style.opacity = '0';
                    if (isFinite(v.duration) && v.duration > 1 && v.currentTime < v.duration - 0.2) {
                      v.currentTime = v.duration - 0.05;
                    }
                    document.querySelectorAll('div, a, button').forEach(function(el) {
                      var tx = (el.innerText || '').trim().toLowerCase();
                      if (tx === 'go to website' || tx.indexOf('install ') === 0 || tx === 'skip ad' || tx === 'skip ads') {
                        if (tx.indexOf('skip') === 0) { try { el.click(); } catch(e) {} }
                        else { try { el.style.display = 'none'; } catch(e) {} }
                      }
                    });
                  } catch(e) {}
                  postAd(v.currentSrc || v.src || location.href);
                  return;
                }
                if (!v.paused && v.currentTime > 0 && isInnerPlayerReady()) {
                  window.__sUserPlayed = true;
                  try { performance.getEntriesByType('resource').forEach(function(e) { post(e.name, false, false); }); } catch(e) {}
                  flushPendingStream();
                }
                var isFeature = isFinite(v.duration) && v.duration >= 60;
                if (v.src) post(v.src, false, isFeature);
                if (v.currentSrc) post(v.currentSrc, false, isFeature);
                v.querySelectorAll('source').forEach(function(s) {
                  if (s.src) post(s.src, false, isFeature);
                });
              });
            } catch(e) {}
          }
          setTimeout(scanAndClick, 600);
          setInterval(scanAndClick, 450);
        })();
        """
        ucc.addUserScript(WKUserScript(source: snifferJs, injectionTime: .atDocumentStart, forMainFrameOnly: false))
        config.userContentController = ucc

        let wv = WKWebView(frame: CGRect(x: 0, y: 0, width: 360, height: 250), configuration: config)
        wv.alpha = 0.01
        wv.isUserInteractionEnabled = false
                wv.navigationDelegate = self
        wv.uiDelegate = self
        wv.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"
        let adRulesJson = "[{\"trigger\": {\"url-filter\": \".*\", \"if-domain\": [\"*google-analytics.com\", \"*googletagmanager.com\", \"*googletagservices.com\", \"*doubleclick.net\", \"*adservice.google.com\", \"*pagead2.googlesyndication.com\", \"*cdn.adx1.com\", \"*intelligenceadx.com\", \"*adsco.re\", \"*mc.yandex.com\", \"*mc.yandex.ru\", \"*bvtpk.com\", \"*my.rtmark.net\", \"*b7510.com\", \"*gt.unbrownunflat.com\", \"*im.malocacomals.com\", \"*nf.sixmossin.com\", \"*realizationnewestfangs.com\", \"*acscdn.com\", \"*lt.taloseempest.com\", \"*pl26708123.profitableratecpm.com\", \"*preferencenail.com\", \"*protrafficinspector.com\", \"*s10.histats.com\", \"*weirdopt.com\", \"*cloudflareinsights.com\", \"*kettledroopingcontinuation.com\", \"*wayfarerorthodox.com\", \"*woxaglasuy.net\", \"*adeptspiritual.com\", \"*calculating-laugh.com\", \"*amavhxdlofklxjg.xyz\", \"*usrpubtrk.com\", \"*adexchangeclear.com\", \"*rzjzjnavztycv.online\", \"*hameltnoummos.com\", \"*ancillammmm.com\", \"*hubeamily.com\", \"*llvpn.com\", \"*gillyspencie.com\", \"*soakysecrets.com\", \"*mdstats.info\", \"*ads-twitter.com\", \"*connatix.com\", \"*imasdk.googleapis.com\", \"*jwpltx.com\", \"*openfpcdn.io\", \"*phruk.org\", \"*welcomingexpulsion.com\", \"*pgo99.com\", \"*todditehexarch.com\", \"*uniolaicecaps.com\", \"*alloha.tv\", \"*pc.alloviewroll.com\", \"*yadro.ru\", \"*getaim.org\", \"*myangular.life\", \"*rstprgapipt.com\", \"*veselchaga.link\", \"*webvisor.org\", \"*datariaarpent.com\", \"*gamesrevenue.com\", \"*mgid.com\", \"*pushaffiliate.net\", \"*imp-mintads.site\", \"*xadsmart.com\", \"*tsyndicate.com\", \"*rapidadexchange.com\", \"*pxltag.com\", \"*runative-syndicate.com\", \"*cdn4ads.com\", \"*popads.net\", \"*popcash.net\", \"*exoclick.com\", \"*juicyads.com\", \"*propellerads.com\", \"*monetag.com\", \"*adsterra.com\", \"*highperformanceformat.com\", \"*effectivegatecpm.com\", \"*onclickalgo.com\", \"*realsrv.com\", \"*hilltopads.net\", \"*admaven.com\", \"*ad-maven.com\", \"*clickadu.com\", \"*galaksion.com\", \"*onclkds.com\", \"*betteradsystem.com\", \"*a-ads.com\", \"*bidvertiser.com\", \"*richpush.co\", \"*2mdn.net\", \"*outbrain.com\", \"*taboola.com\", \"*exosrv.com\", \"*magsrv.com\", \"*ero-advertising.com\", \"*chaturbate.com\", \"*stripchat.com\", \"*bongacams.com\", \"*livejasmin.com\", \"*cam4.com\", \"*trafficjunky.com\", \"*trafficjunky.net\", \"*juicyads.net\", \"*tsyndicate.net\", \"*adskeeper.com\", \"*mgid.com\", \"*profitablecpmrate.com\", \"*highrevenuegate.com\"]}, \"action\": {\"type\": \"block\"}}]"
        WKContentRuleListStore.default().compileContentRuleList(forIdentifier: "SingularityAdBlock", encodedContentRuleList: adRulesJson) { [weak self] list, _ in
            if let list = list {
                DispatchQueue.main.async {
                    self?.adRuleList = list
                    wv.configuration.userContentController.add(list)
                }
            }
        }
        view.insertSubview(wv, at: 0)
        resolverWebView = wv
    }

    func webView(
        _ webView: WKWebView,
        createWebViewWith configuration: WKWebViewConfiguration,
        for navigationAction: WKNavigationAction,
        windowFeatures: WKWindowFeatures
    ) -> WKWebView? {
        return nil
    }

    func webView(
        _ webView: WKWebView,
        decidePolicyFor navigationAction: WKNavigationAction,
        decisionHandler: @escaping (WKNavigationActionPolicy) -> Void
    ) {
        if let u = navigationAction.request.url?.absoluteString.lowercased() {
            if webView === resolverWebView {
                let isCh = u.contains("challenges.cloudflare.com") || u.contains("turnstile/v0/api") || u.contains("recaptcha/api") || u.contains("hcaptcha.com/1/api") || u.contains("arkoselabs.com") || u.contains("geetest.com")
                if isCh && isSwitchingServer && !isCaptchaVisible {
                    DispatchQueue.main.async { [weak self] in
                        guard let self = self else { return }
                        let targetSrc = self.pendingNextSource.isEmpty ? self.currentSource : self.pendingNextSource
                        self.failoverTimer?.invalidate()
                        self.showCaptchaCard(for: targetSrc)
                    }
                }
            }
            let blockedHosts = ["google-analytics.com", "googletagmanager.com", "googletagservices.com", "doubleclick.net", "adservice.google.com", "pagead2.googlesyndication.com", "cdn.adx1.com", "intelligenceadx.com", "adsco.re", "mc.yandex.com", "mc.yandex.ru", "bvtpk.com", "my.rtmark.net", "b7510.com", "gt.unbrownunflat.com", "im.malocacomals.com", "nf.sixmossin.com", "realizationnewestfangs.com", "acscdn.com", "lt.taloseempest.com", "pl26708123.profitableratecpm.com", "preferencenail.com", "protrafficinspector.com", "s10.histats.com", "weirdopt.com", "tsyndicate.com", "mgid.com", "cdn4ads.com", "pxltag.com", "runative-syndicate.com", "rapidadexchange.com", "popads.net", "popcash.net", "exoclick.com", "juicyads.com", "propellerads.com", "monetag.com", "adsterra.com", "highperformanceformat.com", "effectivegatecpm.com", "onclickalgo.com", "realsrv.com", "hilltopads.net", "admaven.com", "ad-maven.com", "clickadu.com", "galaksion.com", "onclkds.com", "betteradsystem.com", "a-ads.com", "bidvertiser.com", "richpush.co", "2mdn.net", "outbrain.com", "taboola.com", "exosrv.com", "magsrv.com", "ero-advertising.com", "chaturbate.com", "stripchat.com", "bongacams.com", "livejasmin.com", "cam4.com", "trafficjunky.com", "trafficjunky.net", "juicyads.net", "tsyndicate.net", "adskeeper.com", "mgid.com", "profitablecpmrate.com", "highrevenuegate.com"]
            let isAdPath = u.contains("/vast") || u.contains("vmap") || u.contains("preroll") || u.contains("popunder")
            if isAdPath || blockedHosts.contains(where: { u.contains($0) }) {
                let prev = UserDefaults.standard.integer(forKey: "sb_blocked_total")
                UserDefaults.standard.set(prev + 1, forKey: "sb_blocked_total")
                onBlockedAd?(u)
                decisionHandler(.cancel)
                return
            }
        }
        decisionHandler(.allow)
    }

    private func parsePayloadAndPlay() {
        guard let data = payloadJson.data(using: .utf8),
              let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            dismiss(animated: true)
            return
        }
        streamUrl = obj["url"] as? String ?? ""
        streamTitle = obj["title"] as? String ?? "SingularityTV"
        progressKey = obj["progressKey"] as? String ?? ""
        startTimeSec = (obj["startTimeSec"] as? NSNumber)?.doubleValue ?? 0
        imdbId = obj["imdbId"] as? String ?? ""
        tmdbId = obj["tmdbId"] as? String ?? ""
        resolveTmdbIdIfNeeded()
        mediaType = obj["mediaType"] as? String ?? "movie"
        seasonNum = (obj["season"] as? NSNumber)?.intValue ?? 1
        episodeNum = (obj["episode"] as? NSNumber)?.intValue ?? 1
        seriesTitle = obj["seriesTitle"] as? String ?? streamTitle.components(separatedBy: " · S").first ?? streamTitle
        totalEpisodesInSeason = (obj["totalEpisodes"] as? NSNumber)?.intValue ?? 0
        preferredLang = (obj["preferredSubLang"] as? String ?? "ar").lowercased()
        currentSource = "multiembed"
        activeReferer = obj["referer"] as? String ?? buildReferer(for: currentSource)

        titleLabel.text = streamTitle
        updateServerBadge(currentSource)

        if let subs = obj["subtitles"] as? [[String: Any]] {
            for s in subs {
                let u = (s["url"] as? String) ?? (s["path"] as? String) ?? ""
                if u.isEmpty { continue }
                let lang = (s["lang"] as? String ?? "en").lowercased()
                let label = (s["label"] as? String) ?? "Stream · \(lang.uppercased())"
                availableSubs.append(IosSubTrack(lang: lang, url: u, score: 100, syncMatch: true))
            }
        }
        subButton.setTitle("Subtitles (\(availableSubs.count))", for: .normal)

        if streamUrl.isEmpty {
            startResolvingInitialSource()
        } else {
            startPlayback(urlString: streamUrl, referer: activeReferer, seekSec: startTimeSec)
        }
        fetchSubtitlesInBackground()
        fetchSkipSegmentsInBackground()
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.4) { [weak self] in
            self?.startBackgroundServerProbing()
        }
        showControllerTemporarily()
    }

    private func showCaptchaCard(for sourceId: String) {
        guard let wv = resolverWebView else { return }
        isCaptchaVisible = true
        failoverTimer?.invalidate()
        if captchaCardView.superview == nil {
            captchaCardView.translatesAutoresizingMaskIntoConstraints = false
            captchaCardView.backgroundColor = UIColor(red: 16/255, green: 20/255, blue: 30/255, alpha: 0.96)
            captchaCardView.layer.cornerRadius = 16
            captchaCardView.layer.borderWidth = 1
            captchaCardView.layer.borderColor = UIColor.white.withAlphaComponent(0.18).cgColor
            captchaCardView.clipsToBounds = true
            view.addSubview(captchaCardView)

            captchaTitleLabel.translatesAutoresizingMaskIntoConstraints = false
            captchaTitleLabel.textColor = .white
            captchaTitleLabel.font = .boldSystemFont(ofSize: 14)

            let skipBtn = UIButton(type: .system)
            skipBtn.translatesAutoresizingMaskIntoConstraints = false
            skipBtn.setImage(UIImage(systemName: "arrow.clockwise"), for: .normal)
            skipBtn.tintColor = .white
            skipBtn.setTitle(" Reload", for: .normal)
            skipBtn.setTitleColor(.white, for: .normal)
            skipBtn.titleLabel?.font = .boldSystemFont(ofSize: 12)
            skipBtn.backgroundColor = UIColor.white.withAlphaComponent(0.14)
            skipBtn.layer.cornerRadius = 11
            skipBtn.contentEdgeInsets = UIEdgeInsets(top: 4, left: 10, bottom: 4, right: 10)
            skipBtn.addTarget(self, action: #selector(skipCaptchaServer), for: .touchUpInside)

            captchaCardView.addSubview(captchaTitleLabel)
            captchaCardView.addSubview(skipBtn)

            NSLayoutConstraint.activate([
                captchaCardView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
                captchaCardView.centerYAnchor.constraint(equalTo: view.centerYAnchor),
                captchaCardView.widthAnchor.constraint(lessThanOrEqualTo: view.widthAnchor, constant: -24),
                captchaCardView.heightAnchor.constraint(lessThanOrEqualTo: view.heightAnchor, constant: -36),
                { let c = captchaCardView.widthAnchor.constraint(equalToConstant: 360); c.priority = .defaultHigh; return c }(),
                { let c = captchaCardView.heightAnchor.constraint(equalToConstant: 290); c.priority = .defaultHigh; return c }(),

                captchaTitleLabel.topAnchor.constraint(equalTo: captchaCardView.topAnchor, constant: 12),
                captchaTitleLabel.leadingAnchor.constraint(equalTo: captchaCardView.leadingAnchor, constant: 14),
                skipBtn.centerYAnchor.constraint(equalTo: captchaTitleLabel.centerYAnchor),
                skipBtn.trailingAnchor.constraint(equalTo: captchaCardView.trailingAnchor, constant: -12)
            ])
        }
        captchaTitleLabel.text = "\(serverDisplayName(sourceId)) · Verify & Play"
        wv.removeFromSuperview()
        wv.translatesAutoresizingMaskIntoConstraints = false
        wv.alpha = 1.0
        wv.isUserInteractionEnabled = true
        captchaCardView.addSubview(wv)
        NSLayoutConstraint.activate([
            wv.topAnchor.constraint(equalTo: captchaTitleLabel.bottomAnchor, constant: 10),
            wv.leadingAnchor.constraint(equalTo: captchaCardView.leadingAnchor),
            wv.trailingAnchor.constraint(equalTo: captchaCardView.trailingAnchor),
            wv.bottomAnchor.constraint(equalTo: captchaCardView.bottomAnchor)
        ])
        captchaCardView.isHidden = false
        view.bringSubviewToFront(captchaCardView)
        wv.evaluateJavaScript("try{window.dispatchEvent(new Event('resize'));}catch(e){}", completionHandler: nil)
    }

    @objc private func skipCaptchaServer() {
        failoverTimer?.invalidate()
        failedStreamUrls.removeAll()
        streamUrl = ""
        currentSource = "multiembed"
        pendingNextSource = "multiembed"
        isSwitchingServer = true
        let embed = buildEmbedUrl(for: "multiembed")
        if !embed.isEmpty, let u = URL(string: embed) {
            resolverWebView?.stopLoading()
            loadMultiEmbedUrl(u)
        }
        showToast("Reloading MultiEmbed...")
    }

    private func hideCaptchaCard() {
        if !isCaptchaVisible { return }
        isCaptchaVisible = false
        if let list = adRuleList { resolverWebView?.configuration.userContentController.add(list) }
        captchaCardView.isHidden = true
        if let wv = resolverWebView {
            wv.removeFromSuperview()
            wv.translatesAutoresizingMaskIntoConstraints = true
            wv.frame = CGRect(x: 0, y: 0, width: 360, height: 250)
            wv.alpha = 0.01
            wv.isUserInteractionEnabled = false
            view.insertSubview(wv, at: 0)
        }
    }

    private func serverStatusKey(_ sourceId: String) -> String {
        let pk = progressKey.isEmpty ? (imdbId.isEmpty ? streamTitle : imdbId) : progressKey
        return "srv_status_\(pk)_\(sourceId)"
    }

    private func recordServerStatus(_ sourceId: String, status: String) {
        guard !sourceId.isEmpty else { return }
        UserDefaults.standard.set(status, forKey: serverStatusKey(sourceId))
        UserDefaults.standard.set(serverCatalogVersion, forKey: serverStatusKey(sourceId) + "_ver")
    }

    private func getServerStatus(_ sourceId: String) -> String {
        let st = UserDefaults.standard.string(forKey: serverStatusKey(sourceId)) ?? "unknown"
        let ver = UserDefaults.standard.string(forKey: serverStatusKey(sourceId) + "_ver") ?? ""
        if st == "working" { return "working" }
        if st == "failed" {
            if ver != serverCatalogVersion {
                return recentlyUpdatedSources.contains(sourceId) ? "updated" : "unknown"
            }
            return "failed"
        }
        if recentlyUpdatedSources.contains(sourceId) { return "updated" }
        return "unknown"
    }

    private func loadMultiEmbedUrl(_ u: URL) {
        var r = URLRequest(url: u)
        r.setValue("https://multiembed.mov/", forHTTPHeaderField: "Referer")
        resolverWebView?.load(r)
    }

    private func startResolvingInitialSource() {
        currentSource = "multiembed"
        isSwitchingServer = true
        failoverAttempts = 0
        pendingNextSource = "multiembed"
        updateServerBadge("multiembed")
        showToast("Connecting to MultiEmbed...")
        let embed = buildEmbedUrl(for: "multiembed")
        if !embed.isEmpty, let u = URL(string: embed) {
            loadMultiEmbedUrl(u)
        }
        failoverTimer?.invalidate()
        failoverTimer = Timer.scheduledTimer(withTimeInterval: 2.5, repeats: false) { [weak self] _ in
            guard let self = self, self.isSwitchingServer, !self.isCaptchaVisible else { return }
            self.showCaptchaCard(for: "multiembed")
        }
    }

    private func serverDisplayName(_ id: String) -> String {
        switch id.lowercased() {
        case "singularity": return "Singularity"
        case "vidsrcmeru": return "VidSrc.ru"
        case "vidsrcto": return "VidSrc.to"
        case "vidlink": return "VidLink"
        case "videasy": return "VidEasy"
        case "vidsrccc": return "VidSrc.cc"
        case "vidsrcxyz": return "VidSrc.xyz"
        case "vidsrcme": return "VidSrc.me"
        case "vidsrcnet": return "VidSrc Pro"
        case "vidsrcin": return "VidSrc.in"
        case "vidsrcpm": return "VidSrc.pm"
        case "vidsrc": return "VidSrc"
        case "vidsrcicu": return "VidSrc.icu"
        case "vidfast": return "VidFast"
        case "vidnest": return "VidNest"
        case "vidlove": return "VidLove"
        case "autoembed": return "AutoEmbed"
        case "embedsu": return "Embed.su"
        case "smashy": return "Smashy"
        case "multiembed": return "MultiEmbed"
        case "superembed": return "SuperEmbed"
        case "rivestream": return "RiveStream"
        case "moviesapi": return "MoviesAPI"
        case "nontongo": return "NontonGo"
        default: return id.capitalized
        }
    }

    private func updateServerBadge(_ sourceId: String) {
        let name = serverDisplayName(sourceId)
        serverBadgeButton.setTitle("\(name)", for: .normal)
    }

    private func buildReferer(for sourceId: String) -> String {
        switch sourceId {
        case "singularity": return "https://proxy.garageband.rocks/"
        case "vidsrcmeru": return "https://vidsrcme.ru/"
        case "vidsrcto": return "https://vidsrc.to/"
        case "vidlink": return "https://vidlink.pro/"
        case "videasy": return "https://player.videasy.net/"
        case "vidsrccc": return "https://vidsrc.cc/"
        case "vidsrcxyz": return "https://vidsrc.xyz/"
        case "vidsrcme": return "https://vidsrc.me/"
        default: return "https://vidlink.pro/"
        }
    }

    private func resolveTmdbIdIfNeeded() {
        if !tmdbId.isEmpty || !imdbId.hasPrefix("tt") { return }
        let isTv = mediaType.lowercased() == "tv"
        let prop = isTv ? "P4983" : "P4947"
        let sparql = "SELECT ?tid WHERE { ?item wdt:P345 \"\(imdbId)\" . ?item wdt:\(prop) ?tid . } LIMIT 1"
        guard let q = sparql.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
              let u = URL(string: "https://query.wikidata.org/sparql?format=json&query=\(q)") else { return }
        var req = URLRequest(url: u)
        req.setValue("application/sparql-results+json", forHTTPHeaderField: "Accept")
        URLSession.shared.dataTask(with: req) { [weak self] data, _, _ in
            guard let self = self, let data = data,
                  let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let results = root["results"] as? [String: Any],
                  let bindings = results["bindings"] as? [[String: Any]],
                  let first = bindings.first,
                  let tidObj = first["tid"] as? [String: Any],
                  let val = tidObj["value"] as? String, !val.isEmpty else { return }
            DispatchQueue.main.async {
                self.tmdbId = val
            }
        }.resume()
    }

    private func buildEmbedUrl(for sourceId: String) -> String {
        let im = imdbId
        let tm = tmdbId.isEmpty ? imdbId : tmdbId
        if im.isEmpty && tm.isEmpty { return "" }
        let isTv = mediaType.lowercased() == "tv"
        let s = max(1, seasonNum)
        let e = max(1, episodeNum)
        switch sourceId {
        case "singularity": return isTv ? "https://proxy.garageband.rocks/embed/tv/\(im)/\(s)/\(e)" : "https://proxy.garageband.rocks/embed/movie/\(im)"
        case "vidsrcmeru": return isTv ? "https://vidsrcme.ru/embed/tv?imdb=\(im)&season=\(s)&episode=\(e)&autoplay=1" : "https://vidsrcme.ru/embed/movie?imdb=\(im)&autoplay=1"
        case "vidsrcto": return isTv ? "https://vidsrc.to/embed/tv/\(im)/\(s)/\(e)" : "https://vidsrc.to/embed/movie/\(im)"
        case "vidlink": return isTv ? "https://vidlink.pro/tv/\(tm)/\(s)/\(e)?autoplay=true" : "https://vidlink.pro/movie/\(tm)?autoplay=true"
        case "videasy": return isTv ? "https://player.videasy.net/tv/\(tm)/\(s)/\(e)" : "https://player.videasy.net/movie/\(tm)"
        case "vidsrccc": return isTv ? "https://vidsrc.cc/v2/embed/tv/\(tm)/\(s)/\(e)?autoPlay=true" : "https://vidsrc.cc/v2/embed/movie/\(tm)?autoPlay=true"
        case "vidsrcxyz": return isTv ? "https://vidsrc.xyz/embed/tv/\(im)/\(s)-\(e)" : "https://vidsrc.xyz/embed/movie/\(im)"
        case "vidsrcnet": return isTv ? "https://vidsrc.net/embed/tv/\(im)/\(s)-\(e)?autoplay=1" : "https://vidsrc.net/embed/movie/\(im)?autoplay=1"
        case "vidsrcin": return isTv ? "https://vidsrc.in/embed/tv/\(im)/\(s)-\(e)" : "https://vidsrc.in/embed/movie/\(im)"
        case "vidsrc": return isTv ? "https://vsembed.su/embed/tv/\(im)/\(s)/\(e)?autoplay=1" : "https://vsembed.su/embed/movie/\(im)?autoplay=1"
        case "vidsrcicu": return isTv ? "https://vidsrc.icu/embed/tv/\(im)/\(s)/\(e)" : "https://vidsrc.icu/embed/movie/\(im)"
        case "vidfast": return isTv ? "https://vidfast.pro/tv/\(tm)/\(s)/\(e)?autoPlay=true" : "https://vidfast.pro/movie/\(tm)?autoPlay=true"
        case "vidnest": return isTv ? "https://vidnest.fun/tv/\(tm)/\(s)/\(e)" : "https://vidnest.fun/movie/\(tm)"
        case "autoembed": return isTv ? "https://player.autoembed.cc/embed/tv/\(tm)/\(s)/\(e)?server=1" : "https://player.autoembed.cc/embed/movie/\(tm)?server=1"
        case "embedsu": return isTv ? "https://embed.su/embed/tv/\(tm)/\(s)/\(e)" : "https://embed.su/embed/movie/\(tm)"
        case "smashy": return isTv ? "https://player.smashy.stream/tv/\(im)?s=\(s)&e=\(e)" : "https://player.smashy.stream/movie/\(im)"
        case "multiembed": return isTv ? "https://multiembed.mov/?video_id=\(im)&s=\(s)&e=\(e)" : "https://multiembed.mov/?video_id=\(im)"
        case "superembed": return isTv ? "https://multiembed.mov/directstream.php?video_id=\(im)&s=\(s)&e=\(e)" : "https://multiembed.mov/directstream.php?video_id=\(im)"
        case "rivestream": return isTv ? "https://rivestream.org/embed?type=tv&id=\(tm)&season=\(s)&episode=\(e)" : "https://rivestream.org/embed?type=movie&id=\(tm)"
        case "moviesapi": return isTv ? "https://moviesapi.club/tv/\(tm)-\(s)-\(e)" : "https://moviesapi.club/movie/\(tm)"
        case "vidsrcpro": return isTv ? "https://vidsrc.pro/embed/tv/\(tm)/\(s)/\(e)" : "https://vidsrc.pro/embed/movie/\(tm)"
        case "vidsrcvip": return isTv ? "https://vidsrc.vip/embed/tv/\(tm)/\(s)/\(e)" : "https://vidsrc.vip/embed/movie/\(tm)"
        case "vidsrcrip": return isTv ? "https://vidsrc.rip/embed/tv/\(tm)/\(s)/\(e)" : "https://vidsrc.rip/embed/movie/\(tm)"
        case "111movies": return isTv ? "https://111movies.com/tv/\(tm)/\(s)/\(e)" : "https://111movies.com/movie/\(tm)"
        case "vidjoy": return isTv ? "https://vidjoy.pro/embed/tv/\(tm)/\(s)/\(e)" : "https://vidjoy.pro/embed/movie/\(tm)"
        case "2embed": return isTv ? "https://www.2embed.cc/embedtv/\(im)&s=\(s)&e=\(e)" : "https://www.2embed.cc/embed/\(im)"
        case "embed2": return isTv ? "https://www.2embed.stream/embed/tv/\(im)/\(s)/\(e)" : "https://www.2embed.stream/embed/movie/\(im)"
        case "nontongo": return isTv ? "https://www.NontonGo.win/embed/tv?id=\(im)&s=\(s)&e=\(e)" : "https://www.NontonGo.win/embed/movie?id=\(im)"
        default: return isTv ? "https://vidsrcme.ru/embed/tv?imdb=\(im)&season=\(s)&episode=\(e)" : "https://vidsrcme.ru/embed/movie?imdb=\(im)"
        }
    }

    private func startPlayback(urlString: String, referer: String, seekSec: Double) {
        failoverTimer?.invalidate()
        guard let url = URL(string: urlString) else { return }
        if let obs = timeObserver {
            player?.removeTimeObserver(obs)
            timeObserver = nil
        }
        itemStatusObserver?.invalidate()
        player?.pause()
        playerLayer?.removeFromSuperlayer()
        var headers: [String: String] = [
            "User-Agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"
        ]
        headers["Accept"] = "*/*"
        if headerRetryStage == 0 && !referer.isEmpty {
            headers["Referer"] = referer
            if let ru = URL(string: referer), let scheme = ru.scheme, let host = ru.host {
                headers["Origin"] = "\(scheme)://\(host)"
            }
        } else if headerRetryStage == 1 && !referer.isEmpty {
            headers["Referer"] = referer
        }
        WKWebsiteDataStore.default().httpCookieStore.getAllCookies { [weak self] cookies in
            guard let self = self else { return }
            let host = url.host?.lowercased() ?? ""
            let matching = cookies.filter { host.hasSuffix($0.domain.trimmingCharacters(in: CharacterSet(charactersIn: ".")).lowercased()) }
            if !matching.isEmpty {
                headers["Cookie"] = matching.map { "\($0.name)=\($0.value)" }.joined(separator: "; ")
            }
            DispatchQueue.main.async {
                self.beginAvAssetPlayback(url: url, headers: headers, seekSec: seekSec)
            }
        }
    }

    private func beginAvAssetPlayback(url: URL, headers: [String: String], seekSec: Double) {
        activeStreamHeaders = headers
        var playUrl = url
        let isInlineHls = url.scheme == "singularity-inline"
        let useCustomHlsLoader = isInlineHls || (streamIsHls && !url.absoluteString.lowercased().contains(".m3u8") && (url.scheme == "https" || url.scheme == "http"))
        if useCustomHlsLoader, var comps = URLComponents(url: url, resolvingAgainstBaseURL: false) {
            comps.scheme = url.scheme == "https" ? "singularity-hlss" : "singularity-hlsp"
            if let cu = comps.url { playUrl = cu }
        }
        let asset = AVURLAsset(url: playUrl, options: ["AVURLAssetHTTPHeaderFieldsKey": headers])
        if useCustomHlsLoader {
            asset.resourceLoader.setDelegate(self, queue: resourceLoaderQueue)
        }
        let item = AVPlayerItem(asset: asset)
        let legibleOut = AVPlayerItemLegibleOutput()
        legibleOut.suppressesPlayerRendering = true
        legibleOut.setDelegate(self, queue: .main)
        item.add(legibleOut)
        let newPlayer = AVPlayer(playerItem: item)
        let layer = AVPlayerLayer(player: newPlayer)
        layer.frame = videoContainer.bounds
        layer.videoGravity = .resizeAspect
        layer.isHidden = true
        videoContainer.layer.addSublayer(layer)

        player = newPlayer
        playerLayer = layer

        if AVPictureInPictureController.isPictureInPictureSupported() {
            pipController = AVPictureInPictureController(playerLayer: layer)
            pipController?.delegate = self
        }

        var didHandleReady = false
        itemStatusObserver = item.observe(\.status, options: [.new]) { [weak self] avItem, _ in
            DispatchQueue.main.async {
                guard let self = self, self.player === newPlayer else { return }
                if avItem.status == .readyToPlay {
                    if didHandleReady { return }
                    didHandleReady = true
                    let dur = CMTimeGetSeconds(avItem.duration)
                    let minValidSec: Double = self.mediaType.lowercased() == "tv" ? 60.0 : 180.0
                    var vSize = avItem.presentationSize
                    if (vSize.width <= 0 || vSize.height <= 0), let tr = avItem.asset.tracks(withMediaType: .video).first {
                        let ns = tr.naturalSize.applying(tr.preferredTransform)
                        vSize = CGSize(width: abs(ns.width), height: abs(ns.height))
                    }
                    let isPortraitAd = vSize.width > 0 && vSize.height > 0 && vSize.height > vSize.width * 0.95
                    if !self.streamUrl.hasPrefix("/") && (isPortraitAd || (dur.isFinite && dur > 0 && dur < minValidSec)) {
                        newPlayer.pause()
                        layer.isHidden = true
                        let prev = UserDefaults.standard.integer(forKey: "sb_blocked_total")
                        UserDefaults.standard.set(prev + 1, forKey: "sb_blocked_total")
                        self.onBlockedAd?(url.absoluteString)
                        self.streamUrl = ""
                        self.isSwitchingServer = true
                        self.showToast("Blocked ad clip")
                        self.showCaptchaCard(for: "multiembed")
                        return
                    }
                    self.headerRetryStage = 0
                    self.hideCaptchaCard()
                    self.resolverWebView?.stopLoading()
                    self.resolverWebView?.loadHTMLString("", baseURL: nil)
                    layer.isHidden = false
                    self.failoverAttempts = 0
                    self.isSwitchingServer = false
                    self.failoverTimer?.invalidate()
                    self.recordServerStatus(self.currentSource, status: "working")
                    UserDefaults.standard.set(self.currentSource, forKey: "streambert_lastWorkingSource")
                    self.onPreferredSource?(self.currentSource)
                    if dur.isFinite && dur > 60 {
                        self.fetchSkipSegmentsInBackground(durationMs: Int(dur * 1000.0))
                    }
                    if let group = avItem.asset.mediaSelectionGroup(forMediaCharacteristic: .legible) {
                        var opts: [(lang: String, title: String, option: AVMediaSelectionOption)] = []
                        for opt in group.options {
                            let code = self.normalizeSubLang(opt.locale?.languageCode ?? opt.extendedLanguageTag ?? "")
                            let title = opt.displayName
                            opts.append((lang: code, title: title, option: opt))
                        }
                        self.hlsLegibleOptions = opts
                        if let prefOpt = opts.first(where: { $0.lang == self.preferredLang }) {
                            avItem.select(prefOpt.option, in: group)
                            self.usingNativeHlsSubtitle = true
                            self.activeSubIndex = -1
                        }
                    }
                    let kickPlay = {
                        newPlayer.pause()
                        newPlayer.rate = self.currentSpeed
                        newPlayer.play()
                        self.updatePlayPauseIcon()
                    }
                    if seekSec > 0 && dur.isFinite && seekSec < dur - 15 {
                        newPlayer.seek(to: CMTime(seconds: seekSec, preferredTimescale: 600)) { _ in
                            DispatchQueue.main.async {
                                kickPlay()
                            }
                        }
                    } else {
                        kickPlay()
                    }
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.28) { [weak self] in
                        guard let self = self, self.player === newPlayer else { return }
                        if newPlayer.timeControlStatus != .playing {
                            kickPlay()
                        }
                    }
                } else if avItem.status == .failed {
                    if self.headerRetryStage < 2 {
                        self.headerRetryStage += 1
                        self.startPlayback(urlString: self.streamUrl, referer: self.activeReferer, seekSec: seekSec)
                        return
                    }
                    self.headerRetryStage = 0
                    self.failedStreamUrls.insert(url.absoluteString)
                    self.streamUrl = ""
                    self.verifiedServers.removeValue(forKey: self.currentSource)
                    self.updateSwitchServerButtonTitle()
                    self.isSwitchingServer = false
                    if self.isCaptchaVisible {
                        self.showToast("Server failed — pick another in SERVERS")
                    } else {
                        self.triggerNextServerFailover()
                    }
                }
            }
        }

        NotificationCenter.default.addObserver(
            forName: .AVPlayerItemDidPlayToEndTime,
            object: item,
            queue: .main
        ) { [weak self] _ in
            self?.saveProgress(forceCompleted: true)
        }

        let interval = CMTime(seconds: 0.25, preferredTimescale: 600)
        timeObserver = newPlayer.addPeriodicTimeObserver(forInterval: interval, queue: .main) { [weak self] _ in
            guard let self = self else { return }
            self.updateTimeAndSubtitles()
            self.updateSkipAndNextEpisodeUi()
            let now = Date().timeIntervalSince1970
            if now - self.lastProgressSaveTime >= 5.0 {
                self.lastProgressSaveTime = now
                self.saveProgress(forceCompleted: false)
            }
        }
    }

    private func updateSwitchServerButtonTitle() {
        let readyCount = verifiedServers.keys.filter { $0 != currentSource }.count
        if readyCount > 0 {
            switchServerButton.setTitle("Servers (\(readyCount)) ▾", for: .normal)
        } else {
            switchServerButton.setTitle("Servers ▾", for: .normal)
        }
    }

    private func bestVerifiedServer(excluding excluded: String) -> (source: String, url: String, referer: String)? {
        let curIdx = serverOrder.firstIndex(of: excluded) ?? -1
        var candidates: [(idx: Int, src: String, url: String, ref: String, isHls: Bool)] = []
        for (src, info) in verifiedServers {
            if src == excluded { continue }
            let idx = serverOrder.firstIndex(of: src) ?? 999
            let l = info.url.lowercased()
            let isHls = l.contains(".m3u8") || l.contains(".mpd")
            candidates.append((idx: idx, src: src, url: info.url, ref: info.referer, isHls: isHls))
        }
        if candidates.isEmpty { return nil }
        candidates.sort { a, b in
            if a.isHls != b.isHls { return a.isHls && !b.isHls }
            let aAfter = a.idx > curIdx ? 0 : 1
            let bAfter = b.idx > curIdx ? 0 : 1
            if aAfter != bAfter { return aAfter < bAfter }
            return a.idx < b.idx
        }
        let pick = candidates[0]
        return (pick.src, pick.url, pick.ref)
    }

    @objc private func handleSwitchServer() {
        showControllerTemporarily()
        let sheet = UIAlertController(title: "MultiEmbed Servers", message: "Choose a server or reload MultiEmbed", preferredStyle: .actionSheet)
        for srv in multiEmbedSubServers {
            sheet.addAction(UIAlertAction(title: srv.name, style: .default) { [weak self] _ in
                guard let self = self else { return }
                self.isSwitchingServer = true
                self.pendingNextSource = "multiembed"
                self.currentSource = "multiembed"
                let js = "(function(){var el=document.querySelector('[data-s-idx=\"\(srv.idx)\"]');if(el){el.click();return 'ok';}return 'no';})();"
                self.resolverWebView?.evaluateJavaScript(js, completionHandler: nil)
                self.showCaptchaCard(for: "multiembed")
                self.showToast("Selected \(srv.name)")
            })
        }
        sheet.addAction(UIAlertAction(title: "Open MultiEmbed Window", style: .default) { [weak self] _ in
            guard let self = self else { return }
            self.isSwitchingServer = true
            self.pendingNextSource = "multiembed"
            self.currentSource = "multiembed"
            let curUrl = self.resolverWebView?.url?.absoluteString ?? ""
            if curUrl.isEmpty || curUrl == "about:blank" {
                let embed = self.buildEmbedUrl(for: "multiembed")
                if !embed.isEmpty, let u = URL(string: embed) {
                    self.loadMultiEmbedUrl(u)
                }
            }
            self.showCaptchaCard(for: "multiembed")
        })
        sheet.addAction(UIAlertAction(title: "Reload MultiEmbed", style: .destructive) { [weak self] _ in
            guard let self = self else { return }
            self.skipCaptchaServer()
            self.showCaptchaCard(for: "multiembed")
        })
        sheet.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        sheet.popoverPresentationController?.sourceView = switchServerButton
        sheet.popoverPresentationController?.sourceRect = switchServerButton.bounds
        present(sheet, animated: true)
    }

    private func startBackgroundServerProbing() {
        if isProbingActive || (!streamUrl.isEmpty && streamUrl.hasPrefix("/")) { return }
        isProbingActive = true
        probeQueue = serverOrder.filter { $0 != currentSource && !probedFailedServers.contains($0) && verifiedServers[$0] == nil }
        if probeQueue.isEmpty { return }
        let slotCount = min(2, probeQueue.count)
        for _ in 0..<slotCount {
            let cfg = WKWebViewConfiguration()
            cfg.websiteDataStore = WKWebsiteDataStore.default()
            cfg.allowsInlineMediaPlayback = true
            cfg.mediaTypesRequiringUserActionForPlayback = .all
            cfg.preferences.javaScriptCanOpenWindowsAutomatically = false
            let ucc = WKUserContentController()
            ucc.add(self, name: "ProbeSniffer")
        let probeJs = """
        (function(){
          var hn = (location.hostname || '').toLowerCase();
          if (/cloudflare\\.com|recaptcha\\.net|hcaptcha\\.com|arkoselabs\\.com|geetest\\.com/.test(hn)) return;
          if (window.__sbProbeInstalled) return;
          window.__sbProbeInstalled = true;
          try { window.open = function(){ return null; }; } catch(e) {}
          function post(kind, u) {
            if (!u || typeof u !== 'string') return;
            var l = u.toLowerCase();
            if (kind === 'dead' || kind === 'challenge' || l.indexOf('.m3u8') !== -1 || l.indexOf('.mpd') !== -1 || l.indexOf('master.txt') !== -1 || l.indexOf('playlist.txt') !== -1 || l.indexOf('/hls/') !== -1 || (l.indexOf('.mp4') !== -1 && l.indexOf('preview') === -1 && l.indexOf('trailer') === -1 && l.indexOf('favicon') === -1)) {
              try { window.webkit.messageHandlers.ProbeSniffer.postMessage({ kind: kind, url: u, ref: location.href }); } catch(e) {}
            }
          }
          if (window.fetch) {
            var of = window.fetch;
            window.fetch = function(i){ try { post('stream', typeof i === 'string' ? i : (i && i.url)); } catch(e) {} return of.apply(this, arguments); };
          }
          if (window.XMLHttpRequest) {
            var oo = XMLHttpRequest.prototype.open;
            XMLHttpRequest.prototype.open = function(m, u){ try { post('stream', u); } catch(e) {} return oo.apply(this, arguments); };
          }
          try { new PerformanceObserver(function(list){ list.getEntries().forEach(function(e){ post('stream', e.name); }); }).observe({ entryTypes: ['resource'] }); } catch(e) {}
          function checkPage() {
            try {
              var txt = ((document.title || '') + ' ' + (document.body ? document.body.innerText.slice(0, 500) : '')).toLowerCase();
              if (txt.indexOf('no sources') !== -1 || txt.indexOf('try again later') !== -1 || txt.indexOf('404 not found') !== -1 || txt.indexOf('502 bad gateway') !== -1 || txt.indexOf('media not found') !== -1 || txt.indexOf('video not found') !== -1 || txt.indexOf('not available') !== -1) {
                post('dead', location.href);
                return;
              }
              if (txt.indexOf('just a moment') !== -1 || txt.indexOf('verify you are human') !== -1 || txt.indexOf('security check') !== -1 || !!document.querySelector('iframe[src*="turnstile"],iframe[src*="challenge"],iframe[src*="captcha"],.cf-turnstile,.g-recaptcha,.h-captcha')) {
                post('challenge', location.href);
                return;
              }
              document.querySelectorAll('video, source').forEach(function(el){
                if (el.src) post('stream', el.src);
                if (el.currentSrc) post('stream', el.currentSrc);
                if (el.tagName === 'VIDEO') { el.muted = true; try { el.pause(); } catch(e) {} }
              });
              document.querySelectorAll('#pl_but,.play,.btn-play,[class*=play],button').forEach(function(b){ try { b.click(); } catch(e) {} });
            } catch(e) {}
          }
          setTimeout(checkPage, 650);
          setTimeout(checkPage, 1700);
        })();
        """
            ucc.addUserScript(WKUserScript(source: probeJs, injectionTime: .atDocumentStart, forMainFrameOnly: false))
            cfg.userContentController = ucc
            let pwv = WKWebView(frame: CGRect(x: 0, y: 0, width: 64, height: 64), configuration: cfg)
            pwv.alpha = 0.001
            pwv.isUserInteractionEnabled = false
            pwv.navigationDelegate = self
            pwv.uiDelegate = self
            pwv.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"
            view.insertSubview(pwv, at: 0)
            probeWebViews.append(pwv)
            advanceProbeSlot(pwv)
        }
    }

    private func advanceProbeSlot(_ pwv: WKWebView) {
        let oid = ObjectIdentifier(pwv)
        probeTimers[oid]?.invalidate()
        probeTimers[oid] = nil
        probeSlotSources.removeValue(forKey: oid)
        pwv.stopLoading()
        while !probeQueue.isEmpty {
            let nextSrc = probeQueue.removeFirst()
            if nextSrc == currentSource || probedFailedServers.contains(nextSrc) || verifiedServers[nextSrc] != nil { continue }
            let embed = buildEmbedUrl(for: nextSrc)
            if embed.isEmpty { continue }
            guard let u = URL(string: embed) else { continue }
            probeSlotSources[oid] = nextSrc
            pwv.load(URLRequest(url: u))
            probeTimers[oid] = Timer.scheduledTimer(withTimeInterval: 6.5, repeats: false) { [weak self, weak pwv] _ in
                guard let self = self, let pwv = pwv else { return }
                let k = ObjectIdentifier(pwv)
                if let failedSrc = self.probeSlotSources[k] {
                    self.probedFailedServers.insert(failedSrc)
                }
                self.advanceProbeSlot(pwv)
            }
            return
        }
        pwv.loadHTMLString("", baseURL: nil)
    }

    private func stopBackgroundServerProbing() {
        isProbingActive = false
        probeQueue.removeAll()
        for (_, t) in probeTimers { t.invalidate() }
        probeTimers.removeAll()
        probeSlotSources.removeAll()
        for pwv in probeWebViews {
            pwv.stopLoading()
            pwv.removeFromSuperview()
        }
        probeWebViews.removeAll()
    }

    private func triggerNextServerFailover() {
        if isSwitchingServer || isCaptchaVisible { return }
        if let best = bestVerifiedServer(excluding: currentSource) {
            failoverTimer?.invalidate()
            isSwitchingServer = false
            hideCaptchaCard()
            currentSource = best.source
            streamUrl = best.url
            updateServerBadge(best.source)
            updateSwitchServerButtonTitle()
            let cur = player.map { CMTimeGetSeconds($0.currentTime()) } ?? startTimeSec
            let resume = cur.isFinite && cur > 0 ? cur : startTimeSec
            startPlayback(urlString: best.url, referer: best.referer, seekSec: resume)
            return
        }
        if serverOrder.count == 1 && serverOrder.first == "multiembed" {
            isSwitchingServer = true
            pendingNextSource = "multiembed"
            currentSource = "multiembed"
            let curUrl = resolverWebView?.url?.absoluteString ?? ""
            if curUrl.isEmpty || curUrl == "about:blank" {
                let embed = buildEmbedUrl(for: "multiembed")
                if !embed.isEmpty, let u = URL(string: embed) {
                    loadMultiEmbedUrl(u)
                }
            }
            resolverWebView?.evaluateJavaScript("(function(){document.querySelectorAll('button,div,span').forEach(function(b){var t=(b.innerText||'').trim().toLowerCase();if(t==='servers'||t.indexOf('servers')===0){try{b.click();}catch(e){}}});})();", completionHandler: nil)
            showToast("Pick another server from Servers ▾")
            showCaptchaCard(for: "multiembed")
            return
        }
        if failoverAttempts >= serverOrder.count {
            showToast("No working server found — tap Switch Server to retry")
            return
        }
        isSwitchingServer = true
        failoverAttempts += 1
        var nextSrc: String? = nil
        let idx = serverOrder.firstIndex(of: currentSource) ?? 0
        for step in 1...serverOrder.count {
            let cand = serverOrder[(idx + step) % serverOrder.count]
            if !probedFailedServers.contains(cand) {
                nextSrc = cand
                break
            }
        }
        guard let nextSrc = nextSrc else {
            showToast("No working server found — tap Switch Server to retry")
            return
        }
        pendingNextSource = nextSrc
        updateServerBadge(nextSrc)
        showToast("Switching to \(nextSrc)...")
        let embed = buildEmbedUrl(for: nextSrc)
        if !embed.isEmpty, let u = URL(string: embed) {
            loadMultiEmbedUrl(u)
        }
        failoverTimer?.invalidate()
        failoverTimer = Timer.scheduledTimer(withTimeInterval: 7.5, repeats: false) { [weak self] _ in
            guard let self = self, self.isSwitchingServer else { return }
            self.isSwitchingServer = false
            self.currentSource = self.pendingNextSource
            self.triggerNextServerFailover()
        }
    }

    func applyExternalResolvedStream(url: String, sourceId: String) {
        if url.isEmpty { return }
        DispatchQueue.main.async {
            self.failoverTimer?.invalidate()
            self.isSwitchingServer = false
            self.streamUrl = url
            if !sourceId.isEmpty { self.currentSource = sourceId }
            self.updateServerBadge(self.currentSource)
            let cur = self.player.map { CMTimeGetSeconds($0.currentTime()) } ?? self.startTimeSec
            let resume = cur.isFinite && cur > 0 ? cur : self.startTimeSec
            self.startPlayback(urlString: url, referer: self.buildReferer(for: self.currentSource), seekSec: resume)
        }
    }

    private func isMismatchedTitleOrEpisode(_ hint: String) -> Bool {
        let h = hint.lowercased()
        if h.isEmpty { return false }
        if mediaType.lowercased() == "tv" {
            if let regex = try? NSRegularExpression(pattern: "(?:s(\\d{1,2})\\s*e(\\d{1,2})|\\b(\\d{1,2})x(\\d{1,2})\\b)") {
                let range = NSRange(h.startIndex..<h.endIndex, in: h)
                if let m = regex.firstMatch(in: h, range: range) {
                    let sRange = m.range(at: 1).location != NSNotFound ? m.range(at: 1) : m.range(at: 3)
                    let eRange = m.range(at: 2).location != NSNotFound ? m.range(at: 2) : m.range(at: 4)
                    if let sr = Range(sRange, in: h), let er = Range(eRange, in: h),
                       let sVal = Int(h[sr]), let eVal = Int(h[er]) {
                        if sVal != seasonNum || eVal != episodeNum { return true }
                    }
                }
            }
        }
        return false
    }

    private func isSuspiciousStreamUrl(_ url: String) -> Bool {
        let l = url.lowercased()
        let bad = ["promo", "teaser", "preroll", "ad_", "/ads/", "banner", "trailer", "preview", "bumper", "doubleclick", "vast", "vmap"]
        return bad.contains { l.contains($0) }
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        if message.name == "ProbeSniffer" {
            guard let pwv = message.webView,
                  let dict = message.body as? [String: Any],
                  let url = dict["url"] as? String else { return }
            let oid = ObjectIdentifier(pwv)
            guard let src = probeSlotSources[oid] else { return }
            let kind = dict["kind"] as? String ?? "stream"
            if kind == "sub" {
            let subTrack = IosSubTrack(lang: preferredLang.isEmpty ? "en" : preferredLang, url: url, score: 160, syncMatch: true)
            mergeSubtitleTracks([subTrack])
            return
        }
        if kind == "servers_list" {
            if let arr = dict["servers"] as? [[String: Any]] {
                var parsed: [(name: String, idx: String)] = []
                for item in arr {
                    if let n = item["name"] as? String, let ix = item["idx"] as? String, !n.isEmpty {
                        parsed.append((name: n, idx: ix))
                    }
                }
                if !parsed.isEmpty {
                    multiEmbedSubServers = parsed
                    switchServerButton.setTitle("Servers (\(parsed.count)) ▾", for: .normal)
                }
            }
            return
        }
        if kind == "ad_blocked" {
            let prev = UserDefaults.standard.integer(forKey: "sb_blocked_total")
            UserDefaults.standard.set(prev + 1, forKey: "sb_blocked_total")
            onBlockedAd?(url)
            return
        }
        if kind == "dead" {
                probedFailedServers.insert(src)
                advanceProbeSlot(pwv)
                return
            }
            if kind == "challenge" {
                advanceProbeSlot(pwv)
                return
            }
            let pHint = (dict["hint"] as? String ?? "")
            if isSuspiciousStreamUrl(url) || isMismatchedTitleOrEpisode(pHint) || probedFailedServers.contains(src) { return }
            let ref = dict["ref"] as? String ?? buildReferer(for: src)
            verifiedServers[src] = (url: url, referer: ref)
            updateSwitchServerButtonTitle()
            if isSwitchingServer && streamUrl.isEmpty {
                failoverTimer?.invalidate()
                isSwitchingServer = false
                hideCaptchaCard()
                currentSource = src
                streamUrl = url
                updateServerBadge(src)
                updateSwitchServerButtonTitle()
                let cur = player.map { CMTimeGetSeconds($0.currentTime()) } ?? startTimeSec
                let resume = cur.isFinite && cur > 0 ? cur : startTimeSec
                startPlayback(urlString: url, referer: ref, seekSec: resume)
            }
            advanceProbeSlot(pwv)
            return
        }
        guard message.name == "PlayerSniffer",
              let dict = message.body as? [String: Any],
              let url = dict["url"] as? String else { return }
        let kind = dict["kind"] as? String ?? "stream"
        if kind == "ad_blocked" {
            let prev = UserDefaults.standard.integer(forKey: "sb_blocked_total")
            UserDefaults.standard.set(prev + 1, forKey: "sb_blocked_total")
            onBlockedAd?(url)
            return
        }
        if kind == "m3u8_inline" {
            if let m3u8 = dict["m3u8"] as? String, !m3u8.isEmpty {
                inlineM3u8Text = m3u8
                streamIsHls = true
                let rawRef = (dict["ref"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
                let ref = rawRef.isEmpty ? buildReferer(for: "multiembed") : rawRef
                failoverTimer?.invalidate()
                isSwitchingServer = false
                currentSource = "multiembed"
                pendingNextSource = ""
                streamUrl = "singularity-inline://playlist.m3u8"
                updateServerBadge(currentSource)
                let cur = player.map { CMTimeGetSeconds($0.currentTime()) } ?? startTimeSec
                let resume = cur.isFinite && cur > 0 ? cur : startTimeSec
                startPlayback(urlString: streamUrl, referer: ref, seekSec: resume)
            }
            return
        }
        if kind == "dead" {
            if isSwitchingServer && !isCaptchaVisible {
                let failedSrc = pendingNextSource.isEmpty ? currentSource : pendingNextSource
                failoverTimer?.invalidate()
                isSwitchingServer = false
                currentSource = failedSrc
                pendingNextSource = ""
                triggerNextServerFailover()
            }
            return
        }
        if kind == "challenge" {
            if isSwitchingServer && !isCaptchaVisible {
                let targetSrc = pendingNextSource.isEmpty ? currentSource : pendingNextSource
                failoverTimer?.invalidate()
                showCaptchaCard(for: targetSrc)
            }
            return
        }
        let psHint = (dict["hint"] as? String ?? "")
        if isSuspiciousStreamUrl(url) || isMismatchedTitleOrEpisode(psHint) || failedStreamUrls.contains(url) || url == streamUrl { return }
        let hint = (dict["hint"] as? String ?? "").lowercased()
        if !hint.isEmpty { activeReleaseHint = hint + " " + url.lowercased() }
        let isHlsFlag = (dict["isHls"] as? Bool) ?? false
        let rawRef = (dict["ref"] as? String ?? "").trimmingCharacters(in: .whitespacesAndNewlines)
        let ref = rawRef.isEmpty ? buildReferer(for: pendingNextSource) : rawRef
        if isSwitchingServer || isCaptchaVisible {
            failoverTimer?.invalidate()
            isSwitchingServer = false
            currentSource = pendingNextSource.isEmpty ? currentSource : pendingNextSource
            pendingNextSource = ""
            headerRetryStage = 0
            streamIsHls = isHlsFlag
            streamUrl = url
            updateServerBadge(currentSource)
            let cur = player.map { CMTimeGetSeconds($0.currentTime()) } ?? startTimeSec
            let resume = cur.isFinite && cur > 0 ? cur : startTimeSec
            startPlayback(urlString: url, referer: ref, seekSec: resume)
        }
    }

    private func showToast(_ text: String) {
        statusToastLabel.text = "  \(text)  "
        statusToastLabel.isHidden = false
        DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) { [weak self] in
            self?.statusToastLabel.isHidden = true
        }
    }

    private func updateTimeAndSubtitles() {
        guard let player = player else { return }
        let pos = CMTimeGetSeconds(player.currentTime())
        let dur = CMTimeGetSeconds(player.currentItem?.duration ?? .zero)
        if !isScrubbing && pos.isFinite && dur.isFinite && dur > 0 {
            let minValidSec: Double = mediaType.lowercased() == "tv" ? 60.0 : 180.0
            if dur < minValidSec && !streamUrl.hasPrefix("/") {
                player.pause()
                recordServerStatus(currentSource, status: "failed")
                showToast("Short/fake clip on \(serverDisplayName(currentSource)) — switching...")
                if !isSwitchingServer {
                    triggerNextServerFailover()
                }
                return
            }
            currentPosLabel.text = formatTime(pos)
            durationLabel.text = formatTime(dur)
            seekSlider.value = Float(min(1.0, max(0.0, pos / dur)))
            if !isSwitchingServer && dur >= minValidSec && (pos > 0.5 || player.rate > 0) {
                if getServerStatus(currentSource) != "working" {
                    recordServerStatus(currentSource, status: "working")
                }
            }
        }
        if usingNativeHlsSubtitle { return }
        if !activeCues.isEmpty && pos.isFinite {
            let adj = pos - subDelaySec
            if let cue = activeCues.first(where: { adj >= $0.startSec && adj <= $0.endSec }) {
                let lc = cue.text.lowercased()
                if lc.contains("osdb.link") || lc.contains("opensubtitles.org") || lc.contains("advertise your product") {
                    subtitleLabel.isHidden = true
                } else {
                    subtitleLabel.text = cue.text
                    subtitleLabel.isHidden = false
                }
            } else {
                subtitleLabel.isHidden = true
            }
        } else {
            subtitleLabel.isHidden = true
        }
    }

    private func formatTime(_ sec: Double) -> String {
        let total = max(0, Int(sec))
        let h = total / 3600
        let m = (total % 3600) / 60
        let s = total % 60
        return h > 0 ? String(format: "%d:%02d:%02d", h, m, s) : String(format: "%d:%02d", m, s)
    }

    private func updatePlayPauseIcon() {
        let playing = (player?.rate ?? 0) > 0
        playPauseButton.setImage(UIImage(systemName: playing ? "pause.fill" : "play.fill"), for: .normal)
    }

    private func showControllerTemporarily() {
        isControllerVisible = true
        overlayView.isHidden = false
        UIView.animate(withDuration: 0.18) { self.overlayView.alpha = 1 }
        hideControllerWorkItem?.cancel()
        let item = DispatchWorkItem { [weak self] in
            guard let self = self, (self.player?.rate ?? 0) > 0, !self.isScrubbing else { return }
            self.setControllerVisible(false)
        }
        hideControllerWorkItem = item
        DispatchQueue.main.asyncAfter(deadline: .now() + 4.0, execute: item)
    }

    private func setControllerVisible(_ visible: Bool) {
        isControllerVisible = visible
        if visible {
            showControllerTemporarily()
        } else {
            hideControllerWorkItem?.cancel()
            UIView.animate(withDuration: 0.18, animations: { self.overlayView.alpha = 0 }) { _ in
                if !self.isControllerVisible { self.overlayView.isHidden = true }
            }
        }
    }

    @objc private func handleBack() {
        saveProgress(forceCompleted: false)
        dismiss(animated: true)
    }

    @objc private func handlePlayPause() {
        guard let player = player else { return }
        if player.rate > 0 {
            player.pause()
        } else {
            player.rate = currentSpeed
            player.play()
        }
        updatePlayPauseIcon()
        showControllerTemporarily()
    }

    @objc private func handleRewind10() { seekBy(-10) }
    @objc private func handleForward10() { seekBy(10) }

    private func seekBy(_ delta: Double) {
        guard let player = player else { return }
        let cur = CMTimeGetSeconds(player.currentTime())
        let dur = CMTimeGetSeconds(player.currentItem?.duration ?? .zero)
        var target = max(0, cur + delta)
        if dur.isFinite && dur > 0 { target = min(dur, target) }
        player.seek(to: CMTime(seconds: target, preferredTimescale: 600))
    }

    @objc private func onSliderStart() {
        isScrubbing = true
        hideControllerWorkItem?.cancel()
    }

    @objc private func onSliderChanged() {
        guard let dur = player?.currentItem?.duration else { return }
        let d = CMTimeGetSeconds(dur)
        if d.isFinite && d > 0 {
            currentPosLabel.text = formatTime(Double(seekSlider.value) * d)
        }
    }

    @objc private func onSliderEnd() {
        isScrubbing = false
        if let dur = player?.currentItem?.duration {
            let d = CMTimeGetSeconds(dur)
            if d.isFinite && d > 0 {
                player?.seek(to: CMTime(seconds: Double(seekSlider.value) * d, preferredTimescale: 600))
            }
        }
        showControllerTemporarily()
    }

    @objc private func openSpeedMenu() {
        let sheet = UIAlertController(title: "Playback Speed", message: nil, preferredStyle: .actionSheet)
        for s: Float in [0.5, 0.75, 1.0, 1.25, 1.5, 2.0] {
            sheet.addAction(UIAlertAction(title: "\(s)x", style: .default) { _ in
                self.currentSpeed = s
                self.speedButton.setTitle("\(s)x", for: .normal)
                if (self.player?.rate ?? 0) > 0 { self.player?.rate = s }
            })
        }
        sheet.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        sheet.popoverPresentationController?.sourceView = speedButton
        present(sheet, animated: true)
    }

    private func languageDisplayName(_ code: String) -> String {
        switch code.lowercased() {
        case "ar": return "Arabic"
        case "en": return "English"
        case "ko": return "Korea"
        case "ja": return "Japanese"
        case "fr": return "French"
        case "es": return "Spanish"
        case "de": return "German"
        case "tr": return "Turkish"
        case "pt": return "Portuguese"
        case "it": return "Italian"
        case "ru": return "Russian"
        case "hi": return "Hindi"
        case "id": return "Indonesian"
        case "zh": return "Chinese"
        case "nl": return "Dutch"
        case "pl": return "Polish"
        case "sv": return "Swedish"
        case "th": return "Thai"
        case "vi": return "Vietnamese"
        case "fa": return "Persian"
        default: return code.uppercased()
        }
    }

    private func formatSyncValue(_ sec: Double) -> String {
        let ms = Int((sec * 1000.0).rounded())
        if ms == 0 { return "0.00s (0ms)" }
        let sign = ms > 0 ? "+" : ""
        return String(format: "%@%.2fs (%@%dms)", sign, sec, sign, ms)
    }

    @objc private func openSyncMenu() {
        if syncCardView.superview == nil {
            syncCardView.translatesAutoresizingMaskIntoConstraints = false
            syncCardView.backgroundColor = UIColor(red: 16/255, green: 20/255, blue: 30/255, alpha: 0.94)
            syncCardView.layer.cornerRadius = 16
            syncCardView.layer.borderWidth = 1
            syncCardView.layer.borderColor = UIColor.white.withAlphaComponent(0.16).cgColor
            view.addSubview(syncCardView)

            let titleLbl = UILabel()
            titleLbl.translatesAutoresizingMaskIntoConstraints = false
            titleLbl.text = "Subtitle Sync"
            titleLbl.textColor = .white
            titleLbl.font = .boldSystemFont(ofSize: 14)

            syncValueLabel.translatesAutoresizingMaskIntoConstraints = false
            syncValueLabel.textColor = UIColor(red: 229/255, green: 9/255, blue: 20/255, alpha: 1)
            syncValueLabel.font = .monospacedDigitSystemFont(ofSize: 13, weight: .bold)

            let earlierLbl = UILabel()
            earlierLbl.translatesAutoresizingMaskIntoConstraints = false
            earlierLbl.text = "Earlier"
            earlierLbl.textColor = UIColor.white.withAlphaComponent(0.75)
            earlierLbl.font = .systemFont(ofSize: 12, weight: .semibold)

            let minusBtn = UIButton(type: .system)
            minusBtn.translatesAutoresizingMaskIntoConstraints = false
            minusBtn.setTitle("−", for: .normal)
            minusBtn.setTitleColor(.white, for: .normal)
            minusBtn.titleLabel?.font = .boldSystemFont(ofSize: 22)
            minusBtn.backgroundColor = UIColor.white.withAlphaComponent(0.14)
            minusBtn.layer.cornerRadius = 12
            minusBtn.addTarget(self, action: #selector(stepSyncMinus), for: .touchUpInside)
            let minusHold = UILongPressGestureRecognizer(target: self, action: #selector(handleMinusLongPress(_:)))
            minusHold.minimumPressDuration = 0.25
            minusBtn.addGestureRecognizer(minusHold)

            syncCenterLabel.translatesAutoresizingMaskIntoConstraints = false
            syncCenterLabel.textColor = .white
            syncCenterLabel.textAlignment = .center
            syncCenterLabel.font = .monospacedDigitSystemFont(ofSize: 18, weight: .bold)

            let plusBtn = UIButton(type: .system)
            plusBtn.translatesAutoresizingMaskIntoConstraints = false
            plusBtn.setTitle("+", for: .normal)
            plusBtn.setTitleColor(.white, for: .normal)
            plusBtn.titleLabel?.font = .boldSystemFont(ofSize: 22)
            plusBtn.backgroundColor = UIColor.white.withAlphaComponent(0.14)
            plusBtn.layer.cornerRadius = 12
            plusBtn.addTarget(self, action: #selector(stepSyncPlus), for: .touchUpInside)
            let plusHold = UILongPressGestureRecognizer(target: self, action: #selector(handlePlusLongPress(_:)))
            plusHold.minimumPressDuration = 0.25
            plusBtn.addGestureRecognizer(plusHold)

            let laterLbl = UILabel()
            laterLbl.translatesAutoresizingMaskIntoConstraints = false
            laterLbl.text = "Later"
            laterLbl.textColor = UIColor.white.withAlphaComponent(0.75)
            laterLbl.font = .systemFont(ofSize: 12, weight: .semibold)

            let resetBtn = UIButton(type: .system)
            resetBtn.translatesAutoresizingMaskIntoConstraints = false
            resetBtn.setTitle("Reset 0.0", for: .normal)
            resetBtn.setTitleColor(.white, for: .normal)
            resetBtn.titleLabel?.font = .boldSystemFont(ofSize: 12)
            resetBtn.backgroundColor = UIColor.white.withAlphaComponent(0.12)
            resetBtn.layer.cornerRadius = 8
            resetBtn.contentEdgeInsets = UIEdgeInsets(top: 5, left: 10, bottom: 5, right: 10)
            resetBtn.addTarget(self, action: #selector(resetSyncSlider), for: .touchUpInside)

            let doneBtn = UIButton(type: .system)
            doneBtn.translatesAutoresizingMaskIntoConstraints = false
            doneBtn.setTitle("Done", for: .normal)
            doneBtn.setTitleColor(.white, for: .normal)
            doneBtn.titleLabel?.font = .boldSystemFont(ofSize: 12)
            doneBtn.backgroundColor = UIColor(red: 229/255, green: 9/255, blue: 20/255, alpha: 1)
            doneBtn.layer.cornerRadius = 8
            doneBtn.contentEdgeInsets = UIEdgeInsets(top: 5, left: 12, bottom: 5, right: 12)
            doneBtn.addTarget(self, action: #selector(closeSyncCard), for: .touchUpInside)

            syncCardView.addSubview(titleLbl)
            syncCardView.addSubview(syncValueLabel)
            syncCardView.addSubview(earlierLbl)
            syncCardView.addSubview(minusBtn)
            syncCardView.addSubview(syncCenterLabel)
            syncCardView.addSubview(plusBtn)
            syncCardView.addSubview(laterLbl)
            syncCardView.addSubview(resetBtn)
            syncCardView.addSubview(doneBtn)

            NSLayoutConstraint.activate([
                syncCardView.centerXAnchor.constraint(equalTo: view.centerXAnchor),
                syncCardView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -92),
                syncCardView.widthAnchor.constraint(equalToConstant: 360),

                titleLbl.topAnchor.constraint(equalTo: syncCardView.topAnchor, constant: 14),
                titleLbl.leadingAnchor.constraint(equalTo: syncCardView.leadingAnchor, constant: 16),

                syncValueLabel.centerYAnchor.constraint(equalTo: titleLbl.centerYAnchor),
                syncValueLabel.trailingAnchor.constraint(equalTo: syncCardView.trailingAnchor, constant: -16),

                syncCenterLabel.topAnchor.constraint(equalTo: titleLbl.bottomAnchor, constant: 18),
                syncCenterLabel.centerXAnchor.constraint(equalTo: syncCardView.centerXAnchor),
                syncCenterLabel.widthAnchor.constraint(equalToConstant: 82),

                minusBtn.centerYAnchor.constraint(equalTo: syncCenterLabel.centerYAnchor),
                minusBtn.trailingAnchor.constraint(equalTo: syncCenterLabel.leadingAnchor, constant: -10),
                minusBtn.widthAnchor.constraint(equalToConstant: 46),
                minusBtn.heightAnchor.constraint(equalToConstant: 42),

                earlierLbl.centerYAnchor.constraint(equalTo: syncCenterLabel.centerYAnchor),
                earlierLbl.trailingAnchor.constraint(equalTo: minusBtn.leadingAnchor, constant: -8),

                plusBtn.centerYAnchor.constraint(equalTo: syncCenterLabel.centerYAnchor),
                plusBtn.leadingAnchor.constraint(equalTo: syncCenterLabel.trailingAnchor, constant: 10),
                plusBtn.widthAnchor.constraint(equalToConstant: 46),
                plusBtn.heightAnchor.constraint(equalToConstant: 42),

                laterLbl.centerYAnchor.constraint(equalTo: syncCenterLabel.centerYAnchor),
                laterLbl.leadingAnchor.constraint(equalTo: plusBtn.trailingAnchor, constant: 8),

                resetBtn.topAnchor.constraint(equalTo: syncCenterLabel.bottomAnchor, constant: 18),
                resetBtn.leadingAnchor.constraint(equalTo: syncCardView.leadingAnchor, constant: 16),
                resetBtn.bottomAnchor.constraint(equalTo: syncCardView.bottomAnchor, constant: -14),

                doneBtn.centerYAnchor.constraint(equalTo: resetBtn.centerYAnchor),
                doneBtn.trailingAnchor.constraint(equalTo: syncCardView.trailingAnchor, constant: -16)
            ])
        }
        refreshSyncUi()
        syncCardView.isHidden = false
        view.bringSubviewToFront(syncCardView)
    }

    private func refreshSyncUi() {
        let sign = subDelaySec > 0.001 ? "+" : ""
        syncCenterLabel.text = String(format: "%@%.1fs", sign, subDelaySec)
        syncValueLabel.text = formatSyncValue(subDelaySec)
        syncButton.setTitle(String(format: "Sync %@%.1fs", sign, subDelaySec), for: .normal)
        updateTimeAndSubtitles()
    }

    private func adjustSync(by delta: Double) {
        subDelaySec = ((subDelaySec + delta) * 10.0).rounded() / 10.0
        refreshSyncUi()
    }

    @objc private func stepSyncMinus() { adjustSync(by: -0.1) }
    @objc private func stepSyncPlus() { adjustSync(by: 0.1) }

    @objc private func handleMinusLongPress(_ g: UILongPressGestureRecognizer) {
        if g.state == .began {
            syncRepeatTimer?.invalidate()
            syncRepeatTimer = Timer.scheduledTimer(withTimeInterval: 0.07, repeats: true) { [weak self] _ in
                self?.adjustSync(by: -0.1)
            }
        } else if g.state == .ended || g.state == .cancelled || g.state == .failed {
            syncRepeatTimer?.invalidate()
            syncRepeatTimer = nil
        }
    }

    @objc private func handlePlusLongPress(_ g: UILongPressGestureRecognizer) {
        if g.state == .began {
            syncRepeatTimer?.invalidate()
            syncRepeatTimer = Timer.scheduledTimer(withTimeInterval: 0.07, repeats: true) { [weak self] _ in
                self?.adjustSync(by: 0.1)
            }
        } else if g.state == .ended || g.state == .cancelled || g.state == .failed {
            syncRepeatTimer?.invalidate()
            syncRepeatTimer = nil
        }
    }

    @objc private func resetSyncSlider() {
        subDelaySec = 0.0
        refreshSyncUi()
    }

    @objc private func closeSyncCard() {
        syncRepeatTimer?.invalidate()
        syncRepeatTimer = nil
        syncCardView.isHidden = true
    }

    @objc private func openSubtitleMenu() {
        let sheet = UIAlertController(title: "Subtitles", message: nil, preferredStyle: .actionSheet)
        sheet.addAction(UIAlertAction(title: "Off", style: .default) { _ in
            self.usingNativeHlsSubtitle = false
            self.activeSubIndex = -1
            self.activeCues = []
            self.rawActiveCues = []
            self.subtitleLabel.isHidden = true
            if let item = self.player?.currentItem, let grp = item.asset.mediaSelectionGroup(forMediaCharacteristic: .legible) {
                item.select(nil, in: grp)
            }
        })
        for hlsOpt in hlsLegibleOptions {
            let label = "\(languageDisplayName(hlsOpt.lang)) (Stream)"
            sheet.addAction(UIAlertAction(title: label, style: .default) { _ in
                if let item = self.player?.currentItem, let grp = item.asset.mediaSelectionGroup(forMediaCharacteristic: .legible) {
                    item.select(hlsOpt.option, in: grp)
                    self.usingNativeHlsSubtitle = true
                    self.activeSubIndex = -1
                    self.activeCues = []
                }
            })
        }
        var langCounts: [String: Int] = [:]
        for (idx, sub) in availableSubs.enumerated() {
            let num = (langCounts[sub.lang] ?? 0) + 1
            langCounts[sub.lang] = num
            let langName = languageDisplayName(sub.lang)
            let prefix = (!usingNativeHlsSubtitle && idx == activeSubIndex) ? "✓ " : ""
            sheet.addAction(UIAlertAction(title: "\(prefix)\(langName) #\(num)", style: .default) { _ in
                self.usingNativeHlsSubtitle = false
                if let item = self.player?.currentItem, let grp = item.asset.mediaSelectionGroup(forMediaCharacteristic: .legible) {
                    item.select(nil, in: grp)
                }
                self.activeSubIndex = idx
                self.activeSubIsStreamNative = sub.score >= 150
                self.loadSubtitleFile(url: sub.url)
            })
        }
        sheet.addAction(UIAlertAction(title: "Cancel", style: .cancel))
        sheet.popoverPresentationController?.sourceView = subButton
        present(sheet, animated: true)
    }

    @objc private func togglePip() {
        guard let pip = pipController else { return }
        if pip.isPictureInPictureActive {
            pip.stopPictureInPicture()
        } else {
            pip.startPictureInPicture()
        }
    }

    private func normalizeSubLang(_ raw: String) -> String {
        let c = raw.trimmingCharacters(in: .whitespacesAndNewlines).lowercased().components(separatedBy: "-").first ?? "en"
        switch c {
        case "ara", "arabic", "ar": return "ar"
        case "eng", "english", "en": return "en"
        case "kor", "korean", "ko": return "ko"
        case "jpn", "japanese", "ja": return "ja"
        case "fre", "fra", "french", "fr": return "fr"
        case "spa", "spanish", "es": return "es"
        case "ger", "deu", "german", "de": return "de"
        case "tur", "turkish", "tr": return "tr"
        case "por", "portuguese", "pt": return "pt"
        case "ita", "italian", "it": return "it"
        case "rus", "russian", "ru": return "ru"
        case "hin", "hindi", "hi": return "hi"
        case "ind", "indonesian", "id": return "id"
        case "chi", "zho", "chinese", "zh": return "zh"
        case "dut", "nld", "dutch", "nl": return "nl"
        case "pol", "polish", "pl": return "pl"
        case "swe", "swedish", "sv": return "sv"
        case "tha", "thai", "th": return "th"
        case "vie", "vietnamese", "vi": return "vi"
        case "per", "fas", "persian", "fa": return "fa"
        default: return c.isEmpty ? "en" : c
        }
    }

    private func scoreRelease(_ name: String) -> (Int, Bool) {
        let l = name.lowercased()
        var score = 40
        var syncMatch = false
        let h = activeReleaseHint
        let isBdStream = h.contains("bdrip") || h.contains("brrip") || h.contains("bluray") || h.contains("xvid")
        let isBdSub = l.contains("bdrip") || l.contains("brrip") || l.contains("bluray")
        let isWebSub = l.contains("web-dl") || l.contains("webrip") || l.contains("web.")
        if isBdStream && isBdSub {
            score += 75
            syncMatch = true
        } else if !isBdStream && isWebSub {
            score += 55
            syncMatch = true
        } else if isBdSub || isWebSub || l.contains("1080p") || l.contains("720p") {
            score += 35
            syncMatch = true
        }
        if l.contains("cam") || l.contains("ts") || l.contains("hdcam") {
            score -= 20
        }
        return (score, syncMatch)
    }

    private func mergeSubtitleTracks(_ tracks: [IosSubTrack]) {
        if tracks.isEmpty { return }
        DispatchQueue.main.async {
            let activeUrl = (self.activeSubIndex >= 0 && self.activeSubIndex < self.availableSubs.count)
                ? self.availableSubs[self.activeSubIndex].url : nil
            var byUrl: [String: IosSubTrack] = [:]
            for t in self.availableSubs { byUrl[t.url] = t }
            for t in tracks {
                if let ex = byUrl[t.url] {
                    if t.score > ex.score { byUrl[t.url] = t }
                } else {
                    byUrl[t.url] = t
                }
            }
            var byLang: [String: [IosSubTrack]] = [:]
            for t in byUrl.values {
                byLang[t.lang, default: []].append(t)
            }
            var merged: [IosSubTrack] = []
            for (_, list) in byLang {
                let sortedList = list.sorted { $0.score > $1.score }
                merged.append(contentsOf: sortedList.prefix(10))
            }
            merged.sort { a, b in
                let aRank = a.lang == self.preferredLang ? 0 : (a.lang == "ar" ? 1 : (a.lang == "en" ? 2 : 3))
                let bRank = b.lang == self.preferredLang ? 0 : (b.lang == "ar" ? 1 : (b.lang == "en" ? 2 : 3))
                if aRank != bRank { return aRank < bRank }
                if a.lang != b.lang { return a.lang < b.lang }
                return a.score > b.score
            }
            let upgradedActiveUrl: String? = nil
            self.availableSubs = merged
            self.subButton.setTitle("Subtitles (\(self.availableSubs.count))", for: .normal)
            if let upUrl = upgradedActiveUrl, let idx = self.availableSubs.firstIndex(where: { $0.url == upUrl }) {
                self.activeSubIndex = idx
                self.activeSubIsStreamNative = self.availableSubs[idx].score >= 150
                self.loadSubtitleFile(url: upUrl)
            } else if let aUrl = activeUrl, let idx = self.availableSubs.firstIndex(where: { $0.url == aUrl }) {
                self.activeSubIndex = idx
            } else if self.activeSubIndex == -1, let firstPref = self.availableSubs.firstIndex(where: { $0.lang == self.preferredLang || $0.lang == "ar" }) {
                self.activeSubIndex = firstPref
                self.activeSubIsStreamNative = self.availableSubs[firstPref].score >= 150
                self.loadSubtitleFile(url: self.availableSubs[firstPref].url)
            }
        }
    }

    private func applySmartAutoSync(to cues: [IosSubCue]) -> [IosSubCue] {
        return cues.filter { cue in
            let lc = cue.text.lowercased()
            return !lc.contains("osdb.link") && !lc.contains("opensubtitles") && !lc.contains("subscene") && !lc.contains("advertise your product")
        }
    }

    func legibleOutput(_ output: AVPlayerItemLegibleOutput, didOutputAttributedStrings strings: [NSAttributedString], nativeSampleBuffers: [Any], forItemTime itemTime: CMTime) {
        guard usingNativeHlsSubtitle else { return }
        let text = strings.map { $0.string.trimmingCharacters(in: .whitespacesAndNewlines) }.filter { !$0.isEmpty }.joined(separator: "\n")
        if text.isEmpty {
            subtitleLabel.isHidden = true
        } else {
            subtitleLabel.text = text
            subtitleLabel.isHidden = false
        }
    }

    private func isSubtitleMatchingCurrentEpisode(_ relName: String) -> Bool {
        let l = relName.lowercased()
        if l.isEmpty { return true }
        let isTv = mediaType.lowercased() == "tv"
        if let regex = try? NSRegularExpression(pattern: "(?:s(\\d{1,2})\\s*e(\\d{1,2})|\\b(\\d{1,2})x(\\d{1,2})\\b)") {
            let range = NSRange(l.startIndex..<l.endIndex, in: l)
            if let m = regex.firstMatch(in: l, range: range) {
                if !isTv { return false }
                let sRange = m.range(at: 1).location != NSNotFound ? m.range(at: 1) : m.range(at: 3)
                let eRange = m.range(at: 2).location != NSNotFound ? m.range(at: 2) : m.range(at: 4)
                if let sr = Range(sRange, in: l), let er = Range(eRange, in: l),
                   let sVal = Int(l[sr]), let eVal = Int(l[er]) {
                    return sVal == seasonNum && eVal == episodeNum
                }
            }
        }
        return true
    }

    private func fetchSubtitlesInBackground() {
        guard !imdbId.isEmpty else { return }
        let isTv = mediaType.lowercased() == "tv"
        let osType = isTv ? "series" : "movie"
        let osTarget = isTv ? "\(imdbId):\(seasonNum):\(episodeNum)" : imdbId

        if let encoded = osTarget.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) {
            let stremioBases = [
                "https://opensubtitles-v3.strem.io/subtitles/\(osType)/\(encoded).json",
                "https://opensubtitles.strem.io/subtitles/\(osType)/\(encoded).json"
            ]
            for baseStr in stremioBases {
                guard let osUrl = URL(string: baseStr) else { continue }
                var req = URLRequest(url: osUrl)
                req.setValue("SingularityTV/2.7.3", forHTTPHeaderField: "User-Agent")
                URLSession.shared.dataTask(with: req) { [weak self] data, _, _ in
                    guard let self = self, let data = data,
                          let root = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                          let arr = root["subtitles"] as? [[String: Any]] else { return }
                    var added: [IosSubTrack] = []
                    for item in arr.prefix(300) {
                        guard let subUrl = item["url"] as? String, !subUrl.isEmpty else { continue }
                        let lang = self.normalizeSubLang(item["lang"] as? String ?? "en")
                        added.append(IosSubTrack(lang: lang, url: subUrl, score: 75, syncMatch: true))
                    }
                    self.mergeSubtitleTracks(added)
                }.resume()
            }
        }

        let numericImdb = imdbId.replacingOccurrences(of: "tt", with: "")
        if !numericImdb.isEmpty {
            let worldLangs = ["ara", "eng", "spa", "fre", "ger", "tur", "por", "ita", "rus", "jpn", "kor", "hin", "all"]
            for wLang in worldLangs {
                let restStr = isTv
                    ? "https://rest.opensubtitles.org/search/episode-\(episodeNum)/imdbid-\(numericImdb)/season-\(seasonNum)/sublanguageid-\(wLang)"
                    : "https://rest.opensubtitles.org/search/imdbid-\(numericImdb)/sublanguageid-\(wLang)"
                guard let ru = URL(string: restStr) else { continue }
                var rreq = URLRequest(url: ru)
                rreq.setValue("TemporaryUserAgent", forHTTPHeaderField: "X-User-Agent")
                rreq.setValue("TemporaryUserAgent", forHTTPHeaderField: "User-Agent")
                URLSession.shared.dataTask(with: rreq) { [weak self] data, _, _ in
                    guard let self = self, let data = data,
                          let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]] else { return }
                    var added: [IosSubTrack] = []
                    for item in arr.prefix(60) {
                        let rawDl = (item["SubDownloadLink"] as? String) ?? ""
                        if rawDl.isEmpty { continue }
                        let dlUrl = rawDl.replacingOccurrences(of: ".gz", with: "")
                        let iso = (item["ISO639"] as? String) ?? (item["SubLanguageID"] as? String) ?? "en"
                        let lang = self.normalizeSubLang(iso)
                        let relName = (item["MovieReleaseName"] as? String) ?? (item["SubFileName"] as? String) ?? ""
                        if !self.isSubtitleMatchingCurrentEpisode(relName) { continue }
                        let (sc, sm) = self.scoreRelease(relName)
                        added.append(IosSubTrack(lang: lang, url: dlUrl, score: sc + 20, syncMatch: sm))
                    }
                    self.mergeSubtitleTracks(added)
                }.resume()
            }
        }
    }

    private func decodeSubtitleData(_ data: Data) -> String? {
        if let utf8 = String(data: data, encoding: .utf8) {
            return utf8
        }
        let cp1256 = String.Encoding(rawValue: CFStringConvertEncodingToNSStringEncoding(CFStringEncoding(0x0506)))
        if let ar = String(data: data, encoding: cp1256) {
            return ar
        }
        if let latin = String(data: data, encoding: .isoLatin1) {
            return latin
        }
        return nil
    }

    private func loadSubtitleFile(url: String) {
        guard let u = URL(string: url) else { return }
        var req = URLRequest(url: u)
        req.setValue("SingularityTV/2.7.3", forHTTPHeaderField: "User-Agent")
        URLSession.shared.dataTask(with: req) { [weak self] data, _, _ in
            guard let self = self, let data = data, let text = self.decodeSubtitleData(data) else { return }
            let parsed = self.parseSrtOrVtt(text)
            DispatchQueue.main.async {
                self.rawActiveCues = parsed
                self.activeCues = self.applySmartAutoSync(to: parsed)
                self.updateTimeAndSubtitles()
            }
        }.resume()
    }

    private func parseSrtOrVtt(_ raw: String) -> [IosSubCue] {
        var cues: [IosSubCue] = []
        let cleaned = raw
            .replacingOccurrences(of: "\u{FEFF}", with: "")
            .replacingOccurrences(of: "\r\n", with: "\n")
            .replacingOccurrences(of: "\r", with: "\n")
        let lines = cleaned.components(separatedBy: "\n")
        var i = 0
        while i < lines.count {
            let line = lines[i].trimmingCharacters(in: .whitespaces)
            if line.contains("-->") {
                let parts = line.components(separatedBy: "-->")
                if parts.count >= 2 {
                    let startStr = parts[0].trimmingCharacters(in: .whitespaces).components(separatedBy: " ").first ?? parts[0]
                    let endStr = parts[1].trimmingCharacters(in: .whitespaces).components(separatedBy: " ").first ?? parts[1]
                    let start = parseTimestamp(startStr)
                    let end = parseTimestamp(endStr)
                    var bodyLines: [String] = []
                    var j = i + 1
                    while j < lines.count {
                        let nextLine = lines[j].trimmingCharacters(in: .whitespaces)
                        if nextLine.isEmpty || nextLine.contains("-->") { break }
                        bodyLines.append(nextLine)
                        j += 1
                    }
                    let body = bodyLines.joined(separator: "\n")
                        .replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression)
                        .trimmingCharacters(in: .whitespacesAndNewlines)
                    if !body.isEmpty && end > start {
                        cues.append(IosSubCue(startSec: start, endSec: end, text: body))
                    }
                    i = j
                    continue
                }
            }
            i += 1
        }
        return cues
    }

    private func parseTimestamp(_ raw: String) -> Double {
        let clean = raw.trimmingCharacters(in: .whitespaces).replacingOccurrences(of: ",", with: ".")
        let comps = clean.components(separatedBy: ":")
        if comps.count == 3 {
            return (Double(comps[0]) ?? 0) * 3600 + (Double(comps[1]) ?? 0) * 60 + (Double(comps[2]) ?? 0)
        } else if comps.count == 2 {
            return (Double(comps[0]) ?? 0) * 60 + (Double(comps[1]) ?? 0)
        }
        return Double(clean) ?? 0
    }

    private func saveProgress(forceCompleted: Bool) {
        guard !progressKey.isEmpty, let player = player else { return }
        let pos = CMTimeGetSeconds(player.currentTime())
        let dur = CMTimeGetSeconds(player.currentItem?.duration ?? .zero)
        guard pos.isFinite, dur.isFinite, dur > 0 else { return }
        let pct = forceCompleted ? 100 : min(100, max(0, Int((pos / dur) * 100)))
        let watched = forceCompleted || (dur - pos <= 20)
        onProgressUpdate?(progressKey, pct, Int(pos), Int(dur), watched)
    }

    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        gestureMode = 0
        gestureStartPoint = touch.location(in: view)
        if gestureStartPoint.x < view.bounds.width * 0.5 {
            gestureStartVal = UIScreen.main.brightness
        } else {
            gestureStartVal = CGFloat(AVAudioSession.sharedInstance().outputVolume)
        }
    }

    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        guard let touch = touches.first else { return }
        let p = touch.location(in: view)
        let w = max(1, view.bounds.width)
        let h = max(1, view.bounds.height)
        let dx = p.x - gestureStartPoint.x
        let dy = gestureStartPoint.y - p.y
        let inSafeY = gestureStartPoint.y >= h * 0.14 && gestureStartPoint.y <= h * 0.84
        let inLeft = gestureStartPoint.x >= 20 && gestureStartPoint.x <= w * 0.24
        let inRight = gestureStartPoint.x >= w * 0.76 && gestureStartPoint.x <= w - 20

        if gestureMode == 0 && inSafeY && (inLeft || inRight) && abs(dy) > 20 && abs(dy) > abs(dx) * 1.25 {
            gestureMode = inLeft ? 1 : 2
        }
        if gestureMode != 0 {
            let nextVal = min(1, max(0, gestureStartVal + dy / (h * 0.6)))
            hideHudWorkItem?.cancel()
            if gestureMode == 1 {
                UIScreen.main.brightness = max(0.04, nextVal)
                brightnessPctLabel.text = "\(Int(nextVal * 100))%"
                brightnessHudView.isHidden = false
                let trackH = brightnessTrackView.bounds.height > 10 ? brightnessTrackView.bounds.height : 128
                brightnessFillHeightConstraint?.constant = max(2, trackH * nextVal)
                brightnessHudView.layoutIfNeeded()
            } else {
                if let slider = hiddenVolumeView.subviews.compactMap({ $0 as? UISlider }).first {
                    slider.value = Float(nextVal)
                }
                volumePctLabel.text = "\(Int(nextVal * 100))%"
                volumeHudView.isHidden = false
                let trackH = volumeTrackView.bounds.height > 10 ? volumeTrackView.bounds.height : 128
                volumeFillHeightConstraint?.constant = max(2, trackH * nextVal)
                volumeHudView.layoutIfNeeded()
            }
            let item = DispatchWorkItem { [weak self] in
                self?.brightnessHudView.isHidden = true
                self?.volumeHudView.isHidden = true
            }
            hideHudWorkItem = item
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.9, execute: item)
        }
    }

    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if gestureMode != 0 {
            gestureMode = 0
            return
        }
        guard let touch = touches.first else { return }
        let p = touch.location(in: view)
        let dist = hypot(p.x - gestureStartPoint.x, p.y - gestureStartPoint.y)
        if dist > 18 { return }

        let now = Date().timeIntervalSince1970
        let w = view.bounds.width
        let tapSide = p.x < w * 0.42 ? -1 : (p.x > w * 0.58 ? 1 : 0)

        if tapSide != 0 && activeSeekSide == tapSide && (now - lastSeekEventTime) < 1.25 {
            singleTapWorkItem?.cancel()
            triggerMultiTapSeek(side: tapSide)
        } else if tapSide != 0 && tapSide == lastTapSide && (now - lastTapTime) < 0.52 {
            singleTapWorkItem?.cancel()
            lastTapTime = 0
            triggerMultiTapSeek(side: tapSide)
        } else if tapSide == 0 {
            singleTapWorkItem?.cancel()
            lastTapTime = 0
            lastTapSide = 0
            setControllerVisible(!isControllerVisible)
        } else {
            lastTapTime = now
            lastTapSide = tapSide
            singleTapWorkItem?.cancel()
            let item = DispatchWorkItem { [weak self] in
                guard let self = self, self.activeSeekSide == 0 else { return }
                self.setControllerVisible(!self.isControllerVisible)
            }
            singleTapWorkItem = item
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.36, execute: item)
        }
    }

    private func triggerMultiTapSeek(side: Int) {
        activeSeekSide = side
        lastSeekEventTime = Date().timeIntervalSince1970
        seekBy(side < 0 ? -10 : 10)
        if side < 0 {
            accumLeftSeek += 10
            leftSeekBadge.text = "« -\(accumLeftSeek)s"
            leftSeekBadge.isHidden = false
            hideLeftSeekWorkItem?.cancel()
            let item = DispatchWorkItem { [weak self] in
                self?.accumLeftSeek = 0
                if self?.activeSeekSide == -1 { self?.activeSeekSide = 0 }
                self?.leftSeekBadge.isHidden = true
            }
            hideLeftSeekWorkItem = item
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.1, execute: item)
        } else {
            accumRightSeek += 10
            rightSeekBadge.text = "+\(accumRightSeek)s »"
            rightSeekBadge.isHidden = false
            hideRightSeekWorkItem?.cancel()
            let item = DispatchWorkItem { [weak self] in
                self?.accumRightSeek = 0
                if self?.activeSeekSide == 1 { self?.activeSeekSide = 0 }
                self?.rightSeekBadge.isHidden = true
            }
            hideRightSeekWorkItem = item
            DispatchQueue.main.asyncAfter(deadline: .now() + 1.1, execute: item)
        }
    }

    func resourceLoader(_ resourceLoader: AVAssetResourceLoader, shouldWaitForLoadingOfRequestedResource loadingRequest: AVAssetResourceLoadingRequest) -> Bool {
        guard let reqUrl = loadingRequest.request.url,
              var comps = URLComponents(url: reqUrl, resolvingAgainstBaseURL: false) else {
            return false
        }
        if comps.scheme == "singularity-inline" {
            if let outData = inlineM3u8Text.data(using: .utf8) {
                if let info = loadingRequest.contentInformationRequest {
                    info.contentType = "application/vnd.apple.mpegurl"
                    info.isByteRangeAccessSupported = false
                    info.contentLength = Int64(outData.count)
                }
                loadingRequest.dataRequest?.respond(with: outData)
                loadingRequest.finishLoading()
                return true
            }
            return false
        }
        if comps.scheme == "singularity-hlss" {
            comps.scheme = "https"
        } else if comps.scheme == "singularity-hlsp" {
            comps.scheme = "http"
        } else {
            return false
        }
        guard let targetUrl = comps.url else { return false }
        var req = URLRequest(url: targetUrl)
        for (k, v) in activeStreamHeaders {
            req.setValue(v, forHTTPHeaderField: k)
        }
        URLSession.shared.dataTask(with: req) { data, response, error in
            if let error = error {
                loadingRequest.finishLoading(with: error)
                return
            }
            guard let data = data else {
                loadingRequest.finishLoading(with: NSError(domain: "SingularityHLS", code: -1))
                return
            }
            let baseUrl = response?.url ?? targetUrl
            var outData = data
            if let text = String(data: data, encoding: .utf8), text.trimmingCharacters(in: .whitespacesAndNewlines).hasPrefix("#EXTM3U") {
                let lines = text.components(separatedBy: .newlines)
                var resolved: [String] = []
                for line in lines {
                    let trimmed = line.trimmingCharacters(in: .whitespaces)
                    if trimmed.isEmpty || trimmed.hasPrefix("#") {
                        var updatedLine = line
                        if let range = updatedLine.range(of: "URI=\"") {
                            let after = updatedLine[range.upperBound...]
                            if let endQ = after.firstIndex(of: "\"") {
                                let rawUri = String(after[..<endQ])
                                if !rawUri.hasPrefix("http"), let abs = URL(string: rawUri, relativeTo: baseUrl)?.absoluteString {
                                    updatedLine.replaceSubrange(range.upperBound..<endQ, with: abs)
                                }
                            }
                        }
                        resolved.append(updatedLine)
                    } else if let abs = URL(string: trimmed, relativeTo: baseUrl)?.absoluteString {
                        resolved.append(abs)
                    } else {
                        resolved.append(line)
                    }
                }
                if let d = resolved.joined(separator: "\n").data(using: .utf8) {
                    outData = d
                }
            }
            if let info = loadingRequest.contentInformationRequest {
                info.contentType = "application/vnd.apple.mpegurl"
                info.isByteRangeAccessSupported = false
                info.contentLength = Int64(outData.count)
            }
            loadingRequest.dataRequest?.respond(with: outData)
            loadingRequest.finishLoading()
        }.resume()
        return true
    }
}
