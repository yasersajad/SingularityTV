import { useState, useEffect, useLayoutEffect, useRef, memo, useCallback, useMemo } from "react";
import { tmdbFetch, imgUrl, PLAYER_SOURCES, getSourceUrl, sourceSupportsProgress, sourceSkipsResetGuard, sourceProgressViaFrames, sourceIsAsync, sourceSupportsAnime, sourceIsAnimeCapable, getAnimeSourceUrl, fetchAnilistData, cleanAnilistDescription, isAnimeContent, ANIME_DEFAULT_SOURCE, NON_ANIME_DEFAULT_SOURCE, NEEDS_INTERCEPT, CLEAN_USER_AGENT, sourceUsesCleanUa, getNextNonAsyncSource } from "../utils/api";
import { PlayIcon, BookmarkIcon, BookmarkFillIcon, BackIcon, StarIcon, FilmIcon, DownloadIcon, WatchedIcon, TrailerIcon, RatingShieldIcon, RatingLockIcon, AlertIcon, SourceIcon, ShieldBlockIcon, PopOutIcon, CastIcon } from "../components/Icons";
import DownloadModal from "../components/DownloadModal";
import TrailerModal from "../components/TrailerModal";
import BlockedStatsModal from "../components/BlockedStatsModal";
import { useBlockedStats } from "../utils/useBlockedStats";
import MediaCard from "../components/MediaCard";
import { storage, STORAGE_KEYS, getFailoverSource, setFailoverSource, clearFailoverSource } from "../utils/storage";
import { fetchMovieRating, isRestricted, getAgeLimitSetting, getRatingCountry } from "../utils/ageRating";
import DownloadConfirmModal from "../components/DownloadConfirmModal";
import { useCredits } from "../utils/useCredits";
import { GAMEPAD_PLAYER_SCRIPT, GAMEPAD_EXIT_CHECK_JS, GAMEPAD_EXIT_RESET_JS, GAMEPAD_CLEANUP_JS } from "../utils/playerGamepadScript";
import { useSourceId } from "../utils/useSourceId";
import { setPlayerGamepadActive } from "../utils/gamepadPlayerState";
import HiAnimeLoader from "../components/HiAnimeLoader";
import StreamPlayerFrame from "../components/StreamPlayerFrame";
export default function MoviePage({
  item,
  apiKey,
  playerSettings,
  onSave,
  isSaved,
  onHistory,
  progress,
  saveProgress,
  onBack,
  onSettings,
  onDownloadStarted,
  watched,
  onMarkWatched,
  onMarkUnwatched,
  downloads,
  onGoToDownloads,
  onSelect,
  onOpenExoPlayer
}) {
  const [details, setDetails] = useState(null);
  const [playing, setPlaying] = useState(false);
  const [showDownload, setShowDownload] = useState(false);
  const [trailerKey, setTrailerKey] = useState(null);
  const [showTrailer, setShowTrailer] = useState(false);
  const [showDownloadConfirm, setShowDownloadConfirm] = useState(false);
  const [pendingDownload, setPendingDownload] = useState(false);
  const credits = useCredits("movie", item.id, apiKey);
  const [m3u8Url, setM3u8Url] = useState(null);
  const m3u8FoundRef = useRef(false);
  const autoExoLaunchedRef = useRef(null);
  const pendingFailoverRef = useRef(false);
  m3u8FoundRef.current = !!m3u8Url;
  const [interceptedSubs, setInterceptedSubs] = useState([]);
  const [playerSource, setPlayerSource] = useState(() => storage.get("playerSource") || NON_ANIME_DEFAULT_SOURCE);
  const playerAccentColor = playerSettings?.accentColor ?? null;
  const playerSubLang = playerSettings?.subtitleLang ?? null;
  const progressViaFrames = useMemo(() => sourceProgressViaFrames(playerSource), [playerSource]);
  const [showSourceMenu, setShowSourceMenu] = useState(false);
  const [dubMode, setDubMode] = useState(() => storage.get(STORAGE_KEYS.HIANIME_DUB_MODE) || "sub");
  const [anilistData, setAnilistData] = useState(null);
  const [menuPos, setMenuPos] = useState(null);
  const sourceRef = useRef(null);
  const playerWrapRef = useRef(null);
  const webviewRef = useRef(null);
  const saveProgressRef = useRef(saveProgress);
  saveProgressRef.current = saveProgress;
  const onMarkWatchedRef = useRef(onMarkWatched);
  onMarkWatchedRef.current = onMarkWatched;
  const [resolvedPlayerUrl, setResolvedPlayerUrl] = useState(null);
  const [resolvingUrl, setResolvingUrl] = useState(false);
  const [resolveError, setResolveError] = useState(null);
  const resolvingUrlRef = useRef(false);
  const resolvedPlayerUrlRef = useRef(null);
  const [collection, setCollection] = useState(null);
  const [webviewLoading, setWebviewLoading] = useState(false);
  const srcId = useSourceId(playerSource, "movie", item.id, apiKey);
  useEffect(() => {
    if (srcId.id && playing) setWebviewLoading(true);
  }, [srcId.id]);
  const [playerFullscreen, setPlayerFullscreen] = useState(false);
  const togglePlayerFullscreen = useCallback((forceState) => {
    setPlayerFullscreen(prev => {
      const next = typeof forceState === "boolean" ? forceState : !prev;
      if (next) {
        document.documentElement.setAttribute("data-player-fullscreen", "1");
        try { window.AndroidBridge?.setImmersiveMode?.(true); } catch {}
      } else {
        document.documentElement.removeAttribute("data-player-fullscreen");
      }
      return next;
    });
  }, []);
  useEffect(() => {
    window.__streambertExitFullscreen = () => { setPlaying(false); setPlayerFullscreen(false); document.documentElement.removeAttribute("data-player-fullscreen"); };
    return () => {
      if (window.__streambertExitFullscreen) delete window.__streambertExitFullscreen;
      document.documentElement.removeAttribute("data-player-fullscreen");
    };
  }, [togglePlayerFullscreen]);
  const [pipOpen, setPipOpen] = useState(false);
  const pipUrlRef = useRef(null);
  const pipWebContentsIdRef = useRef(null);
  const isAnime = useMemo(() => isAnimeContent(item, details), [item.id, details]);
  const playerDirectUrl = useMemo(() => {
    if (isAnime && sourceSupportsAnime(playerSource) && anilistData?.id) {
      const animeUrl = getAnimeSourceUrl(playerSource, anilistData.id, 1, dubMode);
      if (animeUrl) return animeUrl;
    }
    return getSourceUrl(playerSource, "movie", srcId.id, null, null, {}, playerAccentColor, playerSubLang);
  }, [isAnime, playerSource, anilistData, dubMode, srcId.id, playerAccentColor, playerSubLang]);
  const [downloaderFolder, setDownloaderFolder] = useState(() => storage.get("downloaderFolder") || "");
  const {
    sessionTotal: blockedSession,
    alltimeTotal: blockedAlltime,
    showModal: showBlockedModal,
    setShowModal: setShowBlockedModal,
    getSessionDomains: getBlockedDomains
  } = useBlockedStats(item.id);
  const [rating, setRating] = useState({
    cert: null,
    minAge: null
  });
  const ageLimitSetting = useMemo(() => getAgeLimitSetting(storage), []);
  const ratingCountry = useMemo(() => getRatingCountry(storage), []);
  const restricted = isRestricted(rating.minAge, ageLimitSetting);
  const progressKey = `movie_${item.id}`;
  useEffect(() => {
    if (!item?.id) return;
    const im = details?.imdb_id || (String(item.id).startsWith("tt") ? String(item.id) : "");
    const tm = String(details?.id || item.id).startsWith("tt") ? "" : String(details?.id || item.id);
    if (!im && !tm) return;
    window.electron?.preprobeStream?.(JSON.stringify({
      imdbId: im,
      tmdbId: tm,
      mediaType: "movie",
      season: 1,
      episode: 1,
      progressKey
    }));
  }, [item?.id, details?.imdb_id, details?.id, progressKey]);
  const pct = progress[progressKey] || 0;
  const isWatched = !!watched?.[progressKey];
  const hasProgress = pct > 0;
  const d = details || item;
  const title = d.title || d.name;
  const year = (d.release_date || "").slice(0, 4);
  const mediaName = `${title}${year ? " (" + year + ")" : ""}`;
  const {
    watchedSecs,
    totalSecs,
    displayPct,
    progressLabel
  } = useMemo(() => {
    const watchedSecs = storage.get("dlTime_" + progressKey) || 0;
    const totalSecs = d?.runtime ? d.runtime * 60 : 0;
    const derivedPct = watchedSecs > 0 && totalSecs > 0 ? Math.floor(watchedSecs / totalSecs * 100) : 0;
    const displayPct = pct > 0 ? pct : derivedPct;
    const fmt = s => {
      const h = Math.floor(s / 3600);
      const m = Math.floor(s % 3600 / 60);
      const sec = Math.floor(s % 60);
      return h > 0 ? `${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}` : `${m}:${String(sec).padStart(2, "0")}`;
    };
    const progressLabel = watchedSecs > 0 && totalSecs > 0 ? `${fmt(watchedSecs)} / ${fmt(totalSecs)}` : watchedSecs > 0 ? fmt(watchedSecs) : displayPct > 0 ? `${displayPct}%` : null;
    return {
      watchedSecs,
      totalSecs,
      displayPct,
      progressLabel
    };
  }, [progressKey, pct, d?.runtime]);
  const [watchedThreshold] = useState(() => storage.get("watchedThreshold") ?? 20);
  const autoMarkedRef = useRef(false);
  const autoPlayTriggeredRef = useRef(null);
  const lastKnownTimeRef = useRef(0);
  const seekBackCooldownRef = useRef(0);
  useEffect(() => {
    let mounted = true;
    tmdbFetch(`/movie/${item.id}`, apiKey).then(d => {
      if (mounted) setDetails(d);
    }).catch(() => {
      if (mounted) setDetails(item);
    });
    return () => {
      mounted = false;
    };
  }, [item.id, apiKey]);
  useEffect(() => {
    let mounted = true;
    fetchMovieRating(item.id, apiKey, ratingCountry).then(r => {
      if (mounted) setRating(r);
    });
    return () => {
      mounted = false;
    };
  }, [item.id, apiKey, ratingCountry]);
  useEffect(() => {
    let mounted = true;
    tmdbFetch(`/movie/${item.id}/videos`, apiKey).then(data => {
      if (!mounted) return;
      const videos = data.results || [];
      const trailer = videos.find(v => v.type === "Trailer" && v.site === "YouTube") || videos.find(v => v.site === "YouTube");
      if (trailer) setTrailerKey(trailer.key);
    }).catch(() => {});
    return () => {
      mounted = false;
    };
  }, [item.id, apiKey]);
  useEffect(() => {
    setCollection(null);
    if (!details?.belongs_to_collection?.id) return;
    let mounted = true;
    tmdbFetch(`/collection/${details.belongs_to_collection.id}`, apiKey).then(data => {
      if (!mounted) return;
      const parts = (data.parts || []).map(p => ({
        ...p,
        media_type: "movie"
      })).sort((a, b) => (a.release_date || "").localeCompare(b.release_date || ""));
      if (parts.length > 1) {
        setCollection({
          name: data.name,
          parts
        });
      }
    }).catch(() => {});
    return () => {
      mounted = false;
    };
  }, [details?.belongs_to_collection?.id, apiKey]);
  useEffect(() => {
    setM3u8Url(null);
    setInterceptedSubs([]);
    setShowSourceMenu(false);
    setAnilistData(null);
    resolvedPlayerUrlRef.current = null;
    setResolvedPlayerUrl(null);
    resolvingUrlRef.current = false;
    setResolvingUrl(false);
    setResolveError(null);
    setWebviewLoading(true);
  }, [item.id, playerSource, dubMode]);
  useEffect(() => {
    const savedSrc = storage.get("playerSource");
    if (savedSrc && savedSrc !== playerSource) {
      setPlayerSource(savedSrc);
    }
    const h = window.electron?.onPreferredSourceUpdated?.(srcId => {
      if (srcId && typeof srcId === "string") {
        storage.set("playerSource", srcId);
        setPlayerSource(prev => prev !== srcId ? srcId : prev);
      }
    });
    return () => {
      if (h) window.electron?.offPreferredSourceUpdated?.(h);
    };
  }, [item.id]);
  useEffect(() => {
    let mounted = true;
    if (isAnime) {
      fetchAnilistData(item.title || item.name, "ANIME", item.id).then(data => {
        if (mounted && data) setAnilistData(data);
      });
      if (!sourceIsAnimeCapable(playerSource)) {
        const saved = storage.get("playerSource");
        setPlayerSource(sourceIsAnimeCapable(saved) ? saved : ANIME_DEFAULT_SOURCE);
      }
    } else {
      const currentSrc = PLAYER_SOURCES.find(s => s.id === playerSource);
      if (currentSrc?.tag === "ANIME") {
        const saved = storage.get("playerSource");
        const savedSrc = PLAYER_SOURCES.find(s => s.id === saved);
        setPlayerSource(savedSrc?.tag !== "ANIME" ? saved : NON_ANIME_DEFAULT_SOURCE);
      }
    }
    return () => {
      mounted = false;
    };
  }, [item.id, isAnime]);
  useEffect(() => {
    if (!playing) return;
    const epKey = `movie_${item.id}_${dubMode}`;
    if (sourceIsAsync(playerSource)) {
      const cached = getFailoverSource(epKey);
      if (cached && cached !== playerSource) {
        setM3u8Url(null);
        setInterceptedSubs([]);
        resolvedPlayerUrlRef.current = null;
        setResolvedPlayerUrl(null);
        resolvingUrlRef.current = false;
        setResolvingUrl(false);
        setResolveError(null);
        setPlayerSource(cached);
        return;
      }
    }
    if (!sourceIsAsync(playerSource)) return;
    if (resolvedPlayerUrlRef.current || resolvingUrlRef.current) return;
    resolvingUrlRef.current = true;
    setResolvingUrl(true);
    setResolveError(null);
    const startTime = storage.get("dlTime_" + progressKey) || 0;
    let mounted = true;
    window.electron.resolveHiAnime({
      title,
      seasonNumber: 1,
      episodeNumber: 1,
      isMovie: true,
      translationType: dubMode
    }).then(res => {
      if (!mounted) return;
      if (res?.ok && res.url) {
        clearFailoverSource(epKey);
        if (res.isDirectMp4 !== undefined) {
          window.electron.setPlayerVideo({
            url: res.url,
            referer: res.referer || "https://hianime.at/",
            subtitle: res.subtitle || null,
            startTime
          }).then(r => {
            if (!mounted) return;
            resolvedPlayerUrlRef.current = r.playerUrl;
            setResolvedPlayerUrl(r.playerUrl);
            setM3u8Url(res.url);
          }).catch(() => {
            if (mounted) setResolveError("Failed to start local player");
          });
        } else {
          resolvedPlayerUrlRef.current = res.url;
          setResolvedPlayerUrl(res.url);
        }
      } else {
        const next = getNextNonAsyncSource(playerSource);
        if (next) {
          setFailoverSource(epKey, next);
          setM3u8Url(null);
          setInterceptedSubs([]);
          resolvedPlayerUrlRef.current = null;
          setResolvedPlayerUrl(null);
          setResolveError(null);
          setPlayerSource(next);
        } else {
          setResolveError(res?.error || "Movie not found on HiAnime");
        }
      }
    }).catch(e => {
      if (mounted) setResolveError(e.message || "Error");
    }).finally(() => {
      if (mounted) {
        resolvingUrlRef.current = false;
        setResolvingUrl(false);
      }
    });
    return () => {
      mounted = false;
    };
  }, [playing, playerSource, dubMode]);
  useEffect(() => {
    if (!window.electron) return;
    const handler = window.electron.onM3u8Found(url => {
      setM3u8Url(prev => prev !== url ? url : prev);
    });
    return () => window.electron.offM3u8Found(handler);
  }, []);

  useEffect(() => {
    if (!playing || m3u8Url) return;
    const switchNext = () => {
      if (m3u8FoundRef.current) return;
      const order = ["multiembed"];
      const idx = order.indexOf(playerSource);
      const nextSrc = order[(idx + 1) % order.length];
      try {
        if (webviewRef.current) webviewRef.current.src = "about:blank";
      } catch {}
      if (nextSrc && nextSrc !== playerSource) {
        setPlayerSource(nextSrc);
      }
    };
    const chHandler = window.electron?.onServerChallenge?.(() => switchNext());
    const t = setTimeout(switchNext, 4200);
    return () => {
      clearTimeout(t);
      if (chHandler) window.electron?.offServerChallenge?.(chHandler);
    };
  }, [playing, m3u8Url, playerSource]);

  useEffect(() => {
    const h = false && window.electron?.onNeedNextServer?.(data => {
      const cur = data?.currentSource || playerSource;
      const order = ["multiembed"];
      const idx = order.indexOf(cur);
      const nextSrc = order[(idx + 1) % order.length];
      pendingFailoverRef.current = true;
      setM3u8Url(null);
      setPlaying(true);
      try {
        if (webviewRef.current) webviewRef.current.src = "about:blank";
      } catch {}
      if (nextSrc) setPlayerSource(nextSrc);
    });
    return () => {
      if (h) window.electron?.offNeedNextServer?.(h);
    };
  }, [playerSource]);
  useEffect(() => {
    if (!playing || !m3u8Url) return;
    if (pendingDownload) {
      setPendingDownload(false);
      setPlaying(false);
      setShowDownload(true);
      return;
    }
    const launchKey = `movie_${item.id}_${playerSource}`;
    if (!pendingFailoverRef.current && autoExoLaunchedRef.current === launchKey) return;
    const timer = setTimeout(() => {
      autoExoLaunchedRef.current = launchKey;
      if (playerSource && !sourceIsAsync(playerSource)) {
        storage.set("playerSource", playerSource);
      }
      if (window.AndroidBridge?.openExoPlayer) {
        if (pendingFailoverRef.current) {
          pendingFailoverRef.current = false;
          window.AndroidBridge?.deliverNextServerStream?.(m3u8Url, playerSource);
          return;
        }
        const startSec = isWatched || pct >= 90 ? 0 : (storage.get("dlTime_" + progressKey) || 0);
        const payload = {
          url: m3u8Url,
          title: mediaName || title,
          currentSource: playerSource,
          startTimeSec: startSec,
          subtitles: interceptedSubs,
          progressKey: progressKey,
          imdbId: item.imdb_id || item.id,
          tmdbId: item.numeric_id || item.tmdb_id || (!String(item.id || "").startsWith("tt") ? String(item.id) : ""),
          mediaType: "movie",
          subTextColor: storage.get("subtitleTextColor") || "#FFFFFF",
          subBgStyle: storage.get("subtitleBgStyle") || "dark",
          subFontSizeSp: Number(storage.get("subtitleFontSizeSp") || 22),
          preferredSubLang: playerSubLang || "ar"
        };
        try {
          if (webviewRef.current) webviewRef.current.src = "about:blank";
        } catch {}
        window.AndroidBridge.openExoPlayer(JSON.stringify(payload));
        setPlaying(false);
        setPlayerFullscreen(false);
        document.documentElement.removeAttribute("data-player-fullscreen");
      }
    }, 300);
    return () => clearTimeout(timer);
  }, [playing, m3u8Url, item.id, playerSource, pendingDownload]);
  useEffect(() => {
    if (!showSourceMenu) return;
    const close = () => setShowSourceMenu(false);
    window.addEventListener("scroll", close, {
      capture: true,
      passive: true
    });
    const handleClick = e => {
      if (sourceRef.current?.contains(e.target) || e.target.closest(".source-dropdown")) return;
      close();
    };
    document.addEventListener("mousedown", handleClick);
    return () => {
      window.removeEventListener("scroll", close, {
        capture: true
      });
      document.removeEventListener("mousedown", handleClick);
    };
  }, [showSourceMenu]);
  useEffect(() => {
    if (!window.electron) return;
    const handler = window.electron.onSubtitleFound(({
      url,
      lang
    }) => {
      if (!url || !url.toLowerCase().includes(".vtt")) return;
      setInterceptedSubs(prev => {
        const filtered = prev.filter(s => s.lang !== lang);
        return [...filtered, {
          url,
          lang: lang || "unknown"
        }];
      });
    });
    return () => window.electron.offSubtitleFound(handler);
  }, []);
  useEffect(() => {
    autoMarkedRef.current = false;
    lastKnownTimeRef.current = 0;
    seekBackCooldownRef.current = 0;
  }, [item.id, isWatched]);
  useEffect(() => {
    if (playing) setWebviewLoading(true);
    try {
      window.AndroidBridge?.setImmersiveMode?.(!!playing);
    } catch {}
  }, [playing]);
  useLayoutEffect(() => {
    if (playing) return;
    const wv = webviewRef.current;
    if (wv) {
      try {
        wv.src = "about:blank";
      } catch {}
    }
  }, [playing]);
  useEffect(() => {
    return () => {
      window.electron?.playerStopped?.();
    };
  }, []);
  const [gamepadEnabled, setGamepadEnabled] = useState(() => storage.get(STORAGE_KEYS.GAMEPAD_ENABLED) !== false);
  useEffect(() => {
    const handler = () => setGamepadEnabled(storage.get(STORAGE_KEYS.GAMEPAD_ENABLED) !== false);
    window.addEventListener("streambert:gamepad-settings-changed", handler);
    return () => window.removeEventListener("streambert:gamepad-settings-changed", handler);
  }, []);
  useEffect(() => {
    setPlayerGamepadActive(gamepadEnabled && playing);
    return () => setPlayerGamepadActive(false);
  }, [playing, gamepadEnabled]);
  useEffect(() => {
    const wv = webviewRef.current;
    if (!wv || !playing || !gamepadEnabled) return;
    const inject = () => {
      wv.executeJavaScript(GAMEPAD_PLAYER_SCRIPT).catch(() => {});
    };
    wv.addEventListener("dom-ready", inject);
    try {
      inject();
    } catch {}
    const exitPoll = setInterval(async () => {
      try {
        const requested = await wv.executeJavaScript(GAMEPAD_EXIT_CHECK_JS);
        if (requested) {
          wv.executeJavaScript(GAMEPAD_EXIT_RESET_JS).catch(() => {});
          setPlaying(false);
        }
      } catch {}
    }, 250);
    return () => {
      wv.removeEventListener("dom-ready", inject);
      clearInterval(exitPoll);
      try {
        wv.executeJavaScript(GAMEPAD_CLEANUP_JS);
      } catch {}
    };
  }, [playing, gamepadEnabled, playerSource]);
  useEffect(() => {
    if (!playing) return;
    const wv = webviewRef.current;
    if (!wv) return;
    const done = () => {
      setWebviewLoading(false);
      playerWrapRef.current?.scrollIntoView({ behavior: "auto", block: "center" });
      setTimeout(() => {
        if (!m3u8FoundRef.current) tapCenterOfPlayer();
      }, 1400);
      setTimeout(() => {
        if (!m3u8FoundRef.current) tapCenterOfPlayer();
      }, 2800);
    };
    wv.addEventListener("did-finish-load", done);
    wv.addEventListener("did-fail-load", done);
    return () => {
      wv.removeEventListener("did-finish-load", done);
      wv.removeEventListener("did-fail-load", done);
    };
  }, [playing, playerSource, item.id]);
  useEffect(() => {
    if (!playing || !sourceSupportsProgress(playerSource)) return;
    let interval = null;
    const timer = setTimeout(() => {
      interval = setInterval(async () => {
        try {
          const wv = webviewRef.current;
          if (!wv) return;
          let result;
          if (pipWebContentsIdRef.current != null && window.electron?.queryVideoProgress) {
            result = await window.electron.queryVideoProgress(pipWebContentsIdRef.current);
          } else if (progressViaFrames && window.electron?.queryVideoProgress) {
            result = await window.electron.queryVideoProgress(wv.getWebContentsId());
          } else {
            result = await wv.executeJavaScript(`
              (() => {
                const v = document.querySelector('video')
                if (!v || !v.duration || v.duration === Infinity || v.paused) return null
                // Re-attach seek tracker if video element was recreated (e.g. quality change)
                if (!v._seekTracked) {
                  v._seekTracked = true
                  v.addEventListener('seeked', () => {
                    v._lastUserSeek = Date.now()
                    v._lastUserSeekTo = v.currentTime
                  })
                }
                return {
                  currentTime: v.currentTime,
                  duration: v.duration,
                  recentUserSeek: v._lastUserSeek ? (Date.now() - v._lastUserSeek < 6000) : false,
                  lastUserSeekTo: v._lastUserSeekTo ?? null,
                }
              })()
            `);
          }
          if (result && result.duration > 0) {
            const ct = result.currentTime;
            const now = Date.now();
            if (!sourceSkipsResetGuard(playerSource) && lastKnownTimeRef.current > 30 && ct <= 5 && !result.recentUserSeek) {
              if (now > seekBackCooldownRef.current) {
                const seekTo = lastKnownTimeRef.current;
                seekBackCooldownRef.current = now + 8000;
                try {
                  await wv.executeJavaScript(`
                    (() => {
                      const v = document.querySelector('video')
                      if (v) v.currentTime = ${seekTo}
                    })()
                  `);
                } catch {}
              }
              return;
            }
            if (result.recentUserSeek && result.lastUserSeekTo !== null) {
              lastKnownTimeRef.current = result.lastUserSeekTo;
            } else {
              lastKnownTimeRef.current = ct;
            }
            const p = Math.floor(ct / result.duration * 100);
            saveProgressRef.current(progressKey, Math.min(p, 100));
            storage.set("dlTime_" + progressKey, Math.floor(ct));
            const remaining = result.duration - ct;
            if (!autoMarkedRef.current && remaining <= watchedThreshold && remaining >= 0) {
              autoMarkedRef.current = true;
              onMarkWatchedRef.current?.(progressKey);
            }
          }
        } catch {}
      }, 5000);
    }, 3000);
    return () => {
      clearTimeout(timer);
      clearInterval(interval);
    };
  }, [playing, progressKey, watchedThreshold, playerSource, progressViaFrames]);
  const tapCenterOfPlayer = useCallback(() => {
    try {
      const el = playerWrapRef.current;
      if (!el || !window.AndroidBridge?.tapPlayerCenter) return;
      const r = el.getBoundingClientRect();
      if (r.width <= 0 || r.height <= 0) return;
      const rx = (r.left + r.width / 2) / Math.max(1, window.innerWidth);
      const ry = (r.top + r.height / 2) / Math.max(1, window.innerHeight);
      if (ry > 0.05 && ry < 0.95) {
        window.AndroidBridge.tapPlayerCenter(rx, ry);
      }
    } catch {}
  }, []);

  const handlePlay = useCallback(() => {
    if (isWatched || pct >= 90) {
      onMarkUnwatched?.(progressKey);
      saveProgress?.(progressKey, 0);
      storage.set("dlTime_" + progressKey, 0);
    }
    if (window.AndroidBridge?.openExoPlayer && !sourceIsAsync(playerSource)) {
      const startSec = isWatched || pct >= 90 ? 0 : (storage.get("dlTime_" + progressKey) || 0);
      const tmdbVal = item.numeric_id || item.tmdb_id || (!String(item.id || "").startsWith("tt") ? String(item.id) : "");
      const payload = {
        url: "",
        title: mediaName || title,
        currentSource: playerSource,
        startTimeSec: startSec,
        subtitles: [],
        progressKey: progressKey,
        imdbId: item.imdb_id || item.id,
        tmdbId: tmdbVal,
        mediaType: "movie",
        subTextColor: storage.get("subtitleTextColor") || "#FFFFFF",
        subBgStyle: storage.get("subtitleBgStyle") || "dark",
        subFontSizeSp: Number(storage.get("subtitleFontSizeSp") || 22),
        preferredSubLang: playerSubLang || "ar"
      };
      onHistory?.({
        ...d,
        media_type: "movie"
      });
      window.AndroidBridge.openExoPlayer(JSON.stringify(payload));
      return;
    }
    autoExoLaunchedRef.current = null;
    setM3u8Url(null);
    setInterceptedSubs([]);
    setPlaying(true);
    onHistory({
      ...d,
      media_type: "movie"
    });
    setTimeout(() => {
      playerWrapRef.current?.scrollIntoView({
        behavior: "smooth",
        block: "center"
      });
    }, 100);
  }, [d, onHistory, isWatched, pct, progressKey, onMarkUnwatched, saveProgress, playerSource, mediaName, title, item.imdb_id, item.id, item.numeric_id, item.tmdb_id, playerSubLang]);
  useEffect(() => {
    if (!playing) return;
    if (!NEEDS_INTERCEPT.includes(playerSource)) return;
    const enterH = window.electron?.onWebviewEnterFullscreen?.(() => {
      setPlayerFullscreen(true);
      document.documentElement.setAttribute("data-player-fullscreen", "1");
    });
    const leaveH = window.electron?.onWebviewLeaveFullscreen?.(() => {
      setPlayerFullscreen(false);
      document.documentElement.removeAttribute("data-player-fullscreen");
      if (document.fullscreenElement) document.exitFullscreen?.();
    });
    return () => {
      if (enterH) window.electron?.offWebviewEnterFullscreen?.(enterH);
      if (leaveH) window.electron?.offWebviewLeaveFullscreen?.(leaveH);
      document.documentElement.removeAttribute("data-player-fullscreen");
    };
  }, [playing, playerSource]);
  useEffect(() => {
    if (!playing) return;
    const openH = window.electron?.onPipOpened?.(async () => {
      setPipOpen(true);
      pipWebContentsIdRef.current = (await window.electron.getPipWebContentsId?.()) ?? null;
    });
    const closeH = window.electron?.onPipClosed?.(() => {
      pipUrlRef.current = null;
      pipWebContentsIdRef.current = null;
      setPipOpen(false);
    });
    return () => {
      if (openH) window.electron?.offPipOpened?.(openH);
      if (closeH) window.electron?.offPipClosed?.(closeH);
    };
  }, [playing]);
  const handleSetDownloaderFolder = useCallback(folder => {
    setDownloaderFolder(folder);
    storage.set("downloaderFolder", folder);
  }, []);
  const displayOverview = isAnime && anilistData?.description ? cleanAnilistDescription(anilistData.description) : d.overview;
  const displayScore = isAnime && anilistData?.averageScore ? (anilistData.averageScore / 10).toFixed(1) : d.vote_average > 0 ? d.vote_average.toFixed(1) : null;
  const displayGenres = isAnime && anilistData?.genres?.length ? anilistData.genres.map((g, i) => ({
    id: i,
    name: g
  })) : d.genres || [];
  const isUnreleased = useMemo(() => {
    if (!d.release_date) return false;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    return new Date(d.release_date) > today;
  }, [d.release_date]);


  const movieDownload = (downloads || []).find(dl => dl.mediaType === "movie" && (dl.tmdbId === item.id || dl.mediaId === item.id) && (dl.status === "completed" || dl.status === "local" || dl.status === "downloading"));
  return React.createElement("div", {
    className: "fade-in"
  }, React.createElement("button", {
    className: "detail-floating-back",
    onClick: onBack,
    "aria-label": "Back"
  }, React.createElement(BackIcon, null)), React.createElement("div", {
    className: "detail-hero"
  }, React.createElement("div", {
    className: "detail-bg",
    style: {
      backgroundImage: `url(${imgUrl(d.backdrop_path, "w1280")})`
    }
  }), React.createElement("div", {
    className: "detail-gradient"
  }), React.createElement("div", {
    className: "detail-content"
  }, React.createElement("div", {
    className: "detail-poster",
    style: {
      position: "relative"
    }
  }, d.poster_path ? React.createElement("img", {
    src: imgUrl(d.poster_path),
    alt: title,
    loading: "lazy"
  }) : React.createElement("div", {
    style: {
      width: "100%",
      height: "100%",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
      color: "var(--text3)"
    }
  }, React.createElement(FilmIcon, null)), isWatched && React.createElement("div", {
    className: "detail-watched-badge"
  }, React.createElement(WatchedIcon, {
    size: 36
  }))), React.createElement("div", {
    className: "detail-info"
  }, React.createElement("div", {
    className: "detail-type"
  }, "Movie"), React.createElement("div", {
    className: "detail-title"
  }, title), React.createElement("div", {
    className: "genres"
  }, displayGenres.map(g => React.createElement("span", {
    key: g.id,
    className: "genre-tag"
  }, g.name))), React.createElement("div", {
    className: "detail-meta"
  }, displayScore && React.createElement("span", {
    className: "detail-rating"
  }, React.createElement(StarIcon, null), " ", displayScore), year && React.createElement("span", null, year), d.runtime && React.createElement("span", null, d.runtime, " min"), d.original_language && React.createElement("span", null, d.original_language?.toUpperCase())), rating.cert && React.createElement("div", {
    className: `age-rating-pill${restricted ? " age-rating-pill--restricted" : ""}`
  }, restricted ? React.createElement(RatingLockIcon, AlertIcon, {
    size: 13
  }) : React.createElement(RatingShieldIcon, {
    size: 13
  }), React.createElement("span", {
    className: "age-rating-pill-cert"
  }, rating.cert), restricted && React.createElement("span", {
    className: "age-rating-pill-label"
  }, "Inappropriate for your age setting")), React.createElement("p", {
    className: "detail-overview"
  }, displayOverview), !isWatched && displayPct > 0 && React.createElement("div", {
    className: "progress-bar-row",
    style: {
      marginBottom: 12
    }
  }, React.createElement("div", {
    className: "progress-bar-outer"
  }, React.createElement("div", {
    className: "progress-bar-fill",
    style: {
      width: `${Math.min(displayPct, 100)}%`
    }
  })), React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, progressLabel)), React.createElement("div", {
    className: "detail-actions"
  }, isUnreleased ? React.createElement("button", {
    className: "btn btn-primary btn-restricted",
    disabled: true,
    title: "This movie has not been released yet"
  }, React.createElement(RatingLockIcon, { size: 14 }), " Unreleased") : restricted ? React.createElement("button", {
    className: "btn btn-primary btn-restricted",
    disabled: true,
    title: "Inappropriate for your age rating setting"
  }, React.createElement(RatingLockIcon, { size: 14 }), " Restricted") : React.createElement("button", {
    className: "btn btn-primary",
    onClick: handlePlay
  }, React.createElement(PlayIcon, null), " ", (() => {
    const savedSec = Number(storage.get("dlTime_" + progressKey) || 0);
    if (savedSec > 5 && !isWatched) {
      const h = Math.floor(savedSec / 3600);
      const m = Math.floor((savedSec % 3600) / 60);
      const s = Math.floor(savedSec % 60);
      const t = h > 0 ? `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}` : `${m}:${String(s).padStart(2, "0")}`;
      return `Continue ${t}`;
    }
    return playing ? "Loading..." : "Play";
  })()), trailerKey && (restricted ? React.createElement("button", {
    className: "btn btn-secondary btn-restricted",
    disabled: true,
    title: "Inappropriate for your age rating setting"
  }, React.createElement(RatingLockIcon, { size: 14 }), " Trailer") : React.createElement("button", {
    className: "btn btn-secondary",
    onClick: () => setShowTrailer(true)
  }, React.createElement(TrailerIcon, null), " Trailer")), React.createElement("button", {
    className: "btn btn-secondary",
    onClick: () => movieDownload ? onGoToDownloads?.(movieDownload.id) : setShowDownloadConfirm(true)
  }, React.createElement(DownloadIcon, null), " ", movieDownload ? (movieDownload.status === "downloading" ? "Downloading…" : "Downloaded") : (pendingDownload ? "Preparing…" : "Download")), React.createElement("button", {
    className: "btn btn-secondary",
    onClick: onSave
  }, isSaved ? React.createElement(BookmarkFillIcon, null) : React.createElement(BookmarkIcon, null), isSaved ? "Saved" : "Save"), React.createElement("button", {
    className: "btn btn-ghost",
    onClick: onBack
  }, React.createElement(BackIcon, null), " Back"))))), playing && !restricted && !isUnreleased && React.createElement("div", {
    className: "section"
  }, React.createElement("div", {
    className: "player-wrap player-wrap--fullscreen player-wrap--silent-exo",
    ref: playerWrapRef
  }, webviewLoading && !resolveError && React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 10,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      background: "rgba(0,0,0,0.75)",
      pointerEvents: "none",
      gap: 14,
      borderRadius: "inherit"
    }
  }, sourceIsAsync(playerSource) ? React.createElement(HiAnimeLoader, {
    what: "movie",
    playerStarting: !resolvingUrl && !!resolvedPlayerUrl
  }) : React.createElement(React.Fragment, null, React.createElement("div", {
    className: "spinner"
  }), React.createElement("span", {
    style: {
      fontSize: 14,
      color: "var(--text2)"
    }
  }, `Loading ${PLAYER_SOURCES.find(s => s.id === playerSource)?.label ?? "source"}…`))), sourceIsAsync(playerSource) && resolveError && !resolvingUrl && React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 10,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      background: "rgba(0,0,0,0.85)",
      gap: 10,
      borderRadius: "inherit"
    }
  }, React.createElement("span", {
    style: {
      fontSize: 28
    }
  }, React.createElement(AlertIcon, { size: 28 })), React.createElement("span", {
    style: {
      fontSize: 14,
      color: "var(--text2)"
    }
  }, "Movie not found on HiAnime"), React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, resolveError), React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, "Try a different source, or switch sub/dub.")), srcId.error && React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 11,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      background: "rgba(0,0,0,0.85)",
      gap: 10,
      borderRadius: "inherit"
    }
  }, React.createElement("span", {
    style: {
      fontSize: 28
    }
  }, React.createElement(AlertIcon, { size: 28 })), React.createElement("span", {
    style: {
      fontSize: 14,
      color: "var(--text2)"
    }
  }, "Could not resolve the ", srcId.idLabel, " for this title"), React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, srcId.error, ". Try a different source.")), pipOpen && React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 20,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      background: "rgba(0,0,0,0.92)",
      gap: 16,
      borderRadius: "inherit"
    }
  }, React.createElement(PopOutIcon, {
    size: 36
  }), React.createElement("span", {
    style: {
      fontSize: 15,
      color: "var(--text1)",
      fontWeight: 600
    }
  }, "Playing in pop-out window"), React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text2)",
      textAlign: "center",
      maxWidth: 260
    }
  }, "Closing the pop-out will reload the player here."), React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => window.electron?.closePipWindow?.(),
    style: {
      marginTop: 4
    }
  }, "Close pop-out & return")), React.createElement(StreamPlayerFrame, {
    ref: webviewRef,
    key: sourceUsesCleanUa(playerSource) ? "ua-clean" : "ua-default",
    useragent: sourceUsesCleanUa(playerSource) ? CLEAN_USER_AGENT : undefined,
    src: pipOpen ? "about:blank" : sourceIsAsync(playerSource) ? resolvedPlayerUrl || "about:blank" : playerDirectUrl || "about:blank",
    partition: "persist:player",
    allowpopups: "false",
    sandbox: "allow-scripts allow-same-origin allow-forms",
    style: {
      position: "absolute",
      inset: 0,
      width: "100%",
      height: "100%",
      border: "none",
      visibility: sourceIsAsync(playerSource) && !resolvedPlayerUrl ? "hidden" : "visible"
    }
  }), React.createElement("div", {
    className: "player-overlay-group"
  }, React.createElement("button", {
    ref: sourceRef,
    className: "player-overlay-btn",
    onClick: () => {
      const rect = sourceRef.current?.getBoundingClientRect();
      if (rect) setMenuPos({
        top: rect.bottom + 6,
        left: rect.left
      });
      setShowSourceMenu(v => !v);
    },
    title: "Change source"
  }, React.createElement(SourceIcon, null), PLAYER_SOURCES.find(s => s.id === playerSource)?.label ?? "Source"), (sourceIsAsync(playerSource) || isAnime && sourceSupportsAnime(playerSource)) && React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => {
      const next = dubMode === "sub" ? "dub" : "sub";
      setDubMode(next);
      storage.set(STORAGE_KEYS.HIANIME_DUB_MODE, next);
      setM3u8Url(null);
      setInterceptedSubs([]);
      resolvedPlayerUrlRef.current = null;
      setResolvedPlayerUrl(null);
      resolvingUrlRef.current = false;
      setResolvingUrl(false);
      setResolveError(null);
    },
    title: "Toggle Sub/Dub"
  }, dubMode === "sub" ? "SUB" : "DUB"), React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => {
      setShowSourceMenu(false);
      setShowBlockedModal(true);
    },
    title: "Blocked ads & trackers"
  }, React.createElement(ShieldBlockIcon, null), blockedSession > 0 && React.createElement("span", {
    className: "player-blocked-badge"
  }, blockedSession)), m3u8Url && React.createElement("button", {
    className: "player-overlay-btn",
    style: {
      background: "rgba(229,9,20,0.88)",
      borderColor: "var(--red)"
    },
    onClick: () => {
      const pk = typeof progressKey !== "undefined" ? progressKey : currentProgressKey;
      const startSec = isWatched || pct >= 90 ? 0 : (storage.get("dlTime_" + pk) || 0);
      const payload = {
        url: m3u8Url,
        title: mediaName || title,
        currentSource: playerSource,
        startTimeSec: startSec,
        subtitles: interceptedSubs,
        progressKey: typeof progressKey !== "undefined" ? progressKey : currentProgressKey,
        imdbId: item.imdb_id || item.id,
        mediaType: "movie",
        subTextColor: storage.get("subtitleTextColor") || "#FFFFFF",
          subBgStyle: storage.get("subtitleBgStyle") || "dark",
          subFontSizeSp: Number(storage.get("subtitleFontSizeSp") || 22),
          preferredSubLang: playerSubLang || "ar"
      };
      if (window.AndroidBridge?.openExoPlayer) {
        window.AndroidBridge.openExoPlayer(JSON.stringify(payload));
        setPlaying(false);
        setPlayerFullscreen(false);
        document.documentElement.removeAttribute("data-player-fullscreen");
      } else {
        onOpenExoPlayer?.(payload);
      }
    },
    title: "Play stream in Native Media3 ExoPlayer"
  }, "\u25B6 ExoPlayer"), React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => tapCenterOfPlayer(),
    title: "Play / Pause"
  }, "\u23EF"), React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => {
      setPlaying(false);
      setPlayerFullscreen(false);
      document.documentElement.removeAttribute("data-player-fullscreen");
    },
    title: "Exit Player"
  }, "\u2715 Exit"), React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => {
      if (pipOpen) {
        window.electron?.closePipWindow?.();
        return;
      }
      const url = sourceIsAsync(playerSource) ? resolvedPlayerUrl : playerDirectUrl;
      if (!url) return;
      pipUrlRef.current = url;
      window.electron?.openPipWindow?.(url, item.title, sourceUsesCleanUa(playerSource) ? CLEAN_USER_AGENT : null);
    },
    title: pipOpen ? "Close pop-out" : "Pop out player",
    disabled: !pipOpen && (webviewLoading || !!(sourceIsAsync(playerSource) && !resolvedPlayerUrl)),
    style: pipOpen ? {
      color: "var(--red)"
    } : undefined
  }, React.createElement(PopOutIcon, null))), showSourceMenu && menuPos && React.createElement("div", {
    className: "source-dropdown source-dropdown--fixed",
    style: {
      top: menuPos.top,
      left: menuPos.left
    },
    onClick: e => e.stopPropagation()
  }, PLAYER_SOURCES.map(src => React.createElement("button", {
    key: src.id,
    className: "source-dropdown__item" + (playerSource === src.id ? " source-dropdown__item--active" : ""),
    onClick: () => {
      setShowSourceMenu(false);
      if (src.id === playerSource) return;
      clearFailoverSource(`movie_${item.id}_${dubMode}`);
      setPlayerSource(src.id);
      storage.set(STORAGE_KEYS.PLAYER_SOURCE, src.id);
      setM3u8Url(null);
      setInterceptedSubs([]);
      resolvedPlayerUrlRef.current = null;
      setResolvedPlayerUrl(null);
      resolvingUrlRef.current = false;
      setResolvingUrl(false);
      setResolveError(null);
    }
  }, React.createElement("span", null, src.label), src.tag && React.createElement("span", {
    className: "source-dropdown__tag"
  }, src.tag), src.note && React.createElement("span", {
    className: "source-dropdown__note"
  }, src.note)))), React.createElement("button", {
    className: "player-overlay-btn",
    onClick: () => movieDownload ? onGoToDownloads?.(movieDownload.id) : (setShowSourceMenu(false), setShowDownload(true)),
    title: movieDownload ? movieDownload.status === "downloading" ? "Downloading… - view in Downloads" : "Already downloaded - view in Downloads" : "Download"
  }, movieDownload ? React.createElement("span", {
    className: "player-downloaded-icon",
    style: {
      color: movieDownload.status === "downloading" ? "var(--red)" : "#4caf50"
    }
  }, movieDownload.status === "downloading" ? "↓" : "✓") : React.createElement(DownloadIcon, null), !movieDownload && m3u8Url && React.createElement("span", {
    className: "player-overlay-dot"
  }), !sourceSupportsProgress(playerSource) && React.createElement("span", {
    className: "player-no-progress-hint",
    title: "No automatic progress tracking for this source"
  }, "\u26A0 no tracking"))), displayPct > 0 && React.createElement("div", {
    className: "progress-bar-row"
  }, React.createElement("div", {
    className: "progress-bar-outer"
  }, React.createElement("div", {
    className: "progress-bar-fill",
    style: {
      width: `${Math.min(displayPct, 100)}%`
    }
  })), React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text3)"
    }
  }, progressLabel))), collection && onSelect && React.createElement("div", {
    className: "section"
  }, React.createElement("div", {
    className: "section-title"
  }, collection.name), React.createElement("div", {
    className: "scroll-row"
  }, collection.parts.map(part => {
    const pk = `movie_${part.id}`;
    const isCurrent = part.id === item.id;
    return React.createElement(CollectionCard, {
      key: part.id,
      part: part,
      pk: pk,
      isCurrent: isCurrent,
      onSelect: onSelect,
      progress: progress[pk] || 0,
      watched: watched,
      onMarkWatched: onMarkWatched,
      onMarkUnwatched: onMarkUnwatched
    });
  }))), showTrailer && trailerKey && React.createElement(TrailerModal, {
    trailerKey: trailerKey,
    title: title,
    onClose: () => setShowTrailer(false)
  }), showDownloadConfirm && React.createElement(DownloadConfirmModal, {
    title: title,
    runtimeMin: d.runtime,
    episodeCount: 1,
    onCancel: () => setShowDownloadConfirm(false),
    onConfirm: () => {
      setShowDownloadConfirm(false);
      if (m3u8Url) {
        setShowDownload(true);
      } else {
        setPendingDownload(true);
        setM3u8Url(null);
        setPlaying(true);
      }
    }
  }), showBlockedModal && React.createElement(BlockedStatsModal, {
    sessionDomains: getBlockedDomains(),
    sessionTotal: blockedSession,
    alltimeTotal: blockedAlltime,
    onClose: () => setShowBlockedModal(false)
  }), showDownload && React.createElement(DownloadModal, {
    onClose: () => setShowDownload(false),
    m3u8Url: m3u8Url,
    subtitles: interceptedSubs,
    mediaName: mediaName,
    downloaderFolder: downloaderFolder,
    setDownloaderFolder: handleSetDownloaderFolder,
    onOpenSettings: onSettings,
    onDownloadStarted: onDownloadStarted,
    mediaId: item.id,
    mediaType: "movie",
    posterPath: d.poster_path,
    tmdbId: item.id
  }));
}
const CollectionCard = memo(function CollectionCard({
  part,
  isCurrent,
  onSelect,
  progress,
  watched,
  onMarkWatched,
  onMarkUnwatched
}) {
  const handleClick = useCallback(() => onSelect(part), [onSelect, part]);
  return React.createElement("div", {
    style: {
      opacity: isCurrent ? 0.5 : 1,
      pointerEvents: isCurrent ? "none" : "auto"
    }
  }, React.createElement(MediaCard, {
    item: part,
    onClick: handleClick,
    progress: progress,
    watched: watched,
    onMarkWatched: onMarkWatched,
    onMarkUnwatched: onMarkUnwatched
  }));
});
