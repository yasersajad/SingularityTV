# SingularityTV (iOS)

SingularityTV is a native SwiftUI iOS streaming client featuring TMDB catalog browsing, search, title details, playback with progress tracking, **Who's Watching** multi-profile support (up to 5 profiles), Supabase authentication and cloud sync, mandatory Telegram channel verification, and release update checks.

- **Developer:** SingularityTV ([@ec1lz](https://t.me/ec1lz))
- **Official Channel:** [SingularityTV Telegram](https://t.me/+IUpscNRqcqc4Y2Zk)
- **Bundle Identifier:** `com.singularity.tv`

## Building `SingularityTV.ipa` via GitHub Actions

1. Upload `SingularityTV-source.zip` to the root of your GitHub repository (or inside `source/`). Keep only **one** `.zip` file in those locations so the workflow selects it deterministically.
2. Ensure `.github/workflows/build-ipa.yml` is committed to your repository.
3. Push to `main`/`master` or open the **Actions** tab and run **Build SingularityTV IPA from ZIP** (`workflow_dispatch`).
4. Download `SingularityTV.ipa` from the workflow **Artifacts** or from the `latest` GitHub Release.

> **Important iOS Signing Note:** Because no Apple distribution certificate or provisioning profile is included in the repository, the generated `SingularityTV.ipa` is **unsigned**. To install it on a physical iOS device, sign and sideload it using a compatible tool such as AltStore, SideStore, Sideloadly, or Feather.
