# SingularityTV Supabase & Edge Function Setup

## Public Client Values (Embedded in App)

These values are public/publishable and configured in `NightFlix/Singularity/SingularityConfig.swift`:

- **Supabase Project URL:** `https://soufctreejgcpvqftxeb.supabase.co`
- **Supabase Realtime WebSocket URL:** `wss://soufctreejgcpvqftxeb.supabase.co/realtime/v1/websocket`
- **Supabase Publishable Key:** `sb_publishable_CRHhsCu1wvqdK7lUok8VfQ_IOBUqwJI`
- **Telegram Bot Username:** `@SingularityTV_Official_Bot`
- **Telegram Channel Invite URL:** `https://t.me/+IUpscNRqcqc4Y2Zk`

## Supabase Edge Function (`telegram-gate`)

The Edge Function source is included at `supabase/functions/telegram-gate/index.ts`. Deploy it with the Supabase CLI:

```bash
supabase functions deploy telegram-gate
```

### Required Edge Function Secrets (Server-Side Only)

Configure these secrets in **Supabase Dashboard → Edge Functions → Secrets** (or via `supabase secrets set`). **Never** place these values inside the iOS app, ZIP archive, or GitHub Actions workflows:

- `TELEGRAM_BOT_TOKEN` — Bot token for `@SingularityTV_Official_Bot`
- `SUPABASE_SERVICE_ROLE_KEY` — Service role key for `soufctreejgcpvqftxeb.supabase.co`
- `SUPABASE_URL` — `https://soufctreejgcpvqftxeb.supabase.co`
- `CHANNEL_TELEGRAM_ID` — Numeric Telegram channel ID (e.g. `-1004347079304`)
- `CHANNEL_INVITE_URL` — `https://t.me/+IUpscNRqcqc4Y2Zk`
- `ADMIN_TELEGRAM_ID` — Numeric Telegram user ID of the release admin
