import SwiftUI

struct UpdateGateView: View {
    let release: AppReleaseInfo
    let isMandatory: Bool
    let onDismissOptional: (() -> Void)?

    @EnvironmentObject private var sessionManager: SingularitySessionManager
    @Environment(\.openURL) private var openURL
    @State private var isRechecking = false

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color(hex: "22070B"), Color(hex: "0A0A0F"), Color(hex: "050508")],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            ScrollView {
                VStack(spacing: 20) {
                    ZStack {
                        Circle()
                            .fill(NightFlixStyle.accentColor.opacity(0.18))
                            .frame(width: 72, height: 72)
                        Image(systemName: "arrow.down.app.fill")
                            .font(.system(size: 34, weight: .bold))
                            .foregroundStyle(NightFlixStyle.accentColor)
                    }

                    VStack(spacing: 8) {
                        Text(isMandatory ? "Update Required" : "Update Available")
                            .font(.title2.weight(.heavy))
                            .foregroundStyle(.white)

                        Text("Current: v\(SingularityConfig.currentAppVersion)  ·  \(isMandatory ? "Required" : "Latest"): v\(release.latestVersion)")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(.white.opacity(0.75))

                        Text("Download the latest IPA from the release page and install it using your preferred iOS signing method.")
                            .font(.footnote)
                            .foregroundStyle(.white.opacity(0.6))
                            .multilineTextAlignment(.center)
                    }

                    if !release.changelog.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                        VStack(alignment: .leading, spacing: 6) {
                            Text("What's New")
                                .font(.caption.weight(.bold))
                                .foregroundStyle(.white.opacity(0.65))
                            Text(release.changelog)
                                .font(.footnote)
                                .foregroundStyle(.white.opacity(0.88))
                                .frame(maxWidth: .infinity, alignment: .leading)
                        }
                        .padding(14)
                        .background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                        .overlay {
                            RoundedRectangle(cornerRadius: 12, style: .continuous)
                                .stroke(Color.white.opacity(0.1), lineWidth: 1)
                        }
                    }

                    VStack(spacing: 12) {
                        Button {
                            HapticManager.shared.lightImpact()
                            let target = release.updatePostUrl.isEmpty ? release.channelUrl : release.updatePostUrl
                            if let url = URL(string: target) {
                                openURL(url)
                            }
                        } label: {
                            Label("Open Release Page", systemImage: "arrow.up.right.square.fill")
                                .font(.subheadline.weight(.bold))
                                .foregroundStyle(.white)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 14)
                                .background(NightFlixStyle.accentColor, in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                        }
                        .buttonStyle(NFScaleButtonStyle())

                        Button {
                            Task {
                                isRechecking = true
                                await sessionManager.recheckGate()
                                isRechecking = false
                            }
                        } label: {
                            HStack(spacing: 8) {
                                if isRechecking {
                                    ProgressView().tint(.white)
                                }
                                Text(isRechecking ? "Checking..." : "Check Again")
                                    .font(.subheadline.weight(.semibold))
                            }
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 13)
                            .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                        }
                        .buttonStyle(NFScaleButtonStyle())
                        .disabled(isRechecking)

                        if !isMandatory, let onDismissOptional {
                            Button("Later") {
                                HapticManager.shared.lightImpact()
                                onDismissOptional()
                            }
                            .font(.footnote.weight(.semibold))
                            .foregroundStyle(.white.opacity(0.65))
                            .padding(.top, 4)
                        }
                    }
                }
                .padding(24)
                .frame(maxWidth: 420)
                .background(
                    Color(white: 0.08).opacity(0.95),
                    in: RoundedRectangle(cornerRadius: 22, style: .continuous)
                )
                .overlay {
                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                        .stroke(NightFlixStyle.accentColor.opacity(0.35), lineWidth: 1)
                }
                .shadow(color: .black.opacity(0.72), radius: 30, y: 14)
                .padding(.horizontal, 18)
                .padding(.vertical, 32)
            }
        }
        .interactiveDismissDisabled(isMandatory)
        .preferredColorScheme(.dark)
    }
}
