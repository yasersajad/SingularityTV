import SwiftUI

struct TelegramGateView: View {
    @EnvironmentObject private var sessionManager: SingularitySessionManager
    @Environment(\.openURL) private var openURL

    @State private var isChecking = false
    @State private var statusMessage: String?

    var body: some View {
        let status = sessionManager.gateStatus
        let channelUrlString = status?.channelUrl ?? SingularityConfig.telegramChannelURL
        let userId = sessionManager.session?.user.id ?? ""
        let botVerifyString = "https://t.me/\(SingularityConfig.telegramBotUsername)?start=verify_\(userId)"

        ZStack {
            LinearGradient(
                colors: [Color(hex: "22070B"), Color(hex: "0A0A0F"), Color(hex: "050508")],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            ScrollView {
                VStack(spacing: 20) {
                    ZStack {
                        RoundedRectangle(cornerRadius: 16, style: .continuous)
                            .fill(NightFlixStyle.accentColor.opacity(0.16))
                            .frame(width: 60, height: 60)
                            .overlay {
                                RoundedRectangle(cornerRadius: 16, style: .continuous)
                                    .stroke(NightFlixStyle.accentColor.opacity(0.45), lineWidth: 1)
                            }
                        Text("S")
                            .font(.system(size: 32, weight: .black, design: .rounded))
                            .foregroundStyle(NightFlixStyle.accentColor)
                    }

                    VStack(spacing: 8) {
                        Text(headerTitle(status))
                            .font(.title2.weight(.heavy))
                            .foregroundStyle(.white)
                            .multilineTextAlignment(.center)

                        Text(headerSubtitle(status))
                            .font(.footnote)
                            .foregroundStyle(.white.opacity(0.72))
                            .multilineTextAlignment(.center)
                            .lineSpacing(3)
                    }

                    if let netErr = status?.networkError {
                        banner(netErr)
                    } else if let statusMessage {
                        banner(statusMessage)
                    }

                    VStack(spacing: 12) {
                        Button {
                            HapticManager.shared.lightImpact()
                            if let url = URL(string: channelUrlString) {
                                openURL(url)
                            }
                        } label: {
                            Label("1. Join Telegram Channel", systemImage: "paperplane.fill")
                                .font(.subheadline.weight(.bold))
                                .foregroundStyle(.white)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 14)
                                .background(Color(hex: "229ED9"), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                        }
                        .buttonStyle(NFScaleButtonStyle())

                        Button {
                            HapticManager.shared.lightImpact()
                            if let url = URL(string: botVerifyString) {
                                openURL(url)
                            }
                        } label: {
                            Label("2. Verify with @\(SingularityConfig.telegramBotUsername)", systemImage: "checkmark.shield.fill")
                                .font(.subheadline.weight(.bold))
                                .foregroundStyle(.white)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 14)
                                .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
                                .overlay {
                                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                                        .stroke(Color.white.opacity(0.16), lineWidth: 1)
                                }
                        }
                        .buttonStyle(NFScaleButtonStyle())

                        Button {
                            Task { await verifyNow() }
                        } label: {
                            HStack(spacing: 8) {
                                if isChecking {
                                    ProgressView()
                                        .tint(.white)
                                }
                                Text(isChecking ? "Verifying Membership..." : "3. Verify Membership")
                                    .font(.subheadline.weight(.bold))
                            }
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 14)
                            .background(
                                NightFlixStyle.accentColor.opacity(isChecking ? 0.65 : 1),
                                in: RoundedRectangle(cornerRadius: 12, style: .continuous)
                            )
                        }
                        .buttonStyle(NFScaleButtonStyle())
                        .disabled(isChecking)
                    }

                    Button("Sign Out") {
                        Task { await sessionManager.signOut() }
                    }
                    .font(.footnote.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.6))
                    .padding(.top, 4)
                }
                .padding(24)
                .frame(maxWidth: 420)
                .background(
                    Color(white: 0.08).opacity(0.94),
                    in: RoundedRectangle(cornerRadius: 22, style: .continuous)
                )
                .overlay {
                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                        .stroke(Color.white.opacity(0.12), lineWidth: 1)
                }
                .shadow(color: .black.opacity(0.7), radius: 30, y: 14)
                .padding(.horizontal, 18)
                .padding(.vertical, 32)
            }
        }
        .preferredColorScheme(.dark)
    }

    private func headerTitle(_ status: TelegramGateStatus?) -> String {
        if status?.networkError != nil {
            return "Connection Issue"
        }
        if status?.leftChannel == true {
            return "Channel Membership Lost"
        }
        return "Join Official Channel"
    }

    private func headerSubtitle(_ status: TelegramGateStatus?) -> String {
        if status?.networkError != nil {
            return "We couldn't reach the verification server. Check your internet connection and tap Verify Membership."
        }
        if status?.leftChannel == true {
            return "You are no longer in the official SingularityTV Telegram channel. Rejoin the channel and tap Verify Membership to continue."
        }
        return "Joining the official SingularityTV Telegram channel and verifying with our bot is required to unlock the app."
    }

    private func banner(_ text: String) -> some View {
        Text(text)
            .font(.footnote)
            .foregroundStyle(Color(hex: "FF8C92"))
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(12)
            .background(NightFlixStyle.accentColor.opacity(0.15), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 10, style: .continuous)
                    .stroke(NightFlixStyle.accentColor.opacity(0.45), lineWidth: 1)
            }
    }

    private func verifyNow() async {
        isChecking = true
        statusMessage = nil
        await sessionManager.recheckGate()
        isChecking = false

        if let st = sessionManager.gateStatus, st.networkError == nil, !st.member {
            HapticManager.shared.error()
            statusMessage = "Membership not confirmed yet. Make sure you joined the channel and tapped Start in @\(SingularityConfig.telegramBotUsername)."
        }
    }
}
