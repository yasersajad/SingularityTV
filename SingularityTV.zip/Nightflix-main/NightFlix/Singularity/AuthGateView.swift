import SwiftUI

struct AuthGateView: View {
    enum Mode {
        case signIn
        case signUp
        case verifySignUp
        case forgotPassword
        case resetVerify
    }

    @EnvironmentObject private var sessionManager: SingularitySessionManager
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    @State private var mode: Mode = .signIn
    @State private var name = ""
    @State private var email = ""
    @State private var password = ""
    @State private var confirmPassword = ""
    @State private var otp = ""
    @State private var showPassword = false
    @State private var isBusy = false
    @State private var errorMessage: String?
    @State private var infoMessage: String?
    @State private var otpSecondsLeft = 600
    @State private var timerTask: Task<Void, Never>?

    var body: some View {
        ZStack {
            LinearGradient(
                colors: [Color(hex: "22070B"), Color(hex: "0A0A0F"), Color(hex: "050508")],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()

            ScrollView {
                VStack(spacing: 22) {
                    brandHeader

                    if mode == .signIn || mode == .signUp {
                        modePicker
                    }

                    if let errorMessage {
                        banner(text: errorMessage, isError: true)
                    }

                    if let infoMessage {
                        banner(text: infoMessage, isError: false)
                    }

                    formBody
                }
                .padding(24)
                .frame(maxWidth: 420)
                .background(
                    Color(white: 0.08).opacity(0.92),
                    in: RoundedRectangle(cornerRadius: 22, style: .continuous)
                )
                .overlay {
                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                        .stroke(Color.white.opacity(0.1), lineWidth: 1)
                }
                .shadow(color: .black.opacity(0.65), radius: 28, y: 14)
                .padding(.horizontal, 18)
                .padding(.vertical, 32)
            }
            .scrollDismissesKeyboard(.interactively)
        }
        .preferredColorScheme(.dark)
        .onDisappear {
            timerTask?.cancel()
        }
    }

    private var brandHeader: some View {
        VStack(spacing: 10) {
            ZStack {
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .fill(NightFlixStyle.accentColor.opacity(0.15))
                    .frame(width: 58, height: 58)
                    .overlay {
                        RoundedRectangle(cornerRadius: 16, style: .continuous)
                            .stroke(NightFlixStyle.accentColor.opacity(0.45), lineWidth: 1)
                    }

                Text("S")
                    .font(.system(size: 32, weight: .black, design: .rounded))
                    .foregroundStyle(NightFlixStyle.accentColor)
            }

            HStack(spacing: 0) {
                Text("Singularity")
                    .foregroundStyle(.white)
                Text("TV")
                    .foregroundStyle(NightFlixStyle.accentColor)
            }
            .font(.system(size: 24, weight: .heavy, design: .rounded))

            Text(subtitleText)
                .font(.footnote)
                .foregroundStyle(.white.opacity(0.65))
                .multilineTextAlignment(.center)
        }
    }

    private var subtitleText: String {
        switch mode {
        case .signIn: return "Sign in to sync your watch progress & profiles"
        case .signUp: return "Create your account with email verification"
        case .verifySignUp: return "Enter the 6-digit code sent to \(email)"
        case .forgotPassword: return "Enter your email to receive a 6-digit reset code"
        case .resetVerify: return "Enter your reset code and choose a new password"
        }
    }

    private var modePicker: some View {
        HStack(spacing: 6) {
            modeTab("Sign In", target: .signIn)
            modeTab("Sign Up", target: .signUp)
        }
        .padding(4)
        .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 12, style: .continuous))
    }

    private func modeTab(_ title: String, target: Mode) -> some View {
        let selected = mode == target
        return Button {
            HapticManager.shared.selection()
            switchMode(target)
        } label: {
            Text(title)
                .font(.subheadline.weight(.bold))
                .foregroundStyle(selected ? .white : .white.opacity(0.62))
                .frame(maxWidth: .infinity)
                .padding(.vertical, 10)
                .background(
                    selected ? NightFlixStyle.accentColor : Color.clear,
                    in: RoundedRectangle(cornerRadius: 9, style: .continuous)
                )
        }
        .buttonStyle(.plain)
    }

    @ViewBuilder
    private var formBody: some View {
        switch mode {
        case .signIn:
            VStack(spacing: 14) {
                field(title: "Email Address") {
                    TextField("you@example.com", text: $email)
                        .keyboardType(.emailAddress)
                        .textContentType(.emailAddress)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }

                VStack(alignment: .leading, spacing: 6) {
                    HStack {
                        Text("Password")
                            .font(.caption.weight(.semibold))
                            .foregroundStyle(.white.opacity(0.72))
                        Spacer()
                        Button("Forgot password?") {
                            switchMode(.forgotPassword)
                        }
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(NightFlixStyle.accentColor)
                    }

                    passwordField(placeholder: "Enter your password", text: $password)
                }

                primaryButton(title: isBusy ? "Signing In..." : "Sign In") {
                    Task { await performSignIn() }
                }
            }

        case .signUp:
            VStack(spacing: 14) {
                field(title: "Display Name") {
                    TextField("Your name", text: $name)
                        .textContentType(.name)
                }

                field(title: "Email Address") {
                    TextField("you@example.com", text: $email)
                        .keyboardType(.emailAddress)
                        .textContentType(.emailAddress)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }

                field(title: "Password (min. 6 characters)") {
                    passwordField(placeholder: "Create a password", text: $password)
                }

                field(title: "Confirm Password") {
                    passwordField(placeholder: "Repeat your password", text: $confirmPassword)
                }

                primaryButton(title: isBusy ? "Sending Code..." : "Send Verification Code") {
                    Task { await performSignUp() }
                }
            }

        case .verifySignUp:
            VStack(spacing: 14) {
                otpField

                Text(otpSecondsLeft > 0 ? "Code expires in \(formattedTimer)" : "Code expired. Request a new code below.")
                    .font(.caption)
                    .foregroundStyle(otpSecondsLeft > 0 ? .white.opacity(0.65) : Color(hex: "FF8C92"))

                primaryButton(
                    title: isBusy ? "Verifying..." : "Verify & Enter App",
                    disabled: isBusy || otp.count != 6 || otpSecondsLeft <= 0
                ) {
                    Task { await performVerifySignUp() }
                }

                HStack {
                    Button("Back") { switchMode(.signUp) }
                        .foregroundStyle(.white.opacity(0.65))
                    Spacer()
                    Button("Resend Code") {
                        Task { await performResendOTP() }
                    }
                    .disabled(isBusy)
                    .foregroundStyle(NightFlixStyle.accentColor)
                }
                .font(.footnote.weight(.semibold))
            }

        case .forgotPassword:
            VStack(spacing: 14) {
                field(title: "Account Email Address") {
                    TextField("you@example.com", text: $email)
                        .keyboardType(.emailAddress)
                        .textContentType(.emailAddress)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                }

                primaryButton(title: isBusy ? "Sending Reset Code..." : "Send Reset Code") {
                    Task { await performRequestReset() }
                }

                Button("Back to Sign In") {
                    switchMode(.signIn)
                }
                .font(.footnote.weight(.semibold))
                .foregroundStyle(.white.opacity(0.65))
            }

        case .resetVerify:
            VStack(spacing: 14) {
                field(title: "6-Digit Reset Code") {
                    otpField
                }

                Text(otpSecondsLeft > 0 ? "Code expires in \(formattedTimer)" : "Code expired. Request a new code below.")
                    .font(.caption)
                    .foregroundStyle(otpSecondsLeft > 0 ? .white.opacity(0.65) : Color(hex: "FF8C92"))

                field(title: "New Password (min. 6 characters)") {
                    passwordField(placeholder: "Enter new password", text: $password)
                }

                field(title: "Confirm New Password") {
                    passwordField(placeholder: "Repeat new password", text: $confirmPassword)
                }

                primaryButton(
                    title: isBusy ? "Updating Password..." : "Reset Password & Sign In",
                    disabled: isBusy || otp.count != 6 || otpSecondsLeft <= 0
                ) {
                    Task { await performCompleteReset() }
                }

                HStack {
                    Button("Back to Sign In") { switchMode(.signIn) }
                        .foregroundStyle(.white.opacity(0.65))
                    Spacer()
                    Button("Resend Code") {
                        Task { await performRequestReset() }
                    }
                    .disabled(isBusy)
                    .foregroundStyle(NightFlixStyle.accentColor)
                }
                .font(.footnote.weight(.semibold))
            }
        }
    }

    private func field<Content: View>(title: String, @ViewBuilder content: () -> Content) -> some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(.caption.weight(.semibold))
                .foregroundStyle(.white.opacity(0.72))

            content()
                .padding(.horizontal, 14)
                .padding(.vertical, 13)
                .foregroundStyle(.white)
                .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 11, style: .continuous))
                .overlay {
                    RoundedRectangle(cornerRadius: 11, style: .continuous)
                        .stroke(Color.white.opacity(0.14), lineWidth: 1)
                }
        }
    }

    private func passwordField(placeholder: String, text: Binding<String>) -> some View {
        HStack(spacing: 8) {
            Group {
                if showPassword {
                    TextField(placeholder, text: text)
                } else {
                    SecureField(placeholder, text: text)
                }
            }
            .textInputAutocapitalization(.never)
            .autocorrectionDisabled()

            Button {
                showPassword.toggle()
            } label: {
                Image(systemName: showPassword ? "eye.slash" : "eye")
                    .foregroundStyle(.white.opacity(0.6))
                    .frame(width: 28, height: 28)
            }
            .buttonStyle(.plain)
            .accessibilityLabel(showPassword ? "Hide password" : "Show password")
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 13)
        .foregroundStyle(.white)
        .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 11, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 11, style: .continuous)
                .stroke(Color.white.opacity(0.14), lineWidth: 1)
        }
    }

    private var otpField: some View {
        TextField("000000", text: Binding(
            get: { otp },
            set: { otp = String($0.filter(\.isNumber).prefix(6)) }
        ))
        .keyboardType(.numberPad)
        .textContentType(.oneTimeCode)
        .multilineTextAlignment(.center)
        .font(.system(size: 26, weight: .bold, design: .monospaced))
        .tracking(8)
        .foregroundStyle(.white)
        .padding(.vertical, 12)
        .background(Color.white.opacity(0.06), in: RoundedRectangle(cornerRadius: 11, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 11, style: .continuous)
                .stroke(Color.white.opacity(0.16), lineWidth: 1)
        }
    }

    private func primaryButton(title: String, disabled: Bool? = nil, action: @escaping () -> Void) -> some View {
        let isDisabled = disabled ?? isBusy
        return Button(action: {
            HapticManager.shared.lightImpact()
            action()
        }) {
            Text(title)
                .font(.subheadline.weight(.bold))
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 14)
                .background(
                    NightFlixStyle.accentColor.opacity(isDisabled ? 0.55 : 1),
                    in: RoundedRectangle(cornerRadius: 12, style: .continuous)
                )
        }
        .buttonStyle(NFScaleButtonStyle())
        .disabled(isDisabled)
    }

    private func banner(text: String, isError: Bool) -> some View {
        Text(text)
            .font(.footnote)
            .foregroundStyle(isError ? Color(hex: "FF8C92") : Color(hex: "7BE3A2"))
            .frame(maxWidth: .infinity, alignment: .leading)
            .padding(12)
            .background(
                (isError ? NightFlixStyle.accentColor : Color.green).opacity(0.15),
                in: RoundedRectangle(cornerRadius: 10, style: .continuous)
            )
            .overlay {
                RoundedRectangle(cornerRadius: 10, style: .continuous)
                    .stroke((isError ? NightFlixStyle.accentColor : Color.green).opacity(0.42), lineWidth: 1)
            }
    }

    private var formattedTimer: String {
        let m = otpSecondsLeft / 60
        let s = otpSecondsLeft % 60
        return String(format: "%d:%02d", m, s)
    }

    private func switchMode(_ next: Mode) {
        withAnimation(reduceMotion ? nil : .easeOut(duration: 0.18)) {
            mode = next
            errorMessage = nil
            infoMessage = nil
        }
    }

    private func startOTPTimer() {
        timerTask?.cancel()
        otpSecondsLeft = 600
        timerTask = Task {
            while otpSecondsLeft > 0, !Task.isCancelled {
                try? await Task.sleep(for: .seconds(1))
                guard !Task.isCancelled else { break }
                otpSecondsLeft = max(0, otpSecondsLeft - 1)
            }
        }
    }

    // MARK: - Actions

    private func performSignIn() async {
        errorMessage = nil
        infoMessage = nil
        isBusy = true
        defer { isBusy = false }

        do {
            let session = try await SupabaseAuthService.shared.signIn(email: email, password: password)
            await sessionManager.handleAuthenticated(session, isNewSignIn: true)
        } catch AuthFlowError.emailNotConfirmed {
            try? await SupabaseAuthService.shared.resendSignupOTP(email: email)
            otp = ""
            startOTPTimer()
            mode = .verifySignUp
            infoMessage = "Your email is not verified yet. We sent a fresh 6-digit code to your email."
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func performSignUp() async {
        errorMessage = nil
        infoMessage = nil
        guard password == confirmPassword else {
            errorMessage = "Passwords do not match."
            return
        }
        isBusy = true
        defer { isBusy = false }

        do {
            let result = try await SupabaseAuthService.shared.signUp(email: email, password: password, name: name)
            switch result {
            case .authenticated(let session):
                await sessionManager.handleAuthenticated(session, isNewSignIn: true)
            case .needsVerification(let cleanEmail):
                email = cleanEmail
                otp = ""
                startOTPTimer()
                mode = .verifySignUp
                infoMessage = "A 6-digit verification code has been sent to your email."
            }
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func performVerifySignUp() async {
        errorMessage = nil
        infoMessage = nil
        isBusy = true
        defer { isBusy = false }

        do {
            let session = try await SupabaseAuthService.shared.verifyEmailOTP(email: email, token: otp, type: "signup")
            timerTask?.cancel()
            await sessionManager.handleAuthenticated(session, isNewSignIn: true)
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func performResendOTP() async {
        errorMessage = nil
        infoMessage = nil
        isBusy = true
        defer { isBusy = false }

        do {
            try await SupabaseAuthService.shared.resendSignupOTP(email: email)
            otp = ""
            startOTPTimer()
            infoMessage = "A new 6-digit code was sent. Valid for 10 minutes."
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func performRequestReset() async {
        errorMessage = nil
        infoMessage = nil
        isBusy = true
        defer { isBusy = false }

        do {
            try await SupabaseAuthService.shared.requestPasswordReset(email: email)
            otp = ""
            password = ""
            confirmPassword = ""
            startOTPTimer()
            mode = .resetVerify
            infoMessage = "A 6-digit password reset code was sent to your email."
        } catch {
            errorMessage = error.localizedDescription
        }
    }

    private func performCompleteReset() async {
        errorMessage = nil
        infoMessage = nil
        guard password == confirmPassword else {
            errorMessage = "Passwords do not match."
            return
        }
        isBusy = true
        defer { isBusy = false }

        do {
            let session = try await SupabaseAuthService.shared.completePasswordReset(
                email: email,
                token: otp,
                newPassword: password
            )
            timerTask?.cancel()
            await sessionManager.handleAuthenticated(session, isNewSignIn: true)
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}

struct NFScaleButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .scaleEffect(configuration.isPressed ? 0.97 : 1.0)
            .animation(.easeOut(duration: 0.14), value: configuration.isPressed)
    }
}
