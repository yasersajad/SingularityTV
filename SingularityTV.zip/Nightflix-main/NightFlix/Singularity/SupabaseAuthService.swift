import Foundation

actor SupabaseAuthService {
    static let shared = SupabaseAuthService()

    private let session: URLSession = {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 15
        config.timeoutIntervalForResource = 30
        return URLSession(configuration: config)
    }()

    private func makeRequest(path: String, method: String, accessToken: String? = nil, body: [String: Any]? = nil) throws -> URLRequest {
        guard let url = URL(string: SingularityConfig.supabaseURL + path) else {
            throw AuthFlowError.server("Invalid service URL.")
        }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue(SingularityConfig.supabasePublishableKey, forHTTPHeaderField: "apikey")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if let accessToken, !accessToken.isEmpty {
            request.setValue("Bearer \(accessToken)", forHTTPHeaderField: "Authorization")
        }
        if let body {
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
        }
        return request
    }

    private func performJSON(_ request: URLRequest) async throws -> (Int, [String: Any]) {
        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await session.data(for: request)
        } catch let urlErr as URLError {
            if urlErr.code == .notConnectedToInternet || urlErr.code == .networkConnectionLost || urlErr.code == .timedOut {
                throw AuthFlowError.network("Network connection unavailable. Check your internet and try again.")
            }
            throw AuthFlowError.network(urlErr.localizedDescription)
        }

        let status = (response as? HTTPURLResponse)?.statusCode ?? 0
        let json = (try? JSONSerialization.jsonObject(with: data) as? [String: Any]) ?? [:]
        return (status, json)
    }

    private func extractErrorMessage(_ json: [String: Any], fallback: String) -> String {
        for key in ["msg", "error_description", "message", "error"] {
            if let val = json[key] as? String, !val.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                return val
            }
        }
        return fallback
    }

    private func parseSession(from json: [String: Any], fallbackEmail: String = "", fallbackName: String = "") -> SupabaseSession? {
        guard let accessToken = json["access_token"] as? String, !accessToken.isEmpty,
              let rawUser = json["user"] as? [String: Any],
              let userId = rawUser["id"] as? String, !userId.isEmpty else {
            return nil
        }

        let rawEmail = (rawUser["email"] as? String) ?? fallbackEmail
        let email = rawEmail.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        let metadata = rawUser["user_metadata"] as? [String: Any]
        let metaName = (metadata?["name"] as? String) ?? (metadata?["full_name"] as? String) ?? ""
        let defaultName = email.split(separator: "@").first.map(String.init) ?? "User"
        let resolvedName = [metaName, fallbackName, defaultName]
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .first { !$0.isEmpty } ?? "User"

        let refreshToken = (json["refresh_token"] as? String) ?? ""
        let nowMs = Date().timeIntervalSince1970 * 1000
        let expiresAtMs: Double
        if let exp = json["expires_at"] as? Double {
            expiresAtMs = exp * 1000
        } else if let expInt = json["expires_at"] as? Int {
            expiresAtMs = Double(expInt) * 1000
        } else {
            let expiresIn = (json["expires_in"] as? Double) ?? Double((json["expires_in"] as? Int) ?? 3600)
            expiresAtMs = nowMs + expiresIn * 1000
        }

        return SupabaseSession(
            accessToken: accessToken,
            refreshToken: refreshToken,
            expiresAtMs: expiresAtMs,
            user: SupabaseUser(id: userId, email: email, name: resolvedName)
        )
    }

    func signIn(email: String, password: String) async throws -> SupabaseSession {
        let cleanEmail = email.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard cleanEmail.contains("@"), cleanEmail.contains(".") else {
            throw AuthFlowError.invalidEmail
        }
        guard !password.isEmpty else {
            throw AuthFlowError.weakPassword
        }

        let req = try makeRequest(
            path: "/auth/v1/token?grant_type=password",
            method: "POST",
            body: ["email": cleanEmail, "password": password]
        )
        let (status, json) = try await performJSON(req)

        guard (200..<300).contains(status), let session = parseSession(from: json, fallbackEmail: cleanEmail) else {
            let msg = extractErrorMessage(json, fallback: "Invalid email or password.")
            if msg.localizedCaseInsensitiveContains("not confirmed") {
                throw AuthFlowError.emailNotConfirmed
            }
            throw AuthFlowError.server(msg)
        }

        await MainActor.run {
            KeychainHelper.saveSession(session)
        }
        return session
    }

    enum SignUpResult {
        case authenticated(SupabaseSession)
        case needsVerification(email: String)
    }

    func signUp(email: String, password: String, name: String) async throws -> SignUpResult {
        let cleanEmail = email.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard cleanEmail.contains("@"), cleanEmail.contains(".") else {
            throw AuthFlowError.invalidEmail
        }
        guard password.count >= 6 else {
            throw AuthFlowError.weakPassword
        }
        let cleanName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let resolvedName = cleanName.isEmpty ? (cleanEmail.split(separator: "@").first.map(String.init) ?? "User") : cleanName

        let req = try makeRequest(
            path: "/auth/v1/signup",
            method: "POST",
            body: [
                "email": cleanEmail,
                "password": password,
                "data": ["name": resolvedName]
            ]
        )
        let (status, json) = try await performJSON(req)

        guard (200..<300).contains(status) else {
            let msg = extractErrorMessage(json, fallback: "Could not create account.")
            if msg.localizedCaseInsensitiveContains("already") {
                throw AuthFlowError.accountAlreadyExists
            }
            throw AuthFlowError.server(msg)
        }

        if let session = parseSession(from: json, fallbackEmail: cleanEmail, fallbackName: resolvedName) {
            await MainActor.run {
                KeychainHelper.saveSession(session)
            }
            return .authenticated(session)
        }

        if let identities = json["identities"] as? [Any], identities.isEmpty {
            throw AuthFlowError.accountAlreadyExists
        }

        return .needsVerification(email: cleanEmail)
    }

    func resendSignupOTP(email: String) async throws {
        let cleanEmail = email.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard cleanEmail.contains("@") else { throw AuthFlowError.invalidEmail }

        let req = try makeRequest(
            path: "/auth/v1/resend",
            method: "POST",
            body: ["type": "signup", "email": cleanEmail]
        )
        let (status, json) = try await performJSON(req)
        guard (200..<300).contains(status) else {
            throw AuthFlowError.server(extractErrorMessage(json, fallback: "Could not resend verification code."))
        }
    }

    func verifyEmailOTP(email: String, token: String, type: String = "signup") async throws -> SupabaseSession {
        let cleanEmail = email.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        let digits = token.filter(\.isNumber)
        guard digits.count == 6 else { throw AuthFlowError.invalidOTP }

        let req = try makeRequest(
            path: "/auth/v1/verify",
            method: "POST",
            body: ["email": cleanEmail, "token": digits, "type": type]
        )
        let (status, json) = try await performJSON(req)
        guard (200..<300).contains(status), let session = parseSession(from: json, fallbackEmail: cleanEmail) else {
            throw AuthFlowError.server(extractErrorMessage(json, fallback: "Invalid or expired verification code."))
        }

        await MainActor.run {
            KeychainHelper.saveSession(session)
        }
        return session
    }

    func requestPasswordReset(email: String) async throws {
        let cleanEmail = email.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard cleanEmail.contains("@"), cleanEmail.contains(".") else {
            throw AuthFlowError.invalidEmail
        }

        let req = try makeRequest(
            path: "/auth/v1/recover",
            method: "POST",
            body: ["email": cleanEmail]
        )
        let (status, json) = try await performJSON(req)
        guard (200..<300).contains(status) else {
            throw AuthFlowError.server(extractErrorMessage(json, fallback: "Could not send password reset code."))
        }
    }

    func completePasswordReset(email: String, token: String, newPassword: String) async throws -> SupabaseSession {
        let cleanEmail = email.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        let digits = token.filter(\.isNumber)
        guard digits.count == 6 else { throw AuthFlowError.invalidOTP }
        guard newPassword.count >= 6 else { throw AuthFlowError.weakPassword }

        let verified = try await verifyEmailOTP(email: cleanEmail, token: digits, type: "recovery")

        let updateReq = try makeRequest(
            path: "/auth/v1/user",
            method: "PUT",
            accessToken: verified.accessToken,
            body: ["password": newPassword]
        )
        let (status, json) = try await performJSON(updateReq)
        guard (200..<300).contains(status) else {
            throw AuthFlowError.server(extractErrorMessage(json, fallback: "Could not update password."))
        }

        return verified
    }

    func refreshSession(_ current: SupabaseSession) async throws -> SupabaseSession {
        guard !current.refreshToken.isEmpty else {
            throw AuthFlowError.server("Session expired. Please sign in again.")
        }

        let req = try makeRequest(
            path: "/auth/v1/token?grant_type=refresh_token",
            method: "POST",
            body: ["refresh_token": current.refreshToken]
        )
        let (status, json) = try await performJSON(req)
        guard (200..<300).contains(status),
              let refreshed = parseSession(from: json, fallbackEmail: current.user.email, fallbackName: current.user.name) else {
            throw AuthFlowError.server(extractErrorMessage(json, fallback: "Session expired. Please sign in again."))
        }

        await MainActor.run {
            KeychainHelper.saveSession(refreshed)
        }
        return refreshed
    }

    func ensureValidSession(forceRefresh: Bool = false) async -> SupabaseSession? {
        let current = await MainActor.run { KeychainHelper.loadSession() }
        guard let current else { return nil }

        if forceRefresh || current.isExpiringSoon {
            if let refreshed = try? await refreshSession(current) {
                return refreshed
            }
            if forceRefresh {
                return nil
            }
        }
        return current
    }

    func signOut(accessToken: String?) async {
        if let accessToken, !accessToken.isEmpty,
           let req = try? makeRequest(path: "/auth/v1/logout", method: "POST", accessToken: accessToken) {
            _ = try? await session.data(for: req)
        }
        await MainActor.run {
            KeychainHelper.deleteSession()
        }
    }
}
