import Foundation
import UIKit

actor SingularitySyncService {
    static let shared = SingularitySyncService()

    private let session: URLSession = {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 15
        config.timeoutIntervalForResource = 30
        return URLSession(configuration: config)
    }()

    private func makeRequest(urlString: String, method: String, accessToken: String, body: [String: Any]? = nil, extraHeaders: [String: String] = [:]) throws -> URLRequest {
        guard let url = URL(string: urlString) else {
            throw URLError(.badURL)
        }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.setValue(SingularityConfig.supabasePublishableKey, forHTTPHeaderField: "apikey")
        request.setValue("Bearer \(accessToken)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        for (k, v) in extraHeaders {
            request.setValue(v, forHTTPHeaderField: k)
        }
        if let body {
            request.httpBody = try JSONSerialization.data(withJSONObject: body)
        }
        return request
    }

    // MARK: - Telegram Gate & App Releases

    func checkTelegramAndReleaseGate(authSession: SupabaseSession) async -> TelegramGateStatus {
        let currentVersion = await MainActor.run { SingularityConfig.currentAppVersion }

        do {
            var req = try makeRequest(
                urlString: "\(SingularityConfig.supabaseURL)/functions/v1/telegram-gate",
                method: "POST",
                accessToken: authSession.accessToken,
                body: ["action": "check"]
            )
            var (data, response) = try await session.data(for: req)
            if (response as? HTTPURLResponse)?.statusCode == 401,
               let refreshed = await SupabaseAuthService.shared.ensureValidSession(forceRefresh: true) {
                req = try makeRequest(
                    urlString: "\(SingularityConfig.supabaseURL)/functions/v1/telegram-gate",
                    method: "POST",
                    accessToken: refreshed.accessToken,
                    body: ["action": "check"]
                )
                (data, response) = try await session.data(for: req)
            }

            guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode),
                  let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
                  let isMember = json["member"] as? Bool else {
                return TelegramGateStatus(
                    member: false,
                    linked: false,
                    leftChannel: false,
                    channelUrl: SingularityConfig.telegramChannelURL,
                    release: nil,
                    needsMandatoryUpdate: false,
                    hasOptionalUpdate: false,
                    networkError: "Unable to verify membership with the server. Please try again."
                )
            }

            let release = decodeRelease(from: json["release"])
            let channelUrl = (json["channelUrl"] as? String) ?? release?.channelUrl ?? SingularityConfig.telegramChannelURL
            let linked = (json["linked"] as? Bool) ?? false
            let leftChannel = (json["leftChannel"] as? Bool) ?? false

            let mandatory = isMandatoryUpdate(release: release, currentVersion: currentVersion)
            let optional = isOptionalUpdate(release: release, currentVersion: currentVersion, isMandatory: mandatory)

            return TelegramGateStatus(
                member: isMember,
                linked: linked,
                leftChannel: leftChannel,
                channelUrl: channelUrl,
                release: release,
                needsMandatoryUpdate: mandatory,
                hasOptionalUpdate: optional,
                networkError: nil
            )
        } catch {
            return TelegramGateStatus(
                member: false,
                linked: false,
                leftChannel: false,
                channelUrl: SingularityConfig.telegramChannelURL,
                release: nil,
                needsMandatoryUpdate: false,
                hasOptionalUpdate: false,
                networkError: "Network error while checking channel & update status. Please retry."
            )
        }
    }

    func fetchLatestRelease(accessToken: String) async throws -> AppReleaseInfo? {
        let req = try makeRequest(
            urlString: "\(SingularityConfig.supabaseURL)/rest/v1/app_releases?id=eq.1&select=*",
            method: "GET",
            accessToken: accessToken
        )
        let (data, response) = try await session.data(for: req)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode),
              let arr = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]],
              let first = arr.first else {
            return nil
        }
        return decodeRelease(from: first)
    }

    private func decodeRelease(from raw: Any?) -> AppReleaseInfo? {
        guard let dict = raw as? [String: Any],
              let data = try? JSONSerialization.data(withJSONObject: dict) else {
            return nil
        }
        return try? JSONDecoder().decode(AppReleaseInfo.self, from: data)
    }

    private func isMandatoryUpdate(release: AppReleaseInfo?, currentVersion: String) -> Bool {
        guard let release, release.forceUpdate,
              SemanticVersion.isValid(release.minRequiredVersion) else {
            return false
        }
        return SemanticVersion.compare(currentVersion, release.minRequiredVersion) == .orderedAscending
    }

    private func isOptionalUpdate(release: AppReleaseInfo?, currentVersion: String, isMandatory: Bool) -> Bool {
        guard !isMandatory, let release,
              SemanticVersion.isValid(release.latestVersion) else {
            return false
        }
        return SemanticVersion.compare(currentVersion, release.latestVersion) == .orderedAscending
    }

    // MARK: - Cloud Sync Pull & Push

    func pullUserSyncData(authSession: SupabaseSession) async -> [String: Any]? {
        if let req = try? makeRequest(
            urlString: "\(SingularityConfig.supabaseURL)/functions/v1/telegram-gate?action=sync_pull",
            method: "GET",
            accessToken: authSession.accessToken
        ), let (data, response) = try? await session.data(for: req),
           let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode),
           let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
           let syncData = json["data"] as? [String: Any] {
            return syncData
        }

        let encodedId = authSession.user.id.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? authSession.user.id
        if let req = try? makeRequest(
            urlString: "\(SingularityConfig.supabaseURL)/rest/v1/user_sync?user_id=eq.\(encodedId)&select=data,updated_at",
            method: "GET",
            accessToken: authSession.accessToken
        ), let (data, response) = try? await session.data(for: req),
           let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode),
           let rows = try? JSONSerialization.jsonObject(with: data) as? [[String: Any]],
           let first = rows.first,
           let syncData = first["data"] as? [String: Any] {
            return syncData
        }

        return nil
    }

    func pushUserSyncData(authSession: SupabaseSession, dataPayload: [String: Any]) async throws {
        let body: [String: Any] = [
            "user_id": authSession.user.id,
            "email": authSession.user.email,
            "data": dataPayload,
            "updated_at": ISO8601DateFormatter().string(from: Date())
        ]
        var req = try makeRequest(
            urlString: "\(SingularityConfig.supabaseURL)/rest/v1/user_sync?on_conflict=user_id",
            method: "POST",
            accessToken: authSession.accessToken,
            body: body,
            extraHeaders: ["Prefer": "resolution=merge-duplicates,return=minimal"]
        )
        var (_, response) = try await session.data(for: req)
        if (response as? HTTPURLResponse)?.statusCode == 401,
           let refreshed = await SupabaseAuthService.shared.ensureValidSession(forceRefresh: true) {
            req = try makeRequest(
                urlString: "\(SingularityConfig.supabaseURL)/rest/v1/user_sync?on_conflict=user_id",
                method: "POST",
                accessToken: refreshed.accessToken,
                body: body,
                extraHeaders: ["Prefer": "resolution=merge-duplicates,return=minimal"]
            )
            (_, response) = try await session.data(for: req)
        }
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw AuthFlowError.server("Could not sync account data to cloud.")
        }
    }

    // MARK: - Profile Operations

    func performProfileOperation(authSession: SupabaseSession, body: [String: Any]) async throws -> [UserProfile]? {
        var payload = body
        payload["action"] = "sync_profiles"

        let req = try makeRequest(
            urlString: "\(SingularityConfig.supabaseURL)/functions/v1/telegram-gate?action=sync_profiles",
            method: "POST",
            accessToken: authSession.accessToken,
            body: payload
        )
        let (data, response) = try await session.data(for: req)
        let json = (try? JSONSerialization.jsonObject(with: data) as? [String: Any]) ?? [:]
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            let err = (json["error"] as? String) ?? "Profile sync failed."
            throw AuthFlowError.server(err)
        }

        guard let rawProfiles = json["profiles"] as? [[String: Any]],
              let profilesData = try? JSONSerialization.data(withJSONObject: rawProfiles) else {
            return nil
        }
        return try? JSONDecoder().decode([UserProfile].self, from: profilesData)
    }

    // MARK: - Atomic Progress Push

    func pushProgressAtomic(
        authSession: SupabaseSession,
        progressKey: String,
        percent: Int,
        positionSec: Int,
        durationSec: Int,
        watched: Bool,
        isPlaying: Bool,
        profileId: String
    ) async {
        let deviceName = await MainActor.run { UIDevice.current.name }
        let body: [String: Any] = [
            "action": "sync_progress",
            "progressKey": progressKey,
            "percent": max(1, min(100, percent)),
            "positionSec": max(0, positionSec),
            "durationSec": max(0, durationSec),
            "watched": watched,
            "isPlaying": isPlaying,
            "profileId": profileId,
            "deviceId": "ios_native",
            "deviceName": deviceName
        ]
        guard let req = try? makeRequest(
            urlString: "\(SingularityConfig.supabaseURL)/functions/v1/telegram-gate?action=sync_progress",
            method: "POST",
            accessToken: authSession.accessToken,
            body: body
        ) else { return }
        _ = try? await session.data(for: req)
    }
}
