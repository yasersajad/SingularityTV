import SwiftUI

struct NightflixStartupAnimationView: View {
    let animationsEnabled: Bool
    let onFinished: @MainActor () -> Void

    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @State private var hasStarted = false
    @State private var emblemOpacity: Double = 0
    @State private var emblemScale: CGFloat = 0.88
    @State private var glowOpacity: Double = 0
    @State private var glowScale: CGFloat = 0.75
    @State private var wordmarkOpacity: Double = 0
    @State private var wordmarkOffset: CGFloat = 14
    @State private var containerOpacity: Double = 1
    @State private var containerScale: CGFloat = 1

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            RadialGradient(
                colors: [
                    NightFlixStyle.accentColor.opacity(0.28 * glowOpacity),
                    NightFlixStyle.accentColor.opacity(0.08 * glowOpacity),
                    .clear
                ],
                center: .center,
                startRadius: 10,
                endRadius: 320
            )
            .scaleEffect(glowScale)
            .ignoresSafeArea()
            .blendMode(.plusLighter)
            .allowsHitTesting(false)

            VStack(spacing: 18) {
                Text("S")
                    .font(.system(size: 92, weight: .black, design: .rounded))
                    .foregroundStyle(
                        LinearGradient(
                            colors: [
                                Color(red: 1.0, green: 0.18, blue: 0.23),
                                NightFlixStyle.accentColor,
                                Color(red: 0.56, green: 0.02, blue: 0.05)
                            ],
                            startPoint: .top,
                            endPoint: .bottom
                        )
                    )
                    .shadow(color: NightFlixStyle.accentColor.opacity(0.55 * glowOpacity), radius: 22)
                    .shadow(color: NightFlixStyle.accentColor.opacity(0.28 * glowOpacity), radius: 44)
                    .opacity(emblemOpacity)
                    .scaleEffect(emblemScale)

                Text("SINGULARITYTV")
                    .font(.system(size: 16, weight: .bold, design: .rounded))
                    .tracking(5.5)
                    .foregroundStyle(.white.opacity(0.92))
                    .opacity(wordmarkOpacity)
                    .offset(y: wordmarkOffset)
            }
            .scaleEffect(containerScale)
            .opacity(containerOpacity)
        }
        .accessibilityHidden(true)
        .task {
            await runAnimationIfNeeded()
        }
        .onChange(of: animationsEnabled) { _, enabled in
            if !enabled {
                onFinished()
            }
        }
        .onChange(of: reduceMotion) { _, isReduced in
            if isReduced {
                onFinished()
            }
        }
    }

    @MainActor
    private func runAnimationIfNeeded() async {
        guard !hasStarted else { return }
        hasStarted = true

        guard animationsEnabled, !reduceMotion else {
            onFinished()
            return
        }

        withAnimation(.spring(response: 0.58, dampingFraction: 0.78)) {
            emblemOpacity = 1
            emblemScale = 1.0
        }

        try? await Task.sleep(for: .milliseconds(260))
        guard animationsEnabled, !reduceMotion else {
            onFinished()
            return
        }

        withAnimation(.easeOut(duration: 0.70)) {
            glowOpacity = 1
            glowScale = 1.08
        }

        try? await Task.sleep(for: .milliseconds(280))
        guard animationsEnabled, !reduceMotion else {
            onFinished()
            return
        }

        withAnimation(.easeOut(duration: 0.40)) {
            wordmarkOpacity = 1
            wordmarkOffset = 0
        }

        try? await Task.sleep(for: .milliseconds(720))
        guard animationsEnabled, !reduceMotion else {
            onFinished()
            return
        }

        withAnimation(.easeOut(duration: 0.34)) {
            containerOpacity = 0
            containerScale = 1.04
        }

        try? await Task.sleep(for: .milliseconds(340))
        onFinished()
    }
}

#Preview {
    NightflixStartupAnimationView(animationsEnabled: true) {}
}
