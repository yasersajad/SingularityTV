import XCTest
@testable import SingularityTV

final class SingularityTests: XCTestCase {
    func testSemanticVersionComparison() {
        XCTAssertEqual(SemanticVersion.compare("1.1.5", "1.1.6"), .orderedAscending)
        XCTAssertEqual(SemanticVersion.compare("v3.0.0", "3.0.0"), .orderedSame)
        XCTAssertEqual(SemanticVersion.compare("3.1.0", "3.0.9"), .orderedDescending)
    }

    @MainActor
    func testProfileSanitizationDeduplicatesAndCapsAtFive() {
        let input = [
            UserProfile(id: "p1", name: "One", avatarColor: "#E50914", isKids: false, createdAt: 1),
            UserProfile(id: "p1", name: "Duplicate", avatarColor: "#E50914", isKids: false, createdAt: 2),
            UserProfile(id: "", name: "EmptyID", avatarColor: "#E50914", isKids: false, createdAt: 3),
            UserProfile(id: "p2", name: "Two", avatarColor: "#3B82F6", isKids: true, createdAt: 4),
            UserProfile(id: "p3", name: "Three", avatarColor: "#10B981", isKids: false, createdAt: 5),
            UserProfile(id: "p4", name: "Four", avatarColor: "#8B5CF6", isKids: false, createdAt: 6),
            UserProfile(id: "p5", name: "Five", avatarColor: "#EC4899", isKids: false, createdAt: 7),
            UserProfile(id: "p6", name: "Six", avatarColor: "#06B6D4", isKids: false, createdAt: 8)
        ]
        let sanitized = SingularitySessionManager.sanitizeProfiles(input, fallbackName: "Main")
        XCTAssertEqual(sanitized.count, 5)
        XCTAssertEqual(sanitized.map(\.id), ["p1", "p2", "p3", "p4", "p5"])
        XCTAssertEqual(sanitized[0].name, "One")
    }
}
