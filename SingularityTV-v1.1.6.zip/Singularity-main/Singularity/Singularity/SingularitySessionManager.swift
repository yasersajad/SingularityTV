import Combine
import Foundation
import SwiftUI

@MainActor
final class SingularitySessionManager: ObservableObject {
    static let shared = SingularitySessionManager()

    enum GateStage: Equatable {
        case loading
        case auth
        case mandatoryUpdate
        case telegramGate
        case syncError
        case profilePicker
        case ready
    }

    @Published private(set) var session: SupabaseSession?
    @Published private(set) var stage: GateStage = .loading
    @Published private(set) var gateStatus: TelegramGateStatus?
    @Published private(set) var optionalUpdate: AppReleaseInfo?
    @Published var isShowingOptionalUpdate = false

    @Published private(set) var profiles: [UserProfile] = []
    @Published private(set) var activeProfileId: String = "prof_main"
    @Published var isShowingProfileSheet = false
    @Published var isShowingLocalMergePrompt = false

    @Published private(set) var isCheckingGate = false
    @Published private(set) var isSwitchingProfile = false
    @Published private(set) var isLoadingProfileData = false
    @Published private(set) var loadingProfileName: String?
    @Published var profileError: String?
    @Published var profileSwitchError: String?
    @Published var syncPullError: String?
    @Published var failedProfileCandidate: UserProfile?

    var activeProfile: UserProfile? {
        profiles.first { $0.id == activeProfileId } ?? profiles.first
    }

    var isKidsMode: Bool {
        activeProfile?.isKids == true
    }

    private weak var myListManager: MyListManager?
    private weak var historyManager: WatchHistoryManager?
    private weak var continueWatchingManager: ContinueWatchingManager?
    private weak var libraryModel: NFLibrary?
    private weak var settingsManager: AppSettingsManager?

    private var lastGateCheckAt: Date?
    private var debounceSyncTask: Task<Void, Never>?
    private var pendingCloudDataForMerge: [String: Any]?
    private var hasCompletedInitialBootstrap = false
    private var hasCompletedInitialPull = false
    private var isHydratingProfile = false
    struct ProfileSwitchOperation: Equatable {
        let operationID: String
        let generationID: Int
        let targetProfileID: String
        let startedAt: Date
        var isCancelled: Bool = false
        var hydrationState: String = "pending"
    }

    private var switchGeneration: Int = 0
    private(set) var activeSwitchOperation: ProfileSwitchOperation?

    private let defaults = UserDefaults.standard
    private let activeProfileStoragePrefix = "singularity.activeProfileId."
    private let accountVaultPrefix = "singularity.accountVault."
    private let localPreAuthBackupKey = "singularity.localPreAuthBackup"
    private let kidsModeDefaultsKey = "singularity.activeProfileIsKids"

    private init() {
        session = KeychainHelper.loadSession()
    }

    func attachManagers(
        myList: MyListManager,
        history: WatchHistoryManager,
        continueWatching: ContinueWatchingManager,
        library: NFLibrary,
        settings: AppSettingsManager
    ) {
        self.myListManager = myList
        self.historyManager = history
        self.continueWatchingManager = continueWatching
        self.libraryModel = library
        self.settingsManager = settings
    }

    func bootstrapIfNeeded() async {
        guard !hasCompletedInitialBootstrap else { return }
        hasCompletedInitialBootstrap = true
        await restoreSessionAndEvaluateGates(forceRefreshGate: true)
    }

    func restoreSessionAndEvaluateGates(forceRefreshGate: Bool = false) async {
        if let valid = await SupabaseAuthService.shared.ensureValidSession(forceRefresh: false) {
            session = valid
            await evaluateGatesAndLoadAccount(forceGateCheck: forceRefreshGate)
        } else {
            KeychainHelper.deleteSession()
            session = nil
            profiles = []
            defaults.set(false, forKey: kidsModeDefaultsKey)
            stage = .auth
        }
    }

    func handleAuthenticated(_ newSession: SupabaseSession, isNewSignIn: Bool = true) async {
        session = newSession
        lastGateCheckAt = nil
        if isNewSignIn {
            snapshotPreAuthLocalDataIfNeeded(for: newSession.user.id)
        }
        await evaluateGatesAndLoadAccount(forceGateCheck: true)
    }

    func recheckGate() async {
        await evaluateGatesAndLoadAccount(forceGateCheck: true)
    }

    func checkUpdatesManually() async -> AppReleaseInfo? {
        guard let currentSession = await SupabaseAuthService.shared.ensureValidSession(forceRefresh: false) else {
            return nil
        }
        let status = await SingularitySyncService.shared.checkTelegramAndReleaseGate(authSession: currentSession)
        gateStatus = status
        if status.needsMandatoryUpdate {
            stage = .mandatoryUpdate
            return status.release
        }
        if status.hasOptionalUpdate, let rel = status.release {
            optionalUpdate = rel
            isShowingOptionalUpdate = true
            return rel
        }
        return nil
    }

    private func evaluateGatesAndLoadAccount(forceGateCheck: Bool) async {
        guard let currentSession = session else {
            stage = .auth
            return
        }

        if !forceGateCheck,
           let lastCheck = lastGateCheckAt,
           Date().timeIntervalSince(lastCheck) < 60,
           let cached = gateStatus {
            applyGateStatus(cached)
            return
        }

        isCheckingGate = true
        let status = await SingularitySyncService.shared.checkTelegramAndReleaseGate(authSession: currentSession)
        isCheckingGate = false
        lastGateCheckAt = Date()
        gateStatus = status

        if status.networkError != nil {
            if stage == .loading {
                stage = .telegramGate
            }
            return
        }

        if status.needsMandatoryUpdate {
            stage = .mandatoryUpdate
            return
        }

        if !status.member {
            stage = .telegramGate
            return
        }

        if status.hasOptionalUpdate, let rel = status.release {
            optionalUpdate = rel
            if settingsManager?.automaticUpdateChecksEnabled != false {
                isShowingOptionalUpdate = true
            }
        }

        let hydrated = await pullAndHydrateAccount(for: currentSession)
        if hydrated && stage != .ready {
            stage = .profilePicker
        }
    }

    private func applyGateStatus(_ status: TelegramGateStatus) {
        if status.needsMandatoryUpdate {
            stage = .mandatoryUpdate
        } else if !status.member {
            stage = .telegramGate
        } else if stage != .ready {
            stage = .profilePicker
        }
    }

    // MARK: - Profiles

    func selectProfile(_ profile: UserProfile) async {
        guard !isSwitchingProfile else {
            SingularityDiagnostics.shared.record(category: "Profile", message: "Ignored concurrent switch tap for \(profile.id)")
            return
        }
        let cleanId = profile.id.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanId.isEmpty else {
            profileSwitchError = "Invalid profile identifier."
            failedProfileCandidate = profile
            SingularityDiagnostics.shared.record(category: "Profile", message: "Rejected empty profile ID")
            return
        }
        guard let uid = session?.user.id, !uid.isEmpty else {
            profileSwitchError = "Session expired. Please sign in again."
            failedProfileCandidate = profile
            SingularityDiagnostics.shared.record(category: "Profile", message: "Aborted switch: missing session")
            return
        }

        profiles = Self.sanitizeProfiles(profiles, fallbackName: session?.user.name ?? "Main")
        guard let verifiedProfile = profiles.first(where: { $0.id == cleanId }) else {
            profileSwitchError = "Selected profile could not be found."
            failedProfileCandidate = profile
            SingularityDiagnostics.shared.record(category: "Profile", message: "Profile \(cleanId) missing after sanitization")
            return
        }

        switchGeneration &+= 1
        let gen = switchGeneration
        let opID = String(UUID().uuidString.prefix(8))
        if var prevOp = activeSwitchOperation, !prevOp.isCancelled {
            prevOp.isCancelled = true
            SingularityDiagnostics.shared.record(
                category: "ProfileSwitchCancel",
                message: "Cancelled obsolete switch to \(prevOp.targetProfileID)",
                operationID: prevOp.operationID,
                generationID: prevOp.generationID,
                profileID: prevOp.targetProfileID
            )
        }
        var currentOp = ProfileSwitchOperation(
            operationID: opID,
            generationID: gen,
            targetProfileID: verifiedProfile.id,
            startedAt: Date(),
            isCancelled: false,
            hydrationState: "hydrating"
        )
        activeSwitchOperation = currentOp
        let previousProfileId = activeProfileId
        let previousKidsMode = defaults.bool(forKey: kidsModeDefaultsKey)

        isSwitchingProfile = true
        isLoadingProfileData = true
        loadingProfileName = verifiedProfile.name
        profileError = nil
        profileSwitchError = nil
        failedProfileCandidate = nil
        debounceSyncTask?.cancel()

        SingularityDiagnostics.shared.record(
            category: "ProfileSwitchBegin",
            message: "Begin switch to \(verifiedProfile.id)",
            operationID: opID,
            generationID: gen,
            profileID: verifiedProfile.id
        )
        saveCurrentActiveProfileToVault()

        activeProfileId = verifiedProfile.id
        defaults.set(verifiedProfile.id, forKey: activeProfileStoragePrefix + uid)
        defaults.set(verifiedProfile.isKids, forKey: kidsModeDefaultsKey)

        if let auth = await SupabaseAuthService.shared.ensureValidSession(forceRefresh: false) {
            let pullResult = await SingularitySyncService.shared.pullProfileData(authSession: auth, profileId: verifiedProfile.id)
            guard gen == switchGeneration, session?.user.id == uid else {
                activeProfileId = previousProfileId
                defaults.set(previousProfileId, forKey: activeProfileStoragePrefix + uid)
                defaults.set(previousKidsMode, forKey: kidsModeDefaultsKey)
                loadProfileFromVaultIntoManagers(profileId: previousProfileId)
                isSwitchingProfile = false
                isLoadingProfileData = false
                loadingProfileName = nil
                return
            }
            if case .success(let payload) = pullResult,
               let rawBucket = payload["profileData"] as? [String: Any] {
                let remoteBucket = decodeRemoteBucket(rawBucket, profileId: verifiedProfile.id)
                mergeBucketIntoVault(remoteBucket, userId: uid, profileId: verifiedProfile.id)
                SingularityDiagnostics.shared.record(
                    category: "Profile",
                    message: "Hydrated cloud bucket for \(verifiedProfile.id): saved=\(remoteBucket.myList.count), history=\(remoteBucket.history.count)"
                )
            } else {
                SingularityDiagnostics.shared.record(category: "Profile", message: "Using local vault for \(verifiedProfile.id)")
            }
        }

        loadProfileFromVaultIntoManagers(profileId: verifiedProfile.id)

        guard gen == switchGeneration, activeProfileId == verifiedProfile.id, session?.user.id == uid else {
            activeProfileId = previousProfileId
            defaults.set(previousProfileId, forKey: activeProfileStoragePrefix + uid)
            defaults.set(previousKidsMode, forKey: kidsModeDefaultsKey)
            loadProfileFromVaultIntoManagers(profileId: previousProfileId)
            profileSwitchError = "Could not finish switching to \(verifiedProfile.name). Please try again."
            failedProfileCandidate = verifiedProfile
            SingularityDiagnostics.shared.record(category: "Profile", message: "Rolled back switch to \(verifiedProfile.id) (gen mismatch)")
            isSwitchingProfile = false
            isLoadingProfileData = false
            loadingProfileName = nil
            return
        }

        isSwitchingProfile = false
        isLoadingProfileData = false
        loadingProfileName = nil
        try? await Task.sleep(for: .milliseconds(40))
        currentOp.hydrationState = "completed"; activeSwitchOperation = currentOp; SingularityDiagnostics.shared.record(category: "ProfileSwitchComplete", message: "Completed switch to \(verifiedProfile.id); opening ready stage", operationID: opID, generationID: gen, profileID: verifiedProfile.id)
        isShowingProfileSheet = false
        if stage == .profilePicker {
            stage = .ready
        }
        scheduleDebouncedSync()
    }

    static func sanitizeProfiles(_ raw: [UserProfile], fallbackName: String) -> [UserProfile] {
        var seen = Set<String>()
        var clean: [UserProfile] = []
        for p in raw {
            let pid = p.id.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !pid.isEmpty, !seen.contains(pid) else { continue }
            seen.insert(pid)
            let name = String(p.name.trimmingCharacters(in: .whitespacesAndNewlines).prefix(24))
            clean.append(UserProfile(
                id: pid,
                name: name.isEmpty ? "Profile" : name,
                avatarColor: p.avatarColor.isEmpty ? "#E50914" : p.avatarColor,
                isKids: p.isKids,
                createdAt: p.createdAt
            ))
            if clean.count >= 5 { break }
        }
        if clean.isEmpty {
            clean.append(UserProfile(
                id: "prof_main",
                name: fallbackName.isEmpty ? "Main" : String(fallbackName.prefix(24)),
                avatarColor: "#E50914",
                isKids: false,
                createdAt: Date().timeIntervalSince1970 * 1000
            ))
        }
        return clean
    }

    func retryFailedProfileSwitch() async {
        guard let candidate = failedProfileCandidate else { return }
        await selectProfile(candidate)
    }

    func createProfile(name: String, avatarColor: String, isKids: Bool) async -> Bool {
        let trimmed = String(name.trimmingCharacters(in: .whitespacesAndNewlines).prefix(24))
        guard !trimmed.isEmpty else {
            profileError = "Please enter a profile name."
            return false
        }
        guard profiles.count < 5 else {
            profileError = "Maximum 5 profiles per account."
            return false
        }

        let newId = "prof_\(Int(Date().timeIntervalSince1970))_\(Int.random(in: 1000...9999))"
        let newProfile = UserProfile(
            id: newId,
            name: trimmed,
            avatarColor: avatarColor,
            isKids: isKids,
            createdAt: Date().timeIntervalSince1970 * 1000
        )

        if let currentSession = await SupabaseAuthService.shared.ensureValidSession(forceRefresh: false) {
            do {
                if let serverProfiles = try await SingularitySyncService.shared.performProfileOperation(
                    authSession: currentSession,
                    body: [
                        "op": "create",
                        "id": newProfile.id,
                        "name": newProfile.name,
                        "avatarColor": newProfile.avatarColor,
                        "isKids": newProfile.isKids
                    ]
                ) {
                    profiles = Self.sanitizeProfiles(serverProfiles, fallbackName: session?.user.name ?? "Main")
                    persistProfilesMetadataToVault()
                    return true
                }
            } catch {
                profileError = error.localizedDescription
                return false
            }
        }

        profiles.append(newProfile)
        persistProfilesMetadataToVault()
        scheduleDebouncedSync()
        return true
    }

    func updateProfile(id: String, name: String, avatarColor: String, isKids: Bool) async -> Bool {
        let trimmed = String(name.trimmingCharacters(in: .whitespacesAndNewlines).prefix(24))
        guard !trimmed.isEmpty else {
            profileError = "Please enter a profile name."
            return false
        }
        guard let idx = profiles.firstIndex(where: { $0.id == id }) else {
            profileError = "Profile not found."
            return false
        }

        if let currentSession = await SupabaseAuthService.shared.ensureValidSession(forceRefresh: false) {
            do {
                if let serverProfiles = try await SingularitySyncService.shared.performProfileOperation(
                    authSession: currentSession,
                    body: [
                        "op": "update",
                        "id": id,
                        "name": trimmed,
                        "avatarColor": avatarColor,
                        "isKids": isKids
                    ]
                ) {
                    profiles = Self.sanitizeProfiles(serverProfiles, fallbackName: session?.user.name ?? "Main")
                    if activeProfileId == id {
                        defaults.set(isKids, forKey: kidsModeDefaultsKey)
                    }
                    persistProfilesMetadataToVault()
                    return true
                }
            } catch {
                profileError = error.localizedDescription
                return false
            }
        }

        profiles[idx].name = trimmed
        profiles[idx].avatarColor = avatarColor
        profiles[idx].isKids = isKids
        if activeProfileId == id {
            defaults.set(isKids, forKey: kidsModeDefaultsKey)
        }
        persistProfilesMetadataToVault()
        scheduleDebouncedSync()
        return true
    }

    func deleteProfile(id: String) async -> Bool {
        guard profiles.count > 1 else {
            profileError = "Cannot delete the last remaining profile."
            return false
        }

        if let currentSession = await SupabaseAuthService.shared.ensureValidSession(forceRefresh: false) {
            do {
                if let serverProfiles = try await SingularitySyncService.shared.performProfileOperation(
                    authSession: currentSession,
                    body: ["op": "delete", "id": id]
                ) {
                    profiles = Self.sanitizeProfiles(serverProfiles, fallbackName: session?.user.name ?? "Main")
                }
            } catch {
                profileError = error.localizedDescription
                return false
            }
        } else {
            profiles.removeAll { $0.id == id }
        }

        removeProfileFromVault(profileId: id)
        if activeProfileId == id, let fallback = profiles.first {
            await selectProfile(fallback)
        } else {
            persistProfilesMetadataToVault()
        }
        return true
    }

    // MARK: - Sign Out

    func signOut() async {
        debounceSyncTask?.cancel()
        saveCurrentActiveProfileToVault()
        await pushSyncNow()

        let token = session?.accessToken
        await SupabaseAuthService.shared.signOut(accessToken: token)

        session = nil
        profiles = []
        activeProfileId = "prof_main"
        gateStatus = nil
        optionalUpdate = nil
        isShowingOptionalUpdate = false
        isShowingProfileSheet = false
        lastGateCheckAt = nil
        hasCompletedInitialPull = false
        defaults.set(false, forKey: kidsModeDefaultsKey)

        clearActiveRuntimeDataForAccountIsolation()
        stage = .auth
    }

    // MARK: - Sync & Local Data Isolation

    func notifyLocalDataChanged() {
        guard session != nil, !isHydratingProfile else { return }
        saveCurrentActiveProfileToVault()
        scheduleDebouncedSync()
    }

    func pushProgressAtomic(
        type: WatchType,
        tmdbId: String,
        season: Int?,
        episode: Int?,
        positionSeconds: Double,
        durationSeconds: Double,
        watched: Bool
    ) {
        guard let currentSession = session else { return }
        let key: String
        if type == .tv, let s = season, let e = episode {
            key = "tv_\(tmdbId)_s\(s)_e\(e)"
        } else {
            key = "\(type.rawValue)_\(tmdbId)"
        }
        let pct = durationSeconds > 0 ? Int(round((positionSeconds / durationSeconds) * 100)) : (watched ? 100 : 1)
        let pid = activeProfileId

        Task {
            await SingularitySyncService.shared.pushProgressAtomic(
                authSession: currentSession,
                progressKey: key,
                percent: pct,
                positionSec: Int(positionSeconds),
                durationSec: Int(durationSeconds),
                watched: watched,
                isPlaying: !watched,
                profileId: pid
            )
        }
    }

    private func scheduleDebouncedSync() {
        debounceSyncTask?.cancel()
        debounceSyncTask = Task { [weak self] in
            try? await Task.sleep(for: .milliseconds(1500))
            guard !Task.isCancelled else { return }
            await self?.pushSyncNow()
        }
    }

    func pushSyncNow() async {
        guard hasCompletedInitialPull, let currentSession = await SupabaseAuthService.shared.ensureValidSession(forceRefresh: false) else { return }
        saveCurrentActiveProfileToVault()
        let payload = buildCloudPayload(for: currentSession.user.id)
        try? await SingularitySyncService.shared.pushUserSyncData(authSession: currentSession, dataPayload: payload)
    }

    var hasLocalVaultProfiles: Bool {
        guard let uid = session?.user.id else { return false }
        return !loadVault(for: uid).profiles.isEmpty
    }

    func continueOfflineWithLocalVault() {
        guard let uid = session?.user.id else { return }
        let vault = loadVault(for: uid)
        guard !vault.profiles.isEmpty else { return }
        profiles = Self.sanitizeProfiles(vault.profiles, fallbackName: session?.user.name ?? "Main")
        let storedActive = defaults.string(forKey: activeProfileStoragePrefix + uid)
        if let storedActive, profiles.contains(where: { $0.id == storedActive }) {
            activeProfileId = storedActive
        } else if let first = profiles.first {
            activeProfileId = first.id
        }
        defaults.set(activeProfile?.isKids == true, forKey: kidsModeDefaultsKey)
        loadProfileFromVaultIntoManagers(profileId: activeProfileId)
        syncPullError = nil
        stage = .profilePicker
    }

    @discardableResult
    private func pullAndHydrateAccount(for authSession: SupabaseSession) async -> Bool {
        let uid = authSession.user.id
        syncPullError = nil
        let result = await SingularitySyncService.shared.pullUserSyncData(authSession: authSession)

        switch result {
        case .success(let remoteData):
            let backupKey = accountVaultPrefix + uid + ".backup"
            let previousVaultData = defaults.data(forKey: accountVaultPrefix + uid)
            if let previousVaultData {
                defaults.set(previousVaultData, forKey: backupKey)
            }

            let hasPreAuthLocal = defaults.data(forKey: localPreAuthBackupKey) != nil
            if hasPreAuthLocal {
                pendingCloudDataForMerge = remoteData
                applyRemoteDataToVault(remoteData, userId: uid, mergeWithExistingLocal: false)
                isShowingLocalMergePrompt = true
            } else {
                applyRemoteDataToVault(remoteData, userId: uid, mergeWithExistingLocal: true)
            }
            hasCompletedInitialPull = true
            defaults.removeObject(forKey: backupKey)

        case .empty:
            hasCompletedInitialPull = true
            let existingVault = loadVault(for: uid)
            if existingVault.profiles.isEmpty {
                let defaultProfile = UserProfile(
                    id: "prof_main",
                    name: authSession.user.name,
                    avatarColor: "#E50914",
                    isKids: false,
                    createdAt: Date().timeIntervalSince1970 * 1000
                )
                profiles = [defaultProfile]
                activeProfileId = defaultProfile.id
                saveCurrentActiveProfileToVault()
                persistProfilesMetadataToVault()
            } else {
                profiles = Self.sanitizeProfiles(existingVault.profiles, fallbackName: authSession.user.name)
            }
            defaults.removeObject(forKey: localPreAuthBackupKey)
            await pushSyncNow()

        case .unauthorized(let msg):
            SingularityDiagnostics.shared.record(category: "SyncPull", message: "Unauthorized: \(msg)")
            syncPullError = msg
            stage = .auth
            return false

        case .failure(let msg):
            SingularityDiagnostics.shared.record(category: "SyncPull", message: "Pull failed: \(msg)")
            syncPullError = msg
            stage = .syncError
            return false
        }

        let storedActive = defaults.string(forKey: activeProfileStoragePrefix + uid)
        if let storedActive, profiles.contains(where: { $0.id == storedActive }) {
            activeProfileId = storedActive
        } else if let first = profiles.first {
            activeProfileId = first.id
        }
        defaults.set(activeProfile?.isKids == true, forKey: kidsModeDefaultsKey)
        loadProfileFromVaultIntoManagers(profileId: activeProfileId)
        return true
    }

    func resolveLocalMerge(shouldMergeLocal: Bool) async {
        defer {
            defaults.removeObject(forKey: localPreAuthBackupKey)
            pendingCloudDataForMerge = nil
            isShowingLocalMergePrompt = false
        }
        guard let uid = session?.user.id else { return }
        if shouldMergeLocal, let backupData = defaults.data(forKey: localPreAuthBackupKey),
           let localBucket = try? JSONDecoder().decode(ProfileVaultBucket.self, from: backupData) {
            mergeBucketIntoVault(localBucket, userId: uid, profileId: activeProfileId)
            loadProfileFromVaultIntoManagers(profileId: activeProfileId)
            await pushSyncNow()
        }
    }

    // MARK: - Vault Persistence Helpers

    private struct AccountVault: Codable {
        var schemaVersion: Int
        var profiles: [UserProfile]
        var profilesTs: Double
        var profileData: [String: ProfileVaultBucket]

        enum CodingKeys: String, CodingKey {
            case schemaVersion, profiles, profilesTs, profileData
        }

        init(schemaVersion: Int = 2, profiles: [UserProfile], profilesTs: Double, profileData: [String: ProfileVaultBucket]) {
            self.schemaVersion = schemaVersion
            self.profiles = profiles
            self.profilesTs = profilesTs
            self.profileData = profileData
        }

        init(from decoder: Decoder) throws {
            let c = try decoder.container(keyedBy: CodingKeys.self)
            schemaVersion = (try? c.decode(Int.self, forKey: .schemaVersion)) ?? 1
            profiles = (try? c.decode([UserProfile].self, forKey: .profiles)) ?? []
            profilesTs = (try? c.decode(Double.self, forKey: .profilesTs)) ?? 0
            profileData = (try? c.decode([String: ProfileVaultBucket].self, forKey: .profileData)) ?? [:]
        }
    }

    private struct ProfileVaultBucket: Codable {
        var myList: [MyListItem]
        var history: [WatchItem]
        var continueWatching: [ContinueWatchingItem]
        var liked: [NFSavedTitle]
        var reminders: [NFReminder]
        var streamingProviderBaseURL: String?
        var accentColorHex: String?
        var hapticsEnabled: Bool?
        var updatedAt: Double
    }

    private func loadVault(for userId: String) -> AccountVault {
        let key = accountVaultPrefix + userId
        guard let data = defaults.data(forKey: key) else {
            return AccountVault(profiles: [], profilesTs: 0, profileData: [:])
        }
        if let vault = try? JSONDecoder().decode(AccountVault.self, from: data) {
            return vault
        }
        defaults.set(data, forKey: key + ".legacy_backup")
        SingularityDiagnostics.shared.record(category: "Migration", message: "Backed up undecodable vault for \(userId) before migration.")
        if let rawObj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
            var migrated = AccountVault(schemaVersion: 2, profiles: [], profilesTs: 0, profileData: [:])
            if let rawProfiles = rawObj["profiles"] as? [[String: Any]],
               let pData = try? JSONSerialization.data(withJSONObject: rawProfiles),
               let decodedProfiles = try? JSONDecoder().decode([UserProfile].self, from: pData) {
                migrated.profiles = decodedProfiles
            }
            if let rawMap = rawObj["profileData"] as? [String: [String: Any]] {
                for (pid, bucketDict) in rawMap {
                    migrated.profileData[pid] = decodeRemoteBucket(bucketDict)
                }
            }
            if migrated.profileData.isEmpty {
                let rootBucket = decodeRemoteBucket(rawObj)
                if !rootBucket.myList.isEmpty || !rootBucket.history.isEmpty || !rootBucket.continueWatching.isEmpty {
                    let targetPid = migrated.profiles.first?.id ?? "prof_main"
                    migrated.profileData[targetPid] = rootBucket
                }
            }
            saveVault(migrated, for: userId)
            return migrated
        }
        return AccountVault(profiles: [], profilesTs: 0, profileData: [:])
    }

    private func saveVault(_ vault: AccountVault, for userId: String) {
        if let data = try? JSONEncoder().encode(vault) {
            defaults.set(data, forKey: accountVaultPrefix + userId)
        }
    }

    private func snapshotPreAuthLocalDataIfNeeded(for userId: String) {
        let vaultExists = defaults.data(forKey: accountVaultPrefix + userId) != nil
        guard !vaultExists else { return }

        let bucket = extractCurrentManagersBucket()
        let hasData = !bucket.myList.isEmpty || !bucket.history.isEmpty || !bucket.continueWatching.isEmpty || !bucket.liked.isEmpty
        if hasData, let data = try? JSONEncoder().encode(bucket) {
            defaults.set(data, forKey: localPreAuthBackupKey)
        }
    }

    private func extractCurrentManagersBucket() -> ProfileVaultBucket {
        ProfileVaultBucket(
            myList: myListManager?.items ?? [],
            history: historyManager?.items ?? [],
            continueWatching: continueWatchingManager?.items ?? [],
            liked: libraryModel?.liked ?? [],
            reminders: libraryModel?.reminders ?? [],
            streamingProviderBaseURL: defaults.string(forKey: AppSettingsStorageKey.streamingProviderBaseURL),
            accentColorHex: defaults.string(forKey: AppSettingsStorageKey.accentColorHex),
            hapticsEnabled: defaults.object(forKey: "hapticsEnabled") as? Bool,
            updatedAt: Date().timeIntervalSince1970 * 1000
        )
    }

    private func saveCurrentActiveProfileToVault() {
        guard let uid = session?.user.id else { return }
        var vault = loadVault(for: uid)
        vault.profileData[activeProfileId] = extractCurrentManagersBucket()
        if !profiles.isEmpty {
            vault.profiles = profiles
        }
        saveVault(vault, for: uid)
    }

    private func persistProfilesMetadataToVault() {
        guard let uid = session?.user.id else { return }
        var vault = loadVault(for: uid)
        vault.profiles = profiles
        vault.profilesTs = Date().timeIntervalSince1970 * 1000
        saveVault(vault, for: uid)
    }

    private func removeProfileFromVault(profileId: String) {
        guard let uid = session?.user.id else { return }
        var vault = loadVault(for: uid)
        vault.profileData.removeValue(forKey: profileId)
        vault.profiles = profiles
        saveVault(vault, for: uid)
    }

    func currentWebPlayerPrefs() -> [String: Any] {
        let pid = activeProfileId ?? "prof_main"
        guard let data = defaults.data(forKey: "singularity.webPlayerPrefs." + pid),
              let dict = try? JSONSerialization.jsonObject(with: data) as? [String: Any] else {
            return [:]
        }
        return dict
    }

    func updateWebPlayerPrefs(_ updates: [String: Any]) {
        let pid = activeProfileId ?? "prof_main"
        var current = currentWebPlayerPrefs()
        for (k, v) in updates {
            current[k] = v
        }
        if let data = try? JSONSerialization.data(withJSONObject: current) {
            defaults.set(data, forKey: "singularity.webPlayerPrefs." + pid)
            notifyLocalDataChanged()
        }
    }

    private func loadProfileFromVaultIntoManagers(profileId: String) {
        isHydratingProfile = true
        defer { isHydratingProfile = false }
        guard let uid = session?.user.id else { return }
        let vault = loadVault(for: uid)
        let bucket = vault.profileData[profileId]

        if let bucket {
            if let data = try? JSONEncoder().encode(bucket.myList) {
                defaults.set(data, forKey: "myListItems")
            }
            if let data = try? JSONEncoder().encode(bucket.history) {
                defaults.set(data, forKey: "recentlyWatchedItems")
            }
            if let data = try? JSONEncoder().encode(bucket.continueWatching) {
                defaults.set(data, forKey: "continueWatchingItems")
            }
            if let data = try? JSONEncoder().encode(bucket.liked) {
                defaults.set(data, forKey: "nf.likedTitles")
            }
            if let data = try? JSONEncoder().encode(bucket.reminders) {
                defaults.set(data, forKey: "nf.reminders")
            }
            if let provider = bucket.streamingProviderBaseURL {
                defaults.set(provider, forKey: AppSettingsStorageKey.streamingProviderBaseURL)
            }
            if let accent = bucket.accentColorHex {
                defaults.set(accent, forKey: AppSettingsStorageKey.accentColorHex)
            }
            if let haptics = bucket.hapticsEnabled {
                defaults.set(haptics, forKey: "hapticsEnabled")
            }
        } else {
            clearActiveRuntimeDataForAccountIsolation()
        }

        myListManager?.load()
        historyManager?.reloadFromDefaults()
        continueWatchingManager?.load()
        libraryModel?.reloadFromDefaults()
    }

    private func clearActiveRuntimeDataForAccountIsolation() {
        defaults.removeObject(forKey: "myListItems")
        defaults.removeObject(forKey: "recentlyWatchedItems")
        defaults.removeObject(forKey: "continueWatchingItems")
        defaults.removeObject(forKey: "nf.likedTitles")
        defaults.removeObject(forKey: "nf.reminders")

        myListManager?.load()
        historyManager?.reloadFromDefaults()
        continueWatchingManager?.load()
        libraryModel?.reloadFromDefaults()
    }

    private func mergeBuckets(_ base: ProfileVaultBucket, incoming: ProfileVaultBucket) -> ProfileVaultBucket {
        var target = base
        var seenList = Set(target.myList.map { "\($0.mediaType.rawValue)-\($0.tmdbId)" })
        for item in incoming.myList {
            let key = "\(item.mediaType.rawValue)-\(item.tmdbId)"
            if seenList.insert(key).inserted {
                target.myList.append(item)
            }
        }

        var seenCW = Set(target.continueWatching.map { "\($0.type.rawValue)-\($0.tmdbId)" })
        for item in incoming.continueWatching {
            let key = "\(item.type.rawValue)-\(item.tmdbId)"
            if seenCW.insert(key).inserted {
                target.continueWatching.append(item)
            }
        }

        var seenHist = Set(target.history.map { "\($0.type.rawValue)-\($0.tmdbId)-\($0.season ?? 0)-\($0.episode ?? 0)" })
        for item in incoming.history {
            let key = "\(item.type.rawValue)-\(item.tmdbId)-\(item.season ?? 0)-\(item.episode ?? 0)"
            if seenHist.insert(key).inserted {
                target.history.append(item)
            }
        }

        var seenLiked = Set(target.liked.map(\.key))
        for item in incoming.liked where seenLiked.insert(item.key).inserted {
            target.liked.append(item)
        }

        var seenReminders = Set(target.reminders.map(\.id))
        for item in incoming.reminders where seenReminders.insert(item.id).inserted {
            target.reminders.append(item)
        }

        target.streamingProviderBaseURL = target.streamingProviderBaseURL ?? incoming.streamingProviderBaseURL
        target.accentColorHex = target.accentColorHex ?? incoming.accentColorHex
        target.hapticsEnabled = target.hapticsEnabled ?? incoming.hapticsEnabled
        target.updatedAt = max(target.updatedAt, incoming.updatedAt)
        return target
    }

    private func mergeBucketIntoVault(_ incoming: ProfileVaultBucket, userId: String, profileId: String) {
        var vault = loadVault(for: userId)
        let base = vault.profileData[profileId] ?? ProfileVaultBucket(
            myList: [],
            history: [],
            continueWatching: [],
            liked: [],
            reminders: [],
            streamingProviderBaseURL: nil,
            accentColorHex: nil,
            hapticsEnabled: nil,
            updatedAt: Date().timeIntervalSince1970 * 1000
        )
        vault.profileData[profileId] = mergeBuckets(base, incoming: incoming)
        saveVault(vault, for: userId)
    }

    private func applyRemoteDataToVault(_ remoteData: [String: Any], userId: String, mergeWithExistingLocal: Bool) {
        var vault = loadVault(for: userId)

        if let rawProfiles = remoteData["profiles"] as? [[String: Any]],
           let data = try? JSONSerialization.data(withJSONObject: rawProfiles),
           let decodedProfiles = try? JSONDecoder().decode([UserProfile].self, from: data),
           !decodedProfiles.isEmpty {
            let remoteTs = (remoteData["_profilesTs"] as? Double) ?? 0
            if vault.profiles.isEmpty || remoteTs >= vault.profilesTs {
                profiles = Self.sanitizeProfiles(decodedProfiles, fallbackName: session?.user.name ?? "Main")
                vault.profiles = profiles
                vault.profilesTs = remoteTs
            } else {
                profiles = vault.profiles
            }
        } else if vault.profiles.isEmpty {
            let fallbackName = session?.user.name ?? "Main"
            let mainProfile = UserProfile(
                id: "prof_main",
                name: fallbackName,
                avatarColor: "#E50914",
                isKids: false,
                createdAt: Date().timeIntervalSince1970 * 1000
            )
            profiles = [mainProfile]
            vault.profiles = profiles
        } else {
            profiles = vault.profiles
        }

        if let remoteProfileMap = remoteData["profileData"] as? [String: [String: Any]], !remoteProfileMap.isEmpty {
            for (pid, rawBucket) in remoteProfileMap {
                let remoteBucket = decodeRemoteBucket(rawBucket, profileId: pid)
                if mergeWithExistingLocal, let localBucket = vault.profileData[pid] {
                    if localBucket.updatedAt > remoteBucket.updatedAt {
                        vault.profileData[pid] = mergeBuckets(localBucket, incoming: remoteBucket)
                    } else {
                        vault.profileData[pid] = mergeBuckets(remoteBucket, incoming: localBucket)
                    }
                } else {
                    vault.profileData[pid] = remoteBucket
                }
            }
        } else {
            let legacyRootBucket = decodeRemoteBucket(remoteData, profileId: profiles.first?.id ?? "prof_main")
            let hasLegacyData = !legacyRootBucket.myList.isEmpty || !legacyRootBucket.history.isEmpty || !legacyRootBucket.continueWatching.isEmpty
            if hasLegacyData {
                let targetPid = profiles.first?.id ?? "prof_main"
                if let existing = vault.profileData[targetPid] {
                    vault.profileData[targetPid] = mergeBuckets(existing, incoming: legacyRootBucket)
                } else {
                    vault.profileData[targetPid] = legacyRootBucket
                }
                SingularityDiagnostics.shared.record(category: "Migration", message: "Migrated root-level legacy cloud data into profile \(targetPid).")
            }
        }

        vault.schemaVersion = 2
        saveVault(vault, for: userId)
    }

    private func decodeRemoteBucket(_ raw: [String: Any], profileId: String = "prof_main") -> ProfileVaultBucket {
        var myList: [MyListItem] = []
        let savedMap = (raw["saved"] as? [String: [String: Any]]) ?? [:]
        let savedOrder = (raw["savedOrder"] as? [String]) ?? Array(savedMap.keys)
        var orderIdx = 0
        for key in savedOrder {
            if let entry = savedMap[key], let item = decodeMyListItem(from: entry, key: key, fallbackIndex: orderIdx) {
                myList.append(item)
                orderIdx += 1
            }
        }
        for (key, entry) in savedMap where !savedOrder.contains(key) {
            if let item = decodeMyListItem(from: entry, key: key, fallbackIndex: orderIdx) {
                myList.append(item)
                orderIdx += 1
            }
        }
        if myList.isEmpty, let legacyList = raw["myList"] as? [[String: Any]] {
            for entry in legacyList {
                if let item = decodeMyListItem(from: entry, key: "", fallbackIndex: orderIdx) {
                    myList.append(item)
                    orderIdx += 1
                }
            }
        }
        myList.sort { $0.dateAdded < $1.dateAdded }

        let rawHistory = (raw["history"] as? [[String: Any]]) ?? (raw["watchHistory"] as? [[String: Any]]) ?? []
        var history: [WatchItem] = []
        var cwItems: [ContinueWatchingItem] = []
        let progressMap = (raw["progress"] as? [String: Any]) ?? [:]
        let dlTimes = (raw["_dlTimes"] as? [String: Any]) ?? [:]

        for entry in rawHistory {
            guard let idNum = entry["id"] ?? entry["tmdbId"] else { continue }
            let idStr = "\(idNum)"
            let mediaTypeStr = (entry["media_type"] as? String) ?? (entry["type"] as? String) ?? "movie"
            let type: WatchType = mediaTypeStr == "tv" ? .tv : .movie
            let title = (entry["title"] as? String) ?? (entry["name"] as? String) ?? "Untitled"
            let poster = (entry["poster_path"] as? String) ?? (entry["posterPath"] as? String)
            let season = entry["season"] as? Int
            let episode = entry["episode"] as? Int
            let epName = (entry["episode_name"] as? String) ?? (entry["episodeName"] as? String)
            let watchedMs = (entry["watchedAt"] as? Double) ?? Double((entry["watchedAt"] as? Int) ?? 0)
            let watchedDate = watchedMs > 0 ? Date(timeIntervalSince1970: watchedMs / 1000.0) : Date(timeIntervalSince1970: TimeInterval(history.count))

            let url: URL? = type == .movie
                ? StreamingProviderURLBuilder.movieURL(tmdbId: Int(idStr) ?? 0)
                : StreamingProviderURLBuilder.tvURL(tmdbId: Int(idStr) ?? 0, season: season ?? 1, episode: episode ?? 1)
            guard let playableURL = url else { continue }

            history.append(WatchItem(
                type: type,
                title: title,
                tmdbId: idStr,
                season: season,
                episode: episode,
                episodeName: epName,
                posterPath: poster,
                generatedURL: playableURL,
                dateWatched: watchedDate
            ))

            let pk = type == .tv ? "tv_\(idStr)_s\(season ?? 1)_e\(episode ?? 1)" : "movie_\(idStr)"
            let posSec = (dlTimes["dlTime_" + pk] as? Double) ?? Double((dlTimes["dlTime_" + pk] as? Int) ?? 0)
            let pct = (progressMap[pk] as? Double) ?? Double((progressMap[pk] as? Int) ?? 0)
            let explicitDur = (entry["durationSeconds"] as? Double) ?? Double((entry["durationSeconds"] as? Int) ?? 0)
            let durSec: Double? = explicitDur > 0 ? explicitDur : ((posSec > 0 && pct > 0) ? (posSec / (pct / 100.0)) : nil)

            if pct < 95 {
                cwItems.append(ContinueWatchingItem(
                    type: type,
                    title: title,
                    tmdbId: idStr,
                    season: season,
                    episode: episode,
                    episodeName: epName,
                    posterPath: poster,
                    playableURL: playableURL,
                    lastWatchedDate: watchedDate,
                    progressSeconds: posSec > 0 ? posSec : nil,
                    durationSeconds: durSec
                ))
            }
        }
        history.sort { $0.dateWatched < $1.dateWatched }

        if let rawCW = raw["continueWatching"] as? [[String: Any]],
           let cwData = try? JSONSerialization.data(withJSONObject: rawCW),
           let decodedCW = try? JSONDecoder().decode([ContinueWatchingItem].self, from: cwData) {
            var cwByKey: [String: ContinueWatchingItem] = [:]
            for item in cwItems {
                cwByKey["\(item.type.rawValue)_\(item.tmdbId)"] = item
            }
            for item in decodedCW {
                let k = "\(item.type.rawValue)_\(item.tmdbId)"
                if let existing = cwByKey[k] {
                    if (existing.durationSeconds ?? 0) <= 0, let d = item.durationSeconds, d > 0 {
                        cwByKey[k] = item
                    }
                } else {
                    cwByKey[k] = item
                }
            }
            cwItems = Array(cwByKey.values).sorted { $0.lastWatchedDate > $1.lastWatchedDate }
        }

        var liked: [NFSavedTitle] = []
        if let rawLiked = raw["liked"] as? [[String: Any]],
           let likedData = try? JSONSerialization.data(withJSONObject: rawLiked),
           let decodedLiked = try? JSONDecoder().decode([NFSavedTitle].self, from: likedData) {
            liked = decodedLiked
        }

        var reminders: [NFReminder] = []
        if let rawRem = raw["reminders"] as? [[String: Any]],
           let remData = try? JSONSerialization.data(withJSONObject: rawRem),
           let decodedRem = try? JSONDecoder().decode([NFReminder].self, from: remData) {
            reminders = decodedRem
        }

        let prefs = (raw["playerPrefs"] as? [String: Any]) ?? [:]
        let provider = prefs["streamingProviderBaseURL"] as? String
        let accent = prefs["accentColorHex"] as? String
        let haptics = prefs["hapticsEnabled"] as? Bool

        if let subStyleDict = raw["subtitleStyle"] as? [String: Any],
           let subStyleData = try? JSONSerialization.data(withJSONObject: subStyleDict) {
            defaults.set(subStyleData, forKey: "singularity.subtitleStyle." + profileId)
        }
        if let pPrefsDict = raw["profilePlayerPrefs"] as? [String: Any],
           let pPrefsData = try? JSONSerialization.data(withJSONObject: pPrefsDict) {
            defaults.set(pPrefsData, forKey: "singularity.playerPrefs." + profileId)
        }
        if let webPrefsDict = (raw["webPlayerPrefs"] as? [String: Any]) ?? (prefs["webPlayerPrefs"] as? [String: Any]),
           let webPrefsData = try? JSONSerialization.data(withJSONObject: webPrefsDict) {
            defaults.set(webPrefsData, forKey: "singularity.webPlayerPrefs." + profileId)
        }

        let ts = (raw["_playerPrefsTs"] as? Double) ?? (raw["updatedAt"] as? Double) ?? 0

        return ProfileVaultBucket(
            myList: myList,
            history: history,
            continueWatching: cwItems,
            liked: liked,
            reminders: reminders,
            streamingProviderBaseURL: provider,
            accentColorHex: accent,
            hapticsEnabled: haptics,
            updatedAt: ts
        )
    }

    private func decodeMyListItem(from entry: [String: Any], key: String, fallbackIndex: Int = 0) -> MyListItem? {
        let idInt: Int
        if let n = entry["id"] as? Int {
            idInt = n
        } else if let n = entry["tmdbId"] as? Int {
            idInt = n
        } else if let s = (entry["id"] as? String) ?? (entry["tmdbId"] as? String), let n = Int(s) {
            idInt = n
        } else {
            return nil
        }
        let mediaStr = (entry["media_type"] as? String) ?? (entry["mediaType"] as? String) ?? "movie"
        let type: MediaType = mediaStr == "tv" ? .tv : .movie
        let title = (entry["title"] as? String) ?? (entry["name"] as? String) ?? "Untitled"
        let poster = (entry["poster_path"] as? String) ?? (entry["posterPath"] as? String)
        let addedMs = (entry["dateAdded"] as? Double) ?? Double((entry["dateAdded"] as? Int) ?? 0)
        let addedDate = addedMs > 0 ? Date(timeIntervalSince1970: addedMs / 1000.0) : Date(timeIntervalSince1970: TimeInterval(fallbackIndex))
        return MyListItem(mediaType: type, tmdbId: idInt, title: title, posterPath: poster, backdropPath: nil, overview: nil, year: nil, dateAdded: addedDate)
    }

    private func buildCloudPayload(for userId: String) -> [String: Any] {
        let vault = loadVault(for: userId)
        var profileDataDict: [String: Any] = [:]

        for (pid, bucket) in vault.profileData {
            var savedDict: [String: Any] = [:]
            var savedOrder: [String] = []
            for item in bucket.myList.sorted(by: { $0.dateAdded < $1.dateAdded }) {
                let key = "\(item.mediaType.rawValue)_\(item.tmdbId)"
                savedOrder.append(key)
                var entry: [String: Any] = [
                    "id": item.tmdbId,
                    "media_type": item.mediaType.rawValue,
                    "title": item.title,
                    "dateAdded": Int(item.dateAdded.timeIntervalSince1970 * 1000)
                ]
                if let poster = item.posterPath, !poster.isEmpty {
                    entry["poster_path"] = poster
                }
                savedDict[key] = entry
            }

            var historyArr: [[String: Any]] = []
            for item in bucket.history.sorted(by: { $0.dateWatched < $1.dateWatched }) {
                var row: [String: Any] = [
                    "id": Int(item.tmdbId) ?? 0,
                    "media_type": item.type.rawValue,
                    "title": item.title,
                    "watchedAt": Int(item.dateWatched.timeIntervalSince1970 * 1000)
                ]
                if let poster = item.posterPath { row["poster_path"] = poster }
                if let s = item.season { row["season"] = s }
                if let e = item.episode { row["episode"] = e }
                if let epName = item.episodeName { row["episode_name"] = epName }
                historyArr.append(row)
            }

            var progressDict: [String: Int] = [:]
            var dlTimesDict: [String: Int] = [:]
            for cw in bucket.continueWatching {
                let pk = cw.type == .tv ? "tv_\(cw.tmdbId)_s\(cw.season ?? 1)_e\(cw.episode ?? 1)" : "movie_\(cw.tmdbId)"
                if let frac = cw.progressFraction, frac.isFinite {
                    progressDict[pk] = max(1, min(100, Int(round(frac * 100))))
                }
                if let sec = cw.progressSeconds, sec.isFinite {
                    dlTimesDict["dlTime_" + pk] = Int(sec)
                }
            }

            var playerPrefs: [String: Any] = [:]
            if let provider = bucket.streamingProviderBaseURL { playerPrefs["streamingProviderBaseURL"] = provider }
            if let accent = bucket.accentColorHex { playerPrefs["accentColorHex"] = accent }
            if let haptics = bucket.hapticsEnabled { playerPrefs["hapticsEnabled"] = haptics }

            var bucketPayload: [String: Any] = [
                "saved": savedDict,
                "savedOrder": savedOrder,
                "history": historyArr,
                "progress": progressDict,
                "_dlTimes": dlTimesDict,
                "playerPrefs": playerPrefs,
                "_playerPrefsTs": bucket.updatedAt.isFinite ? bucket.updatedAt : 0
            ]

            if let likedData = try? JSONEncoder().encode(bucket.liked),
               let likedObj = try? JSONSerialization.jsonObject(with: likedData) as? [[String: Any]] {
                bucketPayload["liked"] = likedObj
            }
            if let remData = try? JSONEncoder().encode(bucket.reminders),
               let remObj = try? JSONSerialization.jsonObject(with: remData) as? [[String: Any]] {
                bucketPayload["reminders"] = remObj
            }
            if let subData = defaults.data(forKey: "singularity.subtitleStyle." + pid),
               let subObj = try? JSONSerialization.jsonObject(with: subData) as? [String: Any] {
                bucketPayload["subtitleStyle"] = subObj
            }
            if let ppData = defaults.data(forKey: "singularity.playerPrefs." + pid),
               let ppObj = try? JSONSerialization.jsonObject(with: ppData) as? [String: Any] {
                bucketPayload["profilePlayerPrefs"] = ppObj
            }
            if let cwData = try? JSONEncoder().encode(bucket.continueWatching),
               let cwObj = try? JSONSerialization.jsonObject(with: cwData) as? [[String: Any]] {
                bucketPayload["continueWatching"] = cwObj
            }
            if let wpData = defaults.data(forKey: "singularity.webPlayerPrefs." + pid),
               let wpObj = try? JSONSerialization.jsonObject(with: wpData) as? [String: Any] {
                bucketPayload["webPlayerPrefs"] = wpObj
            }

            profileDataDict[pid] = bucketPayload
        }

        let encodedProfiles: [[String: Any]] = (try? JSONSerialization.jsonObject(
            with: JSONEncoder().encode(vault.profiles)
        ) as? [[String: Any]]) ?? []

        return [
            "schemaVersion": 2,
            "profiles": encodedProfiles,
            "_profilesTs": vault.profilesTs.isFinite ? vault.profilesTs : 0,
            "profileData": profileDataDict
        ]
    }
}
