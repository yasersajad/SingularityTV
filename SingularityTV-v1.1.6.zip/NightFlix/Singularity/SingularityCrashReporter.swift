import Darwin
import Foundation
import UIKit

enum SingularityCrashReporter {
    private static var isInstalled = false
    private static var crashFilePathC: UnsafePointer<CChar>?
    private static var breadcrumbsPathC: UnsafePointer<CChar>?

    private static var crashFileURL: URL {
        let dir = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first
            ?? FileManager.default.temporaryDirectory
        return dir.appendingPathComponent("singularity_pending_crash.txt")
    }

    static var breadcrumbsFileURL: URL {
        let dir = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first
            ?? FileManager.default.temporaryDirectory
        return dir.appendingPathComponent("singularity_breadcrumbs.txt")
    }

    static func install() {
        guard !isInstalled else { return }
        isInstalled = true

        deliverPendingCrashToClipboardIfPresent()

        crashFilePathC = strdup(crashFileURL.path)
        breadcrumbsPathC = strdup(breadcrumbsFileURL.path)

        NSSetUncaughtExceptionHandler { exception in
            let crumbs = (try? String(contentsOf: SingularityCrashReporter.breadcrumbsFileURL, encoding: .utf8)) ?? ""
            let stack = exception.callStackSymbols.joined(separator: "\n")
            let report = """
            === SingularityTV Crash Report (NSException) ===
            Time: \(ISO8601DateFormatter().string(from: Date()))
            Name: \(exception.name.rawValue)
            Reason: \(exception.reason ?? "Unknown")

            --- Stack Trace ---
            \(stack)

            --- Recent Breadcrumbs ---
            \(crumbs)
            """
            try? report.write(to: SingularityCrashReporter.crashFileURL, atomically: true, encoding: .utf8)
        }

        let signals: [Int32] = [SIGABRT, SIGSEGV, SIGBUS, SIGILL, SIGTRAP, SIGFPE]
        for sig in signals {
            var action = sigaction()
            action.__sigaction_u.__sa_handler = handleSignal
            sigemptyset(&action.sa_mask)
            action.sa_flags = SA_RESETHAND
            sigaction(sig, &action, nil)
        }
    }

    private static func deliverPendingCrashToClipboardIfPresent() {
        let url = crashFileURL
        guard FileManager.default.fileExists(atPath: url.path),
              let content = try? String(contentsOf: url, encoding: .utf8),
              !content.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else {
            return
        }
        UIPasteboard.general.string = content
        try? FileManager.default.removeItem(at: url)
    }

    private static let handleSignal: @convention(c) (Int32) -> Void = { sig in
        if let path = crashFilePathC {
            let fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0o644)
            if fd >= 0 {
                let header = "=== SingularityTV Crash Report (Signal \(sig)) ===\n"
                _ = header.withCString { ptr in
                    write(fd, ptr, strlen(ptr))
                }
                if let bPath = breadcrumbsPathC {
                    let bfd = open(bPath, O_RDONLY)
                    if bfd >= 0 {
                        let sub = "\n--- Recent Breadcrumbs ---\n"
                        _ = sub.withCString { ptr in
                            write(fd, ptr, strlen(ptr))
                        }
                        var buf = [UInt8](repeating: 0, count: 1024)
                        while true {
                            let n = read(bfd, &buf, buf.count)
                            if n <= 0 { break }
                            _ = write(fd, buf, n)
                        }
                        close(bfd)
                    }
                }
                close(fd)
            }
        }
        Darwin.signal(sig, SIG_DFL)
        Darwin.raise(sig)
    }
}
