import Foundation

@MainActor
final class SingularityDiagnostics {
    static let shared = SingularityDiagnostics()

    struct Entry: Codable, Identifiable {
        let id: UUID
        let timestamp: Date
        let category: String
        let message: String
    }

    private(set) var entries: [Entry] = []
    private let maxEntries = 100
    private let storageKey = "singularity.diagnostics.log"

    private init() {
        if let data = UserDefaults.standard.data(forKey: storageKey),
           let decoded = try? JSONDecoder().decode([Entry].self, from: data) {
            entries = decoded
        }
    }

    func record(category: String, message: String) {
        let entry = Entry(id: UUID(), timestamp: Date(), category: category, message: message)
        entries.insert(entry, at: 0)
        if entries.count > maxEntries {
            entries = Array(entries.prefix(maxEntries))
        }
        if let data = try? JSONEncoder().encode(entries) {
            UserDefaults.standard.set(data, forKey: storageKey)
        }
        let formatter = ISO8601DateFormatter()
        let snapshot = entries.prefix(40)
            .map { "[\(formatter.string(from: $0.timestamp))] [\($0.category)] \($0.message)" }
            .joined(separator: "\n")
        try? snapshot.write(to: SingularityCrashReporter.breadcrumbsFileURL, atomically: true, encoding: .utf8)
    }

    func record(sessionId: Int, provider: String, category: String, message: String) {
        let host = provider.isEmpty ? "unknown" : provider
        record(category: category, message: "[S\(sessionId) | \(host)] \(message)")
    }

    func clear() {
        entries = []
        UserDefaults.standard.removeObject(forKey: storageKey)
        try? FileManager.default.removeItem(at: SingularityCrashReporter.breadcrumbsFileURL)
    }

    func formattedReport() -> String {
        let formatter = ISO8601DateFormatter()
        return entries.map { "[\(formatter.string(from: $0.timestamp))] [\($0.category)] \($0.message)" }
            .joined(separator: "\n")
    }
}
