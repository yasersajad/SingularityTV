import SwiftUI

struct PlayerServersPanel: View {
    let controller: CustomPlayerController
    let settings: AppSettingsManager
    let accent: Color

    private let speedPresets: [Double] = [0.5, 0.75, 1.0, 1.25, 1.5, 2.0]

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            statusBanner

            HStack(alignment: .top, spacing: 14) {
                VStack(alignment: .leading, spacing: 8) {
                    Text("QUALITY")
                        .font(.caption2.weight(.bold))
                        .foregroundStyle(.white.opacity(0.5))
                        .tracking(0.8)

                    ScrollView {
                        VStack(alignment: .leading, spacing: 4) {
                            if controller.state.qualityLevels.isEmpty {
                                modalRow(title: "Auto", subtitle: "Adaptive", isSelected: true)
                            } else {
                                ForEach(controller.state.qualityLevels) { lvl in
                                    Button {
                                        controller.bridge.selectQualityLevel(index: lvl.id, label: lvl.label)
                                        controller.closePanel()
                                    } label: {
                                        modalRow(title: lvl.label, subtitle: nil, isSelected: lvl.isSelected)
                                    }
                                    .buttonStyle(.plain)
                                }
                            }
                        }
                    }
                    .frame(maxHeight: 165)
                }
                .frame(maxWidth: .infinity, alignment: .leading)

                Rectangle()
                    .fill(Color.white.opacity(0.12))
                    .frame(width: 1)

                VStack(alignment: .leading, spacing: 8) {
                    HStack {
                        Text("SERVER")
                            .font(.caption2.weight(.bold))
                            .foregroundStyle(.white.opacity(0.5))
                            .tracking(0.8)

                        Spacer()

                        Button {
                            HapticManager.shared.selection()
                            controller.bridge.rescanInternalServers()
                        } label: {
                            Image(systemName: PlayerIcon.refresh)
                                .font(.caption2.weight(.bold))
                                .foregroundStyle(.white.opacity(0.75))
                                .padding(5)
                                .background(Color.white.opacity(0.08), in: Circle())
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel("Scan Servers")
                    }

                    if controller.internalServers.servers.isEmpty {
                        Text("Scanning vidly.pro servers...")
                            .font(.caption)
                            .foregroundStyle(.white.opacity(0.55))
                            .padding(.vertical, 8)
                    } else {
                        ScrollView {
                            VStack(alignment: .leading, spacing: 4) {
                                ForEach(controller.internalServers.servers) { server in
                                    Button {
                                        Task {
                                            let ok = await controller.switchInternalServer(to: server)
                                            if ok {
                                                controller.closePanel()
                                            }
                                        }
                                    } label: {
                                        modalRow(
                                            title: server.name,
                                            subtitle: server.isAvailable ? nil : "Unavailable",
                                            isSelected: server.isSelected
                                        )
                                    }
                                    .buttonStyle(.plain)
                                    .disabled(!server.isAvailable)
                                    .opacity(server.isAvailable ? 1.0 : 0.5)
                                }
                            }
                        }
                        .frame(maxHeight: 165)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }

            Divider().background(Color.white.opacity(0.12))

            HStack(spacing: 6) {
                Text("SPEED")
                    .font(.caption2.weight(.bold))
                    .foregroundStyle(.white.opacity(0.5))
                    .tracking(0.8)

                Spacer(minLength: 4)

                ForEach(speedPresets, id: \.self) { rate in
                    let selected = abs(controller.state.playbackRate - rate) < 0.01
                    Button {
                        controller.setPlaybackRate(rate)
                    } label: {
                        Text(String(format: "%.2gx", rate))
                            .font(.caption2.weight(.bold).monospacedDigit())
                            .foregroundStyle(selected ? .black : .white.opacity(0.8))
                            .padding(.horizontal, 9)
                            .padding(.vertical, 5)
                            .background(selected ? Color.white : Color.clear, in: RoundedRectangle(cornerRadius: 6))
                    }
                    .buttonStyle(.plain)
                }
            }
        }
        .onAppear {
            controller.bridge.rescanInternalServers()
        }
    }

    private func modalRow(title: String, subtitle: String?, isSelected: Bool) -> some View {
        HStack(spacing: 8) {
            Image(systemName: "checkmark")
                .font(.caption.weight(.bold))
                .foregroundStyle(.white)
                .opacity(isSelected ? 1 : 0)
                .frame(width: 14)

            VStack(alignment: .leading, spacing: 1) {
                Text(title)
                    .font(.subheadline.weight(isSelected ? .bold : .medium))
                    .foregroundStyle(isSelected ? .white : .white.opacity(0.82))
                    .lineLimit(1)
                if let subtitle, !subtitle.isEmpty {
                    Text(subtitle)
                        .font(.caption2)
                        .foregroundStyle(.white.opacity(0.5))
                        .lineLimit(1)
                }
            }

            Spacer(minLength: 0)
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 7)
        .background(isSelected ? Color.white.opacity(0.1) : Color.clear, in: RoundedRectangle(cornerRadius: 8))
    }

    @ViewBuilder
    private var statusBanner: some View {
        switch controller.internalServers.switchState {
        case .switching(let name):
            HStack(spacing: 8) {
                ProgressView().tint(accent)
                Text("Switching server to \(name)...")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.85))
            }
            .padding(8)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 8))

        case .failed(let message):
            Text(message)
                .font(.caption)
                .foregroundStyle(Color(hex: "FF8C92"))
                .padding(8)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(accent.opacity(0.16), in: RoundedRectangle(cornerRadius: 8))

        case .switched(let name):
            Text("Server: \(name)")
                .font(.caption.weight(.semibold))
                .foregroundStyle(Color(hex: "7BE3A2"))
                .padding(8)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.green.opacity(0.14), in: RoundedRectangle(cornerRadius: 8))

        case .idle:
            EmptyView()
        }
    }
}
