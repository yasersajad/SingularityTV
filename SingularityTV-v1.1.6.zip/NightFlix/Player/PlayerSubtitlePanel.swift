import SwiftUI

struct PlayerSubtitlePanel: View {
    let controller: CustomPlayerController
    let accent: Color
    let onOpenExternalSearch: () -> Void

    var body: some View {
        let style = controller.subtitles.stylePrefs

        VStack(alignment: .leading, spacing: 14) {
            ZStack {
                LinearGradient(
                    colors: [Color(hex: "1C2536"), Color(hex: "0F131C")],
                    startPoint: .topLeading,
                    endPoint: .bottomTrailing
                )
                .frame(height: 82)
                .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                .overlay {
                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                        .stroke(Color.white.opacity(0.1), lineWidth: 1)
                }

                Text("This is how subtitles look")
                    .font(.system(size: min(max(style.fontSize * 0.9, 13), 24), weight: style.isBoldText ? .bold : .semibold))
                    .foregroundStyle(Color(hex: style.textColorHex))
                    .padding(.horizontal, 12)
                    .padding(.vertical, 5)
                    .background(Color.black.opacity(style.bgOpacity), in: RoundedRectangle(cornerRadius: 6, style: .continuous))
                    .overlay {
                        if style.textEdge == .outline {
                            RoundedRectangle(cornerRadius: 6, style: .continuous)
                                .stroke(Color.black.opacity(0.85), lineWidth: 1.2)
                        }
                    }
                    .shadow(color: style.textEdge == .shadow ? .black.opacity(0.95) : .clear, radius: style.textEdge == .shadow ? 4 : 0, y: 1)
            }

            VStack(alignment: .leading, spacing: 6) {
                Text("Text size")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.85))
                HStack(spacing: 10) {
                    Image(systemName: "textformat.size")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.6))
                    Slider(
                        value: Binding(
                            get: { controller.subtitles.stylePrefs.fontSize },
                            set: {
                                controller.subtitles.stylePrefs.fontSize = $0
                                controller.saveSubtitleStyle()
                            }
                        ),
                        in: 14...28,
                        step: 1
                    )
                    .tint(.white)
                    Text("\(Int((style.fontSize / 17.0) * 100))%")
                        .font(.caption.weight(.semibold).monospacedDigit())
                        .foregroundStyle(.white.opacity(0.8))
                        .frame(width: 44, alignment: .trailing)
                }
            }

            VStack(alignment: .leading, spacing: 8) {
                Text("Colour")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.85))
                HStack(spacing: 12) {
                    ForEach(SubtitleStylePrefs.colorPresets, id: \.hex) { preset in
                        let selected = style.textColorHex == preset.hex
                        Button {
                            controller.subtitles.stylePrefs.textColorHex = preset.hex
                            controller.saveSubtitleStyle()
                        } label: {
                            Circle()
                                .fill(Color(hex: preset.hex))
                                .frame(width: 26, height: 26)
                                .overlay {
                                    if selected {
                                        Circle()
                                            .stroke(Color.white, lineWidth: 2.5)
                                            .padding(-3)
                                    }
                                }
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel(preset.name)
                    }
                }
            }

            VStack(alignment: .leading, spacing: 8) {
                Text("Text edge")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.85))
                HStack(spacing: 4) {
                    ForEach(SubtitleTextEdge.allCases) { edge in
                        let selected = style.textEdge == edge
                        Button {
                            controller.subtitles.stylePrefs.textEdge = edge
                            controller.subtitles.stylePrefs.shadowEnabled = (edge == .shadow)
                            controller.subtitles.stylePrefs.hasOutline = (edge == .outline)
                            controller.saveSubtitleStyle()
                        } label: {
                            Text(edge.rawValue)
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(selected ? .black : .white.opacity(0.75))
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 8)
                                .background(selected ? Color.white : Color.clear, in: RoundedRectangle(cornerRadius: 8))
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(3)
                .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 10))
            }

            Toggle(isOn: Binding(
                get: { controller.subtitles.stylePrefs.isBoldText },
                set: {
                    controller.subtitles.stylePrefs.isBoldText = $0
                    controller.saveSubtitleStyle()
                }
            )) {
                Text("Bold text")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white)
            }
            .tint(.white)

            VStack(alignment: .leading, spacing: 6) {
                Text("Background")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.85))
                HStack(spacing: 10) {
                    Image(systemName: "rectangle.inset.filled")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.6))
                    Slider(
                        value: Binding(
                            get: { controller.subtitles.stylePrefs.bgOpacity },
                            set: {
                                controller.subtitles.stylePrefs.bgOpacity = $0
                                controller.saveSubtitleStyle()
                            }
                        ),
                        in: 0.0...1.0,
                        step: 0.05
                    )
                    .tint(.white)
                    Text("\(Int(style.bgOpacity * 100))%")
                        .font(.caption.weight(.semibold).monospacedDigit())
                        .foregroundStyle(.white.opacity(0.8))
                        .frame(width: 44, alignment: .trailing)
                }
            }

            VStack(alignment: .leading, spacing: 6) {
                Text("Vertical position")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.85))
                HStack(spacing: 10) {
                    Image(systemName: "arrow.up.and.down")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.6))
                    Slider(
                        value: Binding(
                            get: { controller.subtitles.stylePrefs.positionPercent },
                            set: {
                                controller.subtitles.stylePrefs.positionPercent = $0
                                controller.saveSubtitleStyle()
                            }
                        ),
                        in: 10...96,
                        step: 1
                    )
                    .tint(.white)
                    Text("\(Int(max(0, 100 - style.positionPercent)))%")
                        .font(.caption.weight(.semibold).monospacedDigit())
                        .foregroundStyle(.white.opacity(0.8))
                        .frame(width: 44, alignment: .trailing)
                }
            }

            if controller.subtitles.hasActiveExternalSubtitles {
                HStack {
                    Label(String(format: "Sync: %+.1fs", controller.subtitles.offsetSeconds), systemImage: "timer")
                        .font(.caption.weight(.semibold).monospacedDigit())
                        .foregroundStyle(.white)
                    Spacer()
                    Button("-0.5s") { controller.subtitles.offsetSeconds -= 0.5 }
                        .font(.caption2.weight(.bold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 5)
                        .background(Color.white.opacity(0.1), in: Capsule())
                        .buttonStyle(.plain)
                    Button("0s") { controller.subtitles.offsetSeconds = 0 }
                        .font(.caption2.weight(.bold))
                        .foregroundStyle(.white.opacity(0.75))
                        .padding(.horizontal, 8)
                        .padding(.vertical, 5)
                        .background(Color.white.opacity(0.08), in: Capsule())
                        .buttonStyle(.plain)
                    Button("+0.5s") { controller.subtitles.offsetSeconds += 0.5 }
                        .font(.caption2.weight(.bold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 5)
                        .background(Color.white.opacity(0.1), in: Capsule())
                        .buttonStyle(.plain)
                }
            }

            HStack(spacing: 10) {
                Button {
                    controller.subtitles.stylePrefs = SubtitleStylePrefs()
                    controller.saveSubtitleStyle()
                } label: {
                    Text("Reset to default")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.white.opacity(0.75))
                        .padding(.horizontal, 14)
                        .padding(.vertical, 9)
                        .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 10))
                }
                .buttonStyle(.plain)

                Spacer()

                Button {
                    controller.state.activePanel = .none
                    onOpenExternalSearch()
                } label: {
                    Label("External subtitles", systemImage: "magnifyingglass")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 9)
                        .background(accent, in: RoundedRectangle(cornerRadius: 10))
                }
                .buttonStyle(NFScaleButtonStyle())
            }
        }
    }
}
