import AVFoundation
import SwiftUI

struct CustomPlayerView: View {
    let item: WatchItem
    var continueWatchingManager: ContinueWatchingManager?
    var historyManager: WatchHistoryManager?

    @Environment(\.dismiss) private var dismiss
    @Environment(\.nightflixAccent) private var accent
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @EnvironmentObject private var settings: AppSettingsManager

    @State private var controller: CustomPlayerController
    @State private var gestureController = PlayerGestureController()
    @State private var isShowingExternalSubSearch = false

    init(
        item: WatchItem,
        continueWatchingManager: ContinueWatchingManager?,
        historyManager: WatchHistoryManager? = nil
    ) {
        self.item = item
        self.continueWatchingManager = continueWatchingManager
        self.historyManager = historyManager
        _controller = State(
            initialValue: CustomPlayerController(
                item: item,
                continueWatchingManager: continueWatchingManager,
                historyManager: historyManager
            )
        )
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            SingularityWebPlayerView(
                url: controller.activeURL,
                reloadToken: controller.state.reloadToken,
                bridgeController: controller.bridge,
                onLoadingChanged: { loading in
                    controller.state.isLoading = loading
                },
                onError: { err in
                    controller.state.errorMessage = err
                },
                onEvent: { event in
                    controller.handleBridgeEvent(event)
                }
            )
            .ignoresSafeArea()

            PlayerGestureOverlay(
                controller: controller,
                gestureController: gestureController,
                onSingleTap: { controller.toggleChrome() },
                onDoubleTapBackward: { controller.skip(by: -10) },
                onDoubleTapForward: { controller.skip(by: 10) }
            )

            nativeSubtitleOverlay

            if controller.startup.stage.shouldShowLoadingOverlay && controller.state.errorMessage == nil && !controller.state.isSourceUnavailable {
                loadingOverlay
                    .transition(.opacity)
            }

            if controller.state.isChromeVisible && controller.state.errorMessage == nil && !controller.state.isSourceUnavailable {
                PlayerChromeView(
                    item: item,
                    controller: controller,
                    accent: accent,
                    onBack: {
                        HapticManager.shared.lightImpact()
                        dismiss()
                    }
                )
                .ignoresSafeArea(edges: .horizontal)
                .transition(.opacity)
            }

            if controller.isSkipIntroVisible && controller.state.errorMessage == nil && !controller.state.isSourceUnavailable {
                skipIntroOverlay
                    .transition(.opacity.combined(with: .move(edge: .trailing)))
            }

            PlayerGestureHUDs(gestureState: gestureController.gestureState, accent: accent)
                .zIndex(15)

            if let countdown = controller.state.nextEpisodeCountdown,
               let nextEp = controller.nextEpisodePayload {
                nextEpisodeOverlay(nextEp: nextEp, secondsLeft: countdown)
                    .transition(.opacity.combined(with: .move(edge: .bottom)))
            }

            if controller.state.activePanel != .none {
                panelOverlay
                    .transition(reduceMotion ? .opacity : .move(edge: .bottom).combined(with: .opacity))
            }

            if let errMsg = controller.state.errorMessage {
                failureOverlay(title: "Playback Error", message: errMsg)
            } else if case .timedOut(let timeoutMsg) = controller.startup.stage {
                failureOverlay(title: "Playback Timed Out", message: timeoutMsg)
            } else if controller.state.isSourceUnavailable {
                failureOverlay(
                    title: "Source Unavailable",
                    message: "This server couldn't stream this title right now. Try switching servers or retrying."
                )
            }
        }
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.24), value: controller.state.isChromeVisible)
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.2), value: controller.state.isLoading)
        .animation(reduceMotion ? nil : .spring(response: 0.34, dampingFraction: 0.85), value: controller.state.activePanel)
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.2), value: controller.isSkipIntroVisible)
        .statusBarHidden()
        .persistentSystemOverlays(.hidden)
        .toolbar(.hidden, for: .navigationBar)
        .preferredColorScheme(.dark)
        .onAppear {
            Self.activatePlaybackAudioSession()
            NFOrientation.enterPlayback()
            controller.onAppear()
        }
        .onDisappear {
            gestureController.cleanup()
            controller.onDisappear()
            NFOrientation.exitPlayback()
            Self.deactivatePlaybackAudioSession()
        }
        .sheet(isPresented: $isShowingExternalSubSearch) {
            ExternalSubtitleSearchSheet(
                tmdbId: item.tmdbId,
                title: item.title,
                season: controller.state.playingSeason ?? item.season,
                episode: controller.state.playingEpisode ?? item.episode,
                hasActiveSubtitles: controller.subtitles.hasActiveExternalSubtitles,
                offsetSeconds: Binding(
                    get: { controller.subtitles.offsetSeconds },
                    set: { controller.subtitles.offsetSeconds = $0 }
                ),
                onSelectCues: { cues, name in
                    controller.subtitles.setExternalSubtitles(cues: cues, name: name)
                    controller.bridge.selectTextTrack(index: nil)
                },
                onClearSubtitles: {
                    controller.subtitles.clearExternalSubtitles()
                }
            )
            .presentationBackground(Color(hex: "0B0B10"))
            .presentationDragIndicator(.visible)
        }
    }

    @ViewBuilder
    private var nativeSubtitleOverlay: some View {
        let activeText = controller.subtitles.activeCue(at: controller.state.currentTime)?.text
            ?? (controller.subtitles.activeSource == .inStream ? controller.subtitles.liveInStreamCueText : nil)
        let previewText = (activeText == nil && controller.state.activePanel == .subtitles && !controller.subtitles.isAllOff)
            ? "This is how subtitles look"
            : nil
        if let displayText = activeText ?? previewText {
            let style = controller.subtitles.stylePrefs
            GeometryReader { geo in
                let topMargin: CGFloat = 64
                let bottomMargin: CGFloat = controller.state.isChromeVisible ? 104 : 30
                let usableHeight = max(80, geo.size.height - topMargin - bottomMargin)
                let fraction = min(max(style.positionPercent / 100.0, 0), 1)
                let yOffset = topMargin + (usableHeight * fraction)

                let isArabic = displayText.range(of: "[\u{0600}-\u{06FF}]", options: .regularExpression) != nil
                Text(displayText)
                    .font(.system(size: style.fontSize, weight: style.isBoldText ? .bold : .semibold))
                    .foregroundStyle(Color(hex: style.textColorHex))
                    .multilineTextAlignment(style.textAlignment.swiftUIAlignment)
                    .environment(\.layoutDirection, isArabic ? .rightToLeft : .leftToRight)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 8)
                    .background(subtitleBackground(style), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
                    .overlay {
                        if style.textEdge == .outline || style.hasOutline {
                            RoundedRectangle(cornerRadius: 8, style: .continuous)
                                .stroke(Color.black.opacity(0.85), lineWidth: 1.2)
                        }
                    }
                    .shadow(color: (style.textEdge == .shadow || style.shadowEnabled) && style.textEdge != .none ? .black.opacity(0.95) : .clear, radius: style.textEdge != .none ? 4 : 0, y: 1)
                    .padding(.horizontal, 28)
                    .frame(maxWidth: .infinity)
                    .position(x: geo.size.width / 2, y: min(max(yOffset, topMargin), geo.size.height - bottomMargin))
            }
            .allowsHitTesting(false)
        }
    }

    private func subtitleBackground(_ style: SubtitleStylePrefs) -> Color {
        switch style.bgStyle {
        case .dark: return Color.black.opacity(style.bgOpacity)
        case .translucent: return Color.black.opacity(style.bgOpacity * 0.55)
        case .none: return Color.clear
        }
    }

    private var skipIntroOverlay: some View {
        VStack {
            Spacer()
            HStack {
                Spacer()
                Button {
                    controller.skipIntro()
                } label: {
                    Label("Skip Intro", systemImage: "forward.end.alt.fill")
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 18)
                        .padding(.vertical, 10)
                        .background(Color.black.opacity(0.72), in: RoundedRectangle(cornerRadius: 10, style: .continuous))
                        .overlay {
                            RoundedRectangle(cornerRadius: 10, style: .continuous)
                                .stroke(Color.white.opacity(0.35), lineWidth: 1)
                        }
                }
                .buttonStyle(NFScaleButtonStyle())
                .accessibilityLabel("Skip Intro")
            }
            .padding(.horizontal, 28)
            .padding(.bottom, controller.state.isChromeVisible ? 104 : 36)
        }
        .zIndex(12)
    }

    private var panelOverlay: some View {
        GeometryReader { geo in
            ZStack(alignment: .center) {
                Color.black.opacity(0.58)
                    .ignoresSafeArea()
                    .onTapGesture {
                        controller.closePanel()
                    }

                VStack(spacing: 0) {
                    panelHeader
                    Divider().background(Color.white.opacity(0.12))
                    ScrollView {
                        VStack(alignment: .leading, spacing: 16) {
                            switch controller.state.activePanel {
                            case .subtitles:
                                PlayerSubtitlePanel(controller: controller, accent: accent) {
                                    isShowingExternalSubSearch = true
                                }
                            case .audio:
                                PlayerAudioPanel(controller: controller, settings: settings, accent: accent) {
                                    isShowingExternalSubSearch = true
                                }
                            case .servers:
                                PlayerServersPanel(controller: controller, settings: settings, accent: accent)
                            case .settings:
                                PlayerSettingsPanel(controller: controller, accent: accent)
                            case .episodes:
                                PlayerEpisodesPanel(controller: controller, accent: accent)
                            case .none:
                                EmptyView()
                            }
                        }
                        .padding(18)
                    }
                }
                .frame(
                    maxWidth: min(560, max(300, geo.size.width - 48)),
                    maxHeight: min(335, max(230, geo.size.height - 36))
                )
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                .background(Color(hex: "0D0D14").opacity(0.94), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
                .overlay {
                    RoundedRectangle(cornerRadius: 22, style: .continuous)
                        .stroke(Color.white.opacity(0.14), lineWidth: 1)
                }
                .shadow(color: .black.opacity(0.65), radius: 24, y: 10)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
        }
    }

    private var panelHeader: some View {
        HStack {
            Text(panelTitle)
                .font(.headline.weight(.bold))
                .foregroundStyle(.white)
            Spacer()
            Button {
                controller.closePanel()
            } label: {
                Image(systemName: "xmark")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.white.opacity(0.8))
                    .frame(width: 30, height: 30)
                    .background(Color.white.opacity(0.1), in: Circle())
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Close Panel")
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 14)
    }

    private var panelTitle: String {
        switch controller.state.activePanel {
        case .subtitles: return "Subtitles"
        case .audio: return "Audio & Subtitles"
        case .servers: return "Quality · Servers"
        case .settings: return "Playback"
        case .episodes: return "Season \(controller.state.playingSeason ?? 1) Episodes"
        case .none: return ""
        }
    }

    private func nextEpisodeOverlay(nextEp: NFEpisodePayload, secondsLeft: Int) -> some View {
        VStack {
            Spacer()
            HStack {
                Spacer()
                HStack(spacing: 12) {
                    if let still = nextEp.stillPath {
                        NFImage(url: NF.imageURL(still, .still))
                            .frame(width: 92, height: 52)
                            .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))
                    }

                    VStack(alignment: .leading, spacing: 3) {
                        Text("NEXT EPISODE IN \(secondsLeft)S")
                            .font(.caption2.weight(.black))
                            .foregroundStyle(accent)
                        Text(item.title)
                            .font(.caption2.weight(.semibold))
                            .foregroundStyle(.white.opacity(0.65))
                            .lineLimit(1)
                        Text("S\(nextEp.seasonNumber) · E\(nextEp.episodeNumber) · \(nextEp.displayName)")
                            .font(.caption.weight(.bold))
                            .foregroundStyle(.white)
                            .lineLimit(1)

                        HStack(spacing: 10) {
                            Button {
                                controller.playNextEpisode()
                            } label: {
                                Label("Play Next", systemImage: "play.fill")
                                    .font(.caption2.weight(.bold))
                                    .foregroundStyle(.black)
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 6)
                                    .background(Color.white, in: RoundedRectangle(cornerRadius: 6, style: .continuous))
                            }
                            .buttonStyle(NFScaleButtonStyle())

                            Button("Cancel") {
                                controller.cancelNextEpisodeCountdown()
                            }
                            .font(.caption2.weight(.bold))
                            .foregroundStyle(.white.opacity(0.8))
                        }
                        .padding(.top, 2)
                    }
                }
                .padding(12)
                .frame(maxWidth: 360)
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14))
                .background(Color.black.opacity(0.84), in: RoundedRectangle(cornerRadius: 14))
                .overlay {
                    RoundedRectangle(cornerRadius: 14).stroke(Color.white.opacity(0.16), lineWidth: 1)
                }
            }
            .padding(.horizontal, 28)
            .padding(.bottom, 96)
        }
    }

    private func skipFeedbackBadge(text: String, isForward: Bool) -> some View {
        VStack(spacing: 6) {
            Image(systemName: isForward ? "goforward.10" : "gobackward.10")
                .font(.system(size: 28, weight: .bold))
            Text(text)
                .font(.caption.weight(.bold))
        }
        .foregroundStyle(.white)
        .padding(18)
        .background(Color.black.opacity(0.72), in: Circle())
        .allowsHitTesting(false)
    }

    private var loadingOverlay: some View {
        VStack(spacing: 16) {
            ProgressView()
                .progressViewStyle(.circular)
                .tint(accent)
                .scaleEffect(1.35)
                .frame(width: 46, height: 46)
            Text(item.title)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.white.opacity(0.9))
            if let stageText = controller.startup.stage.statusText {
                Text(stageText)
                    .font(.caption.weight(.medium))
                    .foregroundStyle(.white.opacity(0.62))
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.black.opacity(0.6))
        .allowsHitTesting(false)
    }

    private func failureOverlay(title: String, message: String) -> some View {
        ZStack {
            Color.black.opacity(0.88).ignoresSafeArea()
            VStack(spacing: 14) {
                Image(systemName: "exclamationmark.triangle.fill")
                    .font(.system(size: 32))
                    .foregroundStyle(accent)
                Text(title)
                    .font(.headline.weight(.bold))
                    .foregroundStyle(.white)
                Text(message)
                    .font(.footnote)
                    .foregroundStyle(.white.opacity(0.72))
                    .multilineTextAlignment(.center)
                    .frame(maxWidth: 340)

                HStack(spacing: 10) {
                    Button("Back") {
                        dismiss()
                    }
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 18)
                    .padding(.vertical, 11)
                    .background(Color.white.opacity(0.14), in: Capsule())

                    Button {
                        controller.openPanel(.servers)
                    } label: {
                        Label("Switch Server", systemImage: "server.rack")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 11)
                            .background(Color.white.opacity(0.18), in: Capsule())
                    }

                    Button("Retry") {
                        controller.retry()
                    }
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 18)
                    .padding(.vertical, 11)
                    .background(accent, in: Capsule())
                }
            }
            .padding(24)
        }
    }

    private static func activatePlaybackAudioSession() {
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback, mode: .moviePlayback)
        try? session.setActive(true)
    }

    private static func deactivatePlaybackAudioSession() {
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }
}
