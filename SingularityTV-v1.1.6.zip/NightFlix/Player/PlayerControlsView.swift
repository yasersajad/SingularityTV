import SwiftUI

struct PlayerControlsView: View {
    let controller: CustomPlayerController
    let accent: Color

    @State private var isRewindAnimating = false
    @State private var rewindHideTask: Task<Void, Never>?
    @State private var isForwardAnimating = false
    @State private var forwardHideTask: Task<Void, Never>?

    var body: some View {
        ZStack {
            HStack(spacing: 64) {
                Button {
                    triggerRewindAnimation()
                    controller.skip(by: -10)
                } label: {
                    Image(systemName: PlayerIcon.rewind10)
                        .font(.system(size: 32, weight: .regular))
                        .foregroundStyle(.white)
                        .frame(width: 64, height: 64)
                        .overlay {
                            if isRewindAnimating {
                                seekButtonPulseOverlay(text: "-10s")
                            }
                        }
                }
                .buttonStyle(NFScaleButtonStyle())
                .accessibilityLabel("Rewind 10 seconds")

                Button {
                    controller.togglePlayPause()
                } label: {
                    Image(systemName: controller.state.isPlaying ? PlayerIcon.pause : PlayerIcon.play)
                        .font(.system(size: 46, weight: .bold))
                        .foregroundStyle(.white)
                        .frame(width: 76, height: 76)
                }
                .buttonStyle(NFScaleButtonStyle())
                .accessibilityLabel(controller.state.isPlaying ? "Pause" : "Play")

                Button {
                    triggerForwardAnimation()
                    controller.skip(by: 10)
                } label: {
                    Image(systemName: PlayerIcon.forward10)
                        .font(.system(size: 32, weight: .regular))
                        .foregroundStyle(.white)
                        .frame(width: 64, height: 64)
                        .overlay {
                            if isForwardAnimating {
                                seekButtonPulseOverlay(text: "+10s")
                            }
                        }
                }
                .buttonStyle(NFScaleButtonStyle())
                .accessibilityLabel("Forward 10 seconds")
            }

            VStack(spacing: 0) {
                Spacer(minLength: 0)
                VStack(spacing: 12) {
                    HStack(spacing: 12) {
                        PlayerProgressBar(
                            currentTime: controller.state.currentTime,
                            duration: controller.state.duration,
                            progressFraction: controller.state.progressFraction,
                            bufferedFraction: controller.state.bufferedFraction,
                            accent: accent,
                            onSeekDragChanged: {
                                controller.state.visibility.beginGesture(.scrubbing)
                            },
                            onSeekEnded: { fraction in
                                controller.seek(to: fraction)
                                controller.state.visibility.endGesture(hasCountdownOverlay: controller.state.nextEpisodeCountdown != nil)
                            }
                        )

                        Text(PlayerStateManager.formatTime(controller.state.remainingTime))
                            .font(.caption.weight(.semibold).monospacedDigit())
                            .foregroundStyle(.white.opacity(0.92))
                            .frame(minWidth: 46, alignment: .trailing)
                    }

                    HStack(spacing: 16) {
                        Spacer(minLength: 0)

                        bottomActionButton(
                            icon: PlayerIcon.speed,
                            title: "Speed (\(String(format: "%.2gx", controller.state.playbackRate)))"
                        ) {
                            controller.openPanel(.settings)
                        }

                        Spacer(minLength: 0)

                        bottomActionButton(icon: PlayerIcon.unlock, title: "Lock") {
                            controller.toggleControlsLock()
                        }

                        if controller.initialItem.type == .tv {
                            Spacer(minLength: 0)
                            bottomActionButton(icon: "rectangle.stack", title: "Episodes") {
                                controller.openPanel(.episodes)
                            }
                        }

                        Spacer(minLength: 0)

                        bottomActionButton(
                            icon: controller.subtitles.hasActiveExternalSubtitles ? PlayerIcon.subtitlesActive : PlayerIcon.subtitles,
                            title: "Audio & Subtitles"
                        ) {
                            controller.openPanel(.audio)
                        }

                        Spacer(minLength: 0)

                        bottomActionButton(icon: "slider.horizontal.3", title: "Quality · Servers") {
                            controller.openPanel(.servers)
                        }

                        if controller.hasNextEpisode {
                            Spacer(minLength: 0)
                            bottomActionButton(icon: PlayerIcon.nextEpisode, title: "Next Ep.") {
                                controller.playNextEpisode()
                            }
                        }

                        Spacer(minLength: 0)
                    }
                    .padding(.top, 2)
                }
                .padding(.horizontal, 28)
                .padding(.bottom, 16)
                .padding(.top, 28)
                .background(
                    LinearGradient(
                        colors: [.clear, .black.opacity(0.45), .black.opacity(0.88)],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                    .ignoresSafeArea(edges: .bottom)
                    .allowsHitTesting(false)
                )
            }
        }
    }

    private func seekButtonPulseOverlay(text: String) -> some View {
        ZStack {
            Circle()
                .fill(accent.opacity(0.32))
            Circle()
                .stroke(accent.opacity(0.85), lineWidth: 1.5)
            Text(text)
                .font(.caption2.weight(.black).monospacedDigit())
                .foregroundStyle(.white)
                .padding(.horizontal, 6)
                .padding(.vertical, 3)
                .background(Color.black.opacity(0.75), in: Capsule())
        }
        .frame(width: 60, height: 60)
        .allowsHitTesting(false)
        .transition(.opacity.combined(with: .scale(scale: 0.92)))
    }

    private func triggerRewindAnimation() {
        rewindHideTask?.cancel()
        withAnimation(.easeOut(duration: 0.14)) {
            isRewindAnimating = true
        }
        rewindHideTask = Task { @MainActor in
            try? await Task.sleep(for: .milliseconds(480))
            guard !Task.isCancelled else { return }
            withAnimation(.easeOut(duration: 0.2)) {
                isRewindAnimating = false
            }
        }
    }

    private func triggerForwardAnimation() {
        forwardHideTask?.cancel()
        withAnimation(.easeOut(duration: 0.14)) {
            isForwardAnimating = true
        }
        forwardHideTask = Task { @MainActor in
            try? await Task.sleep(for: .milliseconds(480))
            guard !Task.isCancelled else { return }
            withAnimation(.easeOut(duration: 0.2)) {
                isForwardAnimating = false
            }
        }
    }

    private func bottomActionButton(icon: String, title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            HStack(spacing: 6) {
                Image(systemName: icon)
                    .font(.system(size: 14, weight: .semibold))
                Text(title)
                    .font(.system(size: 12, weight: .semibold))
                    .lineLimit(1)
            }
            .foregroundStyle(.white.opacity(0.95))
            .padding(.vertical, 6)
        }
        .buttonStyle(NFScaleButtonStyle())
    }
}
