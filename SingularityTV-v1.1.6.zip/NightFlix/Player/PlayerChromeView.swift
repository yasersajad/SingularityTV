import AVKit
import SwiftUI

struct PlayerChromeView: View {
    let item: WatchItem
    let controller: CustomPlayerController
    let accent: Color
    let onBack: () -> Void

    private var headerTitle: String {
        if item.type == .tv,
           let s = controller.state.playingSeason,
           let e = controller.state.playingEpisode {
            if let epName = controller.state.playingEpisodeName, !epName.isEmpty {
                return "S\(s):E\(e) \"\(epName)\""
            }
            return "\(item.title) · S\(s):E\(e)"
        }
        return item.title
    }

    var body: some View {
        ZStack {
            if controller.state.visibility.isControlsLocked {
                lockedOverlay
            } else {
                if controller.state.canControlMediaElement {
                    PlayerControlsView(controller: controller, accent: accent)
                }

                VStack(spacing: 0) {
                    topBar
                    Spacer(minLength: 0)
                }
            }
        }
    }

    private var lockedOverlay: some View {
        VStack {
            HStack {
                Spacer()
                Button {
                    controller.toggleControlsLock()
                } label: {
                    Label("Unlock Controls", systemImage: PlayerIcon.lock)
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 8)
                        .background(.ultraThinMaterial, in: Capsule())
                        .background(Color.black.opacity(0.65), in: Capsule())
                        .overlay { Capsule().stroke(accent.opacity(0.65), lineWidth: 1) }
                }
                .buttonStyle(NFScaleButtonStyle())
                .accessibilityLabel("Unlock Controls")
                Spacer()
            }
            .padding(.top, 18)
            Spacer()
        }
    }

    private var topBar: some View {
        HStack(spacing: 14) {
            HStack(spacing: 10) {
                AirPlayRouteButton()
                    .frame(width: 32, height: 32)
                    .accessibilityLabel("AirPlay")

                HStack(spacing: 6) {
                    Image(systemName: PlayerIcon.brightness)
                        .font(.system(size: 13, weight: .semibold))
                        .foregroundStyle(.white.opacity(0.9))
                    Slider(
                        value: Binding(
                            get: { controller.state.screenBrightness },
                            set: { controller.setScreenBrightness($0) }
                        ),
                        in: 0.05...1.0
                    )
                    .tint(.white)
                    .frame(width: 92)
                }
            }

            Spacer(minLength: 8)

            Text(headerTitle)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(.white)
                .lineLimit(1)
                .truncationMode(.tail)

            Spacer(minLength: 8)

            HStack(spacing: 10) {
                Button {
                    controller.openPanel(.settings)
                } label: {
                    Image(systemName: PlayerIcon.settings)
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundStyle(controller.state.activePanel == .settings ? accent : .white.opacity(0.9))
                        .frame(width: 34, height: 34)
                }
                .buttonStyle(NFScaleButtonStyle())
                .accessibilityLabel("Playback Settings")

                Button(action: onBack) {
                    Image(systemName: "xmark")
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundStyle(.white)
                        .frame(width: 34, height: 34)
                }
                .buttonStyle(NFScaleButtonStyle())
                .accessibilityLabel("Close")
            }
        }
        .padding(.horizontal, 28)
        .padding(.top, 14)
        .padding(.bottom, 22)
        .background(
            LinearGradient(
                colors: [.black.opacity(0.82), .black.opacity(0.32), .clear],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea(edges: .top)
            .allowsHitTesting(false)
        )
    }
}

private struct AirPlayRouteButton: UIViewRepresentable {
    func makeUIView(context: Context) -> AVRoutePickerView {
        let picker = AVRoutePickerView()
        picker.tintColor = .white
        picker.activeTintColor = .systemBlue
        picker.prioritizesVideoDevices = true
        return picker
    }

    func updateUIView(_ uiView: AVRoutePickerView, context: Context) {}
}

struct PlayerPanelRow: View {
    let title: String
    let subtitle: String?
    let isSelected: Bool
    let accent: Color

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: isSelected ? PlayerIcon.selected : PlayerIcon.unselected)
                .foregroundStyle(isSelected ? accent : .white.opacity(0.45))

            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                if let subtitle, !subtitle.isEmpty {
                    Text(subtitle)
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.6))
                        .lineLimit(2)
                }
            }

            Spacer()
        }
        .padding(11)
        .background(isSelected ? accent.opacity(0.14) : Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 11))
    }
}
