import SwiftUI

struct PlayerSettingsPanel: View {
    let controller: CustomPlayerController
    let accent: Color

    private let speeds: [Double] = [0.25, 0.5, 1.0, 1.5, 2.0]
    private let autoHideOptions: [Double] = [3.0, 4.0, 6.0, 8.0]

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            VStack(alignment: .leading, spacing: 8) {
                Text("Playback speed")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.85))
                HStack(spacing: 4) {
                    ForEach(speeds, id: \.self) { rate in
                        let selected = abs(controller.state.playbackRate - rate) < 0.01
                        Button {
                            controller.setPlaybackRate(rate)
                        } label: {
                            Text(String(format: "%.2gx", rate))
                                .font(.caption.weight(.semibold).monospacedDigit())
                                .foregroundStyle(selected ? .black : .white.opacity(0.75))
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 8)
                                .background(selected ? Color.white : Color.clear, in: RoundedRectangle(cornerRadius: 8))
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(3)
                .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 10))
            }

            VStack(alignment: .leading, spacing: 8) {
                Text("Picture")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.85))
                HStack(spacing: 4) {
                    ForEach(PlayerPictureMode.allCases) { mode in
                        let selected = controller.state.pictureMode == mode
                        Button {
                            controller.setPictureMode(mode)
                        } label: {
                            Text(mode.rawValue)
                                .font(.caption.weight(.semibold))
                                .foregroundStyle(selected ? .black : .white.opacity(0.75))
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 8)
                                .background(selected ? Color.white : Color.clear, in: RoundedRectangle(cornerRadius: 8))
                        }
                        .buttonStyle(.plain)
                    }
                }
                .padding(3)
                .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 10))
            }

            VStack(alignment: .leading, spacing: 6) {
                Text("Brightness")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.85))
                HStack(spacing: 10) {
                    Image(systemName: "eye")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.6))
                    Slider(
                        value: Binding(
                            get: { controller.state.screenBrightness },
                            set: { controller.setScreenBrightness($0) }
                        ),
                        in: 0.05...1.0
                    )
                    .tint(.white)
                    Text("\(Int(controller.state.screenBrightness * 100))%")
                        .font(.caption.weight(.semibold).monospacedDigit())
                        .foregroundStyle(.white.opacity(0.8))
                        .frame(width: 44, alignment: .trailing)
                }
            }

            VStack(alignment: .leading, spacing: 6) {
                Text("Audio booster")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.85))
                HStack(spacing: 10) {
                    Image(systemName: PlayerIcon.audio)
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.6))
                    Slider(
                        value: Binding(
                            get: { controller.state.audioBoost },
                            set: { controller.setAudioBoost($0) }
                        ),
                        in: 1.0...2.5,
                        step: 0.1
                    )
                    .tint(.white)
                    Text(String(format: "%.1fx", controller.state.audioBoost))
                        .font(.caption.weight(.semibold).monospacedDigit())
                        .foregroundStyle(.white.opacity(0.8))
                        .frame(width: 44, alignment: .trailing)
                }
                Text("Louder than 100%. High levels can distort.")
                    .font(.caption2)
                    .foregroundStyle(.white.opacity(0.5))
            }

            Divider().background(Color.white.opacity(0.1))

            Toggle(isOn: Binding(
                get: { controller.state.gesturesEnabled },
                set: {
                    controller.state.gesturesEnabled = $0
                    controller.savePlayerPreferences()
                }
            )) {
                Text("Gesture Controls")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white)
            }
            .tint(accent)

            Toggle(isOn: Binding(
                get: { controller.state.hapticsEnabled },
                set: {
                    controller.state.hapticsEnabled = $0
                    controller.savePlayerPreferences()
                }
            )) {
                Text("Haptic Feedback")
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white)
            }
            .tint(accent)

            if controller.initialItem.type == .tv {
                Toggle(isOn: Binding(
                    get: { controller.state.autoplayNextEnabled },
                    set: {
                        controller.state.autoplayNextEnabled = $0
                        controller.savePlayerPreferences()
                    }
                )) {
                    Text("Autoplay Next Episode")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.white)
                }
                .tint(accent)

                Toggle(isOn: Binding(
                    get: { controller.state.skipIntroEnabled },
                    set: {
                        controller.state.skipIntroEnabled = $0
                        controller.savePlayerPreferences()
                    }
                )) {
                    Text("Skip Intro Button")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.white)
                }
                .tint(accent)
            }

            VStack(alignment: .leading, spacing: 6) {
                Text("Auto-Hide Controls")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.75))
                HStack(spacing: 8) {
                    ForEach(autoHideOptions, id: \.self) { sec in
                        let selected = abs(controller.state.visibility.autoHideDuration - sec) < 0.1
                        Button {
                            controller.state.visibility.autoHideDuration = sec
                            controller.savePlayerPreferences()
                        } label: {
                            Text("\(Int(sec))s")
                                .font(.caption.weight(.bold).monospacedDigit())
                                .foregroundStyle(selected ? .black : .white)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 6)
                                .background(selected ? Color.white : Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 8))
                        }
                        .buttonStyle(.plain)
                    }
                }
            }

            ShareLink(item: SingularityDiagnostics.shared.formattedReport()) {
                Label("Export Diagnostic Report", systemImage: "doc.text")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.85))
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 10)
                    .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 10))
            }
        }
    }
}
