import SwiftUI

struct PlayerAudioPanel: View {
    let controller: CustomPlayerController
    let settings: AppSettingsManager
    let accent: Color
    let onOpenExternalSearch: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            statusBanner

            HStack(alignment: .top, spacing: 14) {
                VStack(alignment: .leading, spacing: 8) {
                    Text("AUDIO")
                        .font(.caption2.weight(.bold))
                        .foregroundStyle(.white.opacity(0.5))
                        .tracking(0.8)

                    if controller.audio.supportsAudioDiscovery {
                        ScrollView {
                            VStack(alignment: .leading, spacing: 4) {
                                ForEach(controller.audio.tracks) { track in
                                    Button {
                                        Task {
                                            let ok = await controller.audio.selectTrack(track, bridge: controller.bridge)
                                            if ok {
                                                controller.savePlayerPreferences()
                                                controller.closePanel()
                                            }
                                        }
                                    } label: {
                                        modalSelectionRow(
                                            title: track.displayName,
                                            badge: track.languageCode.isEmpty || track.languageCode.lowercased() == "und" ? nil : track.languageCode.uppercased(),
                                            isSelected: track.isSelected
                                        )
                                    }
                                    .buttonStyle(.plain)
                                    .disabled(track.availability != .selectable)
                                    .opacity(track.availability == .selectable ? 1.0 : 0.55)
                                }
                            }
                        }
                        .frame(maxHeight: 165)
                    } else {
                        Text("No selectable audio tracks exposed")
                            .font(.caption)
                            .foregroundStyle(.white.opacity(0.55))
                            .padding(.vertical, 8)
                    }
                }
                .frame(maxWidth: .infinity, alignment: .leading)

                Rectangle()
                    .fill(Color.white.opacity(0.12))
                    .frame(width: 1)

                VStack(alignment: .leading, spacing: 8) {
                    Text("SUBTITLES")
                        .font(.caption2.weight(.bold))
                        .foregroundStyle(.white.opacity(0.5))
                        .tracking(0.8)

                    ScrollView {
                        VStack(alignment: .leading, spacing: 4) {
                            Button {
                                controller.subtitles.disableAll(bridge: controller.bridge)
                                controller.closePanel()
                            } label: {
                                modalSelectionRow(
                                    title: "Off",
                                    badge: nil,
                                    isSelected: controller.subtitles.isAllOff
                                )
                            }
                            .buttonStyle(.plain)

                            ForEach(controller.subtitles.discoveredSiteSubtitles) { item in
                                let isSelected = controller.subtitles.activeTrackId == item.url
                                Button {
                                    Task {
                                        let ok = await controller.subtitles.activateSubtitleFromURL(
                                            id: item.url,
                                            url: item.url,
                                            name: item.displayTitle,
                                            language: item.language,
                                            source: .siteFile,
                                            referer: controller.activeURL.absoluteString,
                                            bridge: controller.bridge
                                        )
                                        if ok {
                                            controller.savePlayerPreferences()
                                            controller.closePanel()
                                        }
                                    }
                                } label: {
                                    modalSelectionRow(
                                        title: item.displayTitle,
                                        badge: item.language.isEmpty ? nil : item.language.uppercased(),
                                        isSelected: isSelected
                                    )
                                }
                                .buttonStyle(.plain)
                            }

                            ForEach(controller.subtitles.inPlayerTracks) { track in
                                let isSelected = (controller.subtitles.activeTrackId == track.trackId || track.isActive) && !controller.subtitles.hasActiveExternalSubtitles
                                Button {
                                    Task {
                                        let ok = await controller.subtitles.activateInStreamTrack(track: track, bridge: controller.bridge)
                                        if ok {
                                            controller.savePlayerPreferences()
                                            controller.closePanel()
                                        }
                                    }
                                } label: {
                                    modalSelectionRow(
                                        title: track.label,
                                        badge: track.language.isEmpty ? nil : track.language.uppercased(),
                                        isSelected: isSelected
                                    )
                                }
                                .buttonStyle(.plain)
                            }

                            if controller.subtitles.activeSource == .external, let extName = controller.subtitles.externalTrackName {
                                modalSelectionRow(
                                    title: extName,
                                    badge: "EXT",
                                    isSelected: true
                                )
                            }
                        }
                    }
                    .frame(maxHeight: 165)
                }
                .frame(maxWidth: .infinity, alignment: .leading)
            }

            HStack(spacing: 10) {
                Button {
                    controller.state.activePanel = .none
                    onOpenExternalSearch()
                } label: {
                    Label("External subtitles", systemImage: "magnifyingglass")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 10))
                        .overlay {
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.white.opacity(0.14), lineWidth: 1)
                        }
                }
                .buttonStyle(NFScaleButtonStyle())

                Button {
                    controller.openPanel(.subtitles)
                } label: {
                    Label("Subtitle style", systemImage: "slider.horizontal.3")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.white)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 10)
                        .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 10))
                        .overlay {
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.white.opacity(0.14), lineWidth: 1)
                        }
                }
                .buttonStyle(NFScaleButtonStyle())
            }
        }
    }

    private func modalSelectionRow(title: String, badge: String?, isSelected: Bool) -> some View {
        HStack(spacing: 8) {
            Image(systemName: "checkmark")
                .font(.caption.weight(.bold))
                .foregroundStyle(.white)
                .opacity(isSelected ? 1 : 0)
                .frame(width: 14)

            Text(title)
                .font(.subheadline.weight(isSelected ? .bold : .medium))
                .foregroundStyle(isSelected ? .white : .white.opacity(0.82))
                .lineLimit(1)

            Spacer(minLength: 4)

            if let badge, !badge.isEmpty {
                Text(badge)
                    .font(.caption2.weight(.bold))
                    .foregroundStyle(.white.opacity(0.55))
                    .padding(.horizontal, 5)
                    .padding(.vertical, 2)
                    .background(Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 4))
            }
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 7)
        .background(isSelected ? Color.white.opacity(0.1) : Color.clear, in: RoundedRectangle(cornerRadius: 8))
    }

    @ViewBuilder
    private var statusBanner: some View {
        if case .switching(let name) = controller.audio.switchState {
            HStack(spacing: 8) {
                ProgressView().tint(accent)
                Text("Switching audio to \(name)...")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.85))
            }
            .padding(8)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 8))
        } else if case .failed(let message) = controller.audio.switchState {
            Text(message)
                .font(.caption)
                .foregroundStyle(Color(hex: "FF8C92"))
                .padding(8)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(accent.opacity(0.16), in: RoundedRectangle(cornerRadius: 8))
        } else if case .loading(let name) = controller.subtitles.activationState {
            HStack(spacing: 8) {
                ProgressView().tint(accent)
                Text("Loading \(name)...")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.85))
            }
            .padding(8)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 8))
        } else if case .failed(let message) = controller.subtitles.activationState {
            Text(message)
                .font(.caption)
                .foregroundStyle(Color(hex: "FF8C92"))
                .padding(8)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(accent.opacity(0.16), in: RoundedRectangle(cornerRadius: 8))
        }
    }
}
