import AVFoundation
import MediaPlayer
import SwiftUI
import WebKit

struct PlayerView: View {
    let item: WatchItem
    var continueWatchingManager: ContinueWatchingManager?

    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var scenePhase
    @Environment(NFAppModel.self) private var app
    @State private var isLoading = true
    @State private var lastPersistedSeconds: Double = -.greatestFiniteMagnitude
    @State private var webViewRef: WKWebView?
    @State private var movieRuntimeText: String?

    private var subtitleMetaText: String {
        if item.type == .tv {
            let s = item.season ?? 1
            let e = item.episode ?? 1
            if let epName = item.episodeName, !epName.isEmpty {
                return "S\(s):E\(e) · \(epName)"
            }
            return "S\(s):E\(e)"
        }
        return movieRuntimeText ?? ""
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VidlyDirectWebView(
                url: item.generatedURL,
                mediaTitle: item.title,
                isMovie: item.type == .movie,
                subtitleMeta: subtitleMetaText,
                onWebViewCreated: { webView in
                    webViewRef = webView
                },
                onLoadingChanged: { loading in
                    isLoading = loading
                },
                onProgress: { currentTime, duration in
                    persistProgress(currentTime: currentTime, duration: duration)
                },
                onBackRequested: {
                    HapticManager.shared.lightImpact()
                    dismiss()
                }
            )
            .ignoresSafeArea()

            if isLoading {
                ProgressView()
                    .progressViewStyle(.circular)
                    .tint(.white)
                    .scaleEffect(1.25)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .allowsHitTesting(false)
            }
        }
        .statusBarHidden()
        .persistentSystemOverlays(.hidden)
        .toolbar(.hidden, for: .navigationBar)
        .preferredColorScheme(.dark)
        .task {
            await loadMovieRuntimeIfNeeded()
        }
        .onAppear {
            Self.configureNoLockScreenAudioSession()
            NFOrientation.enterPlayback()
            app.history.add(item)
        }
        .onDisappear {
            webViewRef?.pauseAllMediaPlayback(completionHandler: nil)
            Self.clearLockScreenNowPlaying()
            NFOrientation.exitPlayback()
        }
        .onChange(of: scenePhase) { _, phase in
            if phase != .active {
                webViewRef?.pauseAllMediaPlayback(completionHandler: nil)
                Self.clearLockScreenNowPlaying()
            }
        }
    }

    private func loadMovieRuntimeIfNeeded() async {
        guard item.type == .movie, movieRuntimeText == nil, let tmdbInt = Int(item.tmdbId) else { return }
        if let payload = try? await NFCatalogService.title(type: .movie, id: tmdbInt),
           let formatted = NF.runtimeText(minutes: payload.runtime) {
            movieRuntimeText = formatted
        }
    }

    private func persistProgress(currentTime: Double, duration: Double) {
        guard currentTime.isFinite, duration.isFinite, duration > 0 else { return }
        if item.type == .movie, movieRuntimeText == nil {
            movieRuntimeText = NF.compactDuration(seconds: duration)
        }
        guard abs(currentTime - lastPersistedSeconds) >= 5 else { return }
        lastPersistedSeconds = currentTime
        continueWatchingManager?.recordProgress(
            type: item.type,
            tmdbId: item.tmdbId,
            title: item.title,
            posterPath: item.posterPath,
            season: item.season,
            episode: item.episode,
            episodeName: item.episodeName,
            positionSeconds: currentTime,
            durationSeconds: duration
        )
    }

    private static func configureNoLockScreenAudioSession() {
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.soloAmbient, mode: .default)
        try? session.setActive(true)
        clearLockScreenNowPlaying()
    }

    private static func clearLockScreenNowPlaying() {
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
    }
}

private struct VidlyDirectWebView: UIViewRepresentable {
    let url: URL
    let mediaTitle: String
    let isMovie: Bool
    let subtitleMeta: String
    let onWebViewCreated: (WKWebView) -> Void
    let onLoadingChanged: (Bool) -> Void
    let onProgress: (Double, Double) -> Void
    let onBackRequested: () -> Void

    private static let progressHandlerName = "vidlyProgress"
    private static let backHandlerName = "vidlyBack"

    func makeCoordinator() -> Coordinator {
        Coordinator(
            mediaTitle: mediaTitle,
            isMovie: isMovie,
            subtitleMeta: subtitleMeta,
            onLoadingChanged: onLoadingChanged,
            onProgress: onProgress,
            onBackRequested: onBackRequested
        )
    }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        config.allowsInlineMediaPlayback = true
        config.allowsPictureInPictureMediaPlayback = false
        config.allowsAirPlayForMediaPlayback = false
        config.defaultWebpagePreferences.allowsContentJavaScript = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.preferences.javaScriptCanOpenWindowsAutomatically = false
        if #available(iOS 15.4, *) {
            config.preferences.isElementFullscreenEnabled = false
        }
        config.applicationNameForUserAgent = "Version/18.0 Mobile/15E148 Safari/604.1"

        let ucc = config.userContentController
        let handler = WeakVidlyMessageHandler(context.coordinator)
        ucc.add(handler, name: Self.progressHandlerName)
        ucc.add(handler, name: Self.backHandlerName)
        ucc.addUserScript(
            WKUserScript(
                source: Self.vidlyCleanupScript(title: mediaTitle, isMovie: isMovie, subtitleMeta: subtitleMeta),
                injectionTime: .atDocumentStart,
                forMainFrameOnly: false
            )
        )
        ucc.addUserScript(
            WKUserScript(
                source: Self.vidlyProgressScript,
                injectionTime: .atDocumentStart,
                forMainFrameOnly: true
            )
        )

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.isOpaque = false
        webView.backgroundColor = .black
        webView.allowsBackForwardNavigationGestures = false
        webView.scrollView.backgroundColor = .black
        webView.scrollView.bounces = false
        webView.scrollView.isScrollEnabled = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never

        onWebViewCreated(webView)
        context.coordinator.load(url, in: webView)
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        context.coordinator.onLoadingChanged = onLoadingChanged
        context.coordinator.onProgress = onProgress
        context.coordinator.onBackRequested = onBackRequested
        context.coordinator.updateMetadata(title: mediaTitle, isMovie: isMovie, subtitleMeta: subtitleMeta, in: webView)
        context.coordinator.load(url, in: webView)
    }

    static func dismantleUIView(_ webView: WKWebView, coordinator: Coordinator) {
        webView.stopLoading()
        webView.pauseAllMediaPlayback(completionHandler: nil)
        webView.navigationDelegate = nil
        webView.uiDelegate = nil
        webView.configuration.userContentController.removeAllUserScripts()
        webView.configuration.userContentController.removeScriptMessageHandler(forName: progressHandlerName)
        webView.configuration.userContentController.removeScriptMessageHandler(forName: backHandlerName)
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
        var mediaTitle: String
        var isMovie: Bool
        var subtitleMeta: String
        var onLoadingChanged: (Bool) -> Void
        var onProgress: (Double, Double) -> Void
        var onBackRequested: () -> Void
        private var loadedURL: URL?

        init(
            mediaTitle: String,
            isMovie: Bool,
            subtitleMeta: String,
            onLoadingChanged: @escaping (Bool) -> Void,
            onProgress: @escaping (Double, Double) -> Void,
            onBackRequested: @escaping () -> Void
        ) {
            self.mediaTitle = mediaTitle
            self.isMovie = isMovie
            self.subtitleMeta = subtitleMeta
            self.onLoadingChanged = onLoadingChanged
            self.onProgress = onProgress
            self.onBackRequested = onBackRequested
        }

        func load(_ url: URL, in webView: WKWebView) {
            guard loadedURL != url else { return }
            loadedURL = url
            onLoadingChanged(true)
            var request = URLRequest(url: url)
            request.setValue("https://vidly.pro/", forHTTPHeaderField: "Referer")
            webView.load(request)
        }

        func updateMetadata(title: String, isMovie: Bool, subtitleMeta: String, in webView: WKWebView) {
            guard self.subtitleMeta != subtitleMeta || self.mediaTitle != title else { return }
            self.mediaTitle = title
            self.isMovie = isMovie
            self.subtitleMeta = subtitleMeta
            let escapedSub = Self.jsEscape(subtitleMeta)
            let js = "window.__singularityMeta = { title: '\(Self.jsEscape(title))', isMovie: \(isMovie ? "true" : "false"), subtitle: '\(escapedSub)' }; if (typeof window.__singularitySyncHeader === 'function') { window.__singularitySyncHeader(); }"
            webView.evaluateJavaScript(js, completionHandler: nil)
        }

        private static func jsEscape(_ str: String) -> String {
            str
                .replacingOccurrences(of: "\\", with: "\\\\")
                .replacingOccurrences(of: "'", with: "\\'")
                .replacingOccurrences(of: "\n", with: " ")
                .replacingOccurrences(of: "\r", with: " ")
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            onLoadingChanged(false)
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            onLoadingChanged(false)
        }

        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            onLoadingChanged(false)
        }

        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            nil
        }

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            if message.name == VidlyDirectWebView.backHandlerName {
                DispatchQueue.main.async {
                    self.onBackRequested()
                }
                return
            }
            guard message.name == VidlyDirectWebView.progressHandlerName,
                  let dict = message.body as? [String: Any],
                  let currentTime = dict["currentTime"] as? Double,
                  let duration = dict["duration"] as? Double else { return }
            onProgress(currentTime, duration)
        }
    }

    private static func vidlyCleanupScript(title: String, isMovie: Bool, subtitleMeta: String) -> String {
        let escapedTitle = title
            .replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "'", with: "\\'")
            .replacingOccurrences(of: "\n", with: " ")
            .replacingOccurrences(of: "\r", with: " ")
        let escapedSub = subtitleMeta
            .replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "'", with: "\\'")
            .replacingOccurrences(of: "\n", with: " ")
            .replacingOccurrences(of: "\r", with: " ")

        return """
        (function () {
            window.__singularityMeta = {
                title: '\(escapedTitle)',
                isMovie: \(isMovie ? "true" : "false"),
                subtitle: '\(escapedSub)'
            };

            try {
                Object.defineProperty(navigator, 'mediaSession', {
                    configurable: true,
                    get: function () { return undefined; }
                });
            } catch (e) {}

            var noop = function () { return Promise.resolve(); };
            try {
                Element.prototype.requestFullscreen = noop;
                Element.prototype.webkitRequestFullscreen = noop;
                Element.prototype.webkitRequestFullScreen = noop;
                HTMLVideoElement.prototype.webkitEnterFullscreen = function () {};
                HTMLVideoElement.prototype.webkitEnterFullScreen = function () {};
                Document.prototype.exitFullscreen = noop;
                Document.prototype.webkitExitFullscreen = noop;
                Object.defineProperty(document, 'fullscreenEnabled', { get: function () { return false; } });
                Object.defineProperty(document, 'webkitFullscreenEnabled', { get: function () { return false; } });
            } catch (e) {}

            var cssText = [
                '[aria-label*="fullscreen" i]',
                '[aria-label*="full screen" i]',
                '[title*="fullscreen" i]',
                '[title*="full screen" i]',
                '[data-testid*="fullscreen" i]',
                '[data-plyr="fullscreen"]',
                '.vjs-fullscreen-control',
                '.plyr__control--fullscreen',
                'a[href*="vidly" i]',
                'img[src*="vidly" i]',
                'img[alt*="vidly" i]',
                '[aria-label*="vidly" i]',
                '[title*="vidly" i]',
                '[class*="watermark" i]',
                '[class*="brand-logo" i]',
                '[class*="player-logo" i]'
            ].join(', ') + ' { display: none !important; opacity: 0 !important; visibility: hidden !important; pointer-events: none !important; width: 0 !important; height: 0 !important; }';

            function injectCSS() {
                if (!document.head && !document.documentElement) return;
                if (document.getElementById('singularity-vidly-cleanup-css')) return;
                var style = document.createElement('style');
                style.id = 'singularity-vidly-cleanup-css';
                style.textContent = cssText;
                (document.head || document.documentElement).appendChild(style);
            }

            function hideEl(el) {
                if (!el || el.tagName === 'VIDEO' || el.tagName === 'BODY' || el.tagName === 'HTML') return;
                if (el.id === '__sgTopBackBtn' || el.id === '__sgMovieSub') return;
                el.style.setProperty('display', 'none', 'important');
                el.style.setProperty('opacity', '0', 'important');
                el.style.setProperty('visibility', 'hidden', 'important');
                el.style.setProperty('pointer-events', 'none', 'important');
            }

            function isMaximizeSvg(el) {
                var svg = el.tagName === 'SVG' ? el : (el.querySelector ? el.querySelector('svg') : null);
                if (!svg) return false;
                var html = (svg.innerHTML || '').toLowerCase();
                return html.indexOf('m15 3h6v6') !== -1 ||
                       html.indexOf('m8 3h5') !== -1 ||
                       html.indexOf('m3 8v5') !== -1 ||
                       html.indexOf('15 3 21 3 21 9') !== -1 ||
                       html.indexOf('9 21 3 21 3 15') !== -1 ||
                       html.indexOf('fullscreen') !== -1;
            }

            function effOp(el) {
                var op = 1, cur = el;
                while (cur && cur.nodeType === 1) {
                    var cs = getComputedStyle(cur);
                    if (cs.display === 'none' || cs.visibility === 'hidden') return 0;
                    op *= parseFloat(cs.opacity);
                    if (op <= 0.02) return 0;
                    cur = cur.parentElement;
                }
                return op;
            }

            function fmtRuntime(sec) {
                var meta = window.__singularityMeta || {};
                if (meta.subtitle && meta.subtitle.length > 0) return meta.subtitle;
                if (!isFinite(sec) || sec < 60) return '';
                var m = Math.round(sec / 60);
                var h = Math.floor(m / 60), rm = m % 60;
                return h > 0 ? (rm > 0 ? (h + 'h ' + rm + 'm') : (h + 'h')) : (rm + 'm');
            }

            function ensureTopBack() {
                if (window !== window.top || !document.body) return;
                var bk = document.getElementById('__sgTopBackBtn');
                if (!bk) {
                    bk = document.createElement('button');
                    bk.id = '__sgTopBackBtn';
                    bk.type = 'button';
                    bk.setAttribute('aria-label', 'Back');
                    bk.style.cssText = 'position:fixed;z-index:2147483645;display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;background:transparent;border:none;color:#FFFFFF;cursor:pointer;padding:0;margin:0;opacity:0;pointer-events:none;transition:opacity 120ms ease;';
                    bk.innerHTML = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5"></path><path d="M12 19l-7-7 7-7"></path></svg>';
                    bk.addEventListener('pointerdown', function (e) { e.stopPropagation(); }, true);
                    bk.addEventListener('click', function (ev) {
                        ev.stopPropagation();
                        ev.preventDefault();
                        try {
                            window.webkit.messageHandlers.\(Self.backHandlerName).postMessage(true);
                        } catch (e) {}
                    }, true);
                    document.body.appendChild(bk);
                }

                var titleEl = null, titleOp = 0;
                var tCands = document.querySelectorAll('h1,h2,h3,div,span,p');
                for (var j = 0; j < tCands.length; j++) {
                    var el = tCands[j];
                    if (el.id === '__sgTopBackBtn' || el.id === '__sgMovieSub' || el.closest('button')) continue;
                    if (el.children.length > 0) continue;
                    var ttx = (el.textContent || '').trim();
                    if (ttx.length < 2 || ttx.length > 85) continue;
                    var low = ttx.toLowerCase();
                    if (low.indexOf('quality') !== -1 || low.indexOf('server') !== -1 || low.indexOf('audio') !== -1 || low.indexOf('subtitle') !== -1) continue;
                    var tr = el.getBoundingClientRect();
                    if (tr.width > 10 && tr.top >= 2 && tr.top < 105 && tr.left >= 4 && tr.left < 400 && tr.height >= 14 && tr.height < 60) {
                        var op = effOp(el);
                        if (op > 0.15) {
                            titleEl = el;
                            titleOp = op;
                            break;
                        }
                    }
                }

                if (titleEl && titleOp > 0.15) {
                    var titleBox = titleEl.parentElement;
                    var isTvUrl = (location.pathname || '').toLowerCase().indexOf('/tv/') !== -1 || !(window.__singularityMeta && window.__singularityMeta.isMovie);
                    var subEl = document.getElementById('__sgMovieSub');
                    var existingSub = null;
                    if (titleBox) {
                        var sibs = titleBox.children;
                        for (var si = 0; si < sibs.length; si++) {
                            var sb = sibs[si];
                            if (sb === titleEl || sb.id === '__sgMovieSub') continue;
                            var st = (sb.textContent || '').trim();
                            if (st.length > 1 && sb.getBoundingClientRect().top >= titleEl.getBoundingClientRect().top + 8) {
                                existingSub = sb;
                                break;
                            }
                        }
                    }

                    if (!existingSub && titleBox) {
                        var v = document.querySelector('video');
                        var subTxt = fmtRuntime(v ? v.duration : 0);
                        if (subTxt.length > 0) {
                            if (!subEl) {
                                subEl = document.createElement('div');
                                subEl.id = '__sgMovieSub';
                                subEl.style.cssText = 'font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:12.5px;font-weight:500;color:rgba(255,255,255,0.68);margin-top:2px;line-height:1.25;white-space:nowrap;pointer-events:none;';
                            }
                            if (subEl.textContent !== subTxt) subEl.textContent = subTxt;
                            if (subEl.parentElement !== titleBox) {
                                var pcs = getComputedStyle(titleBox);
                                if (pcs.display === 'flex' && pcs.flexDirection !== 'column') {
                                    titleBox.style.setProperty('flex-direction', 'column', 'important');
                                    titleBox.style.setProperty('align-items', 'flex-start', 'important');
                                }
                                titleBox.appendChild(subEl);
                            }
                            existingSub = subEl;
                        }
                    } else if (isTvUrl && existingSub && subEl) {
                        subEl.remove();
                    }

                    var shiftTarget = titleBox || titleEl;
                    if (!shiftTarget.dataset.sgBackShifted && titleEl.getBoundingClientRect().left < 56) {
                        shiftTarget.dataset.sgBackShifted = '1';
                        shiftTarget.style.setProperty('padding-left', '40px', 'important');
                    }

                    var tr2 = titleEl.getBoundingClientRect();
                    var sr2 = existingSub ? existingSub.getBoundingClientRect() : tr2;
                    var midY = (tr2.top + Math.max(tr2.bottom, sr2.bottom)) / 2;
                    var bx = Math.max(10, Math.round(tr2.left - 42));
                    var by = Math.max(4, Math.round(midY - 18));
                    bk.style.left = bx + 'px';
                    bk.style.top = by + 'px';
                    bk.style.opacity = String(titleOp);
                    bk.style.pointerEvents = 'auto';
                } else {
                    bk.style.left = '16px';
                    bk.style.top = '14px';
                    var bodyTxt = (document.body.innerText || '').toLowerCase();
                    var isErr = bodyTxt.indexOf('stream unavailable') !== -1 || bodyTxt.indexOf('try again') !== -1 || bodyTxt.indexOf('no sources') !== -1;
                    bk.style.opacity = isErr ? '1' : '0';
                    bk.style.pointerEvents = isErr ? 'auto' : 'none';
                }
            }

            window.__singularitySyncHeader = ensureTopBack;

            function cleanDOM() {
                injectCSS();
                try {
                    if (document.title) document.title = '';
                } catch (e) {}

                var vw = window.innerWidth || document.documentElement.clientWidth || 0;
                var candidates = document.querySelectorAll('button, [role="button"], a, img, svg, div, span');
                for (var i = 0; i < candidates.length; i++) {
                    var el = candidates[i];
                    if (!el || el.tagName === 'VIDEO' || el.id === '__sgTopBackBtn' || el.id === '__sgMovieSub') continue;

                    var aria = (el.getAttribute('aria-label') || '').toLowerCase();
                    var title = (el.getAttribute('title') || '').toLowerCase();
                    var cls = (typeof el.className === 'string' ? el.className : '').toLowerCase();
                    var id = (el.id || '').toLowerCase();
                    var testId = (el.getAttribute('data-testid') || '').toLowerCase();
                    var href = (el.getAttribute('href') || '').toLowerCase();
                    var src = (el.getAttribute('src') || '').toLowerCase();
                    var alt = (el.getAttribute('alt') || '').toLowerCase();

                    if (aria.indexOf('fullscreen') !== -1 || aria.indexOf('full screen') !== -1 ||
                        title.indexOf('fullscreen') !== -1 || title.indexOf('full screen') !== -1 ||
                        testId.indexOf('fullscreen') !== -1 || id.indexOf('fullscreen') !== -1 ||
                        (el.tagName === 'BUTTON' && (cls.indexOf('fullscreen') !== -1 || isMaximizeSvg(el)))) {
                        hideEl(el);
                        continue;
                    }

                    if (href.indexOf('vidly') !== -1 || src.indexOf('vidly') !== -1 || alt.indexOf('vidly') !== -1 ||
                        aria.indexOf('vidly') !== -1 || title.indexOf('vidly') !== -1 ||
                        cls.indexOf('vidly') !== -1 || id.indexOf('vidly') !== -1) {
                        if (el.tagName === 'A' || el.tagName === 'IMG' || el.tagName === 'SVG' || el.children.length <= 2) {
                            hideEl(el);
                            continue;
                        }
                    }

                    if (vw > 0 && (el.tagName === 'A' || el.tagName === 'IMG' || el.tagName === 'DIV' || el.tagName === 'SPAN')) {
                        var txt = (el.innerText || el.textContent || '').trim().toLowerCase();
                        var rect = el.getBoundingClientRect ? el.getBoundingClientRect() : null;
                        if (rect && rect.top >= 0 && rect.top <= 95 && rect.right >= vw - 170 && rect.width > 0 && rect.width <= 170 && rect.height > 0 && rect.height <= 64) {
                            var isModal = !!el.closest('[role="dialog"], [class*="modal" i], [class*="sheet" i], [class*="menu" i]');
                            var isControl = el.tagName === 'BUTTON' || !!el.closest('button');
                            if (!isModal && !isControl && (txt === 'vidly' || txt === 'vidly.pro' || el.tagName === 'A' || el.tagName === 'IMG' || el.querySelector('svg, img'))) {
                                hideEl(el);
                            }
                        }
                    }
                }

                ensureTopBack();
            }

            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', cleanDOM);
            } else {
                cleanDOM();
            }

            var obs = new MutationObserver(function () { cleanDOM(); });
            try {
                obs.observe(document.documentElement || document, { childList: true, subtree: true, attributes: true });
            } catch (e) {}
            setInterval(cleanDOM, 300);
        })();
        """
    }

    private static let vidlyProgressScript = """
    (function () {
        var handlers = window.webkit && window.webkit.messageHandlers;
        var channel = handlers && handlers.\(progressHandlerName);
        if (!channel) return;

        window.addEventListener('message', function (event) {
            var payload = event.data;
            if (typeof payload === 'string') {
                try { payload = JSON.parse(payload); } catch (e) { return; }
            }
            if (!payload || typeof payload !== 'object') return;
            var d = payload.type === 'PLAYER_EVENT' && payload.data ? payload.data : payload;
            var ct = Number(d.currentTime !== undefined ? d.currentTime : d.timestamp);
            var dur = Number(d.duration);
            if (isFinite(ct) && isFinite(dur) && dur > 0) {
                try { channel.postMessage({ currentTime: ct, duration: dur }); } catch (e) {}
            }
        }, false);
    })();
    """
}

private final class WeakVidlyMessageHandler: NSObject, WKScriptMessageHandler {
    private weak var delegate: WKScriptMessageHandler?

    init(_ delegate: WKScriptMessageHandler) {
        self.delegate = delegate
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        delegate?.userContentController(userContentController, didReceive: message)
    }
}
