import AVFoundation
import MediaPlayer
import SwiftUI
import WebKit

struct PlayerView: View {
    let item: WatchItem
    var continueWatchingManager: ContinueWatchingManager?

    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var scenePhase
    @Environment(NFAppModel.self) private var app
    @State private var isLoading = true
    @State private var lastPersistedSeconds: Double = -.greatestFiniteMagnitude
    @State private var webViewRef: WKWebView?

    var body: some View {
        ZStack(alignment: .topLeading) {
            Color.black.ignoresSafeArea()

            VidlyDirectWebView(
                url: item.generatedURL,
                onWebViewCreated: { webView in
                    webViewRef = webView
                },
                onLoadingChanged: { loading in
                    isLoading = loading
                },
                onProgress: { currentTime, duration in
                    persistProgress(currentTime: currentTime, duration: duration)
                }
            )
            .ignoresSafeArea()

            if isLoading {
                ProgressView()
                    .progressViewStyle(.circular)
                    .tint(.white)
                    .scaleEffect(1.25)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .allowsHitTesting(false)
            }

            Button {
                HapticManager.shared.lightImpact()
                dismiss()
            } label: {
                Image(systemName: "chevron.backward")
                    .font(.system(size: 16, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 36, height: 36)
                    .background(Color.black.opacity(0.55), in: Circle())
            }
            .padding(.leading, 18)
            .padding(.top, 14)
            .accessibilityLabel("Back")
        }
        .statusBarHidden()
        .persistentSystemOverlays(.hidden)
        .toolbar(.hidden, for: .navigationBar)
        .preferredColorScheme(.dark)
        .onAppear {
            Self.configureNoLockScreenAudioSession()
            NFOrientation.enterPlayback()
            app.history.add(item)
        }
        .onDisappear {
            webViewRef?.pauseAllMediaPlayback(completionHandler: nil)
            Self.clearLockScreenNowPlaying()
            NFOrientation.exitPlayback()
        }
        .onChange(of: scenePhase) { _, phase in
            if phase != .active {
                webViewRef?.pauseAllMediaPlayback(completionHandler: nil)
                Self.clearLockScreenNowPlaying()
            }
        }
    }

    private func persistProgress(currentTime: Double, duration: Double) {
        guard currentTime.isFinite, duration.isFinite, duration > 0 else { return }
        guard abs(currentTime - lastPersistedSeconds) >= 5 else { return }
        lastPersistedSeconds = currentTime
        continueWatchingManager?.recordProgress(
            type: item.type,
            tmdbId: item.tmdbId,
            title: item.title,
            posterPath: item.posterPath,
            season: item.season,
            episode: item.episode,
            episodeName: item.episodeName,
            positionSeconds: currentTime,
            durationSeconds: duration
        )
    }

    private static func configureNoLockScreenAudioSession() {
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.soloAmbient, mode: .default)
        try? session.setActive(true)
        clearLockScreenNowPlaying()
    }

    private static func clearLockScreenNowPlaying() {
        MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
    }
}

private struct VidlyDirectWebView: UIViewRepresentable {
    let url: URL
    let onWebViewCreated: (WKWebView) -> Void
    let onLoadingChanged: (Bool) -> Void
    let onProgress: (Double, Double) -> Void

    private static let handlerName = "vidlyProgress"

    func makeCoordinator() -> Coordinator {
        Coordinator(
            onLoadingChanged: onLoadingChanged,
            onProgress: onProgress
        )
    }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        config.allowsInlineMediaPlayback = true
        config.allowsPictureInPictureMediaPlayback = false
        config.allowsAirPlayForMediaPlayback = false
        config.defaultWebpagePreferences.allowsContentJavaScript = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.preferences.javaScriptCanOpenWindowsAutomatically = false
        if #available(iOS 15.4, *) {
            config.preferences.isElementFullscreenEnabled = false
        }
        config.applicationNameForUserAgent = "Version/18.0 Mobile/15E148 Safari/604.1"

        let ucc = config.userContentController
        ucc.add(WeakVidlyMessageHandler(context.coordinator), name: Self.handlerName)
        ucc.addUserScript(
            WKUserScript(
                source: Self.vidlyCleanupScript,
                injectionTime: .atDocumentStart,
                forMainFrameOnly: false
            )
        )
        ucc.addUserScript(
            WKUserScript(
                source: Self.vidlyProgressScript,
                injectionTime: .atDocumentStart,
                forMainFrameOnly: true
            )
        )

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.isOpaque = false
        webView.backgroundColor = .black
        webView.allowsBackForwardNavigationGestures = false
        webView.scrollView.backgroundColor = .black
        webView.scrollView.bounces = false
        webView.scrollView.isScrollEnabled = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never

        onWebViewCreated(webView)
        context.coordinator.load(url, in: webView)
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        context.coordinator.onLoadingChanged = onLoadingChanged
        context.coordinator.onProgress = onProgress
        context.coordinator.load(url, in: webView)
    }

    static func dismantleUIView(_ webView: WKWebView, coordinator: Coordinator) {
        webView.stopLoading()
        webView.pauseAllMediaPlayback(completionHandler: nil)
        webView.navigationDelegate = nil
        webView.uiDelegate = nil
        webView.configuration.userContentController.removeAllUserScripts()
        webView.configuration.userContentController.removeScriptMessageHandler(forName: handlerName)
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
        var onLoadingChanged: (Bool) -> Void
        var onProgress: (Double, Double) -> Void
        private var loadedURL: URL?

        init(onLoadingChanged: @escaping (Bool) -> Void, onProgress: @escaping (Double, Double) -> Void) {
            self.onLoadingChanged = onLoadingChanged
            self.onProgress = onProgress
        }

        func load(_ url: URL, in webView: WKWebView) {
            guard loadedURL != url else { return }
            loadedURL = url
            onLoadingChanged(true)
            var request = URLRequest(url: url)
            request.setValue("https://vidly.pro/", forHTTPHeaderField: "Referer")
            webView.load(request)
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            onLoadingChanged(false)
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            onLoadingChanged(false)
        }

        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            onLoadingChanged(false)
        }

        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            nil
        }

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            guard let dict = message.body as? [String: Any],
                  let currentTime = dict["currentTime"] as? Double,
                  let duration = dict["duration"] as? Double else { return }
            onProgress(currentTime, duration)
        }
    }

    private static let vidlyCleanupScript = """
    (function () {
        try {
            Object.defineProperty(navigator, 'mediaSession', {
                configurable: true,
                get: function () { return undefined; }
            });
        } catch (e) {}

        var noop = function () { return Promise.resolve(); };
        try {
            Element.prototype.requestFullscreen = noop;
            Element.prototype.webkitRequestFullscreen = noop;
            Element.prototype.webkitRequestFullScreen = noop;
            HTMLVideoElement.prototype.webkitEnterFullscreen = function () {};
            HTMLVideoElement.prototype.webkitEnterFullScreen = function () {};
            Document.prototype.exitFullscreen = noop;
            Document.prototype.webkitExitFullscreen = noop;
            Object.defineProperty(document, 'fullscreenEnabled', { get: function () { return false; } });
            Object.defineProperty(document, 'webkitFullscreenEnabled', { get: function () { return false; } });
        } catch (e) {}

        var cssText = [
            '[aria-label*="fullscreen" i]',
            '[aria-label*="full screen" i]',
            '[title*="fullscreen" i]',
            '[title*="full screen" i]',
            '[data-testid*="fullscreen" i]',
            '[data-plyr="fullscreen"]',
            '.vjs-fullscreen-control',
            '.plyr__control--fullscreen',
            'a[href*="vidly" i]',
            'img[src*="vidly" i]',
            'img[alt*="vidly" i]',
            '[aria-label*="vidly" i]',
            '[title*="vidly" i]',
            '[class*="watermark" i]',
            '[class*="brand-logo" i]',
            '[class*="player-logo" i]'
        ].join(', ') + ' { display: none !important; opacity: 0 !important; visibility: hidden !important; pointer-events: none !important; width: 0 !important; height: 0 !important; }';

        function injectCSS() {
            if (!document.head && !document.documentElement) return;
            if (document.getElementById('singularity-vidly-cleanup-css')) return;
            var style = document.createElement('style');
            style.id = 'singularity-vidly-cleanup-css';
            style.textContent = cssText;
            (document.head || document.documentElement).appendChild(style);
        }

        function hideEl(el) {
            if (!el || el.tagName === 'VIDEO' || el.tagName === 'BODY' || el.tagName === 'HTML') return;
            el.style.setProperty('display', 'none', 'important');
            el.style.setProperty('opacity', '0', 'important');
            el.style.setProperty('visibility', 'hidden', 'important');
            el.style.setProperty('pointer-events', 'none', 'important');
        }

        function isMaximizeSvg(el) {
            var svg = el.tagName === 'SVG' ? el : (el.querySelector ? el.querySelector('svg') : null);
            if (!svg) return false;
            var html = (svg.innerHTML || '').toLowerCase();
            if (html.indexOf('m15 3h6v6') !== -1 || html.indexOf('m8 3h5') !== -1 || html.indexOf('m3 8v5') !== -1 || html.indexOf('15 3 21 3 21 9') !== -1 || html.indexOf('9 21 3 21 3 15') !== -1 || html.indexOf('fullscreen') !== -1) {
                return true;
            }
            return false;
        }

        function cleanDOM() {
            injectCSS();
            try {
                if (document.title) document.title = '';
            } catch (e) {}

            var vw = window.innerWidth || document.documentElement.clientWidth || 0;
            var candidates = document.querySelectorAll('button, [role="button"], a, img, svg, div, span');
            for (var i = 0; i < candidates.length; i++) {
                var el = candidates[i];
                if (!el || el.tagName === 'VIDEO') continue;

                var aria = (el.getAttribute('aria-label') || '').toLowerCase();
                var title = (el.getAttribute('title') || '').toLowerCase();
                var cls = (typeof el.className === 'string' ? el.className : '').toLowerCase();
                var id = (el.id || '').toLowerCase();
                var testId = (el.getAttribute('data-testid') || '').toLowerCase();
                var href = (el.getAttribute('href') || '').toLowerCase();
                var src = (el.getAttribute('src') || '').toLowerCase();
                var alt = (el.getAttribute('alt') || '').toLowerCase();

                if (aria.indexOf('fullscreen') !== -1 || aria.indexOf('full screen') !== -1 ||
                    title.indexOf('fullscreen') !== -1 || title.indexOf('full screen') !== -1 ||
                    testId.indexOf('fullscreen') !== -1 || id.indexOf('fullscreen') !== -1 ||
                    (el.tagName === 'BUTTON' && (cls.indexOf('fullscreen') !== -1 || isMaximizeSvg(el)))) {
                    hideEl(el);
                    continue;
                }

                if (href.indexOf('vidly') !== -1 || src.indexOf('vidly') !== -1 || alt.indexOf('vidly') !== -1 ||
                    aria.indexOf('vidly') !== -1 || title.indexOf('vidly') !== -1 ||
                    cls.indexOf('vidly') !== -1 || id.indexOf('vidly') !== -1) {
                    if (el.tagName === 'A' || el.tagName === 'IMG' || el.tagName === 'SVG' || el.children.length <= 2) {
                        hideEl(el);
                        continue;
                    }
                }

                if (vw > 0 && (el.tagName === 'A' || el.tagName === 'IMG' || el.tagName === 'DIV' || el.tagName === 'SPAN')) {
                    var txt = (el.innerText || el.textContent || '').trim().toLowerCase();
                    var rect = el.getBoundingClientRect ? el.getBoundingClientRect() : null;
                    if (rect && rect.top >= 0 && rect.top <= 95 && rect.right >= vw - 170 && rect.width > 0 && rect.width <= 170 && rect.height > 0 && rect.height <= 64) {
                        var isModal = !!el.closest('[role="dialog"], [class*="modal" i], [class*="sheet" i], [class*="menu" i]');
                        var isControl = el.tagName === 'BUTTON' || !!el.closest('button');
                        if (!isModal && !isControl && (txt === 'vidly' || txt === 'vidly.pro' || el.tagName === 'A' || el.tagName === 'IMG' || el.querySelector('svg, img'))) {
                            hideEl(el);
                        }
                    }
                }
            }
        }

        if (document.readyState === 'loading') {
            document.addEventListener('DOMContentLoaded', cleanDOM);
        } else {
            cleanDOM();
        }

        var obs = new MutationObserver(function () { cleanDOM(); });
        try {
            obs.observe(document.documentElement || document, { childList: true, subtree: true, attributes: true });
        } catch (e) {}
        setInterval(cleanDOM, 700);
    })();
    """

    private static let vidlyProgressScript = """
    (function () {
        var handlers = window.webkit && window.webkit.messageHandlers;
        var channel = handlers && handlers.\(handlerName);
        if (!channel) return;

        window.addEventListener('message', function (event) {
            var payload = event.data;
            if (typeof payload === 'string') {
                try { payload = JSON.parse(payload); } catch (e) { return; }
            }
            if (!payload || typeof payload !== 'object') return;
            var d = payload.type === 'PLAYER_EVENT' && payload.data ? payload.data : payload;
            var ct = Number(d.currentTime !== undefined ? d.currentTime : d.timestamp);
            var dur = Number(d.duration);
            if (isFinite(ct) && isFinite(dur) && dur > 0) {
                try { channel.postMessage({ currentTime: ct, duration: dur }); } catch (e) {}
            }
        }, false);
    })();
    """
}

private final class WeakVidlyMessageHandler: NSObject, WKScriptMessageHandler {
    private weak var delegate: WKScriptMessageHandler?

    init(_ delegate: WKScriptMessageHandler) {
        self.delegate = delegate
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        delegate?.userContentController(userContentController, didReceive: message)
    }
}
