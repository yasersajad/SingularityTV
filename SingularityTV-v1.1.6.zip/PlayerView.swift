import AVFoundation
import MediaPlayer
import SwiftUI
import UIKit
import WebKit

struct PlayerView: View {
    let item: WatchItem
    var continueWatchingManager: ContinueWatchingManager?

    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var scenePhase
    @Environment(NFAppModel.self) private var app
    @State private var isLoading = true
    @State private var lastPersistedSeconds: Double = -.greatestFiniteMagnitude
    @State private var webViewRef: WKWebView?
    @State private var movieRuntimeText: String?
    @State private var arabicTitleText: String?
    @State private var posterArtwork: MPMediaItemArtwork?
    @State private var activeURL: URL
    @State private var activeServerID: String = "vidly"

    init(item: WatchItem, continueWatchingManager: ContinueWatchingManager? = nil) {
        self.item = item
        self.continueWatchingManager = continueWatchingManager
        _activeURL = State(initialValue: item.generatedURL)
    }

    private var subtitleMetaText: String {
        if item.type == .tv {
            let s = item.season ?? 1
            let e = item.episode ?? 1
            if let epName = item.episodeName, !epName.isEmpty {
                return "S\(s):E\(e) · \(epName)"
            }
            return "S\(s):E\(e)"
        }
        return movieRuntimeText ?? ""
    }

    private var posterURLString: String {
        item.posterURL?.absoluteString ?? ""
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VidlyDirectWebView(
                url: activeURL,
                originalURL: item.generatedURL,
                tmdbId: item.tmdbId,
                season: item.season ?? 1,
                episode: item.episode ?? 1,
                activeServerID: activeServerID,
                mediaTitle: item.title,
                arabicTitle: arabicTitleText ?? item.title,
                isMovie: item.type == .movie,
                subtitleMeta: subtitleMetaText,
                posterURL: posterURLString,
                onWebViewCreated: { webView in
                    webViewRef = webView
                },
                onLoadingChanged: { loading in
                    isLoading = loading
                },
                onProgress: { currentTime, duration in
                    persistProgress(currentTime: currentTime, duration: duration)
                },
                onSwitchExternalServer: { serverId, newURL in
                    activeServerID = serverId
                    activeURL = newURL
                },
                onBackRequested: {
                    HapticManager.shared.lightImpact()
                    dismiss()
                }
            )
            .ignoresSafeArea()

            if isLoading {
                ProgressView()
                    .progressViewStyle(.circular)
                    .tint(.white)
                    .scaleEffect(1.25)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .allowsHitTesting(false)
            }
        }
        .statusBarHidden()
        .persistentSystemOverlays(.hidden)
        .toolbar(.hidden, for: .navigationBar)
        .preferredColorScheme(.dark)
        .task {
            await loadMetadataAndPoster()
        }
        .onAppear {
            Self.configureAudioSession()
            NFOrientation.enterPlayback()
            app.history.add(item)
            publishNowPlaying(elapsed: nil, duration: nil)
        }
        .onDisappear {
            webViewRef?.pauseAllMediaPlayback(completionHandler: nil)
            MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
            try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
            NFOrientation.exitPlayback()
        }
        .onChange(of: scenePhase) { _, phase in
            if phase == .background {
                webViewRef?.pauseAllMediaPlayback(completionHandler: nil)
            }
        }
    }

    private func loadMetadataAndPoster() async {
        async let runtimeTask: Void = loadMovieRuntimeAndArabicTitleIfNeeded()
        async let posterTask: Void = loadPosterArtworkIfNeeded()
        _ = await (runtimeTask, posterTask)
        publishNowPlaying(elapsed: nil, duration: nil)
    }

    private func loadMovieRuntimeAndArabicTitleIfNeeded() async {
        guard let tmdbInt = Int(item.tmdbId) else { return }
        if item.type == .movie, movieRuntimeText == nil {
            if let payload = try? await NFCatalogService.title(type: .movie, id: tmdbInt),
               let formatted = NF.runtimeText(minutes: payload.runtime) {
                movieRuntimeText = formatted
            }
        }
        let credential = TMDBConfig.credential
        guard NightFlixUserConfiguration.isValidTMDBReadAccessToken(credential) else { return }
        let kind = item.type == .movie ? "movie" : "tv"
        guard let url = URL(string: "https://api.themoviedb.org/3/\(kind)/\(tmdbInt)?language=ar") else { return }
        var req = URLRequest(url: url)
        req.setValue("Bearer \(credential)", forHTTPHeaderField: "Authorization")
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        if let (data, _) = try? await URLSession.shared.data(for: req),
           let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
            let arName = (obj["title"] as? String) ?? (obj["name"] as? String)
            if let arName, !arName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                arabicTitleText = arName
            }
        }
    }

    private func loadPosterArtworkIfNeeded() async {
        guard posterArtwork == nil, let url = item.posterURL else { return }
        if let (data, _) = try? await URLSession.shared.data(from: url),
           let image = UIImage(data: data) {
            posterArtwork = MPMediaItemArtwork(boundsSize: image.size) { _ in image }
        }
    }

    private func publishNowPlaying(elapsed: Double?, duration: Double?) {
        var info: [String: Any] = [
            MPMediaItemPropertyTitle: item.title,
            MPMediaItemPropertyArtist: "SingularityTV",
            MPMediaItemPropertyAlbumTitle: subtitleMetaText.isEmpty ? "SingularityTV" : subtitleMetaText,
            MPNowPlayingInfoPropertyPlaybackRate: 1.0
        ]
        if let elapsed, elapsed.isFinite {
            info[MPNowPlayingInfoPropertyElapsedPlaybackTime] = elapsed
        }
        if let duration, duration.isFinite, duration > 0 {
            info[MPMediaItemPropertyPlaybackDuration] = duration
        }
        if let posterArtwork {
            info[MPMediaItemPropertyArtwork] = posterArtwork
        }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = info
    }

    private func persistProgress(currentTime: Double, duration: Double) {
        guard currentTime.isFinite, duration.isFinite, duration > 0 else { return }
        if item.type == .movie, movieRuntimeText == nil {
            movieRuntimeText = NF.compactDuration(seconds: duration)
        }
        publishNowPlaying(elapsed: currentTime, duration: duration)
        guard abs(currentTime - lastPersistedSeconds) >= 5 else { return }
        lastPersistedSeconds = currentTime
        continueWatchingManager?.recordProgress(
            type: item.type,
            tmdbId: item.tmdbId,
            title: item.title,
            posterPath: item.posterPath,
            season: item.season,
            episode: item.episode,
            episodeName: item.episodeName,
            positionSeconds: currentTime,
            durationSeconds: duration
        )
        let isWatched = duration > 0 && (currentTime / duration) >= 0.95
        SingularitySessionManager.shared.pushProgressAtomic(
            type: item.type,
            tmdbId: item.tmdbId,
            season: item.season,
            episode: item.episode,
            positionSeconds: currentTime,
            durationSeconds: duration,
            watched: isWatched
        )
    }

    private static func configureAudioSession() {
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback, mode: .moviePlayback)
        try? session.setActive(true)
    }
}

private struct VidlyDirectWebView: UIViewRepresentable {
    let url: URL
    let originalURL: URL
    let tmdbId: String
    let season: Int
    let episode: Int
    let activeServerID: String
    let mediaTitle: String
    let arabicTitle: String
    let isMovie: Bool
    let subtitleMeta: String
    let posterURL: String
    let onWebViewCreated: (WKWebView) -> Void
    let onLoadingChanged: (Bool) -> Void
    let onProgress: (Double, Double) -> Void
    let onSwitchExternalServer: (String, URL) -> Void
    let onBackRequested: () -> Void

    private static let progressHandlerName = "vidlyProgress"
    private static let backHandlerName = "vidlyBack"
    private static let serverSwitchHandlerName = "vidlySwitchServer"

    func makeCoordinator() -> Coordinator {
        Coordinator(
            originalURL: originalURL,
            tmdbId: tmdbId,
            season: season,
            episode: episode,
            activeServerID: activeServerID,
            mediaTitle: mediaTitle,
            arabicTitle: arabicTitle,
            isMovie: isMovie,
            subtitleMeta: subtitleMeta,
            posterURL: posterURL,
            onLoadingChanged: onLoadingChanged,
            onProgress: onProgress,
            onSwitchExternalServer: onSwitchExternalServer,
            onBackRequested: onBackRequested
        )
    }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        config.allowsInlineMediaPlayback = true
        config.allowsPictureInPictureMediaPlayback = false
        config.allowsAirPlayForMediaPlayback = true
        config.defaultWebpagePreferences.allowsContentJavaScript = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.preferences.javaScriptCanOpenWindowsAutomatically = false
        if #available(iOS 15.4, *) {
            config.preferences.isElementFullscreenEnabled = false
        }
        config.applicationNameForUserAgent = "Version/18.0 Mobile/15E148 Safari/604.1"

        let ucc = config.userContentController
        let handler = WeakVidlyMessageHandler(context.coordinator)
        ucc.add(handler, name: Self.progressHandlerName)
        ucc.add(handler, name: Self.backHandlerName)
        ucc.add(handler, name: Self.serverSwitchHandlerName)
        ucc.addUserScript(
            WKUserScript(
                source: Self.vidlyCleanupScript(
                    title: mediaTitle,
                    isMovie: isMovie,
                    subtitleMeta: subtitleMeta,
                    posterURL: posterURL,
                    activeServerID: activeServerID
                ),
                injectionTime: .atDocumentStart,
                forMainFrameOnly: false
            )
        )
        ucc.addUserScript(
            WKUserScript(
                source: Self.vidlyProgressScript,
                injectionTime: .atDocumentStart,
                forMainFrameOnly: true
            )
        )

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.isOpaque = false
        webView.backgroundColor = .black
        webView.allowsBackForwardNavigationGestures = false
        webView.scrollView.backgroundColor = .black
        webView.scrollView.bounces = false
        webView.scrollView.isScrollEnabled = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never

        onWebViewCreated(webView)
        context.coordinator.load(url, in: webView)
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        context.coordinator.onLoadingChanged = onLoadingChanged
        context.coordinator.onProgress = onProgress
        context.coordinator.onSwitchExternalServer = onSwitchExternalServer
        context.coordinator.onBackRequested = onBackRequested
        context.coordinator.arabicTitle = arabicTitle
        context.coordinator.updateMetadata(
            title: mediaTitle,
            isMovie: isMovie,
            subtitleMeta: subtitleMeta,
            posterURL: posterURL,
            activeServerID: activeServerID,
            in: webView
        )
        context.coordinator.load(url, in: webView)
    }

    static func dismantleUIView(_ webView: WKWebView, coordinator: Coordinator) {
        webView.stopLoading()
        webView.pauseAllMediaPlayback(completionHandler: nil)
        webView.navigationDelegate = nil
        webView.uiDelegate = nil
        webView.configuration.userContentController.removeAllUserScripts()
        webView.configuration.userContentController.removeScriptMessageHandler(forName: progressHandlerName)
        webView.configuration.userContentController.removeScriptMessageHandler(forName: backHandlerName)
        webView.configuration.userContentController.removeScriptMessageHandler(forName: serverSwitchHandlerName)
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
        let originalURL: URL
        let tmdbId: String
        let season: Int
        let episode: Int
        var activeServerID: String
        var mediaTitle: String
        var arabicTitle: String
        var isMovie: Bool
        var subtitleMeta: String
        var posterURL: String
        var onLoadingChanged: (Bool) -> Void
        var onProgress: (Double, Double) -> Void
        var onSwitchExternalServer: (String, URL) -> Void
        var onBackRequested: () -> Void
        private var loadedURL: URL?

        init(
            originalURL: URL,
            tmdbId: String,
            season: Int,
            episode: Int,
            activeServerID: String,
            mediaTitle: String,
            arabicTitle: String,
            isMovie: Bool,
            subtitleMeta: String,
            posterURL: String,
            onLoadingChanged: @escaping (Bool) -> Void,
            onProgress: @escaping (Double, Double) -> Void,
            onSwitchExternalServer: @escaping (String, URL) -> Void,
            onBackRequested: @escaping () -> Void
        ) {
            self.originalURL = originalURL
            self.tmdbId = tmdbId
            self.season = season
            self.episode = episode
            self.activeServerID = activeServerID
            self.mediaTitle = mediaTitle
            self.arabicTitle = arabicTitle
            self.isMovie = isMovie
            self.subtitleMeta = subtitleMeta
            self.posterURL = posterURL
            self.onLoadingChanged = onLoadingChanged
            self.onProgress = onProgress
            self.onSwitchExternalServer = onSwitchExternalServer
            self.onBackRequested = onBackRequested
        }

        func load(_ url: URL, in webView: WKWebView) {
            guard loadedURL != url else { return }
            loadedURL = url
            onLoadingChanged(true)
            webView.load(URLRequest(url: url))
        }

        func updateMetadata(title: String, isMovie: Bool, subtitleMeta: String, posterURL: String, activeServerID: String, in webView: WKWebView) {
            guard self.subtitleMeta != subtitleMeta || self.mediaTitle != title || self.posterURL != posterURL || self.activeServerID != activeServerID else { return }
            self.mediaTitle = title
            self.isMovie = isMovie
            self.subtitleMeta = subtitleMeta
            self.posterURL = posterURL
            self.activeServerID = activeServerID
            let js = "window.__singularityMeta = { title: '\(Self.jsEscape(title))', isMovie: \(isMovie ? "true" : "false"), subtitle: '\(Self.jsEscape(subtitleMeta))', poster: '\(Self.jsEscape(posterURL))', activeServer: '\(Self.jsEscape(activeServerID))' }; if (typeof window.__singularitySyncHeader === 'function') { window.__singularitySyncHeader(); } if (typeof window.__singularitySyncMediaSession === 'function') { window.__singularitySyncMediaSession(); }"
            webView.evaluateJavaScript(js, completionHandler: nil)
        }

        private func urlForExternalServer(_ serverId: String) -> URL? {
            switch serverId {
            case "vidly":
                return originalURL
            case "anafast", "vidspeed", "vidoba":
                let query = isMovie ? arabicTitle : "\(arabicTitle) الحلقة \(episode)"
                let encoded = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? query
                return URL(string: "https://elif.news/?s=\(encoded)&sgServer=\(serverId)")
            case "vidsrccc":
                let str = isMovie
                    ? "https://vidsrc.cc/v2/embed/movie/\(tmdbId)?poster=true&autoPlay=true"
                    : "https://vidsrc.cc/v2/embed/tv/\(tmdbId)/\(season)/\(episode)?poster=true&autoPlay=true"
                return URL(string: str)
            case "vidlink":
                let str = isMovie
                    ? "https://vidlink.pro/movie/\(tmdbId)?primaryColor=E50914&autoplay=true"
                    : "https://vidlink.pro/tv/\(tmdbId)/\(season)/\(episode)?primaryColor=E50914&autoplay=true"
                return URL(string: str)
            case "vidfast":
                let str = isMovie
                    ? "https://vidfast.pro/movie/\(tmdbId)?autoPlay=true"
                    : "https://vidfast.pro/tv/\(tmdbId)/\(season)/\(episode)?autoPlay=true"
                return URL(string: str)
            case "vidsrcxyz":
                let str = isMovie
                    ? "https://vidsrc.xyz/embed/movie?tmdb=\(tmdbId)"
                    : "https://vidsrc.xyz/embed/tv?tmdb=\(tmdbId)&season=\(season)&episode=\(episode)"
                return URL(string: str)
            case "autoembed":
                let str = isMovie
                    ? "https://player.autoembed.cc/embed/movie/\(tmdbId)?server=1"
                    : "https://player.autoembed.cc/embed/tv/\(tmdbId)/\(season)/\(episode)?server=1"
                return URL(string: str)
            case "moviesapi":
                let str = isMovie
                    ? "https://moviesapi.club/movie/\(tmdbId)"
                    : "https://moviesapi.club/tv/\(tmdbId)-\(season)-\(episode)"
                return URL(string: str)
            case "rivestream":
                let str = isMovie
                    ? "https://rivestream.org/embed?type=movie&id=\(tmdbId)"
                    : "https://rivestream.org/embed?type=tv&id=\(tmdbId)&season=\(season)&episode=\(episode)"
                return URL(string: str)
            default:
                return nil
            }
        }

        private static func jsEscape(_ str: String) -> String {
            str
                .replacingOccurrences(of: "\\", with: "\\\\")
                .replacingOccurrences(of: "'", with: "\\'")
                .replacingOccurrences(of: "\n", with: " ")
                .replacingOccurrences(of: "\r", with: " ")
        }

        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            if navigationAction.targetFrame?.isMainFrame == true,
               navigationAction.navigationType == .linkActivated,
               let host = navigationAction.request.url?.host?.lowercased() {
                let allowed = ["vidly", "elif.news", "anafast", "vidspeed", "vidoba", "vidsrc", "vidlink", "vidfast", "autoembed", "moviesapi", "rivestream"]
                if !allowed.contains(where: { host.contains($0) }) {
                    decisionHandler(.cancel)
                    return
                }
            }
            decisionHandler(.allow)
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            onLoadingChanged(false)
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            onLoadingChanged(false)
        }

        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            onLoadingChanged(false)
        }

        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            nil
        }

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            if message.name == VidlyDirectWebView.backHandlerName {
                DispatchQueue.main.async {
                    self.onBackRequested()
                }
                return
            }
            if message.name == VidlyDirectWebView.serverSwitchHandlerName,
               let serverId = message.body as? String,
               let targetURL = urlForExternalServer(serverId) {
                DispatchQueue.main.async {
                    self.onSwitchExternalServer(serverId, targetURL)
                }
                return
            }
            guard message.name == VidlyDirectWebView.progressHandlerName,
                  let dict = message.body as? [String: Any],
                  let currentTime = dict["currentTime"] as? Double,
                  let duration = dict["duration"] as? Double else { return }
            onProgress(currentTime, duration)
        }
    }

    private static func vidlyCleanupScript(title: String, isMovie: Bool, subtitleMeta: String, posterURL: String, activeServerID: String) -> String {
        let escapedTitle = title
            .replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "'", with: "\\'")
            .replacingOccurrences(of: "\n", with: " ")
            .replacingOccurrences(of: "\r", with: " ")
        let escapedSub = subtitleMeta
            .replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "'", with: "\\'")
            .replacingOccurrences(of: "\n", with: " ")
            .replacingOccurrences(of: "\r", with: " ")
        let escapedPoster = posterURL
            .replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "'", with: "\\'")
            .replacingOccurrences(of: "\n", with: " ")
            .replacingOccurrences(of: "\r", with: " ")
        let escapedServer = activeServerID
            .replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "'", with: "\\'")

        return """
        (function () {
            window.__singularityMeta = {
                title: '\(escapedTitle)',
                isMovie: \(isMovie ? "true" : "false"),
                subtitle: '\(escapedSub)',
                poster: '\(escapedPoster)',
                activeServer: '\(escapedServer)'
            };

            var EXTRA_SERVERS = [
                { id: 'anafast', name: 'Anafast (Arabic)' },
                { id: 'vidspeed', name: 'Vidspeed (Arabic)' },
                { id: 'vidoba', name: 'Vidoba (Arabic)' },
                { id: 'vidsrccc', name: 'VidSrc.cc' },
                { id: 'vidlink', name: 'VidLink Pro' },
                { id: 'autoembed', name: 'AutoEmbed' },
                { id: 'vidsrcxyz', name: 'VidSrc.xyz' },
                { id: 'vidfast', name: 'VidFast' },
                { id: 'moviesapi', name: 'MoviesAPI' },
                { id: 'rivestream', name: 'RiveStream' }
            ];

            var noop = function () { return Promise.resolve(); };
            try {
                Element.prototype.requestFullscreen = noop;
                Element.prototype.webkitRequestFullscreen = noop;
                Element.prototype.webkitRequestFullScreen = noop;
                HTMLVideoElement.prototype.webkitEnterFullscreen = function () {};
                HTMLVideoElement.prototype.webkitEnterFullScreen = function () {};
                Document.prototype.exitFullscreen = noop;
                Document.prototype.webkitExitFullscreen = noop;
                Object.defineProperty(document, 'fullscreenEnabled', { get: function () { return false; } });
                Object.defineProperty(document, 'webkitFullscreenEnabled', { get: function () { return false; } });
            } catch (e) {}

            var cssText = [
                '*, *::before, *::after { -webkit-user-select: none !important; user-select: none !important; -webkit-touch-callout: none !important; -webkit-tap-highlight-color: transparent !important; }',
                'html, body { background: #000000 !important; font-family: -apple-system, BlinkMacSystemFont, "SF Pro Display", sans-serif !important; overflow: hidden !important; }',
                '[aria-label*="fullscreen" i], [aria-label*="full screen" i], [title*="fullscreen" i], [title*="full screen" i], [data-testid*="fullscreen" i], [data-plyr="fullscreen"], .vjs-fullscreen-control, .plyr__control--fullscreen { display: none !important; opacity: 0 !important; visibility: hidden !important; pointer-events: none !important; width: 0 !important; height: 0 !important; }',
                'a[href*="vidly" i], img[src*="vidly" i], img[alt*="vidly" i], [aria-label*="vidly" i], [title*="vidly" i], [class*="watermark" i]:not(#__sgWatermark), [class*="brand-logo" i], [class*="player-logo" i] { display: none !important; opacity: 0 !important; visibility: hidden !important; pointer-events: none !important; width: 0 !important; height: 0 !important; }',
                '[role="dialog"] { max-height: calc(100vh - 28px) !important; overflow-y: auto !important; -webkit-overflow-scrolling: touch !important; border-radius: 16px !important; box-shadow: 0 24px 60px rgba(0, 0, 0, 0.85) !important; }',
                'input[type="range"] { accent-color: #E50914 !important; }'
            ].join('\\n');

            function injectCSSImmediate() {
                if (document.getElementById('singularity-vidly-cleanup-css')) return;
                var target = document.head || document.documentElement;
                if (!target) return;
                var style = document.createElement('style');
                style.id = 'singularity-vidly-cleanup-css';
                style.textContent = cssText;
                target.appendChild(style);
            }
            injectCSSImmediate();

            function lockTitleAndFavicon() {
                try {
                    if (document.title !== 'SingularityTV') {
                        document.title = 'SingularityTV';
                    }
                    if (!window.__sgTitleLocked) {
                        window.__sgTitleLocked = true;
                        Object.defineProperty(document, 'title', {
                            configurable: true,
                            get: function () { return 'SingularityTV'; },
                            set: function () {}
                        });
                    }
                } catch (e) {}

                var poster = (window.__singularityMeta && window.__singularityMeta.poster) || '';
                if (poster && window.__sgLastFavicon !== poster) {
                    window.__sgLastFavicon = poster;
                    var icons = document.querySelectorAll('link[rel*="icon" i], link[rel*="apple-touch-icon" i]');
                    for (var i = 0; i < icons.length; i++) {
                        if (icons[i].href !== poster) icons[i].href = poster;
                    }
                    if (icons.length === 0 && document.head) {
                        var lnk = document.createElement('link');
                        lnk.rel = 'apple-touch-icon';
                        lnk.href = poster;
                        document.head.appendChild(lnk);
                    }
                }
            }

            function syncMediaSession() {
                try {
                    if (!('mediaSession' in navigator) || typeof MediaMetadata === 'undefined') return;
                    var meta = window.__singularityMeta || {};
                    var key = (meta.title || '') + '|' + (meta.subtitle || '') + '|' + (meta.poster || '');
                    if (window.__sgLastMediaKey === key) return;
                    window.__sgLastMediaKey = key;
                    var art = meta.poster ? [{ src: meta.poster, sizes: '512x512', type: 'image/jpeg' }] : [];
                    navigator.mediaSession.metadata = new MediaMetadata({
                        title: meta.title || 'SingularityTV',
                        artist: 'SingularityTV',
                        album: meta.subtitle || 'SingularityTV',
                        artwork: art
                    });
                } catch (e) {}
            }
            window.__singularitySyncMediaSession = syncMediaSession;

            lockTitleAndFavicon();
            syncMediaSession();

            function hideEl(el) {
                if (!el || el.dataset.sgHidden === '1' || el.tagName === 'VIDEO' || el.tagName === 'BODY' || el.tagName === 'HTML') return;
                if (el.id === '__sgTopBackBtn' || el.id === '__sgMovieSub' || el.id === '__sgWatermark' || el.id === '__sgExtServerPill' || el.id === '__sgExtServerModal') return;
                el.dataset.sgHidden = '1';
                el.style.setProperty('display', 'none', 'important');
                el.style.setProperty('opacity', '0', 'important');
                el.style.setProperty('visibility', 'hidden', 'important');
                el.style.setProperty('pointer-events', 'none', 'important');
            }

            function isMaximizeSvg(el) {
                var svg = el.tagName === 'SVG' ? el : (el.querySelector ? el.querySelector('svg') : null);
                if (!svg) return false;
                var html = (svg.innerHTML || '').toLowerCase();
                return html.indexOf('m15 3h6v6') !== -1 ||
                       html.indexOf('m8 3h5') !== -1 ||
                       html.indexOf('m3 8v5') !== -1 ||
                       html.indexOf('15 3 21 3 21 9') !== -1 ||
                       html.indexOf('9 21 3 21 3 15') !== -1 ||
                       html.indexOf('fullscreen') !== -1;
            }

            function effOp(el) {
                var op = 1, cur = el;
                while (cur && cur.nodeType === 1) {
                    var cs = getComputedStyle(cur);
                    if (cs.display === 'none' || cs.visibility === 'hidden') return 0;
                    op *= parseFloat(cs.opacity);
                    if (op <= 0.02) return 0;
                    cur = cur.parentElement;
                }
                return op;
            }

            function hasFullScreenDrawer() {
                var vw = window.innerWidth || 0;
                var vh = window.innerHeight || 0;
                var dialogs = document.querySelectorAll('[role="dialog"], [class*="drawer" i]');
                for (var i = 0; i < dialogs.length; i++) {
                    var d = dialogs[i];
                    if (d.id === '__sgExtServerModal') continue;
                    var r = d.getBoundingClientRect ? d.getBoundingClientRect() : null;
                    if (r && r.width > vw * 0.72 && r.height > vh * 0.72 && effOp(d) > 0.1) {
                        return true;
                    }
                }
                return false;
            }

            function switchServer(id) {
                try {
                    window.webkit.messageHandlers.\(Self.serverSwitchHandlerName).postMessage(id);
                } catch (e) {}
            }

            function injectExtraServersIntoDialog() {
                if (window !== window.top) return;
                var btns = document.querySelectorAll('button, [role="button"]');
                var anchorBtn = null;
                for (var b = 0; b < btns.length; b++) {
                    var bt = (btns[b].innerText || btns[b].textContent || '').trim().toLowerCase();
                    if (bt === 'citadel' || bt === 'comet' || bt === 'nimbus' || bt === 'flux' || bt === 'prism' || bt === 'edge') {
                        if (effOp(btns[b]) > 0.1) {
                            anchorBtn = btns[b];
                        }
                    }
                }
                if (!anchorBtn || !anchorBtn.parentElement) return;
                var listParent = anchorBtn.parentElement;
                if (listParent.querySelector('[data-sg-extra-server="1"]')) return;

                var divider = document.createElement('div');
                divider.dataset.sgExtraServer = '1';
                divider.style.cssText = 'font-size:10px;font-weight:700;letter-spacing:0.8px;color:rgba(255,255,255,0.45);padding:10px 12px 4px 24px;text-transform:uppercase;';
                divider.textContent = 'ARABIC & EXTRA SERVERS';
                listParent.appendChild(divider);

                for (var s = 0; s < EXTRA_SERVERS.length; s++) {
                    (function (srv) {
                        var row = document.createElement('button');
                        row.type = 'button';
                        row.dataset.sgExtraServer = '1';
                        row.style.cssText = 'width:100%;display:flex;align-items:center;gap:8px;padding:8px 12px 8px 24px;background:transparent;border:none;color:rgba(255,255,255,0.9);font-size:13.5px;font-weight:500;text-align:left;cursor:pointer;border-radius:8px;';
                        row.textContent = srv.name;
                        row.addEventListener('click', function (ev) {
                            ev.stopPropagation();
                            ev.preventDefault();
                            switchServer(srv.id);
                        }, true);
                        listParent.appendChild(row);
                    })(EXTRA_SERVERS[s]);
                }
            }

            function cleanElifPage() {
                if (window.location.hostname.indexOf('elif.news') === -1) return;
                if (!document.getElementById('singularity-elif-css') && (document.head || document.documentElement)) {
                    var st = document.createElement('style');
                    st.id = 'singularity-elif-css';
                    st.textContent = 'header, footer, nav, article, .entry-content > p, .entry-content > h1, .entry-content > h2, .entry-content > h3, [class*="ad" i] { display: none !important; } body { background: #000 !important; overflow-y: auto !important; padding-top: 56px !important; } iframe { width: 100vw !important; height: calc(100vh - 96px) !important; border: none !important; }';
                    (document.head || document.documentElement).appendChild(st);
                }
                var desired = '';
                var q = window.location.search || '';
                if (q.indexOf('sgServer=anafast') !== -1) desired = 'anafast';
                else if (q.indexOf('sgServer=vidspeed') !== -1) desired = 'vidspeed';
                else if (q.indexOf('sgServer=vidoba') !== -1) desired = 'vidoba';
                if (desired && !window.__sgElifPicked) {
                    var btns = document.querySelectorAll('button, a');
                    for (var i = 0; i < btns.length; i++) {
                        var t = (btns[i].innerText || '').trim().toLowerCase();
                        if (t === desired) {
                            window.__sgElifPicked = true;
                            btns[i].click();
                            break;
                        }
                    }
                }
            }

            function ensureExternalSwitcherUI() {
                if (window !== window.top || !document.body) return;
                var meta = window.__singularityMeta || {};
                var isExternal = meta.activeServer && meta.activeServer !== 'vidly';
                var pill = document.getElementById('__sgExtServerPill');

                if (!isExternal) {
                    var bodyTxt = (document.body.innerText || '').toLowerCase();
                    var isErr = bodyTxt.indexOf('stream unavailable') !== -1 || bodyTxt.indexOf('no sources') !== -1 || bodyTxt.indexOf('media not found') !== -1;
                    if (!isErr) {
                        if (pill) pill.style.display = 'none';
                        return;
                    }
                }

                if (!pill) {
                    pill = document.createElement('button');
                    pill.id = '__sgExtServerPill';
                    pill.type = 'button';
                    pill.style.cssText = 'position:fixed;top:16px;right:50px;z-index:2147483645;display:inline-flex;align-items:center;gap:6px;padding:7px 12px;border-radius:999px;background:rgba(16,17,24,0.84);border:1px solid rgba(255,255,255,0.18);color:#FFFFFF;font-size:12.5px;font-weight:600;cursor:pointer;backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);';
                    pill.addEventListener('click', function (ev) {
                        ev.stopPropagation();
                        ev.preventDefault();
                        toggleExternalServerModal();
                    }, true);
                    document.body.appendChild(pill);
                }
                pill.style.display = 'inline-flex';
                pill.textContent = isExternal ? ('Server: ' + meta.activeServer) : 'Switch Server (Arabic / Extra)';
            }

            function toggleExternalServerModal() {
                var existing = document.getElementById('__sgExtServerModal');
                if (existing) {
                    existing.remove();
                    return;
                }
                var meta = window.__singularityMeta || {};
                var modal = document.createElement('div');
                modal.id = '__sgExtServerModal';
                modal.style.cssText = 'position:fixed;top:56px;right:18px;width:240px;max-height:calc(100vh - 80px);overflow-y:auto;z-index:2147483646;background:rgba(14,15,22,0.95);border:1px solid rgba(255,255,255,0.14);border-radius:16px;padding:10px;backdrop-filter:blur(20px);-webkit-backdrop-filter:blur(20px);box-shadow:0 20px 50px rgba(0,0,0,0.85);';

                var list = [{ id: 'vidly', name: 'Vidly.pro (Default)' }].concat(EXTRA_SERVERS);
                for (var i = 0; i < list.length; i++) {
                    (function (srv) {
                        var btn = document.createElement('button');
                        btn.type = 'button';
                        var isCur = (meta.activeServer || 'vidly') === srv.id;
                        btn.style.cssText = 'width:100%;display:flex;align-items:center;justify-content:space-between;padding:9px 10px;border-radius:10px;border:none;background:' + (isCur ? 'rgba(229,9,20,0.22)' : 'transparent') + ';color:#FFFFFF;font-size:13px;font-weight:' + (isCur ? '700' : '500') + ';text-align:left;cursor:pointer;';
                        btn.textContent = srv.name + (isCur ? ' ✓' : '');
                        btn.addEventListener('click', function (ev) {
                            ev.stopPropagation();
                            ev.preventDefault();
                            modal.remove();
                            switchServer(srv.id);
                        }, true);
                        modal.appendChild(btn);
                    })(list[i]);
                }
                document.body.appendChild(modal);
            }

            function ensureWatermark() {
                if (window !== window.top) return;
                var root = document.body || document.documentElement;
                if (!root) return;
                var wm = document.getElementById('__sgWatermark');
                if (!wm) {
                    wm = document.createElement('div');
                    wm.id = '__sgWatermark';
                    wm.style.cssText = 'position:fixed;top:18px;right:18px;z-index:2147483644;pointer-events:none;user-select:none;opacity:0;transition:opacity 140ms ease;filter:drop-shadow(0 1px 4px rgba(0,0,0,0.7));display:inline-flex;align-items:center;justify-content:center;';
                    wm.innerHTML = '<svg width="20" height="20" viewBox="0 0 64 64" fill="none"><path d="M46 13H25C19 13 14.5 17 14.5 22.5C14.5 28 19 31.5 25 31.5H39C44.5 31.5 49 35 49 40.5C49 46.5 44.5 51 38.5 51H16.5" stroke="#FFFFFF" stroke-width="7.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
                    root.appendChild(wm);
                }
                if (hasFullScreenDrawer()) {
                    wm.style.opacity = '0';
                    return;
                }
                var topBtns = document.querySelectorAll('button, [role="button"]');
                var alignedTop = null;
                var alignedOp = 0;
                for (var i = 0; i < topBtns.length; i++) {
                    var b = topBtns[i];
                    if (b.id === '__sgTopBackBtn') continue;
                    var r = b.getBoundingClientRect ? b.getBoundingClientRect() : null;
                    if (r && r.top >= 4 && r.top < 76 && r.right > (window.innerWidth || 0) * 0.5 && r.height > 12) {
                        var op = effOp(b);
                        if (op > 0.15) {
                            alignedTop = Math.round(r.top + (r.height - 20) / 2);
                            alignedOp = op;
                            break;
                        }
                    }
                }
                if (alignedTop !== null) {
                    wm.style.top = alignedTop + 'px';
                    wm.style.right = '18px';
                    wm.style.opacity = String(Math.min(0.68, alignedOp));
                } else {
                    wm.style.opacity = '0';
                }
            }

            function fmtRuntime(sec) {
                var meta = window.__singularityMeta || {};
                if (meta.subtitle && meta.subtitle.length > 0) return meta.subtitle;
                if (!isFinite(sec) || sec < 60) return '';
                var m = Math.round(sec / 60);
                var h = Math.floor(m / 60), rm = m % 60;
                return h > 0 ? (rm > 0 ? (h + 'h ' + rm + 'm') : (h + 'h')) : (rm + 'm');
            }

            function ensureTopBack() {
                if (window !== window.top || !document.body) return;
                var bk = document.getElementById('__sgTopBackBtn');
                if (!bk) {
                    bk = document.createElement('button');
                    bk.id = '__sgTopBackBtn';
                    bk.type = 'button';
                    bk.setAttribute('aria-label', 'Back');
                    bk.style.cssText = 'position:fixed;z-index:2147483645;display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;background:transparent;border:none;color:#FFFFFF;cursor:pointer;padding:0;margin:0;opacity:0;pointer-events:none;transition:opacity 120ms ease;';
                    bk.innerHTML = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5"></path><path d="M12 19l-7-7 7-7"></path></svg>';
                    bk.addEventListener('pointerdown', function (e) { e.stopPropagation(); }, true);
                    bk.addEventListener('click', function (ev) {
                        ev.stopPropagation();
                        ev.preventDefault();
                        try {
                            window.webkit.messageHandlers.\(Self.backHandlerName).postMessage(true);
                        } catch (e) {}
                    }, true);
                    document.body.appendChild(bk);
                }

                if (hasFullScreenDrawer()) {
                    bk.style.opacity = '0';
                    bk.style.pointerEvents = 'none';
                    return;
                }

                var meta = window.__singularityMeta || {};
                if (meta.activeServer && meta.activeServer !== 'vidly') {
                    bk.style.left = '16px';
                    bk.style.top = '14px';
                    bk.style.opacity = '1';
                    bk.style.pointerEvents = 'auto';
                    return;
                }

                var titleEl = null, titleOp = 0;
                var tCands = document.querySelectorAll('h1,h2,h3,div,span,p');
                for (var j = 0; j < tCands.length; j++) {
                    var el = tCands[j];
                    if (el.id === '__sgTopBackBtn' || el.id === '__sgMovieSub' || el.id === '__sgWatermark' || el.closest('button')) continue;
                    if (el.closest('[role="dialog"], [role="menu"], [class*="drawer" i]')) continue;
                    if (el.children.length > 0) continue;
                    var ttx = (el.textContent || '').trim();
                    if (ttx.length < 2 || ttx.length > 85) continue;
                    var low = ttx.toLowerCase();
                    if (low === 'episodes' || low.indexOf('quality') !== -1 || low.indexOf('server') !== -1 || low.indexOf('audio') !== -1 || low.indexOf('subtitle') !== -1) continue;
                    var tr = el.getBoundingClientRect();
                    if (tr.width > 10 && tr.top >= 2 && tr.top < 105 && tr.left >= 4 && tr.left < 400 && tr.height >= 14 && tr.height < 60) {
                        var op = effOp(el);
                        if (op > 0.15) {
                            titleEl = el;
                            titleOp = op;
                            break;
                        }
                    }
                }

                if (titleEl && titleOp > 0.15) {
                    var titleBox = titleEl.parentElement;
                    var isTvUrl = (location.pathname || '').toLowerCase().indexOf('/tv/') !== -1 || !(window.__singularityMeta && window.__singularityMeta.isMovie);
                    var subEl = document.getElementById('__sgMovieSub');
                    var existingSub = null;
                    if (titleBox) {
                        var sibs = titleBox.children;
                        for (var si = 0; si < sibs.length; si++) {
                            var sb = sibs[si];
                            if (sb === titleEl || sb.id === '__sgMovieSub') continue;
                            var st = (sb.textContent || '').trim();
                            if (st.length > 1 && sb.getBoundingClientRect().top >= titleEl.getBoundingClientRect().top + 8) {
                                existingSub = sb;
                                break;
                            }
                        }
                    }

                    if (!existingSub && titleBox) {
                        var v = document.querySelector('video');
                        var subTxt = fmtRuntime(v ? v.duration : 0);
                        if (subTxt.length > 0) {
                            if (!subEl) {
                                subEl = document.createElement('div');
                                subEl.id = '__sgMovieSub';
                                subEl.style.cssText = 'font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:12.5px;font-weight:500;color:rgba(255,255,255,0.68);margin-top:2px;line-height:1.25;white-space:nowrap;pointer-events:none;';
                            }
                            if (subEl.textContent !== subTxt) subEl.textContent = subTxt;
                            if (subEl.parentElement !== titleBox) {
                                var pcs = getComputedStyle(titleBox);
                                if (pcs.display === 'flex' && pcs.flexDirection !== 'column') {
                                    titleBox.style.setProperty('flex-direction', 'column', 'important');
                                    titleBox.style.setProperty('align-items', 'flex-start', 'important');
                                }
                                titleBox.appendChild(subEl);
                            }
                            existingSub = subEl;
                        }
                    } else if (isTvUrl && existingSub && subEl) {
                        subEl.remove();
                    }

                    var shiftTarget = titleBox || titleEl;
                    if (!shiftTarget.dataset.sgBackShifted && titleEl.getBoundingClientRect().left < 56) {
                        shiftTarget.dataset.sgBackShifted = '1';
                        shiftTarget.style.setProperty('padding-left', '40px', 'important');
                    }

                    var tr2 = titleEl.getBoundingClientRect();
                    var sr2 = existingSub ? existingSub.getBoundingClientRect() : tr2;
                    var midY = (tr2.top + Math.max(tr2.bottom, sr2.bottom)) / 2;
                    var bx = Math.max(10, Math.round(tr2.left - 42));
                    var by = Math.max(4, Math.round(midY - 18));
                    bk.style.left = bx + 'px';
                    bk.style.top = by + 'px';
                    bk.style.opacity = String(titleOp);
                    bk.style.pointerEvents = 'auto';
                } else {
                    bk.style.left = '16px';
                    bk.style.top = '14px';
                    var bodyTxt = (document.body.innerText || '').toLowerCase();
                    var isErr = bodyTxt.indexOf('stream unavailable') !== -1 || bodyTxt.indexOf('try again') !== -1 || bodyTxt.indexOf('no sources') !== -1;
                    bk.style.opacity = isErr ? '1' : '0';
                    bk.style.pointerEvents = isErr ? 'auto' : 'none';
                }

                var topBtns = document.querySelectorAll('button, [role="button"]');
                for (var tb = 0; tb < topBtns.length; tb++) {
                    var btn = topBtns[tb];
                    if (btn.id === '__sgTopBackBtn') continue;
                    var br = btn.getBoundingClientRect ? btn.getBoundingClientRect() : null;
                    if (br && br.top >= 0 && br.top < 70 && br.right > (window.innerWidth || 0) - 52) {
                        if (btn.parentElement && !btn.parentElement.dataset.sgRightShifted && !btn.closest('[role="dialog"], [role="menu"]')) {
                            btn.parentElement.dataset.sgRightShifted = '1';
                            btn.parentElement.style.setProperty('padding-right', '40px', 'important');
                        }
                    }
                }
            }

            window.__singularitySyncHeader = ensureTopBack;

            function cleanQuickNodes() {
                injectCSSImmediate();
                lockTitleAndFavicon();
                syncMediaSession();

                var vw = window.innerWidth || document.documentElement.clientWidth || 0;
                var candidates = document.querySelectorAll('button, [role="button"], a, img, svg, div');
                for (var i = 0; i < candidates.length; i++) {
                    var el = candidates[i];
                    if (!el || el.dataset.sgHidden === '1' || el.tagName === 'VIDEO' || el.id === '__sgTopBackBtn' || el.id === '__sgMovieSub' || el.id === '__sgWatermark' || el.id === '__sgExtServerPill' || el.id === '__sgExtServerModal') continue;

                    var aria = (el.getAttribute('aria-label') || '').toLowerCase();
                    var title = (el.getAttribute('title') || '').toLowerCase();
                    var cls = (typeof el.className === 'string' ? el.className : '').toLowerCase();
                    var id = (el.id || '').toLowerCase();
                    var testId = (el.getAttribute('data-testid') || '').toLowerCase();
                    var href = (el.getAttribute('href') || '').toLowerCase();
                    var src = (el.getAttribute('src') || '').toLowerCase();
                    var alt = (el.getAttribute('alt') || '').toLowerCase();

                    if (aria.indexOf('fullscreen') !== -1 || aria.indexOf('full screen') !== -1 ||
                        title.indexOf('fullscreen') !== -1 || title.indexOf('full screen') !== -1 ||
                        testId.indexOf('fullscreen') !== -1 || id.indexOf('fullscreen') !== -1 ||
                        (el.tagName === 'BUTTON' && (cls.indexOf('fullscreen') !== -1 || isMaximizeSvg(el)))) {
                        hideEl(el);
                        continue;
                    }

                    if (href.indexOf('vidly') !== -1 || src.indexOf('vidly') !== -1 || alt.indexOf('vidly') !== -1 ||
                        aria.indexOf('vidly') !== -1 || title.indexOf('vidly') !== -1 ||
                        cls.indexOf('vidly') !== -1 || id.indexOf('vidly') !== -1) {
                        if (el.tagName === 'A' || el.tagName === 'IMG' || el.tagName === 'SVG' || el.children.length <= 2) {
                            hideEl(el);
                            continue;
                        }
                    }

                    if (vw > 0 && (el.tagName === 'A' || el.tagName === 'IMG' || el.tagName === 'SVG' || el.tagName === 'DIV')) {
                        var rect = el.getBoundingClientRect ? el.getBoundingClientRect() : null;
                        if (rect && rect.top >= 2 && rect.top <= 76 && rect.right >= vw - 80 && rect.width >= 12 && rect.width <= 64 && rect.height >= 12 && rect.height <= 64) {
                            var txt = (el.innerText || el.textContent || '').trim();
                            var isModal = !!el.closest('[role="dialog"], [role="menu"], [class*="drawer" i]');
                            var isControl = el.tagName === 'BUTTON' ||
                                el.getAttribute('role') === 'button' ||
                                el.hasAttribute('tabindex') ||
                                !!el.closest('button, [role="button"]');
                            if (!isModal && !isControl && !txt) {
                                hideEl(el);
                            }
                        }
                    }
                }
            }

            function syncUI() {
                cleanElifPage();
                injectExtraServersIntoDialog();
                ensureExternalSwitcherUI();
                ensureWatermark();
                ensureTopBack();
            }

            var lastCleanAt = 0;
            var scheduledClean = false;
            function scheduleClean() {
                if (scheduledClean) return;
                scheduledClean = true;
                var now = Date.now();
                var delay = Math.max(0, 200 - (now - lastCleanAt));
                setTimeout(function () {
                    scheduledClean = false;
                    lastCleanAt = Date.now();
                    cleanQuickNodes();
                    syncUI();
                }, delay);
            }

            cleanQuickNodes();
            syncUI();
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', function () {
                    cleanQuickNodes();
                    syncUI();
                });
            }

            var obs = new MutationObserver(function () { scheduleClean(); });
            try {
                obs.observe(document.documentElement || document, { childList: true, subtree: true });
            } catch (e) {}

            document.addEventListener('pointerup', function () {
                setTimeout(syncUI, 90);
            }, true);
            setInterval(syncUI, 500);
        })();
        """
    }

    private static let vidlyProgressScript = """
    (function () {
        var handlers = window.webkit && window.webkit.messageHandlers;
        var channel = handlers && handlers.\(progressHandlerName);
        if (!channel) return;

        window.addEventListener('message', function (event) {
            var payload = event.data;
            if (typeof payload === 'string') {
                try { payload = JSON.parse(payload); } catch (e) { return; }
            }
            if (!payload || typeof payload !== 'object') return;
            var d = payload.type === 'PLAYER_EVENT' && payload.data ? payload.data : payload;
            var ct = Number(d.currentTime !== undefined ? d.currentTime : d.timestamp);
            var dur = Number(d.duration);
            if (isFinite(ct) && isFinite(dur) && dur > 0) {
                try { channel.postMessage({ currentTime: ct, duration: dur }); } catch (e) {}
            }
        }, false);
    })();
    """
}

private final class WeakVidlyMessageHandler: NSObject, WKScriptMessageHandler {
    private weak var delegate: WKScriptMessageHandler?

    init(_ delegate: WKScriptMessageHandler) {
        self.delegate = delegate
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        delegate?.userContentController(userContentController, didReceive: message)
    }
}
