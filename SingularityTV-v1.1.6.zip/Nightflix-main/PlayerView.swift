import AVFoundation
import MediaPlayer
import SwiftUI
import UIKit
import WebKit

struct PlayerView: View {
    let item: WatchItem
    var continueWatchingManager: ContinueWatchingManager?

    @Environment(\.dismiss) private var dismiss
    @Environment(\.scenePhase) private var scenePhase
    @Environment(NFAppModel.self) private var app
    @State private var isLoading = true
    @State private var lastPersistedSeconds: Double = -.greatestFiniteMagnitude
    @State private var webViewRef: WKWebView?
    @State private var movieRuntimeText: String?
    @State private var arabicTitleText: String?
    @State private var posterArtwork: MPMediaItemArtwork?

    private var subtitleMetaText: String {
        if item.type == .tv {
            let s = item.season ?? 1
            let e = item.episode ?? 1
            if let epName = item.episodeName, !epName.isEmpty {
                return "S\(s):E\(e) · \(epName)"
            }
            return "S\(s):E\(e)"
        }
        return movieRuntimeText ?? ""
    }

    private var posterURLString: String {
        item.posterURL?.absoluteString ?? ""
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            VidlyDirectWebView(
                url: item.generatedURL,
                tmdbId: item.tmdbId,
                season: item.season ?? 1,
                episode: item.episode ?? 1,
                mediaTitle: item.title,
                arabicTitle: arabicTitleText ?? item.title,
                isMovie: item.type == .movie,
                subtitleMeta: subtitleMetaText,
                posterURL: posterURLString,
                onWebViewCreated: { webView in
                    webViewRef = webView
                },
                onLoadingChanged: { loading in
                    isLoading = loading
                },
                onProgress: { currentTime, duration in
                    persistProgress(currentTime: currentTime, duration: duration)
                },
                onBackRequested: {
                    HapticManager.shared.lightImpact()
                    dismiss()
                }
            )
            .ignoresSafeArea()

            if isLoading {
                ProgressView()
                    .progressViewStyle(.circular)
                    .tint(.white)
                    .scaleEffect(1.25)
                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                    .allowsHitTesting(false)
            }
        }
        .statusBarHidden()
        .persistentSystemOverlays(.hidden)
        .toolbar(.hidden, for: .navigationBar)
        .preferredColorScheme(.dark)
        .task {
            await loadMetadataAndPoster()
        }
        .onAppear {
            Self.configureAudioSession()
            NFOrientation.enterPlayback()
            app.history.add(item)
            publishNowPlaying(elapsed: nil, duration: nil)
        }
        .onDisappear {
            webViewRef?.pauseAllMediaPlayback(completionHandler: nil)
            MPNowPlayingInfoCenter.default().nowPlayingInfo = nil
            try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
            NFOrientation.exitPlayback()
        }
        .onChange(of: scenePhase) { _, phase in
            if phase == .background {
                webViewRef?.pauseAllMediaPlayback(completionHandler: nil)
            }
        }
    }

    private func loadMetadataAndPoster() async {
        async let runtimeTask: Void = loadMovieRuntimeAndArabicTitleIfNeeded()
        async let posterTask: Void = loadPosterArtworkIfNeeded()
        _ = await (runtimeTask, posterTask)
        publishNowPlaying(elapsed: nil, duration: nil)
    }

    private func loadMovieRuntimeAndArabicTitleIfNeeded() async {
        guard let tmdbInt = Int(item.tmdbId) else { return }
        if item.type == .movie, movieRuntimeText == nil {
            if let payload = try? await NFCatalogService.title(type: .movie, id: tmdbInt),
               let formatted = NF.runtimeText(minutes: payload.runtime) {
                movieRuntimeText = formatted
            }
        }
        let credential = TMDBConfig.credential
        guard NightFlixUserConfiguration.isValidTMDBReadAccessToken(credential) else { return }
        let kind = item.type == .movie ? "movie" : "tv"
        guard let url = URL(string: "https://api.themoviedb.org/3/\(kind)/\(tmdbInt)?language=ar") else { return }
        var req = URLRequest(url: url)
        req.setValue("Bearer \(credential)", forHTTPHeaderField: "Authorization")
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        if let (data, _) = try? await URLSession.shared.data(for: req),
           let obj = try? JSONSerialization.jsonObject(with: data) as? [String: Any] {
            let arName = (obj["title"] as? String) ?? (obj["name"] as? String)
            if let arName, !arName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                arabicTitleText = arName
            }
        }
    }

    private func loadPosterArtworkIfNeeded() async {
        guard posterArtwork == nil, let url = item.posterURL else { return }
        if let (data, _) = try? await URLSession.shared.data(from: url),
           let image = UIImage(data: data) {
            posterArtwork = MPMediaItemArtwork(boundsSize: image.size) { _ in image }
        }
    }

    private func publishNowPlaying(elapsed: Double?, duration: Double?) {
        var info: [String: Any] = [
            MPMediaItemPropertyTitle: item.title,
            MPMediaItemPropertyArtist: "SingularityTV",
            MPMediaItemPropertyAlbumTitle: subtitleMetaText.isEmpty ? "SingularityTV" : subtitleMetaText,
            MPNowPlayingInfoPropertyPlaybackRate: 1.0
        ]
        if let elapsed, elapsed.isFinite {
            info[MPNowPlayingInfoPropertyElapsedPlaybackTime] = elapsed
        }
        if let duration, duration.isFinite, duration > 0 {
            info[MPMediaItemPropertyPlaybackDuration] = duration
        }
        if let posterArtwork {
            info[MPMediaItemPropertyArtwork] = posterArtwork
        }
        MPNowPlayingInfoCenter.default().nowPlayingInfo = info
    }

    private func persistProgress(currentTime: Double, duration: Double) {
        guard currentTime.isFinite, duration.isFinite, duration > 0 else { return }
        if item.type == .movie, movieRuntimeText == nil {
            movieRuntimeText = NF.compactDuration(seconds: duration)
        }
        publishNowPlaying(elapsed: currentTime, duration: duration)
        guard abs(currentTime - lastPersistedSeconds) >= 5 else { return }
        lastPersistedSeconds = currentTime
        continueWatchingManager?.recordProgress(
            type: item.type,
            tmdbId: item.tmdbId,
            title: item.title,
            posterPath: item.posterPath,
            season: item.season,
            episode: item.episode,
            episodeName: item.episodeName,
            positionSeconds: currentTime,
            durationSeconds: duration
        )
        let isWatched = duration > 0 && (currentTime / duration) >= 0.95
        SingularitySessionManager.shared.pushProgressAtomic(
            type: item.type,
            tmdbId: item.tmdbId,
            season: item.season,
            episode: item.episode,
            positionSeconds: currentTime,
            durationSeconds: duration,
            watched: isWatched
        )
    }

    private static func configureAudioSession() {
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback, mode: .moviePlayback)
        try? session.setActive(true)
    }
}

private struct VidlyDirectWebView: UIViewRepresentable {
    let url: URL
    let tmdbId: String
    let season: Int
    let episode: Int
    let mediaTitle: String
    let arabicTitle: String
    let isMovie: Bool
    let subtitleMeta: String
    let posterURL: String
    let onWebViewCreated: (WKWebView) -> Void
    let onLoadingChanged: (Bool) -> Void
    let onProgress: (Double, Double) -> Void
    let onBackRequested: () -> Void

    private static let progressHandlerName = "vidlyProgress"
    private static let backHandlerName = "vidlyBack"
    private static let arabicResolveHandlerName = "vidlyResolveArabic"

    func makeCoordinator() -> Coordinator {
        Coordinator(
            tmdbId: tmdbId,
            season: season,
            episode: episode,
            mediaTitle: mediaTitle,
            arabicTitle: arabicTitle,
            isMovie: isMovie,
            subtitleMeta: subtitleMeta,
            posterURL: posterURL,
            onLoadingChanged: onLoadingChanged,
            onProgress: onProgress,
            onBackRequested: onBackRequested
        )
    }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.websiteDataStore = .default()
        config.allowsInlineMediaPlayback = true
        config.allowsPictureInPictureMediaPlayback = false
        config.allowsAirPlayForMediaPlayback = true
        config.defaultWebpagePreferences.allowsContentJavaScript = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.preferences.javaScriptCanOpenWindowsAutomatically = false
        if #available(iOS 15.4, *) {
            config.preferences.isElementFullscreenEnabled = false
        }
        config.applicationNameForUserAgent = "Version/18.0 Mobile/15E148 Safari/604.1"

        let ucc = config.userContentController
        let handler = WeakVidlyMessageHandler(context.coordinator)
        ucc.add(handler, name: Self.progressHandlerName)
        ucc.add(handler, name: Self.backHandlerName)
        ucc.add(handler, name: Self.arabicResolveHandlerName)
        ucc.addUserScript(
            WKUserScript(
                source: Self.vidlyCleanupScript(
                    title: mediaTitle,
                    isMovie: isMovie,
                    subtitleMeta: subtitleMeta,
                    posterURL: posterURL
                ),
                injectionTime: .atDocumentStart,
                forMainFrameOnly: false
            )
        )
        ucc.addUserScript(
            WKUserScript(
                source: Self.vidlyProgressScript,
                injectionTime: .atDocumentStart,
                forMainFrameOnly: true
            )
        )

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.isOpaque = false
        webView.backgroundColor = .black
        webView.allowsBackForwardNavigationGestures = false
        webView.scrollView.backgroundColor = .black
        webView.scrollView.bounces = false
        webView.scrollView.isScrollEnabled = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never

        context.coordinator.mainWebView = webView
        onWebViewCreated(webView)
        context.coordinator.load(url, in: webView)
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        context.coordinator.onLoadingChanged = onLoadingChanged
        context.coordinator.onProgress = onProgress
        context.coordinator.onBackRequested = onBackRequested
        context.coordinator.arabicTitle = arabicTitle
        context.coordinator.updateMetadata(
            title: mediaTitle,
            isMovie: isMovie,
            subtitleMeta: subtitleMeta,
            posterURL: posterURL,
            in: webView
        )
        context.coordinator.load(url, in: webView)
    }

    static func dismantleUIView(_ webView: WKWebView, coordinator: Coordinator) {
        coordinator.cancelResolver()
        webView.stopLoading()
        webView.pauseAllMediaPlayback(completionHandler: nil)
        webView.navigationDelegate = nil
        webView.uiDelegate = nil
        webView.configuration.userContentController.removeAllUserScripts()
        webView.configuration.userContentController.removeScriptMessageHandler(forName: progressHandlerName)
        webView.configuration.userContentController.removeScriptMessageHandler(forName: backHandlerName)
        webView.configuration.userContentController.removeScriptMessageHandler(forName: arabicResolveHandlerName)
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
        let tmdbId: String
        let season: Int
        let episode: Int
        var mediaTitle: String
        var arabicTitle: String
        var isMovie: Bool
        var subtitleMeta: String
        var posterURL: String
        var onLoadingChanged: (Bool) -> Void
        var onProgress: (Double, Double) -> Void
        var onBackRequested: () -> Void
        weak var mainWebView: WKWebView?
        private var loadedURL: URL?
        private var resolver: ArabicStreamResolver?

        init(
            tmdbId: String,
            season: Int,
            episode: Int,
            mediaTitle: String,
            arabicTitle: String,
            isMovie: Bool,
            subtitleMeta: String,
            posterURL: String,
            onLoadingChanged: @escaping (Bool) -> Void,
            onProgress: @escaping (Double, Double) -> Void,
            onBackRequested: @escaping () -> Void
        ) {
            self.tmdbId = tmdbId
            self.season = season
            self.episode = episode
            self.mediaTitle = mediaTitle
            self.arabicTitle = arabicTitle
            self.isMovie = isMovie
            self.subtitleMeta = subtitleMeta
            self.posterURL = posterURL
            self.onLoadingChanged = onLoadingChanged
            self.onProgress = onProgress
            self.onBackRequested = onBackRequested
        }

        func cancelResolver() {
            resolver?.cancel()
            resolver = nil
        }

        func load(_ url: URL, in webView: WKWebView) {
            guard loadedURL != url else { return }
            loadedURL = url
            onLoadingChanged(true)
            webView.load(URLRequest(url: url))
        }

        func updateMetadata(title: String, isMovie: Bool, subtitleMeta: String, posterURL: String, in webView: WKWebView) {
            guard self.subtitleMeta != subtitleMeta || self.mediaTitle != title || self.posterURL != posterURL else { return }
            self.mediaTitle = title
            self.isMovie = isMovie
            self.subtitleMeta = subtitleMeta
            self.posterURL = posterURL
            let js = "window.__singularityMeta = { title: '\(Self.jsEscape(title))', isMovie: \(isMovie ? "true" : "false"), subtitle: '\(Self.jsEscape(subtitleMeta))', poster: '\(Self.jsEscape(posterURL))' }; if (typeof window.__singularitySyncHeader === 'function') { window.__singularitySyncHeader(); } if (typeof window.__singularitySyncMediaSession === 'function') { window.__singularitySyncMediaSession(); }"
            webView.evaluateJavaScript(js, completionHandler: nil)
        }

        private func resolveArabicServer(_ serverName: String) {
            cancelResolver()
            let resolver = ArabicStreamResolver(
                serverName: serverName,
                tmdbId: tmdbId,
                arabicTitle: arabicTitle,
                englishTitle: mediaTitle,
                isMovie: isMovie,
                season: season,
                episode: episode
            ) { [weak self] streamURL in
                guard let self, let webView = self.mainWebView else { return }
                let escapedServer = Self.jsEscape(serverName)
                if let streamURL {
                    let escapedURL = Self.jsEscape(streamURL)
                    let js = "if (typeof window.__singularityApplyResolvedStream === 'function') { window.__singularityApplyResolvedStream('\(escapedServer)', '\(escapedURL)'); }"
                    webView.evaluateJavaScript(js, completionHandler: nil)
                } else {
                    let js = "if (typeof window.__singularityOnResolveFailed === 'function') { window.__singularityOnResolveFailed('\(escapedServer)'); }"
                    webView.evaluateJavaScript(js, completionHandler: nil)
                }
            }
            self.resolver = resolver
            resolver.start()
        }

        private static func jsEscape(_ str: String) -> String {
            str
                .replacingOccurrences(of: "\\", with: "\\\\")
                .replacingOccurrences(of: "'", with: "\\'")
                .replacingOccurrences(of: "\n", with: " ")
                .replacingOccurrences(of: "\r", with: " ")
        }

        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            if navigationAction.targetFrame?.isMainFrame == true,
               navigationAction.navigationType == .linkActivated,
               let host = navigationAction.request.url?.host?.lowercased(),
               !host.contains("vidly") {
                decisionHandler(.cancel)
                return
            }
            decisionHandler(.allow)
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            onLoadingChanged(false)
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            onLoadingChanged(false)
        }

        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            onLoadingChanged(false)
        }

        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            nil
        }

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            if message.name == VidlyDirectWebView.backHandlerName {
                DispatchQueue.main.async {
                    self.onBackRequested()
                }
                return
            }
            if message.name == VidlyDirectWebView.arabicResolveHandlerName,
               let serverName = message.body as? String {
                DispatchQueue.main.async {
                    self.resolveArabicServer(serverName)
                }
                return
            }
            guard message.name == VidlyDirectWebView.progressHandlerName,
                  let dict = message.body as? [String: Any],
                  let currentTime = dict["currentTime"] as? Double,
                  let duration = dict["duration"] as? Double else { return }
            onProgress(currentTime, duration)
        }
    }

    private static func vidlyCleanupScript(title: String, isMovie: Bool, subtitleMeta: String, posterURL: String) -> String {
        let escapedTitle = title
            .replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "'", with: "\\'")
            .replacingOccurrences(of: "\n", with: " ")
            .replacingOccurrences(of: "\r", with: " ")
        let escapedSub = subtitleMeta
            .replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "'", with: "\\'")
            .replacingOccurrences(of: "\n", with: " ")
            .replacingOccurrences(of: "\r", with: " ")
        let escapedPoster = posterURL
            .replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "'", with: "\\'")
            .replacingOccurrences(of: "\n", with: " ")
            .replacingOccurrences(of: "\r", with: " ")

        return """
        (function () {
            window.__singularityMeta = {
                title: '\(escapedTitle)',
                isMovie: \(isMovie ? "true" : "false"),
                subtitle: '\(escapedSub)',
                poster: '\(escapedPoster)'
            };

            var ARABIC_SERVERS = ['Anafast', 'Vidspeed', 'Vidoba'];
            window.__sgActiveArabicServer = null;
            window.__sgArabicAutoTried = {};

            var noop = function () { return Promise.resolve(); };
            try {
                Element.prototype.requestFullscreen = noop;
                Element.prototype.webkitRequestFullscreen = noop;
                Element.prototype.webkitRequestFullScreen = noop;
                HTMLVideoElement.prototype.webkitEnterFullscreen = function () {};
                HTMLVideoElement.prototype.webkitEnterFullScreen = function () {};
                Document.prototype.exitFullscreen = noop;
                Document.prototype.webkitExitFullscreen = noop;
                Object.defineProperty(document, 'fullscreenEnabled', { get: function () { return false; } });
                Object.defineProperty(document, 'webkitFullscreenEnabled', { get: function () { return false; } });
            } catch (e) {}

            var cssText = [
                '*, *::before, *::after { -webkit-user-select: none !important; user-select: none !important; -webkit-touch-callout: none !important; -webkit-tap-highlight-color: transparent !important; }',
                'html, body { background: #000000 !important; font-family: -apple-system, BlinkMacSystemFont, "SF Pro Display", sans-serif !important; overflow: hidden !important; }',
                '[aria-label*="fullscreen" i], [aria-label*="full screen" i], [title*="fullscreen" i], [title*="full screen" i], [data-testid*="fullscreen" i], [data-plyr="fullscreen"], .vjs-fullscreen-control, .plyr__control--fullscreen { display: none !important; opacity: 0 !important; visibility: hidden !important; pointer-events: none !important; width: 0 !important; height: 0 !important; }',
                'a[href*="vidly" i], img[src*="vidly" i], img[alt*="vidly" i], [aria-label*="vidly" i], [title*="vidly" i], [class*="watermark" i]:not(#__sgWatermark), [class*="brand-logo" i], [class*="player-logo" i] { display: none !important; opacity: 0 !important; visibility: hidden !important; pointer-events: none !important; width: 0 !important; height: 0 !important; }',
                '[role="dialog"] { max-height: calc(100vh - 28px) !important; overflow-y: auto !important; -webkit-overflow-scrolling: touch !important; border-radius: 16px !important; box-shadow: 0 24px 60px rgba(0, 0, 0, 0.85) !important; }',
                'input[type="range"] { accent-color: #E50914 !important; }'
            ].join('\\n');

            function injectCSSImmediate() {
                if (document.getElementById('singularity-vidly-cleanup-css')) return;
                var target = document.head || document.documentElement;
                if (!target) return;
                var style = document.createElement('style');
                style.id = 'singularity-vidly-cleanup-css';
                style.textContent = cssText;
                target.appendChild(style);
            }
            injectCSSImmediate();

            var _hlsVal = window.Hls;
            if (!_hlsVal) {
                try {
                    Object.defineProperty(window, 'Hls', {
                        configurable: true,
                        enumerable: true,
                        get: function () { return _hlsVal; },
                        set: function (HlsCtor) {
                            _hlsVal = HlsCtor;
                            if (HlsCtor && HlsCtor.prototype && !HlsCtor.prototype.__sgHooked) {
                                HlsCtor.prototype.__sgHooked = true;
                                var origAttach = HlsCtor.prototype.attachMedia;
                                if (typeof origAttach === 'function') {
                                    HlsCtor.prototype.attachMedia = function () {
                                        window.__sgHlsInstance = this;
                                        return origAttach.apply(this, arguments);
                                    };
                                }
                            }
                        }
                    });
                } catch (e) {}
            }

            function lockTitleAndFavicon() {
                try {
                    if (document.title !== 'SingularityTV') {
                        document.title = 'SingularityTV';
                    }
                    if (!window.__sgTitleLocked) {
                        window.__sgTitleLocked = true;
                        Object.defineProperty(document, 'title', {
                            configurable: true,
                            get: function () { return 'SingularityTV'; },
                            set: function () {}
                        });
                    }
                } catch (e) {}

                var poster = (window.__singularityMeta && window.__singularityMeta.poster) || '';
                if (poster && window.__sgLastFavicon !== poster) {
                    window.__sgLastFavicon = poster;
                    var icons = document.querySelectorAll('link[rel*="icon" i], link[rel*="apple-touch-icon" i]');
                    for (var i = 0; i < icons.length; i++) {
                        if (icons[i].href !== poster) icons[i].href = poster;
                    }
                    if (icons.length === 0 && document.head) {
                        var lnk = document.createElement('link');
                        lnk.rel = 'apple-touch-icon';
                        lnk.href = poster;
                        document.head.appendChild(lnk);
                    }
                }
            }

            function syncMediaSession() {
                try {
                    if (!('mediaSession' in navigator) || typeof MediaMetadata === 'undefined') return;
                    var meta = window.__singularityMeta || {};
                    var key = (meta.title || '') + '|' + (meta.subtitle || '') + '|' + (meta.poster || '');
                    if (window.__sgLastMediaKey === key) return;
                    window.__sgLastMediaKey = key;
                    var art = meta.poster ? [{ src: meta.poster, sizes: '512x512', type: 'image/jpeg' }] : [];
                    navigator.mediaSession.metadata = new MediaMetadata({
                        title: meta.title || 'SingularityTV',
                        artist: 'SingularityTV',
                        album: meta.subtitle || 'SingularityTV',
                        artwork: art
                    });
                } catch (e) {}
            }
            window.__singularitySyncMediaSession = syncMediaSession;

            lockTitleAndFavicon();
            syncMediaSession();

            function hideEl(el) {
                if (!el || el.dataset.sgHidden === '1' || el.tagName === 'VIDEO' || el.tagName === 'BODY' || el.tagName === 'HTML') return;
                if (el.id === '__sgTopBackBtn' || el.id === '__sgMovieSub' || el.id === '__sgWatermark' || el.id === '__sgSwitchToast') return;
                el.dataset.sgHidden = '1';
                el.style.setProperty('display', 'none', 'important');
                el.style.setProperty('opacity', '0', 'important');
                el.style.setProperty('visibility', 'hidden', 'important');
                el.style.setProperty('pointer-events', 'none', 'important');
            }

            function isMaximizeSvg(el) {
                var svg = el.tagName === 'SVG' ? el : (el.querySelector ? el.querySelector('svg') : null);
                if (!svg) return false;
                var html = (svg.innerHTML || '').toLowerCase();
                return html.indexOf('m15 3h6v6') !== -1 ||
                       html.indexOf('m8 3h5') !== -1 ||
                       html.indexOf('m3 8v5') !== -1 ||
                       html.indexOf('15 3 21 3 21 9') !== -1 ||
                       html.indexOf('9 21 3 21 3 15') !== -1 ||
                       html.indexOf('fullscreen') !== -1;
            }

            function effOp(el) {
                var op = 1, cur = el;
                while (cur && cur.nodeType === 1) {
                    var cs = getComputedStyle(cur);
                    if (cs.display === 'none' || cs.visibility === 'hidden') return 0;
                    op *= parseFloat(cs.opacity);
                    if (op <= 0.02) return 0;
                    cur = cur.parentElement;
                }
                return op;
            }

            function hasFullScreenDrawer() {
                var vw = window.innerWidth || 0;
                var vh = window.innerHeight || 0;
                var dialogs = document.querySelectorAll('[role="dialog"], [class*="drawer" i]');
                for (var i = 0; i < dialogs.length; i++) {
                    var d = dialogs[i];
                    var r = d.getBoundingClientRect ? d.getBoundingClientRect() : null;
                    if (r && r.width > vw * 0.72 && r.height > vh * 0.72 && effOp(d) > 0.1) {
                        return true;
                    }
                }
                return false;
            }

            function showSwitchToast(text) {
                if (!document.body) return;
                var toast = document.getElementById('__sgSwitchToast');
                if (!toast) {
                    toast = document.createElement('div');
                    toast.id = '__sgSwitchToast';
                    toast.style.cssText = 'position:fixed;left:50%;bottom:84px;transform:translateX(-50%);z-index:2147483645;display:inline-flex;align-items:center;gap:8px;padding:10px 18px;border-radius:999px;background:rgba(16,17,24,0.92);border:1px solid rgba(255,255,255,0.14);color:#FFFFFF;font-size:13px;font-weight:500;backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);pointer-events:none;transition:opacity 180ms ease;';
                    document.body.appendChild(toast);
                }
                toast.textContent = text;
                toast.style.opacity = '1';
            }

            function hideSwitchToast() {
                var toast = document.getElementById('__sgSwitchToast');
                if (toast) toast.style.opacity = '0';
            }

            function requestArabicServer(name) {
                window.__sgActiveArabicServer = name;
                showSwitchToast('Switching to ' + name + '...');
                updateInjectedServerStates();
                try {
                    window.webkit.messageHandlers.\(Self.arabicResolveHandlerName).postMessage(name);
                } catch (e) {}
            }

            function hideVidlyErrorOverlays() {
                var nodes = document.querySelectorAll('div, p, span, section');
                for (var i = 0; i < nodes.length; i++) {
                    var el = nodes[i];
                    if (el.id === '__sgTopBackBtn' || el.id === '__sgWatermark' || el.id === '__sgSwitchToast') continue;
                    var t = (el.innerText || '').toLowerCase();
                    if ((t.indexOf('stream unavailable') !== -1 || t.indexOf('no sources') !== -1 || t.indexOf('media not found') !== -1) && el.children.length <= 4) {
                        el.style.setProperty('display', 'none', 'important');
                    }
                }
            }

            function playNative(v, url) {
                try {
                    if (window.__sgHlsInstance && typeof window.__sgHlsInstance.destroy === 'function') {
                        window.__sgHlsInstance.destroy();
                        window.__sgHlsInstance = null;
                    }
                } catch (e) {}
                v.playsInline = true;
                v.setAttribute('playsinline', '');
                v.preload = 'auto';
                v.src = url;
                v.load();
                v.play().catch(function () {});
            }

            window.__singularityApplyResolvedStream = function (serverName, streamUrl) {
                hideSwitchToast();
                hideVidlyErrorOverlays();
                window.__sgActiveArabicServer = serverName;
                updateInjectedServerStates();
                var v = document.querySelector('video');
                if (!v) return;
                v.style.setProperty('display', 'block', 'important');
                v.style.setProperty('opacity', '1', 'important');
                v.style.setProperty('visibility', 'visible', 'important');
                var isHls = streamUrl.indexOf('.m3u8') !== -1;
                if (isHls && window.__sgHlsInstance && typeof window.__sgHlsInstance.loadSource === 'function') {
                    try {
                        window.__sgHlsInstance.loadSource(streamUrl);
                        if (typeof window.__sgHlsInstance.attachMedia === 'function') {
                            window.__sgHlsInstance.attachMedia(v);
                        }
                        v.play().catch(function () { playNative(v, streamUrl); });
                        return;
                    } catch (e) {}
                }
                if (isHls && window.Hls && typeof window.Hls.isSupported === 'function' && window.Hls.isSupported()) {
                    try {
                        var hls = new window.Hls({ enableWorker: true, lowLatencyMode: false, maxBufferLength: 30 });
                        hls.on(window.Hls.Events.ERROR, function (_, data) {
                            if (data && data.fatal) {
                                playNative(v, streamUrl);
                            }
                        });
                        hls.loadSource(streamUrl);
                        hls.attachMedia(v);
                        window.__sgHlsInstance = hls;
                        v.play().catch(function () {});
                        return;
                    } catch (e) {}
                }
                playNative(v, streamUrl);
            };

            window.__singularityOnResolveFailed = function (failedServer) {
                var idx = ARABIC_SERVERS.indexOf(failedServer);
                for (var i = idx + 1; i < ARABIC_SERVERS.length; i++) {
                    var next = ARABIC_SERVERS[i];
                    if (!window.__sgArabicAutoTried[next]) {
                        window.__sgArabicAutoTried[next] = true;
                        requestArabicServer(next);
                        return;
                    }
                }
                hideSwitchToast();
                window.__sgActiveArabicServer = null;
                updateInjectedServerStates();
            };

            function updateInjectedServerStates() {
                var rows = document.querySelectorAll('[data-sg-arabic-server]');
                for (var i = 0; i < rows.length; i++) {
                    var r = rows[i];
                    var name = r.getAttribute('data-sg-arabic-server');
                    var isSel = window.__sgActiveArabicServer === name;
                    var chk = r.querySelector('[data-sg-chk="1"]');
                    if (chk) chk.style.opacity = isSel ? '1' : '0';
                    r.style.color = isSel ? '#FFFFFF' : 'rgba(255,255,255,0.88)';
                    r.style.fontWeight = isSel ? '600' : '500';
                }
            }

            function injectArabicServersIntoVidlyList() {
                if (window !== window.top) return;
                var btns = document.querySelectorAll('button, [role="button"]');
                var citadelBtn = null;
                for (var b = 0; b < btns.length; b++) {
                    var bt = (btns[b].innerText || btns[b].textContent || '').trim().toLowerCase();
                    if (bt === 'citadel' || bt === 'comet' || bt === 'nimbus' || bt === 'flux' || bt === 'prism' || bt === 'edge') {
                        if (effOp(btns[b]) > 0.1) {
                            citadelBtn = btns[b];
                            if (bt === 'citadel') break;
                        }
                    }
                }
                if (!citadelBtn || !citadelBtn.parentElement) return;
                var listParent = citadelBtn.parentElement;
                if (listParent.querySelector('[data-sg-arabic-server]')) {
                    updateInjectedServerStates();
                    return;
                }

                var cs = getComputedStyle(citadelBtn);
                for (var s = 0; s < ARABIC_SERVERS.length; s++) {
                    (function (name) {
                        var row = document.createElement('button');
                        row.type = 'button';
                        row.className = citadelBtn.className || '';
                        row.setAttribute('data-sg-arabic-server', name);
                        row.style.fontFamily = cs.fontFamily;
                        row.style.fontSize = cs.fontSize;
                        row.style.padding = cs.padding;
                        row.style.display = 'flex';
                        row.style.alignItems = 'center';
                        row.style.gap = '8px';
                        row.style.width = '100%';
                        row.style.textAlign = 'left';
                        row.style.background = 'transparent';
                        row.style.border = 'none';
                        row.style.cursor = 'pointer';

                        var chk = document.createElement('span');
                        chk.setAttribute('data-sg-chk', '1');
                        chk.textContent = '✓';
                        chk.style.cssText = 'color:#E50914;font-size:13px;font-weight:700;opacity:0;width:14px;display:inline-block;flex-shrink:0;';

                        var lbl = document.createElement('span');
                        lbl.textContent = name;

                        row.appendChild(chk);
                        row.appendChild(lbl);
                        row.addEventListener('click', function (ev) {
                            ev.stopPropagation();
                            ev.preventDefault();
                            window.__sgArabicAutoTried = {};
                            window.__sgArabicAutoTried[name] = true;
                            requestArabicServer(name);
                        }, true);
                        listParent.appendChild(row);
                    })(ARABIC_SERVERS[s]);
                }
                updateInjectedServerStates();
            }

            function checkAutoFailoverToArabic() {
                if (window !== window.top || !document.body) return;
                if (window.__sgActiveArabicServer) return;
                var bodyTxt = (document.body.innerText || '').toLowerCase();
                var isErr = bodyTxt.indexOf('stream unavailable') !== -1 || bodyTxt.indexOf('no sources') !== -1 || bodyTxt.indexOf('media not found') !== -1;
                if (isErr && !window.__sgArabicAutoTried['Anafast']) {
                    window.__sgArabicAutoTried['Anafast'] = true;
                    requestArabicServer('Anafast');
                }
            }

            function ensureWatermark() {
                if (window !== window.top) return;
                var root = document.body || document.documentElement;
                if (!root) return;
                var wm = document.getElementById('__sgWatermark');
                if (!wm) {
                    wm = document.createElement('div');
                    wm.id = '__sgWatermark';
                    wm.style.cssText = 'position:fixed;top:18px;right:18px;z-index:2147483644;pointer-events:none;user-select:none;opacity:0;transition:opacity 140ms ease;filter:drop-shadow(0 1px 4px rgba(0,0,0,0.7));display:inline-flex;align-items:center;justify-content:center;';
                    wm.innerHTML = '<svg width="20" height="20" viewBox="0 0 64 64" fill="none"><path d="M46 13H25C19 13 14.5 17 14.5 22.5C14.5 28 19 31.5 25 31.5H39C44.5 31.5 49 35 49 40.5C49 46.5 44.5 51 38.5 51H16.5" stroke="#FFFFFF" stroke-width="7.5" stroke-linecap="round" stroke-linejoin="round"/></svg>';
                    root.appendChild(wm);
                }
                if (hasFullScreenDrawer()) {
                    wm.style.opacity = '0';
                    return;
                }
                var topBtns = document.querySelectorAll('button, [role="button"]');
                var alignedTop = null;
                var alignedOp = 0;
                for (var i = 0; i < topBtns.length; i++) {
                    var b = topBtns[i];
                    if (b.id === '__sgTopBackBtn') continue;
                    var r = b.getBoundingClientRect ? b.getBoundingClientRect() : null;
                    if (r && r.top >= 4 && r.top < 76 && r.right > (window.innerWidth || 0) * 0.5 && r.height > 12) {
                        var op = effOp(b);
                        if (op > 0.15) {
                            alignedTop = Math.round(r.top + (r.height - 20) / 2);
                            alignedOp = op;
                            break;
                        }
                    }
                }
                if (alignedTop !== null) {
                    wm.style.top = alignedTop + 'px';
                    wm.style.right = '18px';
                    wm.style.opacity = String(Math.min(0.68, alignedOp));
                } else {
                    wm.style.opacity = '0';
                }
            }

            function fmtRuntime(sec) {
                var meta = window.__singularityMeta || {};
                if (meta.subtitle && meta.subtitle.length > 0) return meta.subtitle;
                if (!isFinite(sec) || sec < 60) return '';
                var m = Math.round(sec / 60);
                var h = Math.floor(m / 60), rm = m % 60;
                return h > 0 ? (rm > 0 ? (h + 'h ' + rm + 'm') : (h + 'h')) : (rm + 'm');
            }

            function ensureTopBack() {
                if (window !== window.top || !document.body) return;
                var bk = document.getElementById('__sgTopBackBtn');
                if (!bk) {
                    bk = document.createElement('button');
                    bk.id = '__sgTopBackBtn';
                    bk.type = 'button';
                    bk.setAttribute('aria-label', 'Back');
                    bk.style.cssText = 'position:fixed;z-index:2147483645;display:inline-flex;align-items:center;justify-content:center;width:36px;height:36px;background:transparent;border:none;color:#FFFFFF;cursor:pointer;padding:0;margin:0;opacity:0;pointer-events:none;transition:opacity 120ms ease;';
                    bk.innerHTML = '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5"></path><path d="M12 19l-7-7 7-7"></path></svg>';
                    bk.addEventListener('pointerdown', function (e) { e.stopPropagation(); }, true);
                    bk.addEventListener('click', function (ev) {
                        ev.stopPropagation();
                        ev.preventDefault();
                        try {
                            window.webkit.messageHandlers.\(Self.backHandlerName).postMessage(true);
                        } catch (e) {}
                    }, true);
                    document.body.appendChild(bk);
                }

                if (hasFullScreenDrawer()) {
                    bk.style.opacity = '0';
                    bk.style.pointerEvents = 'none';
                    return;
                }

                var titleEl = null, titleOp = 0;
                var tCands = document.querySelectorAll('h1,h2,h3,div,span,p');
                for (var j = 0; j < tCands.length; j++) {
                    var el = tCands[j];
                    if (el.id === '__sgTopBackBtn' || el.id === '__sgMovieSub' || el.id === '__sgWatermark' || el.closest('button')) continue;
                    if (el.closest('[role="dialog"], [role="menu"], [class*="drawer" i]')) continue;
                    if (el.children.length > 0) continue;
                    var ttx = (el.textContent || '').trim();
                    if (ttx.length < 2 || ttx.length > 85) continue;
                    var low = ttx.toLowerCase();
                    if (low === 'episodes' || low.indexOf('quality') !== -1 || low.indexOf('server') !== -1 || low.indexOf('audio') !== -1 || low.indexOf('subtitle') !== -1) continue;
                    var tr = el.getBoundingClientRect();
                    if (tr.width > 10 && tr.top >= 2 && tr.top < 105 && tr.left >= 4 && tr.left < 400 && tr.height >= 14 && tr.height < 60) {
                        var op = effOp(el);
                        if (op > 0.15) {
                            titleEl = el;
                            titleOp = op;
                            break;
                        }
                    }
                }

                if (titleEl && titleOp > 0.15) {
                    var titleBox = titleEl.parentElement;
                    var isTvUrl = (location.pathname || '').toLowerCase().indexOf('/tv/') !== -1 || !(window.__singularityMeta && window.__singularityMeta.isMovie);
                    var subEl = document.getElementById('__sgMovieSub');
                    var existingSub = null;
                    if (titleBox) {
                        var sibs = titleBox.children;
                        for (var si = 0; si < sibs.length; si++) {
                            var sb = sibs[si];
                            if (sb === titleEl || sb.id === '__sgMovieSub') continue;
                            var st = (sb.textContent || '').trim();
                            if (st.length > 1 && sb.getBoundingClientRect().top >= titleEl.getBoundingClientRect().top + 8) {
                                existingSub = sb;
                                break;
                            }
                        }
                    }

                    if (!existingSub && titleBox) {
                        var v = document.querySelector('video');
                        var subTxt = fmtRuntime(v ? v.duration : 0);
                        if (subTxt.length > 0) {
                            if (!subEl) {
                                subEl = document.createElement('div');
                                subEl.id = '__sgMovieSub';
                                subEl.style.cssText = 'font-family:-apple-system,BlinkMacSystemFont,sans-serif;font-size:12.5px;font-weight:500;color:rgba(255,255,255,0.68);margin-top:2px;line-height:1.25;white-space:nowrap;pointer-events:none;';
                            }
                            if (subEl.textContent !== subTxt) subEl.textContent = subTxt;
                            if (subEl.parentElement !== titleBox) {
                                var pcs = getComputedStyle(titleBox);
                                if (pcs.display === 'flex' && pcs.flexDirection !== 'column') {
                                    titleBox.style.setProperty('flex-direction', 'column', 'important');
                                    titleBox.style.setProperty('align-items', 'flex-start', 'important');
                                }
                                titleBox.appendChild(subEl);
                            }
                            existingSub = subEl;
                        }
                    } else if (isTvUrl && existingSub && subEl) {
                        subEl.remove();
                    }

                    var shiftTarget = titleBox || titleEl;
                    if (!shiftTarget.dataset.sgBackShifted && titleEl.getBoundingClientRect().left < 56) {
                        shiftTarget.dataset.sgBackShifted = '1';
                        shiftTarget.style.setProperty('padding-left', '40px', 'important');
                    }

                    var tr2 = titleEl.getBoundingClientRect();
                    var sr2 = existingSub ? existingSub.getBoundingClientRect() : tr2;
                    var midY = (tr2.top + Math.max(tr2.bottom, sr2.bottom)) / 2;
                    var bx = Math.max(10, Math.round(tr2.left - 42));
                    var by = Math.max(4, Math.round(midY - 18));
                    bk.style.left = bx + 'px';
                    bk.style.top = by + 'px';
                    bk.style.opacity = String(titleOp);
                    bk.style.pointerEvents = 'auto';
                } else {
                    bk.style.left = '16px';
                    bk.style.top = '14px';
                    var bodyTxt = (document.body.innerText || '').toLowerCase();
                    var isErr = bodyTxt.indexOf('stream unavailable') !== -1 || bodyTxt.indexOf('try again') !== -1 || bodyTxt.indexOf('no sources') !== -1;
                    bk.style.opacity = isErr ? '1' : '0';
                    bk.style.pointerEvents = isErr ? 'auto' : 'none';
                }

                var topBtns = document.querySelectorAll('button, [role="button"]');
                for (var tb = 0; tb < topBtns.length; tb++) {
                    var btn = topBtns[tb];
                    if (btn.id === '__sgTopBackBtn') continue;
                    var br = btn.getBoundingClientRect ? btn.getBoundingClientRect() : null;
                    if (br && br.top >= 0 && br.top < 70 && br.right > (window.innerWidth || 0) - 52) {
                        if (btn.parentElement && !btn.parentElement.dataset.sgRightShifted && !btn.closest('[role="dialog"], [role="menu"]')) {
                            btn.parentElement.dataset.sgRightShifted = '1';
                            btn.parentElement.style.setProperty('padding-right', '40px', 'important');
                        }
                    }
                }
            }

            window.__singularitySyncHeader = ensureTopBack;

            function cleanQuickNodes() {
                injectCSSImmediate();
                lockTitleAndFavicon();
                syncMediaSession();

                var vw = window.innerWidth || document.documentElement.clientWidth || 0;
                var candidates = document.querySelectorAll('button, [role="button"], a, img, svg, div');
                for (var i = 0; i < candidates.length; i++) {
                    var el = candidates[i];
                    if (!el || el.dataset.sgHidden === '1' || el.tagName === 'VIDEO' || el.id === '__sgTopBackBtn' || el.id === '__sgMovieSub' || el.id === '__sgWatermark' || el.id === '__sgSwitchToast') continue;

                    var aria = (el.getAttribute('aria-label') || '').toLowerCase();
                    var title = (el.getAttribute('title') || '').toLowerCase();
                    var cls = (typeof el.className === 'string' ? el.className : '').toLowerCase();
                    var id = (el.id || '').toLowerCase();
                    var testId = (el.getAttribute('data-testid') || '').toLowerCase();
                    var href = (el.getAttribute('href') || '').toLowerCase();
                    var src = (el.getAttribute('src') || '').toLowerCase();
                    var alt = (el.getAttribute('alt') || '').toLowerCase();

                    if (aria.indexOf('fullscreen') !== -1 || aria.indexOf('full screen') !== -1 ||
                        title.indexOf('fullscreen') !== -1 || title.indexOf('full screen') !== -1 ||
                        testId.indexOf('fullscreen') !== -1 || id.indexOf('fullscreen') !== -1 ||
                        (el.tagName === 'BUTTON' && (cls.indexOf('fullscreen') !== -1 || isMaximizeSvg(el)))) {
                        hideEl(el);
                        continue;
                    }

                    if (href.indexOf('vidly') !== -1 || src.indexOf('vidly') !== -1 || alt.indexOf('vidly') !== -1 ||
                        aria.indexOf('vidly') !== -1 || title.indexOf('vidly') !== -1 ||
                        cls.indexOf('vidly') !== -1 || id.indexOf('vidly') !== -1) {
                        if (el.tagName === 'A' || el.tagName === 'IMG' || el.tagName === 'SVG' || el.children.length <= 2) {
                            hideEl(el);
                            continue;
                        }
                    }

                    if (vw > 0 && (el.tagName === 'A' || el.tagName === 'IMG' || el.tagName === 'SVG' || el.tagName === 'DIV')) {
                        var rect = el.getBoundingClientRect ? el.getBoundingClientRect() : null;
                        if (rect && rect.top >= 2 && rect.top <= 76 && rect.right >= vw - 80 && rect.width >= 12 && rect.width <= 64 && rect.height >= 12 && rect.height <= 64) {
                            var txt = (el.innerText || el.textContent || '').trim();
                            var isModal = !!el.closest('[role="dialog"], [role="menu"], [class*="drawer" i]');
                            var isControl = el.tagName === 'BUTTON' ||
                                el.getAttribute('role') === 'button' ||
                                el.hasAttribute('tabindex') ||
                                !!el.closest('button, [role="button"]');
                            if (!isModal && !isControl && !txt) {
                                hideEl(el);
                            }
                        }
                    }
                }
            }

            function syncUI() {
                injectArabicServersIntoVidlyList();
                checkAutoFailoverToArabic();
                ensureWatermark();
                ensureTopBack();
            }

            var lastCleanAt = 0;
            var scheduledClean = false;
            function scheduleClean() {
                if (scheduledClean) return;
                scheduledClean = true;
                var now = Date.now();
                var delay = Math.max(0, 200 - (now - lastCleanAt));
                setTimeout(function () {
                    scheduledClean = false;
                    lastCleanAt = Date.now();
                    cleanQuickNodes();
                    syncUI();
                }, delay);
            }

            cleanQuickNodes();
            syncUI();
            if (document.readyState === 'loading') {
                document.addEventListener('DOMContentLoaded', function () {
                    cleanQuickNodes();
                    syncUI();
                });
            }

            var obs = new MutationObserver(function () { scheduleClean(); });
            try {
                obs.observe(document.documentElement || document, { childList: true, subtree: true });
            } catch (e) {}

            document.addEventListener('pointerup', function () {
                setTimeout(syncUI, 90);
            }, true);
            setInterval(syncUI, 500);
        })();
        """
    }

    private static let vidlyProgressScript = """
    (function () {
        var handlers = window.webkit && window.webkit.messageHandlers;
        var channel = handlers && handlers.\(progressHandlerName);
        if (!channel) return;

        var lastSent = 0;
        function emit(ct, dur) {
            if (!isFinite(ct) || !isFinite(dur) || dur <= 0) return;
            var now = Date.now();
            if (now - lastSent < 900) return;
            lastSent = now;
            try { channel.postMessage({ currentTime: ct, duration: dur }); } catch (e) {}
        }

        window.addEventListener('message', function (event) {
            var payload = event.data;
            if (typeof payload === 'string') {
                try { payload = JSON.parse(payload); } catch (e) { return; }
            }
            if (!payload || typeof payload !== 'object') return;
            var d = payload.type === 'PLAYER_EVENT' && payload.data ? payload.data : payload;
            emit(Number(d.currentTime !== undefined ? d.currentTime : d.timestamp), Number(d.duration));
        }, false);

        document.addEventListener('timeupdate', function (ev) {
            var v = ev && ev.target;
            if (v && v.tagName === 'VIDEO') {
                emit(Number(v.currentTime), Number(v.duration));
            }
        }, true);
    })();
    """
}

@MainActor
private final class ArabicStreamResolver: NSObject, WKNavigationDelegate, WKScriptMessageHandler {
    private let serverName: String
    private let tmdbId: String
    private let arabicTitle: String
    private let englishTitle: String
    private let isMovie: Bool
    private let season: Int
    private let episode: Int
    private let completion: (String?) -> Void

    private var workers: [WKWebView] = []
    private var timeoutTask: Task<Void, Never>?
    private var tier2Task: Task<Void, Never>?
    private var tier3Task: Task<Void, Never>?
    private var mp4GraceTask: Task<Void, Never>?
    private var bestMP4Candidate: String?
    private var isFinished = false

    init(
        serverName: String,
        tmdbId: String,
        arabicTitle: String,
        englishTitle: String,
        isMovie: Bool,
        season: Int,
        episode: Int,
        completion: @escaping (String?) -> Void
    ) {
        self.serverName = serverName
        self.tmdbId = tmdbId
        self.arabicTitle = arabicTitle
        self.englishTitle = englishTitle
        self.isMovie = isMovie
        self.season = season
        self.episode = episode
        self.completion = completion
    }

    func start() {
        let query = isMovie ? arabicTitle : "\(arabicTitle) الحلقة \(episode)"
        let encoded = query.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? query
        let fallbackEncoded = arabicTitle.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? arabicTitle

        let tier1URLs = [
            "https://elif.news/?s=\(encoded)",
            "https://mycima.cc/?s=\(encoded)",
            "https://arabseed.show/?s=\(encoded)"
        ]
        launchBatch(tier1URLs)

        tier2Task = Task { [weak self] in
            try? await Task.sleep(for: .seconds(4.0))
            guard let self, !self.isFinished else { return }
            let tier2URLs = [
                "https://ahwaktv.net/?s=\(encoded)",
                "https://cimalight.co/?s=\(fallbackEncoded)",
                "https://royal-drama.com/?s=\(encoded)",
                "https://qfilm.tv/?s=\(encoded)"
            ]
            self.launchBatch(tier2URLs)
        }

        tier3Task = Task { [weak self] in
            try? await Task.sleep(for: .seconds(8.0))
            guard let self, !self.isFinished else { return }
            let cleanId = self.tmdbId.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !cleanId.isEmpty else { return }
            let tier3URLs: [String]
            if self.isMovie {
                tier3URLs = [
                    "https://vidlink.pro/movie/\(cleanId)?autoplay=true",
                    "https://vidsrc.cc/v2/embed/movie/\(cleanId)?autoPlay=true",
                    "https://vidsrcme.ru/embed/movie/\(cleanId)",
                    "https://player.autoembed.cc/embed/movie/\(cleanId)?server=1"
                ]
            } else {
                tier3URLs = [
                    "https://vidlink.pro/tv/\(cleanId)/\(self.season)/\(self.episode)?autoplay=true",
                    "https://vidsrc.cc/v2/embed/tv/\(cleanId)/\(self.season)/\(self.episode)?autoPlay=true",
                    "https://vidsrcme.ru/embed/tv/\(cleanId)/\(self.season)/\(self.episode)",
                    "https://player.autoembed.cc/embed/tv/\(cleanId)/\(self.season)/\(self.episode)?server=1"
                ]
            }
            self.launchBatch(tier3URLs)
        }

        timeoutTask = Task { [weak self] in
            try? await Task.sleep(for: .seconds(16))
            guard let self, !self.isFinished else { return }
            self.finish(with: self.bestMP4Candidate)
        }
    }

    private func launchBatch(_ urlStrings: [String]) {
        for raw in urlStrings {
            guard !isFinished, let url = URL(string: raw) else { continue }
            let config = WKWebViewConfiguration()
            config.websiteDataStore = .default()
            config.allowsInlineMediaPlayback = true
            config.defaultWebpagePreferences.allowsContentJavaScript = true
            config.mediaTypesRequiringUserActionForPlayback = []
            config.applicationNameForUserAgent = "Version/18.0 Mobile/15E148 Safari/604.1"

            let ucc = config.userContentController
            ucc.add(WeakVidlyMessageHandler(self), name: "arabicStreamFound")
            ucc.addUserScript(
                WKUserScript(
                    source: Self.snifferScript(
                        serverName: serverName,
                        arabicTitle: arabicTitle,
                        englishTitle: englishTitle,
                        isMovie: isMovie,
                        season: season,
                        episode: episode
                    ),
                    injectionTime: .atDocumentStart,
                    forMainFrameOnly: false
                )
            )

            let wv = WKWebView(frame: CGRect(x: 0, y: 0, width: 320, height: 240), configuration: config)
            wv.navigationDelegate = self
            workers.append(wv)
            wv.load(URLRequest(url: url))
        }
    }

    func cancel() {
        isFinished = true
        timeoutTask?.cancel()
        timeoutTask = nil
        tier2Task?.cancel()
        tier2Task = nil
        tier3Task?.cancel()
        tier3Task = nil
        mp4GraceTask?.cancel()
        mp4GraceTask = nil
        cleanupWorkers()
    }

    private func finish(with streamURL: String?) {
        guard !isFinished else { return }
        isFinished = true
        timeoutTask?.cancel()
        timeoutTask = nil
        tier2Task?.cancel()
        tier2Task = nil
        tier3Task?.cancel()
        tier3Task = nil
        mp4GraceTask?.cancel()
        mp4GraceTask = nil
        cleanupWorkers()
        completion(streamURL)
    }

    private func cleanupWorkers() {
        for wv in workers {
            wv.stopLoading()
            wv.navigationDelegate = nil
            wv.configuration.userContentController.removeAllUserScripts()
            wv.configuration.userContentController.removeScriptMessageHandler(forName: "arabicStreamFound")
        }
        workers.removeAll()
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard !isFinished, message.name == "arabicStreamFound", let urlStr = message.body as? String, !urlStr.isEmpty else { return }
        let low = urlStr.lowercased()
        if low.contains(".m3u8") {
            finish(with: urlStr)
            return
        }
        if low.contains(".mp4"), bestMP4Candidate == nil {
            bestMP4Candidate = urlStr
            mp4GraceTask = Task { [weak self] in
                try? await Task.sleep(for: .milliseconds(1200))
                guard let self, !self.isFinished else { return }
                self.finish(with: self.bestMP4Candidate)
            }
        }
    }

    private static func snifferScript(
        serverName: String,
        arabicTitle: String,
        englishTitle: String,
        isMovie: Bool,
        season: Int,
        episode: Int
    ) -> String {
        let escapedSrv = serverName.lowercased()
        let escapedAr = arabicTitle.replacingOccurrences(of: "'", with: "\\'")
        let escapedEn = englishTitle.replacingOccurrences(of: "'", with: "\\'")
        return """
        (function () {
            function norm(s) {
                return (s || '')
                    .toLowerCase()
                    .replace(/[\\u064B-\\u065F\\u0670]/g, '')
                    .replace(/[أإآ]/g, 'ا')
                    .replace(/ة/g, 'ه')
                    .replace(/ى/g, 'ي')
                    .trim();
            }

            function isValidStream(u) {
                if (!u || typeof u !== 'string' || u.length < 12) return false;
                var low = u.toLowerCase();
                if (low.indexOf('blob:') === 0 || low.indexOf('data:') === 0) return false;
                if (low.indexOf('.m3u8') === -1 && low.indexOf('.mp4') === -1) return false;
                var bad = ['doubleclick', 'googlesyndication', 'popads', 'analytics', 'trailer', 'promo', 'teaser', 'preview', 'thumb', 'favicon', '.gif', '.jpg', '.png', '.vtt', '.srt'];
                for (var i = 0; i < bad.length; i++) {
                    if (low.indexOf(bad[i]) !== -1) return false;
                }
                return true;
            }

            function report(u) {
                if (!isValidStream(u)) return;
                try { window.webkit.messageHandlers.arabicStreamFound.postMessage(u); } catch (e) {}
            }

            var _hls = window.Hls;
            if (!_hls) {
                try {
                    Object.defineProperty(window, 'Hls', {
                        configurable: true,
                        enumerable: true,
                        get: function () { return _hls; },
                        set: function (Ctor) {
                            _hls = Ctor;
                            if (Ctor && Ctor.prototype && !Ctor.prototype.__sgSniffed) {
                                Ctor.prototype.__sgSniffed = true;
                                var origLoad = Ctor.prototype.loadSource;
                                if (typeof origLoad === 'function') {
                                    Ctor.prototype.loadSource = function (src) {
                                        try { report(src); } catch (e) {}
                                        return origLoad.apply(this, arguments);
                                    };
                                }
                            }
                        }
                    });
                } catch (e) {}
            }

            var origFetch = window.fetch;
            if (typeof origFetch === 'function') {
                window.fetch = function (input) {
                    try { report(typeof input === 'string' ? input : (input && input.url)); } catch (e) {}
                    return origFetch.apply(this, arguments);
                };
            }

            var origOpen = XMLHttpRequest.prototype.open;
            XMLHttpRequest.prototype.open = function (m, u) {
                try { report(u); } catch (e) {}
                return origOpen.apply(this, arguments);
            };

            var arNeedle = norm('\(escapedAr)');
            var enNeedle = norm('\(escapedEn)');
            var epNum = \(episode);
            var isMov = \(isMovie ? "true" : "false");

            function hasEpisodeToken(t) {
                if (isMov) return true;
                var n = norm(t);
                var pats = ['الحلقه ' + epNum, 'حلقه ' + epNum, 'ح' + epNum, 'e' + epNum, 'ep ' + epNum, 'episode ' + epNum];
                for (var i = 0; i < pats.length; i++) {
                    if (n.indexOf(pats[i]) !== -1) return true;
                }
                return false;
            }

            function step() {
                var vids = document.querySelectorAll('video, source');
                for (var i = 0; i < vids.length; i++) {
                    var s = vids[i].currentSrc || vids[i].src || '';
                    if (s) report(s);
                }
                if (window !== window.top) return;

                var host = (window.location.hostname || '').toLowerCase();
                var isArabicHost = host.indexOf('elif.news') !== -1 ||
                    host.indexOf('mycima') !== -1 ||
                    host.indexOf('my-cima') !== -1 ||
                    host.indexOf('arabseed') !== -1 ||
                    host.indexOf('ahwaktv') !== -1 ||
                    host.indexOf('cimalight') !== -1 ||
                    host.indexOf('royal-drama') !== -1 ||
                    host.indexOf('qfilm') !== -1;

                if (isArabicHost) {
                    if (!window.__sgClickedServer) {
                        var btns = document.querySelectorAll('button, a, li[data-watch], [data-server]');
                        var fallbackBtn = null;
                        for (var b = 0; b < btns.length; b++) {
                            var bt = norm(btns[b].innerText || btns[b].textContent || '');
                            if (bt === '\(escapedSrv)' || bt.indexOf('\(escapedSrv)') !== -1) {
                                window.__sgClickedServer = true;
                                btns[b].click();
                                return;
                            }
                            if (!fallbackBtn && (bt.indexOf('سيرفر') !== -1 || bt.indexOf('مشاهده') !== -1 || btns[b].hasAttribute('data-watch'))) {
                                fallbackBtn = btns[b];
                            }
                        }
                        if (fallbackBtn && (location.search || '').indexOf('?s=') === -1) {
                            window.__sgClickedServer = true;
                            fallbackBtn.click();
                            return;
                        }
                    }

                    if (!window.__sgClickedPost) {
                        var links = document.querySelectorAll('article a, .post a, .Thumb--GridItem a, .MovieBlock a, h2 a, h3 a, a');
                        var partialMatch = null;
                        for (var l = 0; l < links.length; l++) {
                            var lt = norm(links[l].innerText || links[l].getAttribute('title') || '');
                            if (!lt || lt.length < 2) continue;
                            var titleHit = (arNeedle.length > 1 && lt.indexOf(arNeedle) !== -1) || (enNeedle.length > 1 && lt.indexOf(enNeedle) !== -1);
                            if (titleHit && hasEpisodeToken(lt)) {
                                window.__sgClickedPost = true;
                                links[l].click();
                                return;
                            }
                            if (!partialMatch && (titleHit || (!isMov && hasEpisodeToken(lt)))) {
                                partialMatch = links[l];
                            }
                        }
                        if (partialMatch && (location.search || '').indexOf('?s=') !== -1) {
                            window.__sgClickedPost = true;
                            partialMatch.click();
                            return;
                        }
                    }
                }
            }

            setInterval(step, 400);
            if (document.readyState !== 'loading') step();
            else document.addEventListener('DOMContentLoaded', step);
        })();
        """
    }
}

private final class WeakVidlyMessageHandler: NSObject, WKScriptMessageHandler {
    private weak var delegate: WKScriptMessageHandler?

    init(_ delegate: WKScriptMessageHandler) {
        self.delegate = delegate
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        delegate?.userContentController(userContentController, didReceive: message)
    }
}
