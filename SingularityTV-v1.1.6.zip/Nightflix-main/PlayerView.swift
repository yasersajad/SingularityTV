import SwiftUI

struct PlayerView: View {
    let item: WatchItem
    var continueWatchingManager: ContinueWatchingManager?
    @Environment(NFAppModel.self) private var app

    var body: some View {
        CustomPlayerView(
            item: item,
            continueWatchingManager: continueWatchingManager,
            historyManager: app.history
        )
    }
}
