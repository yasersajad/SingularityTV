import XCTest
@testable import SingularityTV

final class SingularityTests: XCTestCase {
    func testSRTParserMultiLineAndHTML() {
        let srt = """
        1
        00:00:01,000 --> 00:00:04,500
        <i>Hello</i> world
        Second line

        2
        00:00:05.000 --> 00:00:08.000
        مرحبا بكم
        """
        let cues = SubtitleParser.parse(srt)
        XCTAssertEqual(cues.count, 2)
        XCTAssertEqual(cues[0].text, "Hello world\nSecond line")
        XCTAssertEqual(cues[1].text, "مرحبا بكم")
        XCTAssertEqual(SubtitleParser.activeCue(in: cues, at: 2.0)?.id, 1)
        XCTAssertNil(SubtitleParser.activeCue(in: cues, at: 4.75))
    }

    func testWebVTTParserWithMetadataAndNotes() {
        let vtt = """
        WEBVTT

        NOTE
        This is a comment

        00:01.000 --> 00:03.500 align:start
        Line one
        """
        let cues = SubtitleParser.parse(vtt)
        XCTAssertEqual(cues.count, 1)
        XCTAssertEqual(cues[0].text, "Line one")
        XCTAssertEqual(cues[0].start, 1.0, accuracy: 0.01)
    }

    func testASSParser() {
        let ass = """
        [Script Info]
        Title: Test
        [Events]
        Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
        Dialogue: 0,0:00:10.00,0:00:12.50,Default,,0,0,0,,{\\an8}First\\NSecond
        """
        let cues = SubtitleParser.parse(ass)
        XCTAssertEqual(cues.count, 1)
        XCTAssertEqual(cues[0].text, "First\nSecond")
    }

    func testUTF8BOMAndArabicWindows1256Decoding() {
        let bomBytes: [UInt8] = [0xEF, 0xBB, 0xBF] + Array("1\n00:00:01,000 --> 00:00:02,000\nTest".utf8)
        let decodedBOM = SubtitleEncodingDetector.decode(Data(bomBytes))
        XCTAssertEqual(decodedBOM?.encodingName, "UTF-8 BOM")
        XCTAssertEqual(SubtitleParser.parse(decodedBOM?.text ?? "").count, 1)

        let arabic1256 = Data([0xE3, 0xD1, 0xCD, 0xC8, 0xC7])
        let decodedAr = SubtitleEncodingDetector.decode(arabic1256, preferredLanguage: "ar")
        XCTAssertEqual(decodedAr?.encodingName, "Windows-1256")
        XCTAssertTrue(decodedAr?.text.contains("مرحبا") == true)
    }

    func testSubtitleLanguageResolverMetadataAndContent() {
        let hashResult = SubtitleLanguageResolver.resolveFromMetadata(
            serverCode: "",
            sourceLabel: "idddsoys7327376885hzhskgaa.srt",
            filename: "idddsoys7327376885hzhskgaa.srt"
        )
        XCTAssertFalse(hashResult.isKnown)
        XCTAssertEqual(hashResult.name, "Unknown Language")
        XCTAssertTrue(SubtitleLanguageResolver.isRandomHashFilename("idddsoys7327376885hzhskgaa.srt"))

        let arabicSRT = """
        1
        00:00:01,000 --> 00:00:03,000
        مرحبا بكم في هذا الفيلم الرائع
        2
        00:00:04,000 --> 00:00:07,000
        سنبدأ الرحلة الآن معاً
        """
        let arDetected = SubtitleLanguageResolver.resolveFromContent(arabicSRT)
        XCTAssertTrue(arDetected.isKnown)
        XCTAssertEqual(arDetected.name, "Arabic")

        let jpSRT = """
        1
        00:00:01,000 --> 00:00:03,000
        こんにちは、お元気ですか？
        2
        00:00:04,000 --> 00:00:07,000
        東京へようこそ。
        """
        let jpDetected = SubtitleLanguageResolver.resolveFromContent(jpSRT)
        XCTAssertTrue(jpDetected.isKnown)
        XCTAssertEqual(jpDetected.name, "Japanese")
    }

    @MainActor
    func testAudioManagerDiscoveryAndReset() {
        let manager = PlayerAudioManager()
        let raw = [
            InPlayerAudioTrack(trackId: "hls_0", nativeIndex: 0, languageCode: "en", languageName: "English", displayName: "en", trackType: .hlsManifest, codec: "mp4a", channelLayout: "5.1", isDefault: true, isSelected: true, sourceIdentifier: "HLS", availability: .selectable),
            InPlayerAudioTrack(trackId: "hls_1", nativeIndex: 1, languageCode: "en", languageName: "English", displayName: "en", trackType: .hlsManifest, codec: "mp4a", channelLayout: "2.0", isDefault: false, isSelected: false, sourceIdentifier: "HLS", availability: .selectable),
            InPlayerAudioTrack(trackId: "hls_2", nativeIndex: 2, languageCode: "", languageName: "Unknown Language", displayName: "", trackType: .hlsManifest, codec: nil, channelLayout: nil, isDefault: false, isSelected: false, sourceIdentifier: "HLS", availability: .selectable)
        ]
        manager.updateDiscoveredTracks(raw, source: "HLS Manifest")
        XCTAssertEqual(manager.tracks.count, 3)
        XCTAssertEqual(manager.tracks[0].displayName, "English 1")
        XCTAssertEqual(manager.tracks[1].displayName, "English 2")
        XCTAssertEqual(manager.tracks[2].displayName, "Unknown Audio Track 1")
        manager.reset()
        XCTAssertTrue(manager.tracks.isEmpty)
    }

    func testSemanticVersionComparison() {
        XCTAssertEqual(SemanticVersion.compare("1.1.5", "1.1.6"), .orderedAscending)
        XCTAssertEqual(SemanticVersion.compare("v3.0.0", "3.0.0"), .orderedSame)
        XCTAssertEqual(SemanticVersion.compare("3.1.0", "3.0.9"), .orderedDescending)
    }

    @MainActor
    func testProfileSanitizationDeduplicatesAndCapsAtFive() {
        let input = [
            UserProfile(id: "p1", name: "One", avatarColor: "#E50914", isKids: false, createdAt: 1),
            UserProfile(id: "p1", name: "Duplicate", avatarColor: "#E50914", isKids: false, createdAt: 2),
            UserProfile(id: "", name: "EmptyID", avatarColor: "#E50914", isKids: false, createdAt: 3),
            UserProfile(id: "p2", name: "Two", avatarColor: "#3B82F6", isKids: true, createdAt: 4),
            UserProfile(id: "p3", name: "Three", avatarColor: "#10B981", isKids: false, createdAt: 5),
            UserProfile(id: "p4", name: "Four", avatarColor: "#8B5CF6", isKids: false, createdAt: 6),
            UserProfile(id: "p5", name: "Five", avatarColor: "#EC4899", isKids: false, createdAt: 7),
            UserProfile(id: "p6", name: "Six", avatarColor: "#06B6D4", isKids: false, createdAt: 8)
        ]
        let sanitized = SingularitySessionManager.sanitizeProfiles(input, fallbackName: "Main")
        XCTAssertEqual(sanitized.count, 5)
        XCTAssertEqual(sanitized.map(\.id), ["p1", "p2", "p3", "p4", "p5"])
        XCTAssertEqual(sanitized[0].name, "One")
    }

    func testCorruptSubtitleRejection() {
        let gibberish = String(repeating: "\u{FFFD}", count: 40) + "abc"
        XCTAssertFalse(SubtitleEncodingDetector.isTextReadable(gibberish))

        let controlChars = "Hello\u{0001}\u{0002}\u{0003}\u{0004}World"
        XCTAssertFalse(SubtitleEncodingDetector.isTextReadable(controlChars))

        let clean = "1\n00:00:01,000 --> 00:00:03,000\nمرحبا بكم"
        XCTAssertTrue(SubtitleEncodingDetector.isTextReadable(clean))
    }

    @MainActor
    func testInternalServerManagerDiscoveryAndProviderIsolation() {
        let manager = InternalServerManager()
        let listA = [
            InternalServerOption(id: "a1", parentProviderID: "vidy.st", nativeIndex: 0, name: "Server A1", sourceType: .tab, isSelected: true, isAvailable: true, playbackURL: nil, domKey: "k1"),
            InternalServerOption(id: "b1", parentProviderID: "other.tv", nativeIndex: 1, name: "Server B1", sourceType: .tab, isSelected: false, isAvailable: true, playbackURL: nil, domKey: "k2")
        ]
        manager.updateDiscoveredServers(listA, for: "vidy.st")
        XCTAssertEqual(manager.servers.count, 1)
        XCTAssertEqual(manager.activeServer?.id, "a1")
        manager.reset(for: "vidfast.vc")
        XCTAssertFalse(manager.hasInternalServers)
        XCTAssertEqual(manager.parentProviderID, "vidfast.vc")
    }

    @MainActor
    func testPlayerVisibilityManagerLocksDuringGesturesAndMenus() {
        let vm = PlayerVisibilityManager()
        XCTAssertTrue(vm.isChromeVisible)
        vm.beginGesture(.seeking)
        XCTAssertTrue(vm.isGestureLocked)
        XCTAssertTrue(vm.isChromeVisible)
        vm.handleUserTap()
        XCTAssertTrue(vm.isChromeVisible)
        vm.handleWebInteraction()
        XCTAssertTrue(vm.isChromeVisible)
        vm.hide()
        XCTAssertTrue(vm.isChromeVisible)
        vm.endGesture()
        XCTAssertFalse(vm.isGestureLocked)
        XCTAssertTrue(vm.isChromeVisible)
        vm.presentMenu()
        XCTAssertEqual(vm.state, .menuPresented)
        vm.hide()
        XCTAssertTrue(vm.isChromeVisible)
        vm.dismissMenu()
        XCTAssertEqual(vm.state, .visible)
        vm.cleanup()
        XCTAssertFalse(vm.isChromeVisible)
    }

    @MainActor
    func testPlaybackSessionContextGenerationAndCapabilitiesReset() {
        let item = WatchItem(
            type: .movie,
            title: "Test Movie",
            tmdbId: "123",
            posterPath: nil,
            generatedURL: URL(string: "https://vidy.st/movie/123")!
        )
        let ctx = PlaybackSessionContext(content: item)
        XCTAssertEqual(ctx.sessionGeneration, 1)
        ctx.capabilities.supportsAudioTracks = true
        ctx.capabilities.supportsSkipIntro = true

        let srv = InternalServerOption(
            id: "s1",
            parentProviderID: "vidy.st",
            nativeIndex: 0,
            name: "Mirror 1",
            sourceType: .mirror,
            isSelected: true,
            isAvailable: true,
            playbackURL: nil,
            domKey: "k1"
        )
        let gen2 = ctx.beginInternalServerSession(srv)
        XCTAssertEqual(gen2, 2)
        XCTAssertEqual(ctx.activeInternalServer?.id, "s1")
        XCTAssertFalse(ctx.capabilities.supportsAudioTracks)
        XCTAssertFalse(ctx.capabilities.supportsSkipIntro)

        let gen3 = ctx.beginNewSession(providerHost: "vidfast.vc")
        XCTAssertEqual(gen3, 3)
        XCTAssertNil(ctx.activeInternalServer)
        XCTAssertEqual(ctx.mainProviderHost, "vidfast.vc")
    }
}
