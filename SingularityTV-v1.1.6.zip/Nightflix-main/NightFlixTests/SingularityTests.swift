import XCTest
@testable import SingularityTV

final class SingularityTests: XCTestCase {
    func testSRTParserMultiLineAndHTML() {
        let srt = """
        1
        00:00:01,000 --> 00:00:04,500
        <i>Hello</i> world
        Second line

        2
        00:00:05.000 --> 00:00:08.000
        مرحبا بكم
        """
        let cues = SubtitleParser.parse(srt)
        XCTAssertEqual(cues.count, 2)
        XCTAssertEqual(cues[0].text, "Hello world\nSecond line")
        XCTAssertEqual(cues[1].text, "مرحبا بكم")
        XCTAssertEqual(SubtitleParser.activeCue(in: cues, at: 2.0)?.id, 1)
        XCTAssertNil(SubtitleParser.activeCue(in: cues, at: 4.75))
    }

    func testWebVTTParserWithMetadataAndNotes() {
        let vtt = """
        WEBVTT

        NOTE
        This is a comment

        00:01.000 --> 00:03.500 align:start
        Line one
        """
        let cues = SubtitleParser.parse(vtt)
        XCTAssertEqual(cues.count, 1)
        XCTAssertEqual(cues[0].text, "Line one")
        XCTAssertEqual(cues[0].start, 1.0, accuracy: 0.01)
    }

    func testASSParser() {
        let ass = """
        [Script Info]
        Title: Test
        [Events]
        Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
        Dialogue: 0,0:00:10.00,0:00:12.50,Default,,0,0,0,,{\\an8}First\\NSecond
        """
        let cues = SubtitleParser.parse(ass)
        XCTAssertEqual(cues.count, 1)
        XCTAssertEqual(cues[0].text, "First\nSecond")
    }

    func testUTF8BOMAndArabicWindows1256Decoding() {
        let bomBytes: [UInt8] = [0xEF, 0xBB, 0xBF] + Array("1\n00:00:01,000 --> 00:00:02,000\nTest".utf8)
        let decodedBOM = SubtitleEncodingDetector.decode(Data(bomBytes))
        XCTAssertEqual(decodedBOM?.encodingName, "UTF-8 BOM")
        XCTAssertEqual(SubtitleParser.parse(decodedBOM?.text ?? "").count, 1)

        let arabic1256 = Data([0xE3, 0xD1, 0xCD, 0xC8, 0xC7])
        let decodedAr = SubtitleEncodingDetector.decode(arabic1256, preferredLanguage: "ar")
        XCTAssertEqual(decodedAr?.encodingName, "Windows-1256")
        XCTAssertTrue(decodedAr?.text.contains("مرحبا") == true)
    }

    func testSemanticVersionComparison() {
        XCTAssertEqual(SemanticVersion.compare("1.1.5", "1.1.6"), .orderedAscending)
        XCTAssertEqual(SemanticVersion.compare("v3.0.0", "3.0.0"), .orderedSame)
        XCTAssertEqual(SemanticVersion.compare("3.1.0", "3.0.9"), .orderedDescending)
    }

    @MainActor
    func testProfileSanitizationDeduplicatesAndCapsAtFive() {
        let input = [
            UserProfile(id: "p1", name: "One", avatarColor: "#E50914", isKids: false, createdAt: 1),
            UserProfile(id: "p1", name: "Duplicate", avatarColor: "#E50914", isKids: false, createdAt: 2),
            UserProfile(id: "", name: "EmptyID", avatarColor: "#E50914", isKids: false, createdAt: 3),
            UserProfile(id: "p2", name: "Two", avatarColor: "#3B82F6", isKids: true, createdAt: 4),
            UserProfile(id: "p3", name: "Three", avatarColor: "#10B981", isKids: false, createdAt: 5),
            UserProfile(id: "p4", name: "Four", avatarColor: "#8B5CF6", isKids: false, createdAt: 6),
            UserProfile(id: "p5", name: "Five", avatarColor: "#EC4899", isKids: false, createdAt: 7),
            UserProfile(id: "p6", name: "Six", avatarColor: "#06B6D4", isKids: false, createdAt: 8)
        ]
        let sanitized = SingularitySessionManager.sanitizeProfiles(input, fallbackName: "Main")
        XCTAssertEqual(sanitized.count, 5)
        XCTAssertEqual(sanitized.map(\.id), ["p1", "p2", "p3", "p4", "p5"])
        XCTAssertEqual(sanitized[0].name, "One")
    }
}
