import Combine
import Foundation
import SwiftUI

@MainActor
final class SingularitySessionManager: ObservableObject {
    static let shared = SingularitySessionManager()

    enum GateStage: Equatable {
        case loading
        case auth
        case mandatoryUpdate
        case telegramGate
        case profilePicker
        case ready
    }

    @Published private(set) var session: SupabaseSession?
    @Published private(set) var stage: GateStage = .loading
    @Published private(set) var gateStatus: TelegramGateStatus?
    @Published private(set) var optionalUpdate: AppReleaseInfo?
    @Published var isShowingOptionalUpdate = false

    @Published private(set) var profiles: [UserProfile] = []
    @Published private(set) var activeProfileId: String = "prof_main"
    @Published var isShowingProfileSheet = false
    @Published var isShowingLocalMergePrompt = false

    @Published private(set) var isCheckingGate = false
    @Published private(set) var isSwitchingProfile = false
    @Published var profileError: String?
    @Published var profileSwitchError: String?
    @Published var failedProfileCandidate: UserProfile?

    var activeProfile: UserProfile? {
        profiles.first { $0.id == activeProfileId } ?? profiles.first
    }

    var isKidsMode: Bool {
        activeProfile?.isKids == true
    }

    private weak var myListManager: MyListManager?
    private weak var historyManager: WatchHistoryManager?
    private weak var continueWatchingManager: ContinueWatchingManager?
    private weak var libraryModel: NFLibrary?
    private weak var settingsManager: AppSettingsManager?

    private var lastGateCheckAt: Date?
    private var debounceSyncTask: Task<Void, Never>?
    private var pendingCloudDataForMerge: [String: Any]?
    private var hasCompletedInitialBootstrap = false
    private var isHydratingProfile = false
    private var switchGeneration: Int = 0

    private let defaults = UserDefaults.standard
    private let activeProfileStoragePrefix = "singularity.activeProfileId."
    private let accountVaultPrefix = "singularity.accountVault."
    private let localPreAuthBackupKey = "singularity.localPreAuthBackup"
    private let kidsModeDefaultsKey = "singularity.activeProfileIsKids"

    private init() {
        session = KeychainHelper.loadSession()
    }

    func attachManagers(
        myList: MyListManager,
        history: WatchHistoryManager,
        continueWatching: ContinueWatchingManager,
        library: NFLibrary,
        settings: AppSettingsManager
    ) {
        self.myListManager = myList
        self.historyManager = history
        self.continueWatchingManager = continueWatching
        self.libraryModel = library
        self.settingsManager = settings
    }

    func bootstrapIfNeeded() async {
        guard !hasCompletedInitialBootstrap else { return }
        hasCompletedInitialBootstrap = true
        await restoreSessionAndEvaluateGates(forceRefreshGate: true)
    }

    func restoreSessionAndEvaluateGates(forceRefreshGate: Bool = false) async {
        if let valid = await SupabaseAuthService.shared.ensureValidSession(forceRefresh: false) {
            session = valid
            await evaluateGatesAndLoadAccount(forceGateCheck: forceRefreshGate)
        } else {
            KeychainHelper.deleteSession()
            session = nil
            profiles = []
            defaults.set(false, forKey: kidsModeDefaultsKey)
            stage = .auth
        }
    }

    func handleAuthenticated(_ newSession: SupabaseSession, isNewSignIn: Bool = true) async {
        session = newSession
        lastGateCheckAt = nil
        if isNewSignIn {
            snapshotPreAuthLocalDataIfNeeded(for: newSession.user.id)
        }
        await evaluateGatesAndLoadAccount(forceGateCheck: true)
    }

    func recheckGate() async {
        await evaluateGatesAndLoadAccount(forceGateCheck: true)
    }

    func checkUpdatesManually() async -> AppReleaseInfo? {
        guard let currentSession = await SupabaseAuthService.shared.ensureValidSession(forceRefresh: false) else {
            return nil
        }
        let status = await SingularitySyncService.shared.checkTelegramAndReleaseGate(authSession: currentSession)
        gateStatus = status
        if status.needsMandatoryUpdate {
            stage = .mandatoryUpdate
            return status.release
        }
        if status.hasOptionalUpdate, let rel = status.release {
            optionalUpdate = rel
            isShowingOptionalUpdate = true
            return rel
        }
        return nil
    }

    private func evaluateGatesAndLoadAccount(forceGateCheck: Bool) async {
        guard let currentSession = session else {
            stage = .auth
            return
        }

        if !forceGateCheck,
           let lastCheck = lastGateCheckAt,
           Date().timeIntervalSince(lastCheck) < 60,
           let cached = gateStatus {
            applyGateStatus(cached)
            return
        }

        isCheckingGate = true
        let status = await SingularitySyncService.shared.checkTelegramAndReleaseGate(authSession: currentSession)
        isCheckingGate = false
        lastGateCheckAt = Date()
        gateStatus = status

        if status.networkError != nil {
            if stage == .loading {
                stage = .telegramGate
            }
            return
        }

        if status.needsMandatoryUpdate {
            stage = .mandatoryUpdate
            return
        }

        if !status.member {
            stage = .telegramGate
            return
        }

        if status.hasOptionalUpdate, let rel = status.release {
            optionalUpdate = rel
            if settingsManager?.automaticUpdateChecksEnabled != false {
                isShowingOptionalUpdate = true
            }
        }

        await pullAndHydrateAccount(for: currentSession)

        if stage != .ready {
            stage = .profilePicker
        }
    }

    private func applyGateStatus(_ status: TelegramGateStatus) {
        if status.needsMandatoryUpdate {
            stage = .mandatoryUpdate
        } else if !status.member {
            stage = .telegramGate
        } else if stage != .ready {
            stage = .profilePicker
        }
    }

    // MARK: - Profiles

    func selectProfile(_ profile: UserProfile) async {
        guard !isSwitchingProfile else {
            SingularityDiagnostics.shared.record(category: "Profile", message: "Ignored concurrent switch tap for \(profile.id)")
            return
        }
        let cleanId = profile.id.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !cleanId.isEmpty else {
            profileSwitchError = "Invalid profile identifier."
            failedProfileCandidate = profile
            SingularityDiagnostics.shared.record(category: "Profile", message: "Rejected empty profile ID")
            return
        }
        guard let uid = session?.user.id, !uid.isEmpty else {
            profileSwitchError = "Session expired. Please sign in again."
            failedProfileCandidate = profile
            SingularityDiagnostics.shared.record(category: "Profile", message: "Aborted switch: missing session")
            return
        }

        profiles = Self.sanitizeProfiles(profiles, fallbackName: session?.user.name ?? "Main")
        guard let verifiedProfile = profiles.first(where: { $0.id == cleanId }) else {
            profileSwitchError = "Selected profile could not be found."
            failedProfileCandidate = profile
            SingularityDiagnostics.shared.record(category: "Profile", message: "Profile \(cleanId) missing after sanitization")
            return
        }

        switchGeneration &+= 1
        let gen = switchGeneration
        let previousProfileId = activeProfileId
        let previousKidsMode = defaults.bool(forKey: kidsModeDefaultsKey)

        isSwitchingProfile = true
        profileError = nil
        profileSwitchError = nil
        failedProfileCandidate = nil
        debounceSyncTask?.cancel()
        defer { isSwitchingProfile = false }

        saveCurrentActiveProfileToVault()

        activeProfileId = verifiedProfile.id
        defaults.set(verifiedProfile.id, forKey: activeProfileStoragePrefix + uid)
        defaults.set(verifiedProfile.isKids, forKey: kidsModeDefaultsKey)

        loadProfileFromVaultIntoManagers(profileId: verifiedProfile.id)

        guard gen == switchGeneration, activeProfileId == verifiedProfile.id, session?.user.id == uid else {
            activeProfileId = previousProfileId
            defaults.set(previousProfileId, forKey: activeProfileStoragePrefix + uid)
            defaults.set(previousKidsMode, forKey: kidsModeDefaultsKey)
            loadProfileFromVaultIntoManagers(profileId: previousProfileId)
            profileSwitchError = "Could not finish switching to \(verifiedProfile.name). Please try again."
            failedProfileCandidate = verifiedProfile
            SingularityDiagnostics.shared.record(category: "Profile", message: "Rolled back switch to \(verifiedProfile.id) (gen mismatch)")
            return
        }

        SingularityDiagnostics.shared.record(category: "Profile", message: "Switched to profile \(verifiedProfile.id) (gen \(gen))")
        isShowingProfileSheet = false
        if stage == .profilePicker {
            stage = .ready
        }

        scheduleDebouncedSync()
    }

    static func sanitizeProfiles(_ raw: [UserProfile], fallbackName: String) -> [UserProfile] {
        var seen = Set<String>()
        var clean: [UserProfile] = []
        for p in raw {
            let pid = p.id.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !pid.isEmpty, !seen.contains(pid) else { continue }
            seen.insert(pid)
            let name = String(p.name.trimmingCharacters(in: .whitespacesAndNewlines).prefix(24))
            clean.append(UserProfile(
                id: pid,
                name: name.isEmpty ? "Profile" : name,
                avatarColor: p.avatarColor.isEmpty ? "#E50914" : p.avatarColor,
                isKids: p.isKids,
                createdAt: p.createdAt
            ))
            if clean.count >= 5 { break }
        }
        if clean.isEmpty {
            clean.append(UserProfile(
                id: "prof_main",
                name: fallbackName.isEmpty ? "Main" : String(fallbackName.prefix(24)),
                avatarColor: "#E50914",
                isKids: false,
                createdAt: Date().timeIntervalSince1970 * 1000
            ))
        }
        return clean
    }

    func retryFailedProfileSwitch() async {
        guard let candidate = failedProfileCandidate else { return }
        await selectProfile(candidate)
    }

    func createProfile(name: String, avatarColor: String, isKids: Bool) async -> Bool {
        let trimmed = String(name.trimmingCharacters(in: .whitespacesAndNewlines).prefix(24))
        guard !trimmed.isEmpty else {
            profileError = "Please enter a profile name."
            return false
        }
        guard profiles.count < 5 else {
            profileError = "Maximum 5 profiles per account."
            return false
        }

        let newId = "prof_\(Int(Date().timeIntervalSince1970))_\(Int.random(in: 1000...9999))"
        let newProfile = UserProfile(
            id: newId,
            name: trimmed,
            avatarColor: avatarColor,
            isKids: isKids,
            createdAt: Date().timeIntervalSince1970 * 1000
        )

        if let currentSession = await SupabaseAuthService.shared.ensureValidSession(forceRefresh: false) {
            do {
                if let serverProfiles = try await SingularitySyncService.shared.performProfileOperation(
                    authSession: currentSession,
                    body: [
                        "op": "create",
                        "id": newProfile.id,
                        "name": newProfile.name,
                        "avatarColor": newProfile.avatarColor,
                        "isKids": newProfile.isKids
                    ]
                ) {
                    profiles = Self.sanitizeProfiles(serverProfiles, fallbackName: session?.user.name ?? "Main")
                    persistProfilesMetadataToVault()
                    return true
                }
            } catch {
                profileError = error.localizedDescription
                return false
            }
        }

        profiles.append(newProfile)
        persistProfilesMetadataToVault()
        scheduleDebouncedSync()
        return true
    }

    func updateProfile(id: String, name: String, avatarColor: String, isKids: Bool) async -> Bool {
        let trimmed = String(name.trimmingCharacters(in: .whitespacesAndNewlines).prefix(24))
        guard !trimmed.isEmpty else {
            profileError = "Please enter a profile name."
            return false
        }
        guard let idx = profiles.firstIndex(where: { $0.id == id }) else {
            profileError = "Profile not found."
            return false
        }

        if let currentSession = await SupabaseAuthService.shared.ensureValidSession(forceRefresh: false) {
            do {
                if let serverProfiles = try await SingularitySyncService.shared.performProfileOperation(
                    authSession: currentSession,
                    body: [
                        "op": "update",
                        "id": id,
                        "name": trimmed,
                        "avatarColor": avatarColor,
                        "isKids": isKids
                    ]
                ) {
                    profiles = Self.sanitizeProfiles(serverProfiles, fallbackName: session?.user.name ?? "Main")
                    if activeProfileId == id {
                        defaults.set(isKids, forKey: kidsModeDefaultsKey)
                    }
                    persistProfilesMetadataToVault()
                    return true
                }
            } catch {
                profileError = error.localizedDescription
                return false
            }
        }

        profiles[idx].name = trimmed
        profiles[idx].avatarColor = avatarColor
        profiles[idx].isKids = isKids
        if activeProfileId == id {
            defaults.set(isKids, forKey: kidsModeDefaultsKey)
        }
        persistProfilesMetadataToVault()
        scheduleDebouncedSync()
        return true
    }

    func deleteProfile(id: String) async -> Bool {
        guard profiles.count > 1 else {
            profileError = "Cannot delete the last remaining profile."
            return false
        }

        if let currentSession = await SupabaseAuthService.shared.ensureValidSession(forceRefresh: false) {
            do {
                if let serverProfiles = try await SingularitySyncService.shared.performProfileOperation(
                    authSession: currentSession,
                    body: ["op": "delete", "id": id]
                ) {
                    profiles = Self.sanitizeProfiles(serverProfiles, fallbackName: session?.user.name ?? "Main")
                }
            } catch {
                profileError = error.localizedDescription
                return false
            }
        } else {
            profiles.removeAll { $0.id == id }
        }

        removeProfileFromVault(profileId: id)
        if activeProfileId == id, let fallback = profiles.first {
            await selectProfile(fallback)
        } else {
            persistProfilesMetadataToVault()
        }
        return true
    }

    // MARK: - Sign Out

    func signOut() async {
        debounceSyncTask?.cancel()
        saveCurrentActiveProfileToVault()
        await pushSyncNow()

        let token = session?.accessToken
        await SupabaseAuthService.shared.signOut(accessToken: token)

        session = nil
        profiles = []
        activeProfileId = "prof_main"
        gateStatus = nil
        optionalUpdate = nil
        isShowingOptionalUpdate = false
        isShowingProfileSheet = false
        lastGateCheckAt = nil
        defaults.set(false, forKey: kidsModeDefaultsKey)

        clearActiveRuntimeDataForAccountIsolation()
        stage = .auth
    }

    // MARK: - Sync & Local Data Isolation

    func notifyLocalDataChanged() {
        guard session != nil, !isHydratingProfile else { return }
        saveCurrentActiveProfileToVault()
        scheduleDebouncedSync()
    }

    func pushProgressAtomic(
        type: WatchType,
        tmdbId: String,
        season: Int?,
        episode: Int?,
        positionSeconds: Double,
        durationSeconds: Double,
        watched: Bool
    ) {
        guard let currentSession = session else { return }
        let key: String
        if type == .tv, let s = season, let e = episode {
            key = "tv_\(tmdbId)_s\(s)_e\(e)"
        } else {
            key = "\(type.rawValue)_\(tmdbId)"
        }
        let pct = durationSeconds > 0 ? Int(round((positionSeconds / durationSeconds) * 100)) : (watched ? 100 : 1)
        let pid = activeProfileId

        Task {
            await SingularitySyncService.shared.pushProgressAtomic(
                authSession: currentSession,
                progressKey: key,
                percent: pct,
                positionSec: Int(positionSeconds),
                durationSec: Int(durationSeconds),
                watched: watched,
                isPlaying: !watched,
                profileId: pid
            )
        }
    }

    private func scheduleDebouncedSync() {
        debounceSyncTask?.cancel()
        debounceSyncTask = Task { [weak self] in
            try? await Task.sleep(for: .milliseconds(1500))
            guard !Task.isCancelled else { return }
            await self?.pushSyncNow()
        }
    }

    func pushSyncNow() async {
        guard let currentSession = await SupabaseAuthService.shared.ensureValidSession(forceRefresh: false) else { return }
        saveCurrentActiveProfileToVault()
        let payload = buildCloudPayload(for: currentSession.user.id)
        try? await SingularitySyncService.shared.pushUserSyncData(authSession: currentSession, dataPayload: payload)
    }

    private func pullAndHydrateAccount(for authSession: SupabaseSession) async {
        let uid = authSession.user.id
        let remoteData = await SingularitySyncService.shared.pullUserSyncData(authSession: authSession)

        if let remoteData {
            let hasPreAuthLocal = defaults.data(forKey: localPreAuthBackupKey) != nil
            if hasPreAuthLocal {
                pendingCloudDataForMerge = remoteData
                applyRemoteDataToVault(remoteData, userId: uid, mergeWithExistingLocal: false)
                isShowingLocalMergePrompt = true
            } else {
                applyRemoteDataToVault(remoteData, userId: uid, mergeWithExistingLocal: true)
            }
        } else {
            if profiles.isEmpty {
                let defaultProfile = UserProfile(
                    id: "prof_main",
                    name: authSession.user.name,
                    avatarColor: "#E50914",
                    isKids: false,
                    createdAt: Date().timeIntervalSince1970 * 1000
                )
                profiles = [defaultProfile]
                activeProfileId = defaultProfile.id
                saveCurrentActiveProfileToVault()
                persistProfilesMetadataToVault()
            }
            defaults.removeObject(forKey: localPreAuthBackupKey)
            await pushSyncNow()
        }

        let storedActive = defaults.string(forKey: activeProfileStoragePrefix + uid)
        if let storedActive, profiles.contains(where: { $0.id == storedActive }) {
            activeProfileId = storedActive
        } else if let first = profiles.first {
            activeProfileId = first.id
        }
        defaults.set(activeProfile?.isKids == true, forKey: kidsModeDefaultsKey)
        loadProfileFromVaultIntoManagers(profileId: activeProfileId)
    }

    func resolveLocalMerge(shouldMergeLocal: Bool) async {
        defer {
            defaults.removeObject(forKey: localPreAuthBackupKey)
            pendingCloudDataForMerge = nil
            isShowingLocalMergePrompt = false
        }
        guard let uid = session?.user.id else { return }
        if shouldMergeLocal, let backupData = defaults.data(forKey: localPreAuthBackupKey),
           let localBucket = try? JSONDecoder().decode(ProfileVaultBucket.self, from: backupData) {
            mergeBucketIntoVault(localBucket, userId: uid, profileId: activeProfileId)
            loadProfileFromVaultIntoManagers(profileId: activeProfileId)
            await pushSyncNow()
        }
    }

    // MARK: - Vault Persistence Helpers

    private struct AccountVault: Codable {
        var profiles: [UserProfile]
        var profilesTs: Double
        var profileData: [String: ProfileVaultBucket]
    }

    private struct ProfileVaultBucket: Codable {
        var myList: [MyListItem]
        var history: [WatchItem]
        var continueWatching: [ContinueWatchingItem]
        var liked: [NFSavedTitle]
        var reminders: [NFReminder]
        var streamingProviderBaseURL: String?
        var accentColorHex: String?
        var hapticsEnabled: Bool?
        var updatedAt: Double
    }

    private func loadVault(for userId: String) -> AccountVault {
        if let data = defaults.data(forKey: accountVaultPrefix + userId),
           let vault = try? JSONDecoder().decode(AccountVault.self, from: data) {
            return vault
        }
        return AccountVault(profiles: [], profilesTs: 0, profileData: [:])
    }

    private func saveVault(_ vault: AccountVault, for userId: String) {
        if let data = try? JSONEncoder().encode(vault) {
            defaults.set(data, forKey: accountVaultPrefix + userId)
        }
    }

    private func snapshotPreAuthLocalDataIfNeeded(for userId: String) {
        let vaultExists = defaults.data(forKey: accountVaultPrefix + userId) != nil
        guard !vaultExists else { return }

        let bucket = extractCurrentManagersBucket()
        let hasData = !bucket.myList.isEmpty || !bucket.history.isEmpty || !bucket.continueWatching.isEmpty || !bucket.liked.isEmpty
        if hasData, let data = try? JSONEncoder().encode(bucket) {
            defaults.set(data, forKey: localPreAuthBackupKey)
        }
    }

    private func extractCurrentManagersBucket() -> ProfileVaultBucket {
        ProfileVaultBucket(
            myList: myListManager?.items ?? [],
            history: historyManager?.items ?? [],
            continueWatching: continueWatchingManager?.items ?? [],
            liked: libraryModel?.liked ?? [],
            reminders: libraryModel?.reminders ?? [],
            streamingProviderBaseURL: defaults.string(forKey: AppSettingsStorageKey.streamingProviderBaseURL),
            accentColorHex: defaults.string(forKey: AppSettingsStorageKey.accentColorHex),
            hapticsEnabled: defaults.object(forKey: "hapticsEnabled") as? Bool,
            updatedAt: Date().timeIntervalSince1970 * 1000
        )
    }

    private func saveCurrentActiveProfileToVault() {
        guard let uid = session?.user.id else { return }
        var vault = loadVault(for: uid)
        vault.profileData[activeProfileId] = extractCurrentManagersBucket()
        if !profiles.isEmpty {
            vault.profiles = profiles
        }
        saveVault(vault, for: uid)
    }

    private func persistProfilesMetadataToVault() {
        guard let uid = session?.user.id else { return }
        var vault = loadVault(for: uid)
        vault.profiles = profiles
        vault.profilesTs = Date().timeIntervalSince1970 * 1000
        saveVault(vault, for: uid)
    }

    private func removeProfileFromVault(profileId: String) {
        guard let uid = session?.user.id else { return }
        var vault = loadVault(for: uid)
        vault.profileData.removeValue(forKey: profileId)
        vault.profiles = profiles
        saveVault(vault, for: uid)
    }

    private func loadProfileFromVaultIntoManagers(profileId: String) {
        isHydratingProfile = true
        defer { isHydratingProfile = false }
        guard let uid = session?.user.id else { return }
        let vault = loadVault(for: uid)
        let bucket = vault.profileData[profileId]

        if let bucket {
            if let data = try? JSONEncoder().encode(bucket.myList) {
                defaults.set(data, forKey: "myListItems")
            }
            if let data = try? JSONEncoder().encode(bucket.history) {
                defaults.set(data, forKey: "recentlyWatchedItems")
            }
            if let data = try? JSONEncoder().encode(bucket.continueWatching) {
                defaults.set(data, forKey: "continueWatchingItems")
            }
            if let data = try? JSONEncoder().encode(bucket.liked) {
                defaults.set(data, forKey: "nf.likedTitles")
            }
            if let data = try? JSONEncoder().encode(bucket.reminders) {
                defaults.set(data, forKey: "nf.reminders")
            }
            if let provider = bucket.streamingProviderBaseURL {
                defaults.set(provider, forKey: AppSettingsStorageKey.streamingProviderBaseURL)
            }
            if let accent = bucket.accentColorHex {
                defaults.set(accent, forKey: AppSettingsStorageKey.accentColorHex)
            }
            if let haptics = bucket.hapticsEnabled {
                defaults.set(haptics, forKey: "hapticsEnabled")
            }
        } else {
            clearActiveRuntimeDataForAccountIsolation()
        }

        myListManager?.load()
        historyManager?.reloadFromDefaults()
        continueWatchingManager?.load()
        libraryModel?.reloadFromDefaults()
    }

    private func clearActiveRuntimeDataForAccountIsolation() {
        defaults.removeObject(forKey: "myListItems")
        defaults.removeObject(forKey: "recentlyWatchedItems")
        defaults.removeObject(forKey: "continueWatchingItems")
        defaults.removeObject(forKey: "nf.likedTitles")
        defaults.removeObject(forKey: "nf.reminders")

        myListManager?.load()
        historyManager?.reloadFromDefaults()
        continueWatchingManager?.load()
        libraryModel?.reloadFromDefaults()
    }

    private func mergeBucketIntoVault(_ incoming: ProfileVaultBucket, userId: String, profileId: String) {
        var vault = loadVault(for: userId)
        var target = vault.profileData[profileId] ?? ProfileVaultBucket(
            myList: [],
            history: [],
            continueWatching: [],
            liked: [],
            reminders: [],
            streamingProviderBaseURL: nil,
            accentColorHex: nil,
            hapticsEnabled: nil,
            updatedAt: Date().timeIntervalSince1970 * 1000
        )

        var seenList = Set(target.myList.map { "\($0.mediaType.rawValue)-\($0.tmdbId)" })
        for item in incoming.myList {
            let key = "\(item.mediaType.rawValue)-\(item.tmdbId)"
            if !seenList.contains(key) {
                target.myList.append(item)
                seenList.insert(key)
            }
        }

        var seenCW = Set(target.continueWatching.map { "\($0.type.rawValue)-\($0.tmdbId)" })
        for item in incoming.continueWatching {
            let key = "\(item.type.rawValue)-\(item.tmdbId)"
            if !seenCW.contains(key) {
                target.continueWatching.append(item)
                seenCW.insert(key)
            }
        }

        var seenHist = Set(target.history.map { "\($0.type.rawValue)-\($0.tmdbId)-\($0.season ?? 0)-\($0.episode ?? 0)" })
        for item in incoming.history {
            let key = "\(item.type.rawValue)-\(item.tmdbId)-\(item.season ?? 0)-\(item.episode ?? 0)"
            if !seenHist.contains(key) {
                target.history.append(item)
                seenHist.insert(key)
            }
        }

        var seenLiked = Set(target.liked.map(\.key))
        for item in incoming.liked where !seenLiked.contains(item.key) {
            target.liked.append(item)
            seenLiked.insert(item.key)
        }

        target.updatedAt = max(target.updatedAt, incoming.updatedAt)
        vault.profileData[profileId] = target
        saveVault(vault, for: userId)
    }

    private func applyRemoteDataToVault(_ remoteData: [String: Any], userId: String, mergeWithExistingLocal: Bool) {
        var vault = loadVault(for: userId)

        if let rawProfiles = remoteData["profiles"] as? [[String: Any]],
           let data = try? JSONSerialization.data(withJSONObject: rawProfiles),
           let decodedProfiles = try? JSONDecoder().decode([UserProfile].self, from: data),
           !decodedProfiles.isEmpty {
            let remoteTs = (remoteData["_profilesTs"] as? Double) ?? 0
            if vault.profiles.isEmpty || remoteTs >= vault.profilesTs {
                profiles = Self.sanitizeProfiles(decodedProfiles, fallbackName: session?.user.name ?? "Main")
                vault.profiles = profiles
                vault.profilesTs = remoteTs
            } else {
                profiles = vault.profiles
            }
        } else if vault.profiles.isEmpty {
            let fallbackName = session?.user.name ?? "Main"
            let mainProfile = UserProfile(
                id: "prof_main",
                name: fallbackName,
                avatarColor: "#E50914",
                isKids: false,
                createdAt: Date().timeIntervalSince1970 * 1000
            )
            profiles = [mainProfile]
            vault.profiles = profiles
        } else {
            profiles = vault.profiles
        }

        if let remoteProfileMap = remoteData["profileData"] as? [String: [String: Any]] {
            for (pid, rawBucket) in remoteProfileMap {
                let remoteBucket = decodeRemoteBucket(rawBucket)
                if mergeWithExistingLocal, let localBucket = vault.profileData[pid], localBucket.updatedAt > remoteBucket.updatedAt {
                    continue
                }
                vault.profileData[pid] = remoteBucket
            }
        }

        saveVault(vault, for: userId)
    }

    private func decodeRemoteBucket(_ raw: [String: Any]) -> ProfileVaultBucket {
        let savedMap = (raw["saved"] as? [String: [String: Any]]) ?? [:]
        let savedOrder = (raw["savedOrder"] as? [String]) ?? Array(savedMap.keys)
        var myList: [MyListItem] = []
        for key in savedOrder {
            if let entry = savedMap[key], let item = decodeMyListItem(from: entry, key: key) {
                myList.append(item)
            }
        }
        for (key, entry) in savedMap where !savedOrder.contains(key) {
            if let item = decodeMyListItem(from: entry, key: key) {
                myList.append(item)
            }
        }

        let rawHistory = (raw["history"] as? [[String: Any]]) ?? []
        var history: [WatchItem] = []
        var cwItems: [ContinueWatchingItem] = []
        let progressMap = (raw["progress"] as? [String: Any]) ?? [:]
        let dlTimes = (raw["_dlTimes"] as? [String: Any]) ?? [:]

        for entry in rawHistory {
            guard let idNum = entry["id"] else { continue }
            let idStr = "\(idNum)"
            let mediaTypeStr = (entry["media_type"] as? String) ?? "movie"
            let type: WatchType = mediaTypeStr == "tv" ? .tv : .movie
            let title = (entry["title"] as? String) ?? (entry["name"] as? String) ?? "Untitled"
            let poster = entry["poster_path"] as? String
            let season = entry["season"] as? Int
            let episode = entry["episode"] as? Int
            let epName = entry["episode_name"] as? String

            let url: URL? = type == .movie
                ? StreamingProviderURLBuilder.movieURL(tmdbId: Int(idStr) ?? 0)
                : StreamingProviderURLBuilder.tvURL(tmdbId: Int(idStr) ?? 0, season: season ?? 1, episode: episode ?? 1)
            guard let playableURL = url else { continue }

            history.append(WatchItem(
                type: type,
                title: title,
                tmdbId: idStr,
                season: season,
                episode: episode,
                episodeName: epName,
                posterPath: poster,
                generatedURL: playableURL
            ))

            let pk = type == .tv ? "tv_\(idStr)_s\(season ?? 1)_e\(episode ?? 1)" : "movie_\(idStr)"
            let posSec = (dlTimes["dlTime_" + pk] as? Double) ?? Double((dlTimes["dlTime_" + pk] as? Int) ?? 0)
            let pct = (progressMap[pk] as? Double) ?? Double((progressMap[pk] as? Int) ?? 0)
            let durSec: Double? = (posSec > 0 && pct > 0) ? (posSec / (pct / 100.0)) : nil

            if pct < 95 {
                cwItems.append(ContinueWatchingItem(
                    type: type,
                    title: title,
                    tmdbId: idStr,
                    season: season,
                    episode: episode,
                    episodeName: epName,
                    posterPath: poster,
                    playableURL: playableURL,
                    progressSeconds: posSec > 0 ? posSec : nil,
                    durationSeconds: durSec
                ))
            }
        }

        let prefs = (raw["playerPrefs"] as? [String: Any]) ?? [:]
        let provider = prefs["streamingProviderBaseURL"] as? String
        let accent = prefs["accentColorHex"] as? String
        let haptics = prefs["hapticsEnabled"] as? Bool
        let ts = (raw["_playerPrefsTs"] as? Double) ?? (raw["updatedAt"] as? Double) ?? 0

        return ProfileVaultBucket(
            myList: myList,
            history: history,
            continueWatching: cwItems,
            liked: [],
            reminders: [],
            streamingProviderBaseURL: provider,
            accentColorHex: accent,
            hapticsEnabled: haptics,
            updatedAt: ts
        )
    }

    private func decodeMyListItem(from entry: [String: Any], key: String) -> MyListItem? {
        let idInt: Int
        if let n = entry["id"] as? Int {
            idInt = n
        } else if let s = entry["id"] as? String, let n = Int(s) {
            idInt = n
        } else {
            return nil
        }
        let mediaStr = (entry["media_type"] as? String) ?? "movie"
        let type: MediaType = mediaStr == "tv" ? .tv : .movie
        let title = (entry["title"] as? String) ?? (entry["name"] as? String) ?? "Untitled"
        let poster = entry["poster_path"] as? String
        return MyListItem(mediaType: type, tmdbId: idInt, title: title, posterPath: poster, backdropPath: nil, overview: nil, year: nil, dateAdded: Date())
    }

    private func buildCloudPayload(for userId: String) -> [String: Any] {
        let vault = loadVault(for: userId)
        var profileDataDict: [String: Any] = [:]

        for (pid, bucket) in vault.profileData {
            var savedDict: [String: Any] = [:]
            var savedOrder: [String] = []
            for item in bucket.myList {
                let key = "\(item.mediaType.rawValue)_\(item.tmdbId)"
                savedOrder.append(key)
                var entry: [String: Any] = [
                    "id": item.tmdbId,
                    "media_type": item.mediaType.rawValue,
                    "title": item.title
                ]
                if let poster = item.posterPath, !poster.isEmpty {
                    entry["poster_path"] = poster
                }
                savedDict[key] = entry
            }

            var historyArr: [[String: Any]] = []
            for item in bucket.history {
                var row: [String: Any] = [
                    "id": Int(item.tmdbId) ?? 0,
                    "media_type": item.type.rawValue,
                    "title": item.title,
                    "watchedAt": Int(item.dateWatched.timeIntervalSince1970 * 1000)
                ]
                if let poster = item.posterPath { row["poster_path"] = poster }
                if let s = item.season { row["season"] = s }
                if let e = item.episode { row["episode"] = e }
                if let epName = item.episodeName { row["episode_name"] = epName }
                historyArr.append(row)
            }

            var progressDict: [String: Int] = [:]
            var dlTimesDict: [String: Int] = [:]
            for cw in bucket.continueWatching {
                let pk = cw.type == .tv ? "tv_\(cw.tmdbId)_s\(cw.season ?? 1)_e\(cw.episode ?? 1)" : "movie_\(cw.tmdbId)"
                if let frac = cw.progressFraction, frac.isFinite {
                    progressDict[pk] = max(1, min(100, Int(round(frac * 100))))
                }
                if let sec = cw.progressSeconds, sec.isFinite {
                    dlTimesDict["dlTime_" + pk] = Int(sec)
                }
            }

            var playerPrefs: [String: Any] = [:]
            if let provider = bucket.streamingProviderBaseURL { playerPrefs["streamingProviderBaseURL"] = provider }
            if let accent = bucket.accentColorHex { playerPrefs["accentColorHex"] = accent }
            if let haptics = bucket.hapticsEnabled { playerPrefs["hapticsEnabled"] = haptics }

            profileDataDict[pid] = [
                "saved": savedDict,
                "savedOrder": savedOrder,
                "history": historyArr,
                "progress": progressDict,
                "_dlTimes": dlTimesDict,
                "playerPrefs": playerPrefs,
                "_playerPrefsTs": bucket.updatedAt.isFinite ? bucket.updatedAt : 0
            ]
        }

        let encodedProfiles: [[String: Any]] = (try? JSONSerialization.jsonObject(
            with: JSONEncoder().encode(vault.profiles)
        ) as? [[String: Any]]) ?? []

        return [
            "profiles": encodedProfiles,
            "_profilesTs": vault.profilesTs.isFinite ? vault.profilesTs : 0,
            "profileData": profileDataDict
        ]
    }
}
