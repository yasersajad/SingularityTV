import Foundation

@MainActor
final class SingularityDiagnostics {
    static let shared = SingularityDiagnostics()

    struct Entry: Codable, Identifiable {
        let id: UUID
        let timestamp: Date
        let category: String
        let message: String
    }

    private(set) var entries: [Entry] = []
    private let maxEntries = 80
    private let storageKey = "singularity.diagnostics.log"

    private init() {
        if let data = UserDefaults.standard.data(forKey: storageKey),
           let decoded = try? JSONDecoder().decode([Entry].self, from: data) {
            entries = decoded
        }
    }

    func record(category: String, message: String) {
        let entry = Entry(id: UUID(), timestamp: Date(), category: category, message: message)
        entries.insert(entry, at: 0)
        if entries.count > maxEntries {
            entries = Array(entries.prefix(maxEntries))
        }
        if let data = try? JSONEncoder().encode(entries) {
            UserDefaults.standard.set(data, forKey: storageKey)
        }
    }

    func clear() {
        entries = []
        UserDefaults.standard.removeObject(forKey: storageKey)
    }

    func formattedReport() -> String {
        let formatter = ISO8601DateFormatter()
        return entries.map { "[\(formatter.string(from: $0.timestamp))] [\($0.category)] \($0.message)" }
            .joined(separator: "\n")
    }
}
