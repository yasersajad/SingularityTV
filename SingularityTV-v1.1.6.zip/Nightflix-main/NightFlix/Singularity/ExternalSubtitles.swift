import Foundation
import SwiftUI

struct SubtitleCue: Identifiable, Equatable, Sendable {
    let id: Int
    let start: Double
    let end: Double
    let text: String
}

struct ExternalSubtitleResult: Identifiable, Codable, Equatable, Sendable {
    let id: String
    let url: String
    let language: String
    let display: String
    let format: String?
    let isHearingImpaired: Bool?
    let source: String?

    enum CodingKeys: String, CodingKey {
        case id
        case url
        case language
        case display
        case format
        case isHearingImpaired
        case source
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        if let s = try? c.decode(String.self, forKey: .id) {
            id = s
        } else if let n = try? c.decode(Int.self, forKey: .id) {
            id = String(n)
        } else {
            id = UUID().uuidString
        }
        url = (try? c.decode(String.self, forKey: .url)) ?? ""
        language = (try? c.decode(String.self, forKey: .language)) ?? ""
        display = (try? c.decode(String.self, forKey: .display)) ?? "Subtitle"
        format = try? c.decodeIfPresent(String.self, forKey: .format)
        isHearingImpaired = try? c.decodeIfPresent(Bool.self, forKey: .isHearingImpaired)
        source = try? c.decodeIfPresent(String.self, forKey: .source)
    }
}

actor ExternalSubtitleService {
    static let shared = ExternalSubtitleService()

    private let session: URLSession = {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 15
        config.timeoutIntervalForResource = 25
        return URLSession(configuration: config)
    }()

    private func resolveImdbId(tmdbId: String, isSeries: Bool) async -> String? {
        let token = await MainActor.run { NightFlixUserConfiguration.effectiveTMDBCredential }
        let mediaPath = isSeries ? "tv" : "movie"
        guard let url = URL(string: "https://api.themoviedb.org/3/\(mediaPath)/\(tmdbId)/external_ids") else {
            return nil
        }
        var req = URLRequest(url: url)
        req.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        req.setValue("application/json", forHTTPHeaderField: "Accept")
        guard let (data, resp) = try? await session.data(for: req),
              let http = resp as? HTTPURLResponse, (200..<300).contains(http.statusCode),
              let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let imdb = json["imdb_id"] as? String, !imdb.isEmpty else {
            return nil
        }
        return imdb
    }

    private func matchesLanguage(code: String, filter: String) -> Bool {
        if filter.isEmpty || filter == "all" { return true }
        let c = code.lowercased()
        switch filter.lowercased() {
        case "ar": return c == "ar" || c == "ara" || c == "arabic"
        case "en": return c == "en" || c == "eng" || c == "english"
        case "fr": return c == "fr" || c == "fre" || c == "fra" || c == "french"
        case "es": return c == "es" || c == "spa" || c == "spanish"
        case "de": return c == "de" || c == "ger" || c == "deu" || c == "german"
        case "tr": return c == "tr" || c == "tur" || c == "turkish"
        case "ja": return c == "ja" || c == "jpn" || c == "japanese"
        case "ko": return c == "ko" || c == "kor" || c == "korean"
        default: return c.hasPrefix(filter.lowercased())
        }
    }

    func searchSubtitles(
        tmdbId: String,
        season: Int?,
        episode: Int?,
        language: String
    ) async throws -> [ExternalSubtitleResult] {
        let isSeries = season != nil && episode != nil
        guard let imdbId = await resolveImdbId(tmdbId: tmdbId, isSeries: isSeries) else {
            throw AuthFlowError.server("Could not resolve IMDb ID for external subtitles.")
        }

        let endpoint: String
        if let season, let episode {
            endpoint = "https://opensubtitles-v3.strem.io/subtitles/series/\(imdbId):\(season):\(episode).json"
        } else {
            endpoint = "https://opensubtitles-v3.strem.io/subtitles/movie/\(imdbId).json"
        }

        guard let url = URL(string: endpoint) else { throw URLError(.badURL) }
        var request = URLRequest(url: url)
        request.setValue("application/json", forHTTPHeaderField: "Accept")

        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode),
              let json = try? JSONSerialization.jsonObject(with: data) as? [String: Any],
              let rawSubs = json["subtitles"] as? [[String: Any]] else {
            throw AuthFlowError.server("External subtitle service is currently unavailable.")
        }

        var mapped: [ExternalSubtitleResult] = []
        for (idx, row) in rawSubs.enumerated() {
            guard let subUrl = row["url"] as? String, !subUrl.isEmpty else { continue }
            let lang = (row["lang"] as? String) ?? ""
            guard matchesLanguage(code: lang, filter: language) else { continue }
            let subId = (row["id"] as? String) ?? "os_\(idx)"
            let label = "\(lang.uppercased()) · OpenSubtitles #\(idx + 1)"
            let itemDict: [String: Any] = [
                "id": subId,
                "url": subUrl,
                "language": lang,
                "display": label,
                "format": "srt"
            ]
            if let itemData = try? JSONSerialization.data(withJSONObject: itemDict),
               let decoded = try? JSONDecoder().decode(ExternalSubtitleResult.self, from: itemData) {
                mapped.append(decoded)
            }
        }
        return mapped
    }

    func fetchAndParseSubtitles(from urlString: String, preferredLanguage: String? = nil) async throws -> [SubtitleCue] {
        try await SubtitleDownloadService.shared.downloadAndParse(
            urlString: urlString,
            preferredLanguage: preferredLanguage
        )
    }
}

struct ExternalSubtitleSearchSheet: View {
    let tmdbId: String
    let title: String
    let season: Int?
    let episode: Int?
    let hasActiveSubtitles: Bool
    @Binding var offsetSeconds: Double
    let onSelectCues: ([SubtitleCue], String) -> Void
    let onClearSubtitles: () -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var selectedLang = "ar"
    @State private var results: [ExternalSubtitleResult] = []
    @State private var isSearching = false
    @State private var isLoadingSubId: String?
    @State private var errorMessage: String?

    private let languages: [(code: String, label: String)] = [
        ("ar", "Arabic"),
        ("en", "English"),
        ("fr", "French"),
        ("es", "Spanish"),
        ("de", "German"),
        ("tr", "Turkish"),
        ("ja", "Japanese"),
        ("ko", "Korean"),
        ("all", "All Languages")
    ]

    var body: some View {
        NavigationStack {
            ZStack {
                Color(hex: "0B0B10").ignoresSafeArea()

                VStack(spacing: 14) {
                    if hasActiveSubtitles {
                        syncControlBar
                    }

                    languageBar

                    if let errorMessage {
                        Text(errorMessage)
                            .font(.footnote)
                            .foregroundStyle(Color(hex: "FF8C92"))
                            .padding(12)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(NightFlixStyle.accentColor.opacity(0.14), in: RoundedRectangle(cornerRadius: 10))
                            .padding(.horizontal, 16)
                    }

                    if isSearching {
                        Spacer()
                        ProgressView("Searching external subtitles...")
                            .tint(NightFlixStyle.accentColor)
                            .foregroundStyle(.white.opacity(0.75))
                        Spacer()
                    } else if results.isEmpty {
                        Spacer()
                        VStack(spacing: 8) {
                            Image(systemName: "captions.bubble")
                                .font(.system(size: 36))
                                .foregroundStyle(.white.opacity(0.4))
                            Text("No external subtitles found for this language.")
                                .font(.subheadline)
                                .foregroundStyle(.white.opacity(0.65))
                        }
                        Spacer()
                    } else {
                        List(results) { sub in
                            Button {
                                Task { await loadSubtitle(sub) }
                            } label: {
                                HStack(spacing: 12) {
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(sub.display)
                                            .font(.subheadline.weight(.semibold))
                                            .foregroundStyle(.white)
                                            .lineLimit(2)

                                        HStack(spacing: 8) {
                                            Text(sub.language.uppercased())
                                                .font(.caption2.weight(.bold))
                                                .padding(.horizontal, 6)
                                                .padding(.vertical, 2)
                                                .background(NightFlixStyle.accentColor.opacity(0.22), in: Capsule())
                                                .foregroundStyle(NightFlixStyle.accentColor)

                                            if let fmt = sub.format, !fmt.isEmpty {
                                                Text(fmt.uppercased())
                                                    .font(.caption2.weight(.semibold))
                                                    .foregroundStyle(.white.opacity(0.6))
                                            }

                                            if sub.isHearingImpaired == true {
                                                Text("HI")
                                                    .font(.caption2.weight(.bold))
                                                    .foregroundStyle(.white.opacity(0.6))
                                            }
                                        }
                                    }

                                    Spacer()

                                    if isLoadingSubId == sub.id {
                                        ProgressView().tint(.white)
                                    } else {
                                        Image(systemName: "arrow.down.circle")
                                            .font(.title3)
                                            .foregroundStyle(NightFlixStyle.accentColor)
                                    }
                                }
                                .padding(.vertical, 4)
                            }
                            .listRowBackground(Color.white.opacity(0.05))
                        }
                        .scrollContentBackground(.hidden)
                    }
                }
                .padding(.top, 8)
            }
            .navigationTitle("External Subtitles")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { dismiss() }
                }
                if hasActiveSubtitles {
                    ToolbarItem(placement: .destructiveAction) {
                        Button("Disable") {
                            onClearSubtitles()
                            dismiss()
                        }
                    }
                }
            }
            .task {
                await search()
            }
        }
        .preferredColorScheme(.dark)
    }

    private var syncControlBar: some View {
        HStack(spacing: 12) {
            Text("Sync Offset")
                .font(.caption.weight(.semibold))
                .foregroundStyle(.white.opacity(0.75))

            Spacer()

            Button {
                offsetSeconds = max(-15, offsetSeconds - 0.5)
            } label: {
                Image(systemName: "minus.circle.fill")
                    .font(.title3)
                    .foregroundStyle(.white)
            }
            .buttonStyle(.plain)

            Text(String(format: "%+.1fs", offsetSeconds))
                .font(.caption.weight(.bold).monospacedDigit())
                .foregroundStyle(NightFlixStyle.accentColor)
                .frame(minWidth: 52)

            Button {
                offsetSeconds = min(15, offsetSeconds + 0.5)
            } label: {
                Image(systemName: "plus.circle.fill")
                    .font(.title3)
                    .foregroundStyle(.white)
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 12))
        .padding(.horizontal, 16)
    }

    private var languageBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(languages, id: \.code) { lang in
                    let selected = selectedLang == lang.code
                    Button {
                        selectedLang = lang.code
                        Task { await search() }
                    } label: {
                        Text(lang.label)
                            .font(.caption.weight(.bold))
                            .foregroundStyle(selected ? .white : .white.opacity(0.7))
                            .padding(.horizontal, 12)
                            .padding(.vertical, 7)
                            .background(
                                selected ? NightFlixStyle.accentColor : Color.white.opacity(0.08),
                                in: Capsule()
                            )
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 16)
        }
    }

    private func search() async {
        isSearching = true
        errorMessage = nil
        do {
            results = try await ExternalSubtitleService.shared.searchSubtitles(
                tmdbId: tmdbId,
                season: season,
                episode: episode,
                language: selectedLang
            )
        } catch {
            errorMessage = error.localizedDescription
            results = []
        }
        isSearching = false
    }

    private func loadSubtitle(_ sub: ExternalSubtitleResult) async {
        isLoadingSubId = sub.id
        errorMessage = nil
        do {
            let cues = try await ExternalSubtitleService.shared.fetchAndParseSubtitles(from: sub.url, preferredLanguage: selectedLang)
            onSelectCues(cues, sub.display)
            dismiss()
        } catch {
            errorMessage = error.localizedDescription
        }
        isLoadingSubId = nil
    }
}
