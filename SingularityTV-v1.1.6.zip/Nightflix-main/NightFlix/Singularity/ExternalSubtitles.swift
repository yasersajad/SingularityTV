import Foundation
import SwiftUI

struct SubtitleCue: Identifiable, Equatable, Sendable {
    let id: Int
    let start: Double
    let end: Double
    let text: String
}

struct ExternalSubtitleResult: Identifiable, Codable, Equatable, Sendable {
    let id: String
    let url: String
    let language: String
    let display: String
    let format: String?
    let isHearingImpaired: Bool?
    let source: String?

    enum CodingKeys: String, CodingKey {
        case id
        case url
        case language
        case display
        case format
        case isHearingImpaired
        case source
    }

    init(from decoder: Decoder) throws {
        let c = try decoder.container(keyedBy: CodingKeys.self)
        if let s = try? c.decode(String.self, forKey: .id) {
            id = s
        } else if let n = try? c.decode(Int.self, forKey: .id) {
            id = String(n)
        } else {
            id = UUID().uuidString
        }
        url = (try? c.decode(String.self, forKey: .url)) ?? ""
        language = (try? c.decode(String.self, forKey: .language)) ?? ""
        display = (try? c.decode(String.self, forKey: .display)) ?? "Subtitle"
        format = try? c.decodeIfPresent(String.self, forKey: .format)
        isHearingImpaired = try? c.decodeIfPresent(Bool.self, forKey: .isHearingImpaired)
        source = try? c.decodeIfPresent(String.self, forKey: .source)
    }
}

actor ExternalSubtitleService {
    static let shared = ExternalSubtitleService()

    private let session: URLSession = {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 15
        config.timeoutIntervalForResource = 25
        return URLSession(configuration: config)
    }()

    func searchSubtitles(
        tmdbId: String,
        season: Int?,
        episode: Int?,
        language: String
    ) async throws -> [ExternalSubtitleResult] {
        var components = URLComponents(string: "https://sub.wyzie.ru/search")!
        var items = [URLQueryItem(name: "id", value: tmdbId)]
        if let season, let episode {
            items.append(URLQueryItem(name: "season", value: String(season)))
            items.append(URLQueryItem(name: "episode", value: String(episode)))
        }
        if !language.isEmpty && language != "all" {
            items.append(URLQueryItem(name: "language", value: language))
        }
        components.queryItems = items

        guard let url = components.url else {
            throw URLError(.badURL)
        }

        var request = URLRequest(url: url)
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let (data, response) = try await session.data(for: request)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw AuthFlowError.server("Subtitle search failed. Please try again.")
        }

        let decoded = try JSONDecoder().decode([ExternalSubtitleResult].self, from: data)
        return decoded.filter { !$0.url.isEmpty }
    }

    func fetchAndParseSubtitles(from urlString: String) async throws -> [SubtitleCue] {
        guard let url = URL(string: urlString) else {
            throw URLError(.badURL)
        }
        let (data, response) = try await session.data(from: url)
        guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
            throw AuthFlowError.server("Could not download subtitle file.")
        }

        let raw = String(data: data, encoding: .utf8)
            ?? String(data: data, encoding: .isoLatin1)
            ?? ""
        let cues = SubtitleParser.parse(raw)
        if cues.isEmpty {
            throw AuthFlowError.server("No readable subtitle cues found in this file.")
        }
        return cues
    }
}

enum SubtitleParser {
    static func parse(_ raw: String) -> [SubtitleCue] {
        let normalized = raw
            .replacingOccurrences(of: "\r\n", with: "\n")
            .replacingOccurrences(of: "\r", with: "\n")
            .trimmingCharacters(in: .whitespacesAndNewlines)

        let blocks = normalized.components(separatedBy: "\n\n")
        var cues: [SubtitleCue] = []
        var idx = 0

        for block in blocks {
            let lines = block
                .components(separatedBy: "\n")
                .map { $0.trimmingCharacters(in: .whitespaces) }
                .filter { !$0.isEmpty }

            guard let timeLineIndex = lines.firstIndex(where: { $0.contains("-->") }) else {
                continue
            }

            let timeLine = lines[timeLineIndex]
            let parts = timeLine.components(separatedBy: "-->")
            guard parts.count >= 2,
                  let start = parseTimestamp(parts[0]),
                  let end = parseTimestamp(parts[1].components(separatedBy: " ").first ?? parts[1]) else {
                continue
            }

            let textLines = lines.dropFirst(timeLineIndex + 1)
            let cleaned = cleanText(textLines.joined(separator: "\n"))
            guard !cleaned.isEmpty else { continue }

            idx += 1
            cues.append(SubtitleCue(id: idx, start: start, end: end, text: cleaned))
        }

        return cues.sorted { $0.start < $1.start }
    }

    static func activeCue(in cues: [SubtitleCue], at time: Double) -> SubtitleCue? {
        guard !cues.isEmpty else { return nil }
        var low = 0
        var high = cues.count - 1
        while low <= high {
            let mid = (low + high) / 2
            let cue = cues[mid]
            if time < cue.start {
                high = mid - 1
            } else if time > cue.end {
                low = mid + 1
            } else {
                return cue
            }
        }
        return nil
    }

    private static func parseTimestamp(_ raw: String) -> Double? {
        let clean = raw
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: ",", with: ".")
        let parts = clean.split(separator: ":").map(String.init)
        if parts.count == 3,
           let h = Double(parts[0]),
           let m = Double(parts[1]),
           let s = Double(parts[2]) {
            return h * 3600 + m * 60 + s
        } else if parts.count == 2,
                  let m = Double(parts[0]),
                  let s = Double(parts[1]) {
            return m * 60 + s
        }
        return nil
    }

    private static func cleanText(_ text: String) -> String {
        text
            .replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression)
            .replacingOccurrences(of: "\\{\\\\[^}]+\\}", with: "", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }
}

struct ExternalSubtitleSearchSheet: View {
    let tmdbId: String
    let title: String
    let season: Int?
    let episode: Int?
    let hasActiveSubtitles: Bool
    @Binding var offsetSeconds: Double
    let onSelectCues: ([SubtitleCue], String) -> Void
    let onClearSubtitles: () -> Void

    @Environment(\.dismiss) private var dismiss
    @State private var selectedLang = "ar"
    @State private var results: [ExternalSubtitleResult] = []
    @State private var isSearching = false
    @State private var isLoadingSubId: String?
    @State private var errorMessage: String?

    private let languages: [(code: String, label: String)] = [
        ("ar", "Arabic"),
        ("en", "English"),
        ("fr", "French"),
        ("es", "Spanish"),
        ("de", "German"),
        ("tr", "Turkish"),
        ("ja", "Japanese"),
        ("ko", "Korean"),
        ("all", "All Languages")
    ]

    var body: some View {
        NavigationStack {
            ZStack {
                Color(hex: "0B0B10").ignoresSafeArea()

                VStack(spacing: 14) {
                    if hasActiveSubtitles {
                        syncControlBar
                    }

                    languageBar

                    if let errorMessage {
                        Text(errorMessage)
                            .font(.footnote)
                            .foregroundStyle(Color(hex: "FF8C92"))
                            .padding(12)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(NightFlixStyle.accentColor.opacity(0.14), in: RoundedRectangle(cornerRadius: 10))
                            .padding(.horizontal, 16)
                    }

                    if isSearching {
                        Spacer()
                        ProgressView("Searching external subtitles...")
                            .tint(NightFlixStyle.accentColor)
                            .foregroundStyle(.white.opacity(0.75))
                        Spacer()
                    } else if results.isEmpty {
                        Spacer()
                        VStack(spacing: 8) {
                            Image(systemName: "captions.bubble")
                                .font(.system(size: 36))
                                .foregroundStyle(.white.opacity(0.4))
                            Text("No external subtitles found for this language.")
                                .font(.subheadline)
                                .foregroundStyle(.white.opacity(0.65))
                        }
                        Spacer()
                    } else {
                        List(results) { sub in
                            Button {
                                Task { await loadSubtitle(sub) }
                            } label: {
                                HStack(spacing: 12) {
                                    VStack(alignment: .leading, spacing: 4) {
                                        Text(sub.display)
                                            .font(.subheadline.weight(.semibold))
                                            .foregroundStyle(.white)
                                            .lineLimit(2)

                                        HStack(spacing: 8) {
                                            Text(sub.language.uppercased())
                                                .font(.caption2.weight(.bold))
                                                .padding(.horizontal, 6)
                                                .padding(.vertical, 2)
                                                .background(NightFlixStyle.accentColor.opacity(0.22), in: Capsule())
                                                .foregroundStyle(NightFlixStyle.accentColor)

                                            if let fmt = sub.format, !fmt.isEmpty {
                                                Text(fmt.uppercased())
                                                    .font(.caption2.weight(.semibold))
                                                    .foregroundStyle(.white.opacity(0.6))
                                            }

                                            if sub.isHearingImpaired == true {
                                                Text("HI")
                                                    .font(.caption2.weight(.bold))
                                                    .foregroundStyle(.white.opacity(0.6))
                                            }
                                        }
                                    }

                                    Spacer()

                                    if isLoadingSubId == sub.id {
                                        ProgressView().tint(.white)
                                    } else {
                                        Image(systemName: "arrow.down.circle")
                                            .font(.title3)
                                            .foregroundStyle(NightFlixStyle.accentColor)
                                    }
                                }
                                .padding(.vertical, 4)
                            }
                            .listRowBackground(Color.white.opacity(0.05))
                        }
                        .scrollContentBackground(.hidden)
                    }
                }
                .padding(.top, 8)
            }
            .navigationTitle("External Subtitles")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { dismiss() }
                }
                if hasActiveSubtitles {
                    ToolbarItem(placement: .destructiveAction) {
                        Button("Disable") {
                            onClearSubtitles()
                            dismiss()
                        }
                    }
                }
            }
            .task {
                await search()
            }
        }
        .preferredColorScheme(.dark)
    }

    private var syncControlBar: some View {
        HStack(spacing: 12) {
            Text("Sync Offset")
                .font(.caption.weight(.semibold))
                .foregroundStyle(.white.opacity(0.75))

            Spacer()

            Button {
                offsetSeconds = max(-15, offsetSeconds - 0.5)
            } label: {
                Image(systemName: "minus.circle.fill")
                    .font(.title3)
                    .foregroundStyle(.white)
            }
            .buttonStyle(.plain)

            Text(String(format: "%+.1fs", offsetSeconds))
                .font(.caption.weight(.bold).monospacedDigit())
                .foregroundStyle(NightFlixStyle.accentColor)
                .frame(minWidth: 52)

            Button {
                offsetSeconds = min(15, offsetSeconds + 0.5)
            } label: {
                Image(systemName: "plus.circle.fill")
                    .font(.title3)
                    .foregroundStyle(.white)
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 14)
        .padding(.vertical, 10)
        .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 12))
        .padding(.horizontal, 16)
    }

    private var languageBar: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 8) {
                ForEach(languages, id: \.code) { lang in
                    let selected = selectedLang == lang.code
                    Button {
                        selectedLang = lang.code
                        Task { await search() }
                    } label: {
                        Text(lang.label)
                            .font(.caption.weight(.bold))
                            .foregroundStyle(selected ? .white : .white.opacity(0.7))
                            .padding(.horizontal, 12)
                            .padding(.vertical, 7)
                            .background(
                                selected ? NightFlixStyle.accentColor : Color.white.opacity(0.08),
                                in: Capsule()
                            )
                    }
                    .buttonStyle(.plain)
                }
            }
            .padding(.horizontal, 16)
        }
    }

    private func search() async {
        isSearching = true
        errorMessage = nil
        do {
            results = try await ExternalSubtitleService.shared.searchSubtitles(
                tmdbId: tmdbId,
                season: season,
                episode: episode,
                language: selectedLang
            )
        } catch {
            errorMessage = error.localizedDescription
            results = []
        }
        isSearching = false
    }

    private func loadSubtitle(_ sub: ExternalSubtitleResult) async {
        isLoadingSubId = sub.id
        errorMessage = nil
        do {
            let cues = try await ExternalSubtitleService.shared.fetchAndParseSubtitles(from: sub.url)
            onSelectCues(cues, sub.display)
            dismiss()
        } catch {
            errorMessage = error.localizedDescription
        }
        isLoadingSubId = nil
    }
}
