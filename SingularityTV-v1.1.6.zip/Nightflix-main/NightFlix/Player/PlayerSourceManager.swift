import Foundation

@MainActor
enum PlayerSourceManager {
    static func buildURL(
        for item: WatchItem,
        serverHost: String? = nil,
        season: Int? = nil,
        episode: Int? = nil,
        progressSeconds: Int? = nil
    ) -> URL? {
        guard let tmdbInt = Int(item.tmdbId), tmdbInt > 0 else {
            return item.generatedURL
        }
        let host = serverHost ?? NightFlixUserConfiguration.effectiveStreamingProviderBaseURL
        return StreamingProviderURLBuilder.buildURL(
            baseURL: host,
            type: item.type,
            tmdbId: tmdbInt,
            season: season ?? item.season,
            episode: episode ?? item.episode,
            progressSeconds: progressSeconds
        )
    }
}
