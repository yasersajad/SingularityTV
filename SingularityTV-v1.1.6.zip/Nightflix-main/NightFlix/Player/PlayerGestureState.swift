import Foundation
import Observation

enum ActiveGestureMode: Equatable, Sendable {
    case none
    case scrubbing
    case brightness
    case volume
    case holdSpeed2x
    case holdSeekForward
    case holdSeekBackward
}

@MainActor
@Observable
final class PlayerGestureState {
    var activeMode: ActiveGestureMode = .none

    var scrubStartTime: Double = 0
    var scrubTargetTime: Double = 0
    var scrubDeltaSeconds: Double = 0

    var brightnessLevel: Double = 0.5
    var showBrightnessHUD = false

    var volumeLevel: Double = 0.5
    var showVolumeHUD = false

    var isHold2xActive = false
    var previousPlaybackRate: Double = 1.0

    var holdSeekStartTime: Double = 0
    var holdSeekTargetTime: Double = 0
    var holdSeekAccumulated: Double = 0
    var holdSeekSpeedMultiplier: Double = 1.0
    var holdSeekRingProgress: Double = 0
    var holdSeekIsForward = true
    var showHoldSeekHUD = false
}
