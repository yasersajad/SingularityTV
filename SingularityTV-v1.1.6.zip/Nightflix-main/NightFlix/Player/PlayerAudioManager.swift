import Foundation
import Observation

@MainActor
@Observable
final class PlayerAudioManager {
    var tracks: [InPlayerAudioTrack] = []
    var switchState: AudioSwitchState = .idle
    var discoverySource: String?
    @ObservationIgnored private var switchGeneration: Int = 0

    var supportsAudioDiscovery: Bool {
        !tracks.isEmpty
    }

    var supportsExternalAudioSelection: Bool {
        tracks.contains { $0.availability == .selectable }
    }

    var activeTrack: InPlayerAudioTrack? {
        tracks.first(where: \.isSelected)
    }

    func reset() {
        switchGeneration &+= 1
        tracks = []
        switchState = .idle
        discoverySource = nil
    }

    func updateDiscoveredTracks(_ rawTracks: [InPlayerAudioTrack], source: String? = nil) {
        guard !rawTracks.isEmpty else { return }

        var counts: [String: Int] = [:]
        var unknownIndex = 0
        var resolvedList: [InPlayerAudioTrack] = []

        for raw in rawTracks {
            let resolved = SubtitleLanguageResolver.resolveFromMetadata(
                serverCode: raw.languageCode,
                sourceLabel: raw.displayName
            )
            let baseName: String
            if resolved.isKnown {
                baseName = resolved.name
            } else {
                unknownIndex += 1
                baseName = "Unknown Audio Track \(unknownIndex)"
            }
            counts[baseName, default: 0] += 1
            resolvedList.append(
                InPlayerAudioTrack(
                    trackId: raw.trackId,
                    nativeIndex: raw.nativeIndex,
                    languageCode: resolved.isKnown ? resolved.code : raw.languageCode,
                    languageName: resolved.isKnown ? resolved.name : "Unknown Language",
                    displayName: baseName,
                    trackType: raw.trackType,
                    codec: raw.codec,
                    channelLayout: raw.channelLayout,
                    isDefault: raw.isDefault,
                    isSelected: raw.isSelected,
                    sourceIdentifier: raw.sourceIdentifier,
                    availability: raw.availability
                )
            )
        }

        var seen: [String: Int] = [:]
        let finalized = resolvedList.map { track -> InPlayerAudioTrack in
            guard track.languageName != "Unknown Language", (counts[track.displayName] ?? 0) > 1 else {
                return track
            }
            seen[track.displayName, default: 0] += 1
            let numbered = "\(track.displayName) \(seen[track.displayName, default: 1])"
            return InPlayerAudioTrack(
                trackId: track.trackId,
                nativeIndex: track.nativeIndex,
                languageCode: track.languageCode,
                languageName: track.languageName,
                displayName: numbered,
                trackType: track.trackType,
                codec: track.codec,
                channelLayout: track.channelLayout,
                isDefault: track.isDefault,
                isSelected: track.isSelected,
                sourceIdentifier: track.sourceIdentifier,
                availability: track.availability
            )
        }

        tracks = finalized
        if let source {
            discoverySource = source
        }
    }

    func selectTrack(_ track: InPlayerAudioTrack, bridge: PlayerBridgeController) async -> Bool {
        guard track.availability == .selectable else {
            switchState = .failed("This stream does not allow switching audio tracks externally.")
            return false
        }

        switchGeneration &+= 1
        let gen = switchGeneration
        switchState = .switching(track.displayName)

        let ok = await bridge.selectAudioTrackAndVerify(track: track)
        guard gen == switchGeneration else { return false }

        if ok {
            tracks = tracks.map { item in
                var updated = item
                updated.isSelected = (item.trackId == track.trackId)
                return updated
            }
            switchState = .switched(track.displayName)
            return true
        } else {
            switchState = .failed("Could not switch audio to \(track.displayName). The active audio track was kept.")
            return false
        }
    }
}
