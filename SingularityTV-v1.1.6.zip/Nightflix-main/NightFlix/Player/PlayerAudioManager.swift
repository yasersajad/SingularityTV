import Foundation
import Observation

struct InPlayerAudioTrack: Identifiable, Equatable, Sendable {
    let id: Int
    let label: String
    let language: String
    let isEnabled: Bool
}

@MainActor
@Observable
final class PlayerAudioManager {
    var tracks: [InPlayerAudioTrack] = []

    var supportsExternalAudioSelection: Bool {
        !tracks.isEmpty
    }
}
