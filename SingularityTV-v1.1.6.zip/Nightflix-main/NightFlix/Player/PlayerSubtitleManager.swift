import Foundation
import Observation
import SwiftUI

struct InPlayerSubtitleTrack: Identifiable, Equatable, Sendable {
    let id: Int
    let label: String
    let language: String
    let isActive: Bool
}

enum SubtitleTrackSource: String, Equatable, Sendable {
    case none
    case inStream
    case siteFile
    case external
}

enum SubtitleActivationState: Equatable, Sendable {
    case off
    case loading(String)
    case active(id: String, name: String, source: SubtitleTrackSource)
    case failed(String)
}

enum SubtitleBgStyle: String, CaseIterable, Codable, Identifiable {
    case dark = "Dark Box"
    case translucent = "Translucent"
    case none = "No Background"

    var id: String { rawValue }
}

struct SubtitleStylePrefs: Codable, Equatable {
    var fontSize: Double = 17
    var textColorHex: String = "FFFFFF"
    var bgStyle: SubtitleBgStyle = .dark
    var bottomOffset: Double = 54

    static let colorPresets: [(name: String, hex: String)] = [
        ("White", "FFFFFF"),
        ("Yellow", "FACC15"),
        ("Cyan", "38BDF8")
    ]
}

@MainActor
@Observable
final class PlayerSubtitleManager {
    var inPlayerTracks: [InPlayerSubtitleTrack] = []
    var discoveredSiteSubtitles: [DiscoveredSiteSubtitle] = []
    var externalCues: [SubtitleCue] = []
    var externalTrackName: String?
    var activeTrackId: String?
    var activeSource: SubtitleTrackSource = .none
    var activationState: SubtitleActivationState = .off
    var offsetSeconds: Double = 0
    var stylePrefs: SubtitleStylePrefs = SubtitleStylePrefs()

    @ObservationIgnored private var requestGeneration: Int = 0
    private let styleKeyPrefix = "singularity.subtitleStyle."

    func loadStyle(for profileId: String) {
        if let data = UserDefaults.standard.data(forKey: styleKeyPrefix + profileId),
           let decoded = try? JSONDecoder().decode(SubtitleStylePrefs.self, from: data) {
            stylePrefs = decoded
        } else {
            stylePrefs = SubtitleStylePrefs()
        }
    }

    func saveStyle(for profileId: String) {
        if let data = try? JSONEncoder().encode(stylePrefs) {
            UserDefaults.standard.set(data, forKey: styleKeyPrefix + profileId)
        }
    }

    var hasActiveExternalSubtitles: Bool {
        !externalCues.isEmpty && (activeSource == .external || activeSource == .siteFile)
    }

    var isAllOff: Bool {
        !hasActiveExternalSubtitles && !inPlayerTracks.contains(where: \.isActive)
    }

    func activeCue(at playbackTime: Double) -> SubtitleCue? {
        guard hasActiveExternalSubtitles else { return nil }
        return SubtitleParser.activeCue(in: externalCues, at: playbackTime + offsetSeconds)
    }

    func addDiscoveredSiteSubtitle(_ sub: DiscoveredSiteSubtitle) {
        if let idx = discoveredSiteSubtitles.firstIndex(where: { $0.url == sub.url }) {
            if discoveredSiteSubtitles[idx].label.contains(".srt") && !sub.label.contains(".srt") {
                discoveredSiteSubtitles[idx] = sub
            }
            return
        }
        discoveredSiteSubtitles.append(sub)
    }

    func setExternalSubtitles(cues: [SubtitleCue], name: String, trackId: String = "external", source: SubtitleTrackSource = .external) {
        requestGeneration &+= 1
        externalCues = cues
        externalTrackName = name
        activeTrackId = trackId
        activeSource = source
        activationState = .active(id: trackId, name: name, source: source)
        offsetSeconds = 0
    }

    func activateSubtitleFromURL(
        id: String,
        url: String,
        name: String,
        language: String?,
        source: SubtitleTrackSource,
        referer: String?,
        bridge: PlayerBridgeController
    ) async -> Bool {
        requestGeneration &+= 1
        let gen = requestGeneration
        activationState = .loading(name)

        do {
            let cues = try await SubtitleDownloadService.shared.downloadAndParse(
                urlString: url,
                preferredLanguage: language,
                referer: referer
            )
            guard gen == requestGeneration else { return false }
            externalCues = cues
            externalTrackName = name
            activeTrackId = id
            activeSource = source
            activationState = .active(id: id, name: name, source: source)
            offsetSeconds = 0
            bridge.selectTextTrack(index: nil)
            return true
        } catch {
            guard gen == requestGeneration else { return false }
            activationState = .failed(error.localizedDescription)
            return false
        }
    }

    func activateInStreamTrack(id: Int, name: String, bridge: PlayerBridgeController) {
        requestGeneration &+= 1
        let gen = requestGeneration
        activationState = .loading(name)
        bridge.selectTextTrack(index: id) { [weak self] ok in
            guard let self, gen == self.requestGeneration else { return }
            if ok {
                self.externalCues = []
                self.externalTrackName = nil
                self.activeTrackId = "instream_\(id)"
                self.activeSource = .inStream
                self.activationState = .active(id: "instream_\(id)", name: name, source: .inStream)
            } else {
                self.activationState = .failed("Could not switch to track \(name).")
            }
        }
    }

    func disableAll(bridge: PlayerBridgeController) {
        requestGeneration &+= 1
        externalCues = []
        externalTrackName = nil
        activeTrackId = nil
        activeSource = .none
        activationState = .off
        offsetSeconds = 0
        bridge.selectTextTrack(index: nil)
    }

    func clearExternalSubtitles() {
        requestGeneration &+= 1
        externalCues = []
        externalTrackName = nil
        if activeSource == .external || activeSource == .siteFile {
            activeTrackId = nil
            activeSource = .none
            activationState = .off
        }
        offsetSeconds = 0
    }
}
