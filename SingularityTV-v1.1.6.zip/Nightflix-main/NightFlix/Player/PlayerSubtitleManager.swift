import Foundation
import Observation
import SwiftUI

struct InPlayerSubtitleTrack: Identifiable, Equatable, Sendable {
    let trackId: String
    let nativeIndex: Int
    let label: String
    let language: String
    let resolvedLanguageName: String
    let isActive: Bool

    var id: String { trackId }
}

enum SubtitleTrackSource: String, Equatable, Sendable {
    case none
    case inStream
    case siteFile
    case external
}

enum SubtitleActivationState: Equatable, Sendable {
    case off
    case loading(String)
    case active(id: String, name: String, source: SubtitleTrackSource)
    case failed(String)
}

enum SubtitleBgStyle: String, CaseIterable, Codable, Identifiable {
    case dark = "Dark Box"
    case translucent = "Translucent"
    case none = "No Background"

    var id: String { rawValue }
}

struct SubtitleStylePrefs: Codable, Equatable {
    var fontSize: Double = 17
    var textColorHex: String = "FFFFFF"
    var bgStyle: SubtitleBgStyle = .dark
    var positionPercent: Double = 88
    var bottomOffset: Double = 54

    static let defaultPositionPercent: Double = 88

    static let colorPresets: [(name: String, hex: String)] = [
        ("White", "FFFFFF"),
        ("Yellow", "FACC15"),
        ("Cyan", "38BDF8")
    ]
}

@MainActor
@Observable
final class PlayerSubtitleManager {
    var inPlayerTracks: [InPlayerSubtitleTrack] = []
    var discoveredSiteSubtitles: [DiscoveredSiteSubtitle] = []
    var externalCues: [SubtitleCue] = []
    var externalTrackName: String?
    var activeTrackId: String?
    var activeSource: SubtitleTrackSource = .none
    var activationState: SubtitleActivationState = .off
    var offsetSeconds: Double = 0
    var stylePrefs: SubtitleStylePrefs = SubtitleStylePrefs()

    @ObservationIgnored private var requestGeneration: Int = 0
    @ObservationIgnored private var sessionGeneration: Int = 0
    @ObservationIgnored private var resolvedContentLanguages: [String: ResolvedLanguageResult] = [:]
    @ObservationIgnored private var peekingURLs: Set<String> = []
    private let styleKeyPrefix = "singularity.subtitleStyle."

    func loadStyle(for profileId: String) {
        if let data = UserDefaults.standard.data(forKey: styleKeyPrefix + profileId),
           let decoded = try? JSONDecoder().decode(SubtitleStylePrefs.self, from: data) {
            stylePrefs = decoded
        } else {
            stylePrefs = SubtitleStylePrefs()
        }
    }

    func saveStyle(for profileId: String) {
        if let data = try? JSONEncoder().encode(stylePrefs) {
            UserDefaults.standard.set(data, forKey: styleKeyPrefix + profileId)
        }
    }

    var hasActiveExternalSubtitles: Bool {
        !externalCues.isEmpty && (activeSource == .external || activeSource == .siteFile)
    }

    var isAllOff: Bool {
        !hasActiveExternalSubtitles && !inPlayerTracks.contains(where: \.isActive) && activeSource == .none
    }

    func activeCue(at playbackTime: Double) -> SubtitleCue? {
        guard hasActiveExternalSubtitles else { return nil }
        return SubtitleParser.activeCue(in: externalCues, at: playbackTime + offsetSeconds)
    }

    func resetForNewMedia() {
        sessionGeneration &+= 1
        requestGeneration &+= 1
        inPlayerTracks = []
        discoveredSiteSubtitles = []
        resolvedContentLanguages = [:]
        peekingURLs = []
        externalCues = []
        externalTrackName = nil
        activeTrackId = nil
        activeSource = .none
        activationState = .off
        offsetSeconds = 0
    }

    func updateInPlayerTracks(_ rawTracks: [InPlayerSubtitleTrack]) {
        let resolved = rawTracks.map { t -> InPlayerSubtitleTrack in
            let r = SubtitleLanguageResolver.resolveFromMetadata(
                serverCode: t.language,
                sourceLabel: t.label
            )
            let name = r.isKnown ? r.name : "Unknown Language"
            return InPlayerSubtitleTrack(
                trackId: t.trackId,
                nativeIndex: t.nativeIndex,
                label: t.label,
                language: r.isKnown ? r.code : t.language,
                resolvedLanguageName: name,
                isActive: t.isActive
            )
        }
        inPlayerTracks = numberDuplicateInPlayerTracks(resolved)
    }

    func addDiscoveredSiteSubtitle(_ sub: DiscoveredSiteSubtitle, referer: String?) {
        let initialResolved = resolvedContentLanguages[sub.url] ?? SubtitleLanguageResolver.resolveFromMetadata(
            serverCode: sub.language,
            sourceLabel: sub.label,
            filename: sub.originalFilename
        )

        let updatedSub = DiscoveredSiteSubtitle(
            url: sub.url,
            label: sub.label,
            language: initialResolved.isKnown ? initialResolved.code : sub.language,
            originalFilename: sub.originalFilename,
            resolvedLanguageName: initialResolved.isKnown ? initialResolved.name : "Unknown Language",
            displayTitle: initialResolved.isKnown ? initialResolved.name : "Unknown Language"
        )

        if let idx = discoveredSiteSubtitles.firstIndex(where: { $0.url == sub.url }) {
            if !discoveredSiteSubtitles[idx].isLanguageKnown && updatedSub.isLanguageKnown {
                discoveredSiteSubtitles[idx] = updatedSub
                renumberSiteSubtitles()
            }
        } else {
            discoveredSiteSubtitles.append(updatedSub)
            renumberSiteSubtitles()
        }

        if !initialResolved.isKnown && !peekingURLs.contains(sub.url) {
            peekingURLs.insert(sub.url)
            let capturedSession = sessionGeneration
            Task { [weak self] in
                guard let detected = await SubtitleDownloadService.shared.peekLanguage(urlString: sub.url, referer: referer) else {
                    return
                }
                await MainActor.run {
                    guard let self, self.sessionGeneration == capturedSession else { return }
                    self.resolvedContentLanguages[sub.url] = detected
                    if detected.isKnown, let idx = self.discoveredSiteSubtitles.firstIndex(where: { $0.url == sub.url }) {
                        let existing = self.discoveredSiteSubtitles[idx]
                        self.discoveredSiteSubtitles[idx] = DiscoveredSiteSubtitle(
                            url: existing.url,
                            label: existing.label,
                            language: detected.code,
                            originalFilename: existing.originalFilename,
                            resolvedLanguageName: detected.name,
                            displayTitle: detected.name
                        )
                        self.renumberSiteSubtitles()
                    }
                }
            }
        }
    }

    private func renumberSiteSubtitles() {
        var counts: [String: Int] = [:]
        for s in discoveredSiteSubtitles {
            counts[s.resolvedLanguageName, default: 0] += 1
        }
        var seen: [String: Int] = [:]
        discoveredSiteSubtitles = discoveredSiteSubtitles.map { s in
            let base = s.resolvedLanguageName
            let title: String
            if (counts[base] ?? 0) > 1 {
                seen[base, default: 0] += 1
                title = "\(base) \(seen[base, default: 1])"
            } else {
                title = base
            }
            return DiscoveredSiteSubtitle(
                url: s.url,
                label: s.label,
                language: s.language,
                originalFilename: s.originalFilename,
                resolvedLanguageName: s.resolvedLanguageName,
                displayTitle: title
            )
        }
    }

    private func numberDuplicateInPlayerTracks(_ list: [InPlayerSubtitleTrack]) -> [InPlayerSubtitleTrack] {
        var counts: [String: Int] = [:]
        for t in list {
            counts[t.resolvedLanguageName, default: 0] += 1
        }
        var seen: [String: Int] = [:]
        return list.map { t in
            let base = t.resolvedLanguageName
            let title: String
            if (counts[base] ?? 0) > 1 {
                seen[base, default: 0] += 1
                title = "\(base) \(seen[base, default: 1])"
            } else {
                title = base
            }
            return InPlayerSubtitleTrack(
                trackId: t.trackId,
                nativeIndex: t.nativeIndex,
                label: title,
                language: t.language,
                resolvedLanguageName: t.resolvedLanguageName,
                isActive: t.isActive
            )
        }
    }

    func setExternalSubtitles(cues: [SubtitleCue], name: String, trackId: String = "external", source: SubtitleTrackSource = .external) {
        requestGeneration &+= 1
        externalCues = cues
        externalTrackName = name
        activeTrackId = trackId
        activeSource = source
        activationState = .active(id: trackId, name: name, source: source)
        offsetSeconds = 0
    }

    func activateSubtitleFromURL(
        id: String,
        url: String,
        name: String,
        language: String?,
        source: SubtitleTrackSource,
        referer: String?,
        bridge: PlayerBridgeController
    ) async -> Bool {
        requestGeneration &+= 1
        let gen = requestGeneration
        let sess = sessionGeneration
        activationState = .loading(name)

        do {
            let result = try await SubtitleDownloadService.shared.downloadAndParseWithLanguage(
                urlString: url,
                preferredLanguage: language,
                referer: referer
            )
            guard gen == requestGeneration, sess == sessionGeneration else { return false }

            let finalName: String
            if name == "Unknown Language" || SubtitleLanguageResolver.isRandomHashFilename(name), result.detectedLanguage.isKnown {
                finalName = result.detectedLanguage.name
                resolvedContentLanguages[url] = result.detectedLanguage
                if let idx = discoveredSiteSubtitles.firstIndex(where: { $0.url == url }) {
                    let existing = discoveredSiteSubtitles[idx]
                    discoveredSiteSubtitles[idx] = DiscoveredSiteSubtitle(
                        url: existing.url,
                        label: existing.label,
                        language: result.detectedLanguage.code,
                        originalFilename: existing.originalFilename,
                        resolvedLanguageName: result.detectedLanguage.name,
                        displayTitle: result.detectedLanguage.name
                    )
                    renumberSiteSubtitles()
                }
            } else {
                finalName = name
            }

            externalCues = result.cues
            externalTrackName = finalName
            activeTrackId = id
            activeSource = source
            activationState = .active(id: id, name: finalName, source: source)
            offsetSeconds = 0
            bridge.selectTextTrack(index: nil)
            return true
        } catch {
            guard gen == requestGeneration, sess == sessionGeneration else { return false }
            activationState = .failed(error.localizedDescription)
            return false
        }
    }

    func activateInStreamTrack(track: InPlayerSubtitleTrack, bridge: PlayerBridgeController) async -> Bool {
        requestGeneration &+= 1
        let gen = requestGeneration
        let sess = sessionGeneration
        activationState = .loading(track.label)

        let ok = await bridge.selectTextTrackAndVerify(index: track.nativeIndex)
        guard gen == requestGeneration, sess == sessionGeneration else { return false }

        if ok {
            externalCues = []
            externalTrackName = nil
            activeTrackId = track.trackId
            activeSource = .inStream
            inPlayerTracks = inPlayerTracks.map { item in
                InPlayerSubtitleTrack(
                    trackId: item.trackId,
                    nativeIndex: item.nativeIndex,
                    label: item.label,
                    language: item.language,
                    resolvedLanguageName: item.resolvedLanguageName,
                    isActive: item.trackId == track.trackId
                )
            }
            activationState = .active(id: track.trackId, name: track.label, source: .inStream)
            return true
        } else {
            activationState = .failed("Could not activate \(track.label) on this player.")
            return false
        }
    }

    func disableAll(bridge: PlayerBridgeController) {
        requestGeneration &+= 1
        externalCues = []
        externalTrackName = nil
        activeTrackId = nil
        activeSource = .none
        activationState = .off
        offsetSeconds = 0
        inPlayerTracks = inPlayerTracks.map { item in
            InPlayerSubtitleTrack(
                trackId: item.trackId,
                nativeIndex: item.nativeIndex,
                label: item.label,
                language: item.language,
                resolvedLanguageName: item.resolvedLanguageName,
                isActive: false
            )
        }
        bridge.selectTextTrack(index: nil)
    }

    func clearExternalSubtitles() {
        requestGeneration &+= 1
        externalCues = []
        externalTrackName = nil
        if activeSource == .external || activeSource == .siteFile {
            activeTrackId = nil
            activeSource = .none
            activationState = .off
        }
        offsetSeconds = 0
    }
}
