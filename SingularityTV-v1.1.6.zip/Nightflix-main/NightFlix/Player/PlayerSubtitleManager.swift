import Foundation
import Observation
import SwiftUI

struct InPlayerSubtitleTrack: Identifiable, Equatable, Sendable {
    let id: Int
    let label: String
    let language: String
    let isActive: Bool
}

enum SubtitleBgStyle: String, CaseIterable, Codable, Identifiable {
    case dark = "Dark Box"
    case translucent = "Translucent"
    case none = "No Background"

    var id: String { rawValue }
}

struct SubtitleStylePrefs: Codable, Equatable {
    var fontSize: Double = 17
    var textColorHex: String = "FFFFFF"
    var bgStyle: SubtitleBgStyle = .dark
    var bottomOffset: Double = 54

    static let colorPresets: [(name: String, hex: String)] = [
        ("White", "FFFFFF"),
        ("Yellow", "FACC15"),
        ("Cyan", "38BDF8")
    ]
}

@MainActor
@Observable
final class PlayerSubtitleManager {
    var inPlayerTracks: [InPlayerSubtitleTrack] = []
    var discoveredSiteSubtitles: [(url: String, label: String)] = []
    var externalCues: [SubtitleCue] = []
    var externalTrackName: String?
    var offsetSeconds: Double = 0
    var stylePrefs: SubtitleStylePrefs = SubtitleStylePrefs()

    private let styleKeyPrefix = "singularity.subtitleStyle."

    func loadStyle(for profileId: String) {
        if let data = UserDefaults.standard.data(forKey: styleKeyPrefix + profileId),
           let decoded = try? JSONDecoder().decode(SubtitleStylePrefs.self, from: data) {
            stylePrefs = decoded
        } else {
            stylePrefs = SubtitleStylePrefs()
        }
    }

    func saveStyle(for profileId: String) {
        if let data = try? JSONEncoder().encode(stylePrefs) {
            UserDefaults.standard.set(data, forKey: styleKeyPrefix + profileId)
        }
    }

    var hasActiveExternalSubtitles: Bool {
        !externalCues.isEmpty
    }

    var isAllOff: Bool {
        externalCues.isEmpty && !inPlayerTracks.contains(where: \.isActive)
    }

    func activeCue(at playbackTime: Double) -> SubtitleCue? {
        guard !externalCues.isEmpty else { return nil }
        return SubtitleParser.activeCue(in: externalCues, at: playbackTime + offsetSeconds)
    }

    func setExternalSubtitles(cues: [SubtitleCue], name: String) {
        externalCues = cues
        externalTrackName = name
        offsetSeconds = 0
    }

    func addDiscoveredSiteSubtitle(url: String, label: String) {
        guard !discoveredSiteSubtitles.contains(where: { $0.url == url }) else { return }
        discoveredSiteSubtitles.append((url: url, label: label))
    }

    func clearExternalSubtitles() {
        externalCues = []
        externalTrackName = nil
        offsetSeconds = 0
    }
}
