import Compression
import Foundation

enum SubtitleDownloadError: LocalizedError {
    case invalidURL
    case network(String)
    case httpStatus(Int)
    case emptyFile
    case htmlResponse
    case jsonResponse
    case zipExtractionFailed
    case unsupportedEncoding
    case unsupportedFormat
    case corruptedContent
    case noCuesFound

    var errorDescription: String? {
        switch self {
        case .invalidURL:
            return "Invalid subtitle download link."
        case .network(let msg):
            return "Subtitle server connection failed: \(msg)"
        case .httpStatus(let code):
            return "Subtitle server returned HTTP \(code)."
        case .emptyFile:
            return "The downloaded subtitle file is empty."
        case .htmlResponse:
            return "The server returned an HTML page instead of a subtitle file."
        case .jsonResponse:
            return "The server returned JSON instead of a subtitle file."
        case .zipExtractionFailed:
            return "Could not extract subtitle from compressed archive."
        case .unsupportedEncoding:
            return "Could not decode the text encoding of this subtitle file."
        case .unsupportedFormat:
            return "This subtitle file format is not supported."
        case .corruptedContent:
            return "This subtitle file contains corrupted or unreadable characters."
        case .noCuesFound:
            return "The subtitle file contains no valid timed cues."
        }
    }
}

struct SubtitleParsedPayload: Sendable {
    let cues: [SubtitleCue]
    let detectedLanguage: ResolvedLanguageResult
}

enum SubtitlePeekOutcome: Sendable {
    case valid(ResolvedLanguageResult?)
    case invalid(reason: String)
}

actor SubtitleDownloadService {
    static let shared = SubtitleDownloadService()

    private let session: URLSession = {
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 18
        config.timeoutIntervalForResource = 30
        return URLSession(configuration: config)
    }()

    func downloadAndParse(urlString: String, preferredLanguage: String? = nil, referer: String? = nil) async throws -> [SubtitleCue] {
        let payload = try await downloadAndParseWithLanguage(
            urlString: urlString,
            preferredLanguage: preferredLanguage,
            referer: referer
        )
        return payload.cues
    }

    func downloadAndParseWithLanguage(
        urlString: String,
        preferredLanguage: String? = nil,
        referer: String? = nil
    ) async throws -> SubtitleParsedPayload {
        guard let url = URL(string: urlString) else {
            throw SubtitleDownloadError.invalidURL
        }

        var request = URLRequest(url: url)
        request.setValue(
            "Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1",
            forHTTPHeaderField: "User-Agent"
        )
        request.setValue("*/*", forHTTPHeaderField: "Accept")
        if let referer, !referer.isEmpty {
            request.setValue(referer, forHTTPHeaderField: "Referer")
        }

        let data: Data
        let response: URLResponse
        do {
            (data, response) = try await session.data(for: request)
        } catch {
            await logDiagnostic("Network error: \(error.localizedDescription)")
            throw SubtitleDownloadError.network(error.localizedDescription)
        }

        guard let http = response as? HTTPURLResponse else {
            throw SubtitleDownloadError.network("Invalid server response.")
        }

        let contentType = http.value(forHTTPHeaderField: "Content-Type") ?? ""
        guard (200..<300).contains(http.statusCode) else {
            await logDiagnostic("HTTP \(http.statusCode) | CT=\(contentType) | len=\(data.count)")
            throw SubtitleDownloadError.httpStatus(http.statusCode)
        }

        guard !data.isEmpty else {
            await logDiagnostic("HTTP \(http.statusCode) | Empty body")
            throw SubtitleDownloadError.emptyFile
        }

        let effectiveData: Data
        if isZipArchive(data) {
            guard let extracted = extractFirstSubtitleFromZip(data) else {
                await logDiagnostic("HTTP \(http.statusCode) | ZIP extraction failed | len=\(data.count)")
                throw SubtitleDownloadError.zipExtractionFailed
            }
            effectiveData = extracted
        } else {
            effectiveData = data
        }

        guard let decoded = SubtitleEncodingDetector.decode(effectiveData, preferredLanguage: preferredLanguage) else {
            await logDiagnostic("HTTP \(http.statusCode) | Unsupported encoding | len=\(effectiveData.count)")
            throw SubtitleDownloadError.unsupportedEncoding
        }

        let trimmed = decoded.text.trimmingCharacters(in: .whitespacesAndNewlines)
        let lowerPrefix = trimmed.prefix(200).lowercased()
        if lowerPrefix.contains("<!doctype html") || lowerPrefix.contains("<html") {
            await logDiagnostic("HTTP \(http.statusCode) | HTML returned instead of subtitle")
            throw SubtitleDownloadError.htmlResponse
        }
        if (trimmed.hasPrefix("{") && trimmed.hasSuffix("}")) || (trimmed.hasPrefix("[") && trimmed.hasSuffix("]")) {
            await logDiagnostic("HTTP \(http.statusCode) | JSON returned instead of subtitle")
            throw SubtitleDownloadError.jsonResponse
        }

        let format = SubtitleParser.detectFormat(decoded.text)
        guard format != .unknown else {
            await logDiagnostic("HTTP \(http.statusCode) | Enc=\(decoded.encodingName) | Unknown format")
            throw SubtitleDownloadError.unsupportedFormat
        }

        let cues = SubtitleParser.parse(decoded.text)
        guard !cues.isEmpty else {
            throw SubtitleDownloadError.noCuesFound
        }
        guard areCuesReadable(cues) else {
            await logDiagnostic("HTTP \(http.statusCode) | Corrupted or gibberish cues excluded")
            throw SubtitleDownloadError.corruptedContent
        }

        await logDiagnostic("HTTP \(http.statusCode) | CT=\(contentType) | len=\(effectiveData.count) | Enc=\(decoded.encodingName) | Fmt=\(format.rawValue) | Cues=\(cues.count)")
        let detectedLanguage = SubtitleLanguageResolver.resolveFromContent(decoded.text)
        return SubtitleParsedPayload(cues: cues, detectedLanguage: detectedLanguage)
    }

    func validateAndPeekLanguage(urlString: String, referer: String?) async -> SubtitlePeekOutcome {
        guard let url = URL(string: urlString) else { return .invalid(reason: "Invalid URL") }
        var request = URLRequest(url: url)
        request.setValue(
            "Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1",
            forHTTPHeaderField: "User-Agent"
        )
        request.setValue("bytes=0-12287", forHTTPHeaderField: "Range")
        if let referer, !referer.isEmpty {
            request.setValue(referer, forHTTPHeaderField: "Referer")
        }
        guard let (data, response) = try? await session.data(for: request),
              let http = response as? HTTPURLResponse else {
            return .valid(nil)
        }
        if http.statusCode == 404 || http.statusCode == 410 {
            return .invalid(reason: "HTTP \(http.statusCode)")
        }
        guard (200..<300).contains(http.statusCode), !data.isEmpty else {
            return .valid(nil)
        }
        if isZipArchive(data) {
            return .valid(nil)
        }
        guard let decoded = SubtitleEncodingDetector.decode(data, preferredLanguage: nil) else {
            return .invalid(reason: "Unreadable encoding")
        }
        let lowerPrefix = decoded.text.trimmingCharacters(in: .whitespacesAndNewlines).prefix(200).lowercased()
        if lowerPrefix.contains("<!doctype html") || lowerPrefix.contains("<html") {
            return .invalid(reason: "HTML returned instead of subtitle")
        }
        if lowerPrefix.hasPrefix("{") || lowerPrefix.hasPrefix("[") {
            return .invalid(reason: "JSON returned instead of subtitle")
        }
        let result = SubtitleLanguageResolver.resolveFromContent(decoded.text)
        return .valid(result.isKnown ? result : nil)
    }

    private func areCuesReadable(_ cues: [SubtitleCue]) -> Bool {
        let sample = cues.prefix(25)
        var validCount = 0
        for cue in sample {
            if cue.end > cue.start && SubtitleEncodingDetector.isTextReadable(cue.text) {
                validCount += 1
            }
        }
        return validCount > 0 && Double(validCount) / Double(sample.count) >= 0.5
    }

    private func logDiagnostic(_ msg: String) async {
        await MainActor.run {
            SingularityDiagnostics.shared.record(category: "Subtitles", message: msg)
        }
    }

    private func isZipArchive(_ data: Data) -> Bool {
        data.count >= 4 && data[0] == 0x50 && data[1] == 0x4B && data[2] == 0x03 && data[3] == 0x04
    }

    private func extractFirstSubtitleFromZip(_ data: Data) -> Data? {
        var offset = 0
        let bytes = [UInt8](data)
        while offset + 30 <= bytes.count {
            guard bytes[offset] == 0x50, bytes[offset + 1] == 0x4B, bytes[offset + 2] == 0x03, bytes[offset + 3] == 0x04 else {
                break
            }
            let compression = UInt16(bytes[offset + 8]) | (UInt16(bytes[offset + 9]) << 8)
            let compSize = Int(UInt32(bytes[offset + 18]) | (UInt32(bytes[offset + 19]) << 8) | (UInt32(bytes[offset + 20]) << 16) | (UInt32(bytes[offset + 21]) << 24))
            let uncompSize = Int(UInt32(bytes[offset + 22]) | (UInt32(bytes[offset + 23]) << 8) | (UInt32(bytes[offset + 24]) << 16) | (UInt32(bytes[offset + 25]) << 24))
            let nameLen = Int(UInt16(bytes[offset + 26]) | (UInt16(bytes[offset + 27]) << 8))
            let extraLen = Int(UInt16(bytes[offset + 28]) | (UInt16(bytes[offset + 29]) << 8))

            let nameStart = offset + 30
            let dataStart = nameStart + nameLen + extraLen
            guard dataStart + compSize <= bytes.count else { break }

            let name = String(bytes: bytes[nameStart..<(nameStart + nameLen)], encoding: .utf8)?.lowercased() ?? ""
            let payload = Data(bytes[dataStart..<(dataStart + compSize)])

            if name.hasSuffix(".srt") || name.hasSuffix(".vtt") || name.hasSuffix(".ass") || name.hasSuffix(".ssa") {
                if compression == 0 {
                    return payload
                } else if compression == 8, let inflated = inflateRawDeflate(payload, expectedSize: max(uncompSize, compSize * 4)) {
                    return inflated
                }
            }
            offset = dataStart + compSize
        }
        return nil
    }

    private func inflateRawDeflate(_ compressed: Data, expectedSize: Int) -> Data? {
        let capacity = max(expectedSize, 65_536)
        var dst = Data(count: capacity)
        let decodedCount = dst.withUnsafeMutableBytes { dstPtr in
            compressed.withUnsafeBytes { srcPtr in
                guard let dstBase = dstPtr.bindMemory(to: UInt8.self).baseAddress,
                      let srcBase = srcPtr.bindMemory(to: UInt8.self).baseAddress else { return 0 }
                return compression_decode_buffer(dstBase, capacity, srcBase, compressed.count, nil, COMPRESSION_ZLIB)
            }
        }
        guard decodedCount > 0 else { return nil }
        return dst.prefix(decodedCount)
    }
}
