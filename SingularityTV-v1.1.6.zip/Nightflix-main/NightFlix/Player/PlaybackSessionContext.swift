import Foundation
import Observation

@MainActor
@Observable
final class PlaybackSessionContext {
    private(set) var sessionGeneration: Int = 1
    private(set) var currentContent: WatchItem
    private(set) var mainProviderHost: String
    private(set) var activeInternalServer: InternalServerOption?
    var capabilities = PlayerCapabilities()

    init(content: WatchItem) {
        self.currentContent = content
        self.mainProviderHost = content.generatedURL.host ?? ""
    }

    @discardableResult
    func beginNewSession(content: WatchItem? = nil, providerHost: String) -> Int {
        sessionGeneration &+= 1
        if let content {
            currentContent = content
        }
        mainProviderHost = providerHost
        activeInternalServer = nil
        capabilities = PlayerCapabilities()
        return sessionGeneration
    }

    @discardableResult
    func beginInternalServerSession(_ server: InternalServerOption) -> Int {
        sessionGeneration &+= 1
        activeInternalServer = server
        capabilities.supportsAudioTracks = false
        capabilities.supportsSubtitleTracks = false
        capabilities.supportsSkipIntro = false
        capabilities.supportsAutoNext = false
        return sessionGeneration
    }
}
