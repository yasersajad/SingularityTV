import AVKit
import SwiftUI

struct PlayerChromeView: View {
    let item: WatchItem
    let controller: CustomPlayerController
    let accent: Color
    let onBack: () -> Void

    var body: some View {
        ZStack {
            if controller.state.visibility.isControlsLocked {
                lockedOverlay
            } else {
                if controller.state.canControlMediaElement {
                    PlayerControlsView(controller: controller, accent: accent)
                }

                VStack(spacing: 0) {
                    topBar
                    Spacer(minLength: 0)
                }
            }
        }
    }

    private var lockedOverlay: some View {
        VStack {
            HStack {
                Spacer()
                Button {
                    controller.toggleControlsLock()
                } label: {
                    Label("Unlock Controls", systemImage: PlayerIcon.lock)
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 8)
                        .background(.ultraThinMaterial, in: Capsule())
                        .background(Color.black.opacity(0.65), in: Capsule())
                        .overlay { Capsule().stroke(accent.opacity(0.65), lineWidth: 1) }
                }
                .buttonStyle(NFScaleButtonStyle())
                .accessibilityLabel("Unlock Controls")
                Spacer()
            }
            .padding(.top, 18)
            Spacer()
        }
    }

    private var topBar: some View {
        HStack(spacing: 12) {
            Button(action: onBack) {
                Image(systemName: PlayerIcon.back)
                    .font(.system(size: 17, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: PlayerIconMetrics.topBarButtonSize, height: PlayerIconMetrics.topBarButtonSize)
                    .background(Color.black.opacity(0.45), in: Circle())
            }
            .buttonStyle(NFScaleButtonStyle())
            .accessibilityLabel("Back")

            VStack(alignment: .leading, spacing: 2) {
                Text(item.title)
                    .font(.system(size: 16, weight: .bold))
                    .foregroundStyle(.white)
                    .lineLimit(1)

                if item.type == .tv,
                   let s = controller.state.playingSeason,
                   let e = controller.state.playingEpisode {
                    let epTitle = controller.state.playingEpisodeName.map { " · \($0)" } ?? ""
                    Text("S\(s):E\(e)\(epTitle)")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundStyle(.white.opacity(0.72))
                        .lineLimit(1)
                }
            }

            Spacer()

            HStack(spacing: 8) {
                chromePillButton(
                    icon: PlayerIcon.playbackSources,
                    label: "Playback Sources",
                    isActive: controller.state.activePanel == .servers,
                    hasBadge: controller.internalServers.hasMultipleInternalServers
                ) {
                    controller.openPanel(.servers)
                }

                chromePillButton(
                    icon: controller.subtitles.hasActiveExternalSubtitles ? PlayerIcon.subtitlesActive : PlayerIcon.subtitles,
                    label: "Subtitles",
                    isActive: controller.state.activePanel == .subtitles || controller.subtitles.hasActiveExternalSubtitles
                ) {
                    controller.openPanel(.subtitles)
                }

                chromePillButton(
                    icon: PlayerIcon.audio,
                    label: "Audio Tracks",
                    isActive: controller.state.activePanel == .audio,
                    hasBadge: controller.audio.supportsAudioDiscovery
                ) {
                    controller.openPanel(.audio)
                }

                chromePillButton(
                    icon: PlayerIcon.unlock,
                    label: "Lock Controls",
                    isActive: false
                ) {
                    controller.toggleControlsLock()
                }

                chromePillButton(
                    icon: PlayerIcon.settings,
                    label: "Player Settings",
                    isActive: controller.state.activePanel == .settings
                ) {
                    controller.openPanel(.settings)
                }

                AirPlayRouteButton()
                    .frame(width: PlayerIconMetrics.topBarButtonSize, height: PlayerIconMetrics.topBarButtonSize)
                    .background(Color.black.opacity(0.45), in: Circle())
                    .accessibilityLabel("AirPlay")
            }
        }
        .padding(.horizontal, 28)
        .padding(.top, 12)
        .padding(.bottom, 22)
        .background(
            LinearGradient(
                colors: [.black.opacity(0.86), .black.opacity(0.32), .clear],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea(edges: .top)
            .allowsHitTesting(false)
        )
    }

    private func chromePillButton(
        icon: String,
        label: String,
        isActive: Bool,
        hasBadge: Bool = false,
        action: @escaping () -> Void
    ) -> some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(PlayerIconMetrics.topBarIconFont)
                .foregroundStyle(isActive ? accent : .white)
                .frame(width: PlayerIconMetrics.topBarButtonSize, height: PlayerIconMetrics.topBarButtonSize)
                .background(Color.black.opacity(0.45), in: Circle())
                .overlay {
                    if isActive {
                        Circle().stroke(accent.opacity(0.85), lineWidth: 1.2)
                    }
                }
                .overlay(alignment: .topTrailing) {
                    if hasBadge {
                        Circle()
                            .fill(accent)
                            .frame(width: 7, height: 7)
                            .offset(x: -3, y: 3)
                    }
                }
        }
        .buttonStyle(NFScaleButtonStyle())
        .accessibilityLabel(label)
    }
}

private struct AirPlayRouteButton: UIViewRepresentable {
    func makeUIView(context: Context) -> AVRoutePickerView {
        let picker = AVRoutePickerView()
        picker.tintColor = .white
        picker.activeTintColor = .systemBlue
        picker.prioritizesVideoDevices = true
        return picker
    }

    func updateUIView(_ uiView: AVRoutePickerView, context: Context) {}
}

struct PlayerPanelRow: View {
    let title: String
    let subtitle: String?
    let isSelected: Bool
    let accent: Color

    var body: some View {
        HStack(spacing: 12) {
            Image(systemName: isSelected ? PlayerIcon.selected : PlayerIcon.unselected)
                .foregroundStyle(isSelected ? accent : .white.opacity(0.45))

            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                if let subtitle, !subtitle.isEmpty {
                    Text(subtitle)
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.6))
                        .lineLimit(2)
                }
            }

            Spacer()
        }
        .padding(11)
        .background(isSelected ? accent.opacity(0.14) : Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 11))
    }
}
