import AVFoundation
import MediaPlayer
import Observation
import UIKit

@MainActor
@Observable
final class PlayerGestureController {
    let gestureState = PlayerGestureState()

    private var dragStartBrightness: Double = 0.5
    private var dragStartVolume: Double = 0.5
    private var hudHideTask: Task<Void, Never>?
    private var holdSeekTask: Task<Void, Never>?
    private weak var volumeSlider: UISlider?

    init() {
        gestureState.brightnessLevel = Double(Self.currentScreenBrightness())
        gestureState.volumeLevel = Double(AVAudioSession.sharedInstance().outputVolume)
        prepareSystemVolumeSlider()
    }

    func cleanup() {
        hudHideTask?.cancel()
        holdSeekTask?.cancel()
        gestureState.activeMode = .none
        gestureState.isHold2xActive = false
        gestureState.showBrightnessHUD = false
        gestureState.showVolumeHUD = false
        gestureState.showHoldSeekHUD = false
    }

    func beginDrag(
        translation: CGSize,
        startLocation: CGPoint,
        viewSize: CGSize,
        controller: CustomPlayerController
    ) {
        guard controller.state.gesturesEnabled,
              !controller.state.visibility.isControlsLocked,
              controller.state.activePanel == .none else { return }

        if gestureState.activeMode == .none {
            let dx = abs(translation.width)
            let dy = abs(translation.height)
            guard max(dx, dy) >= 14 else { return }

            if dx > dy * 1.2 {
                guard controller.state.duration > 0 else { return }
                hudHideTask?.cancel()
                controller.state.visibility.beginGesture(.scrubbing)
                gestureState.activeMode = .scrubbing
                gestureState.scrubStartTime = controller.state.currentTime
                gestureState.scrubTargetTime = controller.state.currentTime
                gestureState.scrubDeltaSeconds = 0
                if controller.state.hapticsEnabled { HapticManager.shared.selection() }
            } else if dy > dx * 1.2 {
                let normX = startLocation.x / max(1, viewSize.width)
                if normX < 0.42 {
                    hudHideTask?.cancel()
                    controller.state.visibility.beginGesture(.gestureActive)
                    gestureState.activeMode = .brightness
                    dragStartBrightness = Double(Self.currentScreenBrightness())
                    gestureState.brightnessLevel = dragStartBrightness
                    gestureState.showBrightnessHUD = true
                } else if normX > 0.58 {
                    hudHideTask?.cancel()
                    controller.state.visibility.beginGesture(.gestureActive)
                    gestureState.activeMode = .volume
                    dragStartVolume = Double(AVAudioSession.sharedInstance().outputVolume)
                    gestureState.volumeLevel = dragStartVolume
                    gestureState.showVolumeHUD = true
                }
            }
        }

        switch gestureState.activeMode {
        case .scrubbing:
            let spanSeconds = min(max(controller.state.duration * 0.45, 60), 240)
            let delta = (Double(translation.width) / max(1, viewSize.width)) * spanSeconds
            let target = max(0, min(controller.state.duration, gestureState.scrubStartTime + delta))
            gestureState.scrubTargetTime = target
            gestureState.scrubDeltaSeconds = target - gestureState.scrubStartTime

        case .brightness:
            let delta = -Double(translation.height) / max(180, viewSize.height * 0.65)
            let next = min(max(dragStartBrightness + delta, 0.02), 1.0)
            gestureState.brightnessLevel = next
            Self.setScreenBrightness(CGFloat(next))
            gestureState.showBrightnessHUD = true

        case .volume:
            let delta = -Double(translation.height) / max(180, viewSize.height * 0.65)
            let next = min(max(dragStartVolume + delta, 0.0), 1.0)
            gestureState.volumeLevel = next
            setSystemVolume(Float(next))
            gestureState.showVolumeHUD = true

        default:
            break
        }
    }

    func endDrag(controller: CustomPlayerController) {
        switch gestureState.activeMode {
        case .scrubbing:
            let target = gestureState.scrubTargetTime
            let fraction = controller.state.duration > 0 ? (target / controller.state.duration) : 0
            controller.seek(to: fraction)
            gestureState.activeMode = .none
            controller.state.visibility.endGesture(hasCountdownOverlay: controller.state.nextEpisodeCountdown != nil)
            scheduleHUDHide()

        case .brightness, .volume:
            gestureState.activeMode = .none
            controller.state.visibility.endGesture(hasCountdownOverlay: controller.state.nextEpisodeCountdown != nil)
            scheduleHUDHide()

        default:
            gestureState.activeMode = .none
        }
    }

    func beginHold(at location: CGPoint, viewSize: CGSize, controller: CustomPlayerController) {
        guard controller.state.gesturesEnabled,
              !controller.state.visibility.isControlsLocked,
              controller.state.activePanel == .none,
              gestureState.activeMode == .none else { return }

        let normX = location.x / max(1, viewSize.width)
        if normX < 0.28 {
            startContinuousHoldSeek(isForward: false, controller: controller)
        } else if normX > 0.72 {
            startContinuousHoldSeek(isForward: true, controller: controller)
        } else {
            guard controller.sessionContext.capabilities.supportsPlaybackSpeed else { return }
            hudHideTask?.cancel()
            controller.state.visibility.beginGesture(.gestureActive)
            gestureState.activeMode = .holdSpeed2x
            gestureState.previousPlaybackRate = controller.state.playbackRate
            gestureState.isHold2xActive = true
            if controller.state.hapticsEnabled { HapticManager.shared.lightImpact() }
            controller.bridge.setPlaybackRate(2.0)
        }
    }

    func endHold(controller: CustomPlayerController) {
        if gestureState.activeMode == .holdSpeed2x {
            let prev = gestureState.previousPlaybackRate > 0 ? gestureState.previousPlaybackRate : 1.0
            gestureState.isHold2xActive = false
            gestureState.activeMode = .none
            controller.bridge.setPlaybackRate(prev)
            controller.state.visibility.endGesture(hasCountdownOverlay: controller.state.nextEpisodeCountdown != nil)
        } else if gestureState.activeMode == .holdSeekForward || gestureState.activeMode == .holdSeekBackward {
            holdSeekTask?.cancel()
            holdSeekTask = nil
            let finalTarget = gestureState.holdSeekTargetTime
            gestureState.activeMode = .none
            controller.seekToSeconds(finalTarget)
            controller.state.visibility.endGesture(hasCountdownOverlay: controller.state.nextEpisodeCountdown != nil)
            scheduleHUDHide()
        }
    }

    private func startContinuousHoldSeek(isForward: Bool, controller: CustomPlayerController) {
        holdSeekTask?.cancel()
        hudHideTask?.cancel()
        controller.state.visibility.beginGesture(.seeking)
        gestureState.activeMode = isForward ? .holdSeekForward : .holdSeekBackward
        gestureState.holdSeekIsForward = isForward
        gestureState.holdSeekStartTime = controller.state.currentTime
        gestureState.holdSeekTargetTime = controller.state.currentTime
        gestureState.holdSeekAccumulated = 0
        gestureState.holdSeekSpeedMultiplier = 1.0
        gestureState.holdSeekRingProgress = 0
        gestureState.showHoldSeekHUD = true
        if controller.state.hapticsEnabled { HapticManager.shared.lightImpact() }

        holdSeekTask = Task { @MainActor [weak self, weak controller] in
            var elapsed: Double = 0
            while !Task.isCancelled {
                guard let self, let controller,
                      self.gestureState.activeMode == (isForward ? .holdSeekForward : .holdSeekBackward) else { return }

                let mult: Double
                if elapsed < 1.5 {
                    mult = 1.0
                } else if elapsed < 3.5 {
                    mult = 2.0
                } else {
                    mult = 3.5
                }
                self.gestureState.holdSeekSpeedMultiplier = mult

                let stepSeconds = (isForward ? 1.0 : -1.0) * mult
                let maxDur = controller.state.duration > 0 ? controller.state.duration : 1e9
                let nextTarget = max(0, min(maxDur, self.gestureState.holdSeekTargetTime + stepSeconds))
                self.gestureState.holdSeekTargetTime = nextTarget
                self.gestureState.holdSeekAccumulated = nextTarget - self.gestureState.holdSeekStartTime
                self.gestureState.holdSeekRingProgress = (self.gestureState.holdSeekRingProgress + 0.08).truncatingRemainder(dividingBy: 1.0)

                try? await Task.sleep(for: .milliseconds(100))
                elapsed += 0.1
            }
        }
    }

    private func scheduleHUDHide() {
        hudHideTask?.cancel()
        hudHideTask = Task { @MainActor [weak self] in
            try? await Task.sleep(for: .milliseconds(700))
            guard !Task.isCancelled, let self else { return }
            self.gestureState.showBrightnessHUD = false
            self.gestureState.showVolumeHUD = false
            self.gestureState.showHoldSeekHUD = false
        }
    }

    private func prepareSystemVolumeSlider() {
        let volumeView = MPVolumeView(frame: CGRect(x: -1000, y: -1000, width: 1, height: 1))
        for sub in volumeView.subviews {
            if let slider = sub as? UISlider {
                self.volumeSlider = slider
                break
            }
        }
    }

    private func setSystemVolume(_ value: Float) {
        if let slider = volumeSlider {
            slider.value = value
        }
    }

    private static func currentScreenBrightness() -> CGFloat {
        for scene in UIApplication.shared.connectedScenes {
            if let ws = scene as? UIWindowScene, ws.activationState == .foregroundActive {
                return ws.screen.brightness
            }
        }
        if let ws = UIApplication.shared.connectedScenes.first as? UIWindowScene {
            return ws.screen.brightness
        }
        return 0.5
    }

    private static func setScreenBrightness(_ value: CGFloat) {
        for scene in UIApplication.shared.connectedScenes {
            if let ws = scene as? UIWindowScene {
                ws.screen.brightness = value
            }
        }
    }
}
