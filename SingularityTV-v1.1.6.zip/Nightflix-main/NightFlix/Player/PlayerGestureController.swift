import AVFoundation
import MediaPlayer
import Observation
import UIKit

@MainActor
@Observable
final class PlayerGestureController {
    let gestureState = PlayerGestureState()

    private var dragStartBrightness: Double = 0.5
    private var dragStartVolume: Double = 0.5
    private var hudHideTask: Task<Void, Never>?
    private var holdSeekTask: Task<Void, Never>?
    private weak var volumeSlider: UISlider?

    init() {
        gestureState.brightnessLevel = Double(Self.currentScreenBrightness())
        gestureState.volumeLevel = Double(AVAudioSession.sharedInstance().outputVolume)
        prepareSystemVolumeSlider()
    }

    func cleanup() {
        hudHideTask?.cancel()
        holdSeekTask?.cancel()
        gestureState.activeMode = .none
        gestureState.isHold2xActive = false
        gestureState.showBrightnessHUD = false
        gestureState.showVolumeHUD = false
        gestureState.showHoldSeekHUD = false
    }

    func beginDrag(
        translation: CGSize,
        startLocation: CGPoint,
        viewSize: CGSize,
        controller: CustomPlayerController
    ) {
        guard controller.state.activePanel == .none else { return }

        if gestureState.activeMode == .none {
            let dx = abs(translation.width)
            let dy = abs(translation.height)
            guard max(dx, dy) >= 14 else { return }

            if dx > dy * 1.2 {
                guard controller.state.duration > 0 else { return }
                gestureState.activeMode = .scrubbing
                gestureState.scrubStartTime = controller.state.currentTime
                gestureState.scrubTargetTime = controller.state.currentTime
                gestureState.scrubDeltaSeconds = 0
                HapticManager.shared.selection()
            } else if dy > dx * 1.2 {
                let normX = startLocation.x / max(1, viewSize.width)
                if normX < 0.42 {
                    gestureState.activeMode = .brightness
                    dragStartBrightness = Double(Self.currentScreenBrightness())
                    gestureState.brightnessLevel = dragStartBrightness
                    gestureState.showBrightnessHUD = true
                } else if normX > 0.58 {
                    gestureState.activeMode = .volume
                    dragStartVolume = Double(AVAudioSession.sharedInstance().outputVolume)
                    gestureState.volumeLevel = dragStartVolume
                    gestureState.showVolumeHUD = true
                }
            }
        }

        switch gestureState.activeMode {
        case .scrubbing:
            let spanSeconds = min(max(controller.state.duration * 0.45, 60), 240)
            let delta = (Double(translation.width) / max(1, viewSize.width)) * spanSeconds
            let target = max(0, min(controller.state.duration, gestureState.scrubStartTime + delta))
            gestureState.scrubTargetTime = target
            gestureState.scrubDeltaSeconds = target - gestureState.scrubStartTime

        case .brightness:
            let delta = -Double(translation.height) / max(180, viewSize.height * 0.65)
            let next = min(max(dragStartBrightness + delta, 0.02), 1.0)
            gestureState.brightnessLevel = next
            Self.setScreenBrightness(CGFloat(next))
            gestureState.showBrightnessHUD = true

        case .volume:
            let delta = -Double(translation.height) / max(180, viewSize.height * 0.65)
            let next = min(max(dragStartVolume + delta, 0.0), 1.0)
            gestureState.volumeLevel = next
            setSystemVolume(Float(next))
            gestureState.showVolumeHUD = true

        default:
            break
        }
    }

    func endDrag(controller: CustomPlayerController) {
        switch gestureState.activeMode {
        case .scrubbing:
            let target = gestureState.scrubTargetTime
            let fraction = controller.state.duration > 0 ? (target / controller.state.duration) : 0
            controller.seek(to: fraction)
            gestureState.activeMode = .none
            scheduleHUDHide()

        case .brightness, .volume:
            gestureState.activeMode = .none
            scheduleHUDHide()

        default:
            gestureState.activeMode = .none
        }
    }

    func beginHold(at location: CGPoint, viewSize: CGSize, controller: CustomPlayerController) {
        guard controller.state.activePanel == .none,
              gestureState.activeMode == .none else { return }

        let normX = location.x / max(1, viewSize.width)
        if normX < 0.24 {
            startContinuousHoldSeek(isForward: false, controller: controller)
        } else if normX > 0.76 {
            startContinuousHoldSeek(isForward: true, controller: controller)
        } else {
            guard controller.state.capabilities.supportsPlaybackSpeed else { return }
            gestureState.activeMode = .holdSpeed2x
            gestureState.previousPlaybackRate = controller.state.playbackRate
            gestureState.isHold2xActive = true
            HapticManager.shared.lightImpact()
            controller.bridge.setPlaybackRate(2.0)
        }
    }

    func endHold(controller: CustomPlayerController) {
        if gestureState.activeMode == .holdSpeed2x {
            let prev = gestureState.previousPlaybackRate > 0 ? gestureState.previousPlaybackRate : 1.0
            gestureState.isHold2xActive = false
            gestureState.activeMode = .none
            controller.bridge.setPlaybackRate(prev)
        } else if gestureState.activeMode == .holdSeekForward || gestureState.activeMode == .holdSeekBackward {
            holdSeekTask?.cancel()
            holdSeekTask = nil
            gestureState.activeMode = .none
            scheduleHUDHide()
        }
    }

    private func startContinuousHoldSeek(isForward: Bool, controller: CustomPlayerController) {
        holdSeekTask?.cancel()
        gestureState.activeMode = isForward ? .holdSeekForward : .holdSeekBackward
        gestureState.holdSeekIsForward = isForward
        gestureState.holdSeekAccumulated = 0
        gestureState.showHoldSeekHUD = true
        HapticManager.shared.lightImpact()

        holdSeekTask = Task { @MainActor [weak self, weak controller] in
            while !Task.isCancelled {
                guard let self, let controller,
                      self.gestureState.activeMode == (isForward ? .holdSeekForward : .holdSeekBackward) else { return }
                let step: Double = isForward ? 10 : -10
                controller.bridge.skip(by: step)
                self.gestureState.holdSeekAccumulated += step
                try? await Task.sleep(for: .milliseconds(420))
            }
        }
    }

    private func scheduleHUDHide() {
        hudHideTask?.cancel()
        hudHideTask = Task { @MainActor [weak self] in
            try? await Task.sleep(for: .milliseconds(900))
            guard !Task.isCancelled, let self else { return }
            self.gestureState.showBrightnessHUD = false
            self.gestureState.showVolumeHUD = false
            self.gestureState.showHoldSeekHUD = false
        }
    }

    private func prepareSystemVolumeSlider() {
        let volumeView = MPVolumeView(frame: CGRect(x: -1000, y: -1000, width: 1, height: 1))
        for sub in volumeView.subviews {
            if let slider = sub as? UISlider {
                self.volumeSlider = slider
                break
            }
        }
    }

    private func setSystemVolume(_ value: Float) {
        if let slider = volumeSlider {
            slider.value = value
        }
    }

    private static func currentScreenBrightness() -> CGFloat {
        for scene in UIApplication.shared.connectedScenes {
            if let ws = scene as? UIWindowScene, ws.activationState == .foregroundActive {
                return ws.screen.brightness
            }
        }
        if let ws = UIApplication.shared.connectedScenes.first as? UIWindowScene {
            return ws.screen.brightness
        }
        return 0.5
    }

    private static func setScreenBrightness(_ value: CGFloat) {
        for scene in UIApplication.shared.connectedScenes {
            if let ws = scene as? UIWindowScene {
                ws.screen.brightness = value
            }
        }
    }
}
