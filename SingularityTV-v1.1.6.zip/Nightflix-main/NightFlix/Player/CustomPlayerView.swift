import AVFoundation
import SwiftUI

struct CustomPlayerView: View {
    let item: WatchItem
    var continueWatchingManager: ContinueWatchingManager?
    var historyManager: WatchHistoryManager?

    @Environment(\.dismiss) private var dismiss
    @Environment(\.nightflixAccent) private var accent
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    @EnvironmentObject private var settings: AppSettingsManager

    @State private var controller: CustomPlayerController
    @State private var isShowingExternalSubSearch = false
    @State private var isDraggingSeek = false
    @State private var dragSeekFraction: Double = 0

    init(
        item: WatchItem,
        continueWatchingManager: ContinueWatchingManager?,
        historyManager: WatchHistoryManager? = nil
    ) {
        self.item = item
        self.continueWatchingManager = continueWatchingManager
        self.historyManager = historyManager
        _controller = State(
            initialValue: CustomPlayerController(
                item: item,
                continueWatchingManager: continueWatchingManager,
                historyManager: historyManager
            )
        )
    }

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()

            SingularityWebPlayerView(
                url: controller.activeURL,
                reloadToken: controller.state.reloadToken,
                bridgeController: controller.bridge,
                onLoadingChanged: { loading in
                    controller.state.isLoading = loading
                },
                onError: { err in
                    controller.state.errorMessage = err
                },
                onEvent: { event in
                    controller.handleBridgeEvent(event)
                }
            )
            .ignoresSafeArea()

            PlayerGestureOverlay(
                isControlsVisible: controller.state.isChromeVisible,
                onSingleTap: { controller.toggleChrome() },
                onDoubleTapBackward: { controller.skip(by: -10) },
                onDoubleTapForward: { controller.skip(by: 10) }
            )

            nativeSubtitleOverlay

            if let skipText = controller.state.skipFeedbackText {
                skipFeedbackBadge(text: skipText, isForward: controller.state.skipFeedbackIsForward)
                    .transition(.opacity.combined(with: .scale(scale: 0.9)))
            }

            if controller.state.isLoading && controller.state.errorMessage == nil && !controller.state.isSourceUnavailable {
                loadingOverlay
                    .transition(.opacity)
            }

            if controller.state.isChromeVisible && controller.state.errorMessage == nil && !controller.state.isSourceUnavailable {
                chromeOverlay
                    .transition(.opacity)
            }

            if let countdown = controller.state.nextEpisodeCountdown,
               let nextEp = controller.nextEpisodePayload {
                nextEpisodeOverlay(nextEp: nextEp, secondsLeft: countdown)
                    .transition(.opacity.combined(with: .move(edge: .bottom)))
            }

            if controller.state.activePanel != .none {
                panelOverlay
                    .transition(reduceMotion ? .opacity : .move(edge: .bottom).combined(with: .opacity))
            }

            if let errMsg = controller.state.errorMessage {
                failureOverlay(title: "Playback Error", message: errMsg)
            } else if controller.state.isSourceUnavailable {
                failureOverlay(
                    title: "Source Unavailable",
                    message: "This server couldn't stream this title right now. Try switching servers or retrying."
                )
            }
        }
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.24), value: controller.state.isChromeVisible)
        .animation(reduceMotion ? nil : .easeInOut(duration: 0.2), value: controller.state.isLoading)
        .animation(reduceMotion ? nil : .spring(response: 0.34, dampingFraction: 0.85), value: controller.state.activePanel)
        .statusBarHidden()
        .persistentSystemOverlays(.hidden)
        .toolbar(.hidden, for: .navigationBar)
        .preferredColorScheme(.dark)
        .onAppear {
            Self.activatePlaybackAudioSession()
            NFOrientation.enterPlayback()
            controller.onAppear()
        }
        .onDisappear {
            controller.onDisappear()
            NFOrientation.exitPlayback()
            Self.deactivatePlaybackAudioSession()
        }
        .sheet(isPresented: $isShowingExternalSubSearch) {
            ExternalSubtitleSearchSheet(
                tmdbId: item.tmdbId,
                title: item.title,
                season: controller.state.playingSeason ?? item.season,
                episode: controller.state.playingEpisode ?? item.episode,
                hasActiveSubtitles: controller.subtitles.hasActiveExternalSubtitles,
                offsetSeconds: Binding(
                    get: { controller.subtitles.offsetSeconds },
                    set: { controller.subtitles.offsetSeconds = $0 }
                ),
                onSelectCues: { cues, name in
                    controller.subtitles.setExternalSubtitles(cues: cues, name: name)
                    controller.bridge.selectTextTrack(index: nil)
                },
                onClearSubtitles: {
                    controller.subtitles.clearExternalSubtitles()
                }
            )
            .presentationBackground(Color(hex: "0B0B10"))
            .presentationDragIndicator(.visible)
        }
    }

    // MARK: - Native Subtitle Overlay

    @ViewBuilder
    private var nativeSubtitleOverlay: some View {
        if let cue = controller.subtitles.activeCue(at: controller.state.currentTime) {
            let style = controller.subtitles.stylePrefs
            VStack {
                Spacer()
                Text(cue.text)
                    .font(.system(size: style.fontSize, weight: .semibold))
                    .foregroundStyle(Color(hex: style.textColorHex))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 8)
                    .background(subtitleBackground(style.bgStyle), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
                    .shadow(color: .black.opacity(0.85), radius: 4, y: 1)
                    .padding(.horizontal, 28)
                    .padding(.bottom, controller.state.isChromeVisible ? style.bottomOffset + 64 : style.bottomOffset)
            }
            .allowsHitTesting(false)
        }
    }

    private func subtitleBackground(_ bg: SubtitleBgStyle) -> Color {
        switch bg {
        case .dark: return Color.black.opacity(0.8)
        case .translucent: return Color.black.opacity(0.45)
        case .none: return Color.clear
        }
    }

    // MARK: - Chrome Overlay

    private var chromeOverlay: some View {
        ZStack {
            VStack(spacing: 0) {
                topBar
                Spacer(minLength: 0)
                if controller.state.canControlMediaElement {
                    bottomControls
                }
            }

            if controller.state.canControlMediaElement {
                centerControls
            }
        }
    }

    private var topBar: some View {
        HStack(spacing: 12) {
            Button {
                HapticManager.shared.lightImpact()
                dismiss()
            } label: {
                Image(systemName: "chevron.backward")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 40, height: 40)
                    .background(.ultraThinMaterial, in: Circle())
            }
            .buttonStyle(NFScaleButtonStyle())
            .accessibilityLabel("Back")

            VStack(alignment: .leading, spacing: 2) {
                Text(item.title)
                    .font(.system(size: 16, weight: .bold))
                    .foregroundStyle(.white)
                    .lineLimit(1)

                if item.type == .tv,
                   let s = controller.state.playingSeason,
                   let e = controller.state.playingEpisode {
                    let epTitle = controller.state.playingEpisodeName.map { " · \($0)" } ?? ""
                    Text("S\(s):E\(e)\(epTitle)")
                        .font(.system(size: 12, weight: .medium))
                        .foregroundStyle(.white.opacity(0.72))
                        .lineLimit(1)
                }
            }

            Spacer()

            HStack(spacing: 8) {
                if item.type == .tv {
                    chromePillButton(
                        icon: "list.bullet.rectangle",
                        label: "Episodes",
                        isActive: controller.state.activePanel == .episodes
                    ) {
                        controller.openPanel(.episodes)
                    }
                }

                chromePillButton(
                    icon: controller.subtitles.hasActiveExternalSubtitles ? "captions.bubble.fill" : "captions.bubble",
                    label: "Subtitles",
                    isActive: controller.state.activePanel == .subtitles || controller.subtitles.hasActiveExternalSubtitles
                ) {
                    controller.openPanel(.subtitles)
                }

                chromePillButton(
                    icon: "speaker.wave.2.fill",
                    label: "Audio & Server",
                    isActive: controller.state.activePanel == .audio
                ) {
                    controller.openPanel(.audio)
                }
            }
        }
        .padding(.horizontal, 16)
        .padding(.top, 12)
        .padding(.bottom, 20)
        .background(
            LinearGradient(
                colors: [.black.opacity(0.82), .black.opacity(0.35), .clear],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea(edges: .top)
            .allowsHitTesting(false)
        )
    }

    private func chromePillButton(icon: String, label: String, isActive: Bool, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Image(systemName: icon)
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(isActive ? accent : .white)
                .frame(width: 40, height: 40)
                .background(.ultraThinMaterial, in: Circle())
                .overlay {
                    if isActive {
                        Circle().stroke(accent.opacity(0.7), lineWidth: 1.2)
                    }
                }
        }
        .buttonStyle(NFScaleButtonStyle())
        .accessibilityLabel(label)
    }

    private var centerControls: some View {
        HStack(spacing: 42) {
            Button {
                controller.skip(by: -10)
            } label: {
                Image(systemName: "gobackward.10")
                    .font(.system(size: 28, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(width: 56, height: 56)
                    .background(Color.black.opacity(0.45), in: Circle())
            }
            .buttonStyle(NFScaleButtonStyle())
            .accessibilityLabel("Rewind 10 seconds")

            Button {
                controller.togglePlayPause()
            } label: {
                Image(systemName: controller.state.isPlaying ? "pause.fill" : "play.fill")
                    .font(.system(size: 34, weight: .bold))
                    .foregroundStyle(.white)
                    .frame(width: 72, height: 72)
                    .background(accent.opacity(0.92), in: Circle())
                    .shadow(color: accent.opacity(0.45), radius: 16)
            }
            .buttonStyle(NFScaleButtonStyle())
            .accessibilityLabel(controller.state.isPlaying ? "Pause" : "Play")

            Button {
                controller.skip(by: 10)
            } label: {
                Image(systemName: "goforward.10")
                    .font(.system(size: 28, weight: .semibold))
                    .foregroundStyle(.white)
                    .frame(width: 56, height: 56)
                    .background(Color.black.opacity(0.45), in: Circle())
            }
            .buttonStyle(NFScaleButtonStyle())
            .accessibilityLabel("Forward 10 seconds")
        }
    }

    private var bottomControls: some View {
        let displayFraction = isDraggingSeek ? dragSeekFraction : controller.state.progressFraction
        let displayTime = isDraggingSeek
            ? dragSeekFraction * controller.state.duration
            : controller.state.currentTime

        return VStack(spacing: 10) {
            GeometryReader { geo in
                let width = max(1, geo.size.width)
                ZStack(alignment: .leading) {
                    Capsule()
                        .fill(Color.white.opacity(0.24))
                        .frame(height: isDraggingSeek ? 6 : 4)

                    Capsule()
                        .fill(accent)
                        .frame(width: width * CGFloat(displayFraction), height: isDraggingSeek ? 6 : 4)

                    Circle()
                        .fill(.white)
                        .frame(width: isDraggingSeek ? 16 : 12, height: isDraggingSeek ? 16 : 12)
                        .shadow(color: .black.opacity(0.5), radius: 3)
                        .offset(x: max(0, min(width - 12, width * CGFloat(displayFraction) - 6)))
                }
                .frame(height: 24)
                .contentShape(Rectangle())
                .gesture(
                    DragGesture(minimumDistance: 0)
                        .onChanged { value in
                            isDraggingSeek = true
                            dragSeekFraction = min(max(Double(value.location.x / width), 0), 1)
                            controller.resetChromeTimer()
                        }
                        .onEnded { value in
                            let finalFraction = min(max(Double(value.location.x / width), 0), 1)
                            isDraggingSeek = false
                            controller.seek(to: finalFraction)
                        }
                )
            }
            .frame(height: 24)

            HStack(spacing: 14) {
                Text(PlayerStateManager.formatTime(displayTime))
                    .font(.caption.weight(.semibold).monospacedDigit())
                    .foregroundStyle(.white)

                Spacer()

                Button {
                    controller.toggleMute()
                } label: {
                    Image(systemName: controller.state.isMuted ? "speaker.slash.fill" : "speaker.wave.2.fill")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.white.opacity(0.9))
                }
                .buttonStyle(.plain)

                Menu {
                    ForEach([0.75, 1.0, 1.25, 1.5, 2.0], id: \.self) { rate in
                        Button {
                            controller.setPlaybackRate(rate)
                        } label: {
                            Text(rate == controller.state.playbackRate ? "✓ \(String(format: "%.2gx", rate))" : "\(String(format: "%.2gx", rate))")
                        }
                    }
                } label: {
                    Text(String(format: "%.2gx", controller.state.playbackRate))
                        .font(.caption.weight(.bold).monospacedDigit())
                        .foregroundStyle(.white)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color.white.opacity(0.14), in: Capsule())
                }

                if controller.hasNextEpisode {
                    Button {
                        controller.playNextEpisode()
                    } label: {
                        Label("Next Ep", systemImage: "forward.end.fill")
                            .font(.caption.weight(.bold))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 5)
                            .background(accent, in: Capsule())
                    }
                    .buttonStyle(NFScaleButtonStyle())
                }

                Text("-\(PlayerStateManager.formatTime(controller.state.remainingTime)) / \(PlayerStateManager.formatTime(controller.state.duration))")
                    .font(.caption.weight(.medium).monospacedDigit())
                    .foregroundStyle(.white.opacity(0.75))
            }
        }
        .padding(.horizontal, 20)
        .padding(.bottom, 18)
        .padding(.top, 24)
        .background(
            LinearGradient(
                colors: [.clear, .black.opacity(0.45), .black.opacity(0.86)],
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea(edges: .bottom)
            .allowsHitTesting(false)
        )
    }

    // MARK: - Slide-Up Panels

    private var panelOverlay: some View {
        ZStack(alignment: .bottom) {
            Color.black.opacity(0.55)
                .ignoresSafeArea()
                .onTapGesture {
                    controller.state.activePanel = .none
                    controller.resetChromeTimer()
                }

            VStack(spacing: 0) {
                panelHeader
                Divider().background(Color.white.opacity(0.12))
                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        switch controller.state.activePanel {
                        case .subtitles:
                            subtitlesPanelContent
                        case .audio:
                            audioAndServerPanelContent
                        case .episodes:
                            episodesPanelContent
                        case .none:
                            EmptyView()
                        }
                    }
                    .padding(18)
                }
            }
            .frame(maxWidth: 540, maxHeight: 340)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            .background(Color(hex: "0D0D14").opacity(0.88), in: RoundedRectangle(cornerRadius: 22, style: .continuous))
            .overlay {
                RoundedRectangle(cornerRadius: 22, style: .continuous)
                    .stroke(Color.white.opacity(0.14), lineWidth: 1)
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 16)
        }
    }

    private var panelHeader: some View {
        HStack {
            Text(panelTitle)
                .font(.headline.weight(.bold))
                .foregroundStyle(.white)
            Spacer()
            Button {
                controller.state.activePanel = .none
                controller.resetChromeTimer()
            } label: {
                Image(systemName: "xmark")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.white.opacity(0.8))
                    .frame(width: 30, height: 30)
                    .background(Color.white.opacity(0.1), in: Circle())
            }
            .buttonStyle(.plain)
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 14)
    }

    private var panelTitle: String {
        switch controller.state.activePanel {
        case .subtitles: return "Subtitles & Styling"
        case .audio: return "Audio & Streaming Server"
        case .episodes: return "Season \(controller.state.playingSeason ?? 1) Episodes"
        case .none: return ""
        }
    }

    private var subtitlesPanelContent: some View {
        VStack(alignment: .leading, spacing: 14) {
            Button {
                controller.subtitles.clearExternalSubtitles()
                controller.bridge.selectTextTrack(index: nil)
                controller.state.activePanel = .none
            } label: {
                panelRow(title: "Off", subtitle: "Disable subtitles", isSelected: controller.subtitles.isAllOff)
            }
            .buttonStyle(.plain)

            if !controller.subtitles.inPlayerTracks.isEmpty {
                Text("Source Subtitles")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.white.opacity(0.6))

                ForEach(controller.subtitles.inPlayerTracks) { track in
                    Button {
                        controller.subtitles.clearExternalSubtitles()
                        controller.bridge.selectTextTrack(index: track.id)
                        controller.state.activePanel = .none
                    } label: {
                        panelRow(
                            title: track.label,
                            subtitle: track.language.isEmpty ? nil : track.language.uppercased(),
                            isSelected: track.isActive && !controller.subtitles.hasActiveExternalSubtitles
                        )
                    }
                    .buttonStyle(.plain)
                }
            }

            if let extName = controller.subtitles.externalTrackName {
                panelRow(title: extName, subtitle: "Active external subtitle", isSelected: true)
            }

            Button {
                controller.state.activePanel = .none
                isShowingExternalSubSearch = true
            } label: {
                Label("Search External Subtitles", systemImage: "magnifyingglass")
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(accent, in: RoundedRectangle(cornerRadius: 12))
            }
            .buttonStyle(NFScaleButtonStyle())

            Divider().background(Color.white.opacity(0.1))

            Text("Subtitle Appearance")
                .font(.caption.weight(.bold))
                .foregroundStyle(.white.opacity(0.6))

            HStack {
                Text("Size: \(Int(controller.subtitles.stylePrefs.fontSize))pt")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white)
                Slider(
                    value: Binding(
                        get: { controller.subtitles.stylePrefs.fontSize },
                        set: {
                            controller.subtitles.stylePrefs.fontSize = $0
                            controller.saveSubtitleStyle()
                        }
                    ),
                    in: 14...28,
                    step: 1
                )
                .tint(accent)
            }

            HStack(spacing: 10) {
                ForEach(SubtitleStylePrefs.colorPresets, id: \.hex) { preset in
                    let selected = controller.subtitles.stylePrefs.textColorHex == preset.hex
                    Button {
                        controller.subtitles.stylePrefs.textColorHex = preset.hex
                        controller.saveSubtitleStyle()
                    } label: {
                        Text(preset.name)
                            .font(.caption.weight(.bold))
                            .foregroundStyle(Color(hex: preset.hex))
                            .padding(.horizontal, 12)
                            .padding(.vertical, 6)
                            .background(selected ? Color.white.opacity(0.18) : Color.white.opacity(0.06), in: Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private var audioAndServerPanelContent: some View {
        VStack(alignment: .leading, spacing: 14) {
            if controller.audio.supportsExternalAudioSelection {
                Text("Audio Tracks")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.white.opacity(0.6))

                ForEach(controller.audio.tracks) { track in
                    Button {
                        controller.bridge.selectAudioTrack(index: track.id)
                        controller.state.activePanel = .none
                    } label: {
                        panelRow(
                            title: track.label,
                            subtitle: track.language.isEmpty ? nil : track.language.uppercased(),
                            isSelected: track.isEnabled
                        )
                    }
                    .buttonStyle(.plain)
                }
            } else {
                Text("Audio tracks are controlled directly inside the embedded player when multiple languages are provided by the stream. You can also switch streaming servers below:")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.68))
                    .padding(10)
                    .background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 10))
            }

            Text("Streaming Servers")
                .font(.caption.weight(.bold))
                .foregroundStyle(.white.opacity(0.6))

            ForEach(StreamingServerPreset.all) { preset in
                let isSelected = settings.streamingProviderBaseURL.localizedCaseInsensitiveContains(preset.host)
                Button {
                    controller.switchServer(to: preset, settings: settings)
                } label: {
                    panelRow(title: preset.name, subtitle: preset.subtitle, isSelected: isSelected)
                }
                .buttonStyle(.plain)
            }
        }
    }

    private var episodesPanelContent: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 10) {
                if controller.hasPreviousEpisode {
                    Button {
                        controller.playPreviousEpisode()
                    } label: {
                        Label("Previous", systemImage: "backward.end.fill")
                            .font(.caption.weight(.bold))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .background(Color.white.opacity(0.1), in: Capsule())
                    }
                    .buttonStyle(.plain)
                }

                if controller.hasNextEpisode {
                    Button {
                        controller.playNextEpisode()
                    } label: {
                        Label("Next Episode", systemImage: "forward.end.fill")
                            .font(.caption.weight(.bold))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .background(accent, in: Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }

            if controller.state.isLoadingEpisodes {
                ProgressView("Loading episodes...")
                    .tint(accent)
                    .foregroundStyle(.white.opacity(0.7))
            } else if controller.state.seasonEpisodes.isEmpty {
                Text("No episode list available for this season.")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.65))
            } else {
                ForEach(controller.state.seasonEpisodes, id: \.episodeNumber) { ep in
                    let isCurrent = ep.episodeNumber == controller.state.playingEpisode
                    Button {
                        controller.playEpisode(ep)
                    } label: {
                        panelRow(
                            title: "E\(ep.episodeNumber) · \(ep.name)",
                            subtitle: (ep.overview?.isEmpty == false) ? ep.overview : nil,
                            isSelected: isCurrent
                        )
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    private func panelRow(title: String, subtitle: String?, isSelected: Bool) -> some View {
        HStack(spacing: 12) {
            Image(systemName: isSelected ? "checkmark.circle.fill" : "circle")
                .foregroundStyle(isSelected ? accent : .white.opacity(0.45))

            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white)
                    .lineLimit(1)
                if let subtitle, !subtitle.isEmpty {
                    Text(subtitle)
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.6))
                        .lineLimit(2)
                }
            }

            Spacer()
        }
        .padding(11)
        .background(isSelected ? accent.opacity(0.14) : Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 11))
    }

    // MARK: - Overlays

    private func nextEpisodeOverlay(nextEp: NFEpisodePayload, secondsLeft: Int) -> some View {
        VStack {
            Spacer()
            HStack(spacing: 14) {
                VStack(alignment: .leading, spacing: 3) {
                    Text("NEXT EPISODE IN \(secondsLeft)S")
                        .font(.caption2.weight(.black))
                        .foregroundStyle(accent)
                    Text("E\(nextEp.episodeNumber) · \(nextEp.name)")
                        .font(.subheadline.weight(.bold))
                        .foregroundStyle(.white)
                        .lineLimit(1)
                }

                Spacer()

                Button("Cancel") {
                    controller.cancelNextEpisodeCountdown()
                }
                .font(.caption.weight(.bold))
                .foregroundStyle(.white.opacity(0.75))

                Button {
                    controller.playNextEpisode()
                } label: {
                    Text("Play Now")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 8)
                        .background(accent, in: Capsule())
                }
                .buttonStyle(NFScaleButtonStyle())
            }
            .padding(16)
            .frame(maxWidth: 480)
            .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16))
            .background(Color.black.opacity(0.78), in: RoundedRectangle(cornerRadius: 16))
            .overlay {
                RoundedRectangle(cornerRadius: 16).stroke(Color.white.opacity(0.16), lineWidth: 1)
            }
            .padding(.horizontal, 20)
            .padding(.bottom, 76)
        }
    }

    private func skipFeedbackBadge(text: String, isForward: Bool) -> some View {
        VStack(spacing: 6) {
            Image(systemName: isForward ? "goforward.10" : "gobackward.10")
                .font(.system(size: 28, weight: .bold))
            Text(text)
                .font(.caption.weight(.bold))
        }
        .foregroundStyle(.white)
        .padding(18)
        .background(Color.black.opacity(0.72), in: Circle())
        .allowsHitTesting(false)
    }

    private var loadingOverlay: some View {
        VStack(spacing: 16) {
            ProgressView()
                .progressViewStyle(.circular)
                .tint(accent)
                .scaleEffect(1.35)
                .frame(width: 46, height: 46)
            Text(item.title)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(.white.opacity(0.8))
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(Color.black.opacity(0.6))
        .allowsHitTesting(false)
    }

    private func failureOverlay(title: String, message: String) -> some View {
        ZStack {
            Color.black.opacity(0.88).ignoresSafeArea()
            VStack(spacing: 14) {
                Image(systemName: "exclamationmark.triangle.fill")
                    .font(.system(size: 32))
                    .foregroundStyle(accent)
                Text(title)
                    .font(.headline.weight(.bold))
                    .foregroundStyle(.white)
                Text(message)
                    .font(.footnote)
                    .foregroundStyle(.white.opacity(0.72))
                    .multilineTextAlignment(.center)
                    .frame(maxWidth: 340)

                HStack(spacing: 10) {
                    Button("Back") {
                        dismiss()
                    }
                    .font(.subheadline.weight(.semibold))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 18)
                    .padding(.vertical, 11)
                    .background(Color.white.opacity(0.14), in: Capsule())

                    Menu {
                        ForEach(StreamingServerPreset.all) { preset in
                            Button {
                                controller.switchServer(to: preset, settings: settings)
                            } label: {
                                Text(preset.name)
                            }
                        }
                    } label: {
                        Label("Switch Server", systemImage: "server.rack")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 11)
                            .background(Color.white.opacity(0.18), in: Capsule())
                    }

                    Button("Retry") {
                        controller.retry()
                    }
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 18)
                    .padding(.vertical, 11)
                    .background(accent, in: Capsule())
                }
            }
            .padding(24)
        }
    }

    // MARK: - Audio Session

    private static func activatePlaybackAudioSession() {
        let session = AVAudioSession.sharedInstance()
        try? session.setCategory(.playback, mode: .moviePlayback)
        try? session.setActive(true)
    }

    private static func deactivatePlaybackAudioSession() {
        try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
    }
}
