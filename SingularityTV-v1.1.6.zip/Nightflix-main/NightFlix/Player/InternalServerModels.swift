import Foundation

enum InternalServerSourceType: String, Equatable, Sendable {
    case tab = "Tab"
    case button = "Button"
    case dropdown = "Selector"
    case mirror = "Mirror"
    case embedProvider = "Embed"
    case unknown = "Source"
}

struct InternalServerOption: Identifiable, Equatable, Sendable {
    let id: String
    let parentProviderID: String
    let nativeIndex: Int
    let name: String
    let sourceType: InternalServerSourceType
    var isSelected: Bool
    let isAvailable: Bool
    let playbackURL: String?
    let domKey: String
}

enum InternalServerSwitchState: Equatable, Sendable {
    case idle
    case switching(String)
    case switched(String)
    case failed(String)
}
