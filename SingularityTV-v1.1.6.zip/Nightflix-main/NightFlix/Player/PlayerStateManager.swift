import Foundation
import Observation
import SwiftUI

enum PlayerActivePanel: Equatable {
    case none
    case subtitles
    case audio
    case settings
    case episodes
}

@MainActor
@Observable
final class PlayerStateManager {
    var lifecycle: PlayerLifecycleState = .idle
    var capabilities = PlayerCapabilities()

    var isLoading = true
    var isPlaying = false
    var currentTime: Double = 0
    var duration: Double = 0
    var playbackRate: Double = 1.0
    var volume: Double = 1.0
    var isMuted = false
    var canControlMediaElement = false
    var isVideoFill = false
    var autoplayNextEnabled = true
    var skipIntroEnabled = true

    var qualityLevels: [InPlayerQualityLevel] = []

    var introWindow: IntroSkipWindow?
    var didSkipIntro = false
    var serverAutoplaySignal: ServerAutoplaySignal?

    var isChromeVisible = true
    var activePanel: PlayerActivePanel = .none
    var errorMessage: String?
    var isSourceUnavailable = false
    var reloadToken = 0
    var webRecoveryAttempts = 0

    var playingSeason: Int?
    var playingEpisode: Int?
    var playingEpisodeName: String?
    var seasonEpisodes: [NFEpisodePayload] = []
    var isLoadingEpisodes = false

    var nextEpisodeCountdown: Int?
    var didDismissNextEpisodeOverlay = false

    var skipFeedbackText: String?
    var skipFeedbackIsForward = true

    var progressFraction: Double {
        guard duration > 0, currentTime.isFinite, duration.isFinite else { return 0 }
        return min(max(currentTime / duration, 0), 1)
    }

    var remainingTime: Double {
        guard duration > 0 else { return 0 }
        return max(0, duration - currentTime)
    }

    static func formatTime(_ seconds: Double) -> String {
        guard seconds.isFinite, seconds >= 0 else { return "0:00" }
        let total = Int(seconds)
        let h = total / 3600
        let m = (total % 3600) / 60
        let s = total % 60
        if h > 0 {
            return String(format: "%d:%02d:%02d", h, m, s)
        }
        return String(format: "%d:%02d", m, s)
    }
}
