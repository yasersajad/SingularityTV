import SwiftUI

struct PlayerGestureOverlay: View {
    let isControlsVisible: Bool
    let onSingleTap: () -> Void
    let onDoubleTapBackward: () -> Void
    let onDoubleTapForward: () -> Void

    var body: some View {
        HStack(spacing: 0) {
            Color.clear
                .contentShape(Rectangle())
                .onTapGesture(count: 2) {
                    onDoubleTapBackward()
                }
                .onTapGesture(count: 1) {
                    onSingleTap()
                }

            Color.clear
                .contentShape(Rectangle())
                .onTapGesture(count: 1) {
                    onSingleTap()
                }

            Color.clear
                .contentShape(Rectangle())
                .onTapGesture(count: 2) {
                    onDoubleTapForward()
                }
                .onTapGesture(count: 1) {
                    onSingleTap()
                }
        }
        .allowsHitTesting(!isControlsVisible)
    }
}
