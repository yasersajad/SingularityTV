import SwiftUI

struct PlayerGestureOverlay: View {
    let controller: CustomPlayerController
    let gestureController: PlayerGestureController
    let onSingleTap: () -> Void
    let onDoubleTapBackward: () -> Void
    let onDoubleTapForward: () -> Void

    @State private var isHolding = false

    var body: some View {
        GeometryReader { geo in
            Color.clear
                .contentShape(Rectangle())
                .gesture(
                    DragGesture(minimumDistance: 14, coordinateSpace: .local)
                        .onChanged { value in
                            if isHolding {
                                isHolding = false
                                gestureController.endHold(controller: controller)
                            }
                            gestureController.beginDrag(
                                translation: value.translation,
                                startLocation: value.startLocation,
                                viewSize: geo.size,
                                controller: controller
                            )
                        }
                        .onEnded { _ in
                            gestureController.endDrag(controller: controller)
                        }
                )
                .simultaneousGesture(
                    LongPressGesture(minimumDuration: 0.35)
                        .sequenced(before: DragGesture(minimumDistance: 0, coordinateSpace: .local))
                        .onChanged { value in
                            switch value {
                            case .first(true):
                                break
                            case .second(true, let drag):
                                if !isHolding {
                                    isHolding = true
                                    gestureController.beginHold(
                                        at: drag?.startLocation ?? CGPoint(x: geo.size.width / 2, y: geo.size.height / 2),
                                        viewSize: geo.size,
                                        controller: controller
                                    )
                                }
                            default:
                                break
                            }
                        }
                        .onEnded { _ in
                            if isHolding {
                                isHolding = false
                                gestureController.endHold(controller: controller)
                            }
                        }
                )
                .simultaneousGesture(
                    SpatialTapGesture(count: 2)
                        .onEnded { value in
                            guard controller.state.gesturesEnabled,
                                  !controller.state.visibility.isControlsLocked,
                                  !controller.state.visibility.isGestureLocked else { return }
                            let normX = value.location.x / max(1, geo.size.width)
                            if normX < 0.38 {
                                onDoubleTapBackward()
                            } else if normX > 0.62 {
                                onDoubleTapForward()
                            } else {
                                onSingleTap()
                            }
                        }
                )
                .simultaneousGesture(
                    TapGesture(count: 1)
                        .onEnded {
                            guard !controller.state.visibility.isGestureLocked,
                                  gestureController.gestureState.activeMode == .none,
                                  !isHolding else { return }
                            onSingleTap()
                        }
                )
        }
        .allowsHitTesting(controller.state.activePanel == .none)
    }
}

struct PlayerGestureHUDs: View {
    let gestureState: PlayerGestureState
    let accent: Color

    var body: some View {
        ZStack {
            if gestureState.activeMode == .scrubbing {
                scrubbingPreviewHUD
                    .transition(.opacity)
            }

            if gestureState.isHold2xActive {
                VStack {
                    Label("2x SPEED", systemImage: PlayerIcon.forwardContinuous)
                        .font(.caption.weight(.black))
                        .tracking(0.6)
                        .foregroundStyle(.white)
                        .padding(.horizontal, 16)
                        .padding(.vertical, 8)
                        .background(.ultraThinMaterial, in: Capsule())
                        .background(Color.black.opacity(0.68), in: Capsule())
                        .overlay { Capsule().stroke(accent.opacity(0.65), lineWidth: 1.2) }
                        .padding(.top, 58)
                    Spacer()
                }
                .transition(.opacity.combined(with: .scale(scale: 0.94)))
            }

            if gestureState.showHoldSeekHUD {
                holdSeekRingHUD
                    .transition(.opacity.combined(with: .scale(scale: 0.94)))
            }

            HStack {
                if gestureState.showBrightnessHUD {
                    verticalMeterHUD(
                        icon: PlayerIcon.brightness,
                        label: "Brightness",
                        value: gestureState.brightnessLevel
                    )
                    .padding(.leading, 28)
                    .transition(.opacity)
                }
                Spacer()
                if gestureState.showVolumeHUD {
                    verticalMeterHUD(
                        icon: gestureState.volumeLevel <= 0.01 ? PlayerIcon.audioMuted : PlayerIcon.audio,
                        label: "Volume",
                        value: gestureState.volumeLevel
                    )
                    .padding(.trailing, 28)
                    .transition(.opacity)
                }
            }
        }
        .allowsHitTesting(false)
    }

    private var holdSeekRingHUD: some View {
        let delta = Int(gestureState.holdSeekAccumulated.rounded())
        let sign = delta >= 0 ? "+" : "-"
        let absDelta = abs(delta)
        let speedText = String(format: "%.1fx", gestureState.holdSeekSpeedMultiplier).replacingOccurrences(of: ".0x", with: "x")

        return HStack {
            if !gestureState.holdSeekIsForward {
                holdSeekCard(sign: sign, seconds: absDelta, speedText: speedText, isForward: false)
                    .padding(.leading, 36)
                Spacer()
            } else {
                Spacer()
                holdSeekCard(sign: sign, seconds: absDelta, speedText: speedText, isForward: true)
                    .padding(.trailing, 36)
            }
        }
    }

    private func holdSeekCard(sign: String, seconds: Int, speedText: String, isForward: Bool) -> some View {
        VStack(spacing: 8) {
            ZStack {
                Circle()
                    .stroke(Color.white.opacity(0.18), lineWidth: 3)
                    .frame(width: 58, height: 58)
                Circle()
                    .trim(from: 0, to: max(0.18, CGFloat(gestureState.holdSeekRingProgress)))
                    .stroke(accent, style: StrokeStyle(lineWidth: 3, lineCap: .round))
                    .frame(width: 58, height: 58)
                    .rotationEffect(.degrees(gestureState.holdSeekRingProgress * 360))
                Image(systemName: isForward ? "chevron.forward.2" : "chevron.backward.2")
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(.white)
            }

            Text("\(sign)\(seconds)s")
                .font(.subheadline.weight(.heavy).monospacedDigit())
                .foregroundStyle(.white)

            Text("\(PlayerStateManager.formatTime(gestureState.holdSeekTargetTime)) · \(speedText)")
                .font(.caption2.weight(.semibold).monospacedDigit())
                .foregroundStyle(.white.opacity(0.75))
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 12)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .background(Color.black.opacity(0.76), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 16, style: .continuous).stroke(Color.white.opacity(0.18), lineWidth: 1)
        }
    }

    private var scrubbingPreviewHUD: some View {
        let delta = Int(gestureState.scrubDeltaSeconds.rounded())
        let sign = delta >= 0 ? "+" : "-"
        let absDelta = abs(delta)
        let deltaText = String(format: "%@%02d:%02d", sign, absDelta / 60, absDelta % 60)

        return VStack(spacing: 4) {
            HStack(spacing: 6) {
                Image(systemName: delta >= 0 ? PlayerIcon.forwardContinuous : PlayerIcon.rewindContinuous)
                    .font(.caption.weight(.bold))
                    .foregroundStyle(accent)
                Text(deltaText)
                    .font(.headline.weight(.heavy).monospacedDigit())
                    .foregroundStyle(.white)
            }
            Text(PlayerStateManager.formatTime(gestureState.scrubTargetTime))
                .font(.caption.weight(.semibold).monospacedDigit())
                .foregroundStyle(.white.opacity(0.75))
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 10)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .background(Color.black.opacity(0.75), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Color.white.opacity(0.18), lineWidth: 1)
        }
    }

    private func verticalMeterHUD(icon: String, label: String, value: Double) -> some View {
        VStack(spacing: 8) {
            Image(systemName: icon)
                .font(.subheadline.weight(.bold))
                .foregroundStyle(.white)

            GeometryReader { geo in
                ZStack(alignment: .bottom) {
                    Capsule()
                        .fill(Color.white.opacity(0.22))
                    Capsule()
                        .fill(accent)
                        .frame(height: max(4, geo.size.height * CGFloat(min(max(value, 0), 1))))
                }
            }
            .frame(width: 6, height: 96)

            Text("\(Int((value * 100).rounded()))%")
                .font(.caption2.weight(.bold).monospacedDigit())
                .foregroundStyle(.white.opacity(0.85))
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 14)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .background(Color.black.opacity(0.72), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(label) \(Int((value * 100).rounded())) percent")
    }
}
