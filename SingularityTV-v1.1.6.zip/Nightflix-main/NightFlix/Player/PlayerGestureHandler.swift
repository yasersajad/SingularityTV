import SwiftUI

struct PlayerGestureOverlay: View {
    let controller: CustomPlayerController
    let gestureController: PlayerGestureController
    let onSingleTap: () -> Void
    let onDoubleTapBackward: () -> Void
    let onDoubleTapForward: () -> Void

    @State private var lastTouchLocation: CGPoint = .zero
    @State private var isHolding = false

    var body: some View {
        GeometryReader { geo in
            Color.clear
                .contentShape(Rectangle())
                .gesture(
                    DragGesture(minimumDistance: 14, coordinateSpace: .local)
                        .onChanged { value in
                            if isHolding {
                                isHolding = false
                                gestureController.endHold(controller: controller)
                            }
                            gestureController.beginDrag(
                                translation: value.translation,
                                startLocation: value.startLocation,
                                viewSize: geo.size,
                                controller: controller
                            )
                        }
                        .onEnded { _ in
                            gestureController.endDrag(controller: controller)
                        }
                )
                .simultaneousGesture(
                    LongPressGesture(minimumDuration: 0.38)
                        .sequenced(before: DragGesture(minimumDistance: 0, coordinateSpace: .local))
                        .onChanged { value in
                            switch value {
                            case .first(true):
                                break
                            case .second(true, let drag):
                                if let loc = drag?.location {
                                    lastTouchLocation = loc
                                }
                                if !isHolding {
                                    isHolding = true
                                    gestureController.beginHold(
                                        at: drag?.startLocation ?? CGPoint(x: geo.size.width / 2, y: geo.size.height / 2),
                                        viewSize: geo.size,
                                        controller: controller
                                    )
                                }
                            default:
                                break
                            }
                        }
                        .onEnded { _ in
                            if isHolding {
                                isHolding = false
                                gestureController.endHold(controller: controller)
                            }
                        }
                )
                .simultaneousGesture(
                    SpatialTapGesture(count: 2)
                        .onEnded { value in
                            let normX = value.location.x / max(1, geo.size.width)
                            if normX < 0.38 {
                                onDoubleTapBackward()
                            } else if normX > 0.62 {
                                onDoubleTapForward()
                            } else {
                                onSingleTap()
                            }
                        }
                )
                .simultaneousGesture(
                    TapGesture(count: 1)
                        .onEnded {
                            guard gestureController.gestureState.activeMode == .none, !isHolding else { return }
                            onSingleTap()
                        }
                )
        }
        .allowsHitTesting(controller.state.activePanel == .none)
    }
}

struct PlayerGestureHUDs: View {
    let gestureState: PlayerGestureState
    let accent: Color

    var body: some View {
        ZStack {
            if gestureState.activeMode == .scrubbing {
                scrubbingPreviewHUD
                    .transition(.opacity)
            }

            if gestureState.isHold2xActive {
                VStack {
                    Label("2x Speed", systemImage: "forward.fill")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 8)
                        .background(.ultraThinMaterial, in: Capsule())
                        .background(Color.black.opacity(0.65), in: Capsule())
                        .overlay { Capsule().stroke(Color.white.opacity(0.2), lineWidth: 1) }
                        .padding(.top, 56)
                    Spacer()
                }
                .transition(.opacity)
            }

            if gestureState.showHoldSeekHUD {
                let sign = gestureState.holdSeekIsForward ? "+" : ""
                Label("\(sign)\(Int(gestureState.holdSeekAccumulated))s", systemImage: gestureState.holdSeekIsForward ? "goforward" : "gobackward")
                    .font(.subheadline.weight(.bold).monospacedDigit())
                    .foregroundStyle(.white)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 10)
                    .background(Color.black.opacity(0.75), in: Capsule())
                    .transition(.opacity)
            }

            HStack {
                if gestureState.showBrightnessHUD {
                    verticalMeterHUD(
                        icon: "sun.max.fill",
                        label: "Brightness",
                        value: gestureState.brightnessLevel
                    )
                    .padding(.leading, 28)
                    .transition(.opacity)
                }
                Spacer()
                if gestureState.showVolumeHUD {
                    verticalMeterHUD(
                        icon: gestureState.volumeLevel <= 0.01 ? "speaker.slash.fill" : "speaker.wave.2.fill",
                        label: "Volume",
                        value: gestureState.volumeLevel
                    )
                    .padding(.trailing, 28)
                    .transition(.opacity)
                }
            }
        }
        .allowsHitTesting(false)
    }

    private var scrubbingPreviewHUD: some View {
        let delta = Int(gestureState.scrubDeltaSeconds.rounded())
        let sign = delta >= 0 ? "+" : "-"
        let absDelta = abs(delta)
        let deltaText = String(format: "%@%02d:%02d", sign, absDelta / 60, absDelta % 60)

        return VStack(spacing: 4) {
            HStack(spacing: 6) {
                Image(systemName: delta >= 0 ? "goforward" : "gobackward")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(accent)
                Text(deltaText)
                    .font(.headline.weight(.heavy).monospacedDigit())
                    .foregroundStyle(.white)
            }
            Text(PlayerStateManager.formatTime(gestureState.scrubTargetTime))
                .font(.caption.weight(.semibold).monospacedDigit())
                .foregroundStyle(.white.opacity(0.75))
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 10)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .background(Color.black.opacity(0.75), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay {
            RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Color.white.opacity(0.18), lineWidth: 1)
        }
    }

    private func verticalMeterHUD(icon: String, label: String, value: Double) -> some View {
        VStack(spacing: 8) {
            Image(systemName: icon)
                .font(.subheadline.weight(.bold))
                .foregroundStyle(.white)

            GeometryReader { geo in
                ZStack(alignment: .bottom) {
                    Capsule()
                        .fill(Color.white.opacity(0.22))
                    Capsule()
                        .fill(accent)
                        .frame(height: max(4, geo.size.height * CGFloat(min(max(value, 0), 1))))
                }
            }
            .frame(width: 6, height: 96)

            Text("\(Int((value * 100).rounded()))%")
                .font(.caption2.weight(.bold).monospacedDigit())
                .foregroundStyle(.white.opacity(0.85))
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 14)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .background(Color.black.opacity(0.72), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
        .accessibilityElement(children: .ignore)
        .accessibilityLabel("\(label) \(Int((value * 100).rounded())) percent")
    }
}
