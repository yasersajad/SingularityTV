import Foundation
import Observation

enum PlaybackStartupStage: Equatable, Sendable {
    case connectingToProvider
    case loadingWatchPage
    case detectingServer
    case preparingVideo
    case buffering
    case startingPlayback
    case ready
    case timedOut(String)
    case failed(String)

    var statusText: String? {
        switch self {
        case .connectingToProvider: return "Connecting to Provider..."
        case .loadingWatchPage: return "Loading Watch Page..."
        case .detectingServer: return "Detecting Playback Server..."
        case .preparingVideo: return "Preparing Video..."
        case .buffering: return "Buffering..."
        case .startingPlayback: return "Starting Playback..."
        case .ready, .timedOut, .failed: return nil
        }
    }

    var shouldShowLoadingOverlay: Bool {
        switch self {
        case .ready, .timedOut, .failed:
            return false
        default:
            return true
        }
    }
}

@MainActor
@Observable
final class PlaybackStartupCoordinator {
    private(set) var stage: PlaybackStartupStage = .connectingToProvider
    private(set) var hasPageLoaded = false
    private(set) var hasPlayerDetected = false
    private(set) var hasMediaSource = false
    private(set) var hasFirstFrame = false

    @ObservationIgnored private var activeGeneration: Int = 0
    @ObservationIgnored private var timeoutTask: Task<Void, Never>?
    @ObservationIgnored private var isDisposed = false
    private let startupTimeoutSeconds: Double = 18.0

    func beginStartup(sessionGeneration: Int, providerHost: String) {
        isDisposed = false
        activeGeneration = sessionGeneration
        hasPageLoaded = false
        hasPlayerDetected = false
        hasMediaSource = false
        hasFirstFrame = false
        stage = .connectingToProvider
        SingularityDiagnostics.shared.record(
            sessionId: sessionGeneration,
            provider: providerHost,
            category: "Playback",
            message: "Session created; connecting to provider."
        )
        scheduleTimeout(for: sessionGeneration, providerHost: providerHost)
    }

    func markNavigationStarted(sessionGeneration: Int, providerHost: String) {
        guard !isDisposed, sessionGeneration == activeGeneration, !hasFirstFrame else { return }
        stage = .loadingWatchPage
        SingularityDiagnostics.shared.record(
            sessionId: sessionGeneration,
            provider: providerHost,
            category: "Playback",
            message: "Navigation started."
        )
    }

    func markNavigationFinished(sessionGeneration: Int, providerHost: String) {
        guard !isDisposed, sessionGeneration == activeGeneration, !hasFirstFrame else { return }
        hasPageLoaded = true
        if !hasPlayerDetected {
            stage = .detectingServer
        }
        SingularityDiagnostics.shared.record(
            sessionId: sessionGeneration,
            provider: providerHost,
            category: "Playback",
            message: "Navigation finished; awaiting player element."
        )
    }

    func markMediaSnapshot(
        sessionGeneration: Int,
        providerHost: String,
        hasVideoElement: Bool,
        readyState: Int,
        hasFirstFrame: Bool,
        isBuffering: Bool,
        isPlaying: Bool
    ) {
        guard !isDisposed, sessionGeneration == activeGeneration else { return }

        if hasVideoElement && !hasPlayerDetected {
            hasPlayerDetected = true
            SingularityDiagnostics.shared.record(
                sessionId: sessionGeneration,
                provider: providerHost,
                category: "Playback",
                message: "Player video element detected."
            )
        }

        if readyState >= 1 && !hasMediaSource {
            hasMediaSource = true
            SingularityDiagnostics.shared.record(
                sessionId: sessionGeneration,
                provider: providerHost,
                category: "Playback",
                message: "Media source detected (readyState=\(readyState))."
            )
        }

        if hasFirstFrame {
            if !self.hasFirstFrame {
                self.hasFirstFrame = true
                timeoutTask?.cancel()
                timeoutTask = nil
                SingularityDiagnostics.shared.record(
                    sessionId: sessionGeneration,
                    provider: providerHost,
                    category: "Playback",
                    message: "First frame presented; playback ready."
                )
            }
            stage = isBuffering && !isPlaying ? .buffering : .ready
        } else if hasVideoElement {
            stage = readyState >= 2 ? .startingPlayback : .preparingVideo
        }
    }

    func markFailed(sessionGeneration: Int, providerHost: String, reason: String) {
        guard !isDisposed, sessionGeneration == activeGeneration else { return }
        timeoutTask?.cancel()
        timeoutTask = nil
        stage = .failed(reason)
        SingularityDiagnostics.shared.record(
            sessionId: sessionGeneration,
            provider: providerHost,
            category: "Playback",
            message: "Playback failed: \(reason)"
        )
    }

    func cleanup() {
        isDisposed = true
        timeoutTask?.cancel()
        timeoutTask = nil
    }

    private func scheduleTimeout(for generation: Int, providerHost: String) {
        timeoutTask?.cancel()
        timeoutTask = Task { @MainActor [weak self] in
            try? await Task.sleep(for: .seconds(self?.startupTimeoutSeconds ?? 18.0))
            guard !Task.isCancelled, let self, !self.isDisposed, self.activeGeneration == generation else { return }
            if !self.hasFirstFrame {
                self.stage = .timedOut("The video stream took too long to start on \(providerHost). You can retry or switch servers.")
                SingularityDiagnostics.shared.record(
                    sessionId: generation,
                    provider: providerHost,
                    category: "Playback",
                    message: "Startup timed out before first frame."
                )
            }
        }
    }
}
