import Foundation

struct HLSMasterParseResult: Sendable {
    let audioTracks: [InPlayerAudioTrack]
    let subtitleURLs: [(url: String, label: String, language: String)]
}

enum HLSManifestParser {
    static func fetchAndParse(urlString: String, referer: String?) async -> HLSMasterParseResult? {
        guard let url = URL(string: urlString),
              let scheme = url.scheme?.lowercased(),
              scheme == "http" || scheme == "https" else {
            return nil
        }

        var request = URLRequest(url: url)
        request.timeoutInterval = 12
        request.setValue(
            "Mozilla/5.0 (iPhone; CPU iPhone OS 18_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.0 Mobile/15E148 Safari/604.1",
            forHTTPHeaderField: "User-Agent"
        )
        if let referer, !referer.isEmpty {
            request.setValue(referer, forHTTPHeaderField: "Referer")
        }

        guard let (data, response) = try? await URLSession.shared.data(for: request),
              let http = response as? HTTPURLResponse,
              (200..<300).contains(http.statusCode),
              let text = String(data: data, encoding: .utf8),
              text.contains("#EXTM3U") else {
            return nil
        }

        return parse(text: text, baseURL: url)
    }

    static func parse(text: String, baseURL: URL) -> HLSMasterParseResult {
        let lines = text.components(separatedBy: .newlines)
        var audios: [InPlayerAudioTrack] = []
        var subs: [(url: String, label: String, language: String)] = []

        for line in lines where line.hasPrefix("#EXT-X-MEDIA:") {
            let mType = extractAttr("TYPE", from: line)?.uppercased() ?? ""
            let name = extractQuotedAttr("NAME", from: line) ?? ""
            let lang = extractQuotedAttr("LANGUAGE", from: line) ?? ""
            let channels = extractQuotedAttr("CHANNELS", from: line)
            let uri = extractQuotedAttr("URI", from: line)
            let isDefault = extractAttr("DEFAULT", from: line)?.uppercased() == "YES"

            if mType == "AUDIO" {
                let resolved = SubtitleLanguageResolver.resolveFromMetadata(serverCode: lang, sourceLabel: name)
                let langName = resolved.isKnown ? resolved.name : "Unknown Language"
                let idx = audios.count
                audios.append(
                    InPlayerAudioTrack(
                        trackId: "hls_swift_\(idx)_\(lang.lowercased())",
                        nativeIndex: idx,
                        languageCode: resolved.isKnown ? resolved.code : lang,
                        languageName: langName,
                        displayName: resolved.isKnown ? resolved.name : name,
                        trackType: .hlsManifest,
                        codec: nil,
                        channelLayout: channels,
                        isDefault: isDefault,
                        isSelected: isDefault || idx == 0,
                        sourceIdentifier: "HLS Master",
                        availability: .selectable
                    )
                )
            } else if mType == "SUBTITLES", let uri, !uri.isEmpty {
                if let resolvedURL = URL(string: uri, relativeTo: baseURL)?.absoluteString {
                    subs.append((url: resolvedURL, label: name, language: lang))
                }
            }
        }

        return HLSMasterParseResult(audioTracks: audios, subtitleURLs: subs)
    }

    private static func extractQuotedAttr(_ key: String, from line: String) -> String? {
        let pattern = "\(key)=\"([^\"]+)\""
        guard let range = line.range(of: pattern, options: [.regularExpression, .caseInsensitive]) else {
            return nil
        }
        let match = String(line[range])
        guard let eqIdx = match.firstIndex(of: "=") else { return nil }
        return String(match[match.index(after: eqIdx)...]).trimmingCharacters(in: CharacterSet(charactersIn: "\""))
    }

    private static func extractAttr(_ key: String, from line: String) -> String? {
        let pattern = "\(key)=([^,\\s]+)"
        guard let range = line.range(of: pattern, options: [.regularExpression, .caseInsensitive]) else {
            return nil
        }
        let match = String(line[range])
        guard let eqIdx = match.firstIndex(of: "=") else { return nil }
        return String(match[match.index(after: eqIdx)...]).trimmingCharacters(in: CharacterSet(charactersIn: "\""))
    }
}
