import SwiftUI

struct PlayerServersPanel: View {
    let controller: CustomPlayerController
    let settings: AppSettingsManager
    let accent: Color

    private var activeMainPreset: StreamingServerPreset? {
        StreamingServerPreset.all.first {
            settings.streamingProviderBaseURL.localizedCaseInsensitiveContains($0.host)
        }
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            statusBanner

            if controller.internalServers.hasInternalServers {
                VStack(alignment: .leading, spacing: 4) {
                    Label("Available Sources", systemImage: "rectangle.stack")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.white.opacity(0.65))
                    if let main = activeMainPreset {
                        Text("Main Server: \(main.name)")
                            .font(.caption2)
                            .foregroundStyle(.white.opacity(0.5))
                    }
                }

                ForEach(controller.internalServers.servers) { server in
                    Button {
                        Task {
                            let ok = await controller.switchInternalServer(to: server)
                            if ok {
                                controller.state.activePanel = .none
                            }
                        }
                    } label: {
                        PlayerPanelRow(
                            title: server.name,
                            subtitle: server.sourceType.rawValue,
                            isSelected: server.isSelected,
                            accent: accent
                        )
                    }
                    .buttonStyle(.plain)
                    .disabled(!server.isAvailable)
                }

                Divider().background(Color.white.opacity(0.1))
            }

            Label("Main Streaming Providers", systemImage: "server.rack")
                .font(.caption.weight(.bold))
                .foregroundStyle(.white.opacity(0.65))

            ForEach(StreamingServerPreset.all) { preset in
                let isSelected = settings.streamingProviderBaseURL.localizedCaseInsensitiveContains(preset.host)
                Button {
                    controller.switchServer(to: preset, settings: settings)
                } label: {
                    PlayerPanelRow(title: preset.name, subtitle: preset.subtitle, isSelected: isSelected, accent: accent)
                }
                .buttonStyle(.plain)
            }
        }
    }

    @ViewBuilder
    private var statusBanner: some View {
        switch controller.internalServers.switchState {
        case .switching(let name):
            HStack(spacing: 10) {
                ProgressView().tint(accent)
                Text("Switching source to \(name)...")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.85))
            }
            .padding(10)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 10))

        case .failed(let message):
            Text(message)
                .font(.caption)
                .foregroundStyle(Color(hex: "FF8C92"))
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(accent.opacity(0.16), in: RoundedRectangle(cornerRadius: 10))

        case .switched(let name):
            Text("Source: \(name)")
                .font(.caption.weight(.semibold))
                .foregroundStyle(Color(hex: "7BE3A2"))
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.green.opacity(0.14), in: RoundedRectangle(cornerRadius: 10))

        case .idle:
            EmptyView()
        }
    }
}
