import SwiftUI

struct PlayerServersPanel: View {
    let controller: CustomPlayerController
    let settings: AppSettingsManager
    let accent: Color

    private var activeMainPresetName: String {
        if let preset = StreamingServerPreset.all.first(where: {
            settings.streamingProviderBaseURL.localizedCaseInsensitiveContains($0.host)
        }) {
            return preset.name
        }
        return controller.activeURL.host ?? "Current Provider"
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            statusBanner

            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Label("Playback Sources", systemImage: PlayerIcon.playbackSources)
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.white.opacity(0.7))
                    Text("Main Server: \(activeMainPresetName)")
                        .font(.caption2)
                        .foregroundStyle(.white.opacity(0.5))
                }

                Spacer()

                Button {
                    HapticManager.shared.selection()
                    controller.bridge.rescanInternalServers()
                } label: {
                    Label("Scan", systemImage: PlayerIcon.refresh)
                        .font(.caption2.weight(.bold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 6)
                        .background(Color.white.opacity(0.1), in: Capsule())
                }
                .buttonStyle(.plain)
                .accessibilityLabel("Scan Internal Playback Sources")
            }

            if controller.internalServers.servers.isEmpty {
                VStack(alignment: .leading, spacing: 8) {
                    HStack(alignment: .top, spacing: 10) {
                        Image(systemName: PlayerIcon.error)
                            .foregroundStyle(.white.opacity(0.55))
                        Text("No internal playback sources were exposed by \(controller.activeURL.host ?? "this provider"). Some providers stream inside a cross-origin iframe or provide only one default stream.")
                            .font(.caption)
                            .foregroundStyle(.white.opacity(0.68))
                    }
                }
                .padding(12)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 11))
            } else {
                if controller.internalServers.servers.count == 1 {
                    Text("Only available source for this provider")
                        .font(.caption2)
                        .foregroundStyle(.white.opacity(0.55))
                }

                ForEach(controller.internalServers.servers) { server in
                    Button {
                        Task {
                            let ok = await controller.switchInternalServer(to: server)
                            if ok {
                                controller.closePanel()
                            }
                        }
                    } label: {
                        PlayerPanelRow(
                            title: server.name,
                            subtitle: server.isAvailable ? server.sourceType.rawValue : "\(server.sourceType.rawValue) · Unavailable",
                            isSelected: server.isSelected,
                            accent: accent
                        )
                    }
                    .buttonStyle(.plain)
                    .disabled(!server.isAvailable)
                    .opacity(server.isAvailable ? 1.0 : 0.55)
                }
            }
        }
        .onAppear {
            controller.bridge.rescanInternalServers()
        }
    }

    @ViewBuilder
    private var statusBanner: some View {
        switch controller.internalServers.switchState {
        case .switching(let name):
            HStack(spacing: 10) {
                ProgressView().tint(accent)
                Text("Switching source to \(name)...")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.85))
            }
            .padding(10)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 10))

        case .failed(let message):
            VStack(alignment: .leading, spacing: 6) {
                Text(message)
                    .font(.caption)
                    .foregroundStyle(Color(hex: "FF8C92"))
                if let active = controller.internalServers.activeServer {
                    Text("Active source kept: \(active.name)")
                        .font(.caption2)
                        .foregroundStyle(.white.opacity(0.7))
                }
            }
            .padding(10)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(accent.opacity(0.16), in: RoundedRectangle(cornerRadius: 10))

        case .switched(let name):
            Text("Source: \(name)")
                .font(.caption.weight(.semibold))
                .foregroundStyle(Color(hex: "7BE3A2"))
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.green.opacity(0.14), in: RoundedRectangle(cornerRadius: 10))

        case .idle:
            EmptyView()
        }
    }
}
