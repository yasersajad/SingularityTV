import SwiftUI

struct PlayerServersPanel: View {
    let controller: CustomPlayerController
    let settings: AppSettingsManager
    let accent: Color

    private var activeMainPresetName: String {
        if let preset = StreamingServerPreset.all.first(where: {
            settings.streamingProviderBaseURL.localizedCaseInsensitiveContains($0.host)
        }) {
            return preset.name
        }
        return controller.activeURL.host ?? "Current Provider"
    }

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            statusBanner

            VStack(alignment: .leading, spacing: 4) {
                Label("Playback Sources", systemImage: "rectangle.stack")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.white.opacity(0.65))
                Text("Main Server: \(activeMainPresetName)")
                    .font(.caption2)
                    .foregroundStyle(.white.opacity(0.5))
            }

            if controller.internalServers.servers.isEmpty {
                HStack(alignment: .top, spacing: 10) {
                    Image(systemName: "server.rack")
                        .foregroundStyle(.white.opacity(0.55))
                    Text("This provider does not expose internal playback sources.")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.68))
                }
                .padding(12)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 11))
            } else {
                if controller.internalServers.servers.count == 1 {
                    Text("Only available source for this provider")
                        .font(.caption2)
                        .foregroundStyle(.white.opacity(0.55))
                }

                ForEach(controller.internalServers.servers) { server in
                    Button {
                        Task {
                            let ok = await controller.switchInternalServer(to: server)
                            if ok {
                                controller.state.activePanel = .none
                            }
                        }
                    } label: {
                        PlayerPanelRow(
                            title: server.name,
                            subtitle: server.isAvailable ? server.sourceType.rawValue : "\(server.sourceType.rawValue) · Unavailable",
                            isSelected: server.isSelected,
                            accent: accent
                        )
                    }
                    .buttonStyle(.plain)
                    .disabled(!server.isAvailable)
                    .opacity(server.isAvailable ? 1.0 : 0.55)
                }
            }
        }
    }

    @ViewBuilder
    private var statusBanner: some View {
        switch controller.internalServers.switchState {
        case .switching(let name):
            HStack(spacing: 10) {
                ProgressView().tint(accent)
                Text("Switching source to \(name)...")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.85))
            }
            .padding(10)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 10))

        case .failed(let message):
            VStack(alignment: .leading, spacing: 8) {
                Text(message)
                    .font(.caption)
                    .foregroundStyle(Color(hex: "FF8C92"))
                if let active = controller.internalServers.activeServer {
                    Text("Active source kept: \(active.name)")
                        .font(.caption2)
                        .foregroundStyle(.white.opacity(0.7))
                }
            }
            .padding(10)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(accent.opacity(0.16), in: RoundedRectangle(cornerRadius: 10))

        case .switched(let name):
            Text("Source: \(name)")
                .font(.caption.weight(.semibold))
                .foregroundStyle(Color(hex: "7BE3A2"))
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.green.opacity(0.14), in: RoundedRectangle(cornerRadius: 10))

        case .idle:
            EmptyView()
        }
    }
}
