import Foundation

enum AudioTrackType: String, Equatable, Sendable {
    case hlsManifest = "HLS Manifest"
    case hlsJs = "HLS.js"
    case html5 = "HTML5"
    case videoJs = "Video.js"
    case plyr = "Plyr"
    case jwPlayer = "JW Player"
    case domMenu = "Player Menu"
    case unknown = "Stream"
}

enum AudioTrackAvailability: String, Equatable, Sendable {
    case selectable
    case readOnly
    case unavailable
}

struct InPlayerAudioTrack: Identifiable, Equatable, Sendable {
    let trackId: String
    let nativeIndex: Int
    let languageCode: String
    let languageName: String
    let displayName: String
    let trackType: AudioTrackType
    let codec: String?
    let channelLayout: String?
    let isDefault: Bool
    var isSelected: Bool
    let sourceIdentifier: String
    let availability: AudioTrackAvailability

    var id: String { trackId }
    var label: String { displayName }
    var language: String { languageCode }
    var isEnabled: Bool { isSelected }

    var detailLine: String {
        var parts: [String] = []
        if !languageCode.isEmpty && languageCode.lowercased() != "und" {
            parts.append(languageCode.uppercased())
        }
        if let channelLayout, !channelLayout.isEmpty {
            parts.append(channelLayout)
        }
        if let codec, !codec.isEmpty {
            parts.append(codec)
        }
        if parts.isEmpty {
            parts.append(trackType.rawValue)
        }
        if isDefault {
            parts.append("Default")
        }
        return parts.joined(separator: " · ")
    }
}

enum AudioSwitchState: Equatable, Sendable {
    case idle
    case switching(String)
    case switched(String)
    case failed(String)
}
