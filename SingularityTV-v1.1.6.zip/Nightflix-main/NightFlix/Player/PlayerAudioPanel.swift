import SwiftUI

struct PlayerAudioPanel: View {
    let controller: CustomPlayerController
    let settings: AppSettingsManager
    let accent: Color

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            audioStatusBanner

            if controller.audio.supportsAudioDiscovery {
                HStack {
                    Label("Audio Tracks", systemImage: "waveform")
                        .font(.caption.weight(.bold))
                        .foregroundStyle(.white.opacity(0.65))
                    Spacer()
                    if let src = controller.audio.discoverySource {
                        Text(src)
                            .font(.caption2.weight(.semibold))
                            .foregroundStyle(.white.opacity(0.5))
                    }
                }

                ForEach(controller.audio.tracks) { track in
                    Button {
                        Task {
                            let ok = await controller.audio.selectTrack(track, bridge: controller.bridge)
                            if ok {
                                controller.savePlayerPreferences()
                                controller.state.activePanel = .none
                            }
                        }
                    } label: {
                        PlayerPanelRow(
                            title: track.displayName,
                            subtitle: track.detailLine,
                            isSelected: track.isSelected,
                            accent: accent
                        )
                    }
                    .buttonStyle(.plain)
                    .disabled(track.availability != .selectable)
                    .opacity(track.availability == .selectable ? 1.0 : 0.6)
                }
            } else {
                HStack(alignment: .top, spacing: 10) {
                    Image(systemName: "speaker.slash")
                        .foregroundStyle(.white.opacity(0.6))
                    Text("No selectable audio tracks were exposed by this server stream. Switch streaming servers below if you need another audio language.")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.68))
                }
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 10))
            }

            Divider().background(Color.white.opacity(0.1))

            Label("Streaming Servers", systemImage: "server.rack")
                .font(.caption.weight(.bold))
                .foregroundStyle(.white.opacity(0.65))

            ForEach(StreamingServerPreset.all) { preset in
                let isSelected = settings.streamingProviderBaseURL.localizedCaseInsensitiveContains(preset.host)
                Button {
                    controller.switchServer(to: preset, settings: settings)
                } label: {
                    PlayerPanelRow(title: preset.name, subtitle: preset.subtitle, isSelected: isSelected, accent: accent)
                }
                .buttonStyle(.plain)
            }
        }
    }

    @ViewBuilder
    private var audioStatusBanner: some View {
        switch controller.audio.switchState {
        case .switching(let name):
            HStack(spacing: 10) {
                ProgressView().tint(accent)
                Text("Switching audio to \(name)...")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.85))
            }
            .padding(10)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 10))

        case .failed(let message):
            Text(message)
                .font(.caption)
                .foregroundStyle(Color(hex: "FF8C92"))
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(accent.opacity(0.16), in: RoundedRectangle(cornerRadius: 10))

        case .switched(let name):
            Text("Audio: \(name)")
                .font(.caption.weight(.semibold))
                .foregroundStyle(Color(hex: "7BE3A2"))
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.green.opacity(0.14), in: RoundedRectangle(cornerRadius: 10))

        case .idle:
            EmptyView()
        }
    }
}
