import SwiftUI

struct PlayerAudioPanel: View {
    let controller: CustomPlayerController
    let settings: AppSettingsManager
    let accent: Color

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            if controller.audio.supportsExternalAudioSelection {
                Text("Audio Tracks")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.white.opacity(0.6))

                ForEach(controller.audio.tracks) { track in
                    Button {
                        controller.bridge.selectAudioTrack(index: track.id)
                        controller.state.activePanel = .none
                    } label: {
                        PlayerPanelRow(
                            title: track.label,
                            subtitle: track.language.isEmpty ? nil : track.language.uppercased(),
                            isSelected: track.isEnabled,
                            accent: accent
                        )
                    }
                    .buttonStyle(.plain)
                }
            } else {
                Text("This stream does not expose selectable audio tracks to WebKit. Switch streaming servers below if you need another audio source.")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.68))
                    .padding(10)
                    .background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 10))
            }

            Text("Streaming Servers")
                .font(.caption.weight(.bold))
                .foregroundStyle(.white.opacity(0.6))

            ForEach(StreamingServerPreset.all) { preset in
                let isSelected = settings.streamingProviderBaseURL.localizedCaseInsensitiveContains(preset.host)
                Button {
                    controller.switchServer(to: preset, settings: settings)
                } label: {
                    PlayerPanelRow(title: preset.name, subtitle: preset.subtitle, isSelected: isSelected, accent: accent)
                }
                .buttonStyle(.plain)
            }
        }
    }
}
