import Foundation
import Observation
import SwiftUI

struct ProfilePlayerPrefs: Codable, Equatable {
    var autoplayNextEpisode: Bool = true
    var skipIntroEnabled: Bool = true
    var playbackSpeed: Double = 1.0
    var isVideoFill: Bool = false
    var preferredAudioLanguage: String?
    var subtitleLanguagePreference: String?
}

@MainActor
@Observable
final class CustomPlayerController {
    let initialItem: WatchItem
    private weak var continueWatchingManager: ContinueWatchingManager?
    private weak var historyManager: WatchHistoryManager?

    let state = PlayerStateManager()
    let subtitles = PlayerSubtitleManager()
    let audio = PlayerAudioManager()
    let internalServers = InternalServerManager()
    let bridge = PlayerBridgeController()

    private(set) var activeURL: URL
    private(set) var mediaSessionGeneration: Int = 1
    private var lastPersistedSeconds: Double = -.greatestFiniteMagnitude
    private var chromeHideTask: Task<Void, Never>?
    private var skipFeedbackTask: Task<Void, Never>?
    private var countdownTask: Task<Void, Never>?
    private var episodesTask: Task<Void, Never>?

    private static let persistThreshold: Double = 5
    private static let completionFraction: Double = 0.95
    private static let prefsKeyPrefix = "singularity.playerPrefs."

    init(
        item: WatchItem,
        continueWatchingManager: ContinueWatchingManager?,
        historyManager: WatchHistoryManager? = nil
    ) {
        self.initialItem = item
        self.continueWatchingManager = continueWatchingManager
        self.historyManager = historyManager
        self.activeURL = item.generatedURL
        self.state.lifecycle = .preparing
        self.state.playingSeason = item.season
        self.state.playingEpisode = item.episode
        self.state.playingEpisodeName = item.episodeName

        let pid = SingularitySessionManager.shared.activeProfileId
        self.subtitles.loadStyle(for: pid)
        self.loadPlayerPreferences(for: pid)
    }

    func onAppear() {
        state.lifecycle = .loading
        showChrome()
        loadEpisodesIfSeries()
    }

    func onDisappear() {
        state.lifecycle = .disposed
        bridge.isDisposed = true
        chromeHideTask?.cancel()
        skipFeedbackTask?.cancel()
        countdownTask?.cancel()
        episodesTask?.cancel()
        persistFinalProgressOnExit()
    }

    func saveSubtitleStyle() {
        let pid = SingularitySessionManager.shared.activeProfileId
        subtitles.saveStyle(for: pid)
    }

    func loadPlayerPreferences(for profileId: String) {
        if let data = UserDefaults.standard.data(forKey: Self.prefsKeyPrefix + profileId),
           let prefs = try? JSONDecoder().decode(ProfilePlayerPrefs.self, from: data) {
            state.autoplayNextEnabled = prefs.autoplayNextEpisode
            state.skipIntroEnabled = prefs.skipIntroEnabled
            state.playbackRate = prefs.playbackSpeed
            state.isVideoFill = prefs.isVideoFill
        }
    }

    func savePlayerPreferences() {
        let pid = SingularitySessionManager.shared.activeProfileId
        let prefs = ProfilePlayerPrefs(
            autoplayNextEpisode: state.autoplayNextEnabled,
            skipIntroEnabled: state.skipIntroEnabled,
            playbackSpeed: state.playbackRate,
            isVideoFill: state.isVideoFill,
            preferredAudioLanguage: audio.activeTrack?.languageCode,
            subtitleLanguagePreference: subtitles.activeTrackId
        )
        if let data = try? JSONEncoder().encode(prefs) {
            UserDefaults.standard.set(data, forKey: Self.prefsKeyPrefix + pid)
        }
    }

    func toggleChrome() {
        if state.activePanel != .none {
            state.activePanel = .none
            showChrome()
            return
        }
        if state.isChromeVisible {
            chromeHideTask?.cancel()
            state.isChromeVisible = false
        } else {
            showChrome()
        }
    }

    func showChrome() {
        state.isChromeVisible = true
        resetChromeTimer()
    }

    func resetChromeTimer() {
        chromeHideTask?.cancel()
        guard state.activePanel == .none else { return }
        chromeHideTask = Task { @MainActor [weak self] in
            try? await Task.sleep(for: .seconds(4.0))
            guard !Task.isCancelled, let self, self.state.lifecycle != .disposed else { return }
            if self.state.activePanel == .none && self.state.nextEpisodeCountdown == nil {
                self.state.isChromeVisible = false
            }
        }
    }

    func openPanel(_ panel: PlayerActivePanel) {
        HapticManager.shared.selection()
        chromeHideTask?.cancel()
        state.isChromeVisible = true
        state.activePanel = (state.activePanel == panel) ? .none : panel
        if state.activePanel == .none {
            resetChromeTimer()
        }
    }

    func togglePlayPause() {
        guard state.lifecycle != .disposed else { return }
        HapticManager.shared.lightImpact()
        bridge.togglePlayPause { [weak self] ok in
            guard ok, let self, self.state.lifecycle != .disposed else { return }
            self.state.isPlaying.toggle()
            self.state.lifecycle = self.state.isPlaying ? .playing : .paused
        }
        resetChromeTimer()
    }

    func skip(by seconds: Double) {
        guard state.lifecycle != .disposed else { return }
        HapticManager.shared.lightImpact()
        bridge.skip(by: seconds) { [weak self] ok in
            guard ok, let self, self.state.lifecycle != .disposed else { return }
            let nextTime = max(0, min(self.state.duration > 0 ? self.state.duration : 1e9, self.state.currentTime + seconds))
            self.state.currentTime = nextTime
            self.showSkipFeedback(seconds: seconds)
        }
        resetChromeTimer()
    }

    func seek(to fraction: Double) {
        guard state.lifecycle != .disposed, state.duration > 0 else { return }
        let target = max(0, min(state.duration, fraction * state.duration))
        state.currentTime = target
        bridge.seek(to: target)
        resetChromeTimer()
    }

    func setPlaybackRate(_ rate: Double) {
        guard state.lifecycle != .disposed else { return }
        HapticManager.shared.selection()
        state.playbackRate = rate
        bridge.setPlaybackRate(rate)
        savePlayerPreferences()
        resetChromeTimer()
    }

    func toggleMute() {
        guard state.lifecycle != .disposed else { return }
        HapticManager.shared.selection()
        state.isMuted.toggle()
        bridge.setVolume(state.volume, muted: state.isMuted)
        resetChromeTimer()
    }

    var isSkipIntroVisible: Bool {
        guard state.skipIntroEnabled,
              !state.didSkipIntro,
              let intro = state.introWindow,
              intro.isValid else {
            return false
        }
        if intro.hasDomButton {
            return true
        }
        if let start = intro.start, let end = intro.end {
            return state.currentTime >= start && state.currentTime < end
        }
        return false
    }

    func skipIntro() {
        guard let intro = state.introWindow, intro.isValid else { return }
        HapticManager.shared.impactStrong()
        bridge.triggerSkipIntro(endSeconds: intro.end) { [weak self] ok in
            guard ok, let self, self.state.lifecycle != .disposed else { return }
            self.state.didSkipIntro = true
            if let end = intro.end, end > self.state.currentTime {
                self.state.currentTime = end
            }
        }
        resetChromeTimer()
    }

    func switchInternalServer(to server: InternalServerOption) async -> Bool {
        HapticManager.shared.selection()
        let ok = await internalServers.selectServer(server, bridge: bridge)
        guard ok else { return false }
        mediaSessionGeneration &+= 1
        state.isLoading = true
        state.qualityLevels = []
        state.introWindow = nil
        state.didSkipIntro = false
        state.serverAutoplaySignal = nil
        audio.reset()
        subtitles.resetForNewMedia()
        resetChromeTimer()
        return true
    }

    func retry() {
        HapticManager.shared.lightImpact()
        mediaSessionGeneration &+= 1
        state.lifecycle = .loading
        state.isSourceUnavailable = false
        state.errorMessage = nil
        state.isLoading = true
        state.reloadToken += 1
    }

    func switchServer(to preset: StreamingServerPreset, settings: AppSettingsManager) {
        HapticManager.shared.selection()
        settings.streamingProviderBaseURL = preset.host
        let resume = state.currentTime >= 5 ? Int(state.currentTime) : nil
        if let newURL = StreamingProviderURLBuilder.buildURL(
            baseURL: preset.host,
            type: initialItem.type,
            tmdbId: Int(initialItem.tmdbId) ?? 0,
            season: state.playingSeason ?? initialItem.season,
            episode: state.playingEpisode ?? initialItem.episode,
            progressSeconds: resume
        ) {
            beginMediaTransition(url: newURL)
        }
    }

    private func beginMediaTransition(url: URL) {
        mediaSessionGeneration &+= 1
        countdownTask?.cancel()
        state.lifecycle = .switching
        state.nextEpisodeCountdown = nil
        state.didDismissNextEpisodeOverlay = false
        state.isSourceUnavailable = false
        state.errorMessage = nil
        state.isLoading = true
        state.activePanel = .none
        state.qualityLevels = []
        state.introWindow = nil
        state.didSkipIntro = false
        state.serverAutoplaySignal = nil
        state.capabilities = PlayerCapabilities()
        audio.reset()
        subtitles.resetForNewMedia()
        internalServers.reset(for: url.host ?? "")
        activeURL = url
        state.reloadToken += 1
        resetChromeTimer()
    }

    var hasNextEpisode: Bool {
        nextEpisodePayload != nil
    }

    var hasPreviousEpisode: Bool {
        previousEpisodePayload != nil
    }

    var nextEpisodePayload: NFEpisodePayload? {
        guard initialItem.type == .tv, let currentEp = state.playingEpisode else { return nil }
        return state.seasonEpisodes.first { $0.episodeNumber == currentEp + 1 }
    }

    var previousEpisodePayload: NFEpisodePayload? {
        guard initialItem.type == .tv, let currentEp = state.playingEpisode else { return nil }
        return state.seasonEpisodes.first { $0.episodeNumber == currentEp - 1 }
    }

    func playEpisode(_ ep: NFEpisodePayload) {
        guard initialItem.type == .tv,
              let season = state.playingSeason ?? initialItem.season,
              let tmdbInt = Int(initialItem.tmdbId),
              let url = StreamingProviderURLBuilder.tvURL(
                tmdbId: tmdbInt,
                season: season,
                episode: ep.episodeNumber
              ) else { return }

        HapticManager.shared.impactStrong()
        state.playingEpisode = ep.episodeNumber
        state.playingEpisodeName = ep.name
        state.currentTime = 0
        state.duration = 0
        lastPersistedSeconds = -.greatestFiniteMagnitude
        beginMediaTransition(url: url)

        let newWatchItem = WatchItem(
            type: .tv,
            title: initialItem.title,
            tmdbId: initialItem.tmdbId,
            season: season,
            episode: ep.episodeNumber,
            episodeName: ep.name,
            posterPath: initialItem.posterPath,
            generatedURL: url
        )
        historyManager?.add(newWatchItem)
        continueWatchingManager?.addOrUpdate(
            item: ContinueWatchingItem(
                type: .tv,
                title: initialItem.title,
                tmdbId: initialItem.tmdbId,
                season: season,
                episode: ep.episodeNumber,
                episodeName: ep.name,
                posterPath: initialItem.posterPath,
                playableURL: url
            )
        )
    }

    func playNextEpisode() {
        guard let next = nextEpisodePayload else { return }
        playEpisode(next)
    }

    func playPreviousEpisode() {
        guard let prev = previousEpisodePayload else { return }
        playEpisode(prev)
    }

    func cancelNextEpisodeCountdown() {
        countdownTask?.cancel()
        state.nextEpisodeCountdown = nil
        state.didDismissNextEpisodeOverlay = true
    }

    private func loadEpisodesIfSeries() {
        guard initialItem.type == .tv,
              let season = state.playingSeason ?? initialItem.season,
              let tmdbInt = Int(initialItem.tmdbId) else { return }

        let capturedGen = mediaSessionGeneration
        state.isLoadingEpisodes = true
        episodesTask?.cancel()
        episodesTask = Task { [weak self] in
            let eps = (try? await NFCatalogService.season(seriesId: tmdbInt, number: season)) ?? []
            guard !Task.isCancelled, let self, self.mediaSessionGeneration == capturedGen, self.state.lifecycle != .disposed else { return }
            self.state.seasonEpisodes = eps
            if self.state.playingEpisodeName == nil,
               let cur = eps.first(where: { $0.episodeNumber == self.state.playingEpisode }) {
                self.state.playingEpisodeName = cur.name
            }
            self.state.isLoadingEpisodes = false
        }
    }

    func handleBridgeEvent(_ event: PlayerBridgeEvent) {
        guard state.lifecycle != .disposed else { return }

        switch event {
        case .userInteraction:
            showChrome()

        case .sourceUnavailable:
            state.lifecycle = .failed
            state.isSourceUnavailable = true

        case .webContentProcessTerminated:
            if state.webRecoveryAttempts < 2 {
                state.webRecoveryAttempts += 1
                state.lifecycle = .recovering
                state.isLoading = true
                state.reloadToken += 1
            } else {
                state.lifecycle = .failed
                state.errorMessage = "The video player stopped unexpectedly. Please retry or switch servers."
            }

        case .discoveredInternalServers(let servers):
            state.capabilities.supportsInternalServerSelection = servers.count > 1
            internalServers.updateDiscoveredServers(servers, for: activeURL.host ?? "")

        case .discoveredSubtitle(let sub):
            state.capabilities.supportsSiteSubtitleFiles = true
            subtitles.addDiscoveredSiteSubtitle(sub, referer: activeURL.absoluteString)

        case .discoveredAudioTracks(let tracks, let source):
            state.capabilities.supportsAudioTrackDiscovery = !tracks.isEmpty
            state.capabilities.supportsAudioTrackSelection = tracks.contains { $0.availability == .selectable }
            audio.updateDiscoveredTracks(tracks, source: source)

        case .discoveredQualityLevels(let levels):
            if !levels.isEmpty {
                state.qualityLevels = levels
            }

        case .discoveredIntroWindow(let intro):
            state.capabilities.supportsSkipIntro = intro.isValid
            state.introWindow = intro

        case .discoveredAutoplaySignal(let signal):
            state.capabilities.supportsAutoplayNextEpisode = true
            state.serverAutoplaySignal = signal

        case .mediaSnapshot(let snap):
            state.canControlMediaElement = snap.hasVideoElement
            state.capabilities.supportsPlaybackSpeed = snap.hasVideoElement
            if snap.hasVideoElement {
                state.lifecycle = snap.isPlaying ? .playing : (state.duration > 0 ? .paused : .ready)
            }
            if snap.currentTime > 0 { state.currentTime = snap.currentTime }
            if snap.duration > 0 { state.duration = snap.duration }
            state.isPlaying = snap.isPlaying
            state.isMuted = snap.isMuted
            state.volume = snap.volume
            state.playbackRate = snap.playbackRate
            if !snap.textTracks.isEmpty {
                state.capabilities.supportsSubtitleTrackDiscovery = true
                state.capabilities.supportsSubtitleTrackSelection = true
                subtitles.updateInPlayerTracks(snap.textTracks)
            }
            if !snap.audioTracks.isEmpty {
                state.capabilities.supportsAudioTrackDiscovery = true
                state.capabilities.supportsAudioTrackSelection = snap.audioTracks.contains { $0.availability == .selectable }
                audio.updateDiscoveredTracks(snap.audioTracks, source: snap.audioTracks.first?.sourceIdentifier)
            }
            if !snap.qualityLevels.isEmpty {
                state.qualityLevels = snap.qualityLevels
            }

            evaluateNextEpisodeTrigger()
            persistThrottledProgress(
                currentTime: state.currentTime,
                duration: state.duration,
                isDiscrete: false,
                isEnded: false
            )

        case .progress(let prog):
            guard prog.id.isEmpty || prog.id == initialItem.tmdbId else { return }
            if initialItem.type == .tv {
                state.playingSeason = prog.season ?? state.playingSeason
                state.playingEpisode = prog.episode ?? state.playingEpisode
            }
            if prog.currentTime > 0 { state.currentTime = prog.currentTime }
            if prog.duration > 0 { state.duration = prog.duration }
            if prog.kind == .play {
                state.isPlaying = true
                state.lifecycle = .playing
            }
            if prog.kind == .pause {
                state.isPlaying = false
                state.lifecycle = .paused
            }
            if prog.kind == .ended {
                state.isPlaying = false
                state.lifecycle = .finished
            }

            let isDiscrete = prog.kind == .pause || prog.kind == .seeked || prog.kind == .ended
            let isEnded = prog.kind == .ended || prog.fraction >= Self.completionFraction
            persistThrottledProgress(
                currentTime: prog.currentTime,
                duration: prog.duration,
                isDiscrete: isDiscrete,
                isEnded: isEnded
            )
            evaluateNextEpisodeTrigger(forceEnded: prog.kind == .ended)
        }
    }

    private func evaluateNextEpisodeTrigger(forceEnded: Bool = false) {
        guard initialItem.type == .tv,
              state.autoplayNextEnabled,
              hasNextEpisode,
              !state.didDismissNextEpisodeOverlay,
              state.nextEpisodeCountdown == nil else { return }

        let serverTriggered = state.serverAutoplaySignal?.hasNextButton == true
        let nearEnd = state.duration > 60 && (state.duration - state.currentTime) <= 12
        guard forceEnded || nearEnd || (serverTriggered && nearEnd) else { return }

        state.nextEpisodeCountdown = 8
        let capturedGen = mediaSessionGeneration
        countdownTask?.cancel()
        countdownTask = Task { @MainActor [weak self] in
            while let count = self?.state.nextEpisodeCountdown, count > 0, !Task.isCancelled {
                try? await Task.sleep(for: .seconds(1))
                guard !Task.isCancelled, let self, self.mediaSessionGeneration == capturedGen, self.state.lifecycle != .disposed else { return }
                if let c = self.state.nextEpisodeCountdown {
                    if c <= 1 {
                        self.state.nextEpisodeCountdown = nil
                        self.playNextEpisode()
                        return
                    } else {
                        self.state.nextEpisodeCountdown = c - 1
                    }
                }
            }
        }
    }

    private func persistThrottledProgress(
        currentTime: Double,
        duration: Double,
        isDiscrete: Bool,
        isEnded: Bool
    ) {
        guard let continueWatchingManager else { return }

        if initialItem.type == .movie, isEnded {
            continueWatchingManager.markFinished(type: initialItem.type, tmdbId: initialItem.tmdbId)
            SingularitySessionManager.shared.pushProgressAtomic(
                type: initialItem.type,
                tmdbId: initialItem.tmdbId,
                season: initialItem.season,
                episode: initialItem.episode,
                positionSeconds: duration,
                durationSeconds: duration,
                watched: true
            )
            return
        }

        if !isDiscrete && abs(currentTime - lastPersistedSeconds) < Self.persistThreshold {
            return
        }
        guard currentTime > 0 else { return }
        lastPersistedSeconds = currentTime

        let season = state.playingSeason ?? initialItem.season
        let episode = state.playingEpisode ?? initialItem.episode
        let epName = (season == initialItem.season && episode == initialItem.episode)
            ? initialItem.episodeName
            : state.playingEpisodeName

        continueWatchingManager.recordProgress(
            type: initialItem.type,
            tmdbId: initialItem.tmdbId,
            title: initialItem.title,
            posterPath: initialItem.posterPath,
            season: season,
            episode: episode,
            episodeName: epName,
            positionSeconds: currentTime,
            durationSeconds: duration
        )

        SingularitySessionManager.shared.pushProgressAtomic(
            type: initialItem.type,
            tmdbId: initialItem.tmdbId,
            season: season,
            episode: episode,
            positionSeconds: currentTime,
            durationSeconds: duration,
            watched: isEnded
        )
    }

    private func persistFinalProgressOnExit() {
        guard state.currentTime > 5 else { return }
        persistThrottledProgress(
            currentTime: state.currentTime,
            duration: state.duration,
            isDiscrete: true,
            isEnded: state.duration > 0 && (state.currentTime / state.duration) >= Self.completionFraction
        )
    }

    private func showSkipFeedback(seconds: Double) {
        skipFeedbackTask?.cancel()
        state.skipFeedbackIsForward = seconds >= 0
        state.skipFeedbackText = seconds >= 0 ? "+\(Int(seconds))s" : "\(Int(seconds))s"
        skipFeedbackTask = Task { @MainActor [weak self] in
            try? await Task.sleep(for: .milliseconds(750))
            guard !Task.isCancelled else { return }
            self?.state.skipFeedbackText = nil
        }
    }
}
