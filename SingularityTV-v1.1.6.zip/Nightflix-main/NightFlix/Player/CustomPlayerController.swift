import Foundation
import Observation
import SwiftUI

@MainActor
@Observable
final class CustomPlayerController {
    let initialItem: WatchItem
    private weak var continueWatchingManager: ContinueWatchingManager?
    private weak var historyManager: WatchHistoryManager?

    let state = PlayerStateManager()
    let subtitles = PlayerSubtitleManager()
    let audio = PlayerAudioManager()
    let bridge = PlayerBridgeController()

    private(set) var activeURL: URL
    private var lastPersistedSeconds: Double = -.greatestFiniteMagnitude
    private var chromeHideTask: Task<Void, Never>?
    private var skipFeedbackTask: Task<Void, Never>?
    private var countdownTask: Task<Void, Never>?
    private var episodesTask: Task<Void, Never>?

    private static let persistThreshold: Double = 5
    private static let completionFraction: Double = 0.95

    init(
        item: WatchItem,
        continueWatchingManager: ContinueWatchingManager?,
        historyManager: WatchHistoryManager? = nil
    ) {
        self.initialItem = item
        self.continueWatchingManager = continueWatchingManager
        self.historyManager = historyManager
        self.activeURL = item.generatedURL
        self.state.playingSeason = item.season
        self.state.playingEpisode = item.episode
        self.state.playingEpisodeName = item.episodeName

        let pid = SingularitySessionManager.shared.activeProfileId
        self.subtitles.loadStyle(for: pid)
    }

    func onAppear() {
        showChrome()
        loadEpisodesIfSeries()
    }

    func onDisappear() {
        chromeHideTask?.cancel()
        skipFeedbackTask?.cancel()
        countdownTask?.cancel()
        episodesTask?.cancel()
        persistFinalProgressOnExit()
    }

    func saveSubtitleStyle() {
        let pid = SingularitySessionManager.shared.activeProfileId
        subtitles.saveStyle(for: pid)
    }

    // MARK: - Chrome & Gestures

    func toggleChrome() {
        if state.activePanel != .none {
            state.activePanel = .none
            showChrome()
            return
        }
        if state.isChromeVisible {
            chromeHideTask?.cancel()
            state.isChromeVisible = false
        } else {
            showChrome()
        }
    }

    func showChrome() {
        state.isChromeVisible = true
        resetChromeTimer()
    }

    func resetChromeTimer() {
        chromeHideTask?.cancel()
        guard state.activePanel == .none else { return }
        chromeHideTask = Task { @MainActor [weak self] in
            try? await Task.sleep(for: .seconds(4.0))
            guard !Task.isCancelled, let self else { return }
            if self.state.activePanel == .none && self.state.nextEpisodeCountdown == nil {
                self.state.isChromeVisible = false
            }
        }
    }

    func openPanel(_ panel: PlayerActivePanel) {
        HapticManager.shared.selection()
        chromeHideTask?.cancel()
        state.isChromeVisible = true
        state.activePanel = (state.activePanel == panel) ? .none : panel
        if state.activePanel == .none {
            resetChromeTimer()
        }
    }

    // MARK: - Playback Controls

    func togglePlayPause() {
        HapticManager.shared.lightImpact()
        bridge.togglePlayPause()
        state.isPlaying.toggle()
        resetChromeTimer()
    }

    func skip(by seconds: Double) {
        HapticManager.shared.lightImpact()
        bridge.skip(by: seconds)
        let nextTime = max(0, min(state.duration > 0 ? state.duration : 1e9, state.currentTime + seconds))
        state.currentTime = nextTime
        showSkipFeedback(seconds: seconds)
        resetChromeTimer()
    }

    func seek(to fraction: Double) {
        guard state.duration > 0 else { return }
        let target = max(0, min(state.duration, fraction * state.duration))
        state.currentTime = target
        bridge.seek(to: target)
        resetChromeTimer()
    }

    func setPlaybackRate(_ rate: Double) {
        HapticManager.shared.selection()
        state.playbackRate = rate
        bridge.setPlaybackRate(rate)
        resetChromeTimer()
    }

    func toggleMute() {
        HapticManager.shared.selection()
        state.isMuted.toggle()
        bridge.setVolume(state.volume, muted: state.isMuted)
        resetChromeTimer()
    }

    func retry() {
        HapticManager.shared.lightImpact()
        state.isSourceUnavailable = false
        state.errorMessage = nil
        state.isLoading = true
        state.reloadToken += 1
    }

    func switchServer(to preset: StreamingServerPreset, settings: AppSettingsManager) {
        HapticManager.shared.selection()
        settings.streamingProviderBaseURL = preset.host
        let resume = state.currentTime >= 5 ? Int(state.currentTime) : nil
        if let newURL = StreamingProviderURLBuilder.buildURL(
            baseURL: preset.host,
            type: initialItem.type,
            tmdbId: Int(initialItem.tmdbId) ?? 0,
            season: state.playingSeason ?? initialItem.season,
            episode: state.playingEpisode ?? initialItem.episode,
            progressSeconds: resume
        ) {
            state.isSourceUnavailable = false
            state.errorMessage = nil
            state.isLoading = true
            activeURL = newURL
            state.reloadToken += 1
            state.activePanel = .none
            resetChromeTimer()
        }
    }

    // MARK: - Series Episodes

    var hasNextEpisode: Bool {
        nextEpisodePayload != nil
    }

    var hasPreviousEpisode: Bool {
        previousEpisodePayload != nil
    }

    var nextEpisodePayload: NFEpisodePayload? {
        guard initialItem.type == .tv, let currentEp = state.playingEpisode else { return nil }
        return state.seasonEpisodes.first { $0.episodeNumber == currentEp + 1 }
    }

    var previousEpisodePayload: NFEpisodePayload? {
        guard initialItem.type == .tv, let currentEp = state.playingEpisode else { return nil }
        return state.seasonEpisodes.first { $0.episodeNumber == currentEp - 1 }
    }

    func playEpisode(_ ep: NFEpisodePayload) {
        guard initialItem.type == .tv,
              let season = state.playingSeason ?? initialItem.season,
              let tmdbInt = Int(initialItem.tmdbId),
              let url = StreamingProviderURLBuilder.tvURL(
                tmdbId: tmdbInt,
                season: season,
                episode: ep.episodeNumber
              ) else { return }

        HapticManager.shared.impactStrong()
        countdownTask?.cancel()
        state.nextEpisodeCountdown = nil
        state.didDismissNextEpisodeOverlay = false
        state.playingEpisode = ep.episodeNumber
        state.playingEpisodeName = ep.name
        state.currentTime = 0
        state.duration = 0
        lastPersistedSeconds = -.greatestFiniteMagnitude
        state.isSourceUnavailable = false
        state.errorMessage = nil
        state.isLoading = true
        state.activePanel = .none
        subtitles.clearExternalSubtitles()

        activeURL = url
        state.reloadToken += 1

        let newWatchItem = WatchItem(
            type: .tv,
            title: initialItem.title,
            tmdbId: initialItem.tmdbId,
            season: season,
            episode: ep.episodeNumber,
            episodeName: ep.name,
            posterPath: initialItem.posterPath,
            generatedURL: url
        )
        historyManager?.add(newWatchItem)
        continueWatchingManager?.addOrUpdate(
            item: ContinueWatchingItem(
                type: .tv,
                title: initialItem.title,
                tmdbId: initialItem.tmdbId,
                season: season,
                episode: ep.episodeNumber,
                episodeName: ep.name,
                posterPath: initialItem.posterPath,
                playableURL: url
            )
        )
    }

    func playNextEpisode() {
        guard let next = nextEpisodePayload else { return }
        playEpisode(next)
    }

    func playPreviousEpisode() {
        guard let prev = previousEpisodePayload else { return }
        playEpisode(prev)
    }

    func cancelNextEpisodeCountdown() {
        countdownTask?.cancel()
        state.nextEpisodeCountdown = nil
        state.didDismissNextEpisodeOverlay = true
    }

    private func loadEpisodesIfSeries() {
        guard initialItem.type == .tv,
              let season = state.playingSeason ?? initialItem.season,
              let tmdbInt = Int(initialItem.tmdbId) else { return }

        state.isLoadingEpisodes = true
        episodesTask = Task { [weak self] in
            let eps = (try? await NFCatalogService.season(seriesId: tmdbInt, number: season)) ?? []
            guard !Task.isCancelled, let self else { return }
            self.state.seasonEpisodes = eps
            if self.state.playingEpisodeName == nil,
               let cur = eps.first(where: { $0.episodeNumber == self.state.playingEpisode }) {
                self.state.playingEpisodeName = cur.name
            }
            self.state.isLoadingEpisodes = false
        }
    }

    // MARK: - Bridge Events

    func handleBridgeEvent(_ event: PlayerBridgeEvent) {
        switch event {
        case .userInteraction:
            showChrome()

        case .sourceUnavailable:
            state.isSourceUnavailable = true

        case .mediaSnapshot(let snap):
            state.canControlMediaElement = snap.hasVideoElement
            if snap.currentTime > 0 { state.currentTime = snap.currentTime }
            if snap.duration > 0 { state.duration = snap.duration }
            state.isPlaying = snap.isPlaying
            state.isMuted = snap.isMuted
            state.volume = snap.volume
            state.playbackRate = snap.playbackRate
            subtitles.inPlayerTracks = snap.textTracks
            audio.tracks = snap.audioTracks

            evaluateNextEpisodeTrigger()
            persistThrottledProgress(
                currentTime: state.currentTime,
                duration: state.duration,
                isDiscrete: false,
                isEnded: false
            )

        case .progress(let prog):
            guard prog.id.isEmpty || prog.id == initialItem.tmdbId else { return }
            if initialItem.type == .tv {
                state.playingSeason = prog.season ?? state.playingSeason
                state.playingEpisode = prog.episode ?? state.playingEpisode
            }
            if prog.currentTime > 0 { state.currentTime = prog.currentTime }
            if prog.duration > 0 { state.duration = prog.duration }
            if prog.kind == .play { state.isPlaying = true }
            if prog.kind == .pause || prog.kind == .ended { state.isPlaying = false }

            let isDiscrete = prog.kind == .pause || prog.kind == .seeked || prog.kind == .ended
            let isEnded = prog.kind == .ended || prog.fraction >= Self.completionFraction
            persistThrottledProgress(
                currentTime: prog.currentTime,
                duration: prog.duration,
                isDiscrete: isDiscrete,
                isEnded: isEnded
            )
            evaluateNextEpisodeTrigger(forceEnded: prog.kind == .ended)
        }
    }

    private func evaluateNextEpisodeTrigger(forceEnded: Bool = false) {
        guard initialItem.type == .tv,
              hasNextEpisode,
              !state.didDismissNextEpisodeOverlay,
              state.nextEpisodeCountdown == nil else { return }

        let nearEnd = state.duration > 60 && (state.duration - state.currentTime) <= 12
        guard forceEnded || nearEnd else { return }

        state.nextEpisodeCountdown = 8
        countdownTask?.cancel()
        countdownTask = Task { @MainActor [weak self] in
            while let count = self?.state.nextEpisodeCountdown, count > 0, !Task.isCancelled {
                try? await Task.sleep(for: .seconds(1))
                guard !Task.isCancelled, let self else { return }
                if let c = self.state.nextEpisodeCountdown {
                    if c <= 1 {
                        self.state.nextEpisodeCountdown = nil
                        self.playNextEpisode()
                        return
                    } else {
                        self.state.nextEpisodeCountdown = c - 1
                    }
                }
            }
        }
    }

    private func persistThrottledProgress(
        currentTime: Double,
        duration: Double,
        isDiscrete: Bool,
        isEnded: Bool
    ) {
        guard let continueWatchingManager else { return }

        if initialItem.type == .movie, isEnded {
            continueWatchingManager.markFinished(type: initialItem.type, tmdbId: initialItem.tmdbId)
            SingularitySessionManager.shared.pushProgressAtomic(
                type: initialItem.type,
                tmdbId: initialItem.tmdbId,
                season: initialItem.season,
                episode: initialItem.episode,
                positionSeconds: duration,
                durationSeconds: duration,
                watched: true
            )
            return
        }

        if !isDiscrete && abs(currentTime - lastPersistedSeconds) < Self.persistThreshold {
            return
        }
        guard currentTime > 0 else { return }
        lastPersistedSeconds = currentTime

        let season = state.playingSeason ?? initialItem.season
        let episode = state.playingEpisode ?? initialItem.episode
        let epName = (season == initialItem.season && episode == initialItem.episode)
            ? initialItem.episodeName
            : state.playingEpisodeName

        continueWatchingManager.recordProgress(
            type: initialItem.type,
            tmdbId: initialItem.tmdbId,
            title: initialItem.title,
            posterPath: initialItem.posterPath,
            season: season,
            episode: episode,
            episodeName: epName,
            positionSeconds: currentTime,
            durationSeconds: duration
        )

        SingularitySessionManager.shared.pushProgressAtomic(
            type: initialItem.type,
            tmdbId: initialItem.tmdbId,
            season: season,
            episode: episode,
            positionSeconds: currentTime,
            durationSeconds: duration,
            watched: isEnded
        )
    }

    private func persistFinalProgressOnExit() {
        guard state.currentTime > 5 else { return }
        persistThrottledProgress(
            currentTime: state.currentTime,
            duration: state.duration,
            isDiscrete: true,
            isEnded: state.duration > 0 && (state.currentTime / state.duration) >= Self.completionFraction
        )
    }

    private func showSkipFeedback(seconds: Double) {
        skipFeedbackTask?.cancel()
        state.skipFeedbackIsForward = seconds > 0
        state.skipFeedbackText = seconds > 0 ? "+\(Int(seconds))s" : "\(Int(seconds))s"
        skipFeedbackTask = Task { @MainActor [weak self] in
            try? await Task.sleep(for: .milliseconds(700))
            guard !Task.isCancelled else { return }
            self?.state.skipFeedbackText = nil
        }
    }
}
