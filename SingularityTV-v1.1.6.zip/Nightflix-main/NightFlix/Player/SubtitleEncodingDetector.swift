import Foundation

struct SubtitleDecodeResult: Sendable {
    let text: String
    let encodingName: String
}

enum SubtitleEncodingDetector {
    static func decode(_ data: Data, preferredLanguage: String? = nil) -> SubtitleDecodeResult? {
        guard !data.isEmpty else { return nil }

        if data.count >= 3 && data[0] == 0xEF && data[1] == 0xBB && data[2] == 0xBF {
            let trimmed = data.dropFirst(3)
            if let str = String(data: trimmed, encoding: .utf8), isTextReadable(str) {
                return SubtitleDecodeResult(text: str, encodingName: "UTF-8 BOM")
            }
        }

        if data.count >= 2 && data[0] == 0xFF && data[1] == 0xFE {
            if let str = String(data: data, encoding: .utf16LittleEndian), isTextReadable(str) {
                return SubtitleDecodeResult(text: str, encodingName: "UTF-16 LE")
            }
        }

        if data.count >= 2 && data[0] == 0xFE && data[1] == 0xFF {
            if let str = String(data: data, encoding: .utf16BigEndian), isTextReadable(str) {
                return SubtitleDecodeResult(text: str, encodingName: "UTF-16 BE")
            }
        }

        if let utf8 = String(data: data, encoding: .utf8), isTextReadable(utf8) {
            return SubtitleDecodeResult(text: utf8, encodingName: "UTF-8")
        }

        let windowsArabic = String.Encoding(
            rawValue: CFStringConvertEncodingToNSStringEncoding(
                CFStringEncoding(CFStringEncodings.windowsArabic.rawValue)
            )
        )
        let isArabicPreferred = (preferredLanguage ?? "").lowercased().hasPrefix("ar")
        if isArabicPreferred, let arText = String(data: data, encoding: windowsArabic), isTextReadable(arText) {
            return SubtitleDecodeResult(text: arText, encodingName: "Windows-1256")
        }

        if let arText = String(data: data, encoding: windowsArabic),
           arText.range(of: "[\u{0600}-\u{06FF}]", options: .regularExpression) != nil,
           isTextReadable(arText) {
            return SubtitleDecodeResult(text: arText, encodingName: "Windows-1256")
        }

        if let cp1252 = String(data: data, encoding: .windowsCP1252), isTextReadable(cp1252) {
            return SubtitleDecodeResult(text: cp1252, encodingName: "Windows-1252")
        }

        if let latin1 = String(data: data, encoding: .isoLatin1), isTextReadable(latin1) {
            return SubtitleDecodeResult(text: latin1, encodingName: "ISO-8859-1")
        }

        return nil
    }

    static func isTextReadable(_ text: String) -> Bool {
        let sample = String(text.prefix(8000))
        guard !sample.isEmpty else { return false }
        var total = 0
        var badControl = 0
        var replacement = 0

        for scalar in sample.unicodeScalars {
            total += 1
            let v = scalar.value
            if v == 0xFFFD {
                replacement += 1
            } else if v < 0x20 && v != 0x09 && v != 0x0A && v != 0x0D {
                badControl += 1
            }
        }
        guard total > 0 else { return false }
        if Double(replacement) / Double(total) > 0.02 { return false }
        if Double(badControl) / Double(total) > 0.01 { return false }
        return true
    }
}
