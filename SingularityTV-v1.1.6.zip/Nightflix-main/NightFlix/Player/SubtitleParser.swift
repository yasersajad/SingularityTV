import Foundation

enum SubtitleFileFormat: String, Sendable {
    case srt = "SRT"
    case vtt = "WebVTT"
    case ass = "ASS/SSA"
    case unknown = "Unknown"
}

enum SubtitleParser {
    static func detectFormat(_ raw: String) -> SubtitleFileFormat {
        let trimmed = raw.trimmingCharacters(in: .whitespacesAndNewlines)
        if trimmed.hasPrefix("WEBVTT") {
            return .vtt
        }
        if trimmed.contains("[Script Info]") || trimmed.contains("Dialogue:") {
            return .ass
        }
        if trimmed.contains("-->") {
            return .srt
        }
        return .unknown
    }

    static func parse(_ raw: String) -> [SubtitleCue] {
        let cleanedRaw = raw
            .replacingOccurrences(of: "\u{FEFF}", with: "")
            .replacingOccurrences(of: "\r\n", with: "\n")
            .replacingOccurrences(of: "\r", with: "\n")

        let format = detectFormat(cleanedRaw)
        switch format {
        case .ass:
            return parseASS(cleanedRaw)
        case .vtt, .srt:
            return parseSRTAndVTT(cleanedRaw, isVTT: format == .vtt)
        case .unknown:
            return []
        }
    }

    static func activeCue(in cues: [SubtitleCue], at time: Double) -> SubtitleCue? {
        guard !cues.isEmpty else { return nil }
        var low = 0
        var high = cues.count - 1
        while low <= high {
            let mid = (low + high) / 2
            let cue = cues[mid]
            if time < cue.start {
                high = mid - 1
            } else if time > cue.end {
                low = mid + 1
            } else {
                return cue
            }
        }
        return nil
    }

    private static func parseSRTAndVTT(_ raw: String, isVTT: Bool) -> [SubtitleCue] {
        let lines = raw.components(separatedBy: "\n")
        var cues: [SubtitleCue] = []
        var i = 0
        var cueCounter = 0

        while i < lines.count {
            let line = lines[i].trimmingCharacters(in: .whitespaces)

            if isVTT && (line.hasPrefix("WEBVTT") || line.hasPrefix("NOTE") || line.hasPrefix("STYLE") || line.hasPrefix("REGION")) {
                i += 1
                while i < lines.count && !lines[i].trimmingCharacters(in: .whitespaces).isEmpty {
                    i += 1
                }
                continue
            }

            if line.contains("-->") {
                if let (start, end) = parseTimingLine(line) {
                    var textLines: [String] = []
                    i += 1
                    while i < lines.count {
                        let nextLine = lines[i].trimmingCharacters(in: .whitespaces)
                        if nextLine.isEmpty {
                            break
                        }
                        if nextLine.contains("-->") {
                            i -= 1
                            break
                        }
                        if Int(nextLine) != nil,
                           i + 1 < lines.count,
                           lines[i + 1].contains("-->") {
                            break
                        }
                        textLines.append(nextLine)
                        i += 1
                    }

                    let cleaned = cleanText(textLines.joined(separator: "\n"))
                    if !cleaned.isEmpty && end >= start {
                        cueCounter += 1
                        cues.append(SubtitleCue(id: cueCounter, start: start, end: end, text: cleaned))
                    }
                }
            }
            i += 1
        }

        return cues.sorted { $0.start < $1.start }
    }

    private static func parseASS(_ raw: String) -> [SubtitleCue] {
        let lines = raw.components(separatedBy: "\n")
        var cues: [SubtitleCue] = []
        var counter = 0

        for line in lines {
            let trimmed = line.trimmingCharacters(in: .whitespaces)
            guard trimmed.hasPrefix("Dialogue:") else { continue }
            let body = String(trimmed.dropFirst("Dialogue:".count)).trimmingCharacters(in: .whitespaces)
            let parts = body.split(separator: ",", maxSplits: 9, omittingEmptySubsequences: false)
            guard parts.count == 10,
                  let start = parseTimestamp(String(parts[1])),
                  let end = parseTimestamp(String(parts[2])) else {
                continue
            }
            let rawText = String(parts[9])
                .replacingOccurrences(of: "\\N", with: "\n")
                .replacingOccurrences(of: "\\n", with: "\n")
                .replacingOccurrences(of: "\\h", with: " ")
            let cleaned = cleanText(rawText)
            guard !cleaned.isEmpty, end >= start else { continue }
            counter += 1
            cues.append(SubtitleCue(id: counter, start: start, end: end, text: cleaned))
        }

        return cues.sorted { $0.start < $1.start }
    }

    private static func parseTimingLine(_ line: String) -> (Double, Double)? {
        let parts = line.components(separatedBy: "-->")
        guard parts.count >= 2 else { return nil }
        let startRaw = parts[0].trimmingCharacters(in: .whitespaces)
        let endToken = parts[1].trimmingCharacters(in: .whitespaces).components(separatedBy: .whitespaces).first ?? ""
        guard let start = parseTimestamp(startRaw), let end = parseTimestamp(endToken) else {
            return nil
        }
        return (start, end)
    }

    static func parseTimestamp(_ raw: String) -> Double? {
        let clean = raw
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: ",", with: ".")
        let parts = clean.split(separator: ":").map(String.init)
        if parts.count == 3,
           let h = Double(parts[0]),
           let m = Double(parts[1]),
           let s = Double(parts[2]),
           h.isFinite, m.isFinite, s.isFinite {
            return h * 3600 + m * 60 + s
        } else if parts.count == 2,
                  let m = Double(parts[0]),
                  let s = Double(parts[1]),
                  m.isFinite, s.isFinite {
            return m * 60 + s
        }
        return nil
    }

    private static func cleanText(_ text: String) -> String {
        text
            .replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression)
            .replacingOccurrences(of: "\\{[^}]*\\}", with: "", options: .regularExpression)
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }
}
