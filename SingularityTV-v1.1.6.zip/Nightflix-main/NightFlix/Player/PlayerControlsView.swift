import SwiftUI

struct PlayerControlsView: View {
    let controller: CustomPlayerController
    let accent: Color

    var body: some View {
        VStack(spacing: 0) {
            Spacer(minLength: 0)

            HStack(spacing: 42) {
                Button {
                    controller.skip(by: -10)
                } label: {
                    Image(systemName: "gobackward.10")
                        .font(.system(size: 28, weight: .semibold))
                        .foregroundStyle(.white)
                        .frame(width: 56, height: 56)
                        .background(Color.black.opacity(0.45), in: Circle())
                }
                .buttonStyle(NFScaleButtonStyle())
                .accessibilityLabel("Rewind 10 seconds")

                Button {
                    controller.togglePlayPause()
                } label: {
                    Image(systemName: controller.state.isPlaying ? "pause.fill" : "play.fill")
                        .font(.system(size: 34, weight: .bold))
                        .foregroundStyle(.white)
                        .frame(width: 72, height: 72)
                        .background(accent.opacity(0.92), in: Circle())
                        .shadow(color: accent.opacity(0.45), radius: 16)
                }
                .buttonStyle(NFScaleButtonStyle())
                .accessibilityLabel(controller.state.isPlaying ? "Pause" : "Play")

                Button {
                    controller.skip(by: 10)
                } label: {
                    Image(systemName: "goforward.10")
                        .font(.system(size: 28, weight: .semibold))
                        .foregroundStyle(.white)
                        .frame(width: 56, height: 56)
                        .background(Color.black.opacity(0.45), in: Circle())
                }
                .buttonStyle(NFScaleButtonStyle())
                .accessibilityLabel("Forward 10 seconds")
            }

            Spacer(minLength: 0)

            VStack(spacing: 10) {
                PlayerProgressBar(
                    currentTime: controller.state.currentTime,
                    duration: controller.state.duration,
                    progressFraction: controller.state.progressFraction,
                    accent: accent,
                    onSeekDragChanged: { controller.resetChromeTimer() },
                    onSeekEnded: { fraction in controller.seek(to: fraction) }
                )

                HStack(spacing: 14) {
                    Text(PlayerStateManager.formatTime(controller.state.currentTime))
                        .font(.caption.weight(.semibold).monospacedDigit())
                        .foregroundStyle(.white)

                    Spacer()

                    Button {
                        controller.toggleMute()
                    } label: {
                        Image(systemName: controller.state.isMuted ? "speaker.slash.fill" : "speaker.wave.2.fill")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(.white.opacity(0.9))
                    }
                    .buttonStyle(.plain)

                    Button {
                        controller.openPanel(.settings)
                    } label: {
                        Text(String(format: "%.2gx", controller.state.playbackRate))
                            .font(.caption.weight(.bold).monospacedDigit())
                            .foregroundStyle(.white)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(Color.white.opacity(0.14), in: Capsule())
                    }
                    .buttonStyle(.plain)

                    if controller.hasNextEpisode {
                        Button {
                            controller.playNextEpisode()
                        } label: {
                            Label("Next Ep", systemImage: "forward.end.fill")
                                .font(.caption.weight(.bold))
                                .foregroundStyle(.white)
                                .padding(.horizontal, 10)
                                .padding(.vertical, 5)
                                .background(accent, in: Capsule())
                        }
                        .buttonStyle(NFScaleButtonStyle())
                    }

                    Text("-\(PlayerStateManager.formatTime(controller.state.remainingTime)) / \(PlayerStateManager.formatTime(controller.state.duration))")
                        .font(.caption.weight(.medium).monospacedDigit())
                        .foregroundStyle(.white.opacity(0.75))
                }
            }
            .padding(.horizontal, 28)
            .padding(.bottom, 18)
            .padding(.top, 24)
            .background(
                LinearGradient(
                    colors: [.clear, .black.opacity(0.45), .black.opacity(0.86)],
                    startPoint: .top,
                    endPoint: .bottom
                )
                .ignoresSafeArea(edges: .bottom)
                .allowsHitTesting(false)
            )
        }
    }
}
