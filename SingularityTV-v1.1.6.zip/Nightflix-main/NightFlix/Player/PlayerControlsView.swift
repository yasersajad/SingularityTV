import SwiftUI

struct PlayerControlsView: View {
    let controller: CustomPlayerController
    let accent: Color

    var body: some View {
        ZStack {
            HStack(spacing: 52) {
                Button {
                    controller.skip(by: -10)
                } label: {
                    Image(systemName: "gobackward.10")
                        .font(.system(size: 27, weight: .semibold))
                        .foregroundStyle(.white)
                        .frame(width: 56, height: 56)
                        .background(Color.black.opacity(0.42), in: Circle())
                }
                .buttonStyle(NFScaleButtonStyle())
                .accessibilityLabel("Rewind 10 seconds")

                Button {
                    controller.togglePlayPause()
                } label: {
                    Image(systemName: controller.state.isPlaying ? "pause.fill" : "play.fill")
                        .font(.system(size: 36, weight: .bold))
                        .foregroundStyle(.white)
                        .frame(width: 74, height: 74)
                        .background(Color.black.opacity(0.5), in: Circle())
                        .overlay {
                            Circle().stroke(Color.white.opacity(0.22), lineWidth: 1)
                        }
                }
                .buttonStyle(NFScaleButtonStyle())
                .accessibilityLabel(controller.state.isPlaying ? "Pause" : "Play")

                Button {
                    controller.skip(by: 10)
                } label: {
                    Image(systemName: "goforward.10")
                        .font(.system(size: 27, weight: .semibold))
                        .foregroundStyle(.white)
                        .frame(width: 56, height: 56)
                        .background(Color.black.opacity(0.42), in: Circle())
                }
                .buttonStyle(NFScaleButtonStyle())
                .accessibilityLabel("Forward 10 seconds")
            }

            VStack(spacing: 0) {
                Spacer(minLength: 0)
                VStack(spacing: 10) {
                    PlayerProgressBar(
                        currentTime: controller.state.currentTime,
                        duration: controller.state.duration,
                        progressFraction: controller.state.progressFraction,
                        accent: accent,
                        onSeekDragChanged: { controller.resetChromeTimer() },
                        onSeekEnded: { fraction in controller.seek(to: fraction) }
                    )

                    HStack {
                        Text(PlayerStateManager.formatTime(controller.state.currentTime))
                            .font(.caption.weight(.semibold).monospacedDigit())
                            .foregroundStyle(.white)

                        Spacer()

                        Text("-\(PlayerStateManager.formatTime(controller.state.remainingTime))")
                            .font(.caption.weight(.medium).monospacedDigit())
                            .foregroundStyle(.white.opacity(0.75))
                    }

                    HStack(spacing: 18) {
                        if controller.initialItem.type == .tv {
                            bottomActionButton(icon: "list.bullet", title: "Episodes") {
                                controller.openPanel(.episodes)
                            }
                        }

                        bottomActionButton(
                            icon: "speedometer",
                            title: String(format: "%.2gx", controller.state.playbackRate)
                        ) {
                            controller.openPanel(.settings)
                        }

                        bottomActionButton(icon: "rectangle.stack", title: "Playback Servers") {
                            controller.openPanel(.servers)
                        }

                        Spacer()

                        Button {
                            controller.toggleMute()
                        } label: {
                            Image(systemName: controller.state.isMuted ? "speaker.slash.fill" : "speaker.wave.2.fill")
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(.white.opacity(0.9))
                        }
                        .buttonStyle(.plain)
                        .accessibilityLabel(controller.state.isMuted ? "Unmute" : "Mute")

                        if controller.hasNextEpisode {
                            Button {
                                controller.playNextEpisode()
                            } label: {
                                Label("Next Episode", systemImage: "forward.end.fill")
                                    .font(.caption.weight(.bold))
                                    .foregroundStyle(.white)
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 6)
                                    .background(Color.white.opacity(0.16), in: Capsule())
                            }
                            .buttonStyle(NFScaleButtonStyle())
                        }
                    }
                    .padding(.top, 2)
                }
                .padding(.horizontal, 28)
                .padding(.bottom, 12)
                .padding(.top, 26)
                .background(
                    LinearGradient(
                        colors: [.clear, .black.opacity(0.45), .black.opacity(0.88)],
                        startPoint: .top,
                        endPoint: .bottom
                    )
                    .ignoresSafeArea(edges: .bottom)
                    .allowsHitTesting(false)
                )
            }
        }
    }

    private func bottomActionButton(icon: String, title: String, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Label(title, systemImage: icon)
                .font(.caption.weight(.semibold))
                .foregroundStyle(.white.opacity(0.92))
        }
        .buttonStyle(.plain)
    }
}
