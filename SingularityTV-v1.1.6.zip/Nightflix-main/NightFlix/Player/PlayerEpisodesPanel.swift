import SwiftUI

struct PlayerEpisodesPanel: View {
    let controller: CustomPlayerController
    let accent: Color

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(spacing: 10) {
                if controller.hasPreviousEpisode {
                    Button {
                        controller.playPreviousEpisode()
                    } label: {
                        Label("Previous", systemImage: "backward.end.fill")
                            .font(.caption.weight(.bold))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .background(Color.white.opacity(0.1), in: Capsule())
                    }
                    .buttonStyle(.plain)
                }

                if controller.hasNextEpisode {
                    Button {
                        controller.playNextEpisode()
                    } label: {
                        Label("Next Episode", systemImage: "forward.end.fill")
                            .font(.caption.weight(.bold))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 12)
                            .padding(.vertical, 8)
                            .background(accent, in: Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }

            if controller.state.isLoadingEpisodes {
                ProgressView("Loading episodes...")
                    .tint(accent)
                    .foregroundStyle(.white.opacity(0.7))
            } else if controller.state.seasonEpisodes.isEmpty {
                Text("No episode list available for this season.")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.65))
            } else {
                ForEach(controller.state.seasonEpisodes, id: \.episodeNumber) { ep in
                    let isCurrent = ep.episodeNumber == controller.state.playingEpisode
                    Button {
                        controller.playEpisode(ep)
                    } label: {
                        PlayerPanelRow(
                            title: "E\(ep.episodeNumber) · \(ep.name)",
                            subtitle: (ep.overview?.isEmpty == false) ? ep.overview : nil,
                            isSelected: isCurrent,
                            accent: accent
                        )
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}
