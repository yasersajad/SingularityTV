import SwiftUI

enum PlayerIcon {
    static let play = "play.fill"
    static let pause = "pause.fill"
    static let back = "chevron.backward"
    static let rewind10 = "gobackward.10"
    static let forward10 = "goforward.10"
    static let rewindContinuous = "backward.fill"
    static let forwardContinuous = "forward.fill"
    static let subtitles = "captions.bubble"
    static let subtitlesActive = "captions.bubble.fill"
    static let audio = "speaker.wave.2.fill"
    static let audioMuted = "speaker.slash.fill"
    static let settings = "gearshape.fill"
    static let playbackSources = "rectangle.stack"
    static let episodes = "list.bullet"
    static let speed = "speedometer"
    static let brightness = "sun.max.fill"
    static let nextEpisode = "forward.end.fill"
    static let skipIntro = "forward.end.alt.fill"
    static let lock = "lock.fill"
    static let unlock = "lock.open.fill"
    static let error = "exclamationmark.triangle.fill"
    static let selected = "checkmark.circle.fill"
    static let unselected = "circle"
    static let fillScreen = "arrow.up.left.and.arrow.down.right"
    static let refresh = "arrow.clockwise"
}

enum PlayerIconMetrics {
    static let topBarButtonSize: CGFloat = 38
    static let centerSideButtonSize: CGFloat = 58
    static let centerPlayButtonSize: CGFloat = 76
    static let topBarIconFont: Font = .system(size: 15, weight: .semibold)
    static let centerSideIconFont: Font = .system(size: 26, weight: .semibold)
    static let centerPlayIconFont: Font = .system(size: 34, weight: .bold)
}
