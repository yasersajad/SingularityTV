import SwiftUI

struct PlayerProgressBar: View {
    let currentTime: Double
    let duration: Double
    let progressFraction: Double
    let accent: Color
    let onSeekDragChanged: () -> Void
    let onSeekEnded: (Double) -> Void

    @State private var isDragging = false
    @State private var dragFraction: Double = 0

    var body: some View {
        let displayFraction = isDragging ? dragFraction : progressFraction
        let previewTime = dragFraction * duration

        GeometryReader { geo in
            let width = max(1, geo.size.width)
            let thumbX = max(0, min(width - 14, width * CGFloat(displayFraction) - 7))

            ZStack(alignment: .leading) {
                if isDragging && duration > 0 {
                    Text(PlayerStateManager.formatTime(previewTime))
                        .font(.caption2.weight(.bold).monospacedDigit())
                        .foregroundStyle(.white)
                        .padding(.horizontal, 8)
                        .padding(.vertical, 4)
                        .background(Color.black.opacity(0.85), in: Capsule())
                        .overlay {
                            Capsule().stroke(Color.white.opacity(0.2), lineWidth: 1)
                        }
                        .offset(x: max(0, min(width - 52, thumbX - 18)), y: -28)
                }

                Capsule()
                    .fill(Color.white.opacity(0.24))
                    .frame(height: isDragging ? 6 : 4)

                Capsule()
                    .fill(accent)
                    .frame(width: width * CGFloat(displayFraction), height: isDragging ? 6 : 4)

                Circle()
                    .fill(.white)
                    .frame(width: isDragging ? 16 : 12, height: isDragging ? 16 : 12)
                    .shadow(color: .black.opacity(0.5), radius: 3)
                    .offset(x: thumbX)
            }
            .frame(height: 24)
            .contentShape(Rectangle())
            .gesture(
                DragGesture(minimumDistance: 0)
                    .onChanged { value in
                        isDragging = true
                        dragFraction = min(max(Double(value.location.x / width), 0), 1)
                        onSeekDragChanged()
                    }
                    .onEnded { value in
                        let finalFraction = min(max(Double(value.location.x / width), 0), 1)
                        isDragging = false
                        onSeekEnded(finalFraction)
                    }
            )
        }
        .frame(height: 24)
    }
}
