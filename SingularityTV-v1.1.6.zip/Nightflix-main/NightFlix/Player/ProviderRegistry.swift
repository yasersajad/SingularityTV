import Foundation

enum ProviderFeatureStatus: String, Equatable, Sendable {
    case available = "Available"
    case limited = "Limited"
    case notDetected = "Not Detected"
    case unsupported = "Unsupported"
    case temporarilyUnavailable = "Temporarily Unavailable"
    case failed = "Failed"
}

struct ProviderCapabilityProfile: Equatable, Sendable {
    let providerID: String
    let host: String
    let displayName: String
    var internalServers: ProviderFeatureStatus
    var audioTracks: ProviderFeatureStatus
    var subtitleTracks: ProviderFeatureStatus
    var hlsSupport: Bool
    var html5Support: Bool
    var skipIntro: ProviderFeatureStatus
    var autoNext: ProviderFeatureStatus
    var technicalNotes: String
}

struct ProviderAdapterConfig: Sendable {
    let providerID: String
    let host: String
    let displayName: String
    let serverSelectors: [String]
    let supportsPostMessageProgress: Bool
    let defaultCapabilities: ProviderCapabilityProfile
}

@MainActor
final class ProviderRegistry {
    static let shared = ProviderRegistry()

    private(set) var adapters: [String: ProviderAdapterConfig] = [:]

    private init() {
        let configs: [ProviderAdapterConfig] = [
            ProviderAdapterConfig(
                providerID: "vidyst",
                host: "vidy.st",
                displayName: "Vidy.st (Recommended)",
                serverSelectors: ["[class*='server' i]", "[data-server]", "[class*='mirror' i]"],
                supportsPostMessageProgress: true,
                defaultCapabilities: ProviderCapabilityProfile(
                    providerID: "vidyst",
                    host: "vidy.st",
                    displayName: "Vidy.st (Recommended)",
                    internalServers: .notDetected,
                    audioTracks: .notDetected,
                    subtitleTracks: .available,
                    hlsSupport: true,
                    html5Support: true,
                    skipIntro: .notDetected,
                    autoNext: .available,
                    technicalNotes: "Uses Vidstack/HLS; subtitle files & cues are discoverable; internal servers depend on frame origin."
                )
            ),
            ProviderAdapterConfig(
                providerID: "vidfast",
                host: "vidfast.vc",
                displayName: "VidFast",
                serverSelectors: ["[class*='server' i]", "[data-server]", "[class*='source' i]"],
                supportsPostMessageProgress: true,
                defaultCapabilities: ProviderCapabilityProfile(
                    providerID: "vidfast",
                    host: "vidfast.vc",
                    displayName: "VidFast",
                    internalServers: .notDetected,
                    audioTracks: .notDetected,
                    subtitleTracks: .available,
                    hlsSupport: true,
                    html5Support: true,
                    skipIntro: .notDetected,
                    autoNext: .available,
                    technicalNotes: "Posts PLAYER_EVENT progress envelopes; server tabs may be inside cross-origin frames."
                )
            ),
            ProviderAdapterConfig(
                providerID: "vidlink",
                host: "vidlink.pro",
                displayName: "VidLink Pro",
                serverSelectors: ["[class*='server' i]", "[data-server]", "[aria-label*='server' i]"],
                supportsPostMessageProgress: true,
                defaultCapabilities: ProviderCapabilityProfile(
                    providerID: "vidlink",
                    host: "vidlink.pro",
                    displayName: "VidLink Pro",
                    internalServers: .notDetected,
                    audioTracks: .notDetected,
                    subtitleTracks: .available,
                    hlsSupport: true,
                    html5Support: true,
                    skipIntro: .notDetected,
                    autoNext: .available,
                    technicalNotes: "Dynamic React embed; some streams may return WebKit decode errors on unsupported codecs."
                )
            ),
            ProviderAdapterConfig(
                providerID: "vidsrc",
                host: "vidsrc.xyz",
                displayName: "VidSrc",
                serverSelectors: ["[class*='server' i]", "#servers button", ".serversList div"],
                supportsPostMessageProgress: false,
                defaultCapabilities: ProviderCapabilityProfile(
                    providerID: "vidsrc",
                    host: "vidsrc.xyz",
                    displayName: "VidSrc",
                    internalServers: .notDetected,
                    audioTracks: .notDetected,
                    subtitleTracks: .available,
                    hlsSupport: true,
                    html5Support: true,
                    skipIntro: .notDetected,
                    autoNext: .notDetected,
                    technicalNotes: "Embeds nested cross-origin player frames; audio/server controls may be isolated by Same-Origin Policy."
                )
            ),
            ProviderAdapterConfig(
                providerID: "vidly",
                host: "vidly.pro",
                displayName: "Vidly.pro (Mirror)",
                serverSelectors: ["[class*='server' i]", "[data-server]", "[class*='mirror' i]"],
                supportsPostMessageProgress: true,
                defaultCapabilities: ProviderCapabilityProfile(
                    providerID: "vidly",
                    host: "vidly.pro",
                    displayName: "Vidly.pro (Mirror)",
                    internalServers: .notDetected,
                    audioTracks: .notDetected,
                    subtitleTracks: .available,
                    hlsSupport: true,
                    html5Support: true,
                    skipIntro: .notDetected,
                    autoNext: .notDetected,
                    technicalNotes: "DNS/CDN availability varies by region; some streams require H.264/AAC compatibility."
                )
            )
        ]

        for cfg in configs {
            adapters[cfg.host.lowercased()] = cfg
        }
    }

    func adapter(for host: String?) -> ProviderAdapterConfig? {
        guard let host = host?.lowercased(), !host.isEmpty else { return nil }
        if let exact = adapters[host] { return exact }
        return adapters.values.first { host.contains($0.host) }
    }
}
