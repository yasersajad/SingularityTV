import Foundation
import NaturalLanguage

struct ResolvedLanguageResult: Equatable, Sendable {
    let code: String
    let name: String
    let isKnown: Bool
}

enum SubtitleLanguageResolver {
    private static let codeToName: [String: String] = [
        "ar": "Arabic", "ara": "Arabic", "arb": "Arabic",
        "en": "English", "eng": "English",
        "ja": "Japanese", "jpn": "Japanese", "jp": "Japanese",
        "fr": "French", "fre": "French", "fra": "French",
        "de": "German", "ger": "German", "deu": "German",
        "es": "Spanish", "spa": "Spanish",
        "tr": "Turkish", "tur": "Turkish",
        "ko": "Korean", "kor": "Korean",
        "it": "Italian", "ita": "Italian",
        "pt": "Portuguese", "por": "Portuguese",
        "ru": "Russian", "rus": "Russian",
        "zh": "Chinese", "chi": "Chinese", "zho": "Chinese", "cmn": "Chinese",
        "hi": "Hindi", "hin": "Hindi",
        "nl": "Dutch", "dut": "Dutch", "nld": "Dutch",
        "pl": "Polish", "pol": "Polish",
        "sv": "Swedish", "swe": "Swedish",
        "no": "Norwegian", "nor": "Norwegian",
        "da": "Danish", "dan": "Danish",
        "fi": "Finnish", "fin": "Finnish",
        "el": "Greek", "gre": "Greek", "ell": "Greek",
        "he": "Hebrew", "heb": "Hebrew",
        "id": "Indonesian", "ind": "Indonesian",
        "ms": "Malay", "msa": "Malay", "may": "Malay",
        "th": "Thai", "tha": "Thai",
        "vi": "Vietnamese", "vie": "Vietnamese",
        "fa": "Persian", "per": "Persian", "fas": "Persian",
        "ur": "Urdu", "urd": "Urdu",
        "uk": "Ukrainian", "ukr": "Ukrainian",
        "ro": "Romanian", "ron": "Romanian", "rum": "Romanian",
        "cs": "Czech", "ces": "Czech", "cze": "Czech",
        "hu": "Hungarian", "hun": "Hungarian",
        "orig": "Original Audio", "original": "Original Audio"
    ]

    private static let nameKeywords: [(token: String, code: String, name: String)] = [
        ("arabic", "ar", "Arabic"), ("العربية", "ar", "Arabic"), ("عربي", "ar", "Arabic"),
        ("english", "en", "English"),
        ("japanese", "ja", "Japanese"), ("nihongo", "ja", "Japanese"),
        ("french", "fr", "French"), ("français", "fr", "French"), ("francais", "fr", "French"),
        ("german", "de", "German"), ("deutsch", "de", "German"),
        ("spanish", "es", "Spanish"), ("español", "es", "Spanish"), ("espanol", "es", "Spanish"), ("latino", "es", "Spanish"),
        ("turkish", "tr", "Turkish"), ("türkçe", "tr", "Turkish"), ("turkce", "tr", "Turkish"),
        ("korean", "ko", "Korean"),
        ("italian", "it", "Italian"), ("italiano", "it", "Italian"),
        ("portuguese", "pt", "Portuguese"), ("português", "pt", "Portuguese"), ("brazilian", "pt", "Portuguese"),
        ("russian", "ru", "Russian"),
        ("chinese", "zh", "Chinese"), ("mandarin", "zh", "Chinese"), ("cantonese", "zh", "Chinese"),
        ("hindi", "hi", "Hindi"),
        ("persian", "fa", "Persian"), ("farsi", "fa", "Persian"),
        ("indonesian", "id", "Indonesian"),
        ("dutch", "nl", "Dutch"), ("nederlands", "nl", "Dutch"),
        ("polish", "pl", "Polish"), ("polski", "pl", "Polish"),
        ("thai", "th", "Thai"),
        ("vietnamese", "vi", "Vietnamese"),
        ("original", "orig", "Original Audio")
    ]

    static func resolveFromMetadata(
        serverCode: String? = nil,
        providerLang: String? = nil,
        htmlLang: String? = nil,
        manifestLang: String? = nil,
        sourceLabel: String? = nil,
        filename: String? = nil
    ) -> ResolvedLanguageResult {
        for candidate in [serverCode, providerLang, htmlLang, manifestLang] {
            if let res = matchCodeOrName(candidate) {
                return res
            }
        }
        if let res = matchCodeOrName(sourceLabel) {
            return res
        }
        if let filename, let res = matchFilenameToken(filename) {
            return res
        }
        return ResolvedLanguageResult(code: "und", name: "Unknown Language", isKnown: false)
    }

    static func resolveFromContent(_ rawText: String) -> ResolvedLanguageResult {
        let sample = extractDialogueSample(from: rawText)
        guard sample.count >= 24 else {
            return ResolvedLanguageResult(code: "und", name: "Unknown Language", isKnown: false)
        }

        if let scriptResult = detectNonLatinScript(in: sample) {
            return scriptResult
        }

        let recognizer = NLLanguageRecognizer()
        recognizer.processString(sample)
        let hypotheses = recognizer.languageHypotheses(withMaximum: 2)
        if let best = hypotheses.max(by: { $0.value < $1.value }),
           best.value >= 0.55,
           best.key != .undetermined {
            let code = best.key.rawValue.lowercased()
            let base = String(code.split(separator: "-").first ?? Substring(code))
            if let name = codeToName[base] ?? Locale(identifier: "en").localizedString(forLanguageCode: base) {
                return ResolvedLanguageResult(code: base, name: name.capitalized, isKnown: true)
            }
        }

        return ResolvedLanguageResult(code: "und", name: "Unknown Language", isKnown: false)
    }

    static func languageName(for raw: String?) -> ResolvedLanguageResult {
        matchCodeOrName(raw) ?? ResolvedLanguageResult(code: "und", name: "Unknown Language", isKnown: false)
    }

    static func isRandomHashFilename(_ filename: String) -> Bool {
        let base = filename
            .replacingOccurrences(of: ".srt", with: "", options: .caseInsensitive)
            .replacingOccurrences(of: ".vtt", with: "", options: .caseInsensitive)
            .replacingOccurrences(of: ".ass", with: "", options: .caseInsensitive)
            .trimmingCharacters(in: .whitespacesAndNewlines)
        if base.count >= 16 && base.range(of: "^[A-Za-z0-9_-]+$", options: .regularExpression) != nil {
            let digits = base.filter(\.isNumber).count
            if digits >= 4 || base.count >= 24 {
                return true
            }
        }
        return false
    }

    private static func matchCodeOrName(_ raw: String?) -> ResolvedLanguageResult? {
        guard let raw else { return nil }
        let cleaned = raw.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        guard !cleaned.isEmpty,
              cleaned != "und",
              cleaned != "unknown",
              cleaned != "off",
              cleaned != "none",
              cleaned != "subtitle",
              cleaned != "source subtitle" else {
            return nil
        }

        if let mapped = codeToName[cleaned] {
            let iso = canonicalCode(for: mapped, fallback: cleaned)
            return ResolvedLanguageResult(code: iso, name: mapped, isKnown: true)
        }

        let primary = String(cleaned.split(whereSeparator: { $0 == "-" || $0 == "_" }).first ?? "")
        if let mapped = codeToName[primary] {
            let iso = canonicalCode(for: mapped, fallback: primary)
            return ResolvedLanguageResult(code: iso, name: mapped, isKnown: true)
        }

        for entry in nameKeywords where cleaned.contains(entry.token) {
            return ResolvedLanguageResult(code: entry.code, name: entry.name, isKnown: true)
        }

        return nil
    }

    private static func matchFilenameToken(_ filename: String) -> ResolvedLanguageResult? {
        let lower = filename.lowercased()
        for entry in nameKeywords where lower.contains(entry.token) {
            return ResolvedLanguageResult(code: entry.code, name: entry.name, isKnown: true)
        }
        let tokens = lower
            .replacingOccurrences(of: ".srt", with: "")
            .replacingOccurrences(of: ".vtt", with: "")
            .replacingOccurrences(of: ".ass", with: "")
            .split(whereSeparator: { !$0.isLetter })
            .map(String.init)
        for token in tokens {
            if let mapped = codeToName[token] {
                return ResolvedLanguageResult(code: canonicalCode(for: mapped, fallback: token), name: mapped, isKnown: true)
            }
        }
        return nil
    }

    private static func canonicalCode(for name: String, fallback: String) -> String {
        switch name {
        case "Arabic": return "ar"
        case "English": return "en"
        case "Japanese": return "ja"
        case "French": return "fr"
        case "German": return "de"
        case "Spanish": return "es"
        case "Turkish": return "tr"
        case "Korean": return "ko"
        case "Italian": return "it"
        case "Portuguese": return "pt"
        case "Russian": return "ru"
        case "Chinese": return "zh"
        case "Hindi": return "hi"
        case "Original Audio": return "orig"
        default: return fallback
        }
    }

    private static func extractDialogueSample(from raw: String) -> String {
        let lines = raw.components(separatedBy: .newlines)
        var collected: [String] = []
        var totalChars = 0

        for line in lines {
            var s = line.trimmingCharacters(in: .whitespacesAndNewlines)
            if s.isEmpty { continue }
            if s == "WEBVTT" || s.hasPrefix("NOTE") || s.hasPrefix("STYLE") { continue }
            if s.contains("-->") { continue }
            if s.allSatisfy(\.isNumber) { continue }
            if s.hasPrefix("[") || s.hasPrefix("Dialogue:") {
                if let commaRange = s.range(of: ",,") {
                    s = String(s[commaRange.upperBound...])
                } else if s.hasPrefix("[") {
                    continue
                }
            }
            s = s.replacingOccurrences(of: "<[^>]+>", with: " ", options: .regularExpression)
            s = s.replacingOccurrences(of: "\\{\\\\[^}]+\\}", with: " ", options: .regularExpression)
            s = s.replacingOccurrences(of: "\\s+", with: " ", options: .regularExpression)
                .trimmingCharacters(in: .whitespacesAndNewlines)
            if s.count < 2 { continue }
            collected.append(s)
            totalChars += s.count
            if collected.count >= 60 || totalChars >= 2000 { break }
        }
        return collected.joined(separator: " ")
    }

    private static func detectNonLatinScript(in text: String) -> ResolvedLanguageResult? {
        var arabic = 0
        var kana = 0
        var hangul = 0
        var cjk = 0
        var cyrillic = 0
        var thai = 0
        var hebrew = 0
        var greek = 0
        var totalLetters = 0

        for scalar in text.unicodeScalars {
            guard CharacterSet.letters.contains(scalar) else { continue }
            totalLetters += 1
            let v = scalar.value
            if (0x0600...0x06FF).contains(v) || (0x0750...0x077F).contains(v) || (0xFB50...0xFDFF).contains(v) || (0xFE70...0xFEFF).contains(v) {
                arabic += 1
            } else if (0x3040...0x309F).contains(v) || (0x30A0...0x30FF).contains(v) {
                kana += 1
            } else if (0xAC00...0xD7AF).contains(v) || (0x1100...0x11FF).contains(v) {
                hangul += 1
            } else if (0x4E00...0x9FFF).contains(v) {
                cjk += 1
            } else if (0x0400...0x04FF).contains(v) {
                cyrillic += 1
            } else if (0x0E00...0x0E7F).contains(v) {
                thai += 1
            } else if (0x0590...0x05FF).contains(v) {
                hebrew += 1
            } else if (0x0370...0x03FF).contains(v) {
                greek += 1
            }
        }

        guard totalLetters >= 12 else { return nil }
        if Double(arabic) / Double(totalLetters) >= 0.4 {
            return ResolvedLanguageResult(code: "ar", name: "Arabic", isKnown: true)
        }
        if kana >= 4 && Double(kana + cjk) / Double(totalLetters) >= 0.35 {
            return ResolvedLanguageResult(code: "ja", name: "Japanese", isKnown: true)
        }
        if Double(hangul) / Double(totalLetters) >= 0.4 {
            return ResolvedLanguageResult(code: "ko", name: "Korean", isKnown: true)
        }
        if Double(cjk) / Double(totalLetters) >= 0.4 {
            return ResolvedLanguageResult(code: "zh", name: "Chinese", isKnown: true)
        }
        if Double(cyrillic) / Double(totalLetters) >= 0.4 {
            return ResolvedLanguageResult(code: "ru", name: "Russian", isKnown: true)
        }
        if Double(thai) / Double(totalLetters) >= 0.4 {
            return ResolvedLanguageResult(code: "th", name: "Thai", isKnown: true)
        }
        if Double(hebrew) / Double(totalLetters) >= 0.4 {
            return ResolvedLanguageResult(code: "he", name: "Hebrew", isKnown: true)
        }
        if Double(greek) / Double(totalLetters) >= 0.4 {
            return ResolvedLanguageResult(code: "el", name: "Greek", isKnown: true)
        }
        return nil
    }
}
