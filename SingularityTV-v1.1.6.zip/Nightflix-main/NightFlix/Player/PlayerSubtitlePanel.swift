import SwiftUI

struct PlayerSubtitlePanel: View {
    let controller: CustomPlayerController
    let accent: Color
    let onOpenExternalSearch: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            statusBanner

            Button {
                controller.subtitles.disableAll(bridge: controller.bridge)
                controller.state.activePanel = .none
            } label: {
                PlayerPanelRow(title: "Off", subtitle: "Disable subtitles", isSelected: controller.subtitles.isAllOff, accent: accent)
            }
            .buttonStyle(.plain)

            if !controller.subtitles.discoveredSiteSubtitles.isEmpty {
                Text("Site Subtitle Files")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.white.opacity(0.6))

                ForEach(controller.subtitles.discoveredSiteSubtitles) { item in
                    let isSelected = controller.subtitles.activeTrackId == item.url
                    Button {
                        Task {
                            let ok = await controller.subtitles.activateSubtitleFromURL(
                                id: item.url,
                                url: item.url,
                                name: item.label,
                                language: item.language,
                                source: .siteFile,
                                referer: controller.activeURL.absoluteString,
                                bridge: controller.bridge
                            )
                            if ok {
                                controller.state.activePanel = .none
                            }
                        }
                    } label: {
                        PlayerPanelRow(
                            title: item.label,
                            subtitle: item.language.isEmpty ? "From watching site" : item.language.uppercased(),
                            isSelected: isSelected,
                            accent: accent
                        )
                    }
                    .buttonStyle(.plain)
                }
            }

            if !controller.subtitles.inPlayerTracks.isEmpty {
                Text("Source Subtitles")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.white.opacity(0.6))

                ForEach(controller.subtitles.inPlayerTracks) { track in
                    Button {
                        controller.subtitles.activateInStreamTrack(id: track.id, name: track.label, bridge: controller.bridge)
                        controller.state.activePanel = .none
                    } label: {
                        PlayerPanelRow(
                            title: track.label,
                            subtitle: track.language.isEmpty ? nil : track.language.uppercased(),
                            isSelected: track.isActive && !controller.subtitles.hasActiveExternalSubtitles,
                            accent: accent
                        )
                    }
                    .buttonStyle(.plain)
                }
            } else if controller.subtitles.discoveredSiteSubtitles.isEmpty {
                Text("No exposed in-stream subtitle tracks were detected for this source.")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.65))
                    .padding(10)
                    .background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 10))
            }

            if controller.subtitles.activeSource == .external, let extName = controller.subtitles.externalTrackName {
                PlayerPanelRow(title: extName, subtitle: "Active external subtitle", isSelected: true, accent: accent)
            }

            Button {
                controller.state.activePanel = .none
                onOpenExternalSearch()
            } label: {
                Label("Search External Subtitles", systemImage: "magnifyingglass")
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(accent, in: RoundedRectangle(cornerRadius: 12))
            }
            .buttonStyle(NFScaleButtonStyle())

            Divider().background(Color.white.opacity(0.1))

            Text("Subtitle Appearance")
                .font(.caption.weight(.bold))
                .foregroundStyle(.white.opacity(0.6))

            HStack {
                Text("Size: \(Int(controller.subtitles.stylePrefs.fontSize))pt")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white)
                Slider(
                    value: Binding(
                        get: { controller.subtitles.stylePrefs.fontSize },
                        set: {
                            controller.subtitles.stylePrefs.fontSize = $0
                            controller.saveSubtitleStyle()
                        }
                    ),
                    in: 14...28,
                    step: 1
                )
                .tint(accent)
            }

            HStack(spacing: 10) {
                ForEach(SubtitleStylePrefs.colorPresets, id: \.hex) { preset in
                    let selected = controller.subtitles.stylePrefs.textColorHex == preset.hex
                    Button {
                        controller.subtitles.stylePrefs.textColorHex = preset.hex
                        controller.saveSubtitleStyle()
                    } label: {
                        Text(preset.name)
                            .font(.caption.weight(.bold))
                            .foregroundStyle(Color(hex: preset.hex))
                            .padding(.horizontal, 12)
                            .padding(.vertical, 6)
                            .background(selected ? Color.white.opacity(0.18) : Color.white.opacity(0.06), in: Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }

            HStack(spacing: 8) {
                ForEach(SubtitleBgStyle.allCases) { bg in
                    let selected = controller.subtitles.stylePrefs.bgStyle == bg
                    Button {
                        controller.subtitles.stylePrefs.bgStyle = bg
                        controller.saveSubtitleStyle()
                    } label: {
                        Text(bg.rawValue)
                            .font(.caption2.weight(.bold))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 6)
                            .background(selected ? accent.opacity(0.35) : Color.white.opacity(0.06), in: Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }

    @ViewBuilder
    private var statusBanner: some View {
        switch controller.subtitles.activationState {
        case .loading(let name):
            HStack(spacing: 10) {
                ProgressView().tint(accent)
                Text("Loading \(name)...")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.85))
            }
            .padding(10)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 10))

        case .failed(let message):
            Text(message)
                .font(.caption)
                .foregroundStyle(Color(hex: "FF8C92"))
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(accent.opacity(0.16), in: RoundedRectangle(cornerRadius: 10))

        case .active(_, let name, _):
            Text("Active: \(name)")
                .font(.caption.weight(.semibold))
                .foregroundStyle(Color(hex: "7BE3A2"))
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.green.opacity(0.14), in: RoundedRectangle(cornerRadius: 10))

        case .off:
            EmptyView()
        }
    }
}
