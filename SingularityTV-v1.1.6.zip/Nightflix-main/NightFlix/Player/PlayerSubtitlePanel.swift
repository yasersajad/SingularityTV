import SwiftUI

struct PlayerSubtitlePanel: View {
    let controller: CustomPlayerController
    let accent: Color
    let onOpenExternalSearch: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            statusBanner

            Button {
                controller.subtitles.disableAll(bridge: controller.bridge)
                controller.state.activePanel = .none
            } label: {
                PlayerPanelRow(title: "Off", subtitle: "Disable subtitles", isSelected: controller.subtitles.isAllOff, accent: accent)
            }
            .buttonStyle(.plain)

            if !controller.subtitles.discoveredSiteSubtitles.isEmpty {
                Label("Site Subtitle Files", systemImage: "doc.text.magnifyingglass")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.white.opacity(0.65))

                ForEach(controller.subtitles.discoveredSiteSubtitles) { item in
                    let isSelected = controller.subtitles.activeTrackId == item.url
                    let detail = item.originalFilename.isEmpty
                        ? "From watching site"
                        : "\(item.language.isEmpty ? "Source" : item.language.uppercased()) · \(item.originalFilename)"
                    Button {
                        Task {
                            let ok = await controller.subtitles.activateSubtitleFromURL(
                                id: item.url,
                                url: item.url,
                                name: item.displayTitle,
                                language: item.language,
                                source: .siteFile,
                                referer: controller.activeURL.absoluteString,
                                bridge: controller.bridge
                            )
                            if ok {
                                controller.savePlayerPreferences()
                                controller.state.activePanel = .none
                            }
                        }
                    } label: {
                        PlayerPanelRow(
                            title: item.displayTitle,
                            subtitle: detail,
                            isSelected: isSelected,
                            accent: accent
                        )
                    }
                    .buttonStyle(.plain)
                }
            }

            if !controller.subtitles.inPlayerTracks.isEmpty {
                Label("Source Subtitles", systemImage: "captions.bubble")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.white.opacity(0.65))

                ForEach(controller.subtitles.inPlayerTracks) { track in
                    let isSelected = (controller.subtitles.activeTrackId == track.trackId || track.isActive) && !controller.subtitles.hasActiveExternalSubtitles
                    Button {
                        Task {
                            let ok = await controller.subtitles.activateInStreamTrack(track: track, bridge: controller.bridge)
                            if ok {
                                controller.savePlayerPreferences()
                                controller.state.activePanel = .none
                            }
                        }
                    } label: {
                        PlayerPanelRow(
                            title: track.label,
                            subtitle: track.language.isEmpty ? "In-Stream" : track.language.uppercased(),
                            isSelected: isSelected,
                            accent: accent
                        )
                    }
                    .buttonStyle(.plain)
                }
            } else if controller.subtitles.discoveredSiteSubtitles.isEmpty {
                Text("No exposed in-stream subtitle tracks were detected for this source.")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.65))
                    .padding(10)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 10))
            }

            if controller.subtitles.activeSource == .external, let extName = controller.subtitles.externalTrackName {
                PlayerPanelRow(title: extName, subtitle: "Active external subtitle", isSelected: true, accent: accent)
            }

            Button {
                controller.state.activePanel = .none
                onOpenExternalSearch()
            } label: {
                Label("Search External Subtitles", systemImage: "magnifyingglass")
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(accent, in: RoundedRectangle(cornerRadius: 12))
            }
            .buttonStyle(NFScaleButtonStyle())

            Divider().background(Color.white.opacity(0.1))

            Label("Subtitle Position & Styling", systemImage: "textformat.size")
                .font(.caption.weight(.bold))
                .foregroundStyle(.white.opacity(0.65))

            VStack(alignment: .leading, spacing: 8) {
                HStack {
                    Label("Subtitle Position", systemImage: "arrow.up.and.down")
                        .font(.caption.weight(.semibold))
                        .foregroundStyle(.white)
                    Spacer()
                    Text(positionDescription(controller.subtitles.stylePrefs.positionPercent))
                        .font(.caption2.weight(.bold).monospacedDigit())
                        .foregroundStyle(.white.opacity(0.75))
                    Button {
                        controller.subtitles.stylePrefs.positionPercent = SubtitleStylePrefs.defaultPositionPercent
                        controller.saveSubtitleStyle()
                    } label: {
                        Image(systemName: "arrow.counterclockwise")
                            .font(.caption2.weight(.bold))
                            .foregroundStyle(accent)
                            .padding(.horizontal, 8)
                            .padding(.vertical, 4)
                            .background(Color.white.opacity(0.08), in: Capsule())
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Reset Subtitle Position")
                }

                Slider(
                    value: Binding(
                        get: { controller.subtitles.stylePrefs.positionPercent },
                        set: {
                            controller.subtitles.stylePrefs.positionPercent = $0
                            controller.saveSubtitleStyle()
                        }
                    ),
                    in: 0...100,
                    step: 1
                )
                .tint(accent)

                HStack(spacing: 8) {
                    positionPresetButton(title: "Top", value: 10)
                    positionPresetButton(title: "Center", value: 50)
                    positionPresetButton(title: "Bottom", value: SubtitleStylePrefs.defaultPositionPercent)
                }
            }

            HStack {
                Label("Size: \(Int(controller.subtitles.stylePrefs.fontSize))pt", systemImage: "textformat")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white)
                Slider(
                    value: Binding(
                        get: { controller.subtitles.stylePrefs.fontSize },
                        set: {
                            controller.subtitles.stylePrefs.fontSize = $0
                            controller.saveSubtitleStyle()
                        }
                    ),
                    in: 14...28,
                    step: 1
                )
                .tint(accent)
            }

            HStack {
                Label("Opacity: \(Int(controller.subtitles.stylePrefs.bgOpacity * 100))%", systemImage: "circle.lefthalf.filled")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white)
                Slider(
                    value: Binding(
                        get: { controller.subtitles.stylePrefs.bgOpacity },
                        set: {
                            controller.subtitles.stylePrefs.bgOpacity = $0
                            controller.saveSubtitleStyle()
                        }
                    ),
                    in: 0.0...1.0,
                    step: 0.05
                )
                .tint(accent)
            }

            if controller.subtitles.hasActiveExternalSubtitles {
                HStack {
                    Label(String(format: "Sync: %+.1fs", controller.subtitles.offsetSeconds), systemImage: "timer")
                        .font(.caption.weight(.semibold).monospacedDigit())
                        .foregroundStyle(.white)
                    Spacer()
                    Button("-0.5s") { controller.subtitles.offsetSeconds -= 0.5 }
                        .font(.caption2.weight(.bold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 5)
                        .background(Color.white.opacity(0.1), in: Capsule())
                        .buttonStyle(.plain)
                    Button("0s") { controller.subtitles.offsetSeconds = 0 }
                        .font(.caption2.weight(.bold))
                        .foregroundStyle(.white.opacity(0.75))
                        .padding(.horizontal, 8)
                        .padding(.vertical, 5)
                        .background(Color.white.opacity(0.08), in: Capsule())
                        .buttonStyle(.plain)
                    Button("+0.5s") { controller.subtitles.offsetSeconds += 0.5 }
                        .font(.caption2.weight(.bold))
                        .foregroundStyle(.white)
                        .padding(.horizontal, 10)
                        .padding(.vertical, 5)
                        .background(Color.white.opacity(0.1), in: Capsule())
                        .buttonStyle(.plain)
                }
            }

            HStack(spacing: 10) {
                ForEach(SubtitleStylePrefs.colorPresets, id: \.hex) { preset in
                    let selected = controller.subtitles.stylePrefs.textColorHex == preset.hex
                    Button {
                        controller.subtitles.stylePrefs.textColorHex = preset.hex
                        controller.saveSubtitleStyle()
                    } label: {
                        Text(preset.name)
                            .font(.caption.weight(.bold))
                            .foregroundStyle(Color(hex: preset.hex))
                            .padding(.horizontal, 12)
                            .padding(.vertical, 6)
                            .background(selected ? Color.white.opacity(0.18) : Color.white.opacity(0.06), in: Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }

            HStack(spacing: 8) {
                ForEach(SubtitleBgStyle.allCases) { bg in
                    let selected = controller.subtitles.stylePrefs.bgStyle == bg
                    Button {
                        controller.subtitles.stylePrefs.bgStyle = bg
                        controller.saveSubtitleStyle()
                    } label: {
                        Text(bg.rawValue)
                            .font(.caption2.weight(.bold))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 6)
                            .background(selected ? accent.opacity(0.35) : Color.white.opacity(0.06), in: Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }

            HStack(spacing: 8) {
                ForEach(SubtitleTextAlignment.allCases) { align in
                    let selected = controller.subtitles.stylePrefs.textAlignment == align
                    Button {
                        controller.subtitles.stylePrefs.textAlignment = align
                        controller.saveSubtitleStyle()
                    } label: {
                        Text(align.rawValue)
                            .font(.caption2.weight(.bold))
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 6)
                            .background(selected ? accent.opacity(0.35) : Color.white.opacity(0.06), in: Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }

            HStack(spacing: 12) {
                Toggle("Outline", isOn: Binding(
                    get: { controller.subtitles.stylePrefs.hasOutline },
                    set: {
                        controller.subtitles.stylePrefs.hasOutline = $0
                        controller.saveSubtitleStyle()
                    }
                ))
                .font(.caption.weight(.semibold))
                .foregroundStyle(.white)
                .tint(accent)

                Toggle("Shadow", isOn: Binding(
                    get: { controller.subtitles.stylePrefs.shadowEnabled },
                    set: {
                        controller.subtitles.stylePrefs.shadowEnabled = $0
                        controller.saveSubtitleStyle()
                    }
                ))
                .font(.caption.weight(.semibold))
                .foregroundStyle(.white)
                .tint(accent)
            }
        }
    }

    private func positionPresetButton(title: String, value: Double) -> some View {
        let isNear = abs(controller.subtitles.stylePrefs.positionPercent - value) <= 3
        return Button {
            controller.subtitles.stylePrefs.positionPercent = value
            controller.saveSubtitleStyle()
        } label: {
            Text(title)
                .font(.caption2.weight(.bold))
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 6)
                .background(isNear ? accent.opacity(0.35) : Color.white.opacity(0.06), in: Capsule())
        }
        .buttonStyle(.plain)
    }

    private func positionDescription(_ percent: Double) -> String {
        let p = Int(percent.rounded())
        if p <= 20 { return "Top (\(p)%)" }
        if p <= 65 { return "Middle (\(p)%)" }
        return "Bottom (\(p)%)"
    }

    @ViewBuilder
    private var statusBanner: some View {
        switch controller.subtitles.activationState {
        case .loading(let name):
            HStack(spacing: 10) {
                ProgressView().tint(accent)
                Text("Loading \(name)...")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.85))
            }
            .padding(10)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 10))

        case .failed(let message):
            Text(message)
                .font(.caption)
                .foregroundStyle(Color(hex: "FF8C92"))
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(accent.opacity(0.16), in: RoundedRectangle(cornerRadius: 10))

        case .active(_, let name, _):
            Text("Active: \(name)")
                .font(.caption.weight(.semibold))
                .foregroundStyle(Color(hex: "7BE3A2"))
                .padding(10)
                .frame(maxWidth: .infinity, alignment: .leading)
                .background(Color.green.opacity(0.14), in: RoundedRectangle(cornerRadius: 10))

        case .off:
            EmptyView()
        }
    }
}
