import SwiftUI

struct PlayerSubtitlePanel: View {
    let controller: CustomPlayerController
    let accent: Color
    let onOpenExternalSearch: () -> Void

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Button {
                controller.subtitles.clearExternalSubtitles()
                controller.bridge.selectTextTrack(index: nil)
                controller.state.activePanel = .none
            } label: {
                PlayerPanelRow(title: "Off", subtitle: "Disable subtitles", isSelected: controller.subtitles.isAllOff, accent: accent)
            }
            .buttonStyle(.plain)

            if !controller.subtitles.discoveredSiteSubtitles.isEmpty {
                Text("Site Subtitle Files")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.white.opacity(0.6))

                ForEach(controller.subtitles.discoveredSiteSubtitles, id: \.url) { item in
                    Button {
                        Task {
                            if let cues = try? await ExternalSubtitleService.shared.fetchAndParseSubtitles(from: item.url) {
                                controller.subtitles.setExternalSubtitles(cues: cues, name: item.label)
                                controller.bridge.selectTextTrack(index: nil)
                                controller.state.activePanel = .none
                            }
                        }
                    } label: {
                        PlayerPanelRow(
                            title: item.label,
                            subtitle: "From watching site",
                            isSelected: controller.subtitles.externalTrackName == item.label,
                            accent: accent
                        )
                    }
                    .buttonStyle(.plain)
                }
            }

            if !controller.subtitles.inPlayerTracks.isEmpty {
                Text("Source Subtitles")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.white.opacity(0.6))

                ForEach(controller.subtitles.inPlayerTracks) { track in
                    Button {
                        controller.subtitles.clearExternalSubtitles()
                        controller.bridge.selectTextTrack(index: track.id)
                        controller.state.activePanel = .none
                    } label: {
                        PlayerPanelRow(
                            title: track.label,
                            subtitle: track.language.isEmpty ? nil : track.language.uppercased(),
                            isSelected: track.isActive && !controller.subtitles.hasActiveExternalSubtitles,
                            accent: accent
                        )
                    }
                    .buttonStyle(.plain)
                }
            } else {
                Text("No exposed in-stream subtitle tracks were detected for this source.")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.65))
                    .padding(10)
                    .background(Color.white.opacity(0.05), in: RoundedRectangle(cornerRadius: 10))
            }

            if let extName = controller.subtitles.externalTrackName {
                PlayerPanelRow(title: extName, subtitle: "Active external subtitle", isSelected: true, accent: accent)
            }

            Button {
                controller.state.activePanel = .none
                onOpenExternalSearch()
            } label: {
                Label("Search External Subtitles", systemImage: "magnifyingglass")
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 12)
                    .background(accent, in: RoundedRectangle(cornerRadius: 12))
            }
            .buttonStyle(NFScaleButtonStyle())

            Divider().background(Color.white.opacity(0.1))

            Text("Subtitle Appearance")
                .font(.caption.weight(.bold))
                .foregroundStyle(.white.opacity(0.6))

            HStack {
                Text("Size: \(Int(controller.subtitles.stylePrefs.fontSize))pt")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white)
                Slider(
                    value: Binding(
                        get: { controller.subtitles.stylePrefs.fontSize },
                        set: {
                            controller.subtitles.stylePrefs.fontSize = $0
                            controller.saveSubtitleStyle()
                        }
                    ),
                    in: 14...28,
                    step: 1
                )
                .tint(accent)
            }

            HStack(spacing: 10) {
                ForEach(SubtitleStylePrefs.colorPresets, id: \.hex) { preset in
                    let selected = controller.subtitles.stylePrefs.textColorHex == preset.hex
                    Button {
                        controller.subtitles.stylePrefs.textColorHex = preset.hex
                        controller.saveSubtitleStyle()
                    } label: {
                        Text(preset.name)
                            .font(.caption.weight(.bold))
                            .foregroundStyle(Color(hex: preset.hex))
                            .padding(.horizontal, 12)
                            .padding(.vertical, 6)
                            .background(selected ? Color.white.opacity(0.18) : Color.white.opacity(0.06), in: Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }

            HStack(spacing: 8) {
                ForEach(SubtitleBgStyle.allCases) { bg in
                    let selected = controller.subtitles.stylePrefs.bgStyle == bg
                    Button {
                        controller.subtitles.stylePrefs.bgStyle = bg
                        controller.saveSubtitleStyle()
                    } label: {
                        Text(bg.rawValue)
                            .font(.caption2.weight(.bold))
                            .foregroundStyle(.white)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 6)
                            .background(selected ? accent.opacity(0.35) : Color.white.opacity(0.06), in: Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}
