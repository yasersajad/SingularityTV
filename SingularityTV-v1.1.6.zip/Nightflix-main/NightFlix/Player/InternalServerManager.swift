import Foundation
import Observation

@MainActor
@Observable
final class InternalServerManager {
    var parentProviderID: String = ""
    var servers: [InternalServerOption] = []
    var switchState: InternalServerSwitchState = .idle
    @ObservationIgnored private var switchGeneration: Int = 0

    var hasInternalServers: Bool {
        !servers.isEmpty
    }

    var hasMultipleInternalServers: Bool {
        servers.count > 1
    }

    var activeServer: InternalServerOption? {
        servers.first(where: \.isSelected)
    }

    func reset(for providerID: String = "") {
        switchGeneration &+= 1
        parentProviderID = providerID
        servers = []
        switchState = .idle
    }

    func updateDiscoveredServers(_ incoming: [InternalServerOption], for providerID: String) {
        guard !incoming.isEmpty else { return }
        if !parentProviderID.isEmpty && parentProviderID != providerID {
            servers = []
        }
        parentProviderID = providerID
        servers = incoming.filter { $0.parentProviderID == providerID }
    }

    func selectServer(_ server: InternalServerOption, bridge: PlayerBridgeController) async -> Bool {
        guard server.parentProviderID == parentProviderID else {
            switchState = .failed("This source belongs to another streaming provider.")
            return false
        }
        guard server.isAvailable else {
            switchState = .failed("\(server.name) is currently unavailable.")
            return false
        }

        switchGeneration &+= 1
        let gen = switchGeneration
        switchState = .switching(server.name)

        let ok = await bridge.selectInternalServerAndVerify(server: server)
        guard gen == switchGeneration else { return false }

        if ok {
            servers = servers.map { item in
                var copy = item
                copy.isSelected = (item.id == server.id)
                return copy
            }
            switchState = .switched(server.name)
            return true
        } else {
            switchState = .failed("Could not switch to \(server.name). Kept the current source.")
            return false
        }
    }
}
