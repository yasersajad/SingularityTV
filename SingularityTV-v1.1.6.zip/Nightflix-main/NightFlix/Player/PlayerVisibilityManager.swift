import Foundation
import Observation

enum PlayerVisibilityState: Equatable, Sendable {
    case hidden
    case visible
    case interacting
    case seeking
    case scrubbing
    case gestureActive
    case menuPresented
}

@MainActor
@Observable
final class PlayerVisibilityManager {
    private(set) var state: PlayerVisibilityState = .visible
    var autoHideDuration: Double = 4.0
    var isControlsLocked = false

    @ObservationIgnored private var autoHideTask: Task<Void, Never>?
    @ObservationIgnored private var isDisposed = false

    var isChromeVisible: Bool {
        state != .hidden
    }

    var isGestureLocked: Bool {
        switch state {
        case .interacting, .seeking, .scrubbing, .gestureActive:
            return true
        default:
            return false
        }
    }

    func showAndScheduleAutoHide(hasCountdownOverlay: Bool = false) {
        guard !isDisposed else { return }
        if state == .menuPresented || isGestureLocked {
            return
        }
        state = .visible
        scheduleAutoHide(hasCountdownOverlay: hasCountdownOverlay)
    }

    func hide() {
        guard !isDisposed else { return }
        guard !isGestureLocked, state != .menuPresented else { return }
        autoHideTask?.cancel()
        autoHideTask = nil
        state = .hidden
    }

    func handleUserTap(hasCountdownOverlay: Bool = false) {
        guard !isDisposed, !isGestureLocked, state != .menuPresented else { return }
        if state == .hidden {
            showAndScheduleAutoHide(hasCountdownOverlay: hasCountdownOverlay)
        } else {
            hide()
        }
    }

    func handleWebInteraction(hasCountdownOverlay: Bool = false) {
        guard !isDisposed, !isGestureLocked, state != .menuPresented, !isControlsLocked else { return }
        showAndScheduleAutoHide(hasCountdownOverlay: hasCountdownOverlay)
    }

    func beginGesture(_ gestureMode: PlayerVisibilityState) {
        guard !isDisposed else { return }
        autoHideTask?.cancel()
        autoHideTask = nil
        state = gestureMode
    }

    func endGesture(hasCountdownOverlay: Bool = false) {
        guard !isDisposed else { return }
        if state == .menuPresented { return }
        state = .visible
        scheduleAutoHide(hasCountdownOverlay: hasCountdownOverlay)
    }

    func presentMenu() {
        guard !isDisposed else { return }
        autoHideTask?.cancel()
        autoHideTask = nil
        state = .menuPresented
    }

    func dismissMenu(hasCountdownOverlay: Bool = false) {
        guard !isDisposed else { return }
        state = .visible
        scheduleAutoHide(hasCountdownOverlay: hasCountdownOverlay)
    }

    func resetAutoHideTimer(hasCountdownOverlay: Bool = false) {
        guard !isDisposed, !isGestureLocked, state == .visible else { return }
        scheduleAutoHide(hasCountdownOverlay: hasCountdownOverlay)
    }

    func cleanup() {
        isDisposed = true
        autoHideTask?.cancel()
        autoHideTask = nil
        state = .hidden
    }

    private func scheduleAutoHide(hasCountdownOverlay: Bool) {
        autoHideTask?.cancel()
        guard !hasCountdownOverlay, state == .visible else { return }
        let delay = max(2.0, autoHideDuration)
        autoHideTask = Task { @MainActor [weak self] in
            try? await Task.sleep(for: .seconds(delay))
            guard !Task.isCancelled, let self, !self.isDisposed else { return }
            if self.state == .visible {
                self.state = .hidden
            }
        }
    }
}
