import Foundation
import SwiftUI
import WebKit

@MainActor
final class PlayerBridgeController {
    weak var webView: WKWebView?
    weak var activeVideoFrame: WKFrameInfo?

    func togglePlayPause(completion: ((Bool) -> Void)? = nil) {
        evaluateInVideoFrame("""
        (function(){
          var v = document.querySelector('video');
          if (!v) return false;
          if (v.paused) { v.play().catch(function(){}); } else { v.pause(); }
          return true;
        })();
        """, completion: completion)
    }

    func seek(to seconds: Double, completion: ((Bool) -> Void)? = nil) {
        guard seconds.isFinite, seconds >= 0 else { completion?(false); return }
        evaluateInVideoFrame("""
        (function(){
          var v = document.querySelector('video');
          if (!v) return false;
          var target = Math.max(0, Math.min(v.duration || \(seconds), \(seconds)));
          v.currentTime = target;
          return true;
        })();
        """, completion: completion)
    }

    func skip(by delta: Double, completion: ((Bool) -> Void)? = nil) {
        guard delta.isFinite else { completion?(false); return }
        evaluateInVideoFrame("""
        (function(){
          var v = document.querySelector('video');
          if (!v) return false;
          var target = Math.max(0, Math.min(v.duration || 1e9, (v.currentTime || 0) + \(delta)));
          v.currentTime = target;
          return true;
        })();
        """, completion: completion)
    }

    func setPlaybackRate(_ rate: Double, completion: ((Bool) -> Void)? = nil) {
        guard rate.isFinite, rate > 0 else { completion?(false); return }
        evaluateInVideoFrame("""
        (function(){
          var v = document.querySelector('video');
          if (!v) return false;
          v.playbackRate = \(rate);
          return true;
        })();
        """, completion: completion)
    }

    func setVolume(_ volume: Double, muted: Bool, completion: ((Bool) -> Void)? = nil) {
        let clamped = min(max(volume, 0), 1)
        evaluateInVideoFrame("""
        (function(){
          var v = document.querySelector('video');
          if (!v) return false;
          v.muted = \(muted ? "true" : "false");
          v.volume = \(clamped);
          return true;
        })();
        """, completion: completion)
    }

    func setVideoFillMode(fill: Bool) {
        let mode = fill ? "cover" : "contain"
        evaluateInVideoFrame("""
        (function(){
          var v = document.querySelector('video');
          if (!v) return false;
          v.style.setProperty('object-fit', '\(mode)', 'important');
          return true;
        })();
        """)
    }

    func selectTextTrack(index: Int?, completion: ((Bool) -> Void)? = nil) {
        let idxVal = index.map(String.init) ?? "-1"
        evaluateInVideoFrame("""
        (function(){
          var hls = window.__singularityHls || window.hls;
          if (hls && Array.isArray(hls.subtitleTracks) && hls.subtitleTracks.length > 0) {
            hls.subtitleTrack = \(idxVal);
            return true;
          }
          var v = document.querySelector('video');
          if (!v || !v.textTracks) return false;
          for (var i = 0; i < v.textTracks.length; i++) {
            v.textTracks[i].mode = (i === \(idxVal)) ? 'showing' : 'disabled';
          }
          return true;
        })();
        """, completion: completion)
    }

    func selectAudioTrack(index: Int, completion: ((Bool) -> Void)? = nil) {
        evaluateInVideoFrame("""
        (function(){
          var hls = window.__singularityHls || window.hls;
          if (hls && Array.isArray(hls.audioTracks) && hls.audioTracks.length > 0) {
            hls.audioTrack = \(index);
            return true;
          }
          var v = document.querySelector('video');
          if (!v || !v.audioTracks || v.audioTracks.length === 0) return false;
          for (var i = 0; i < v.audioTracks.length; i++) {
            v.audioTracks[i].enabled = (i === \(index));
          }
          return true;
        })();
        """, completion: completion)
    }

    func selectQualityLevel(index: Int, completion: ((Bool) -> Void)? = nil) {
        evaluateInVideoFrame("""
        (function(){
          var hls = window.__singularityHls || window.hls;
          if (hls && Array.isArray(hls.levels) && hls.levels.length > 0) {
            hls.currentLevel = \(index);
            return true;
          }
          return false;
        })();
        """, completion: completion)
    }

    private func evaluateInVideoFrame(_ script: String, completion: ((Bool) -> Void)? = nil) {
        guard let webView else {
            completion?(false)
            return
        }
        webView.evaluateJavaScript(script, in: activeVideoFrame, in: .page) { result in
            switch result {
            case .success(let value):
                completion?((value as? Bool) ?? true)
            case .failure(let error):
                Task { @MainActor in
                    SingularityDiagnostics.shared.record(category: "PlayerBridge", message: "JS command failed: \(error.localizedDescription)")
                }
                completion?(false)
            }
        }
    }
}

struct SingularityWebPlayerView: UIViewRepresentable {
    let url: URL
    let reloadToken: Int
    let bridgeController: PlayerBridgeController
    let onLoadingChanged: (Bool) -> Void
    let onError: (String?) -> Void
    let onEvent: (PlayerBridgeEvent) -> Void

    private static let messageHandlerName = "singularityPlayerEvents"

    func makeCoordinator() -> Coordinator {
        Coordinator(
            bridgeController: bridgeController,
            onLoadingChanged: onLoadingChanged,
            onError: onError,
            onEvent: onEvent
        )
    }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.allowsPictureInPictureMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.preferences.javaScriptCanOpenWindowsAutomatically = false
        config.applicationNameForUserAgent = "Version/18.0 Mobile/15E148 Safari/604.1"

        let ucc = config.userContentController
        ucc.add(WeakScriptMessageHandler(context.coordinator), name: Self.messageHandlerName)
        ucc.addUserScript(
            WKUserScript(
                source: Self.bridgeScript,
                injectionTime: .atDocumentStart,
                forMainFrameOnly: false
            )
        )
        ucc.addUserScript(
            WKUserScript(
                source: Self.resumeLoopGuardScript,
                injectionTime: .atDocumentStart,
                forMainFrameOnly: true
            )
        )

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.isOpaque = false
        webView.backgroundColor = .black
        webView.allowsBackForwardNavigationGestures = false
        webView.scrollView.backgroundColor = .black
        webView.scrollView.bounces = false
        webView.scrollView.isScrollEnabled = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never

        bridgeController.webView = webView
        context.coordinator.load(url, reloadToken: reloadToken, in: webView)
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        bridgeController.webView = webView
        context.coordinator.onLoadingChanged = onLoadingChanged
        context.coordinator.onError = onError
        context.coordinator.onEvent = onEvent
        context.coordinator.load(url, reloadToken: reloadToken, in: webView)
    }

    static func dismantleUIView(_ webView: WKWebView, coordinator: Coordinator) {
        webView.stopLoading()
        webView.pauseAllMediaPlayback(completionHandler: nil)
        webView.configuration.userContentController.removeAllUserScripts()
        webView.configuration.userContentController.removeScriptMessageHandler(forName: messageHandlerName)
        coordinator.bridgeController.activeVideoFrame = nil
        coordinator.bridgeController.webView = nil
    }

    private static let bridgeScript = """
    (function () {
        var handlers = window.webkit && window.webkit.messageHandlers;
        var channel = handlers && handlers.\(messageHandlerName);
        if (!channel) { return; }

        function post(payload) {
            try { channel.postMessage(payload); } catch (e) {}
        }

        function normalize(raw) {
            var payload = raw;
            if (typeof raw === "string") {
                try { payload = JSON.parse(raw); } catch (e) { return null; }
            }
            if (!payload || typeof payload !== "object") { return null; }
            return payload;
        }

        function shouldForward(payload) {
            if (payload.type === "PLAYER_EVENT") {
                return !!payload.data && typeof payload.data === "object";
            }
            if (payload.event === "status") { return true; }
            var hasPosition = payload.timestamp !== undefined || payload.progress !== undefined;
            var hasIdentity = payload.id !== undefined || payload.type !== undefined;
            return hasPosition && hasIdentity;
        }

        if (window === window.top) {
            window.addEventListener("message", function (event) {
                var payload = normalize(event.data);
                if (!payload || !shouldForward(payload)) { return; }
                try { post(JSON.parse(JSON.stringify(payload))); } catch (e) {}
            }, false);

            var lastTouch = 0;
            function reportInteraction() {
                var now = Date.now();
                if (now - lastTouch < 350) { return; }
                lastTouch = now;
                post({ type: "SINGULARITY_INTERACTION" });
            }
            document.addEventListener("touchstart", reportInteraction, { capture: true, passive: true });
            document.addEventListener("mousedown", reportInteraction, { capture: true, passive: true });
        }

        var _hlsVal = window.Hls;
        if (!_hlsVal) {
            try {
                Object.defineProperty(window, "Hls", {
                    configurable: true,
                    enumerable: true,
                    get: function () { return _hlsVal; },
                    set: function (HlsCtor) {
                        _hlsVal = HlsCtor;
                        if (HlsCtor && HlsCtor.prototype && !HlsCtor.prototype.__singularityHooked) {
                            HlsCtor.prototype.__singularityHooked = true;
                            var origAttach = HlsCtor.prototype.attachMedia;
                            if (typeof origAttach === "function") {
                                HlsCtor.prototype.attachMedia = function (media) {
                                    window.__singularityHls = this;
                                    var selfHls = this;
                                    if (typeof selfHls.on === "function") {
                                        ["hlsManifestParsed", "hlsAudioTracksUpdated", "hlsSubtitleTracksUpdated", "hlsLevelSwitched"].forEach(function (ev) {
                                            try { selfHls.on(ev, function () { emitVideoSnapshot(true); }); } catch (e) {}
                                        });
                                    }
                                    return origAttach.apply(this, arguments);
                                };
                            }
                        }
                    }
                });
            } catch (e) {}
        }

        function reportSubtitleUrl(u) {
            if (!u || typeof u !== "string") return;
            var lower = u.toLowerCase();
            if (lower.indexOf(".vtt") !== -1 || lower.indexOf(".srt") !== -1) {
                var cleanName = u.split("?")[0].split("/").pop() || "Site Subtitle";
                post({ type: "SINGULARITY_DISCOVERED_SUBTITLE", url: u, label: cleanName });
            }
        }

        if (window.fetch && !window.fetch.__singularityHooked) {
            var origFetch = window.fetch;
            window.fetch = function (input) {
                try {
                    var u = (typeof input === "string") ? input : (input && input.url);
                    reportSubtitleUrl(u);
                } catch (e) {}
                return origFetch.apply(this, arguments);
            };
            window.fetch.__singularityHooked = true;
        }

        if (window.XMLHttpRequest && !XMLHttpRequest.prototype.__singularityHooked) {
            var origOpen = XMLHttpRequest.prototype.open;
            XMLHttpRequest.prototype.open = function (method, url) {
                try { reportSubtitleUrl(url); } catch (e) {}
                return origOpen.apply(this, arguments);
            };
            XMLHttpRequest.prototype.__singularityHooked = true;
        }

        function discoverHlsInstance() {
            if (window.__singularityHls) return window.__singularityHls;
            if (window.hls && typeof window.hls === "object") {
                window.__singularityHls = window.hls;
                return window.hls;
            }
            return null;
        }

        function injectCleanPlayerCSS() {
            if (!document.getElementById("__singularityCleanCSS")) {
                var style = document.createElement("style");
                style.id = "__singularityCleanCSS";
                style.textContent = [
                    "html, body { margin: 0 !important; padding: 0 !important; width: 100% !important; height: 100% !important; overflow: hidden !important; background: #000 !important; }",
                    "video::-webkit-media-controls, video::-webkit-media-controls-enclosure, video::-webkit-media-controls-panel { display: none !important; opacity: 0 !important; }",
                    "video { position: fixed !important; inset: 0 !important; width: 100vw !important; height: 100vh !important; max-width: 100vw !important; max-height: 100vh !important; object-fit: contain !important; background: #000 !important; z-index: 1 !important; }",
                    "body *:not(video):not(:has(video)):not(style):not(script) { opacity: 0 !important; pointer-events: none !important; visibility: hidden !important; display: none !important; }"
                ].join("\\n");
                (document.head || document.documentElement).appendChild(style);
            }
        }

        var lastSnapAt = 0;
        function emitVideoSnapshot(force) {
            var v = document.querySelector("video");
            if (!v) return;
            var now = Date.now();
            if (!force && now - lastSnapAt < 850) return;
            lastSnapAt = now;

            var hls = discoverHlsInstance();
            var tTracks = [];
            if (hls && Array.isArray(hls.subtitleTracks) && hls.subtitleTracks.length > 0) {
                for (var hi = 0; hi < hls.subtitleTracks.length; hi++) {
                    var hst = hls.subtitleTracks[hi];
                    tTracks.push({
                        id: hi,
                        label: hst.name || hst.lang || ("Track " + (hi + 1)),
                        language: hst.lang || "",
                        isActive: hls.subtitleTrack === hi
                    });
                }
            } else if (v.textTracks) {
                for (var i = 0; i < v.textTracks.length; i++) {
                    var tt = v.textTracks[i];
                    tTracks.push({
                        id: i,
                        label: tt.label || tt.language || ("Track " + (i + 1)),
                        language: tt.language || "",
                        isActive: tt.mode === "showing"
                    });
                }
            }

            var aTracks = [];
            if (hls && Array.isArray(hls.audioTracks) && hls.audioTracks.length > 0) {
                for (var ai = 0; ai < hls.audioTracks.length; ai++) {
                    var hat = hls.audioTracks[ai];
                    aTracks.push({
                        id: ai,
                        label: hat.name || hat.lang || ("Audio " + (ai + 1)),
                        language: hat.lang || "",
                        isEnabled: hls.audioTrack === ai
                    });
                }
            } else if (v.audioTracks) {
                for (var j = 0; j < v.audioTracks.length; j++) {
                    var at = v.audioTracks[j];
                    aTracks.push({
                        id: j,
                        label: at.label || at.language || ("Audio " + (j + 1)),
                        language: at.language || "",
                        isEnabled: !!at.enabled
                    });
                }
            }

            var qLevels = [];
            if (hls && Array.isArray(hls.levels) && hls.levels.length > 0) {
                qLevels.push({ id: -1, label: "Auto", isSelected: hls.currentLevel === -1 });
                for (var qi = 0; qi < hls.levels.length; qi++) {
                    var lvl = hls.levels[qi];
                    var qLabel = lvl.height ? (lvl.height + "p") : ("Level " + (qi + 1));
                    qLevels.push({ id: qi, label: qLabel, isSelected: hls.currentLevel === qi });
                }
            }

            post({
                type: "SINGULARITY_VIDEO_STATE",
                currentTime: isFinite(v.currentTime) ? v.currentTime : 0,
                duration: isFinite(v.duration) ? v.duration : 0,
                isPlaying: !v.paused && !v.ended,
                isMuted: !!v.muted,
                volume: isFinite(v.volume) ? v.volume : 1,
                playbackRate: isFinite(v.playbackRate) ? v.playbackRate : 1,
                textTracks: tTracks,
                audioTracks: aTracks,
                qualityLevels: qLevels
            });
        }

        function attachVideo(v) {
            if (!v || v.__singularityAttached) return;
            v.__singularityAttached = true;
            v.controls = false;
            v.removeAttribute("controls");
            injectCleanPlayerCSS();
            ["play", "pause", "seeked", "loadedmetadata", "durationchange", "ratechange", "volumechange"].forEach(function (evt) {
                v.addEventListener(evt, function () {
                    v.controls = false;
                    injectCleanPlayerCSS();
                    emitVideoSnapshot(true);
                }, { passive: true });
            });
            v.addEventListener("timeupdate", function () { emitVideoSnapshot(false); }, { passive: true });
            if (v.textTracks && v.textTracks.addEventListener) {
                v.textTracks.addEventListener("addtrack", function () { emitVideoSnapshot(true); });
                v.textTracks.addEventListener("change", function () { emitVideoSnapshot(true); });
            }
            if (v.audioTracks && v.audioTracks.addEventListener) {
                v.audioTracks.addEventListener("addtrack", function () { emitVideoSnapshot(true); });
                v.audioTracks.addEventListener("change", function () { emitVideoSnapshot(true); });
            }
            emitVideoSnapshot(true);
        }

        function scanVideos() {
            var videos = document.getElementsByTagName("video");
            for (var i = 0; i < videos.length; i++) { attachVideo(videos[i]); }
        }

        if (document.documentElement) {
            scanVideos();
            if (window.MutationObserver) {
                new MutationObserver(scanVideos).observe(document.documentElement, { childList: true, subtree: true });
            }
        } else {
            document.addEventListener("DOMContentLoaded", scanVideos, { once: true });
        }
    })();
    """

    private static let resumeLoopGuardScript = """
    (function () {
        var params = new URLSearchParams(window.location.search);
        var raw = params.get("startAt") || params.get("progress");
        var resumeTime = raw ? parseFloat(raw) : NaN;
        if (!(resumeTime > 0)) { return; }

        var proto = window.HTMLMediaElement && HTMLMediaElement.prototype;
        var descriptor = proto && Object.getOwnPropertyDescriptor(proto, "currentTime");
        if (!descriptor || !descriptor.get || !descriptor.set) { return; }

        function guard(video) {
            if (!video || video.__singularityResumeGuarded) { return; }
            video.__singularityResumeGuarded = true;

            var furthest = 0;
            var everResumed = false;

            video.addEventListener("timeupdate", function () {
                var t = descriptor.get.call(video);
                if (t > furthest) { furthest = t; }
            });

            Object.defineProperty(video, "currentTime", {
                configurable: true,
                get: function () { return descriptor.get.call(this); },
                set: function (value) {
                    if (value === resumeTime) {
                        var current = descriptor.get.call(this);
                        if (!everResumed) {
                            everResumed = true;
                            descriptor.set.call(this, Math.max(resumeTime, furthest));
                            return;
                        }
                        if (current < furthest - 5) {
                            descriptor.set.call(this, Math.max(resumeTime, furthest));
                        }
                        return;
                    }
                    descriptor.set.call(this, value);
                }
            });
        }

        function guardAll() {
            var videos = document.getElementsByTagName("video");
            for (var i = 0; i < videos.length; i++) { guard(videos[i]); }
        }

        guardAll();
        if (window.MutationObserver) {
            new MutationObserver(guardAll).observe(document.documentElement, { childList: true, subtree: true });
        }
    })();
    """

    final class WeakScriptMessageHandler: NSObject, WKScriptMessageHandler {
        weak var delegate: WKScriptMessageHandler?
        init(_ delegate: WKScriptMessageHandler) { self.delegate = delegate }
        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            delegate?.userContentController(userContentController, didReceive: message)
        }
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
        let bridgeController: PlayerBridgeController
        var onLoadingChanged: (Bool) -> Void
        var onError: (String?) -> Void
        var onEvent: (PlayerBridgeEvent) -> Void

        private var requestedURL: URL?
        private var requestedReloadToken: Int?
        private var allowedBrandLabel: String?

        init(
            bridgeController: PlayerBridgeController,
            onLoadingChanged: @escaping (Bool) -> Void,
            onError: @escaping (String?) -> Void,
            onEvent: @escaping (PlayerBridgeEvent) -> Void
        ) {
            self.bridgeController = bridgeController
            self.onLoadingChanged = onLoadingChanged
            self.onError = onError
            self.onEvent = onEvent
        }

        func load(_ url: URL, reloadToken: Int, in webView: WKWebView) {
            guard requestedURL != url || requestedReloadToken != reloadToken else { return }
            requestedURL = url
            requestedReloadToken = reloadToken
            allowedBrandLabel = Self.brandLabel(of: url.host)
            bridgeController.activeVideoFrame = nil
            Task { @MainActor in
                onLoadingChanged(true)
                onError(nil)
            }
            webView.load(URLRequest(url: url))
        }

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            let senderFrame = message.frameInfo
            guard let dict = message.body as? [String: Any] else {
                if let bridgeMsg = PlayerBridgeMessage(payload: message.body) {
                    forwardLegacy(bridgeMsg)
                }
                return
            }

            if (dict["type"] as? String) == "SINGULARITY_INTERACTION" {
                Task { @MainActor in self.onEvent(.userInteraction) }
                return
            }

            if (dict["type"] as? String) == "SINGULARITY_DISCOVERED_SUBTITLE",
               let subURL = dict["url"] as? String, !subURL.isEmpty {
                let label = (dict["label"] as? String) ?? "Source Subtitle"
                Task { @MainActor in self.onEvent(.discoveredSubtitle(url: subURL, label: label)) }
                return
            }

            if (dict["type"] as? String) == "SINGULARITY_VIDEO_STATE" {
                Task { @MainActor in
                    self.bridgeController.activeVideoFrame = senderFrame
                }
                let ct = (dict["currentTime"] as? Double) ?? 0
                let dur = (dict["duration"] as? Double) ?? 0
                let playing = (dict["isPlaying"] as? Bool) ?? false
                let muted = (dict["isMuted"] as? Bool) ?? false
                let vol = (dict["volume"] as? Double) ?? 1
                let rate = (dict["playbackRate"] as? Double) ?? 1

                let rawT = (dict["textTracks"] as? [[String: Any]]) ?? []
                let tTracks = rawT.compactMap { row -> InPlayerSubtitleTrack? in
                    guard let id = row["id"] as? Int else { return nil }
                    let label = (row["label"] as? String) ?? "Track \(id + 1)"
                    let lang = (row["language"] as? String) ?? ""
                    let active = (row["isActive"] as? Bool) ?? false
                    return InPlayerSubtitleTrack(id: id, label: label, language: lang, isActive: active)
                }

                let rawA = (dict["audioTracks"] as? [[String: Any]]) ?? []
                let aTracks = rawA.compactMap { row -> InPlayerAudioTrack? in
                    guard let id = row["id"] as? Int else { return nil }
                    let label = (row["label"] as? String) ?? "Audio \(id + 1)"
                    let lang = (row["language"] as? String) ?? ""
                    let enabled = (row["isEnabled"] as? Bool) ?? false
                    return InPlayerAudioTrack(id: id, label: label, language: lang, isEnabled: enabled)
                }

                let rawQ = (dict["qualityLevels"] as? [[String: Any]]) ?? []
                let qLevels = rawQ.compactMap { row -> InPlayerQualityLevel? in
                    guard let id = row["id"] as? Int else { return nil }
                    let label = (row["label"] as? String) ?? "Quality"
                    let selected = (row["isSelected"] as? Bool) ?? false
                    return InPlayerQualityLevel(id: id, label: label, isSelected: selected)
                }

                let snap = PlayerMediaStateSnapshot(
                    currentTime: ct.isFinite ? ct : 0,
                    duration: dur.isFinite ? dur : 0,
                    isPlaying: playing,
                    isMuted: muted,
                    volume: vol.isFinite ? vol : 1,
                    playbackRate: rate.isFinite ? rate : 1,
                    hasVideoElement: true,
                    textTracks: tTracks,
                    audioTracks: aTracks,
                    qualityLevels: qLevels
                )
                Task { @MainActor in self.onEvent(.mediaSnapshot(snap)) }
                return
            }

            if let bridgeMsg = PlayerBridgeMessage(payload: dict) {
                forwardLegacy(bridgeMsg)
            }
        }

        private func forwardLegacy(_ bridgeMsg: PlayerBridgeMessage) {
            Task { @MainActor in
                switch bridgeMsg {
                case .userInteraction:
                    self.onEvent(.userInteraction)
                case .sourceUnavailable:
                    self.onEvent(.sourceUnavailable)
                case .progress(let ev):
                    self.onEvent(.progress(ev))
                }
            }
        }

        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            Task { @MainActor in
                onLoadingChanged(true)
                onError(nil)
            }
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            Task { @MainActor in
                onLoadingChanged(false)
            }
        }

        func webView(
            _ webView: WKWebView,
            decidePolicyFor navigationAction: WKNavigationAction,
            decisionHandler: @escaping (WKNavigationActionPolicy) -> Void
        ) {
            guard let targetFrame = navigationAction.targetFrame else {
                decisionHandler(.cancel)
                return
            }

            if targetFrame.isMainFrame,
               let host = navigationAction.request.url?.host,
               let allowedBrandLabel,
               Self.brandLabel(of: host) != allowedBrandLabel {
                decisionHandler(.cancel)
                return
            }

            decisionHandler(.allow)
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            handleLoadFailure(error, isLoading: webView.isLoading)
        }

        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            handleLoadFailure(error, isLoading: webView.isLoading)
        }

        func webView(
            _ webView: WKWebView,
            createWebViewWith configuration: WKWebViewConfiguration,
            for navigationAction: WKNavigationAction,
            windowFeatures: WKWindowFeatures
        ) -> WKWebView? {
            return nil
        }

        private func handleLoadFailure(_ error: Error, isLoading: Bool) {
            let nsErr = error as NSError
            if (nsErr.domain == NSURLErrorDomain && nsErr.code == NSURLErrorCancelled)
                || (nsErr.domain == "WebKitErrorDomain" && nsErr.code == 102) {
                Task { @MainActor in onLoadingChanged(isLoading) }
                return
            }
            Task { @MainActor in
                SingularityDiagnostics.shared.record(category: "PlayerWebView", message: "Load failed: \(error.localizedDescription)")
                onLoadingChanged(false)
                onError(error.localizedDescription)
            }
        }

        private static func brandLabel(of host: String?) -> String? {
            guard let host else { return nil }
            let labels = host.lowercased().split(separator: ".")
            guard labels.count >= 2 else { return labels.first.map(String.init) }
            return String(labels[labels.count - 2])
        }
    }
}
