import Foundation
import SwiftUI
import WebKit

@MainActor
final class PlayerBridgeController {
    weak var webView: WKWebView?
    weak var activeVideoFrame: WKFrameInfo?
    weak var activeServerFrame: WKFrameInfo?
    var isDisposed = false

    func togglePlayPause(completion: ((Bool) -> Void)? = nil) {
        evaluateInVideoFrame("""
        (function(){
          var v = document.querySelector('video');
          if (!v) return false;
          if (v.paused) { v.play().catch(function(){}); } else { v.pause(); }
          return true;
        })();
        """, completion: completion)
    }

    func seek(to seconds: Double, completion: ((Bool) -> Void)? = nil) {
        guard seconds.isFinite, seconds >= 0 else { completion?(false); return }
        evaluateInVideoFrame("""
        (function(){
          var v = document.querySelector('video');
          if (!v) return false;
          var target = Math.max(0, Math.min(v.duration || \(seconds), \(seconds)));
          v.currentTime = target;
          return true;
        })();
        """, completion: completion)
    }

    func skip(by delta: Double, completion: ((Bool) -> Void)? = nil) {
        guard delta.isFinite else { completion?(false); return }
        evaluateInVideoFrame("""
        (function(){
          var v = document.querySelector('video');
          if (!v) return false;
          var target = Math.max(0, Math.min(v.duration || 1e9, (v.currentTime || 0) + \(delta)));
          v.currentTime = target;
          return true;
        })();
        """, completion: completion)
    }

    func setPlaybackRate(_ rate: Double, completion: ((Bool) -> Void)? = nil) {
        guard rate.isFinite, rate > 0 else { completion?(false); return }
        evaluateInVideoFrame("""
        (function(){
          var v = document.querySelector('video');
          if (!v) return false;
          v.playbackRate = \(rate);
          return true;
        })();
        """, completion: completion)
    }

    func setVolume(_ volume: Double, muted: Bool, completion: ((Bool) -> Void)? = nil) {
        let clamped = min(max(volume, 0), 1)
        evaluateInVideoFrame("""
        (function(){
          var v = document.querySelector('video');
          if (!v) return false;
          v.muted = \(muted ? "true" : "false");
          v.volume = \(clamped);
          return true;
        })();
        """, completion: completion)
    }

    func setVideoFillMode(fill: Bool) {
        let mode = fill ? "cover" : "contain"
        evaluateInVideoFrame("""
        (function(){
          var v = document.querySelector('video');
          if (!v) return false;
          v.style.setProperty('object-fit', '\(mode)', 'important');
          return true;
        })();
        """)
    }

    func selectTextTrack(index: Int?, completion: ((Bool) -> Void)? = nil) {
        let idxVal = index.map(String.init) ?? "-1"
        evaluateInVideoFrame("""
        (function(){
          var hls = window.__singularityHls || window.hls;
          if (hls && Array.isArray(hls.subtitleTracks) && hls.subtitleTracks.length > 0) {
            hls.subtitleTrack = \(idxVal);
            return hls.subtitleTrack === \(idxVal) || \(idxVal) === -1;
          }
          if (window.jwplayer && typeof window.jwplayer === 'function') {
            try {
              var jw = window.jwplayer();
              if (jw && typeof jw.setCurrentCaptions === 'function') {
                jw.setCurrentCaptions(\(idxVal) < 0 ? 0 : (\(idxVal) + 1));
                return true;
              }
            } catch (e) {}
          }
          var v = document.querySelector('video');
          if (v && v.textTracks) {
            for (var i = 0; i < v.textTracks.length; i++) {
              v.textTracks[i].mode = (i === \(idxVal)) ? 'showing' : 'disabled';
            }
            if (\(idxVal) >= 0 && v.textTracks[\(idxVal)]) {
              return v.textTracks[\(idxVal)].mode === 'showing';
            }
            return true;
          }
          return false;
        })();
        """, completion: completion)
    }

    func selectTextTrackAndVerify(index: Int) async -> Bool {
        let switched = await withCheckedContinuation { cont in
            selectTextTrack(index: index) { ok in
                cont.resume(returning: ok)
            }
        }
        guard switched else { return false }
        try? await Task.sleep(for: .milliseconds(180))
        return await withCheckedContinuation { cont in
            evaluateInVideoFrame("""
            (function(){
              var hls = window.__singularityHls || window.hls;
              if (hls && Array.isArray(hls.subtitleTracks) && hls.subtitleTracks.length > 0) {
                return hls.subtitleTrack === \(index);
              }
              var v = document.querySelector('video');
              if (v && v.textTracks && v.textTracks[\(index)]) {
                return v.textTracks[\(index)].mode === 'showing';
              }
              return true;
            })();
            """) { ok in
                cont.resume(returning: ok)
            }
        }
    }

    func selectAudioTrackAndVerify(track: InPlayerAudioTrack) async -> Bool {
        let escapedLabel = track.displayName.replacingOccurrences(of: "'", with: "\\'")
        let escapedLang = track.languageCode.replacingOccurrences(of: "'", with: "\\'")
        let index = track.nativeIndex
        let switched = await withCheckedContinuation { cont in
            evaluateInVideoFrame("""
            (function(){
              var hls = window.__singularityHls || window.hls;
              if (hls && Array.isArray(hls.audioTracks) && hls.audioTracks.length > 0 && \(index) >= 0 && \(index) < hls.audioTracks.length) {
                hls.audioTrack = \(index);
                return true;
              }
              if (window.videojs && typeof window.videojs.getPlayers === 'function') {
                try {
                  var players = window.videojs.getPlayers();
                  var keys = Object.keys(players || {});
                  for (var p = 0; p < keys.length; p++) {
                    var pl = players[keys[p]];
                    if (pl && typeof pl.audioTracks === 'function') {
                      var list = pl.audioTracks();
                      if (list && list.length > \(index)) {
                        for (var k = 0; k < list.length; k++) { list[k].enabled = (k === \(index)); }
                        return true;
                      }
                    }
                  }
                } catch (e) {}
              }
              if (window.jwplayer && typeof window.jwplayer === 'function') {
                try {
                  var jw = window.jwplayer();
                  if (jw && typeof jw.setCurrentAudioTrack === 'function') {
                    jw.setCurrentAudioTrack(\(index));
                    return true;
                  }
                } catch (e) {}
              }
              var v = document.querySelector('video');
              if (v && v.audioTracks && v.audioTracks.length > 0 && \(index) < v.audioTracks.length) {
                for (var i = 0; i < v.audioTracks.length; i++) {
                  v.audioTracks[i].enabled = (i === \(index));
                }
                return true;
              }
              if ('\(escapedLabel)' !== '' || '\(escapedLang)' !== '') {
                var els = document.querySelectorAll('button, [role="menuitem"], [role="menuitemradio"], [role="option"], li');
                for (var m = 0; m < els.length; m++) {
                  var t = (els[m].innerText || els[m].textContent || '').trim().toLowerCase();
                  if (t && (t === '\(escapedLabel)'.toLowerCase() || ('\(escapedLang)' !== '' && t === '\(escapedLang)'.toLowerCase()))) {
                    els[m].click();
                    return true;
                  }
                }
              }
              return false;
            })();
            """) { ok in
                cont.resume(returning: ok)
            }
        }
        guard switched else { return false }
        try? await Task.sleep(for: .milliseconds(220))
        return await withCheckedContinuation { cont in
            evaluateInVideoFrame("""
            (function(){
              var hls = window.__singularityHls || window.hls;
              if (hls && Array.isArray(hls.audioTracks) && hls.audioTracks.length > 0) {
                return hls.audioTrack === \(index);
              }
              var v = document.querySelector('video');
              if (v && v.audioTracks && v.audioTracks.length > \(index)) {
                return !!v.audioTracks[\(index)].enabled;
              }
              return true;
            })();
            """) { verified in
                cont.resume(returning: verified)
            }
        }
    }

    func selectInternalServerAndVerify(server: InternalServerOption) async -> Bool {
        let escapedKey = server.domKey.replacingOccurrences(of: "'", with: "\\'")
        let escapedName = server.name.replacingOccurrences(of: "'", with: "\\'")
        let clicked = await withCheckedContinuation { cont in
            evaluateInFrame(activeServerFrame ?? activeVideoFrame, script: """
            (function(){
              var target = document.querySelector('[data-singularity-server-key="\(escapedKey)"]');
              if (target) {
                if (target.tagName === 'OPTION' && target.parentElement && target.parentElement.tagName === 'SELECT') {
                  target.selected = true;
                  target.parentElement.dispatchEvent(new Event('change', { bubbles: true }));
                  return true;
                }
                target.click();
                return true;
              }
              var els = document.querySelectorAll('button, a, li, [role="tab"], [role="button"], [role="option"]');
              for (var i = 0; i < els.length; i++) {
                var t = (els[i].innerText || els[i].textContent || '').trim();
                if (t === '\(escapedName)') {
                  els[i].click();
                  return true;
                }
              }
              return false;
            })();
            """) { ok in
                cont.resume(returning: ok)
            }
        }
        guard clicked else { return false }
        try? await Task.sleep(for: .milliseconds(350))
        return true
    }

    func selectQualityLevel(index: Int, label: String? = nil, completion: ((Bool) -> Void)? = nil) {
        let escapedLabel = (label ?? "").replacingOccurrences(of: "'", with: "\\'")
        evaluateInVideoFrame("""
        (function(){
          var hls = window.__singularityHls || window.hls;
          if (hls && Array.isArray(hls.levels) && hls.levels.length > 0) {
            hls.currentLevel = \(index);
            return true;
          }
          if ('\(escapedLabel)' !== '') {
            var els = document.querySelectorAll('button, [role="menuitem"], [role="option"], li');
            for (var k = 0; k < els.length; k++) {
              var t = (els[k].innerText || els[k].textContent || '').trim();
              if (t.indexOf('\(escapedLabel)') !== -1) { els[k].click(); return true; }
            }
          }
          return false;
        })();
        """, completion: completion)
    }

    func triggerSkipIntro(endSeconds: Double?, completion: ((Bool) -> Void)? = nil) {
        let endVal = endSeconds.map { String($0) } ?? "-1"
        evaluateInVideoFrame("""
        (function(){
          var btns = document.querySelectorAll('button, [role="button"], a');
          for (var i = 0; i < btns.length; i++) {
            var txt = (btns[i].innerText || btns[i].textContent || btns[i].getAttribute('aria-label') || '').trim().toLowerCase();
            if (txt.indexOf('skip intro') !== -1 || txt.indexOf('skip opening') !== -1 || txt.indexOf('تخطي المقدمة') !== -1) {
              btns[i].click();
              return true;
            }
          }
          if (\(endVal) > 0) {
            var v = document.querySelector('video');
            if (v) {
              v.currentTime = Math.min(v.duration || \(endVal), \(endVal));
              return true;
            }
          }
          return false;
        })();
        """, completion: completion)
    }

    func rescanInternalServers() {
        evaluateInFrame(activeServerFrame ?? activeVideoFrame, script: "if (typeof window.__singularityDiscoverServers === 'function') { window.__singularityDiscoverServers(true); }")
        evaluateInFrame(nil, script: "if (typeof window.__singularityDiscoverServers === 'function') { window.__singularityDiscoverServers(true); }")
    }

    private func evaluateInVideoFrame(_ script: String, completion: ((Bool) -> Void)? = nil) {
        evaluateInFrame(activeVideoFrame, script: script, completion: completion)
    }

    private func evaluateInFrame(_ frame: WKFrameInfo?, script: String, completion: ((Bool) -> Void)? = nil) {
        guard !isDisposed, let webView else {
            completion?(false)
            return
        }
        webView.evaluateJavaScript(script, in: frame, in: .page) { result in
            switch result {
            case .success(let value):
                completion?((value as? Bool) ?? true)
            case .failure(let error):
                Task { @MainActor in
                    SingularityDiagnostics.shared.record(category: "PlayerBridge", message: "JS command failed: \(error.localizedDescription)")
                }
                completion?(false)
            }
        }
    }
}

struct SingularityWebPlayerView: UIViewRepresentable {
    let url: URL
    let reloadToken: Int
    let bridgeController: PlayerBridgeController
    let onLoadingChanged: (Bool) -> Void
    let onError: (String?) -> Void
    let onEvent: (PlayerBridgeEvent) -> Void

    private static let messageHandlerName = "singularityPlayerEvents"

    func makeCoordinator() -> Coordinator {
        Coordinator(
            bridgeController: bridgeController,
            onLoadingChanged: onLoadingChanged,
            onError: onError,
            onEvent: onEvent
        )
    }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.allowsInlineMediaPlayback = true
        config.allowsPictureInPictureMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        config.preferences.javaScriptCanOpenWindowsAutomatically = false
        config.applicationNameForUserAgent = "Version/18.0 Mobile/15E148 Safari/604.1"

        let ucc = config.userContentController
        ucc.add(WeakScriptMessageHandler(context.coordinator), name: Self.messageHandlerName)
        ucc.addUserScript(
            WKUserScript(
                source: Self.bridgeScript,
                injectionTime: .atDocumentStart,
                forMainFrameOnly: false
            )
        )
        ucc.addUserScript(
            WKUserScript(
                source: Self.resumeLoopGuardScript,
                injectionTime: .atDocumentStart,
                forMainFrameOnly: true
            )
        )

        let webView = WKWebView(frame: .zero, configuration: config)
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        webView.isOpaque = false
        webView.backgroundColor = .black
        webView.allowsBackForwardNavigationGestures = false
        webView.scrollView.backgroundColor = .black
        webView.scrollView.bounces = false
        webView.scrollView.isScrollEnabled = false
        webView.scrollView.contentInsetAdjustmentBehavior = .never

        bridgeController.isDisposed = false
        bridgeController.webView = webView
        context.coordinator.load(url, reloadToken: reloadToken, in: webView)
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        bridgeController.webView = webView
        context.coordinator.onLoadingChanged = onLoadingChanged
        context.coordinator.onError = onError
        context.coordinator.onEvent = onEvent
        context.coordinator.load(url, reloadToken: reloadToken, in: webView)
    }

    static func dismantleUIView(_ webView: WKWebView, coordinator: Coordinator) {
        coordinator.bridgeController.isDisposed = true
        webView.stopLoading()
        webView.pauseAllMediaPlayback(completionHandler: nil)
        webView.navigationDelegate = nil
        webView.uiDelegate = nil
        webView.configuration.userContentController.removeAllUserScripts()
        webView.configuration.userContentController.removeScriptMessageHandler(forName: messageHandlerName)
        coordinator.bridgeController.activeVideoFrame = nil
        coordinator.bridgeController.activeServerFrame = nil
        coordinator.bridgeController.webView = nil
    }

    private static let bridgeScript = """
    (function () {
        var handlers = window.webkit && window.webkit.messageHandlers;
        var channel = handlers && handlers.\(messageHandlerName);
        if (!channel) { return; }

        function post(payload) {
            try { channel.postMessage(payload); } catch (e) {}
        }

        function normalize(raw) {
            var payload = raw;
            if (typeof raw === "string") {
                try { payload = JSON.parse(raw); } catch (e) { return null; }
            }
            if (!payload || typeof payload !== "object") { return null; }
            return payload;
        }

        function shouldForward(payload) {
            if (payload.type === "PLAYER_EVENT") {
                return !!payload.data && typeof payload.data === "object";
            }
            if (payload.event === "status") { return true; }
            var hasPosition = payload.timestamp !== undefined || payload.progress !== undefined;
            var hasIdentity = payload.id !== undefined || payload.type !== undefined;
            return hasPosition && hasIdentity;
        }

        if (window === window.top) {
            window.addEventListener("message", function (event) {
                var payload = normalize(event.data);
                if (!payload) { return; }
                if (payload.intro || payload.skipIntro || (payload.data && (payload.data.intro || payload.data.skipIntro))) {
                    var introObj = payload.intro || payload.skipIntro || (payload.data && (payload.data.intro || payload.data.skipIntro));
                    if (introObj && typeof introObj === "object") {
                        var st = Number(introObj.start !== undefined ? introObj.start : introObj.from);
                        var en = Number(introObj.end !== undefined ? introObj.end : introObj.to);
                        if (isFinite(st) && isFinite(en) && en > st) {
                            post({ type: "SINGULARITY_INTRO_WINDOW", start: st, end: en, hasDomButton: false, source: "postMessage" });
                        }
                    }
                }
                if (shouldForward(payload)) {
                    try { post(JSON.parse(JSON.stringify(payload))); } catch (e) {}
                }
            }, false);

            var lastTouch = 0;
            function reportInteraction() {
                var now = Date.now();
                if (now - lastTouch < 350) { return; }
                lastTouch = now;
                post({ type: "SINGULARITY_INTERACTION" });
            }
            document.addEventListener("touchstart", reportInteraction, { capture: true, passive: true });
            document.addEventListener("mousedown", reportInteraction, { capture: true, passive: true });
        }

        var _hlsVal = window.Hls;
        if (!_hlsVal) {
            try {
                Object.defineProperty(window, "Hls", {
                    configurable: true,
                    enumerable: true,
                    get: function () { return _hlsVal; },
                    set: function (HlsCtor) {
                        _hlsVal = HlsCtor;
                        if (HlsCtor && HlsCtor.prototype && !HlsCtor.prototype.__singularityHooked) {
                            HlsCtor.prototype.__singularityHooked = true;
                            var origAttach = HlsCtor.prototype.attachMedia;
                            if (typeof origAttach === "function") {
                                HlsCtor.prototype.attachMedia = function () {
                                    window.__singularityHls = this;
                                    var selfHls = this;
                                    if (typeof selfHls.on === "function") {
                                        ["hlsManifestParsed", "hlsAudioTracksUpdated", "hlsAudioTrackSwitched", "hlsSubtitleTracksUpdated", "hlsLevelSwitched"].forEach(function (ev) {
                                            try { selfHls.on(ev, function () { emitVideoSnapshot(true); }); } catch (e) {}
                                        });
                                    }
                                    return origAttach.apply(this, arguments);
                                };
                            }
                        }
                    }
                });
            } catch (e) {}
        }

        function resolveUrl(rel, base) {
            if (!rel) return "";
            try { return new URL(rel, base || window.location.href).href; } catch (e) { return rel; }
        }

        function parseM3u8Manifest(text, manifestUrl) {
            if (!text || text.indexOf("#EXTM3U") === -1) return;
            var lines = text.split(/\\r?\\n/);
            var audios = [];
            var qualities = [];
            var qSeen = {};
            for (var i = 0; i < lines.length; i++) {
                var line = lines[i];
                if (line.indexOf("#EXT-X-MEDIA:") === 0) {
                    var typeM = line.match(/TYPE=([^,]+)/i);
                    var nameM = line.match(/NAME="([^"]+)"/i);
                    var langM = line.match(/LANGUAGE="([^"]+)"/i);
                    var defM = line.match(/DEFAULT=(YES|NO)/i);
                    var chM = line.match(/CHANNELS="([^"]+)"/i);
                    var uriM = line.match(/URI="([^"]+)"/i);
                    var mType = typeM ? typeM[1].toUpperCase() : "";
                    var mName = nameM ? nameM[1] : (langM ? langM[1] : "");
                    var mLang = langM ? langM[1] : "";
                    var mCh = chM ? chM[1] : "";
                    if (mType === "AUDIO") {
                        audios.push({
                            id: audios.length,
                            label: mName,
                            language: mLang,
                            channels: mCh,
                            isDefault: defM ? defM[1] === "YES" : audios.length === 0,
                            isEnabled: defM ? defM[1] === "YES" : audios.length === 0,
                            sourceType: "hlsManifest",
                            selectable: true
                        });
                    } else if (mType === "SUBTITLES" && uriM && uriM[1]) {
                        var subUrl = resolveUrl(uriM[1], manifestUrl);
                        if (subUrl) {
                            post({ type: "SINGULARITY_DISCOVERED_SUBTITLE", url: subUrl, label: mName, language: mLang });
                        }
                    }
                } else if (line.indexOf("#EXT-X-STREAM-INF:") === 0) {
                    var resM = line.match(/RESOLUTION=\\d+x(\\d+)/i);
                    if (resM && !qSeen[resM[1]]) {
                        qSeen[resM[1]] = true;
                        qualities.push({ id: qualities.length, label: resM[1] + "p", isSelected: false });
                    }
                }
            }
            if (audios.length > 0) post({ type: "SINGULARITY_DISCOVERED_AUDIOS", source: "HLS Manifest", tracks: audios });
            if (qualities.length > 0) {
                qualities.unshift({ id: -1, label: "Auto", isSelected: true });
                post({ type: "SINGULARITY_DISCOVERED_QUALITIES", levels: qualities });
            }
        }

        function inspectJsonPayload(obj, depth) {
            if (!obj || typeof obj !== "object" || (depth || 0) > 4) return;
            var d = depth || 0;
            var candidates = obj.subtitles || obj.tracks || obj.captions || obj.textTracks;
            if (Array.isArray(candidates)) {
                for (var i = 0; i < candidates.length; i++) {
                    var c = candidates[i];
                    if (!c || typeof c !== "object") continue;
                    var u = c.url || c.file || c.src;
                    if (typeof u === "string" && u.length > 4) {
                        var lbl = c.label || c.lang || c.language || c.name || "";
                        var lng = c.language || c.lang || c.srclang || "";
                        post({ type: "SINGULARITY_DISCOVERED_SUBTITLE", url: u, label: String(lbl), language: String(lng) });
                    }
                }
            }
            var introCandidate = obj.intro || obj.skipIntro || (obj.timestamps && obj.timestamps.intro);
            if (introCandidate && typeof introCandidate === "object") {
                var st = Number(introCandidate.start !== undefined ? introCandidate.start : introCandidate.from);
                var en = Number(introCandidate.end !== undefined ? introCandidate.end : introCandidate.to);
                if (isFinite(st) && isFinite(en) && en > st) {
                    post({ type: "SINGULARITY_INTRO_WINDOW", start: st, end: en, hasDomButton: false, source: "Stream JSON" });
                }
            }
            var srcs = obj.sources || obj.streams;
            if (Array.isArray(srcs)) {
                var qList = [];
                var seen = {};
                for (var j = 0; j < srcs.length; j++) {
                    var s = srcs[j];
                    if (s && s.quality && !seen[s.quality]) {
                        seen[s.quality] = true;
                        qList.push({ id: qList.length, label: String(s.quality), isSelected: qList.length === 0 });
                    }
                }
                if (qList.length > 0) post({ type: "SINGULARITY_DISCOVERED_QUALITIES", levels: qList });
            }
            if (Array.isArray(obj)) {
                for (var ai = 0; ai < Math.min(obj.length, 10); ai++) {
                    inspectJsonPayload(obj[ai], d + 1);
                }
            } else {
                var keys = Object.keys(obj);
                for (var ki = 0; ki < keys.length; ki++) {
                    var val = obj[keys[ki]];
                    if (val && typeof val === "object") {
                        inspectJsonPayload(val, d + 1);
                    }
                }
            }
        }

        function reportSubtitleUrl(u) {
            if (!u || typeof u !== "string") return;
            var lower = u.toLowerCase();
            if (lower.indexOf(".vtt") !== -1 || lower.indexOf(".srt") !== -1) {
                var cleanName = u.split("?")[0].split("/").pop() || "";
                post({ type: "SINGULARITY_DISCOVERED_SUBTITLE", url: u, label: cleanName, language: "" });
            }
        }

        if (window.fetch && !window.fetch.__singularityHooked) {
            var origFetch = window.fetch;
            window.fetch = function (input) {
                var u = (typeof input === "string") ? input : (input && input.url);
                try { reportSubtitleUrl(u); } catch (e) {}
                return origFetch.apply(this, arguments).then(function (resp) {
                    try {
                        var ct = (resp.headers && resp.headers.get("content-type")) || "";
                        var lowerU = (u || "").toLowerCase();
                        if (lowerU.indexOf(".m3u8") !== -1 || ct.indexOf("mpegurl") !== -1) {
                            resp.clone().text().then(function (txt) { parseM3u8Manifest(txt, u); }).catch(function(){});
                        } else if (ct.indexOf("application/json") !== -1) {
                            resp.clone().json().then(function (j) { inspectJsonPayload(j, 0); }).catch(function(){});
                        }
                    } catch (e) {}
                    return resp;
                });
            };
            window.fetch.__singularityHooked = true;
        }

        if (window.XMLHttpRequest && !XMLHttpRequest.prototype.__singularityHooked) {
            var origOpen = XMLHttpRequest.prototype.open;
            var origSend = XMLHttpRequest.prototype.send;
            XMLHttpRequest.prototype.open = function (method, url) {
                this.__singularityUrl = url;
                try { reportSubtitleUrl(url); } catch (e) {}
                return origOpen.apply(this, arguments);
            };
            XMLHttpRequest.prototype.send = function () {
                var xhr = this;
                xhr.addEventListener("load", function () {
                    try {
                        var u = (xhr.__singularityUrl || "").toLowerCase();
                        var text = xhr.responseText || "";
                        if (u.indexOf(".m3u8") !== -1 || text.indexOf("#EXTM3U") === 0) {
                            parseM3u8Manifest(text, xhr.__singularityUrl);
                        } else if (text && (text.charAt(0) === "{" || text.charAt(0) === "[")) {
                            inspectJsonPayload(JSON.parse(text), 0);
                        }
                    } catch (e) {}
                });
                return origSend.apply(this, arguments);
            };
            XMLHttpRequest.prototype.__singularityHooked = true;
        }

        function discoverHlsInstance() {
            if (window.__singularityHls) return window.__singularityHls;
            if (window.hls && typeof window.hls === "object") {
                window.__singularityHls = window.hls;
                return window.hls;
            }
            return null;
        }

        var lastServerSig = "";
        function discoverInternalServers(force) {
            var containers = document.querySelectorAll('[class*="server" i], [id*="server" i], [class*="mirror" i], [id*="mirror" i], [aria-label*="server" i], [title*="server" i], [data-testid*="server" i], [data-server], [data-source-id], [data-embed]');
            var list = [];
            var seen = {};
            for (var c = 0; c < containers.length; c++) {
                var root = containers[c];
                if (root.closest && root.closest('[role="menu"], .plyr__menu, .vjs-menu, .vds-menu')) continue;
                var items = root.matches('button, a, li, option, [data-server], [data-source-id], [data-embed]') ? [root] : root.querySelectorAll('button, a, li, option, [role="tab"], [role="option"]');
                for (var i = 0; i < items.length; i++) {
                    var el = items[i];
                    if (el.closest && el.closest('[role="menu"], .plyr__menu, .vjs-menu, .vds-menu')) continue;
                    var name = (el.innerText || el.textContent || el.getAttribute('data-name') || el.getAttribute('title') || el.getAttribute('aria-label') || '').trim();
                    if (!name || name.length > 42 || name.length < 2) continue;
                    if (/^(\\d+(\\.\\d+)?x|normal|all settings|playback|loop|pip|picture.in.picture|download|share|report|theater|aspect|zoom|stretch|fit|fill|off|none|play|pause|mute|full|close|skip|next|prev|back|settings|cc|subtitles|audio|captions|speed|quality|\\d+p|auto|english|arabic|french|spanish|german|turkish|japanese|korean)/i.test(name)) continue;
                    var norm = name.toLowerCase();
                    if (seen[norm]) continue;
                    seen[norm] = true;
                    var key = "srv_" + list.length + "_" + norm.replace(/[^a-z0-9]/g, "");
                    el.setAttribute('data-singularity-server-key', key);
                    var cls = (el.className && typeof el.className === 'string') ? el.className.toLowerCase() : '';
                    var isSel = cls.indexOf('active') !== -1 || cls.indexOf('selected') !== -1 || el.getAttribute('aria-selected') === 'true' || el.getAttribute('aria-current') === 'true' || !!el.selected;
                    var sType = el.tagName === 'OPTION' ? 'dropdown' : (cls.indexOf('tab') !== -1 ? 'tab' : 'button');
                    var pUrl = el.getAttribute('data-url') || el.getAttribute('href') || null;
                    list.push({ id: key, index: list.length, name: name, sourceType: sType, isSelected: isSel, isAvailable: !el.disabled, playbackURL: pUrl, domKey: key });
                }
            }
            if (list.length >= 1) {
                var sig = list.map(function (x) { return x.name + (x.isSelected ? "*" : ""); }).join("|");
                if (force || sig !== lastServerSig) {
                    lastServerSig = sig;
                    post({ type: "SINGULARITY_DISCOVERED_SERVERS", servers: list });
                }
            }
        }
        window.__singularityDiscoverServers = discoverInternalServers;

        function detectDomSignals() {
            var hasSkipBtn = false;
            var hasNextBtn = false;
            var els = document.querySelectorAll("button, [role='button']");
            for (var i = 0; i < els.length; i++) {
                var txt = (els[i].innerText || els[i].textContent || els[i].getAttribute("aria-label") || "").trim().toLowerCase();
                if (!txt) continue;
                if (txt.indexOf("skip intro") !== -1 || txt.indexOf("skip opening") !== -1 || txt.indexOf("تخطي المقدمة") !== -1) {
                    hasSkipBtn = true;
                }
                if (txt.indexOf("next episode") !== -1 || txt.indexOf("up next") !== -1) {
                    hasNextBtn = true;
                }
            }
            if (hasSkipBtn) {
                post({ type: "SINGULARITY_INTRO_WINDOW", start: -1, end: -1, hasDomButton: true, source: "Player Button" });
            }
            if (hasNextBtn) {
                post({ type: "SINGULARITY_AUTOPLAY_SIGNAL", hasNextButton: true, source: "Player Button" });
            }
        }

        function injectCleanPlayerCSS() {
            if (!document.getElementById("__singularityCleanCSS")) {
                var style = document.createElement("style");
                style.id = "__singularityCleanCSS";
                style.textContent = [
                    "html, body { margin: 0 !important; padding: 0 !important; width: 100% !important; height: 100% !important; overflow: hidden !important; background: #000 !important; }",
                    "video::-webkit-media-controls, video::-webkit-media-controls-enclosure, video::-webkit-media-controls-panel { display: none !important; opacity: 0 !important; }",
                    "video { position: fixed !important; inset: 0 !important; width: 100vw !important; height: 100vh !important; max-width: 100vw !important; max-height: 100vh !important; object-fit: contain !important; background: #000 !important; z-index: 1 !important; }",
                    "body *:not(video):not(:has(video)):not(style):not(script) { opacity: 0 !important; pointer-events: none !important; visibility: hidden !important; }"
                ].join("\\n");
                (document.head || document.documentElement).appendChild(style);
            }
        }

        var lastSnapAt = 0;
        function emitVideoSnapshot(force) {
            discoverInternalServers();
            var v = document.querySelector("video");
            if (!v) return;
            var now = Date.now();
            if (!force && now - lastSnapAt < 850) return;
            lastSnapAt = now;

            detectDomSignals();

            var trackEls = v.querySelectorAll("track");
            for (var ti = 0; ti < trackEls.length; ti++) {
                var tr = trackEls[ti];
                if (tr.src) {
                    post({ type: "SINGULARITY_DISCOVERED_SUBTITLE", url: tr.src, label: tr.label || tr.srclang || "", language: tr.srclang || "" });
                }
            }

            var hls = discoverHlsInstance();
            var tTracks = [];
            if (hls && Array.isArray(hls.subtitleTracks) && hls.subtitleTracks.length > 0) {
                for (var hi = 0; hi < hls.subtitleTracks.length; hi++) {
                    var hst = hls.subtitleTracks[hi];
                    tTracks.push({
                        id: hi,
                        label: hst.name || hst.lang || "",
                        language: hst.lang || "",
                        isActive: hls.subtitleTrack === hi
                    });
                }
            } else if (v.textTracks) {
                for (var i = 0; i < v.textTracks.length; i++) {
                    var tt = v.textTracks[i];
                    tTracks.push({
                        id: i,
                        label: tt.label || tt.language || "",
                        language: tt.language || "",
                        isActive: tt.mode === "showing"
                    });
                }
            }

            var aTracks = [];
            if (hls && Array.isArray(hls.audioTracks) && hls.audioTracks.length > 0) {
                for (var ai = 0; ai < hls.audioTracks.length; ai++) {
                    var hat = hls.audioTracks[ai];
                    aTracks.push({
                        id: ai,
                        label: hat.name || hat.lang || "",
                        language: hat.lang || "",
                        codec: hat.audioCodec || "",
                        isDefault: !!hat.default,
                        isEnabled: hls.audioTrack === ai,
                        sourceType: "hlsJs",
                        selectable: true
                    });
                }
            } else if (window.videojs && typeof window.videojs.getPlayers === "function") {
                try {
                    var vjsPlayers = window.videojs.getPlayers();
                    var vjsKeys = Object.keys(vjsPlayers || {});
                    for (var vp = 0; vp < vjsKeys.length; vp++) {
                        var vpl = vjsPlayers[vjsKeys[vp]];
                        if (vpl && typeof vpl.audioTracks === "function") {
                            var vList = vpl.audioTracks();
                            for (var vi = 0; vi < vList.length; vi++) {
                                aTracks.push({
                                    id: vi,
                                    label: vList[vi].label || vList[vi].language || "",
                                    language: vList[vi].language || "",
                                    isEnabled: !!vList[vi].enabled,
                                    sourceType: "videoJs",
                                    selectable: true
                                });
                            }
                        }
                    }
                } catch (e) {}
            } else if (window.jwplayer && typeof window.jwplayer === "function") {
                try {
                    var jw = window.jwplayer();
                    if (jw && typeof jw.getAudioTracks === "function") {
                        var jList = jw.getAudioTracks() || [];
                        var jCur = typeof jw.getCurrentAudioTrack === "function" ? jw.getCurrentAudioTrack() : 0;
                        for (var ji = 0; ji < jList.length; ji++) {
                            aTracks.push({
                                id: ji,
                                label: jList[ji].name || jList[ji].language || "",
                                language: jList[ji].language || "",
                                isEnabled: jCur === ji,
                                sourceType: "jwPlayer",
                                selectable: true
                            });
                        }
                    }
                } catch (e) {}
            } else if (v.audioTracks && v.audioTracks.length > 0) {
                for (var j = 0; j < v.audioTracks.length; j++) {
                    var at = v.audioTracks[j];
                    aTracks.push({
                        id: j,
                        label: at.label || at.language || "",
                        language: at.language || "",
                        isEnabled: !!at.enabled,
                        sourceType: "html5",
                        selectable: true
                    });
                }
            }

            var qLevels = [];
            if (hls && Array.isArray(hls.levels) && hls.levels.length > 0) {
                qLevels.push({ id: -1, label: "Auto", isSelected: hls.currentLevel === -1 });
                for (var qi = 0; qi < hls.levels.length; qi++) {
                    var lvl = hls.levels[qi];
                    var qLabel = lvl.height ? (lvl.height + "p") : ("Level " + (qi + 1));
                    qLevels.push({ id: qi, label: qLabel, isSelected: hls.currentLevel === qi });
                }
            }

            post({
                type: "SINGULARITY_VIDEO_STATE",
                currentTime: isFinite(v.currentTime) ? v.currentTime : 0,
                duration: isFinite(v.duration) ? v.duration : 0,
                isPlaying: !v.paused && !v.ended,
                isMuted: !!v.muted,
                volume: isFinite(v.volume) ? v.volume : 1,
                playbackRate: isFinite(v.playbackRate) ? v.playbackRate : 1,
                textTracks: tTracks,
                audioTracks: aTracks,
                qualityLevels: qLevels
            });
        }

        function attachVideo(v) {
            if (!v || v.__singularityAttached) return;
            v.__singularityAttached = true;
            v.controls = false;
            v.removeAttribute("controls");
            injectCleanPlayerCSS();
            ["play", "pause", "seeked", "loadedmetadata", "durationchange", "ratechange", "volumechange"].forEach(function (evt) {
                v.addEventListener(evt, function () {
                    v.controls = false;
                    injectCleanPlayerCSS();
                    emitVideoSnapshot(true);
                }, { passive: true });
            });
            v.addEventListener("timeupdate", function () { emitVideoSnapshot(false); }, { passive: true });
            if (v.textTracks && v.textTracks.addEventListener) {
                v.textTracks.addEventListener("addtrack", function () { emitVideoSnapshot(true); });
                v.textTracks.addEventListener("change", function () { emitVideoSnapshot(true); });
            }
            if (v.audioTracks && v.audioTracks.addEventListener) {
                v.audioTracks.addEventListener("addtrack", function () { emitVideoSnapshot(true); });
                v.audioTracks.addEventListener("change", function () { emitVideoSnapshot(true); });
            }
            emitVideoSnapshot(true);
            setTimeout(function () { emitVideoSnapshot(true); }, 1200);
            setTimeout(function () { emitVideoSnapshot(true); }, 3200);
            setTimeout(function () { emitVideoSnapshot(true); }, 6000);
        }

        function scanVideos() {
            discoverInternalServers();
            var videos = document.getElementsByTagName("video");
            for (var i = 0; i < videos.length; i++) { attachVideo(videos[i]); }
        }

        if (document.documentElement) {
            scanVideos();
            if (window.MutationObserver) {
                new MutationObserver(scanVideos).observe(document.documentElement, { childList: true, subtree: true });
            }
        } else {
            document.addEventListener("DOMContentLoaded", scanVideos, { once: true });
        }
    })();
    """

    private static let resumeLoopGuardScript = """
    (function () {
        var params = new URLSearchParams(window.location.search);
        var raw = params.get("startAt") || params.get("progress");
        var resumeTime = raw ? parseFloat(raw) : NaN;
        if (!(resumeTime > 0)) { return; }

        var proto = window.HTMLMediaElement && HTMLMediaElement.prototype;
        var descriptor = proto && Object.getOwnPropertyDescriptor(proto, "currentTime");
        if (!descriptor || !descriptor.get || !descriptor.set) { return; }

        function guard(video) {
            if (!video || video.__singularityResumeGuarded) { return; }
            video.__singularityResumeGuarded = true;

            var furthest = 0;
            var everResumed = false;

            video.addEventListener("timeupdate", function () {
                var t = descriptor.get.call(video);
                if (t > furthest) { furthest = t; }
            });

            Object.defineProperty(video, "currentTime", {
                configurable: true,
                get: function () { return descriptor.get.call(this); },
                set: function (value) {
                    if (value === resumeTime) {
                        var current = descriptor.get.call(this);
                        if (!everResumed) {
                            everResumed = true;
                            descriptor.set.call(this, Math.max(resumeTime, furthest));
                            return;
                        }
                        if (current < furthest - 5) {
                            descriptor.set.call(this, Math.max(resumeTime, furthest));
                        }
                        return;
                    }
                    descriptor.set.call(this, value);
                }
            });
        }

        function guardAll() {
            var videos = document.getElementsByTagName("video");
            for (var i = 0; i < videos.length; i++) { guard(videos[i]); }
        }

        guardAll();
        if (window.MutationObserver) {
            new MutationObserver(guardAll).observe(document.documentElement, { childList: true, subtree: true });
        }
    })();
    """

    final class WeakScriptMessageHandler: NSObject, WKScriptMessageHandler {
        weak var delegate: WKScriptMessageHandler?
        init(_ delegate: WKScriptMessageHandler) { self.delegate = delegate }
        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            delegate?.userContentController(userContentController, didReceive: message)
        }
    }

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKScriptMessageHandler {
        let bridgeController: PlayerBridgeController
        var onLoadingChanged: (Bool) -> Void
        var onError: (String?) -> Void
        var onEvent: (PlayerBridgeEvent) -> Void

        private var requestedURL: URL?
        private var requestedReloadToken: Int?
        private var allowedBrandLabel: String?

        init(
            bridgeController: PlayerBridgeController,
            onLoadingChanged: @escaping (Bool) -> Void,
            onError: @escaping (String?) -> Void,
            onEvent: @escaping (PlayerBridgeEvent) -> Void
        ) {
            self.bridgeController = bridgeController
            self.onLoadingChanged = onLoadingChanged
            self.onError = onError
            self.onEvent = onEvent
        }

        func load(_ url: URL, reloadToken: Int, in webView: WKWebView) {
            guard requestedURL != url || requestedReloadToken != reloadToken else { return }
            requestedURL = url
            requestedReloadToken = reloadToken
            allowedBrandLabel = Self.brandLabel(of: url.host)
            bridgeController.activeVideoFrame = nil
            bridgeController.activeServerFrame = nil
            Task { @MainActor in
                onLoadingChanged(true)
                onError(nil)
            }
            webView.load(URLRequest(url: url))
        }

        func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
            let senderFrame = message.frameInfo
            guard let dict = message.body as? [String: Any] else {
                if let bridgeMsg = PlayerBridgeMessage(payload: message.body) {
                    forwardLegacy(bridgeMsg)
                }
                return
            }

            let msgType = dict["type"] as? String
            if msgType == "SINGULARITY_INTERACTION" {
                Task { @MainActor in self.onEvent(.userInteraction) }
                return
            }

            if msgType == "SINGULARITY_DISCOVERED_SERVERS",
               let rawServers = dict["servers"] as? [[String: Any]] {
                let parsed = rawServers.compactMap { row -> InternalServerOption? in
                    guard let id = row["id"] as? String,
                          let idx = row["index"] as? Int,
                          let name = row["name"] as? String,
                          let domKey = row["domKey"] as? String else { return nil }
                    let sTypeStr = (row["sourceType"] as? String) ?? ""
                    let sType: InternalServerSourceType
                    switch sTypeStr {
                    case "tab": sType = .tab
                    case "dropdown": sType = .dropdown
                    case "button": sType = .button
                    default: sType = .unknown
                    }
                    let isSel = (row["isSelected"] as? Bool) ?? false
                    let isAvail = (row["isAvailable"] as? Bool) ?? true
                    let providerHost = self.requestedURL?.host ?? ""
                    let pUrl = row["playbackURL"] as? String
                    return InternalServerOption(
                        id: providerHost + "::" + id,
                        parentProviderID: providerHost,
                        nativeIndex: idx,
                        name: name,
                        sourceType: sType,
                        isSelected: isSel,
                        isAvailable: isAvail,
                        playbackURL: pUrl,
                        domKey: domKey
                    )
                }
                if !parsed.isEmpty {
                    Task { @MainActor in
                        self.bridgeController.activeServerFrame = senderFrame
                        self.onEvent(.discoveredInternalServers(parsed))
                    }
                }
                return
            }

            if msgType == "SINGULARITY_INTRO_WINDOW" {
                let startVal = dict["start"] as? Double
                let endVal = dict["end"] as? Double
                let hasBtn = (dict["hasDomButton"] as? Bool) ?? false
                let src = (dict["source"] as? String) ?? "Source"
                let window = IntroSkipWindow(
                    start: (startVal ?? -1) >= 0 ? startVal : nil,
                    end: (endVal ?? -1) > 0 ? endVal : nil,
                    hasDomButton: hasBtn,
                    source: src
                )
                if window.isValid {
                    Task { @MainActor in self.onEvent(.discoveredIntroWindow(window)) }
                }
                return
            }

            if msgType == "SINGULARITY_AUTOPLAY_SIGNAL" {
                let hasBtn = (dict["hasNextButton"] as? Bool) ?? false
                let src = (dict["source"] as? String) ?? "Source"
                let signal = ServerAutoplaySignal(hasNextButton: hasBtn, countdownSeconds: nil, source: src)
                Task { @MainActor in self.onEvent(.discoveredAutoplaySignal(signal)) }
                return
            }

            if msgType == "SINGULARITY_DISCOVERED_SUBTITLE",
               let subURL = dict["url"] as? String, !subURL.isEmpty {
                let label = (dict["label"] as? String) ?? ""
                let lang = (dict["language"] as? String) ?? ""
                let filename = URL(string: subURL)?.lastPathComponent ?? label
                let resolved = SubtitleLanguageResolver.resolveFromMetadata(
                    serverCode: lang,
                    sourceLabel: label,
                    filename: filename
                )
                let sub = DiscoveredSiteSubtitle(
                    url: subURL,
                    label: label,
                    language: resolved.isKnown ? resolved.code : lang,
                    originalFilename: filename,
                    resolvedLanguageName: resolved.isKnown ? resolved.name : "Unknown Language",
                    displayTitle: resolved.isKnown ? resolved.name : "Unknown Language"
                )
                Task { @MainActor in self.onEvent(.discoveredSubtitle(sub)) }
                return
            }

            if msgType == "SINGULARITY_DISCOVERED_AUDIOS",
               let rawA = dict["tracks"] as? [[String: Any]] {
                let src = (dict["source"] as? String) ?? "Stream"
                let tracks = Self.parseAudioTracks(rawA, sourcePrefix: src)
                if !tracks.isEmpty {
                    Task { @MainActor in self.onEvent(.discoveredAudioTracks(tracks, source: src)) }
                }
                return
            }

            if msgType == "SINGULARITY_DISCOVERED_QUALITIES",
               let rawQ = dict["levels"] as? [[String: Any]] {
                let levels = rawQ.compactMap { row -> InPlayerQualityLevel? in
                    guard let id = row["id"] as? Int else { return nil }
                    let label = (row["label"] as? String) ?? "Quality"
                    let selected = (row["isSelected"] as? Bool) ?? false
                    return InPlayerQualityLevel(id: id, label: label, isSelected: selected)
                }
                if !levels.isEmpty {
                    Task { @MainActor in self.onEvent(.discoveredQualityLevels(levels)) }
                }
                return
            }

            if msgType == "SINGULARITY_VIDEO_STATE" {
                Task { @MainActor in
                    self.bridgeController.activeVideoFrame = senderFrame
                }
                let ct = (dict["currentTime"] as? Double) ?? 0
                let dur = (dict["duration"] as? Double) ?? 0
                let playing = (dict["isPlaying"] as? Bool) ?? false
                let muted = (dict["isMuted"] as? Bool) ?? false
                let vol = (dict["volume"] as? Double) ?? 1
                let rate = (dict["playbackRate"] as? Double) ?? 1

                let rawT = (dict["textTracks"] as? [[String: Any]]) ?? []
                let tTracks = rawT.compactMap { row -> InPlayerSubtitleTrack? in
                    guard let idx = row["id"] as? Int else { return nil }
                    let label = (row["label"] as? String) ?? ""
                    let lang = (row["language"] as? String) ?? ""
                    let active = (row["isActive"] as? Bool) ?? false
                    let resolved = SubtitleLanguageResolver.resolveFromMetadata(serverCode: lang, sourceLabel: label)
                    let resolvedName = resolved.isKnown ? resolved.name : "Unknown Language"
                    return InPlayerSubtitleTrack(
                        trackId: "instream_\(idx)_\(lang.lowercased())",
                        nativeIndex: idx,
                        label: resolvedName,
                        language: resolved.isKnown ? resolved.code : lang,
                        resolvedLanguageName: resolvedName,
                        isActive: active
                    )
                }

                let rawA = (dict["audioTracks"] as? [[String: Any]]) ?? []
                let aTracks = Self.parseAudioTracks(rawA, sourcePrefix: "Player")

                let rawQ = (dict["qualityLevels"] as? [[String: Any]]) ?? []
                let qLevels = rawQ.compactMap { row -> InPlayerQualityLevel? in
                    guard let id = row["id"] as? Int else { return nil }
                    let label = (row["label"] as? String) ?? "Quality"
                    let selected = (row["isSelected"] as? Bool) ?? false
                    return InPlayerQualityLevel(id: id, label: label, isSelected: selected)
                }

                let snap = PlayerMediaStateSnapshot(
                    currentTime: ct.isFinite ? ct : 0,
                    duration: dur.isFinite ? dur : 0,
                    isPlaying: playing,
                    isMuted: muted,
                    volume: vol.isFinite ? vol : 1,
                    playbackRate: rate.isFinite ? rate : 1,
                    hasVideoElement: true,
                    textTracks: tTracks,
                    audioTracks: aTracks,
                    qualityLevels: qLevels,
                    introWindow: nil,
                    serverAutoplay: nil
                )
                Task { @MainActor in self.onEvent(.mediaSnapshot(snap)) }
                return
            }

            if let bridgeMsg = PlayerBridgeMessage(payload: dict) {
                forwardLegacy(bridgeMsg)
            }
        }

        private static func parseAudioTracks(_ rawA: [[String: Any]], sourcePrefix: String) -> [InPlayerAudioTrack] {
            rawA.compactMap { row -> InPlayerAudioTrack? in
                guard let idx = row["id"] as? Int else { return nil }
                let label = (row["label"] as? String) ?? ""
                let lang = (row["language"] as? String) ?? ""
                let codec = row["codec"] as? String
                let channels = row["channels"] as? String
                let isDef = (row["isDefault"] as? Bool) ?? false
                let enabled = (row["isEnabled"] as? Bool) ?? false
                let srcTypeStr = (row["sourceType"] as? String) ?? ""
                let selectable = (row["selectable"] as? Bool) ?? true

                let trackType: AudioTrackType
                switch srcTypeStr {
                case "hlsManifest": trackType = .hlsManifest
                case "hlsJs": trackType = .hlsJs
                case "videoJs": trackType = .videoJs
                case "plyr": trackType = .plyr
                case "jwPlayer": trackType = .jwPlayer
                case "html5": trackType = .html5
                default: trackType = .unknown
                }

                let resolved = SubtitleLanguageResolver.resolveFromMetadata(serverCode: lang, sourceLabel: label)
                let langName = resolved.isKnown ? resolved.name : "Unknown Language"
                return InPlayerAudioTrack(
                    trackId: "\(sourcePrefix)_\(idx)_\(lang.lowercased())",
                    nativeIndex: idx,
                    languageCode: resolved.isKnown ? resolved.code : lang,
                    languageName: langName,
                    displayName: resolved.isKnown ? resolved.name : label,
                    trackType: trackType,
                    codec: (codec?.isEmpty == false) ? codec : nil,
                    channelLayout: (channels?.isEmpty == false) ? channels : nil,
                    isDefault: isDef,
                    isSelected: enabled,
                    sourceIdentifier: sourcePrefix,
                    availability: selectable ? .selectable : .readOnly
                )
            }
        }

        private func forwardLegacy(_ bridgeMsg: PlayerBridgeMessage) {
            Task { @MainActor in
                switch bridgeMsg {
                case .userInteraction:
                    self.onEvent(.userInteraction)
                case .sourceUnavailable:
                    self.onEvent(.sourceUnavailable)
                case .progress(let ev):
                    self.onEvent(.progress(ev))
                }
            }
        }

        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            Task { @MainActor in
                onLoadingChanged(true)
                onError(nil)
            }
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            Task { @MainActor in
                onLoadingChanged(false)
            }
        }

        func webViewWebContentProcessDidTerminate(_ webView: WKWebView) {
            Task { @MainActor in
                SingularityDiagnostics.shared.record(category: "PlayerWebView", message: "WebContent process terminated; requesting safe recovery.")
                onEvent(.webContentProcessTerminated)
            }
        }

        func webView(
            _ webView: WKWebView,
            decidePolicyFor navigationAction: WKNavigationAction,
            decisionHandler: @escaping (WKNavigationActionPolicy) -> Void
        ) {
            guard let targetFrame = navigationAction.targetFrame else {
                decisionHandler(.cancel)
                return
            }

            if targetFrame.isMainFrame,
               let host = navigationAction.request.url?.host,
               let allowedBrandLabel,
               Self.brandLabel(of: host) != allowedBrandLabel {
                decisionHandler(.cancel)
                return
            }

            decisionHandler(.allow)
        }

        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            handleLoadFailure(error, isLoading: webView.isLoading)
        }

        func webView(_ webView: WKWebView, didFailProvisionalNavigation navigation: WKNavigation!, withError error: Error) {
            handleLoadFailure(error, isLoading: webView.isLoading)
        }

        func webView(
            _ webView: WKWebView,
            createWebViewWith configuration: WKWebViewConfiguration,
            for navigationAction: WKNavigationAction,
            windowFeatures: WKWindowFeatures
        ) -> WKWebView? {
            return nil
        }

        private func handleLoadFailure(_ error: Error, isLoading: Bool) {
            let nsErr = error as NSError
            if (nsErr.domain == NSURLErrorDomain && nsErr.code == NSURLErrorCancelled)
                || (nsErr.domain == "WebKitErrorDomain" && nsErr.code == 102) {
                Task { @MainActor in onLoadingChanged(isLoading) }
                return
            }
            Task { @MainActor in
                SingularityDiagnostics.shared.record(category: "PlayerWebView", message: "Load failed: \(error.localizedDescription)")
                onLoadingChanged(false)
                onError(error.localizedDescription)
            }
        }

        private static func brandLabel(of host: String?) -> String? {
            guard let host else { return nil }
            let labels = host.lowercased().split(separator: ".")
            guard labels.count >= 2 else { return labels.first.map(String.init) }
            return String(labels[labels.count - 2])
        }
    }
}
