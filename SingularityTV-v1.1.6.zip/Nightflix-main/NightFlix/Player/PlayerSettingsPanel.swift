import SwiftUI

struct PlayerSettingsPanel: View {
    let controller: CustomPlayerController
    let accent: Color

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Label("Playback Speed", systemImage: "gauge.with.needle")
                .font(.caption.weight(.bold))
                .foregroundStyle(.white.opacity(0.65))

            HStack(spacing: 8) {
                ForEach([0.75, 1.0, 1.25, 1.5, 2.0], id: \.self) { rate in
                    let selected = abs(controller.state.playbackRate - rate) < 0.01
                    Button {
                        controller.setPlaybackRate(rate)
                    } label: {
                        Text(String(format: "%.2gx", rate))
                            .font(.caption.weight(.bold).monospacedDigit())
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 8)
                            .background(selected ? accent : Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 8))
                    }
                    .buttonStyle(.plain)
                }
            }

            Divider().background(Color.white.opacity(0.1))

            Label("Display & Automation", systemImage: "slider.horizontal.3")
                .font(.caption.weight(.bold))
                .foregroundStyle(.white.opacity(0.65))

            Toggle(isOn: Binding(
                get: { controller.state.isVideoFill },
                set: { newVal in
                    controller.state.isVideoFill = newVal
                    controller.bridge.setVideoFillMode(fill: newVal)
                    controller.savePlayerPreferences()
                }
            )) {
                Label {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Fill Screen (Zoom)")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(.white)
                        Text("Switch between Fit and edge-to-edge Fill")
                            .font(.caption)
                            .foregroundStyle(.white.opacity(0.6))
                    }
                } icon: {
                    Image(systemName: "arrow.up.left.and.arrow.down.right")
                        .foregroundStyle(accent)
                }
            }
            .tint(accent)

            if controller.initialItem.type == .tv {
                Toggle(isOn: Binding(
                    get: { controller.state.autoplayNextEnabled },
                    set: {
                        controller.state.autoplayNextEnabled = $0
                        controller.savePlayerPreferences()
                    }
                )) {
                    Label {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Autoplay Next Episode")
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(.white)
                            Text("Show countdown and advance automatically")
                                .font(.caption)
                                .foregroundStyle(.white.opacity(0.6))
                        }
                    } icon: {
                        Image(systemName: "forward.end.fill")
                            .foregroundStyle(accent)
                    }
                }
                .tint(accent)

                Toggle(isOn: Binding(
                    get: { controller.state.skipIntroEnabled },
                    set: {
                        controller.state.skipIntroEnabled = $0
                        controller.savePlayerPreferences()
                    }
                )) {
                    Label {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Skip Intro Button")
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(.white)
                            Text("Show Skip Intro when provided by the source")
                                .font(.caption)
                                .foregroundStyle(.white.opacity(0.6))
                        }
                    } icon: {
                        Image(systemName: "forward.frame.fill")
                            .foregroundStyle(accent)
                    }
                }
                .tint(accent)
            }

            if !controller.state.qualityLevels.isEmpty {
                Divider().background(Color.white.opacity(0.1))

                Label("Stream Quality", systemImage: "sparkles.tv")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.white.opacity(0.65))

                ForEach(controller.state.qualityLevels) { lvl in
                    Button {
                        controller.bridge.selectQualityLevel(index: lvl.id, label: lvl.label)
                        controller.state.activePanel = .none
                    } label: {
                        PlayerPanelRow(title: lvl.label, subtitle: nil, isSelected: lvl.isSelected, accent: accent)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}
