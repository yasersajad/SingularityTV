import SwiftUI

struct PlayerSettingsPanel: View {
    let controller: CustomPlayerController
    let accent: Color

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Playback Speed")
                .font(.caption.weight(.bold))
                .foregroundStyle(.white.opacity(0.6))

            HStack(spacing: 8) {
                ForEach([0.75, 1.0, 1.25, 1.5, 2.0], id: \.self) { rate in
                    let selected = abs(controller.state.playbackRate - rate) < 0.01
                    Button {
                        controller.setPlaybackRate(rate)
                    } label: {
                        Text(String(format: "%.2gx", rate))
                            .font(.caption.weight(.bold).monospacedDigit())
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity)
                            .padding(.vertical, 8)
                            .background(selected ? accent : Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 8))
                    }
                    .buttonStyle(.plain)
                }
            }

            Toggle(isOn: Binding(
                get: { controller.state.isVideoFill },
                set: { newVal in
                    controller.state.isVideoFill = newVal
                    controller.bridge.setVideoFillMode(fill: newVal)
                }
            )) {
                VStack(alignment: .leading, spacing: 2) {
                    Text("Fill Screen (Zoom)")
                        .font(.subheadline.weight(.semibold))
                        .foregroundStyle(.white)
                    Text("Switch between Fit and edge-to-edge Fill")
                        .font(.caption)
                        .foregroundStyle(.white.opacity(0.6))
                }
            }
            .tint(accent)

            if controller.initialItem.type == .tv {
                Toggle(isOn: Binding(
                    get: { controller.state.autoplayNextEnabled },
                    set: { controller.state.autoplayNextEnabled = $0 }
                )) {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Autoplay Next Episode")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(.white)
                        Text("Show countdown and advance automatically")
                            .font(.caption)
                            .foregroundStyle(.white.opacity(0.6))
                    }
                }
                .tint(accent)
            }

            if !controller.state.qualityLevels.isEmpty {
                Text("Stream Quality")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.white.opacity(0.6))

                ForEach(controller.state.qualityLevels) { lvl in
                    Button {
                        controller.bridge.selectQualityLevel(index: lvl.id)
                        controller.state.activePanel = .none
                    } label: {
                        PlayerPanelRow(title: lvl.label, subtitle: nil, isSelected: lvl.isSelected, accent: accent)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}
