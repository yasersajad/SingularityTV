import SwiftUI

struct PlayerSettingsPanel: View {
    let controller: CustomPlayerController
    let accent: Color

    private let speeds: [Double] = [0.5, 0.75, 1.0, 1.25, 1.5, 1.75, 2.0]
    private let autoHideOptions: [Double] = [3.0, 4.0, 6.0, 8.0]

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            if controller.state.capabilities.supportsPlaybackSpeed {
                Label("Playback Speed", systemImage: PlayerIcon.speed)
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.white.opacity(0.65))

                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(speeds, id: \.self) { rate in
                            let selected = abs(controller.state.playbackRate - rate) < 0.01
                            Button {
                                controller.setPlaybackRate(rate)
                            } label: {
                                Text(String(format: "%.2gx", rate))
                                    .font(.caption.weight(.bold).monospacedDigit())
                                    .foregroundStyle(.white)
                                    .padding(.horizontal, 12)
                                    .padding(.vertical, 8)
                                    .background(selected ? accent : Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 8))
                            }
                            .buttonStyle(.plain)
                        }
                    }
                }

                Divider().background(Color.white.opacity(0.1))
            }

            Label("Controls & Gestures", systemImage: "hand.draw")
                .font(.caption.weight(.bold))
                .foregroundStyle(.white.opacity(0.65))

            Toggle(isOn: Binding(
                get: { controller.state.gesturesEnabled },
                set: {
                    controller.state.gesturesEnabled = $0
                    controller.savePlayerPreferences()
                }
            )) {
                Label {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Gesture Controls")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(.white)
                        Text("Scrubbing, Brightness, Volume, Hold-to-2x & Hold-to-Seek")
                            .font(.caption)
                            .foregroundStyle(.white.opacity(0.6))
                    }
                } icon: {
                    Image(systemName: "hand.tap")
                        .foregroundStyle(accent)
                }
            }
            .tint(accent)

            Toggle(isOn: Binding(
                get: { controller.state.hapticsEnabled },
                set: {
                    controller.state.hapticsEnabled = $0
                    controller.savePlayerPreferences()
                }
            )) {
                Label {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Haptic Feedback")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(.white)
                        Text("Tactile feedback on gestures and controls")
                            .font(.caption)
                            .foregroundStyle(.white.opacity(0.6))
                    }
                } icon: {
                    Image(systemName: "iphone.radiowaves.left.and.right")
                        .foregroundStyle(accent)
                }
            }
            .tint(accent)

            VStack(alignment: .leading, spacing: 8) {
                Label("Auto-Hide Controls Delay", systemImage: "timer")
                    .font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.85))
                HStack(spacing: 8) {
                    ForEach(autoHideOptions, id: \.self) { sec in
                        let selected = abs(controller.state.visibility.autoHideDuration - sec) < 0.1
                        Button {
                            controller.state.visibility.autoHideDuration = sec
                            controller.savePlayerPreferences()
                        } label: {
                            Text("\(Int(sec))s")
                                .font(.caption.weight(.bold).monospacedDigit())
                                .foregroundStyle(.white)
                                .frame(maxWidth: .infinity)
                                .padding(.vertical, 7)
                                .background(selected ? accent : Color.white.opacity(0.08), in: RoundedRectangle(cornerRadius: 8))
                        }
                        .buttonStyle(.plain)
                    }
                }
            }

            Divider().background(Color.white.opacity(0.1))

            Label("Display & Automation", systemImage: "slider.horizontal.3")
                .font(.caption.weight(.bold))
                .foregroundStyle(.white.opacity(0.65))

            Toggle(isOn: Binding(
                get: { controller.state.isVideoFill },
                set: { newVal in
                    controller.state.isVideoFill = newVal
                    controller.bridge.setVideoFillMode(fill: newVal)
                    controller.savePlayerPreferences()
                }
            )) {
                Label {
                    VStack(alignment: .leading, spacing: 2) {
                        Text("Fill Screen (Zoom)")
                            .font(.subheadline.weight(.semibold))
                            .foregroundStyle(.white)
                        Text("Switch between Fit and edge-to-edge Fill")
                            .font(.caption)
                            .foregroundStyle(.white.opacity(0.6))
                    }
                } icon: {
                    Image(systemName: PlayerIcon.fillScreen)
                        .foregroundStyle(accent)
                }
            }
            .tint(accent)

            if controller.initialItem.type == .tv {
                Toggle(isOn: Binding(
                    get: { controller.state.autoplayNextEnabled },
                    set: {
                        controller.state.autoplayNextEnabled = $0
                        controller.savePlayerPreferences()
                    }
                )) {
                    Label {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Autoplay Next Episode")
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(.white)
                            Text("Show countdown and advance automatically")
                                .font(.caption)
                                .foregroundStyle(.white.opacity(0.6))
                        }
                    } icon: {
                        Image(systemName: PlayerIcon.nextEpisode)
                            .foregroundStyle(accent)
                    }
                }
                .tint(accent)

                Toggle(isOn: Binding(
                    get: { controller.state.skipIntroEnabled },
                    set: {
                        controller.state.skipIntroEnabled = $0
                        controller.savePlayerPreferences()
                    }
                )) {
                    Label {
                        VStack(alignment: .leading, spacing: 2) {
                            Text("Skip Intro Button")
                                .font(.subheadline.weight(.semibold))
                                .foregroundStyle(.white)
                            Text("Show Skip Intro when provided by the source")
                                .font(.caption)
                                .foregroundStyle(.white.opacity(0.6))
                        }
                    } icon: {
                        Image(systemName: PlayerIcon.skipIntro)
                            .foregroundStyle(accent)
                    }
                }
                .tint(accent)
            }

            if !controller.state.qualityLevels.isEmpty {
                Divider().background(Color.white.opacity(0.1))

                Label("Stream Quality", systemImage: "sparkles.tv")
                    .font(.caption.weight(.bold))
                    .foregroundStyle(.white.opacity(0.65))

                ForEach(controller.state.qualityLevels) { lvl in
                    Button {
                        controller.bridge.selectQualityLevel(index: lvl.id, label: lvl.label)
                        controller.closePanel()
                    } label: {
                        PlayerPanelRow(title: lvl.label, subtitle: nil, isSelected: lvl.isSelected, accent: accent)
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}
