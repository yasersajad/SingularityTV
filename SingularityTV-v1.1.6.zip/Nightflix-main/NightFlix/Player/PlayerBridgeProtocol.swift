import Foundation

enum PlayerLifecycleState: String, Equatable, Sendable {
    case idle
    case preparing
    case loading
    case ready
    case playing
    case paused
    case switching
    case recovering
    case failed
    case finished
    case disposed
}

struct PlayerCapabilities: Equatable, Sendable {
    var supportsAudioTrackDiscovery = false
    var supportsAudioTrackSelection = false
    var supportsSubtitleTrackDiscovery = false
    var supportsSubtitleTrackSelection = false
    var supportsSiteSubtitleFiles = false
    var supportsInternalServerSelection = false
    var supportsSkipIntro = false
    var supportsAutoplayNextEpisode = false
    var supportsPlaybackSpeed = false
}

struct IntroSkipWindow: Equatable, Sendable {
    let start: Double?
    let end: Double?
    let hasDomButton: Bool
    let source: String

    var isValid: Bool {
        if hasDomButton { return true }
        if let start, let end { return end > start && start >= 0 }
        return false
    }
}

struct ServerAutoplaySignal: Equatable, Sendable {
    let hasNextButton: Bool
    let countdownSeconds: Int?
    let source: String
}

struct InPlayerQualityLevel: Identifiable, Equatable, Sendable {
    let id: Int
    let label: String
    let isSelected: Bool
}

struct PlayerMediaStateSnapshot: Equatable, Sendable {
    let currentTime: Double
    let duration: Double
    let isPlaying: Bool
    let isMuted: Bool
    let volume: Double
    let playbackRate: Double
    let hasVideoElement: Bool
    let textTracks: [InPlayerSubtitleTrack]
    let audioTracks: [InPlayerAudioTrack]
    let qualityLevels: [InPlayerQualityLevel]
    let introWindow: IntroSkipWindow?
    let serverAutoplay: ServerAutoplaySignal?
}

struct DiscoveredSiteSubtitle: Identifiable, Equatable, Sendable {
    var id: String { url }
    let url: String
    let label: String
    let language: String
    let originalFilename: String
    let resolvedLanguageName: String
    let displayTitle: String

    var isLanguageKnown: Bool {
        resolvedLanguageName != "Unknown Language" && !resolvedLanguageName.isEmpty
    }
}

enum PlayerBridgeEvent {
    case progress(PlayerProgressEvent)
    case mediaSnapshot(PlayerMediaStateSnapshot)
    case sourceUnavailable
    case userInteraction
    case discoveredSubtitle(DiscoveredSiteSubtitle)
    case discoveredAudioTracks([InPlayerAudioTrack], source: String)
    case discoveredQualityLevels([InPlayerQualityLevel])
    case discoveredInternalServers([InternalServerOption])
    case discoveredIntroWindow(IntroSkipWindow)
    case discoveredAutoplaySignal(ServerAutoplaySignal)
    case webContentProcessTerminated
}
