import Foundation

struct InPlayerQualityLevel: Identifiable, Equatable, Sendable {
    let id: Int
    let label: String
    let isSelected: Bool
}

struct PlayerMediaStateSnapshot: Equatable, Sendable {
    let currentTime: Double
    let duration: Double
    let isPlaying: Bool
    let isMuted: Bool
    let volume: Double
    let playbackRate: Double
    let hasVideoElement: Bool
    let textTracks: [InPlayerSubtitleTrack]
    let audioTracks: [InPlayerAudioTrack]
    let qualityLevels: [InPlayerQualityLevel]
}

enum PlayerBridgeEvent {
    case progress(PlayerProgressEvent)
    case mediaSnapshot(PlayerMediaStateSnapshot)
    case sourceUnavailable
    case userInteraction
}
