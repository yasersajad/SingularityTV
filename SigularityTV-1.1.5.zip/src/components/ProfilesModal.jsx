import React, { useState, useEffect } from "react";
import { getProfilesList, getActiveProfileId, switchActiveProfile, createProfileOnServer, updateProfileOnServer, deleteProfileOnServer, getAuthUser } from "../utils/supabaseSync";
import { SingularityLogo, CloseIcon } from "./Icons";

const AVATAR_COLORS = ["#E50914", "#E6B86A", "#3B82F6", "#10B981", "#8B5CF6", "#EC4899", "#06B6D4"];

function GeometricAvatar({ name, color, isKids, size = 84 }) {
  const initial = (name || "S").trim().charAt(0).toUpperCase();
  return React.createElement("div", {
    className: "sg-profile-avatar-box",
    style: {
      width: size,
      height: size,
      borderRadius: Math.round(size * 0.28),
      background: `linear-gradient(145deg, ${color} 0%, #090B12 145%)`,
      boxShadow: `0 14px 32px ${color}44, inset 0 1px 1px rgba(255,255,255,0.32)`
    }
  },
    React.createElement("svg", { viewBox: "0 0 100 100", style: { position: "absolute", inset: 0, width: "100%", height: "100%", opacity: 0.24, pointerEvents: "none" } },
      React.createElement("circle", { cx: "50", cy: "50", r: "38", stroke: "#fff", strokeWidth: "1.5", fill: "none" }),
      React.createElement("ellipse", { cx: "50", cy: "50", rx: "42", ry: "16", transform: "rotate(-28 50 50)", stroke: "#fff", strokeWidth: "1.5", fill: "none" })
    ),
    React.createElement("span", { style: { position: "relative", fontSize: Math.round(size * 0.42), fontWeight: 800, color: "#F5F5F7" } }, initial),
    isKids && React.createElement("span", { className: "sg-kids-pill" }, "KIDS")
  );
}

export default function ProfilesModal({ onClose, onProfileSwitched }) {
  const [profiles, setProfiles] = useState(() => getProfilesList());
  const [activeId, setActiveId] = useState(() => getActiveProfileId());
  const [manageMode, setManageMode] = useState(false);
  const [editing, setEditing] = useState(null);
  const [launching, setLaunching] = useState(null);
  const [nameInput, setNameInput] = useState("");
  const [colorInput, setColorInput] = useState(AVATAR_COLORS[0]);
  const [kidsInput, setKidsInput] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  useEffect(() => {
    const sync = () => { setProfiles(getProfilesList()); setActiveId(getActiveProfileId()); };
    window.addEventListener("singularity:profile-changed", sync);
    window.addEventListener("singularity:live-sync-updated", sync);
    return () => {
      window.removeEventListener("singularity:profile-changed", sync);
      window.removeEventListener("singularity:live-sync-updated", sync);
    };
  }, []);

  const authUser = getAuthUser();
  const openCreate = () => { if (profiles.length < 5) { setErr(""); setEditing({ mode: "create" }); setNameInput(""); setColorInput(AVATAR_COLORS[profiles.length % AVATAR_COLORS.length]); setKidsInput(false); } };
  const openEdit = p => { setErr(""); setEditing({ mode: "edit", profile: p }); setNameInput(p.name || ""); setColorInput(p.avatarColor || AVATAR_COLORS[0]); setKidsInput(!!p.isKids); };

  useEffect(() => {
    if (!launching) return;
    const hardStop = setTimeout(() => {
      setLaunching(null);
      setBusy(false);
      onClose?.();
    }, 1700);
    return () => clearTimeout(hardStop);
  }, [launching, onClose]);

  const handleSelect = async p => {
    if (manageMode) { openEdit(p); return; }
    if (busy || launching) return;
    setBusy(true);
    setLaunching(p);
    const minAnim = new Promise(res => setTimeout(res, 680));
    const maxWait = new Promise(res => setTimeout(res, 1300));
    try {
      if (p.id !== activeId) {
        await Promise.race([Promise.all([switchActiveProfile(p.id), minAnim]), maxWait]);
        setActiveId(p.id);
        onProfileSwitched?.(p);
      } else {
        await minAnim;
      }
    } catch {} finally {
      setLaunching(null);
      setBusy(false);
      onClose?.();
    }
  };

  const handleSaveEdit = async e => {
    e?.preventDefault();
    const clean = nameInput.trim();
    if (!clean) { setErr("Enter a profile name"); return; }
    setBusy(true); setErr("");
    try {
      const res = editing.mode === "create"
        ? await createProfileOnServer({ name: clean, avatarColor: colorInput, isKids: kidsInput })
        : await updateProfileOnServer(editing.profile.id, { name: clean, avatarColor: colorInput, isKids: kidsInput });
      if (!res.ok) { setErr(res.error || "Could not save profile"); return; }
      setProfiles(getProfilesList()); setEditing(null);
    } finally { setBusy(false); }
  };

  const handleDelete = async () => {
    if (!editing?.profile || editing.profile.isPrimary) return;
    setBusy(true); setErr("");
    try {
      const res = await deleteProfileOnServer(editing.profile.id);
      if (!res.ok) { setErr(res.error || "Could not delete profile"); return; }
      setProfiles(getProfilesList()); setActiveId(getActiveProfileId()); onProfileSwitched?.(); setEditing(null);
    } finally { setBusy(false); }
  };

  if (launching) {
    const col = launching.avatarColor || "#E6B86A";
    return React.createElement("div", {
      className: "sg4-profile-launch",
      style: { "--launch-color": col }
    },
      React.createElement("div", { className: "sg4-profile-launch-ring" }),
      React.createElement("div", { className: "sg4-profile-launch-avatar" },
        React.createElement(GeometricAvatar, { name: launching.name, color: col, isKids: launching.isKids, size: 112 })
      ),
      React.createElement("div", { className: "sg4-profile-launch-name" }, launching.name),
      React.createElement("div", { className: "sg4-profile-launch-sub" }, "ENTERING YOUR UNIVERSE"),
      React.createElement("div", { className: "sg4-profile-launch-bar" },
        React.createElement("div", { className: "sg4-profile-launch-fill" })
      )
    );
  }

  return React.createElement("div", { className: "sg-profiles-overlay", onClick: () => !busy && onClose?.() },
    React.createElement("div", { className: "sg-profiles-shell", onClick: e => e.stopPropagation() },
      React.createElement("div", { className: "sg-profiles-header" },
        React.createElement(SingularityLogo, { variant: "horizontal", size: 32 }),
        React.createElement("button", { className: "sg-glass-icon-btn", onClick: () => !busy && onClose?.(), "aria-label": "Close Profiles" }, React.createElement(CloseIcon))
      ),
      editing ? React.createElement("form", { className: "sg-profile-editor-card", onSubmit: handleSaveEdit },
        React.createElement("h2", { className: "sg-profiles-title" }, editing.mode === "create" ? "Create Profile" : "Customize Profile"),
        React.createElement("div", { style: { display: "flex", justifyContent: "center", margin: "18px 0" } },
          React.createElement(GeometricAvatar, { name: nameInput || "S", color: colorInput, isKids: kidsInput, size: 92 })
        ),
        React.createElement("input", { className: "sg-glass-input", type: "text", maxLength: 24, placeholder: "Profile Name", value: nameInput, onChange: e => setNameInput(e.target.value), autoFocus: true }),
        React.createElement("div", { className: "sg-color-swatches" },
          AVATAR_COLORS.map(c => React.createElement("button", { key: c, type: "button", className: `sg-color-swatch${colorInput === c ? " active" : ""}`, style: { background: c }, onClick: () => setColorInput(c) }))
        ),
        React.createElement("label", { className: "sg-kids-toggle-row" },
          React.createElement("input", { type: "checkbox", checked: kidsInput, onChange: e => setKidsInput(e.target.checked) }),
          React.createElement("span", null, "Kids Experience (Age-filtered catalog)")
        ),
        err && React.createElement("div", { className: "sg-error-banner" }, err),
        React.createElement("div", { className: "sg-editor-actions" },
          React.createElement("button", { type: "submit", className: "btn btn-primary", disabled: busy }, busy ? "Saving..." : "Save Profile"),
          React.createElement("button", { type: "button", className: "btn btn-secondary", disabled: busy, onClick: () => setEditing(null) }, "Cancel"),
          editing.mode === "edit" && !editing.profile.isPrimary && React.createElement("button", { type: "button", className: "btn btn-ghost", style: { color: "#ff4d6d" }, disabled: busy, onClick: handleDelete }, "Delete")
        )
      ) : React.createElement(React.Fragment, null,
        React.createElement("div", { className: "sg-profiles-heading-wrap" },
          React.createElement("h1", { className: "sg-profiles-title" }, manageMode ? "Manage Profiles" : "Who's Watching?"),
          authUser?.email && React.createElement("p", { className: "sg-profiles-subtitle" }, `Synced workspace · ${authUser.email}`)
        ),
        React.createElement("div", { className: "sg-profiles-grid" },
          profiles.map((p, idx) => {
            const isCurrent = p.id === activeId;
            return React.createElement("button", {
              key: p.id, className: `sg-profile-card card${isCurrent ? " active" : ""}`, style: { animationDelay: `${idx * 55}ms` },
              disabled: busy, onClick: () => handleSelect(p)
            },
              React.createElement(GeometricAvatar, { name: p.name, color: p.avatarColor || AVATAR_COLORS[idx % AVATAR_COLORS.length], isKids: p.isKids, size: 88 }),
              React.createElement("span", { className: "sg-profile-name" }, p.name),
              isCurrent && !manageMode && React.createElement("span", { className: "sg-profile-active-tag" }, "ACTIVE"),
              manageMode && React.createElement("span", { className: "sg-profile-edit-tag" }, "EDIT")
            );
          }),
          profiles.length < 5 && React.createElement("button", { className: "sg-profile-card sg-profile-card--add card", disabled: busy, onClick: openCreate },
            React.createElement("div", { className: "sg-add-profile-circle" }, "+"),
            React.createElement("span", { className: "sg-profile-name" }, "Add Profile")
          )
        ),
        React.createElement("div", { className: "sg-profiles-footer" },
          React.createElement("button", { className: "btn btn-secondary", onClick: () => setManageMode(m => !m) }, manageMode ? "Done" : "Manage Profiles")
        )
      )
    )
  );
}
