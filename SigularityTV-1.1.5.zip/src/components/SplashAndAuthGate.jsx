import React, { useState, useEffect } from "react";
import { SingularityLogo } from "./Icons";
import {
  signInWithEmail,
  signUpWithEmail,
  verifyEmailOtp,
  resendSignupOtp,
  requestPasswordReset,
  completePasswordReset
} from "../utils/supabaseSync";

const SPLASH_KEYFRAMES = `
@keyframes splashFadeUp { 0% { opacity: 0; transform: translateY(14px); } 100% { opacity: 1; transform: translateY(0); } }
@keyframes splashOrbFloat { 0%, 100% { transform: translate(0, 0) scale(1); } 50% { transform: translate(12px, -10px) scale(1.06); } }
`;

const SINGULARITY_EVENT_CSS = `
@keyframes seCoreIgnite {
  0% { opacity: 0; transform: scale(0.1); }
  35% { opacity: 1; transform: scale(1.25); }
  100% { opacity: 1; transform: scale(1); }
}
@keyframes seOrbitDraw {
  0% { stroke-dashoffset: 320; opacity: 0; }
  25% { opacity: 1; }
  100% { stroke-dashoffset: 0; opacity: 1; }
}
@keyframes seEmblemRotate {
  0% { transform: scale(0.86) rotate(-18deg); opacity: 0.2; }
  55% { transform: scale(1.03) rotate(4deg); opacity: 1; }
  100% { transform: scale(1) rotate(0deg); opacity: 1; }
}
@keyframes seLightPulse {
  0% { opacity: 0; transform: scale(0.2); }
  45% { opacity: 0.42; transform: scale(1.1); }
  100% { opacity: 0; transform: scale(2.1); }
}
@keyframes seWordmarkReveal {
  0% { opacity: 0; transform: translateY(10px); letter-spacing: 0.36em; }
  100% { opacity: 1; transform: translateY(0); letter-spacing: 0.22em; }
}
@keyframes seSubReveal {
  0% { opacity: 0; transform: translateY(6px); }
  100% { opacity: 0.85; transform: translateY(0); }
}
`;

export function LaunchSplash({ onComplete }) {
  const [fading, setFading] = useState(false);

  useEffect(() => {
    const reduced = typeof window !== "undefined" && window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const t1 = setTimeout(() => setFading(true), reduced ? 420 : 1750);
    const t2 = setTimeout(() => onComplete?.(), reduced ? 620 : 2180);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, [onComplete]);

  const skipIntro = () => {
    setFading(true);
    setTimeout(() => onComplete?.(), 180);
  };

  return React.createElement("div", {
    onClick: skipIntro,
    role: "button",
    tabIndex: 0,
    onKeyDown: e => { if (e.key === "Enter" || e.key === " ") skipIntro(); },
    style: {
      position: "fixed",
      inset: 0,
      zIndex: 99999,
      display: "flex",
      flexDirection: "column",
      alignItems: "center",
      justifyContent: "center",
      background: "#040507",
      opacity: fading ? 0 : 1,
      transform: fading ? "scale(1.03)" : "scale(1)",
      transition: "opacity 420ms cubic-bezier(0.22, 1, 0.36, 1), transform 420ms cubic-bezier(0.22, 1, 0.36, 1)",
      cursor: "pointer",
      overflow: "hidden"
    }
  },
    React.createElement("style", null, SINGULARITY_EVENT_CSS),
    React.createElement("div", {
      style: {
        position: "absolute",
        width: 340,
        height: 340,
        borderRadius: "50%",
        background: "radial-gradient(circle, rgba(230, 184, 106, 0.32) 0%, rgba(110, 145, 255, 0.14) 45%, transparent 72%)",
        animation: "seLightPulse 1500ms cubic-bezier(0.16, 1, 0.3, 1) 520ms both",
        pointerEvents: "none"
      }
    }),
    React.createElement("div", {
      style: {
        position: "relative",
        width: 112,
        height: 112,
        animation: "seEmblemRotate 1150ms cubic-bezier(0.22, 1, 0.36, 1) 120ms both"
      }
    },
      React.createElement("svg", { viewBox: "0 0 120 120", width: "112", height: "112", fill: "none" },
        React.createElement("circle", {
          cx: "60", cy: "60", r: "46",
          stroke: "#E8ECF5", strokeWidth: "1.8", strokeDasharray: "320", strokeLinecap: "round",
          style: { animation: "seOrbitDraw 900ms cubic-bezier(0.22, 1, 0.36, 1) 180ms both" }
        }),
        React.createElement("circle", {
          cx: "60", cy: "60", r: "32",
          stroke: "#E6B86A", strokeWidth: "2.4", strokeDasharray: "220", strokeLinecap: "round",
          transform: "rotate(140 60 60)",
          style: { animation: "seOrbitDraw 850ms cubic-bezier(0.22, 1, 0.36, 1) 300ms both" }
        }),
        React.createElement("ellipse", {
          cx: "60", cy: "60", rx: "48", ry: "15",
          transform: "rotate(-28 60 60)",
          stroke: "#F5E6C8", strokeWidth: "3.2", strokeDasharray: "320", strokeLinecap: "round",
          style: { animation: "seOrbitDraw 950ms cubic-bezier(0.22, 1, 0.36, 1) 380ms both" }
        }),
        React.createElement("circle", {
          cx: "60", cy: "60", r: "6.5", fill: "#FFFFFF",
          style: { transformOrigin: "60px 60px", animation: "seCoreIgnite 650ms cubic-bezier(0.22, 1, 0.36, 1) 60ms both" }
        })
      )
    ),
    React.createElement("div", {
      style: {
        marginTop: 26,
        fontFamily: "var(--font-display)",
        fontSize: 32,
        fontWeight: 700,
        color: "#F5F5F7",
        letterSpacing: "0.22em",
        animation: "seWordmarkReveal 720ms cubic-bezier(0.22, 1, 0.36, 1) 680ms both"
      }
    }, "SINGULARITY"),
    React.createElement("div", {
      style: {
        marginTop: 6,
        fontSize: 10,
        fontWeight: 700,
        letterSpacing: "0.38em",
        color: "#E6B86A",
        animation: "seSubReveal 620ms ease 860ms both"
      }
    }, "WEBOS · CINEMATIC INTELLIGENCE")
  );
}

export function AuthGate({ onAuthenticated }) {
  const [view, setView] = useState("signin");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [otp, setOtp] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [otpSecondsLeft, setOtpSecondsLeft] = useState(600);

  useEffect(() => {
    if (view !== "verify_signup" && view !== "reset_verify") return;
    const iv = setInterval(() => {
      setOtpSecondsLeft(prev => (prev > 0 ? prev - 1 : 0));
    }, 1000);
    return () => clearInterval(iv);
  }, [view]);

  const switchView = next => {
    setView(next);
    setError("");
    setInfo("");
  };

  const handleSignIn = async e => {
    e.preventDefault();
    setError("");
    setInfo("");
    setBusy(true);
    try {
      const res = await signInWithEmail(email, password);
      onAuthenticated?.(res);
    } catch (err) {
      if (err.code === "EMAIL_NOT_CONFIRMED") {
        try {
          await resendSignupOtp(email);
        } catch {}
        setOtp("");
        setOtpSecondsLeft(600);
        setView("verify_signup");
        setInfo("Your email is not verified yet. We sent a fresh 6-digit code to your email.");
      } else {
        setError(err.message || "Sign in failed.");
      }
    } finally {
      setBusy(false);
    }
  };

  const handleSignUp = async e => {
    e.preventDefault();
    setError("");
    setInfo("");
    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }
    setBusy(true);
    try {
      const res = await signUpWithEmail(email, password, name);
      if (res.needsVerification) {
        setOtp("");
        setOtpSecondsLeft(600);
        setView("verify_signup");
        setInfo("A 6-digit verification code has been sent to your email.");
      } else {
        onAuthenticated?.(res);
      }
    } catch (err) {
      setError(err.message || "Could not create account.");
    } finally {
      setBusy(false);
    }
  };

  const handleVerifySignup = async e => {
    e.preventDefault();
    setError("");
    setInfo("");
    if (otpSecondsLeft <= 0) {
      setError("Verification code expired. Please request a new code.");
      return;
    }
    setBusy(true);
    try {
      const res = await verifyEmailOtp(email, otp, "signup");
      onAuthenticated?.(res);
    } catch (err) {
      setError(err.message || "Verification failed.");
    } finally {
      setBusy(false);
    }
  };

  const handleResendSignup = async () => {
    setError("");
    setInfo("");
    setBusy(true);
    try {
      await resendSignupOtp(email);
      setOtp("");
      setOtpSecondsLeft(600);
      setInfo("A new 6-digit code was sent. Valid for 10 minutes.");
    } catch (err) {
      setError(err.message || "Could not resend code.");
    } finally {
      setBusy(false);
    }
  };

  const handleRequestReset = async e => {
    e.preventDefault();
    setError("");
    setInfo("");
    setBusy(true);
    try {
      await requestPasswordReset(email);
      setOtp("");
      setPassword("");
      setConfirmPassword("");
      setOtpSecondsLeft(600);
      setView("reset_verify");
      setInfo("A 6-digit password reset code was sent to your email.");
    } catch (err) {
      setError(err.message || "Could not send reset code.");
    } finally {
      setBusy(false);
    }
  };

  const handleCompleteReset = async e => {
    e.preventDefault();
    setError("");
    setInfo("");
    if (otpSecondsLeft <= 0) {
      setError("Reset code expired. Please request a new code.");
      return;
    }
    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }
    setBusy(true);
    try {
      const res = await completePasswordReset(email, otp, password);
      onAuthenticated?.(res);
    } catch (err) {
      setError(err.message || "Could not reset password.");
    } finally {
      setBusy(false);
    }
  };

  const inputStyle = {
    width: "100%",
    padding: "13px 14px",
    borderRadius: 11,
    border: "1px solid rgba(255,255,255,0.14)",
    background: "rgba(255,255,255,0.06)",
    color: "#ffffff",
    fontSize: 15,
    outline: "none",
    boxSizing: "border-box"
  };

  const labelStyle = {
    display: "block",
    fontSize: 12,
    fontWeight: 600,
    color: "rgba(255,255,255,0.72)",
    marginBottom: 6
  };

  const primaryBtnStyle = {
    width: "100%",
    padding: "13px 18px",
    borderRadius: 11,
    border: "none",
    background: "linear-gradient(135deg, #e50914, #b80710)",
    color: "#ffffff",
    fontSize: 15,
    fontWeight: 700,
    cursor: busy ? "not-allowed" : "pointer",
    opacity: busy ? 0.7 : 1,
    boxShadow: "0 8px 24px rgba(229,9,20,0.32)"
  };

  const linkBtnStyle = {
    background: "none",
    border: "none",
    color: "#ff5a63",
    fontSize: 13,
    fontWeight: 600,
    cursor: "pointer",
    padding: 0
  };

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 9999,
        overflowY: "auto",
        background: "radial-gradient(circle at 50% 15%, #23080b 0%, #0c0c12 52%, #060609 100%)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "max(24px, env(safe-area-inset-top)) 18px max(24px, env(safe-area-inset-bottom))",
        direction: "ltr"
      }}
    >
      <style>{SPLASH_KEYFRAMES}</style>
      <div
        style={{
          width: "100%",
          maxWidth: 410,
          background: "rgba(20, 20, 28, 0.88)",
          backdropFilter: "blur(20px)",
          WebkitBackdropFilter: "blur(20px)",
          border: "1px solid rgba(255,255,255,0.1)",
          borderRadius: 20,
          padding: "28px 24px",
          boxShadow: "0 24px 72px rgba(0,0,0,0.65)",
          animation: "stvFadeUp 0.45s ease both"
        }}
      >
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", marginBottom: 22 }}>
          <div
            style={{
              width: 58,
              height: 58,
              borderRadius: 16,
              background: "rgba(229,9,20,0.14)",
              border: "1px solid rgba(229,9,20,0.38)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              marginBottom: 12
            }}
          >
            <SingularityLogo style={{ width: 34, height: 34 }} />
          </div>
          <div style={{ fontSize: 22, fontWeight: 800, color: "#fff", letterSpacing: "0.03em" }}>
            Singularity<span style={{ color: "#e50914" }}>TV</span>
          </div>
          <div style={{ fontSize: 13, color: "rgba(255,255,255,0.6)", marginTop: 4, textAlign: "center" }}>
            {view === "signin" && "Sign in to sync your watch progress & library"}
            {view === "signup" && "Create your account with email verification"}
            {view === "verify_signup" && "Enter the 6-digit code sent to your email"}
            {view === "forgot" && "Enter your email to receive a 6-digit reset code"}
            {view === "reset_verify" && "Verify your code and choose a new password"}
          </div>
        </div>

        {(view === "signin" || view === "signup") && (
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr 1fr",
              gap: 6,
              background: "rgba(255,255,255,0.05)",
              padding: 4,
              borderRadius: 12,
              marginBottom: 20
            }}
          >
            <button
              type="button"
              onClick={() => switchView("signin")}
              style={{
                padding: "9px 10px",
                borderRadius: 9,
                border: "none",
                background: view === "signin" ? "rgba(229,9,20,0.9)" : "transparent",
                color: view === "signin" ? "#fff" : "rgba(255,255,255,0.65)",
                fontSize: 13,
                fontWeight: 700,
                cursor: "pointer"
              }}
            >
              Sign In
            </button>
            <button
              type="button"
              onClick={() => switchView("signup")}
              style={{
                padding: "9px 10px",
                borderRadius: 9,
                border: "none",
                background: view === "signup" ? "rgba(229,9,20,0.9)" : "transparent",
                color: view === "signup" ? "#fff" : "rgba(255,255,255,0.65)",
                fontSize: 13,
                fontWeight: 700,
                cursor: "pointer"
              }}
            >
              Sign Up
            </button>
          </div>
        )}

        {error && (
          <div
            style={{
              padding: "10px 12px",
              borderRadius: 10,
              background: "rgba(229,9,20,0.16)",
              border: "1px solid rgba(229,9,20,0.45)",
              color: "#ff8c92",
              fontSize: 13,
              marginBottom: 14,
              lineHeight: 1.45
            }}
          >
            {error}
          </div>
        )}

        {info && (
          <div
            style={{
              padding: "10px 12px",
              borderRadius: 10,
              background: "rgba(72,199,116,0.14)",
              border: "1px solid rgba(72,199,116,0.4)",
              color: "#7be3a2",
              fontSize: 13,
              marginBottom: 14,
              lineHeight: 1.45
            }}
          >
            {info}
          </div>
        )}

        {view === "signin" && (
          <form onSubmit={handleSignIn} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <div>
              <label style={labelStyle}>Email Address</label>
              <input
                type="email"
                required
                autoComplete="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="you@example.com"
                style={inputStyle}
              />
            </div>
            <div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
                <label style={{ ...labelStyle, marginBottom: 0 }}>Password</label>
                <button type="button" onClick={() => switchView("forgot")} style={linkBtnStyle}>
                  Forgot password?
                </button>
              </div>
              <div style={{ position: "relative" }}>
                <input
                  type={showPass ? "text" : "password"}
                  required
                  autoComplete="current-password"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  style={{ ...inputStyle, paddingRight: 44 }}
                />
                <button
                  type="button"
                  onClick={() => setShowPass(p => !p)}
                  aria-label="Toggle password visibility"
                  style={{
                    position: "absolute",
                    right: 10,
                    top: "50%",
                    transform: "translateY(-50%)",
                    background: "none",
                    border: "none",
                    color: "rgba(255,255,255,0.6)",
                    cursor: "pointer",
                    display: "flex",
                    padding: 4
                  }}
                >
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                    {showPass ? (
                      <>
                        <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94" />
                        <path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19" />
                        <line x1="1" y1="1" x2="23" y2="23" />
                      </>
                    ) : (
                      <>
                        <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                        <circle cx="12" cy="12" r="3" />
                      </>
                    )}
                  </svg>
                </button>
              </div>
            </div>
            <button type="submit" disabled={busy} style={{ ...primaryBtnStyle, marginTop: 4 }}>
              {busy ? "Signing In..." : "Sign In"}
            </button>
          </form>
        )}

        {view === "signup" && (
          <form onSubmit={handleSignUp} style={{ display: "flex", flexDirection: "column", gap: 13 }}>
            <div>
              <label style={labelStyle}>Display Name</label>
              <input
                type="text"
                required
                autoComplete="name"
                value={name}
                onChange={e => setName(e.target.value)}
                placeholder="Your name"
                style={inputStyle}
              />
            </div>
            <div>
              <label style={labelStyle}>Email Address</label>
              <input
                type="email"
                required
                autoComplete="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="you@example.com"
                style={inputStyle}
              />
            </div>
            <div>
              <label style={labelStyle}>Password (min. 6 characters)</label>
              <input
                type={showPass ? "text" : "password"}
                required
                minLength={6}
                autoComplete="new-password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="Create a password"
                style={inputStyle}
              />
            </div>
            <div>
              <label style={labelStyle}>Confirm Password</label>
              <input
                type={showPass ? "text" : "password"}
                required
                minLength={6}
                autoComplete="new-password"
                value={confirmPassword}
                onChange={e => setConfirmPassword(e.target.value)}
                placeholder="Repeat your password"
                style={inputStyle}
              />
            </div>
            <button type="submit" disabled={busy} style={{ ...primaryBtnStyle, marginTop: 4 }}>
              {busy ? "Sending 6-Digit Code..." : "Send Verification Code"}
            </button>
          </form>
        )}

        {view === "verify_signup" && (
          <form onSubmit={handleVerifySignup} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <div style={{ textAlign: "center", fontSize: 13, color: "rgba(255,255,255,0.75)" }}>
              Code sent to <strong style={{ color: "#fff" }}>{email}</strong>
            </div>
            <input
              type="text"
              inputMode="numeric"
              autoComplete="one-time-code"
              maxLength={6}
              required
              value={otp}
              onChange={e => setOtp(e.target.value.replace(/\D/g, "").slice(0, 6))}
              placeholder="000000"
              style={{
                ...inputStyle,
                textAlign: "center",
                fontSize: 26,
                fontWeight: 800,
                letterSpacing: "0.35em",
                fontFamily: "monospace",
                padding: "14px 10px"
              }}
            />
            <div
              style={{
                textAlign: "center",
                fontSize: 12,
                color: otpSecondsLeft > 0 ? "rgba(255,255,255,0.62)" : "#ff8c92"
              }}
            >
              {otpSecondsLeft > 0 ? `Code expires in ${formatTimer(otpSecondsLeft)}` : "Code expired. Request a new code below."}
            </div>
            <button type="submit" disabled={busy || otp.length !== 6 || otpSecondsLeft <= 0} style={primaryBtnStyle}>
              {busy ? "Verifying..." : "Verify & Enter App"}
            </button>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 4 }}>
              <button type="button" onClick={() => switchView("signup")} style={{ ...linkBtnStyle, color: "rgba(255,255,255,0.65)" }}>
                Back
              </button>
              <button type="button" disabled={busy} onClick={handleResendSignup} style={linkBtnStyle}>
                Resend Code
              </button>
            </div>
          </form>
        )}

        {view === "forgot" && (
          <form onSubmit={handleRequestReset} style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <div>
              <label style={labelStyle}>Account Email Address</label>
              <input
                type="email"
                required
                autoComplete="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="you@example.com"
                style={inputStyle}
              />
            </div>
            <button type="submit" disabled={busy} style={primaryBtnStyle}>
              {busy ? "Sending Reset Code..." : "Send Reset Code"}
            </button>
            <div style={{ textAlign: "center", marginTop: 4 }}>
              <button type="button" onClick={() => switchView("signin")} style={{ ...linkBtnStyle, color: "rgba(255,255,255,0.65)" }}>
                Back to Sign In
              </button>
            </div>
          </form>
        )}

        {view === "reset_verify" && (
          <form onSubmit={handleCompleteReset} style={{ display: "flex", flexDirection: "column", gap: 13 }}>
            <div style={{ textAlign: "center", fontSize: 13, color: "rgba(255,255,255,0.75)" }}>
              Reset code sent to <strong style={{ color: "#fff" }}>{email}</strong>
            </div>
            <div>
              <label style={labelStyle}>6-Digit Reset Code</label>
              <input
                type="text"
                inputMode="numeric"
                autoComplete="one-time-code"
                maxLength={6}
                required
                value={otp}
                onChange={e => setOtp(e.target.value.replace(/\D/g, "").slice(0, 6))}
                placeholder="000000"
                style={{
                  ...inputStyle,
                  textAlign: "center",
                  fontSize: 22,
                  fontWeight: 800,
                  letterSpacing: "0.3em",
                  fontFamily: "monospace"
                }}
              />
            </div>
            <div
              style={{
                textAlign: "center",
                fontSize: 12,
                color: otpSecondsLeft > 0 ? "rgba(255,255,255,0.62)" : "#ff8c92"
              }}
            >
              {otpSecondsLeft > 0 ? `Code expires in ${formatTimer(otpSecondsLeft)}` : "Code expired. Request a new code below."}
            </div>
            <div>
              <label style={labelStyle}>New Password (min. 6 characters)</label>
              <input
                type="password"
                required
                minLength={6}
                autoComplete="new-password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="Enter new password"
                style={inputStyle}
              />
            </div>
            <div>
              <label style={labelStyle}>Confirm New Password</label>
              <input
                type="password"
                required
                minLength={6}
                autoComplete="new-password"
                value={confirmPassword}
                onChange={e => setConfirmPassword(e.target.value)}
                placeholder="Repeat new password"
                style={inputStyle}
              />
            </div>
            <button type="submit" disabled={busy || otp.length !== 6 || otpSecondsLeft <= 0} style={primaryBtnStyle}>
              {busy ? "Updating Password..." : "Reset Password & Sign In"}
            </button>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginTop: 4 }}>
              <button type="button" onClick={() => switchView("signin")} style={{ ...linkBtnStyle, color: "rgba(255,255,255,0.65)" }}>
                Back to Sign In
              </button>
              <button type="button" disabled={busy} onClick={handleRequestReset} style={linkBtnStyle}>
                Resend Code
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
