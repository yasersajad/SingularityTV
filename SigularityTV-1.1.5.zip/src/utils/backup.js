const PREFIX = "streambert_";
export const PROFILE_DATA_KEYS = ["saved", "savedOrder", "history", "progress", "watched", "_progressTs", "_watchedTs", "_savedTs", "_historyDeletedTs", "_livePlayback"];
export const BACKUP_KEYS = ["saved", "savedOrder", "history", "progress", "watched", "homeRowOrder", "homeRowVisible", "homeViewMode", "startPage", "playerSource", "hianimeDubMode", "introSkipMode", "ageLimit", "ratingCountry", "watchedThreshold", "autoplayNextEnabled", "autoplayNextDuration", "autoplayNextLayout", "subtitleDownload", "subtitleLang", "downloadPath", "downloaderFolder", "invidiousBase", "autoCheckUpdates", "searchHistory", "accentColor", "fontSize", "compactMode", "reduceAnimations", "librarySort", "historyEnabled", "tmdbLang", "notifyDownloadComplete", "notifyNewEpisode", "episodeReleaseCache", "favorites", "subTextSize", "subTextColor", "subBgStyle", "subBottomOffset", "subtitleTextColor", "subtitleBgStyle", "subtitleFontSizeSp", "seriesPrefs", "webPlayerPrefs", "theme", "customThemeVars", "accentInPlayer", "liveFavorites", "customLiveM3u", "_progressTs", "_watchedTs", "_savedTs", "_liveFavTs", "_settingsTs", "_livePlayback", "_historyDeletedTs", "profiles", "profileData", "_profilesTs"];

const NON_SCALAR_KEYS = new Set(["saved", "savedOrder", "history", "progress", "watched", "liveFavorites", "_progressTs", "_watchedTs", "_savedTs", "_liveFavTs", "_settingsTs", "_livePlayback", "_historyDeletedTs", "_dlTimes", "profiles", "profileData", "_profilesTs"]);

export function getStoredActiveProfileId() {
  try {
    return localStorage.getItem(PREFIX + "active_profile_id") || "prof_main";
  } catch {
    return "prof_main";
  }
}

function setLocalAndNative(shortKey, jsonVal) {
  try { localStorage.setItem(PREFIX + shortKey, jsonVal); } catch {}
  try { window.AndroidBridge?.setPreference?.(shortKey, jsonVal); } catch {}
}

function removeLocalAndNative(shortKey) {
  try { localStorage.removeItem(PREFIX + shortKey); } catch {}
  try { window.AndroidBridge?.removePreference?.(shortKey); } catch {}
}

export function clearProfileLocalKeys() {
  for (const key of PROFILE_DATA_KEYS) {
    removeLocalAndNative(key);
  }
  for (const key of PLAYER_PREF_KEYS) {
    removeLocalAndNative(key);
  }
  try {
    const toRemove = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && (k.startsWith(PREFIX + "dlTime_") || k.startsWith("dlTime_"))) {
        toRemove.push(k);
      }
    }
    for (const k of toRemove) {
      localStorage.removeItem(k);
      if (k.startsWith(PREFIX)) {
        try { window.AndroidBridge?.removePreference?.(k.slice(PREFIX.length)); } catch {}
      }
    }
  } catch {}
}

export function extractCurrentProfileBucket() {
  const bucket = {};
  for (const key of PROFILE_DATA_KEYS) {
    try {
      const raw = localStorage.getItem(PREFIX + key);
      if (raw !== null) bucket[key] = JSON.parse(raw);
    } catch {}
  }
  const dlTimes = {};
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(PREFIX + "dlTime_")) {
        const raw = localStorage.getItem(k);
        if (raw !== null) dlTimes[k.slice(PREFIX.length)] = JSON.parse(raw);
      }
    }
  } catch {}
  if (Object.keys(dlTimes).length > 0) bucket._dlTimes = dlTimes;
  bucket.playerPrefs = readCurrentProfilePlayerPrefs();
  return bucket;
}

export function applyProfileBucketToLocal(bucket) {
  clearProfileLocalKeys();
  const b = bucket && typeof bucket === "object" ? bucket : {};
  for (const key of PROFILE_DATA_KEYS) {
    if (key === "playerPrefs") continue;
    if (b[key] !== undefined && b[key] !== null) {
      setLocalAndNative(key, JSON.stringify(b[key]));
    }
  }
  const mergedPrefs = { ...(b.playerPrefs && typeof b.playerPrefs === "object" ? b.playerPrefs : {}) };
  for (const pk of PLAYER_PREF_KEYS) {
    if (b[pk] !== undefined && b[pk] !== null && mergedPrefs[pk] === undefined) mergedPrefs[pk] = b[pk];
  }
  for (const key of PLAYER_PREF_KEYS) {
    if (mergedPrefs[key] !== undefined && mergedPrefs[key] !== null) {
      setLocalAndNative(key, JSON.stringify(mergedPrefs[key]));
    } else {
      removeLocalAndNative(key);
    }
  }
  if (b._dlTimes && typeof b._dlTimes === "object") {
    for (const [k, v] of Object.entries(b._dlTimes)) {
      setLocalAndNative(k, JSON.stringify(v));
    }
  }
}

export function touchBackupTimestamp(mapKey, itemKey) {
  try {
    const raw = localStorage.getItem(PREFIX + mapKey);
    const obj = raw ? JSON.parse(raw) : {};
    obj[itemKey] = Date.now();
    setLocalAndNative(mapKey, JSON.stringify(obj));
  } catch {}
}

export function touchSettingsTimestamp() {
  try {
    setLocalAndNative("_settingsTs", JSON.stringify(Date.now()));
  } catch {}
}

export function collectBackupData() {
  const data = {};
  for (const key of BACKUP_KEYS) {
    try {
      const raw = localStorage.getItem(PREFIX + key);
      if (raw !== null) data[key] = JSON.parse(raw);
    } catch {}
  }
  const dlTimes = {};
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.startsWith(PREFIX + "dlTime_")) {
        const raw = localStorage.getItem(k);
        if (raw !== null) dlTimes[k.slice(PREFIX.length)] = JSON.parse(raw);
      }
    }
  } catch {}
  if (Object.keys(dlTimes).length > 0) {
    data._dlTimes = dlTimes;
  }
  const pid = getStoredActiveProfileId();
  const pMap = (data.profileData && typeof data.profileData === "object") ? { ...data.profileData } : {};
  pMap[pid] = extractCurrentProfileBucket();
  data.profileData = pMap;
  return data;
}

export function clearBackupData() {
  for (const key of BACKUP_KEYS) {
    try {
      localStorage.removeItem(PREFIX + key);
    } catch {}
  }
  try {
    const toRemove = [];
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && (k.startsWith(PREFIX + "dlTime_") || k.startsWith("dlTime_"))) {
        toRemove.push(k);
      }
    }
    for (const k of toRemove) {
      localStorage.removeItem(k);
    }
  } catch {}
}

function normalizeShowTitle(t) {
  return String(t || "").trim().toLowerCase().replace(/[^a-z0-9\u0600-\u06ff]+/g, " ").trim();
}

export function deduplicateHistoryList(list) {
  const arr = Array.isArray(list) ? list : [];
  const sorted = [...arr].filter(h => h && h.id).sort((a, b) => Number(b.watchedAt || 0) - Number(a.watchedAt || 0));
  const seenKeys = new Set();
  const seenTvTitles = new Set();
  const out = [];
  for (const h of sorted) {
    if (h.media_type === "tv") {
      const idKey = `tv_${String(h.id)}`;
      const titleKey = normalizeShowTitle(h.title || h.name);
      if (seenKeys.has(idKey) || (titleKey && seenTvTitles.has(titleKey))) continue;
      seenKeys.add(idKey);
      if (titleKey) seenTvTitles.add(titleKey);
      out.push(h);
    } else {
      const mk = `movie_${String(h.id)}`;
      if (seenKeys.has(mk)) continue;
      seenKeys.add(mk);
      out.push(h);
    }
  }
  return out.slice(0, 100);
}

function mergeProfileBucket(loc = {}, rem = {}) {
  const merged = {};
  const locLp = loc._livePlayback && typeof loc._livePlayback === "object" ? loc._livePlayback : null;
  const remLp = rem._livePlayback && typeof rem._livePlayback === "object" ? rem._livePlayback : null;
  const locLpTs = Number(locLp?.updatedAt || 0);
  const remLpTs = Number(remLp?.updatedAt || 0);
  if (remLpTs > locLpTs && remLp) {
    merged._livePlayback = remLp;
  } else if (locLp) {
    merged._livePlayback = locLp;
  } else if (remLp) {
    merged._livePlayback = remLp;
  }

  const locProgTs = loc._progressTs && typeof loc._progressTs === "object" ? loc._progressTs : {};
  const remProgTs = rem._progressTs && typeof rem._progressTs === "object" ? rem._progressTs : {};
  const locProg = loc.progress && typeof loc.progress === "object" ? loc.progress : {};
  const remProg = rem.progress && typeof rem.progress === "object" ? rem.progress : {};
  const locDl = loc._dlTimes && typeof loc._dlTimes === "object" ? loc._dlTimes : {};
  const remDl = rem._dlTimes && typeof rem._dlTimes === "object" ? rem._dlTimes : {};

  const outProg = {};
  const outProgTs = {};
  const outDl = { ...remDl, ...locDl };
  const progKeys = new Set([...Object.keys(locProg), ...Object.keys(remProg), ...Object.keys(locProgTs), ...Object.keys(remProgTs)]);
  for (const k of progKeys) {
    const lt = Number(locProgTs[k] || 0);
    const rt = Number(remProgTs[k] || 0);
    const dlKey = "dlTime_" + k;
    const lvNum = locProg[k] !== undefined ? Number(locProg[k] || 0) : null;
    const rvNum = remProg[k] !== undefined ? Number(remProg[k] || 0) : null;
    const lSec = Number(locDl[dlKey] || 0);
    const rSec = Number(remDl[dlKey] || 0);
    const locIsStub = lvNum !== null && lvNum <= 1 && lSec <= 3;
    const remIsStub = rvNum !== null && rvNum <= 1 && rSec <= 3;
    const locHasReal = lvNum !== null && (lvNum > 1 || lSec > 5);
    const remHasReal = rvNum !== null && (rvNum > 1 || rSec > 5);
    if (locIsStub && remHasReal) {
      outProg[k] = remProg[k];
      outProgTs[k] = Math.max(lt, rt);
      if (remDl[dlKey] !== undefined) outDl[dlKey] = remDl[dlKey];
    } else if (remIsStub && locHasReal) {
      outProg[k] = locProg[k];
      outProgTs[k] = Math.max(lt, rt);
      if (locDl[dlKey] !== undefined) outDl[dlKey] = locDl[dlKey];
    } else if (Math.abs(rt - lt) < 300000 && locHasReal && remHasReal && lvNum < 92 && rvNum < 92) {
      if (rSec > lSec || (rSec === lSec && (rvNum || 0) > (lvNum || 0))) {
        outProg[k] = remProg[k];
        outProgTs[k] = Math.max(lt, rt);
        if (remDl[dlKey] !== undefined) outDl[dlKey] = remDl[dlKey];
      } else {
        outProg[k] = locProg[k];
        outProgTs[k] = Math.max(lt, rt);
        if (locDl[dlKey] !== undefined) outDl[dlKey] = locDl[dlKey];
      }
    } else if (rt > lt) {
      if (remProg[k] !== undefined) outProg[k] = remProg[k];
      else delete outDl[dlKey];
      outProgTs[k] = rt;
      if (remDl[dlKey] !== undefined && remProg[k] !== undefined) outDl[dlKey] = remDl[dlKey];
    } else if (lt > rt) {
      if (locProg[k] !== undefined) outProg[k] = locProg[k];
      else delete outDl[dlKey];
      outProgTs[k] = lt;
      if (locDl[dlKey] !== undefined && locProg[k] !== undefined) outDl[dlKey] = locDl[dlKey];
    } else {
      const lv = locProg[k] !== undefined ? Number(locProg[k] || 0) : null;
      const rv = remProg[k] !== undefined ? Number(remProg[k] || 0) : null;
      if (lv !== null || rv !== null) {
        outProg[k] = Math.max(lv || 0, rv || 0);
        if ((rv || 0) > (lv || 0) && remDl[dlKey] !== undefined) outDl[dlKey] = remDl[dlKey];
      }
      if (Math.max(lt, rt) > 0) outProgTs[k] = Math.max(lt, rt);
    }
  }
  merged.progress = outProg;
  merged._progressTs = outProgTs;
  merged._dlTimes = outDl;

  const locWatchTs = loc._watchedTs && typeof loc._watchedTs === "object" ? loc._watchedTs : {};
  const remWatchTs = rem._watchedTs && typeof rem._watchedTs === "object" ? rem._watchedTs : {};
  const locWatch = loc.watched && typeof loc.watched === "object" ? loc.watched : {};
  const remWatch = rem.watched && typeof rem.watched === "object" ? rem.watched : {};
  const outWatch = {};
  const outWatchTs = {};
  const watchKeys = new Set([...Object.keys(locWatch), ...Object.keys(remWatch), ...Object.keys(locWatchTs), ...Object.keys(remWatchTs)]);
  for (const k of watchKeys) {
    const lt = Number(locWatchTs[k] || 0);
    const rt = Number(remWatchTs[k] || 0);
    const val = rt > lt ? !!remWatch[k] : lt > rt ? !!locWatch[k] : !!(locWatch[k] || remWatch[k]);
    if (val) outWatch[k] = true;
    const ts = Math.max(lt, rt);
    if (ts > 0) outWatchTs[k] = ts;
  }
  merged.watched = outWatch;
  merged._watchedTs = outWatchTs;

  const locSavedTs = loc._savedTs && typeof loc._savedTs === "object" ? loc._savedTs : {};
  const remSavedTs = rem._savedTs && typeof rem._savedTs === "object" ? rem._savedTs : {};
  const locSaved = loc.saved && typeof loc.saved === "object" ? loc.saved : {};
  const remSaved = rem.saved && typeof rem.saved === "object" ? rem.saved : {};
  const outSaved = {};
  const outSavedTs = {};
  const savedKeys = new Set([...Object.keys(locSaved), ...Object.keys(remSaved), ...Object.keys(locSavedTs), ...Object.keys(remSavedTs)]);
  for (const k of savedKeys) {
    const lt = Number(locSavedTs[k] || 0);
    const rt = Number(remSavedTs[k] || 0);
    const lEntry = locSaved[k];
    const rEntry = remSaved[k];
    let entry = null;
    if (rt > lt) {
      entry = rEntry !== undefined ? rEntry : (lt === 0 && lEntry ? lEntry : null);
    } else if (lt > rt) {
      entry = lEntry !== undefined ? lEntry : (rt === 0 && rEntry ? rEntry : null);
    } else {
      entry = lEntry || rEntry;
    }
    if (entry) outSaved[k] = entry;
    const ts = Math.max(lt, rt, entry ? Number(entry.savedAt || entry.addedAt || 1) : 0);
    if (ts > 0) outSavedTs[k] = ts;
  }
  merged.saved = outSaved;
  merged._savedTs = outSavedTs;

  const locOrder = Array.isArray(loc.savedOrder) ? loc.savedOrder : [];
  const remOrder = Array.isArray(rem.savedOrder) ? rem.savedOrder : [];
  const orderSet = new Set();
  const outOrder = [];
  for (const k of [...locOrder, ...remOrder, ...Object.keys(outSaved)]) {
    if (outSaved[k] && !orderSet.has(k)) {
      orderSet.add(k);
      outOrder.push(k);
    }
  }
  merged.savedOrder = outOrder;

  const locHistDel = loc._historyDeletedTs && typeof loc._historyDeletedTs === "object" ? loc._historyDeletedTs : {};
  const remHistDel = rem._historyDeletedTs && typeof rem._historyDeletedTs === "object" ? rem._historyDeletedTs : {};
  const outHistDel = {};
  for (const k of new Set([...Object.keys(locHistDel), ...Object.keys(remHistDel)])) {
    const ts = Math.max(Number(locHistDel[k] || 0), Number(remHistDel[k] || 0));
    if (ts > 0) outHistDel[k] = ts;
  }
  merged._historyDeletedTs = outHistDel;

  const allHist = [...(Array.isArray(rem.history) ? rem.history : []), ...(Array.isArray(loc.history) ? loc.history : [])].filter(h => {
    if (!h || !h.id) return false;
    const wAt = Number(h.watchedAt || 0);
    const idDelKey = h.media_type === "tv" ? `tv_${String(h.id)}` : `movie_${String(h.id)}`;
    if (Number(outHistDel[idDelKey] || 0) >= wAt && Number(outHistDel[idDelKey] || 0) > 0) return false;
    if (h.media_type === "tv") {
      const tk = normalizeShowTitle(h.title || h.name);
      if (tk && Number(outHistDel["tv_t_" + tk] || 0) >= wAt && Number(outHistDel["tv_t_" + tk] || 0) > 0) return false;
    }
    return true;
  });
  merged.history = deduplicateHistoryList(allHist);

  const locFavTs = loc._liveFavTs && typeof loc._liveFavTs === "object" ? loc._liveFavTs : {};
  const remFavTs = rem._liveFavTs && typeof rem._liveFavTs === "object" ? rem._liveFavTs : {};
  const locFavMap = new Map();
  for (const f of Array.isArray(loc.liveFavorites) ? loc.liveFavorites : []) {
    if (f && f.url) locFavMap.set(f.url, f);
  }
  const remFavMap = new Map();
  for (const f of Array.isArray(rem.liveFavorites) ? rem.liveFavorites : []) {
    if (f && f.url) remFavMap.set(f.url, f);
  }
  const outFavs = [];
  const outFavTs = {};
  const allFavUrls = new Set([...locFavMap.keys(), ...remFavMap.keys(), ...Object.keys(locFavTs), ...Object.keys(remFavTs)]);
  for (const u of allFavUrls) {
    const lt = Number(locFavTs[u] || 0);
    const rt = Number(remFavTs[u] || 0);
    const entry = rt > lt ? remFavMap.get(u) : lt > rt ? locFavMap.get(u) : (locFavMap.get(u) || remFavMap.get(u));
    if (entry) outFavs.push(entry);
    const ts = Math.max(lt, rt);
    if (ts > 0) outFavTs[u] = ts;
  }
  return merged;
}

export function mergeBackupData(localData = {}, remoteData = {}) {
  const loc = localData && typeof localData === "object" ? localData : {};
  const rem = remoteData && typeof remoteData === "object" ? remoteData : {};
  const locSetTs = Number(loc._settingsTs || 0);
  const remSetTs = Number(rem._settingsTs || 0);
  const settingsWinner = remSetTs > locSetTs ? rem : loc;
  const merged = {};
  for (const key of BACKUP_KEYS) {
    if (NON_SCALAR_KEYS.has(key)) continue;
    if (settingsWinner[key] !== undefined) {
      merged[key] = settingsWinner[key];
    }
  }
  merged._settingsTs = Math.max(locSetTs, remSetTs);

  const locFavTs = loc._liveFavTs && typeof loc._liveFavTs === "object" ? loc._liveFavTs : {};
  const remFavTs = rem._liveFavTs && typeof rem._liveFavTs === "object" ? rem._liveFavTs : {};
  const locFavMap = new Map();
  for (const f of Array.isArray(loc.liveFavorites) ? loc.liveFavorites : []) {
    if (f && f.url) locFavMap.set(f.url, f);
  }
  const remFavMap = new Map();
  for (const f of Array.isArray(rem.liveFavorites) ? rem.liveFavorites : []) {
    if (f && f.url) remFavMap.set(f.url, f);
  }
  const outFavs = [];
  const outFavTs = {};
  for (const u of new Set([...locFavMap.keys(), ...remFavMap.keys(), ...Object.keys(locFavTs), ...Object.keys(remFavTs)])) {
    const lt = Number(locFavTs[u] || 0);
    const rt = Number(remFavTs[u] || 0);
    const entry = rt > lt ? remFavMap.get(u) : lt > rt ? locFavMap.get(u) : (locFavMap.get(u) || remFavMap.get(u));
    if (entry) outFavs.push(entry);
    const ts = Math.max(lt, rt);
    if (ts > 0) outFavTs[u] = ts;
  }
  merged.liveFavorites = outFavs;
  merged._liveFavTs = outFavTs;

  const locProfTs = Number(loc._profilesTs || 0);
  const remProfTs = Number(rem._profilesTs || 0);
  const remProfs = Array.isArray(rem.profiles) && rem.profiles.length > 0 ? rem.profiles : null;
  const locProfs = Array.isArray(loc.profiles) && loc.profiles.length > 0 ? loc.profiles : null;
  const chosenProfs = (remProfTs >= locProfTs ? (remProfs || locProfs) : (locProfs || remProfs)) || [{ id: "prof_main", name: "Main", avatarColor: "#e50914", isKids: false }];
  merged.profiles = chosenProfs.slice(0, 5);
  merged._profilesTs = Math.max(locProfTs, remProfTs);

  const locPMap = (loc.profileData && typeof loc.profileData === "object") ? loc.profileData : {};
  const remPMap = (rem.profileData && typeof rem.profileData === "object") ? rem.profileData : {};
  const activePid = getStoredActiveProfileId();
  const allPids = new Set([...merged.profiles.map(p => p.id), ...Object.keys(locPMap), ...Object.keys(remPMap), activePid]);
  const outPMap = {};
  for (const pid of allPids) {
    if (!merged.profiles.some(p => p.id === pid)) continue;
    const rawLB = (locPMap[pid] && typeof locPMap[pid] === "object") ? locPMap[pid] : {};
    const rawRB = (remPMap[pid] && typeof remPMap[pid] === "object") ? remPMap[pid] : {};
    const lBucket = pid === activePid ? {
      ...rawLB,
      saved: { ...(rawLB.saved || {}), ...(loc.saved || {}) },
      _savedTs: { ...(rawLB._savedTs || {}), ...(loc._savedTs || {}) },
      progress: { ...(rawLB.progress || {}), ...(loc.progress || {}) },
      _progressTs: { ...(rawLB._progressTs || {}), ...(loc._progressTs || {}) },
      watched: { ...(rawLB.watched || {}), ...(loc.watched || {}) },
      _watchedTs: { ...(rawLB._watchedTs || {}), ...(loc._watchedTs || {}) },
      history: Array.isArray(loc.history) && loc.history.length > 0 ? loc.history : (rawLB.history || []),
      _dlTimes: { ...(rawLB._dlTimes || {}), ...(loc._dlTimes || {}) }
    } : rawLB;
    const rBucket = (pid === "prof_main" && (!rem.profileData || !remPMap[pid])) ? {
      ...rem,
      ...rawRB,
      saved: { ...(rem.saved || {}), ...(rawRB.saved || {}) },
      _savedTs: { ...(rem._savedTs || {}), ...(rawRB._savedTs || {}) }
    } : rawRB;
    outPMap[pid] = mergeProfileBucket(lBucket, rBucket);
  }
  merged.profileData = outPMap;
  const effectivePid = merged.profileData[activePid] ? activePid : (merged.profiles[0]?.id || "prof_main");
  const activeBucket = merged.profileData[effectivePid] || {};
  for (const k of PROFILE_DATA_KEYS) {
    if (activeBucket[k] !== undefined) merged[k] = activeBucket[k];
  }
  if (activeBucket._dlTimes) merged._dlTimes = activeBucket._dlTimes;
  if (activeBucket.playerPrefs && typeof activeBucket.playerPrefs === "object") { for (const [pk, pv] of Object.entries(activeBucket.playerPrefs)) { if (pv !== undefined) merged[pk] = pv; } }
  return merged;
}

export function restoreBackupData(data) {
  if (!data || typeof data !== "object") throw new Error("Invalid backup data");
  for (const key of BACKUP_KEYS) {
    removeLocalAndNative(key);
  }
  for (const key of BACKUP_KEYS) {
    if (data[key] !== undefined && data[key] !== null) {
      setLocalAndNative(key, JSON.stringify(data[key]));
    }
  }
  const profs = Array.isArray(data.profiles) && data.profiles.length > 0 ? data.profiles : null;
  let activePid = getStoredActiveProfileId();
  if (profs && !profs.some(p => p && p.id === activePid)) {
    activePid = profs[0].id;
    setLocalAndNative("active_profile_id", activePid);
  }
  const pBucket = (data.profileData && typeof data.profileData === "object" && data.profileData[activePid]) ? data.profileData[activePid] : null;
  if (pBucket) {
    applyProfileBucketToLocal(pBucket);
  } else if (data._dlTimes && typeof data._dlTimes === "object") {
    for (const [k, v] of Object.entries(data._dlTimes)) {
      setLocalAndNative(k, JSON.stringify(v));
    }
  }
}
