package com.singularity.tv.bridge

import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.net.Uri
import android.os.Environment
import android.webkit.JavascriptInterface
import androidx.core.app.NotificationCompat
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import androidx.work.Data
import androidx.work.ExistingWorkPolicy
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import com.singularity.tv.BuildConfig
import com.singularity.tv.MainActivity
import com.singularity.tv.StreambertApp
import com.singularity.tv.data.DownloadEntity
import com.singularity.tv.data.PreferenceEntity
import com.singularity.tv.download.StreamDownloadWorker
import com.singularity.tv.player.NativeExoPlayerActivity
import com.singularity.tv.stream.HiAnimeResolver
import com.singularity.tv.webview.AdBlockerInterceptor
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

class StreambertJsBridge(
    private val activity: MainActivity,
    private val dispatchToWeb: (String, String) -> Unit
) {

    private val db get() = StreambertApp.instance.database
    private val numericIdCache = ConcurrentHashMap<String, String>()

    private val securePrefs by lazy {
        val masterKey = MasterKey.Builder(activity)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()
        EncryptedSharedPreferences.create(
            activity,
            "streambert_secure_store",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    @JavascriptInterface
    fun isTvDevice(): Boolean {
        if (BuildConfig.FORCE_TV_MODE || activity.forceTvMode) return true
        val uiMode = activity.resources.configuration.uiMode
        if ((uiMode and Configuration.UI_MODE_TYPE_MASK) == Configuration.UI_MODE_TYPE_TELEVISION) return true
        val umm = activity.getSystemService(Context.UI_MODE_SERVICE) as? android.app.UiModeManager
        if (umm?.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION) return true
        val pm = activity.packageManager
        if (pm.hasSystemFeature(PackageManager.FEATURE_LEANBACK) || pm.hasSystemFeature(PackageManager.FEATURE_TELEVISION)) return true
        return !pm.hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN)
    }

    @JavascriptInterface
    fun getAppVersion(): String = BuildConfig.VERSION_NAME

    @JavascriptInterface
    fun tapPlayerCenter(xRatio: Float, yRatio: Float) {
        activity.simulateTap(xRatio, yRatio)
    }

    @JavascriptInterface
    fun setImmersiveMode(enabled: Boolean): String {
        activity.setPlaybackImmersive(enabled)
        return JSONObject().put("ok", true).toString()
    }

    @JavascriptInterface
    fun resolveNumericId(imdbId: String, mediaType: String): String {
        val cleanId = imdbId.trim()
        if (cleanId.all { it.isDigit() } && cleanId.isNotEmpty()) return cleanId
        val cacheKey = "$mediaType:$cleanId"
        numericIdCache[cacheKey]?.let { return it }

        try {
            val redirectUrl = "https://www.themoviedb.org/redirect?external_source=imdb_id&external_id=${URLEncoder.encode(cleanId, "UTF-8")}"
            val conn = (URL(redirectUrl).openConnection() as HttpURLConnection).apply {
                instanceFollowRedirects = false
                connectTimeout = 5000
                readTimeout = 5000
                setRequestProperty(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
                )
            }
            conn.connect()
            val location = conn.getHeaderField("Location") ?: ""
            conn.disconnect()
            val match = Regex("""/(?:movie|tv)/(\d+)""").find(location)
            val num = match?.groupValues?.getOrNull(1)
            if (!num.isNullOrBlank()) {
                numericIdCache[cacheKey] = num
                return num
            }
        } catch (_: Exception) {}

        try {
            val cType = if (mediaType == "tv") "series" else "movie"
            val req = Request.Builder()
                .url("https://cinemeta-live.strem.io/meta/$cType/${URLEncoder.encode(cleanId, "UTF-8")}.json")
                .header("Accept", "application/json")
                .build()
            StreambertApp.instance.okHttpClient.newCall(req).execute().use { res ->
                if (res.isSuccessful) {
                    val body = res.body?.string() ?: ""
                    val meta = JSONObject(body).optJSONObject("meta")
                    val numId = meta?.optInt("moviedb_id", 0) ?: 0
                    if (numId > 0) {
                        val s = numId.toString()
                        numericIdCache[cacheKey] = s
                        return s
                    }
                }
            }
        } catch (_: Exception) {}

        try {
            val sparql = """SELECT ?m ?t WHERE { ?item wdt:P345 "$cleanId" . OPTIONAL { ?item wdt:P4947 ?m . } OPTIONAL { ?item wdt:P4983 ?t . } } LIMIT 1"""
            val req = Request.Builder()
                .url("https://query.wikidata.org/sparql?format=json&query=${URLEncoder.encode(sparql, "UTF-8")}")
                .header("Accept", "application/sparql-results+json")
                .header("User-Agent", "StreambertAndroid/2.7.0")
                .build()
            StreambertApp.instance.okHttpClient.newCall(req).execute().use { res ->
                if (res.isSuccessful) {
                    val body = res.body?.string() ?: ""
                    val bindings = JSONObject(body)
                        .optJSONObject("results")
                        ?.optJSONArray("bindings")
                    val row = bindings?.optJSONObject(0)
                    val mVal = row?.optJSONObject("m")?.optString("value")
                    val tVal = row?.optJSONObject("t")?.optString("value")
                    val picked = if (mediaType == "tv") (tVal ?: mVal) else (mVal ?: tVal)
                    if (!picked.isNullOrBlank()) {
                        numericIdCache[cacheKey] = picked
                        return picked
                    }
                }
            }
        } catch (_: Exception) {}

        return ""
    }

    @JavascriptInterface
    fun getAllPreferencesJson(): String {
        return try {
            val map = JSONObject()
            for (p in db.preferenceDao().getAllSync()) {
                map.put(p.key, p.valueJson)
            }
            map.toString()
        } catch (_: Throwable) {
            "{}"
        }
    }

    @JavascriptInterface
    fun getPreference(key: String): String? {
        return try {
            db.preferenceDao().getValueSync(key)
        } catch (_: Throwable) {
            null
        }
    }

    @JavascriptInterface
    fun setPreference(key: String, valueJson: String) {
        try {
            db.preferenceDao().upsertSync(PreferenceEntity(key = key, valueJson = valueJson))
        } catch (_: Throwable) {}
    }

    @JavascriptInterface
    fun removePreference(key: String) {
        try {
            db.preferenceDao().deleteSync(key)
        } catch (_: Throwable) {}
    }

    @JavascriptInterface
    fun clearPreferences() {
        try {
            db.preferenceDao().clearAllSync()
        } catch (_: Throwable) {}
    }

    @JavascriptInterface
    fun secureGet(key: String): String? {
        return try {
            securePrefs.getString(key, null)
        } catch (_: Throwable) {
            null
        }
    }

    @JavascriptInterface
    fun secureSet(key: String, value: String) {
        if (value.isBlank()) {
            securePrefs.edit().remove(key).apply()
        } else {
            securePrefs.edit().putString(key, value).apply()
        }
    }

    @Volatile
    private var pendingNextServerCallback: ((String?, String?) -> Unit)? = null

    @JavascriptInterface
    fun deliverNextServerStream(url: String, sourceId: String) {
        val cb = pendingNextServerCallback
        pendingNextServerCallback = null
        cb?.invoke(url.ifEmpty { null }, sourceId.ifEmpty { null })
    }

    @JavascriptInterface
    fun openExoPlayer(payloadJson: String): String {
        com.singularity.tv.player.ExoProgressBus.preferredSourceListener = { srcId ->
            activity.runOnUiThread {
                dispatchToWeb("preferred-source-updated", JSONObject.quote(srcId))
            }
        }
        NativeExoPlayerActivity.onNeedNextServer = { currentSource, resumeSec, cb ->
            pendingNextServerCallback = cb
            val req = JSONObject().apply {
                put("currentSource", currentSource)
                put("resumePosSec", resumeSec)
            }
            activity.runOnUiThread {
                dispatchToWeb("player-need-next-server", req.toString())
            }
        }
        activity.runOnUiThread {
            try {
                NativeExoPlayerActivity.isPlayerActive = true
                val intent = Intent(activity, NativeExoPlayerActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra(NativeExoPlayerActivity.EXTRA_PAYLOAD_JSON, payloadJson)
                }
                activity.startActivity(intent)
            } catch (_: Exception) {
                NativeExoPlayerActivity.isPlayerActive = false
            }
        }
        return JSONObject().put("ok", true).toString()
    }

    @JavascriptInterface
    fun enterPipMode(payloadJson: String): String {
        activity.runOnUiThread {
            activity.enterAppPipMode()
        }
        return JSONObject().put("ok", true).toString()
    }

    @JavascriptInterface
    fun exitPipMode(): String {
        return JSONObject().put("ok", true).toString()
    }

    @JavascriptInterface
    fun resolveHiAnime(argsJson: String): String {
        val obj = JSONObject(argsJson)
        val title = obj.optString("title", "")
        val season = obj.optInt("seasonNumber", 1)
        val episode = obj.optInt("episodeNumber", 1)
        val isMovie = obj.optBoolean("isMovie", false)
        val mode = obj.optString("translationType", "sub")

        val res = HiAnimeResolver.resolve(
            title = title,
            seasonNumber = season,
            episodeNumber = episode,
            isMovie = isMovie,
            translationType = mode
        ) { stage ->
            dispatchToWeb("hianime-progress", JSONObject().put("stage", stage).toString())
        }

        return JSONObject().apply {
            put("ok", res.ok)
            if (res.ok) {
                put("url", res.url)
                put("referer", res.referer)
                put("subtitle", res.subtitle)
                put("malId", res.malId)
                put("matchedTitle", res.matchedTitle)
                put("isDirectMp4", false)
            } else {
                put("error", res.error ?: "Failed to resolve stream")
            }
        }.toString()
    }

    @JavascriptInterface
    fun enqueueDownload(argsJson: String): String {
        val obj = JSONObject(argsJson)
        val id = UUID.randomUUID().toString()
        val m3u8Url = obj.optString("m3u8Url")
        val name = obj.optString("name", "SingularityTV Video")
        val defaultDir = File(
            activity.getExternalFilesDir(Environment.DIRECTORY_MOVIES),
            "SingularityTV"
        ).apply { mkdirs() }.absolutePath
        val downloadPath = obj.optString("downloadPath").ifEmpty { defaultDir }
        val headers = AdBlockerInterceptor.streamHeadersMap[m3u8Url] ?: emptyMap()

        val entity = DownloadEntity(
            id = id,
            name = name,
            m3u8Url = m3u8Url,
            downloadPath = downloadPath,
            filePath = null,
            status = "downloading",
            progress = 0,
            speed = "Starting…",
            eta = "",
            size = "",
            totalFragments = 0,
            completedFragments = 0,
            lastMessage = "Queued in WorkManager…",
            startedAt = System.currentTimeMillis(),
            completedAt = null,
            mediaId = obj.optString("mediaId").ifEmpty { null },
            mediaType = obj.optString("mediaType").ifEmpty { null },
            season = if (obj.has("season") && !obj.isNull("season")) obj.optInt("season") else null,
            episode = if (obj.has("episode") && !obj.isNull("episode")) obj.optInt("episode") else null,
            posterPath = obj.optString("posterPath").ifEmpty { null },
            subtitlesJson = (obj.optJSONArray("subtitles") ?: JSONArray()).toString(),
            subtitlePathsJson = "[]",
            refererHeader = headers["Referer"],
            userAgentHeader = headers["User-Agent"]
        )
        db.downloadDao().upsertSync(entity)
        enqueueWorker(id)

        return JSONObject().apply {
            put("ok", true)
            put("id", id)
        }.toString()
    }

    private fun enqueueWorker(downloadId: String) {
        val workReq = OneTimeWorkRequestBuilder<StreamDownloadWorker>()
            .setInputData(Data.Builder().putString(StreamDownloadWorker.KEY_DOWNLOAD_ID, downloadId).build())
            .addTag("dl_$downloadId")
            .build()
        WorkManager.getInstance(activity).enqueueUniqueWork(
            "streambert_dl_$downloadId",
            ExistingWorkPolicy.REPLACE,
            workReq
        )
    }

    @JavascriptInterface
    fun pauseDownload(id: String): String {
        WorkManager.getInstance(activity).cancelUniqueWork("streambert_dl_$id")
        val dao = db.downloadDao()
        dao.getByIdSync(id)?.let { current ->
            val updated = current.copy(status = "paused", speed = "", eta = "", lastMessage = "Paused")
            dao.upsertSync(updated)
            dispatchToWeb("download-progress", downloadToJson(updated).toString())
        }
        return JSONObject().put("ok", true).toString()
    }

    @JavascriptInterface
    fun resumeDownload(id: String): String {
        val dao = db.downloadDao()
        dao.getByIdSync(id)?.let { current ->
            val updated = current.copy(status = "downloading", lastMessage = "Resuming…")
            dao.upsertSync(updated)
            dispatchToWeb("download-progress", downloadToJson(updated).toString())
            enqueueWorker(id)
        }
        return JSONObject().put("ok", true).toString()
    }

    @JavascriptInterface
    fun cancelDownload(id: String): String {
        WorkManager.getInstance(activity).cancelUniqueWork("streambert_dl_$id")
        val dao = db.downloadDao()
        dao.getByIdSync(id)?.let { current ->
            current.filePath?.let { File(it).delete() }
            val updated = current.copy(status = "cancelled", speed = "", eta = "", lastMessage = "Cancelled")
            dao.upsertSync(updated)
            dispatchToWeb("download-progress", downloadToJson(updated).toString())
        }
        return JSONObject().put("ok", true).toString()
    }

    @JavascriptInterface
    fun retryDownload(id: String): String {
        val dao = db.downloadDao()
        dao.getByIdSync(id)?.let { current ->
            val updated = current.copy(
                status = "downloading",
                progress = 0,
                completedFragments = 0,
                lastMessage = "Retrying…"
            )
            dao.upsertSync(updated)
            dispatchToWeb("download-progress", downloadToJson(updated).toString())
            enqueueWorker(id)
        }
        return JSONObject().put("ok", true).toString()
    }

    @JavascriptInterface
    fun getDownloads(): String {
        val arr = JSONArray()
        for (d in db.downloadDao().getAllSync()) {
            arr.put(downloadToJson(d))
        }
        return arr.toString()
    }

    @JavascriptInterface
    fun deleteDownload(argsJson: String): String {
        val obj = JSONObject(argsJson)
        val id = obj.optString("id")
        WorkManager.getInstance(activity).cancelUniqueWork("streambert_dl_$id")
        val entry = db.downloadDao().getByIdSync(id)
        entry?.filePath?.let { File(it).delete() }
        db.downloadDao().deleteByIdSync(id)
        return JSONObject().put("ok", true).toString()
    }

    @JavascriptInterface
    fun deleteAllDownloads(): String {
        val all = db.downloadDao().getAllSync()
        var deleted = 0
        for (d in all) {
            WorkManager.getInstance(activity).cancelUniqueWork("streambert_dl_${d.id}")
            if (d.filePath != null && File(d.filePath).delete()) deleted++
        }
        db.downloadDao().deleteAllSync()
        return JSONObject().apply {
            put("ok", true)
            put("deleted", deleted)
            put("errors", 0)
        }.toString()
    }

    @JavascriptInterface
    fun getDownloadsSize(): String {
        var bytes = 0L
        for (d in db.downloadDao().getAllSync()) {
            val f = d.filePath?.let { File(it) }
            if (f != null && f.exists()) bytes += f.length()
        }
        return JSONObject().put("bytes", bytes).toString()
    }

    @JavascriptInterface
    fun fileExists(filePath: String): Boolean {
        if (filePath.isBlank()) return false
        return File(filePath).exists()
    }

    @JavascriptInterface
    fun pickFolder(): String {
        val dir = File(
            activity.getExternalFilesDir(Environment.DIRECTORY_MOVIES),
            "SingularityTV"
        ).apply { mkdirs() }
        return JSONObject().put("path", dir.absolutePath).toString()
    }

    @JavascriptInterface
    fun scanDirectory(folderPath: String): String {
        val dir = File(folderPath)
        val arr = JSONArray()
        if (!dir.exists() || !dir.isDirectory) return arr.toString()
        val videoExts = setOf("mp4", "mkv", "webm", "avi", "mov", "m4v", "ts")
        dir.walkTopDown().maxDepth(3).forEach { file ->
            if (file.isFile && file.extension.lowercase() in videoExts) {
                arr.put(JSONObject().apply {
                    put("filePath", file.absolutePath)
                    put("name", file.nameWithoutExtension)
                    put("size", "${file.length() / (1024 * 1024)} MB")
                    put("ext", ".${file.extension}")
                })
            }
        }
        return arr.toString()
    }

    @JavascriptInterface
    fun getBlockStats(): String {
        val list = db.blockedDomainDao().getAllSync()
        val domainsObj = JSONObject()
        var total = 0L
        for (item in list) {
            total += item.count
            domainsObj.put(item.domain, item.count)
        }
        return JSONObject().apply {
            put("total", total)
            put("domains", domainsObj)
        }.toString()
    }

    @JavascriptInterface
    fun getCacheSize(): String {
        val bytes = activity.cacheDir.walkBottomUp().fold(0L) { acc, f ->
            acc + if (f.isFile) f.length() else 0L
        }
        return JSONObject().put("bytes", bytes).toString()
    }

    @JavascriptInterface
    fun clearAppCache(): String {
        activity.runOnUiThread {
            activity.clearWebViewCache()
        }
        return JSONObject().put("ok", true).toString()
    }

    @JavascriptInterface
    fun clearWatchData(): String {
        db.playbackProgressDao().clearAllSync()
        return JSONObject().put("ok", true).toString()
    }

    @JavascriptInterface
    fun resetApp(): String {
        db.preferenceDao().clearAllSync()
        db.playbackProgressDao().clearAllSync()
        db.downloadDao().deleteAllSync()
        return JSONObject().put("ok", true).toString()
    }

    @JavascriptInterface
    fun showNotification(argsJson: String) {
        try {
            val obj = JSONObject(argsJson)
            val title = obj.optString("title", "SingularityTV")
            val body = obj.optString("body", "")
            val nm = activity.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
            val notif = NotificationCompat.Builder(activity, StreambertApp.CHANNEL_EPISODES)
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(title)
                .setContentText(body)
                .setAutoCancel(true)
                .build()
            nm.notify(System.currentTimeMillis().toInt(), notif)
        } catch (_: Exception) {}
    }


    @JavascriptInterface
    fun startGoogleOAuth(authUrl: String): String {
        return openExternal(authUrl)
    }

    @JavascriptInterface
    fun openExternal(url: String): String {
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            activity.startActivity(intent)
            JSONObject().put("ok", true).toString()
        } catch (e: Exception) {
            JSONObject().put("ok", false).toString()
        }
    }

    @JavascriptInterface
    fun quitApp() {
        activity.runOnUiThread {
            activity.finishAffinity()
        }
    }

    companion object {
        fun downloadToJson(d: DownloadEntity): JSONObject {
            return JSONObject().apply {
                put("id", d.id)
                put("name", d.name)
                put("m3u8Url", d.m3u8Url)
                put("downloadPath", d.downloadPath)
                put("filePath", d.filePath)
                put("status", d.status)
                put("progress", d.progress)
                put("speed", d.speed)
                put("eta", d.eta)
                put("size", d.size)
                put("totalFragments", d.totalFragments)
                put("completedFragments", d.completedFragments)
                put("lastMessage", d.lastMessage)
                put("startedAt", d.startedAt)
                put("completedAt", d.completedAt)
                put("mediaId", d.mediaId)
                put("tmdbId", d.mediaId)
                put("mediaType", d.mediaType)
                put("season", d.season)
                put("episode", d.episode)
                put("posterPath", d.posterPath)
                put("subtitles", try { JSONArray(d.subtitlesJson) } catch (_: Exception) { JSONArray() })
                put("subtitlePaths", try { JSONArray(d.subtitlePathsJson) } catch (_: Exception) { JSONArray() })
            }
        }
    }

    @Volatile
    private var activeUpdateCall: okhttp3.Call? = null

    @JavascriptInterface
    fun cancelUpdate(): String {
        try { activeUpdateCall?.cancel() } catch (_: Exception) {}
        activeUpdateCall = null
        return JSONObject().put("ok", true).toString()
    }

    @JavascriptInterface
    fun downloadAndInstallUpdate(payloadJson: String): String {
        return try {
            val obj = JSONObject(payloadJson)
            val url = obj.optString("url", "").trim()
            if (url.isEmpty()) return JSONObject().put("ok", false).put("error", "Missing update URL").toString()
            kotlin.concurrent.thread(start = true) {
                try {
                    val dir = java.io.File(activity.cacheDir, "updates")
                    if (!dir.exists()) dir.mkdirs()
                    val outFile = java.io.File(dir, "SingularityTV-update.apk")
                    if (outFile.exists()) outFile.delete()
                    val req = okhttp3.Request.Builder().url(url).header("User-Agent", "SingularityTV/1.0.0").build()
                    val call = com.singularity.tv.StreambertApp.instance.okHttpClient.newCall(req)
                    activeUpdateCall = call
                    call.execute().use { res ->
                        if (!res.isSuccessful) {
                            dispatchToWeb("update-progress", JSONObject().put("percent", 0).put("label", "Download failed (" + res.code + ")").put("error", "HTTP " + res.code).toString())
                            return@thread
                        }
                        val body = res.body ?: throw IllegalStateException("Empty body")
                        val total = body.contentLength()
                        var downloaded = 0L
                        var lastPct = -1
                        body.byteStream().use { input ->
                            java.io.FileOutputStream(outFile).use { output ->
                                val buf = ByteArray(16384)
                                while (true) {
                                    val n = input.read(buf)
                                    if (n == -1) break
                                    output.write(buf, 0, n)
                                    downloaded += n
                                    if (total > 0L) {
                                        val pct = ((downloaded * 100L) / total).toInt().coerceIn(0, 99)
                                        if (pct != lastPct) {
                                            lastPct = pct
                                            val mbDone = String.format(java.util.Locale.US, "%.1f", downloaded / 1048576.0)
                                            val mbTot = String.format(java.util.Locale.US, "%.1f", total / 1048576.0)
                                            dispatchToWeb("update-progress", JSONObject().put("percent", pct).put("label", "Downloading " + mbDone + " / " + mbTot + " MB").toString())
                                        }
                                    }
                                }
                            }
                        }
                    }
                    dispatchToWeb("update-progress", JSONObject().put("percent", 100).put("label", "Launching installer...").put("done", true).toString())
                    activity.runOnUiThread {
                        try {
                            val apkUri = androidx.core.content.FileProvider.getUriForFile(
                                activity,
                                activity.packageName + ".fileprovider",
                                outFile
                            )
                            val installIntent = Intent(Intent.ACTION_VIEW).apply {
                                setDataAndType(apkUri, "application/vnd.android.package-archive")
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
                            }
                            activity.startActivity(installIntent)
                        } catch (e: Exception) {
                            dispatchToWeb("update-progress", JSONObject().put("percent", 100).put("label", "Install error").put("error", e.message ?: "Cannot launch installer").toString())
                        }
                    }
                } catch (e: Exception) {
                    dispatchToWeb("update-progress", JSONObject().put("percent", 0).put("label", "Download failed").put("error", e.message ?: "Download error").toString())
                } finally {
                    activeUpdateCall = null
                }
            }
            JSONObject().put("ok", true).toString()
        } catch (e: Exception) {
            JSONObject().put("ok", false).put("error", e.message ?: "Failed").toString()
        }
    }

}
